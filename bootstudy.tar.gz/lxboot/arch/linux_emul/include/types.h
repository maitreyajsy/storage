#ifndef __EMUL_ARCH_TYPES_H__
#define __EMUL_ARCH_TYPES_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdint.h>
#include <limits.h>
#include <ctype.h>

typedef signed 		char 	s8;
typedef unsigned 	char 	u8;

typedef signed 		short 	s16;
typedef unsigned 	short 	u16;

typedef signed 		int 	s32;
typedef unsigned 	int 	u32;

typedef signed long long	s64;
typedef unsigned long long	u64;

typedef unsigned	int		dma_addr_t;

#define IO_WRITE(x,v)		(*((volatile u32 *)(x)) = v)
#define IO_READ(x)			(*((volatile u32 *)(x)))

#define REG_WRITE(x,v)		IO_WRITE(x,v)
#define REG_READ(x)			IO_READ(x)

#endif // _TYPEDEF__HEADER_
