#ifndef __ARCH_CPU_H__
#define __ARCH_CPU_H__

#include <arch/cpu_registers.h>

#define PRIMARY_CPU				0x0
#define SECONDARY_CPU			0x1


#ifdef __ASSEMBLY__
.macro get_cpuid, reg
	mrc		p15, 0, \reg, c0, c0, 5
	and		\reg, \reg, #0xf
.endm

#else
static inline unsigned long read_cp15_sctlr(void)
{
	unsigned long value;
	asm volatile("mrc	p15, 0, %0, c1, c0, 0\n"
				: "=r" (value):: "memory");
	return value;
}

static inline void write_cp15_sctlr(unsigned long v)
{
	asm volatile("mcr	p15, 0, %0, c1, c0, 0\n"
				:: "r" (v): "memory");

}

#define isb()	asm("isb")
#define dsb()	asm("dsb")
#define dmb()	asm("dmb")

// in cacheops.S
void flush_dcache(void);
void clean_dcache(void);
void inv_dcache(void);

#endif

#endif /* __ARCH_CPU_H__ */
