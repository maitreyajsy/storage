#ifndef __ARCH_CPU_REGISTERS_H__
#define __ARCH_CPU_REGISTERS_H__

/*
 * RAZ	- Read-As-Zero
 * SBZ	- Should Be Zero
 * SBZP	- SBZ or Preserved
 * UNP	- Unpredictable Value
 * SBO	- Should Be One
 * SBOP	- SBO or Predictable
 * WI	- Writes Ignored
 * UNK	- Unknown
 */

/* System Control Register : c1, c0, 0 */
#define CP15_SCTLR_M_ENABLE		(0x01 << 0)		/* MMU E/D(enable/disable) */
#define CP15_SCTLR_A_ENABLE		(0x01 << 1)		/* Strict data address alignment fault E/D */
#define CP15_SCTLR_C_ENABLE		(0x01 << 2)		/* Level one data cache E/D */
/* [6:3]	RAO/SBOP	*/
/* [9:7]	RAZ/SBZP	*/
#define CP15_SCTLR_SW_ENABLE	(0x01 << 10)	/* SWP/SWPB Enable bit */
#define CP15_SCTLR_Z_ENABLE		(0x01 << 11)	/* Program flow prediction */
#define CP15_SCTLR_I_ENABLE		(0x01 << 12)	/* Level one instruction cache E/D */
#define CP15_SCTLR_VECTOR		(0x01 << 13)	/* Location of exception vectors */
#define CP15_SCTLR_RR			(0x01 << 14)	/* Replacement strategy for caches, BTAC, and micro TLBs */
/* [15]		RAZ/SBZP	*/
/* [16]		RAO/SBOP	*/
#define CP15_SCTLR_HA_ENABLE	(0x01 << 17)	/* RAZ/WI, Hardware Access Flag Enable bit */
/* [18]		RAO/SBOP	*/
/* [20:19]	RAZ/SBZP	*/
/* [21]		RAZ/WI		*/
/* [23:22]	RAO/SBOP	*/
/* [24]		RAZ/WI		*/
#define CP15_SCTLR_EE_SET		(0x01 << 25)	/* Exception Endianness. 0:Little, 1:Big */
/* [26]		SBZ/RAZ		*/
#define CP15_SCTLR_NMFI			(0x01 << 27)	/* NMFI, nonmaskable. read-only */
#define CP15_SCTLR_TRE_ENABLE	(0x01 << 28)	/* TEX Remap Enable */
#define CP15_SCTLR_AFE_ENABLE	(0x01 << 29)	/* Access Flag Enable */
#define CP15_SCTLR_TE_ENABLE	(0x01 << 30)	/* Thumb Exception enable */
/* [31]		UNK/SBZP	*/



/* Auxiliary Control Register : c1, c0, 1 */
#define CP15_ACTLR_FW_ENABLE	(0x01 << 0)		/* Cache and TLB maintenance broadcast */
#define CP15_ACTLR_L2_PREFETCH	(0x01 << 1)		/* Prefetch hint enable */
#define CP15_ACTLR_L1_PREFECTCH	(0x01 << 2)		/* Dside prefetch */
#define CP15_ACTLR_WFL_OF_ZEROS	(0x01 << 3)		/* Enable write full line of zeros mode */
/* [5:4] RAZ/WI 		*/
#define CP15_ACTLR_SMP			(0x01 << 6)		/* Signals if the Cortex-A9 processor is taking part in coherency or not */
#define CP15_ACTLR_EXCL			(0x01 << 7)		/* Exclusive cache bit */
#define CP15_ACTLR_ALLOC_ONEWAY	(0x01 << 8)		/* Enable allocation in one cache way only */
#define CP15_ACTLR_PARITY_ON	(0x01 << 9)		/* Support for parity checking, if implemented */
/* [31:10] UNP/SBZP		*/


/* Non-secure Access Control Register : c1, c1, 2 */
/* [9:0] UNK/SBZP		*/
#define CP15_NSACR_CP10			(0x01 << 10)	/* Determines permission to access coprocessor 10 in the NS */
#define CP15_NSACR_CP11			(0x01 << 11)	/* Determines permission to access coprocessor 11 in the NS */
/* [13:12] UNK/SBZP		*/
#define CP15_NSACR_NSD32DIS		(0x01 << 14)	/* Disable the NS use of D16-D31 of the VFP register file */
#define CP15_NSACR_NSASEDIS		(0x01 << 15)	/* Disable NS Advanced SIMD Extension functionality */
#define CP15_NSACR_PLE			(0x01 << 16)	/* Controls NS accesses to the Preload Engine resources */
#define CP15_NSACR_TL			(0x01 << 17)	/* Determines if lockable TLB entries can be allocated in NS */
#define CP15_NSACR_NS_SMP		(0x01 << 18)	/* Determines if the SMP bit of the ACR is writable in NS */
/* [31:19] UNK/SBZP		*/



#define SCR_ENABLE						(0x24)
#define TZ_NSACR_MASK					(0x0000C000)
#define TZ_NSACR_ENABLE					(0x00043FFF)/* NS_SMP */
#define SECURE_INT_MASK0				(0xFFFFFFFF)


#endif /* __ARCH_CPU_REGISTERS_H__ */
