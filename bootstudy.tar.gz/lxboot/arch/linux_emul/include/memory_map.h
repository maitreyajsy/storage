#ifndef __ARCH_MEMORY_MAP_H__
#define __ARCH_MEMORY_MAP_H__

#define DATA_BUF_BASE		0x0000000
#define DATA_BUF_SIZE		0x0200000

#define KERNEL_ENTRY_POINT	0x00008000
#define KERNEL_LOAD_BASE	0x01000000		/* If the kernel was compressed then load at this address */
#define KERNEL_PARAM_BASE	0x00001000

#endif
