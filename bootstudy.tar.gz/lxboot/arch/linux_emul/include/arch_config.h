#ifndef __ARCH_CONFIG_H__
#define __ARCH_CONFIG_H__

#define	ARCH_NAME			"Emulator"

#define SPEED_984MHZ		(984*MHZ)
#define SPEED_792MHZ		(792*MHZ)


#define	CPU_SPEED			SPEED_984MHZ
#define CPU_CLOCK			SPEED_984MHZ
#define DDR_CLOCK			SPEED_792MHZ

#define	FCLK				DDR_CLOCK

#define HCLK				(FCLK >> 2)
#define PCLK				(FCLK >> 2)

#define UART_CLK			PCLK
#define TIMER_CLK			PCLK
#define I2C_CLK				PCLK


#define EMAC_BASE			LG1152_FEMAC_BASE
#define PL011_UART_BASE		{LG1152_UART0_BASE, LG1152_UART1_BASE, LG1152_UART2_BASE}
#define NFC_BASE			LG1152_NANDC_BASE
#define I2C_BASE			{LG1152_I2C0_BASE, LG1152_I2C1_BASE, LG1152_I2C2_BASE, LG1152_I2C3_BASE, \
							 LG1152_I2C4_BASE, LG1152_I2C5_BASE, LG1152_I2C6_BASE, LG1152_I2C7_BASE, \
							 LG1152_I2C8_BASE}


/* if you want to change belows, redefine or undefine it in platform_config.h */
//#define USE_TZ_BOOT				1	/* TrustZone Boot */
#define USE_IRQ					0
#define USE_DATA_CACHE			0

#define TIMER_FREQ				1000

#define USE_NAND				1
#define NAND_ECC_BIT			4
#define USE_NAND_IRQ			1
#define USE_NAND_BBM			1
#define USE_MTD_INFO			1

#define USE_DTVSOC_I2C			0

#define CONSOLE_UART_PORT		0
#define CONSOLE_UART_BAUDRATE	BAUDRATE_115200

#endif  // __ARCH_CONFIG_H__

