/*
 * $Copyright (c) 2008-2009, ARM Ltd. All rights reserved.

 * -------------------------------------------------------

 * File:     mmu.h

 * $
 *
 * Headers for mmu.s
 *
 */


#ifndef __ARCH_MMU_H__
#define __ARCH_MMU_H__

#endif
