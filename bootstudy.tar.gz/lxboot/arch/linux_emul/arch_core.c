/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
void cpu_init(void)
{

}

void cpu_exit(void)
{

}

uint32_t get_chip_rev(void)
{
	return CONFIG_CHIP;
}
/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
void mmu_init(void)
{

}

void mmu_disable(void)
{

}

uint8_t mmu_status(void)
{
	return 1;
}


/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
int gpio_set_top(uint32_t port)
{

}

int gpio_set_direction(uint32_t port, int dir)
{
}

int gpio_set_value(uint32_t port, int value)
{
}

int gpio_get_value(uint32_t port)
{
	return -1;
}

/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
void dcache_flush_range(unsigned long start, unsigned long size)
{
}

void dcache_clean_range(unsigned long start, unsigned long size)
{
}

void dcache_inv_range(unsigned long start, unsigned long size)
{
}

void icache_disable(void)
{

}

void cache_flush(void)
{

}

/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
uint32_t interrupt_enable(void)
{
	return 0;
}

uint32_t interrupt_disable(void)
{
	return 0;
}

void interrupt_active( uint32_t irq )
{
}

void interrupt_deactive( uint32_t irq )
{
}

void interrupt_handler( void )
{
}


int interrupt_request(uint32_t irq, void (*irq_func )(void*), void *param)
{
	return 0;
}


void interrupt_free( uint32_t irq )
{
}


void interrupt_init( void )
{
}

