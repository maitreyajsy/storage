/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#include <types.h>
#include <sys/types.h>
#include <time.h>
#include <sys/time.h>

#define	CLOCK_RATE		10000

static uint64_t start_usec_time;

uint64_t read_us_time(void)
{
	uint64_t out;
	struct timespec tm;
	(void)clock_gettime(CLOCK_MONOTONIC, &tm );
	out = tm.tv_sec * 1000000 + tm.tv_nsec/1000;
	return out;
}

void timer_init(void)
{
	start_usec_time = read_us_time();
	/* save base time in usec unit */
	printf("[emul] %s : start_usec_time %d\n", __FUNCTION__, start_usec_time );
}

uint32_t timer_usec(void)
{
	uint64_t tm = read_us_time() - start_usec_time;
	return (uint32_t)tm;
}

uint32_t timer_msec(void)
{
	uint64_t tm = read_us_time() - start_usec_time;
	return (uint32_t)(tm/1000);
}

uint32_t timer_sec(void)
{
	uint64_t tm = read_us_time() - start_usec_time;
	return (uint32_t)(tm/1000000);
}

void mdelay(unsigned int msec)
{
	usleep(msec*1000);
}

void udelay(uint32_t usec)
{
	usleep(usec);
}

/* I'will use usec as tick */
uint32_t timer_tick(void)
{
	uint64_t tm = read_us_time() - start_usec_time;

	return (uint32_t)(tm/CLOCK_RATE);
}

uint32_t timer_ticks2usec(uint32_t ticks)
{
	return ticks * CLOCK_RATE;
}

/* in usec unit */
uint32_t timer_elapsed(uint32_t ticks)
{
	uint32_t tm = timer_tick() - ticks;
	return timer_ticks2usec(tm);
}

