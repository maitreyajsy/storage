/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#include <sys/types.h>
#include <string.h>

void malloc_init(void)
{
	/* do nothing */
}

void* _bfill(void *p, size_t n, int c)
{
	return memset(p,c,n);
}

char *_bcopy(const char *src, char *dst, int n)
{
	return memcpy(dst,src,n);
}


/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
int stricmp(const char *s1, const char *s2)
{
    char f, l;

    do
    {
        f = ((*s1 <= 'Z') && (*s1 >= 'A')) ? *s1 + 'a' - 'A' : *s1;
        l = ((*s2 <= 'Z') && (*s2 >= 'A')) ? *s2 + 'a' - 'A' : *s2;
        s1++;
        s2++;
    } while ((f) && (f == l));

    return (int) (f - l);
}

/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
int get_ctrl_c(void)
{
    if(console_check_rx())
    {
        if(getchar() == 0x03)
            return 1;
    }

    return 0;
}

void printf_timeinfo_control(int on)
{

}

void printf_control(int on)
{

}

/* get string */
char* gets(char *s)
{
    int cnt = 0;
    char c;
	char _s = s;

    while((c = getchar()) != LF/*CR*/)
    {
        if(c != BS)
        {
            cnt++;
            *s++ = c;
            printf("%c",c );
        }
        else
        {
            if(cnt > 0)
            {
                cnt--; *s-- = ' ';
                printf("\b \b");
            }

        }
    }
    *s = 0;

    return _s;
}

/* put string */
int	puts( const char* s )
{
	int	ch;
	char* p = s;
	while((ch=*p++))
	{
		 if ( ch == '\n' )	printf("\n"); //putchar('\n');
		else				putchar(ch);
	}
}

