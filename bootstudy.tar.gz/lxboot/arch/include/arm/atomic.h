#ifndef __ARCH_ARM_ATOMIC_H_
#define __ARCH_ARM_ATOMIC_H_

#define ATOMIC_READ(ptr) 		(*(volatile int32_t *)&(ptr)->a_val)

typedef struct
{
	int32_t a_val;
}atomic_t;

/********************************************
 *	val = *ptr;
 *	if(val == old){ *ptr = new;}
 *	return val;
 *********************************************/
#define atomic_compare_n_change(old,new,ptr)	\
({\
	unsigned long res, val; \
	asm volatile( \
	"1:	ldrex	%0, [%4]\n" \
	"	mov		%1,	#0x0\n" \
	"	teq		%2, %0\n" \
	"	strexeq	%1, %3, [%4]\n" \
	"	teq		%1, #0x0\n" \
	"	bne		1b\n" \
	: "=&r" (val), "=&r" (res) \
	: "r" (old), "r" (new), "r" (ptr)); \
	dmb(); \
	val; \
})


/********************************************
 * val = *ptr; *ptr = new;
 * return val;
 ********************************************/
#define atomic_swap(new,ptr) \
({ \
	unsigned long res, val; \
	asm volatile( \
	"1:	ldrex	%0, [%3]\n" \
	"	strex	%1, %2, [%3]\n" \
	"	teq		%1, #0\n" \
	"	bne		1b\n" \
	: "=&r" (val), "=&r" (res) \
	: "r" (new), "r" (ptr)); \
	val;  \
})


static inline __attribute__((always_inline)) 
	int32_t atomic_dec(atomic_t *ptr)
{
	int32_t res, val;

	asm volatile(
	"1:	ldrex 	%1, [%2]\n"
	"	sub 	%1, %1, #1\n"
	"	strex 	%0, %1, [%2]\n"
	" 	teq 	%0, #0\n"
	" 	bne 	1b"
	: "=&r" (res), "=&r" (val) : "r" (&ptr->a_val)
	: "cc", "memory");
	dmb();
	return val;
}

static inline __attribute__((always_inline)) 
	int32_t atomic_inc(atomic_t *ptr)
{
	int32_t res, val;

	asm volatile(
	"1:	ldrex 	%1, [%2]\n"
	"	add 	%1, %1, #1\n"
	"	strex 	%0, %1, [%2]\n"
	" 	teq 	%0, #0\n"
	" 	bne 	1b"
	: "=&r" (res), "=&r" (val) : "r" (&ptr->a_val)
	: "cc", "memory");
	dmb();
	return val;
}

#endif /* __ARCH_ATOMIC_H_ */
