/*************************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 **************************************************************************************************/


/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	ks.hyun@lge.com 	Release initial codes for lxboot in arch/lg1152/include folder.
|	? 	? 	2011	yw.kim@lge.com		Copy this file from arch/lg1152/include to arch/lg1154/include
|										for evaluation.
|	Feb	26	2012	yw.kim@lge.com		Add read_cp15_ttbr0(), read_cp15_ttbr1(), read_cp15_ttbcr() and
|	                                    v7_flush_tlb_range() functions to insert mmu entry dynamically.
| 	Mar	04	2012	yw.kim@lge.com		Add v7_read_nsacr(), v7_write_nsacr(), v7_read_actlr(), v7_write_actlr()
|										v7_read_scr() and v7_write_scr() macro for normal world cpu1 initialization.
|
|============================================================================================================*/

#ifndef __ARCH_ARM_CPU_H__
#define __ARCH_ARM_CPU_H__


#define PRIMARY_CPU				0x0
#define SECONDARY_CPU			0x1

#ifndef D_CACHE_LINE_SIZE
#define D_CACHE_LINE_SIZE		32
#endif

/* struct regs 구조체 */
#define SPSR_OFFSET			(4*3)
#define REG_SP_OFFSET		(4*0)
#define REG_LR_OFFSET		(4*1)
#define REG_PC_OFFSET		(4*2)
#define REG_R0_OFFSET		(4*4)
#define REG_R1_OFFSET		(4*5)
#define REG_R2_OFFSET		(4*6)
#define REG_R3_OFFSET		(4*7)
#define REG_R4_OFFSET		(4*8)
#define REG_R5_OFFSET		(4*9)
#define REG_R6_OFFSET		(4*10)
#define REG_R7_OFFSET		(4*11)
#define REG_R8_OFFSET		(4*12)
#define REG_R9_OFFSET		(4*13)
#define REG_R10_OFFSET		(4*14)
#define REG_R11_OFFSET		(4*15)
#define REG_R12_OFFSET		(4*16)

#ifdef __ASSEMBLY__
.macro get_cpuid, reg
	mrc		p15, 0, \reg, c0, c0, 5
	and		\reg, \reg, #0xf
.endm
#else

typedef struct regs
{
	u32	sp, lr, pc;
	u32	spsr;
	u32	r[13];
} regs_t;


static inline __attribute__((always_inline)) unsigned long read_cp15_sctlr(void)
{
	unsigned long value;
	asm volatile("mrc	p15, 0, %0, c1, c0, 0\n"
				: "=r" (value):: "memory");
	return value;
}

static inline __attribute__((always_inline)) void write_cp15_sctlr(unsigned long v)
{
	asm volatile("mcr	p15, 0, %0, c1, c0, 0\n"
				:: "r" (v): "memory");
}

static inline __attribute__((always_inline)) void write_cp15_vbar(unsigned long v)
{
	asm volatile("mcr	p15, 0, %0, c12, c0, 0\n"
				:: "r" (v): "memory");
}

static inline unsigned int get_cpu_id(void)
{
	unsigned int id;
	asm volatile("mrc p15, 0, %0, c0, c0, 5" : "=r" (id));
	id &= 0x0F;
	return id;
}

static inline void write_thread_id(unsigned int id)
{
	asm volatile("mcr p15, 0, %0, c13, c0, 4" :: "r" (id));
}

static inline unsigned int get_thread_id(void)
{
	unsigned int id;
	asm volatile("mrc p15, 0, %0, c13, c0, 4" : "=r" (id));
	return id;
}

static inline unsigned long read_cp15_ttbr0(void)
{
	unsigned long value;
	asm volatile("mrc	p15, 0, %0, c2, c0, 0\n"
				: "=r" (value):: "memory");
	return value;
}

static inline unsigned long read_cp15_ttbr1(void)
{
	unsigned long value;
	asm volatile("mrc	p15, 0, %0, c2, c0, 1\n"
				: "=r" (value):: "memory");
	return value;
}

static inline unsigned long read_cp15_ttbcr(void)
{
	unsigned long value;
	asm volatile("mrc	p15, 0, %0, c2, c0, 2\n"
				: "=r" (value):: "memory");
	return value;
}

static inline u32 arch_swap32(u32 x)
{
	asm volatile("rev %0, %1" : "=r" (x) : "r" (x));
	return x;
}

/**
* NSACR(Non Secure Access Control Register)
* set the non-secure access permission for coprocessors. yw.kim@lge.com
*/
#define v7_read_nsacr()						\
	({										\
		unsigned int __val;					\
		asm("mrc	p15, 0, %0, c1, c1, 2" 	\
		    : "=r" (__val)	/*output*/		\
		    :			   	/*input*/		\
		    : "cc");		/*clobber list*/\
		__val;								\
	})

#define v7_write_nsacr(val)					\
	({										\
		__asm__("mcr p15, 0, %0, c1, c1, 2"	\
			: 								\
			: "r" (val)						\
			: "cc");						\
	})



/**
* ACTLR(Auxiliary ConTroL Register)
* cannot write auxctrl except for SMP bit if in normal world. yw.kim@lge.com
*/
#define v7_read_actlr()						\
	({										\
		unsigned int __val;					\
		asm("mrc	p15, 0, %0, c1, c0, 1" 	\
		    : "=r" (__val)					\
		    :								\
		    : "cc");						\
		__val;								\
	})

#define v7_write_actlr(val)					\
	({										\
		__asm__("mcr p15, 0, %0, c1, c0, 1"	\
			:								\
			: "r" (val) 					\
			: "cc");						\
	})


/**
* SCR(Security Configuration Register)
* from now on, secondary cpu  is in normal world. yw.kim@lge.com
*/
#define v7_read_scr()						\
	({										\
		unsigned int __val; 				\
		asm("mrc	p15, 0, %0, c1, c1, 0"	\
			: "=r" (__val)					\
			:								\
			: "cc");						\
			__val;							\
	})

#define v7_write_scr(val)					\
	({										\
		__asm__("mcr p15, 0, %0, c1, c1, 0"	\
			:								\
			: "r" (val) 					\
			: "cc");						\
	})


#define isb()	asm("isb")
#define dsb()	asm("dsb")
#define dmb()	asm("dmb")

#define wfi()	asm volatile("wfi");

#endif

#endif /* __ARCH_ARM_CPU_H__ */
