#ifndef __ARCH_ARM_REGISTERS_H__
#define __ARCH_ARM_REGISTERS_H__

/*
 * RAZ	- Read-As-Zero
 * SBZ	- Should Be Zero
 * SBZP	- SBZ or Preserved
 * UNP	- Unpredictable Value
 * SBO	- Should Be One
 * SBOP	- SBO or Predictable
 * WI	- Writes Ignored
 * UNK	- Unknown
 */

/* System Control Register : c1, c0, 0 */
#define CP15_SCTLR_M_ENABLE		(0x01 << 0)		/* MMU E/D(enable/disable) */
#define CP15_SCTLR_A_ENABLE		(0x01 << 1)		/* Strict data address alignment fault E/D */
#define CP15_SCTLR_C_ENABLE		(0x01 << 2)		/* Level one data cache E/D */
/* [6:3]	RAO/SBOP	*/
/* [9:7]	RAZ/SBZP	*/
#define CP15_SCTLR_SW_ENABLE	(0x01 << 10)	/* SWP/SWPB Enable bit */
#define CP15_SCTLR_Z_ENABLE		(0x01 << 11)	/* Program flow prediction */
#define CP15_SCTLR_I_ENABLE		(0x01 << 12)	/* Level one instruction cache E/D */
#define CP15_SCTLR_VECTOR		(0x01 << 13)	/* Location of exception vectors */
#define CP15_SCTLR_RR			(0x01 << 14)	/* Replacement strategy for caches, BTAC, and micro TLBs */
/* [15]		RAZ/SBZP	*/
/* [16]		RAO/SBOP	*/
#define CP15_SCTLR_HA_ENABLE	(0x01 << 17)	/* RAZ/WI, Hardware Access Flag Enable bit */
/* [18]		RAO/SBOP	*/
/* [20:19]	RAZ/SBZP	*/
/* [21]		RAZ/WI		*/
/* [23:22]	RAO/SBOP	*/
/* [24]		RAZ/WI		*/
#define CP15_SCTLR_EE_SET		(0x01 << 25)	/* Exception Endianness. 0:Little, 1:Big */
/* [26]		SBZ/RAZ		*/
#define CP15_SCTLR_NMFI			(0x01 << 27)	/* NMFI, nonmaskable. read-only */
#define CP15_SCTLR_TRE_ENABLE	(0x01 << 28)	/* TEX Remap Enable */
#define CP15_SCTLR_AFE_ENABLE	(0x01 << 29)	/* Access Flag Enable */
#define CP15_SCTLR_TE_ENABLE	(0x01 << 30)	/* Thumb Exception enable */
/* [31]		UNK/SBZP	*/



/* Auxiliary Control Register : c1, c0, 1 */
#define CP15_ACTLR_FW_ENABLE	(0x01 << 0)		/* Cache and TLB maintenance broadcast */
#define CP15_ACTLR_L2_PREFETCH	(0x01 << 1)		/* Prefetch hint enable */
#define CP15_ACTLR_L1_PREFECTCH	(0x01 << 2)		/* Dside prefetch */
#define CP15_ACTLR_WFL_OF_ZEROS	(0x01 << 3)		/* Enable write full line of zeros mode */
/* [5:4] RAZ/WI 		*/
#define CP15_ACTLR_SMP			(0x01 << 6)		/* Signals if the Cortex-A9 processor is taking part in coherency or not */
#define CP15_ACTLR_EXCL			(0x01 << 7)		/* Exclusive cache bit */
#define CP15_ACTLR_ALLOC_ONEWAY	(0x01 << 8)		/* Enable allocation in one cache way only */
#define CP15_ACTLR_PARITY_ON	(0x01 << 9)		/* Support for parity checking, if implemented */
/* [31:10] UNP/SBZP		*/

/* Coprocessor Access Contorl Register c1, c0, 1 , NEON, VFP*/
#define CP15_CPACR_CP10_PREAD_MODE  (0x03 << 20)    //OR in User and Privileged access for CP10
#define CP15_CPACR_CP11_PREAD_MODE  (0x03 << 22)    //OR in User and Privileged access for CP11
#define CP15_CPACR_ASEDIS_D32DIS    (0x03 << 30)    //Clear ASEDIS/D32DIS if set
#define FPEXC_NEON_VFP_ENABLE       (0x01 << 30)    //Enable VFP and SIMD extensions

/* Non-secure Access Control Register : c1, c1, 2 */
/* [9:0] UNK/SBZP		*/
#define CP15_NSACR_CP10			(0x01 << 10)	/* Determines permission to access coprocessor 10 in the NS */
#define CP15_NSACR_CP11			(0x01 << 11)	/* Determines permission to access coprocessor 11 in the NS */
/* [13:12] UNK/SBZP		*/
#define CP15_NSACR_NSD32DIS		(0x01 << 14)	/* Disable the NS use of D16-D31 of the VFP register file */
#define CP15_NSACR_NSASEDIS		(0x01 << 15)	/* Disable NS Advanced SIMD Extension functionality */
#define CP15_NSACR_PLE			(0x01 << 16)	/* Controls NS accesses to the Preload Engine resources */
#define CP15_NSACR_TL			(0x01 << 17)	/* Determines if lockable TLB entries can be allocated in NS */
#define CP15_NSACR_NS_SMP		(0x01 << 18)	/* Determines if the SMP bit of the ACR is writable in NS */
/* [31:19] UNK/SBZP		*/

/*
* Security Configuration Register
**/
#define CP15_SCR_NS				(0x1<<0)
#define CP15_SCR_IRQ			(0x1<<1)
#define CP15_SCR_FIQ			(0x1<<2)
#define CP15_SCR_EA				(0x1<<3)
#define CP15_SCR_FW				(0x1<<4)
#define CP15_SCR_AW				(0x1<<5)
#define CP15_SCR_nET			(0x1<<6)



/* Current Program Status Register(CPSR) */
#define CPSR_N_FLAG				(0x01 << 31)
#define CPSR_Z_FLAG				(0x01 << 30)
#define CPSR_C_FLAG				(0x01 << 29)
#define CPSR_V_FLAG				(0x01 << 28)
#define CPSR_Q_FLAG				(0x01 << 27)
#define CPSR_IT_1_0				(0x03 << 25)
#define CPSR_JAZELLE			(0x01 << 24)
/* [23:20] RAZ/SBZP		*/
#define CPSR_GE					(0x01 << 16)
#define CPSR_IT_7_2				(0x3F << 10)
#define CPSR_E_STATE			(0x01 << 9)		/* Endianness execution state bit. 0:Little, 1:Big */
#define CPSR_A_DISABLE			(0x01 << 8)		/* Asynchronous abort disable bit */
#define CPSR_I_DISABLE			(0x01 << 7)		/* Interrupt disable bit */
#define CPSR_F_DISABLE			(0x01 << 6)		/* Fast interrupt diable bit */
#define CPSR_T_STATE			(0x01 << 5)		/* Thumb execution state bit */
#define CPSR_MODE				(0x1F << 0)		/* The current mode of the processor */

#define CPSR_MODE_USER			0x10
#define CPSR_MODE_FIQ			0x11
#define CPSR_MODE_IRQ			0x12
#define CPSR_MODE_SVC			0x13
#define CPSR_MODE_ABT			0x17
#define CPSR_MODE_UND			0x1B
#define CPSR_MODE_SYS			0x1F







#define SCR_ENABLE						(0x24)



#endif /* __ARCH_CPU_REGISTERS_H__ */
