#ifndef __ARCH_ARM_TIMERS_H__
#define __ARCH_ARM_TIMERS_H__

#define TIMER_MAX_LOAD_VALUE	0xFFFFFFFF

#define TIMER_CTRL_ONESHOT	(1 << 0)
#define TIMER_CTRL_32BIT	(1 << 1)
#define TIMER_CTRL_DIV1		(0 << 2)
#define TIMER_CTRL_DIV16	(1 << 2)
#define TIMER_CTRL_DIV256	(2 << 2)
#define TIMER_CTRL_IE		(1 << 5)	/* Interrupt Enable (versatile only) */
#define TIMER_CTRL_FREERUN	(0 << 6)
#define TIMER_CTRL_PERIODIC	(1 << 6)
#define TIMER_CTRL_ENABLE	(1 << 7)
#define TIMER_CTRL_DISABLE	(0 << 7)


typedef struct timer
{
    volatile u32		load;		/* Load value for Timer */
    volatile u32 const	value;		/* The current value for Timer */
    volatile u32 		control;	/* Timer control register */
    volatile u32		intclr;		/* Timer interrupt clear */
    volatile u32 const	ris;		/* Timer raw interrupt status */
	volatile u32 const	mis;		/* Timer masked interrupt status */
    volatile u32		bgload;		/* Background load value for Timer */
	u32	const			reserved;
} timer_t;

typedef struct timer64
{
    volatile u32		load_lo;	/* 0x00 : Load value(LOW) for Timer */
    volatile u32 const	value_lo;	/* 0x04 : The current value(LOW) for Timer */
    volatile u32 		control;	/* 0x08 : Timer control register */
    volatile u32		intclr;		/* 0x0C : Timer interrupt clear */
    volatile u32 const	ris;		/* 0x10 : Timer raw interrupt status */
	volatile u32 const	mis;		/* 0x14 : Timer masked interrupt status */
    volatile u32		bgload_lo;	/* 0x18 : Background load value(LOW) for Timer */
	u32	const			reserved1;
    volatile u32		load_hi;	/* 0x20 : Load value(HIGH) for Timer */
    volatile u32 const	value_hi;	/* 0x24 : The current value(HIGH) for Timer */
    volatile u32		snapshot;	/* 0x28 : The current snapshot value(HIGH) for Timer */
	u32	const			reserved2[4];
    volatile u32		bgload_hi;	/* 0x38 : Background load value(HIGH) for Timer */
	u32	const			reserved3;
} timer64_t;

typedef struct watchdog
{
	volatile u32		load;		/* 0x0000 Watchdog load register */
	volatile u32 const	value;		/* 0x0004 The current value for the watchdog counter */
	volatile u32		control;	/* 0x0008 Watchdog control register */
	volatile u32		intclr;		/* 0x000C Clears the watchdog interrupt */
	volatile u32 const	ris;		/* 0x0010 Watchdog raw interrupt status */
	volatile u32 const	mis;		/* 0x0014 Watchdog masked interrupt status */
	u32 const	reserved1[0x2F9];
	volatile u32		lock;		/* 0x0C00 Watchdog lockk register */
	u32 const	reserved2[0xBE];
	volatile u32		itcr;		/* 0x0F00 Integration test control register */
	volatile u32		itop;		/* 0x0F04 Integration test output set register */
	u32 const	reserved3[0x35];
	volatile u32 const	periphid[4];/* 0x0FE0 Peripheral ID register */
	volatile u32 const	cellid[4];	/* 0x0FF0 PrimeCell ID register */
}watchdog_t;


//arm ca9 local timer(private timer)
#ifdef ARM_CORTEX_A9
#define LOCAL_TIMER_CTRL_ENABLE			(1 << 0)
#define LOCAL_TIMER_CTRL_DISABLE		(0 << 0)
#define LOCAL_TIMER_CTRL_AUTO_RELOAD	(1 << 1)
#define LOCAL_TIMER_CTRL_SINGLE_SHOT	(0 << 1)
#define LOCAL_TIMER_CTRL_IRQ_ENABLE		(1 << 2)

typedef struct local_timer
{
    volatile u32		load;		/* Load Register */
    volatile u32		counter;	/* Counter Register */
    volatile u32 		control;	/* Control Register */
    volatile u32		intsts;		/* Interrupt Status Register */
} local_timer_t;

typedef struct local_watchdog
{
	volatile u32		load;		/* Load Register */
	volatile u32		counter;	/* Counter Register */
	volatile u32 		control;	/* Control Register */
	volatile u32		intsts;		/* Interrupt Status Register */
	volatile u32		rststs;		/* Reset Status Register */
	volatile u32		disable;	/* Disable Register */
} local_watchdog_t;
#endif

//arm ca15 local timer(generic timer)
#ifdef ARM_CORTEX_A15
struct cntcr_bit
{
	unsigned int en 	:1;		/* 0: system counter disabled. 1 : enabled */
	unsigned int hdbg 	:1;
	unsigned int 		:30;
	/* TODO: reference lg1156 datasheet */
	/* FCREQ [m:8] */
	/* Reserved [31:m+1] */
};
typedef union
{
	u32 all;
	struct cntcr_bit bit;
}sc_cntcr_t;

typedef struct system_counter
{
	volatile sc_cntcr_t cntcr;
}system_counter_t;

#if 0
struct cntkctl_bit
{
	unsigned int pl0pcten 	:1;
	unsigned int pl0vcten 	:1;
	unsigned int evnten 	:1;
	unsigned int evntdir 	:1;
	unsigned int evnti 		:4;
	unsigned int pl0vten 	:1;
	unsigned int pl0pten 	:1;
	unsigned int  			:22;
};
typedef union
{
	u32 all;
	struct cntkctl_bit bit;
}gt_cntkctl_t;

struct cntp_ctl_bit
{
	unsigned int enable 	:1; /* 0: timer disabled. 	1: timer enabled */
	unsigned int imask 		:1; /* 0: irq is masked. 	1: irq is not masked */
	unsigned int istatus 	:1; /* 0: irq asserted.		1: irq not asserted. */
	unsigned int 			:29;
};
typedef union
{
	u32 all;
	struct cntp_ctl_bit bit;
}gt_cntp_ctl_t;

typedef struct generic_timer
{
	u32				cntfrq; 	/* Counter Frequency register */
	u64				cntpct; 	/* Physical Count register */
	gt_cntkctl_t	cntkctl; 	/* Timer PL1 Control register */
	gt_cntp_ctl_t	cntp_ctl;	/* PL1 Physical Timer Control register */
	u32				cntp_tval;	/* PL1 PhysicalTimerValue register */
	u64				cntp_cval;	/* PL1 Physical Timer CompareValue register */
}generic_timer_t;
#endif

static inline void write_timer_cntfrq(u32 frq)
{
	//MCR p15, 0, <Rt>, c14, c0, 0 ; Write Rt to CNTFRQ
	asm volatile("mcr p15, 0, %0, c14, c0, 0" :: "r" (frq));
}
static inline u32 read_timer_cntfrq(void)
{
	u32 frq;
	//MRC p15, 0, <Rt>, c14, c0, 0 ; Read CNTFRQ into Rt
	asm volatile("mrc p15, 0, %0, c14, c0, 0" : "=r" (frq));
	return frq;
}
static inline u64 read_timer_cntpct(void)
{
	u32 cnt0;
	u32 cnt1;
	//MRRC p15, 0, <Rt>, <Rt2>, c14 ; Read 64-bit CNTPCT into Rt (low word) and Rt2 (high word)
	asm volatile("mrrc p15, 0, %0, %1, c14" : "=r" (cnt0), "=r" (cnt1));
	return ((u64)cnt1 << 32) | (u64)cnt0;
}
static inline void write_timer_cntkctl(u32 ctl)
{
	//MCR p15, 0, <Rt>, c14, c1, 0 ; Write Rt to CNTKCTL
	asm volatile("mcr p15, 0, %0, c14, c1, 0" :: "r" (ctl));
}
static inline u32 read_timer_cntkctl(void)
{
	u32 ctl;
	//MRC p15, 0, <Rt>, c14, c1, 0 ; Read CNTKCTL to Rt
	asm volatile("mrc p15, 0, %0, c14, c1, 0" : "=r" (ctl));
	return ctl;
}
static inline void write_timer_cntp_tval(u32 tval)
{
	//MCR p15, 0, <Rt>, c14, c2, 0 ; Write Rt to CNTP_TVAL
	asm volatile("mcr p15, 0, %0, c14, c2, 0" :: "r" (tval));
}
static inline u32 read_timer_cntp_tval(void)
{
	u32 tval;
	//MRC p15, 0, <Rt>, c14, c2, 0 ; Read CNTP_TVAL into Rt
	asm volatile("mrc p15, 0, %0, c14, c2, 0" : "=r" (tval));
	return tval;
}
static inline void write_timer_cntp_ctl(u32 ctl)
{
	//MCR p15, 0, <Rt>, c14, c2, 1 ; Write Rt to CNTP_CTL
	asm volatile("mcr p15, 0, %0, c14, c2, 1" :: "r" (ctl));
}
static inline u32 read_timer_cntp_ctl(void)
{
	u32 ctl;
	//MRC p15, 0, <Rt>, c14, c2, 1 ; Read CNTP_CTL into Rt
	asm volatile("mrc p15, 0, %0, c14, c2, 1" : "=r" (ctl));
	return ctl;
}
static inline void write_timer_cntp_cval(u64 cval)
{
	u32 cval0 = (u32)(cval & 0xffffffff);
	u32 cval1 = (u32)(cval >> 32);
	//MCRR p15, 2, <Rt>, <Rt2>, c14 ; Write Rt (low word) and Rt2 (high word) to 64-bit CNTP_CVAL
	asm volatile("mcrr p15, 2, %0, %1, c14" :: "r" (cval0), "r" (cval1));
}
static inline u64 read_timer_cntp_cval(void)
{
	u32 cval0;
	u32 cval1;
	//MRRC p15, 2, <Rt>, <Rt2>, c14 ; Read 64-bit CNTP_CVAL into Rt (low word) and Rt2 (high word)
	asm volatile("mrrc p15, 2, %0, %1, c14" : "=r" (cval0), "=r" (cval1));
	return ((u64)cval1 << 32) | (u64)cval0;
}
#endif//ARM_CORTEX_A15

#endif /* __ARCH_TIMERS_H__ */
