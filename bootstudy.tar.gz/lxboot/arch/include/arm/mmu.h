/*
 * $Copyright (c) 2008-2009, ARM Ltd. All rights reserved.

 * -------------------------------------------------------

 * File:     mmu.h

 * $
 *
 * Headers for mmu.s
 *
 */

/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	ks.hyun@lge.com 	Release initial codes for lxboot in arch/lg1152 folder.
|	Feb 26	2012	yw.kim@lge.com		Loading address for tzfw is inserted into mmu table dynamically.
|
|============================================================================================================*/


#ifndef __ARCH_ARM_MMU_H__
#define __ARCH_ARM_MMU_H__


/* Definitions for section descriptors */
#define S_NGLOBAL               (1 << 17)
#define S_SHARED                (1 << 16)
#define S_APX                   (1 << 15)
#define S_TEX1                  (1 << 12)
#define S_AP0                   (1 << 10)
#define S_AP1                   (1 << 11)
#define S_PARITY                (1 << 9)
#define S_XN                    (1 << 4)
#define S_CACHE                 (1 << 3)
#define S_BUFFER                (1 << 2)

#define IS_A_SECTION            (1 << 1)

/* Outer and Inner Write-Back, Write Allocate */
#define S_MEMORY                (S_TEX1 | S_CACHE | S_BUFFER | S_AP0 | S_AP1 | IS_A_SECTION)
#define S_SHARED_MEMORY         (S_MEMORY | S_SHARED)
#define S_SO_MEMORY             (S_AP0 | S_AP1 | IS_A_SECTION)
#define S_SHARED_SO_MEMORY      (S_SO_MEMORY | S_SHARED)
#define S_DEVICE                (S_BUFFER | S_AP0 | S_AP1 | IS_A_SECTION)
//#define S_DEVICE                (S_AP0 | S_AP1 | IS_A_SECTION)
#define S_SHARED_DEVICE         (S_DEVICE | S_SHARED)
#define S_NO_ACCESS             (IS_A_SECTION)


/* Definitions for page descriptors */

#define P_NGLOBAL               (1 << 11)
#define P_SHARED                (1 << 10)
#define P_APX                   (1 << 9)
#define P_TEX1                  (1 << 6)
#define P_AP1                   (1 << 5)
#define P_AP0                   (1 << 4)
#define P_CACHE                 (1 << 3)
#define P_BUFFER                (1 << 2)
#define IS_A_PAGE               (1 << 1)
#define P_XN                    (1 << 0)

#define IS_A_PAGETABLE          (1 << 0)

#define P_MEMORY                (P_TEX1 | P_CACHE | P_BUFFER | IS_A_PAGE | P_AP0 | P_AP1)
#define P_SHARED_SO_MEMORY      (P_SHARED | P_AP0 | P_AP1 | IS_A_PAGE)
#define P_SHARED_MEMORY         (P_MEMORY | P_SHARED)


#define MMU_SECTION_ADDR_SHIFT	20
#define MMU_SECTION_ADDR_MASK	(0xFFF << MMU_SECTION_ADDR_SHIFT)
#define MMU_SECTION_SIZE		(0x1 << MMU_SECTION_ADDR_SHIFT)

#define MMU_ENTRY_SIZE			4

#endif /* __ARCH_ARM_MMU_H__ */
