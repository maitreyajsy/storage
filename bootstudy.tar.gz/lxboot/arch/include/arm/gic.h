#ifndef __ARCH_ARM_GIC_H__
#define __ARCH_ARM_GIC_H__


/**
 * \brief ID of 'spurious' interrupt
 *
 * This ID is returned when acknowledging an interrupt, if no interrupt is pending.
 * This is also returned when acknowledging an interrupt that has become masked due
 * to priority change but was already pending (sent to the CPU).
 */
#define SPURIOUS_INTERRUPT 1023

/*
 * Number of interrupts implemented in the GIC
 *
 * The number of interrupts that the Distributor can handle is IMPLEMENTATION DEFINED.
 * It can be up to 1020, with up to 4 CPUs being supported (expansion space reserved for
 * up to 8 CPUs)
 */
#define NO_OF_INTERRUPTS_IMPLEMENTED NR_IRQS

/*
 * Description:
 * Number of 32 bit registers necessary in order to allocate enough space
 * for 1020 irqs (1 bit each) for the following:
 * - Enable Set / Enable Clear
 * - Pending Set / Pending Clear
 * - Active Bit
 */
#define GIC_NUM_REGISTERS 32

/*
 * Description:
 * Number of 4 byte registers necessary in order to allocate enough space
 * for 1020 irqs (8 bit each) for the priority field
 */
#define GIC_PRIORITY_REGISTERS 256

/*
 * Description:
 * Number of 4 byte registers necessary in order to allocate enough space
 * for 1020 irqs (8 bit each) for the CPU targets field
 */
#define GIC_TARGET_REGISTERS 256

/*
 * Description:
 * Number of 4 byte registers necessary in order to allocate enough space
 * for 1020 irqs (8 bit each) for the configuration field
 */
#define GIC_CONFIG_REGISTERS 64

/*
 * Description:
 * Number of Peripheral Identification Registers
 */
#define GIC_PERIPHERAL_ID 4

/*
 * Description:
 * Number of PrimeCell Hardcoded Peripherals Register
 * Four words, each of which contains a hardcoded byte reset value
 */
#define GIC_PRIMECELL_ID 4

/*
 * Description:
 * Reserved address space of the GIC controller (size expressed in 32 bit words)
 */
#define GIC_RESERVED_BEFORE_ENABLE_SET			30
#define GIC_RESERVED_BEFORE_PRIORITY			32
#define GIC_RESERVED_BEFORE_IDENTIFICATION		55
#define GIC_IMPLEMENTATION_DEFINED_DISTR		64
#define GIC_RESERVED_BEFORE_SOFT_INT			128


/*
 * Description:
 * Mask for interrupt ID (used with acknowledge, highest pending, software and end of interrupt registers
 */
#define INTERRUPT_MASK     0x000003FF


#define IAR_CPUID_MASK     0x00001C00
#define IAR_CPUID_SHIFT    10

/*
 * Description:
 * Mask for Inter Processor Interrupt ID
 */
#define IPI_MASK           0x0000000F

/*
 * Description:
 * Shift required to locate the CPU target list field in the Software Interrupt register
 */
#define IPI_TARGET_SHIFT   16

/*
 * Description:
 * Shift required to locate the target list filter field in the Software Interrupt register
 */
#define IPI_TARGET_FILTER_SHIFT 24

/**
 * Target list filter for Software Interrupt register
 */
#define USE_TARGET_LIST   0x0 /**< Interrupt sent to the CPUs listed in CPU Target List */
#define ALL_BUT_SELF      0x1 /**< CPU Target list ignored, interrupt is sent to all but requesting CPU */
#define SELF              0x2 /**< CPU Target list ignored, interrupt is sent to requesting CPU only */



#if	(USE_TZ_BOOT)
#define ICDISR_SGI_PPI_NONSECURE	(0xFFFFFFFF)
#define ICCICR_EnableNS				(0x1<<1)
#define ICDISER_SGI_SET_ENABLE		(0xFFFF)
#endif


#ifndef __ASSEMBLY__

/*
 * Interrupt Distributor access structure
 *
 */
typedef struct
{
	volatile u32		control;	/* 0x000: Interrupt Distributor Control Register (R/W) */

	volatile u32 const	type;		/* 0x004: Interrupt Controller Type Register (RO) */

	uint32_t const		reserved1[GIC_RESERVED_BEFORE_ENABLE_SET];	/* 0x008: Reserved */

	volatile u32		security[GIC_NUM_REGISTERS];				/* 0x80: Interrupt Security Registers (R/W) */

	volatile u32		enable_set[GIC_NUM_REGISTERS];				/* 0x100: Interrupt Set Enable Registers (R/W) */

	volatile u32		enable_clear[GIC_NUM_REGISTERS];			/* 0x180: Interrupt Clear Enable Registers (R/W) */

	volatile u32		pending_set[GIC_NUM_REGISTERS];				/* 0x200: Interrupt Set Pending Registers (R/W) */

	volatile u32		pending_clear[GIC_NUM_REGISTERS];			/* 0x280: Interrupt Clear Pending Registers (R/W) */

	volatile u32 const	active[GIC_NUM_REGISTERS];					/* 0x300: Interrupt Active Bit Registers (R/W) */

	uint32_t const		reserved2[GIC_RESERVED_BEFORE_PRIORITY];	/* 0x380: Reserved */

	volatile u32 		priority[GIC_PRIORITY_REGISTERS];			/* 0x400: Interrupt Priority Registers (R/W) */

	volatile u32 		target[GIC_TARGET_REGISTERS];				/* 0x800: Interrupt CPU Target Registers (R/W) */

	volatile u32 		configuration[GIC_CONFIG_REGISTERS];		/* 0xC00: Interrupt Configuration Registers (R/W) */

	uint32_t const		reserved3[GIC_RESERVED_BEFORE_SOFT_INT];	/* 0xD00: Reserved */

	volatile u32 		software_interrupt;							/* 0xF00: Software Interrupt Register (R/W) */

	uint32_t const		reserved4[GIC_RESERVED_BEFORE_IDENTIFICATION];	/* 0xF04: Reserved */

	volatile u32 const	peripheral_id[GIC_PERIPHERAL_ID];			/* 0xFE0: Peripheral Identification Registers (RO) */

	volatile u32 const	primecell_id[GIC_PRIMECELL_ID];				/* 0xFF0: PrimeCell Identification Registers (RO) */

} interrupt_distributor_t;



/*
 * CPU Interrupt Interface access structure
 *
 * These registers are aliased for each CPU
 */
typedef struct
{
	volatile u32		control; /* 0x00: Control Register (R/W) */

	volatile u32		priority_mask; /* 0x04: Priority Mask Register (R/W) */

	volatile u32		binary_point; /* 0x08: Binary Point Register (R/W) */

	volatile u32 const	interrupt_ack; /* 0x0C: Interrupt Acknowledge Register (R) */

	volatile u32		end_of_interrupt; /* 0x10: End of Interrupt Register (W) */

	volatile u32 const	running_priority; /* 0x14: Running Priority Register (R) */

	volatile u32 const	highest_pending; /* 0x18: Highest Pending Interrupt Register (R) */

} cpu_interrupt_interface_t;
#endif

#endif	/* __ARCH_GIC_H__ */
