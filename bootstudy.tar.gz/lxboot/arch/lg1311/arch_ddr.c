/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <string.h>
#include <timer.h>
#include <arch/ddr.h>


#if defined(CONFIG_BOOT_SINGLE) || defined(FIRST_BOOT)

#if 1
#define debug(fmt, args...)		do{}while(0)
#else
#define debug(fmt, args...)		early_printf(fmt, ##args)
#endif


/* Tuning DRAM and BUS B/W for M14A0 */
static reg_param_t ltop_confs_a0[] =
{
	{0xc00000c4, 0x1000e480},
	{0xc00000e4, 0x0000e480},
	{0xc0000104, 0x6000e480},
	{0xc0000124, 0x4000e480},
	{0xc0000144, 0x3000e480},
	{0xc0000164, 0x2000e480},
	{0xc0000184, 0x7000e480},
	{0xc00001a4, 0x5000e480},
	{0xc0000060, 0x0015e402},
	{0xc0000064, 0x0015e401},
	{0xc000d008, 0x0000000c},
	{0xc000d088, 0x0000000c},
	{0xc000d188, 0x00000000},
	{0xc000d208, 0x00000000},
	{0xc000d288, 0x00000000},
	{0xc000e1f0, 0x0000000a},
	{0xc000e2f0, 0x00000000},
	{0xc000e3f0, 0x00000000},
	{0xc000e4f0, 0x00000000},
	{0xc000e5f0, 0x00000000},
	{0xc000e6f0, 0x00000000},
	{0xc000e7f0, 0x0000000e},
	{0xc000e8f0, 0x00000004},
	{0xc000e9f0, 0x0000000f},
	{0xc000eef0, 0x0000000f},
	{0xc000eff0, 0x0000000a},
	{0xc00110f0, 0x00000004},
	{0xc000d010, 0x00000200},
	{0xc000d014, 0x00000000},
	{0xc000d090, 0x00000200},
	{0xc000d094, 0x00000000},
	{0xc000d190, 0x00000fff},
	{0xc000d194, 0x00000000},
	{0xc000d210, 0x00000fff},
	{0xc000d214, 0x00000000},
	{0xc000d290, 0x00000fff},
	{0xc000d294, 0x00000000},
	{0xc000e1f8, 0x00000fff},
	{0xc000e1fc, 0x00000fff},
	{0xc000e2f8, 0x00000fff},
	{0xc000e2fc, 0x00000000},
	{0xc000e3f8, 0x00000fff},
	{0xc000e3fc, 0x00000000},
	{0xc000e4f8, 0x00000fff},
	{0xc000e4fc, 0x00000000},
	{0xc000e5f8, 0x00000fff},
	{0xc000e5fc, 0x00000000},
	{0xc000e6f8, 0x00000fff},
	{0xc000e6fc, 0x00000000},
	{0xc000e7f8, 0x00000fff},
	{0xc000e7fc, 0x00000fff},
	{0xc000e8f8, 0x00000fff},
	{0xc000e8fc, 0x00000fff},
	{0xc000e9f8, 0x00000fff},
	{0xc000e9fc, 0x00000fff},
	{0xc000eef8, 0x00000fff},
	{0xc000eefc, 0x00000fff},
	{0xc000eff8, 0x00000fff},
	{0xc000effc, 0x00000fff},
	{0xc00110f8, 0x00000fff},
	{0xc00110fc, 0x00000000},
	{0xc000e180, 0x01007f00},
	{0xc000e184, 0x0100ff80},
	{0xc000e280, 0x02007f00},
	{0xc000e284, 0x0200ff80},
	{0xc000e380, 0x02007f00},
	{0xc000e384, 0x0200ff80},
	{0xc000e480, 0x02007f00},
	{0xc000e484, 0x0200ff80},
	{0xc000e580, 0x02007f00},
	{0xc000e584, 0x0200ff80},
	{0xc000e680, 0x01007f00},
	{0xc000e684, 0x0100ff80},
	{0xc000e780, 0x03007f00},
	{0xc000e784, 0x0300ff80},
	{0xc000e880, 0x01007f00},
	{0xc000e884, 0x0100ff80},
	{0xc000e980, 0x02007f00},
	{0xc000e984, 0x0200ff80},
	{0xc000ee80, 0x01007f00},
	{0xc000ee84, 0x0100ff80},
	{0xc000ef80, 0x01007f00},
	{0xc000ef84, 0x0100ff80},
	{0xc0011080, 0x03007f00},
	{0xc0011084, 0x0300ff80},
};

static reg_param_t gtop_confs_a0[] =
{
	{0xc00010c4, 0x1000e481},
	{0xc00010e4, 0x0000e481},
	{0xc0001104, 0x7000e481},
	{0xc0001124, 0x6000e481},
	{0xc0001144, 0x3000e481},
	{0xc0001164, 0x2000e481},
	{0xc0001184, 0x5000e481},
	{0xc00011a4, 0x4000e481},
	{0xc0001060, 0x0015e402},
	{0xc0001064, 0x0017e401},
	{0xc0010af0, 0x0000000e},
	{0xc0010bf0, 0x0000000f},
	{0xc0010cf0, 0x0000000e},
	{0xc0010df0, 0x0000000f},
	{0xc00111f0, 0x00000000},
	{0xc00112f0, 0x0000000c},
	{0xc00113f0, 0x00000000},
	{0xc00114f0, 0x0000000f},
	{0xc00115f0, 0x0000000a},
	{0xc00116f0, 0x00000000},
	{0xc00117f0, 0x00000005},
	{0xc0011af0, 0x0000000a},
	{0xc0010af8, 0x00000fff},
	{0xc0010afc, 0x00000fff},
	{0xc0010bf8, 0x00000fff},
	{0xc0010bfc, 0x00000fff},
	{0xc0010cf8, 0x00000fff},
	{0xc0010cfc, 0x00000fff},
	{0xc0010df8, 0x00000fff},
	{0xc0010dfc, 0x00000fff},
	{0xc00111f8, 0x00000fff},
	{0xc00111fc, 0x00000fff},
	{0xc00112f8, 0x00000fff},
	{0xc00112fc, 0x00000fff},
	{0xc00113f8, 0x00000fff},
	{0xc00113fc, 0x00000fff},
	{0xc00114f8, 0x00000fff},
	{0xc00114fc, 0x00000fff},
	{0xc00115f8, 0x00000fff},
	{0xc00115fc, 0x00000fff},
	{0xc00116f8, 0x00000fff},
	{0xc00116fc, 0x00000fff},
	{0xc00117f8, 0x00000fff},
	{0xc00117fc, 0x00000fff},
	{0xc0011af8, 0x00000fff},
	{0xc0011afc, 0x00000fff},
	{0xc0010a80, 0x01007f00},
	{0xc0010a84, 0x0100ff80},
	{0xc0010b80, 0x01007f00},
	{0xc0010b84, 0x0100ff80},
	{0xc0010c80, 0x01007f00},
	{0xc0010c84, 0x0100ff80},
	{0xc0010d80, 0x01007f00},
	{0xc0010d84, 0x0100ff80},
	{0xc0011180, 0x03007f00},
	{0xc0011184, 0x0300ff80},
	{0xc0011280, 0x03007f00},
	{0xc0011284, 0x0300ff80},
	{0xc0011380, 0x02007f00},
	{0xc0011384, 0x0200ff80},
	{0xc0011480, 0x02007f00},
	{0xc0011484, 0x0200ff80},
	{0xc0011580, 0x02007f00},
	{0xc0011584, 0x0200ff80},
	{0xc0011680, 0x02007f00},
	{0xc0011684, 0x0200ff80},
	{0xc0011780, 0x02007f00},
	{0xc0011784, 0x0200ff80},
	{0xc0011a80, 0x01007f00},
	{0xc0011a84, 0x0300ff80},
};

/* OLD FORMAT for M14A0 */
static void ddr_param_set(ddr_params_t* param, int cnt)
{
	while(cnt--)
	{
		switch(param->op)
		{
			case 0x00:	// write
				IO_WRITE(param->addr, param->val);
				debug("IO_WRITE( 0x%08x, 0x%08x);\n", param->addr, param->val);
				break;

			case 0x01:	// check1
				while((IO_READ(param->addr) & param->mask) != param->val);
				debug("while((IO_READ(0x%08x) & 0x%08x) != 0x%08x);\n", param->addr, param->mask, param->val);
				break;

			case 0x02:	// check2
				while((IO_READ(param->addr) != param->val) && (IO_READ(param->addr) != param->mask));
				debug("while((IO_READ(0x%08x)!= 0x%x)&&(IO_READ(0x%08x)!=0x%x));\n",
						param->addr, param->val, param->addr, param->mask);
				break;

			case 0x03:	// wait
				udelay(param->val);
				debug("delay(_%dms);\n", param->val/1000);
				break;

			default:
				printf("Invalid OP code[0x%x].\n", param->op);
				break;
		}
		//debug("0x%x 0x%08x 0x%08x 0x%08x\n", param->op, param->addr, param->val, param->mask);
		param++;
	}
}


static void reg_param_set(reg_param_t *param, int cnt)
{
	while(cnt--)
	{
		switch((param->opcode&REG_PARAM_OP_GROUP_MASK))
		{
			case REG_PARAM_OP_GROUP_WAIT:	// wait
				udelay(param->operand);
				debug("delay(_%dms);\n", param->operand/1000);
				break;

			case REG_PARAM_OP_GROUP_CHECK:	// check
				debug("REG_PARAM_OP_GROUP_CHECK\n");
				break;

			case REG_PARAM_OP_GROUP_RESERVED:
				debug("REG_PARAM_OP_GROUP_RESERVED\n");
				break;

			default:	// REG_PARAM_OP_GROUP_WRITE
				IO_WRITE(param->opcode, param->operand);
				debug("IO_WRITE( 0x%08x, 0x%08x);\n", param->opcode, param->operand);
				break;
		}
		//debug("0x%08x 0x%08x\n", param->op, param->val);
		param++;
	}
}

#include "arch/bus/ddrc_arbitration_b0.h"
#include "arch/bus/flexnoc_urgency_b0.h"
#include "arch/bus/router_b0.h"

#include "arch/bus/ddrc_arbitration_c0.h"
#include "arch/bus/flexnoc_urgency_c0.h"
#include "arch/bus/router_c0.h"

void ddr_ctrl_init(void)
{
	extern long _ext_info;

	if(get_chip_rev() < CHIP_LG1311_B0)
	{
		ext_info_hdr_a0_t *ext_info = (ext_info_hdr_a0_t*)&_ext_info;;

		if(ext_info->magic == EXT_INFO_MAGIC_M14A0)
		{
			ddr_param_set(ext_info->ddr_param, ext_info->ddr_params);
		}

		reg_param_set(ltop_confs_a0, sizeof(ltop_confs_a0)/sizeof(reg_param_t));
		reg_param_set(gtop_confs_a0, sizeof(gtop_confs_a0)/sizeof(reg_param_t));

		REG_WRITE(0xC001B0EC, 0x400);	/* disable cpu monitor through gpio[31] */
	}
	else
	{
		ext_info_hdr_b0_t *ext_info = (ext_info_hdr_b0_t*)&_ext_info;;

		if(ext_info->magic == EXT_INFO_MAGIC_M14B0)
		{
			reg_param_set(ext_info->ddr_param, ext_info->ddr_params);
		}

		if(get_chip_rev() < CHIP_LG1311_C0)
		{
			reg_param_set(ddrc_arbitration_b0_cmm, sizeof(ddrc_arbitration_b0_cmm)/sizeof(reg_param_t));
			reg_param_set(flexnoc_urgency_b0_cmm, sizeof(flexnoc_urgency_b0_cmm)/sizeof(reg_param_t));
			reg_param_set(router_b0_cmm, sizeof(router_b0_cmm)/sizeof(reg_param_t));
			//reg_param_set(reordering_ctrl, sizeof(reordering_ctrl)/sizeof(reg_param_t));
		}
		else
		{
			reg_param_set(ddrc_arbitration_c0_cmm, sizeof(ddrc_arbitration_c0_cmm)/sizeof(reg_param_t));
			reg_param_set(flexnoc_urgency_c0_cmm, sizeof(flexnoc_urgency_c0_cmm)/sizeof(reg_param_t));
			reg_param_set(router_c0_cmm, sizeof(router_c0_cmm)/sizeof(reg_param_t));
			//reg_param_set(reordering_ctrl, sizeof(reordering_ctrl)/sizeof(reg_param_t));
		}
	}

}
#else
void ddr_ctrl_init(void){}
#endif

