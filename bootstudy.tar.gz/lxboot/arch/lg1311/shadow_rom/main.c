#include <common.h>
#include <top_ddrc.h>
#include <shadow.h>
#include <soc_test.h>
#include <chip_config.h>

#define CHECK_TIME 		0

#if CHECK_TIME
#define GET_USEC(x) 	{x = timer_usec();}
#else
#define GET_USEC(x) 	do{}while(0);
#endif

#if PORT_ERR_CNT_CHECK
uint32_t port_err_cnt[6] = {0,};
#endif

#define RETRY_CNT 		25

//////////////////////////////////////////////////////////////////////
static void chip_detect(void);
static uint32_t get_chip_rev(void);



//////////////////////////////////////////////////////////////////////
static uint32_t shadow_test_cnt = 0;
static uint32_t chip_rev = CONFIG_CHIP;

//////////////////////////////////////////////////////////////////////
uint32_t ddr_vendor = DDR_NON_SS;



/* to change start address of shadow_rom

   SHADOW_ROM_OFFSET 	(firstboot/Makefile)
   SHADOW_OFFSET 		(shadow_rom/Makefile)
   shadow_rom.lst 		(header/b0/shadow)
   shadow_rom_ss.lst 	(header/b0/shadow)
 */

//////////////////////////////////////////////////////////////////////
int main(uint32_t mode0, uint32_t mode1)
{
#if CHECK_TIME
	uint32_t start_usec;
	uint32_t test_s_usec;
	uint32_t end_usec;
#endif

	chip_detect();

	/* from M14C0, support multi vendor DDR */
	if(get_chip_rev() >= CHIP_LG1311_C0)
	{
		if(mode0 == 0xa && mode1 == 0xb)
			ddr_vendor = DDR_SS;
		else
			ddr_vendor = DDR_NON_SS;
	}
	else
		ddr_vendor = DDR_NON_SS;

	printf("ddr vendor : %s\n", (ddr_vendor == DDR_NON_SS) ? "NON_SS" : "SS");

	if(soc_test())
		return 0;

	/* 
	 * normal initial sequence
	 * 1. setup top
	 * 2. ip reset
	 * 3. bus reset
	 * 4. setup lm & gm
	 * ---- workaournd code ----fail : jmp 3
	 * 5. ip on
	 */

	GET_USEC(start_usec);

	debug("IN SHADOW....\n");

	setup_top();


	GET_USEC(test_s_usec);

test_reset:

	setup_lm();

	setup_gm();

	shadow_test_cnt++;

	if(m14bx_gfx_port_walking() != 0)
	{
		setup_bus_reset();
		if(shadow_test_cnt >= RETRY_CNT)
		{
			debug(COLOR_RED"revival fail, reset cnt : %d\n"COLOR_NONE, shadow_test_cnt);
			while(1);
		}
		else
			goto test_reset;
	}


	GET_USEC(end_usec);


#if CHECK_TIME

	printf("gfx test elapsed time %d, try : %d\n"
			, end_usec - test_s_usec, shadow_test_cnt);

	printf("shadow elapsed time %d, s: %d, e: %d\n"
			, end_usec - start_usec, start_usec, end_usec);
#endif	

#if PORT_ERR_CNT_CHECK
	printf("err cnt - lm1[%d], lm2[%d], lm3[%d], gm1[%d], gm2[%d], gm3[%d]\n"
						,port_err_cnt[0]
						,port_err_cnt[1]
						,port_err_cnt[2]
						,port_err_cnt[3]
						,port_err_cnt[5]
						,port_err_cnt[4]);
#endif



	return 0;
}

/* chip detection */
static void chip_detect(void)
{
	uint32_t version;

	version = REG_READ(0xFD3003C4);
	if(version == 0x20120314)
	{
		u8 value = IO_READ8(0xC0223170);
		if(value != 0x00) chip_rev = ARCH_LG1311 | REV_A1;
		else chip_rev = ARCH_LG1311 | REV_A0;
		//ace_rev = ARCH_LG1311 | REV_A0;
	}
	else if(version == 0x20130221)
	{
	#if 0
		u8 value = IO_READ8(0xC0223170);
		if(value != 0xB1) chip_rev = ARCH_LG1311 | REV_B0;
		else chip_rev = ARCH_LG1311 | REV_B1;
	#else
		if(!(REG_READ(0xc000e018) & (1<<11)))
			chip_rev = ARCH_LG1311 | REV_B1;
		else
			chip_rev = ARCH_LG1311 | REV_C0;

		printf("chip rev : %s%s\n", get_arch_string(chip_rev), get_rev_string(chip_rev));
	#endif
		//ace_rev = ARCH_LG1311 | REV_B0;
	}
}

static uint32_t get_chip_rev(void)
{
	return chip_rev;
}


#if 0
int raise (int signum){ return 0;}
void __aeabi_unwind_cpp_pr0(void){}
void __aeabi_unwind_cpp_pr1(void){}
#endif

#if 0
void setup_normal_cmm(void)
{
	setup_top();

	setup_lm();

	setup_gm();
}
#endif


