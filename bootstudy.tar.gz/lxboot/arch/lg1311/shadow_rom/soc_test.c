#include <common.h>
#include <top_ddrc.h>
#include <shadow.h>


#define WATCHDOG_MAGIC 		0x5343524e
#define WORK_MAGIC_ADD 		0x10000000
#define WORK_MAGIC 			0xc372a397

#define READ_TE_SRAM_MAGIC0() 	({\
								REG_WRITE(0xc0008490, 0x3c);\
								REG_READ(0xc0008494);\
								})
#define READ_TE_SRAM_MAGIC1() 	({\
								REG_WRITE(0xc0008490, 0x3d);\
								REG_READ(0xc0008494);\
								})

#define CLEAR_WATCHDOG_MAGIC() 	do{\
									REG_WRITE(WORK_MAGIC_ADD 		, 0x0); \
									REG_WRITE(WORK_MAGIC_ADD + 0x04 , 0x0); \
									REG_WRITE(WORK_MAGIC_ADD + 0x08 , 0x0); \
									REG_WRITE(0xc0008490, 0x3c);\
									REG_WRITE(0xc0008494, 0x0);\
									REG_WRITE(0xc0008490, 0x3d);\
									REG_WRITE(0xc0008494, 0x0);\
								}while(0);

static void soc_reset(void)
{
	asm volatile ("cpsid	i");//interrupt disable

	//Watchdog reset
	REG_WRITE(0xfd200008, 0x2); /* Enable Watchdog reset output */
	REG_WRITE(0xfd200000, 0);

	udelay(100000);
	while(1);
}

int soc_test(void)
{
	/* if not soc test, then return */
	if((READ_TE_SRAM_MAGIC0() != WATCHDOG_MAGIC) ||
			(READ_TE_SRAM_MAGIC1() != WATCHDOG_MAGIC))
		return 0;
	/////////////////////////////////////////////////////////////
	else
	{

		uint32_t  	gfx_check0 = 0;
		uint32_t  	gfx_check1 = 0;
		volatile uint32_t *magic 		= (volatile uint32_t *)(WORK_MAGIC_ADD);
		volatile uint32_t *cnt 			= (volatile uint32_t *)(WORK_MAGIC_ADD + 0x04);
		volatile uint32_t *port_cnt 	= (volatile uint32_t *)(WORK_MAGIC_ADD + 0x08);
		volatile uint32_t *err_cnt 		= (volatile uint32_t *)(WORK_MAGIC_ADD + 0x0c);

		uint32_t 	port[6] = {1,2,3,1,2,3};
		uint32_t 	check_add[6] = {0x77004000,
			0x77004000,
			0x77004000,
			0xa7004000,
			0xa7004000,
			0xa7004000};

		/* do soc test */
		debug("checked soc-test in bootrom\n");

		setup_top();
		setup_lm();
		setup_gm();


		if(*magic != WORK_MAGIC)
		{
			*magic = WORK_MAGIC;
			*cnt = 1;
			*port_cnt = 0;
			err_cnt[0] =  0;
			err_cnt[1] =  0;
			err_cnt[2] =  0;
			err_cnt[3] =  0;
			err_cnt[4] =  0;
			err_cnt[5] =  0;
			printf("first time soc reset, %d\n", *cnt);
		}

		/*
		 * 1. setup gfx port
		 * 2. start gfx
		 * 3. check gfx
		 * 4. reset or not
		 */

		m14bx_gfx_port_setup(port[*port_cnt]); 			//setup gfx prot

		m14bx_gfx_start_add(check_add[*port_cnt]);	 	//start gfx

		udelay(10);

		gfx_check0 = REG_READ(0xc000b004) & 0x1;
		gfx_check1 = REG_READ(0xc000b00c) & 0x1;

		printf("check gfx:%d,%d ,p:%d, add:0x%08x loop:%d\n", gfx_check0, gfx_check1
				, port[*port_cnt], check_add[*port_cnt], (*cnt));

		if(gfx_check0 || gfx_check1)
		{
			err_cnt[*port_cnt]++;
			printf(COLOR_RED"=== fail gfx r/w ===\n"COLOR_NONE);
			while(1);
		}

		if(++(*port_cnt) >= 6)
		{
			*port_cnt = 0;
			(*cnt)++;
		}

		if((*magic == WORK_MAGIC) && (*cnt <= 100))
		{
			udelay(5000);
			soc_reset();
		}

		printf("\n============== report gfx r/w err count ==================\n");
		printf("port[%d],address[0x%08x] : %d\n", port[0], check_add[0], err_cnt[0]);
		printf("port[%d],address[0x%08x] : %d\n", port[1], check_add[1], err_cnt[1]);
		printf("port[%d],address[0x%08x] : %d\n", port[2], check_add[2], err_cnt[2]);
		printf("port[%d],address[0x%08x] : %d\n", port[3], check_add[3], err_cnt[3]);
		printf("port[%d],address[0x%08x] : %d\n", port[4], check_add[4], err_cnt[4]);
		printf("port[%d],address[0x%08x] : %d\n", port[5], check_add[5], err_cnt[5]);

		CLEAR_WATCHDOG_MAGIC();
		m14bx_gfx_port_setup(3); 	//restore gfx port

		return 1;
	}
}

