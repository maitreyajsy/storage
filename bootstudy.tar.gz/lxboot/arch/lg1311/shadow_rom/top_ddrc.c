#include <common.h>
#include <top_ddrc.h>

#include "top.h"
#include "lm.h"
#include "gm.h"
#include "lm_ss.h"
#include "gm_ss.h"

#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3


void setup_top(void)
{
	reg_param_set(top_cmm, ARRAY_SIZE(top_cmm));
	debug("top setup-done\n");
}

void setup_lm(void)
{
	if(ddr_vendor == DDR_NON_SS)
	{
		reg_param_set(lm_cmm, ARRAY_SIZE(lm_cmm));
		debug("lm setup-done[V:non-ss]\n");
	}
	else
	{
		reg_param_set(lm_ss_cmm, ARRAY_SIZE(lm_ss_cmm));
		debug("lm setup-done[V:ss]\n");
	}
}

void setup_gm(void)
{
	if(ddr_vendor == DDR_NON_SS)
	{
		reg_param_set(gm_cmm, ARRAY_SIZE(gm_cmm));
		debug("gm setup-done[V:non-ss]\n");
	}
	else
	{
		reg_param_set(gm_ss_cmm, ARRAY_SIZE(gm_ss_cmm));
		debug("gm setup-done[V:ss]\n");
	}
}

void reg_param_set(reg_param_t *param, int cnt)
{
	while(cnt--)
	{
		switch((param->opcode&REG_PARAM_OP_GROUP_MASK))
		{
			case REG_PARAM_OP_GROUP_WAIT:	// wait
				udelay(param->operand);
				//debug("delay(_%dms);\n", param->operand/1000);
				break;

			case REG_PARAM_OP_GROUP_CHECK:	// check
				//debug("REG_PARAM_OP_GROUP_CHECK\n");
				break;

			case REG_PARAM_OP_GROUP_RESERVED:
				//debug("REG_PARAM_OP_GROUP_RESERVED\n");
				break;

			default:	// REG_PARAM_OP_GROUP_WRITE
				IO_WRITE(param->opcode, param->operand);
				//debug("IO_WRITE( 0x%08x, 0x%08x);\n", param->opcode, param->operand);
				break;
		}
		//debug("0x%08x 0x%08x\n", param->op, param->val);
		param++;
	}
}


