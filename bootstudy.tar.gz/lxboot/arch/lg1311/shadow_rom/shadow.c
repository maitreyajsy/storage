#include <common.h>
#include <top_ddrc.h>

#include "bus_reset.h"


#if PORT_ERR_CNT_CHECK
extern uint32_t port_err_cnt[6];
#endif


void m14bx_gfx_port_setup(uint32_t port)
{
	REG_WRITE(0xC0015CA0 ,port);//0x3 		; GFX    LM READ
	REG_WRITE(0xC0015CA4 ,port);//0x3 		; GFX    GM READ
	REG_WRITE(0xC0015DA0 ,port);//0x3 		; GFX    LM WRITE
	REG_WRITE(0xC0015DA4 ,port);//0x3 		; GFX    GM WRITE
}

void m14bx_gfx_start_add(uint32_t add)
{
	REG_WRITE(0xc000b03c ,0x00000001);
	REG_WRITE(0xc000b03c ,0x00000000);
	REG_WRITE(0xc000b050 ,add 		); //src address //lm:0x77004000, gm:0xA7004000
	REG_WRITE(0xc000b054 ,0x00001400); //stride
	REG_WRITE(0xc000b058 ,0x0000001e);
	REG_WRITE(0xc000b05c ,0xffffffff);
	REG_WRITE(0xc000b060 ,0x00000000);
	REG_WRITE(0xc000b068 ,0x00000000);
	REG_WRITE(0xc000b06c ,0x00000000);
	REG_WRITE(0xc000b070 ,0x00000000);
	REG_WRITE(0xc000b074 ,0x00000000);
	REG_WRITE(0xc000b07c ,0x00000000);
	REG_WRITE(0xc000b120 ,add 		); //dst address //lm:0x78009000, gm: 0xA8009000
	REG_WRITE(0xc000b124 ,0x00001400); //stride
	REG_WRITE(0xc000b128 ,0x0000001e);
	REG_WRITE(0xc000b12c ,0x00000040); //write size // only 1 Access
	REG_WRITE(0xc000b130 ,0xffffffff);
	REG_WRITE(0xc000b134 ,0x00000000);
	REG_WRITE(0xc000b138 ,0x00000000);
	REG_WRITE(0xc000b140 ,0x10000000);
	REG_WRITE(0xc000b144 ,0x00000000);
	REG_WRITE(0xc000b148 ,0x10000000);
	REG_WRITE(0xc000b14c ,0x00000000);
	REG_WRITE(0xc000b150 ,0x10000000);
	REG_WRITE(0xc000b154 ,0x00000000);
	REG_WRITE(0xc000b158 ,0x00000000);
	REG_WRITE(0xc000b15c ,0x00000000);
	REG_WRITE(0xc000b100 ,0x00000000);
	REG_WRITE(0xc000b104 ,0x00000000);
	REG_WRITE(0xc000b108 ,0x00000000);
	REG_WRITE(0xc000b10c ,0x00000000);
	REG_WRITE(0xc000b110 ,0x00000000);
	REG_WRITE(0xc000b020 ,0x00000001);
	REG_WRITE(0xc000b024 ,0x008000c0);
	REG_WRITE(0xc000b028 ,0x01000040);
	REG_WRITE(0xc000b180 ,0x00000001);
	REG_WRITE(0xc000b034 ,0x00000001);
	REG_WRITE(0xc000b030 ,0x00000001);
}

int m14bx_gfx_port_walking(void)
{
	uint32_t 	port[6] = {1,2,3,1,3,2};
	uint32_t 	check_add[6] = {0x77004000,
								0x77004000,
								0x77004000,
								0xa7004000,
								0xa7004000,
								0xa7004000};
	int32_t 	i = 0;
	uint32_t  	gfx_check0 = 0;
	uint32_t  	gfx_check1 = 0;

	debug("=== %s ===\n", __func__);

	for(i = 5; i >= 0; i--)
	{
		m14bx_gfx_port_setup(port[i]);

		m14bx_gfx_start_add(check_add[i]);

		udelay(10);

		gfx_check0 = REG_READ(0xc000b004) & 0x1;
		gfx_check1 = REG_READ(0xc000b00c) & 0x1;


		debug("check gfx:%d,%d ,p:%d, add:0x%08x\n", gfx_check0, gfx_check1
				, port[i], check_add[i]);

		if(gfx_check0 || gfx_check1)
		{
#if PORT_ERR_CNT_CHECK
			port_err_cnt[i]++;
#endif
			debug(COLOR_RED"fail gfx r/w \n"COLOR_NONE);
			return -1;
		}
	}

	m14bx_gfx_port_setup(3); 	//restore gfx port
	return 0;
}

void setup_bus_reset(void)
{
	reg_param_set(bus_reset_cmm, ARRAY_SIZE(bus_reset_cmm));
	debug("bus_reset-done\n");
}


