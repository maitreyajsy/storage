#ifndef _TYPES_H_
#define _TYPES_H_

#ifdef __ASSEMBLY__

#define ENTRY(name)	.globl name; .align 4; name:
#define END(name)	.size name, .-name

#else

typedef signed 		char 	s8;
typedef unsigned 	char 	u8;

typedef signed 		short 	s16;
typedef unsigned 	short 	u16;

typedef signed 		int 	s32;
typedef unsigned 	int 	u32;

typedef signed long long	s64;
typedef unsigned long long	u64;

typedef u8 				uint8_t;
typedef u16				uint16_t;
typedef u32 			uint32_t;
typedef u64 			uint64_t;

typedef s8 				int8_t;
typedef s16				int16_t;
typedef s32 			int32_t;
typedef s64 			int64_t;

typedef unsigned int	size_t;
typedef long			off_t;
typedef long long		loff_t;


#define NULL 			((void *)0)


#define IO_WRITE(x,v)		(*((volatile u32 *)(x)) = v)
#define IO_READ(x)			(*((volatile u32 *)(x)))

#define IO_WRITE8(x,v)		(*((volatile u8 *)(x)) = v)
#define IO_READ8(x)			(*((volatile u8 *)(x)))

#define REG_WRITE(x,v)		IO_WRITE(x,v)
#define REG_READ(x)			IO_READ(x)

#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))

#endif // __ASSEMBLY__

#define YES			1
#define NO			0

#define FALSE		0
#define TRUE		1

#define UNLOCK		0
#define LOCK		1

#define	KB			1024
#define MB			(KB*1024)

#define KHZ			(1000)
#define MHZ			(1000*KHZ)
#define GHZ			(1000*MHZ)

#endif // _TYPES_H_
