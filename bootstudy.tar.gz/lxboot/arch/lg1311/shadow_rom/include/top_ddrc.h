#ifndef _TOP_DDRC_H_
#define _TOP_DDRC_H_

typedef struct
{
	uint32_t	opcode;
	uint32_t	operand;
} reg_param_t;

void reg_param_set(reg_param_t *param, int cnt);
void setup_top(void);
void setup_lm(void);
void setup_gm(void);

#endif
