#ifndef _SOC_TEST_H_
#define _SOC_TEST_H_


int soc_test(void);

#endif
