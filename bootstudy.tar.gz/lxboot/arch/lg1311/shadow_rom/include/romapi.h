#ifndef _ROMAPI_H_
#define _ROMAPI_H_



#if 0
int vsprintf(char *buf, const char *fmt, va_list args);
int vsnprintf(char *buf, size_t n, const char *fmt, va_list args);
int sprintf(char * buf, const char *fmt, ...);
int snprintf(char *buf, size_t n, const char *fmt, ...);
int putchar(char c);
void puts(const char *str);
#endif

int printf(const char *fmt, ...);
void puts(const char *str);
void udelay(uint32_t  usec);
uint32_t timer_usec(void);


#endif // _SHADOW_H_
