#ifndef _SHADOW_H_
#define _SHADOW_H_


void m14bx_gfx_port_setup(uint32_t port);
void m14bx_gfx_start_add(uint32_t add);
int m14bx_gfx_port_walking(void);
void setup_ip_reset(void);
void setup_ip_on(void);
void setup_bus_reset(void);

#endif
