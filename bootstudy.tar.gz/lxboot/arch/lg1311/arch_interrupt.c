#include <types.h>
#include <arch/irqs.h>
#include <arch/gic.h>
#include <stdio.h>
#include <serial.h>
#include <timer.h>
#include <thread.h>

/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	ks.hyun@lge.com 	Release initial codes for lxboot in arch/lg1152 folder.
|	? 	? 	2011	yw.kim@lge.com		Copy this file from arch/lg1152 to arch/lg1154 for evaluation.
|	Feb	26	2012	yw.kim@lge.com		Add interrupt_pre_cpu2nw() and interrupt_post_cpu2nw() for normal
|										world cpu2 interrupt.
|============================================================================================================*/


typedef struct
{
	int irq;
	void (*func)(void*);
	void* param;
	u32		count;
} irq_func_t;

#if USE_IRQ
static cpu_interrupt_interface_t *cii	= (cpu_interrupt_interface_t*)LG1311_GIC_CPU_BASE;
static interrupt_distributor_t *id 		= (interrupt_distributor_t *)LG1311_GIC_DIST_BASE;

static irq_func_t irq_local_funcs[CPU_NUM][IRQ_GIC_START];
static irq_func_t irq_shared_funcs[NR_IRQS - IRQ_GIC_START];
#endif

int interrupt_enabled(void)
{
	uint32_t cpsr;
	asm volatile("mrs	%0, cpsr\n"	: "=r"(cpsr));
	return (cpsr&CPSR_I_DISABLE) ? 0 : 1;
}

void interrupt_disable(void)
{
	asm volatile ("cpsid	i");
}

#if USE_IRQ
uint32_t interrupt_save(void)
{
	uint32_t old;

	asm volatile (
		"	mrs		%0, cpsr\n"
		"	cpsid	i\n"
		: "=r"(old) : );

	return old;
}

void interrupt_restore( uint32_t cpsr )
{
	asm volatile(
		"	msr		cpsr_c, %0\n"
		: : "r" (cpsr));
}

void interrupt_enable(void)
{
	asm volatile("cpsie	i");
}

void interrupt_active( uint32_t irq )
{
	uint32_t index;

	index = irq / 32;
	irq %= 32;
	irq = 1 << irq;

	id->enable_set[index] = irq;
}

void interrupt_deactive( uint32_t irq )
{
	uint32_t index;

	index = irq / 32;
	irq %= 32;
	irq = 1 << irq;

	id->enable_clear[index] = irq;
}

#define get_irq_func(n)	((n < IRQ_GIC_START) ? \
		&irq_local_funcs[get_current_cpu()][n] : \
		&irq_shared_funcs[n - IRQ_GIC_START])

int interrupt_handler( void )
{
	int ret = 0;
	irq_func_t *irq_func;

	uint32_t ack;
	int cpu_id, int_id;

#if USE_MULTI_THREAD
	thread_t* current = get_current_thread();
	current->in_interrupt = 1;
#endif

	do
	{
		ack = cii->interrupt_ack;
		cpu_id = (ack&IAR_CPUID_MASK) >> IAR_CPUID_SHIFT;
		int_id = (ack&INTERRUPT_MASK);

		if(int_id == SPURIOUS_INTERRUPT)
			break;

		irq_func = get_irq_func(int_id);

		if(irq_func->func)
		{
			irq_func->func(irq_func->param);
			irq_func->count++;
		}
		//else serial_printf("unregistered irq[%d]\n", irq);

		/* Clear the interrupt */
		cii->end_of_interrupt = ack;
	} while(TRUE);

#if USE_MULTI_THREAD
	current->in_interrupt = 0;
	ret = get_need_schedule();
#endif

	return ret;
}

int interrupt_request(uint32_t irq, void (*func )(void*), void *param)
{
	irq_func_t *irq_func = get_irq_func(irq);
	irq_func->func = func;
	irq_func->param = param;

//	printf("Request IRQ[%d]\n", irq);
	return 0;
}

void interrupt_free( uint32_t irq )
{
	irq_func_t *irq_func = get_irq_func(irq);
	interrupt_deactive(irq);
	irq_func->func = NULL;
}

void interrupt_local_init(void)
{
	int i;

#if 0
	/* Enable the CPU Interface */
	cii->control = 0x00000001;
#else
	/* Initialize cpu interrupt interface ! */

	/* Clear up the bits of the distributor which are actually CPU-specific */
	id->pending_clear[0] = 0xFFFFFFFF;
	for (i = 0; i < 8; i++)
	{
		id->priority[i] = 0x00000000;
}
	id->configuration[0] = 0xAAAAAAAA;
	id->configuration[1] = 0xAAAAAAAA;

	/* Disable the CPU Interface */
	cii->control = 0x00000000;

	/* Allow interrupts with higher priority (i.e. lower number) than 0xF */
	cii->priority_mask = 0x000000F0;

	/* All priority bits are compared for pre-emption */
	cii->binary_point = 0x00000003;

	/* Clear any pending interrupts */
	do
	{
		uint32_t irq = cii->interrupt_ack;

		if ((irq & INTERRUPT_MASK) == SPURIOUS_INTERRUPT)
		{
			break;
		}

		cii->end_of_interrupt = irq;
	} while (TRUE);

	/* Enable the CPU Interface */
	cii->control = 0x00000001;
#endif
}

void interrupt_init( void )
{
	int i;

	/* Initialize the IRQ handler */
#if 0
	for(i=0; i<NR_IRQS; i++)
	{

	}
#endif

#ifdef DBG
	printf("PERIPHERAL ID : ");
	for(i=0; i<GIC_PERIPHERAL_ID; i++)
		printf("0x%02x ", id->peripheral_id[i]);
	printf("\n");

	printf("PRIMCELL ID : ");
	for(i=0; i<GIC_PRIMECELL_ID; i++)
		printf("0x%02x ", id->primecell_id[i]);
	printf("\n");
#endif

	/* Disable the whole controller */
	id->control = 0x00000000;

	/* Disable all interrupts */
	for (i = 0; i < NO_OF_INTERRUPTS_IMPLEMENTED / 32; i++)
	{
		id->enable_clear[i] = 0xFFFFFFFF;
	}

	/* Clear all interrupts */
	for (i = 1; i < NO_OF_INTERRUPTS_IMPLEMENTED / 32; i++)
	{
		id->pending_clear[i] = 0xFFFFFFFF;
	}

	/* Reset interrupt priorities */
	for (i = 8; i < NO_OF_INTERRUPTS_IMPLEMENTED / 4; i++)
	{
		id->priority[i] = 0x80808080;
	}

	/* Reset interrupt targets */
	for (i = 0; i < NO_OF_INTERRUPTS_IMPLEMENTED / 4; i++)
	{
		id->target[i] = 0x01010101;		/* Each bit refers to CPU1, so we are using CPU1 not CPU0 ? */
	}

	/* Set interrupt configuration (level high sensitive, 1-N) */
	for (i = 2; i < NO_OF_INTERRUPTS_IMPLEMENTED / 16; i++)
	{
		id->configuration[i] = 0x55555555;
	}

	/* Set security status */
	for (i = 0; i < NO_OF_INTERRUPTS_IMPLEMENTED / 32; i++)
	{
		id->security[i] = 0x00000000;
	}

	/* Finally, enable the interrupt controller */
	id->control = 0x00000001;


	interrupt_local_init();

//	interrupt_enable();
}

/* Send an IPI to the requesting CPU */
void ipi_send(u32 ipi)
{
	ipi &= IPI_MASK;
	id->software_interrupt = (SELF << IPI_TARGET_FILTER_SHIFT) | ipi;
	dmb();
}

/* Send an IPI to all but the requesting CPU */
void ipi_broadcast(u32 ipi)
{
	ipi &= IPI_MASK;
	id->software_interrupt = (ALL_BUT_SELF << IPI_TARGET_FILTER_SHIFT) | ipi;
	dmb();
}

void ipi_send_target(u32 ipi, u32 target)
{
	ipi &= IPI_MASK;
	target &= 0xFF;

	id->software_interrupt = (USE_TARGET_LIST << IPI_TARGET_FILTER_SHIFT) |
							 (target << IPI_TARGET_SHIFT) |
							 ipi;
	dmb();
}
#else
void interrupt_init( void ){}
void interrupt_local_init(void){}
#endif	// #ifdef USE_IRQ


