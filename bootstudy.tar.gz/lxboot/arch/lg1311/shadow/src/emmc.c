#include <types.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <arch/address_map.h>

#include <emmc.h>


#include "arasan_emmc.h"
#include "sdmmc.h"


#if 0
#define debug(fmt,args...)		printf(fmt, ##args)
#else
#define debug(fmt,args...)		do{}while(0)
#endif

#if 1
#define error(fmt,args...)		printf(fmt, ##args)
#else
#define error(fmt,args...)		do{}while(0)
#endif


static struct mmc_host emmc_host;


static void emmc_decode_ext_csd(struct sd_mmc_ext_csd *pextcsd)
{
	unsigned char buffer[512];
	memcpy(buffer, pextcsd->buffer, 512);

	pextcsd->s_cmd_set =  buffer[504]; //1bits 504
	pextcsd->power_off_long_time =  buffer[247];
	pextcsd->ini_timeout_ap =  buffer[241]; //1bits 241
	pextcsd->pwr_cl_ddr_52_360 =  buffer[239]; //1bits 239
	pextcsd->pwr_cl_ddr_52_195 =  buffer[238]; //1bits 238
	pextcsd->min_perf_ddr_w8_52 =  buffer[235]; //1bits 235
	pextcsd->min_perf_ddr_r8_52 =  buffer[234]; //1bits 234
	pextcsd->trim_mult =  buffer[232]; //1bits 232
	pextcsd->sec_support                 =  buffer[231]; //1bits 231
	pextcsd->sec_erase_mult              =  buffer[230]; //1bits 230
	pextcsd->sec_trim_mult               =  buffer[229]; //1bits 229
	pextcsd->boot_info                   =  buffer[228]; //1bits 228
	pextcsd->boot_size_mult              =  buffer[226]; //1bits 226
	pextcsd->access_size                 =  buffer[225]; //1bits 225
	pextcsd->hc_erase_grp_size   =  buffer[224]; //1bits 224
	pextcsd->erase_timeout_multi =  buffer[223]; //1bits 223
	pextcsd->rel_wr_sec_cnt              =  buffer[222]; //1bits 222
	pextcsd->hc_wp_grp_size              =  buffer[221]; //1bits 221
	pextcsd->sleep_cur_vcc               =  buffer[220]; //1bits 220
	pextcsd->sleep_cur_vccq              =  buffer[219]; //1bits 219
	pextcsd->slp_awk_timeout     =  buffer[217]; //1bits 217

	pextcsd->sec_count = ( (buffer[215] << 24) | (buffer[214] << 16) | ( buffer[213] << 8) | (0 << buffer[212]));//4bits 215-212
	pextcsd->min_pref_w_8_52      = buffer[210];    //1bit 210
	pextcsd->min_pref_r_8_52      = buffer[209];    //1bit 209
	pextcsd->min_pref_w_8_26_4_52 = buffer[208];    //1bit 208
	pextcsd->min_pref_r_8_26_4_52 = buffer[207];    //1bit 207
	pextcsd->min_pref_w_4_26      = buffer[206];    //1bit 206
	pextcsd->min_pref_r_4_26      = buffer[205];    //1bit 205
	pextcsd->pwr_cl_26_360        = buffer[203];    //1bit 203
	pextcsd->pwr_cl_52_360        = buffer[202];    //1bit 202
	pextcsd->pwr_cl_26_195        = buffer[201];    //1bit 201
	pextcsd->pwr_cl_52_195        = buffer[200];    //1bit 200
	pextcsd->card_type            = buffer[196];    //1bit 196
	pextcsd->csd_structure        = buffer[194];    //1bit 194
	pextcsd->ext_csd_rev          = buffer[192];    //1bit 192

	// Modes segment
	pextcsd->cmd_Set              = buffer[191];    //1bit 191 r/w
	pextcsd->cmd_set_rev          = buffer[189];    //bit1 189
	pextcsd->power_class          = buffer[187];    //bit1 187
	pextcsd->hs_timing            = buffer[185];    //bit1 185
	pextcsd->bus_width            = buffer[183];    //bit1 183
	pextcsd->erased_mem_cont      = buffer[181];    //bit1 181
	pextcsd->boot_config                  = buffer[179];
	pextcsd->boot_config_prot     = buffer[178];
	pextcsd->boot_bus_width               = buffer[177];
	pextcsd->erase_grp_defn               = buffer[175];
	pextcsd->boot_wp                              = buffer[173];
	pextcsd->user_wp                              = buffer[171];
	pextcsd->fw_config                    = buffer[169];
	pextcsd->rpmb_size_mult               = buffer[168];
	pextcsd->rst_n_func                   = buffer[162];
	pextcsd->part_support                 = buffer[160];
	pextcsd->max_enh_size_mult    = (buffer[159] << 16)| (buffer[158] << 8) | buffer[157];
	pextcsd->part_attrb                   = buffer[156];
	pextcsd->part_set_complete    = buffer[155];
	pextcsd->GP_size_mult0                = (buffer[145] << 16) | (buffer[144] << 8) | buffer[143];
	pextcsd->GP_size_mult1                = (buffer[148] << 16) | (buffer[147] << 8) | buffer[146];
	pextcsd->GP_size_mult2                = (buffer[151] << 16) | (buffer[150] << 8) | buffer[149];
	pextcsd->GP_size_mult3                = (buffer[154] << 16) | (buffer[153] << 8) | buffer[152];
	pextcsd->enh_size_mult                = (buffer[142] << 16) | (buffer[141] << 8) | buffer[140];
	pextcsd->enh_start_addr       = (buffer[139] << 24) | (buffer[138] << 16) | (buffer[137] << 8) | buffer[136];
	pextcsd->sec_bad_blk_mngt     =  buffer[134];
	pextcsd->power_off_noti =  buffer[34];
}

static void emmc_set_baseaddress(struct mmc_host *host, unsigned int address)
{
	host->base = address;
}

static void emmc_delay(unsigned int usec)
{
	loop_udelay(usec);
}

static unsigned int emmc_ready_delay(struct mmc_host *host)
{
	unsigned int temp;
	uint32_t start_tick;

	start_tick = timer_tick();
	while (1)
	{
		temp = SDMMC_REG_READ(host,EMMC_PRESENT_STATE) & 0x7FFFF;
		if (temp == 0x70000)
		{
			break;
		}

		if(timer_elapsed(start_tick) > (500*1000))
		{
			error("EMMC BUS TIME OUT\n");
			return EMMC_ERROR_READY_TIMEOUT;
		}
	}

	return 0;
}

static unsigned int emmc_send_cmd(struct mmc_host *host, struct mmc_cmd *mmc)
{
	unsigned int result;

	result = emmc_ready_delay(host);
	if (result)
		return result;

	debug("CMD %u FLAG %02X MODE %02X ARG 0x%08X\n",mmc->cmd,mmc->flag, mmc->opr, mmc->arg);

	host->cmd = *mmc;

	SDMMC_REG_WRITE(host,EMMC_ARG, mmc->arg);
	SDMMC_REG_WRITE(host,EMMC_COMMAND, (mmc->cmd << (16 + 8)) + (mmc->flag << (16)) + mmc->opr);

	return EMMC_SUCCESS;
}

static unsigned int emmc_flag_check(struct mmc_host *host)
{
	unsigned int cmd_mask;
	unsigned int data_mask;
	unsigned int temp;
	unsigned int irq_res = 0;
	uint32_t start_tick;

	cmd_mask = CARD_CMD_MASK;
	data_mask = CARD_DATA_MASK;

	temp = SDMMC_REG_READ(host,EMMC_INT_STATUS);
	debug("EMMC_INT_STATUS = 0x%X\n", temp);
	if (temp & (1 << EMMC_INT_CARD_INSERT))
	{
		SDMMC_BIT_SET(host, EMMC_INT_STATUS, EMMC_INT_CARD_INSERT);
	}

	start_tick = timer_tick();

	while (1)
	{
		temp = SDMMC_REG_READ(host,EMMC_INT_STATUS);
		debug("EMMC_INT_STATUS2 = 0x%X\n", temp);
		if (temp & cmd_mask)
		{
			SDMMC_REG_WRITE(host,EMMC_INT_STATUS, (temp & cmd_mask));
			if (temp & CARD_CMD_FIN)
			{
				irq_res += MMC_CMD_COMPLETE;
				break;
			}
			else
			{
				error("CE = %08X\n",temp & cmd_mask);
				SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_CMD_RESET);
				SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_DATA_RESET);

				host->cmd.err += MMC_CMD_ERROR;
				irq_res += MMC_CMD_ERROR;
				return irq_res;
			}
		}

		if (timer_elapsed(start_tick) > (100*1000))
		{
			error("ITC = %08X\n",temp & cmd_mask);
			SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_CMD_RESET);
			SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_DATA_RESET);

			irq_res += MMC_CMD_TIMEOUT;
			return irq_res;
		}
	}


	if (host->cmd.done_check == MMC_FLAG_COMMAND_ONLY)
	{
		return 0;
	}

	unsigned int maxtime;
	maxtime = (1000*1000);

	start_tick = timer_tick();
	while (1)
	{
		temp = SDMMC_REG_READ(host,EMMC_INT_STATUS);
		if (temp & data_mask)
		{
			SDMMC_REG_WRITE(host,EMMC_INT_STATUS, (temp & data_mask));
			if(temp & CARD_DATA_FIN)
			{
				irq_res += MMC_DATA_COMPLETE;
				break;
			}
			else
			{
				error("DE = %08X\n",temp & data_mask);
				SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_CMD_RESET);
				SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_DATA_RESET);

				host->cmd.err += MMC_DATA_ERROR;
				irq_res += MMC_DATA_ERROR;
				return irq_res;
			}
		}

		if(timer_elapsed(start_tick) > maxtime)	/* temporary value */
		{
			error("ITD = %08X\n",temp & cmd_mask);
			SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_CMD_RESET);
			SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_DATA_RESET);

			irq_res += MMC_DATA_TIMEOUT;
			return irq_res;
		}
	}

	return 0;
}

static unsigned int emmc_int_check(struct mmc_host *host)
{
	unsigned int ret = 0;
	ret = emmc_flag_check(host);
	return ret;
}


int emmc_get_extcsd(struct mmc_host *host, int dump)
{
	unsigned int result;
	uint8_t csd_dma_buf[512];
	struct mmc_cmd mmc;


	host->mmc_adma_list[0].address = (unsigned int)csd_dma_buf;
	host->mmc_adma_list[0].size = 512;
	host->mmc_adma_list[0].flag = 0x23;

	SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(unsigned int)host->mmc_adma_list);
	SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(1 << 16) + 512);

	mmc.cmd = EMMC_CMD8_SEND_EXT_CSD;
	mmc.flag = MMC_RESP_R1 | RSP_DATA_PRESENT;
	mmc.opr = 0x11;
	mmc.arg = 0x00000000;
	mmc.done_check = MMC_FLAG_DATA;
	mmc.ack = 0;
	mmc.timeout_ms = 100;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		error("EMMC CMD8 SEND ERROR\n");
		return 1;
	}

	result = emmc_int_check(host);
	if (result)
	{
		error("EMMC CMD8 CHECK ERROR\n");
		return 1;
	}

	memcpy(host->card.ext_csd.buffer, (void *)csd_dma_buf, 512);

	emmc_decode_ext_csd(&host->card.ext_csd);

	return 0;
}


static adma_list_t t[MMC_ADMA_LIST_MAX];
static unsigned int init_emmc(struct mmc_host *host)
{
	volatile unsigned int temp;

	debug("EMMC Initialize Start\n");

	host->mmc_adma_list = (adma_list_t *)t;

	host->card.rca = 1;

	temp = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
	if (temp)
		return EMMC_FAIL;

	if (host->card.ext_csd.sec_count > (2 * 1024 * 1024 / 512))
		host->card.address_mode = EMMC_SECTOR_MODE;
	else
		host->card.address_mode = EMMC_BYTE_MODE;

	return EMMC_SUCCESS;
}

static unsigned int transfer_emmc_adma(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address, unsigned int r_w)
{
	unsigned int SectorAddress;
	unsigned short BlockCount;
	unsigned short BlockSize = MMC_SECTOR_SIZE;
	unsigned int result;
	struct mmc_cmd mmc;

	if (size & (BlockSize - 1))
	{
		debug("512");
		return EMMC_ERROR_UNITSIZE_FALSE;
	}

	if (size > MMC_CHUNKSIZE_MAX)
	{
		debug("t.s.o\n");
		return EMMC_ERROR_SIZE_OVER;
	}

	if (host->card.address_mode == EMMC_SECTOR_MODE)
		SectorAddress = (unsigned int)(address / MMC_SECTOR_SIZE);
	else
		SectorAddress = (unsigned int)address;

	unsigned int i;
	unsigned int size_count, size_mod;

//	printf("MMC READ SIZE = %u\n", size);

	size_count = size / MMC_ADMA_BLOCK_MAX;
	size_mod = size & (MMC_ADMA_BLOCK_MAX-1);
	if (size_mod)
		size_count++;

	for (i=0; i<(size_count-1); i++)
	{
		host->mmc_adma_list[i].address = buffer + (i*MMC_ADMA_BLOCK_MAX);
		host->mmc_adma_list[i].size = 0;
		host->mmc_adma_list[i].flag = 0x21;
	}
	host->mmc_adma_list[i].address = buffer + (i*MMC_ADMA_BLOCK_MAX);
	host->mmc_adma_list[i].size = size_mod;
	host->mmc_adma_list[i].flag = 0x23;

	BlockCount = (size / 512);

	SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(uint32_t)host->mmc_adma_list);
	SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(BlockCount << 16) + BlockSize);


	mmc.opr = (1 << EMMC_CMD_DMA_ENABLE);

	if (r_w == MMC_READ)
	{
		if (BlockCount > 1)
			mmc.cmd = EMMC_CMD18_READ_MULTI_EBLOCK;
		else
			mmc.cmd = EMMC_CMD17_READ_SINGLE_BLOCK;

		mmc.opr = mmc.opr + (1 << EMMC_CMD_DATA_DIRECTION);
	}
	else
	{
		if (BlockCount > 1)
			mmc.cmd = EMMC_CMD25_WRITE_MULTI_EBLOCK;
		else
			mmc.cmd = EMMC_CMD24_WRITE_SINGLE_BLOCK;
	}
	mmc.flag = MMC_RESP_R1 | RSP_DATA_PRESENT;


	if (BlockCount > 1)
		mmc.opr = mmc.opr + (1 << EMMC_CMD_MULTIBLOCK) + (1 << EMMC_CMD_BLOCK_COUNT_ENABLE) + (EMMC_AUTOCMD12_EN << EMMC_CMD_AUTO_ENABLE); // opr = opr + 0x26;

	mmc.arg = SectorAddress;
	mmc.done_check = MMC_FLAG_DATA;
	mmc.ack = 0;
	mmc.timeout_ms = 10000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;

	return result;
}

static unsigned int read_emmc_adma(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	return transfer_emmc_adma(host, buffer, size, address, MMC_READ);
}


static unsigned int read_emmc(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	unsigned int res;

	res = read_emmc_adma(host, buffer, size, address);
	if (res)
	{
		error("EMMC READ CMD SEND ERROR\n");
		return res;
	}

	res = emmc_int_check(host);
	if (res)
	{
		error("EMMC READ CMD CHECK ERROR\n");
	}

	return res;
}


static int arasan_emmc_init(void)
{
	struct mmc_host *host;
	static unsigned int inited = 0;

	if (!inited)
	{
		memset(&emmc_host, 0x0, sizeof(struct mmc_host));
		inited = 1;
	}
	host = &emmc_host;

	emmc_set_baseaddress(host,LG1311_SDHC_BASE);
	init_emmc(host);

	return 0;
}

static int arasan_emmc_read(loff_t offset, size_t len, void* buf)
{
	unsigned int retry_count = 0;
	unsigned int init_result;
	unsigned int block_result;
	struct mmc_host *host;
	host = &emmc_host;


	while (1)
	{
		if (retry_count)
		{
			if (retry_count >= 3)
			{
				return - 1;
			}

			printf("EMMC READ RETRY COUNT %u\n",retry_count);
			emmc_delay(100000);
			init_result = init_emmc(host);

			if (init_result)
			{
				retry_count++;
				continue;
			}
		}
		block_result = read_emmc(host, (unsigned int)buf, len, offset);
		if (block_result == 0)
		{
			break;
		}

		retry_count++;
	}


	return 0;
}


int emmc_init(void)
{
	return arasan_emmc_init();
}


int emmc_read(loff_t offset, size_t len, void* buf)
{
	return arasan_emmc_read(offset, len, buf);
}

