#include <types.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <serial.h>

#define PRINT_BUFFER_SIZE		256
void puts(const char *str)
{
	serial_puts(str);
}

int printf(const char *fmt, ...)
{
	char buffer[PRINT_BUFFER_SIZE];
	va_list ap;
	int len;

	va_start(ap, fmt);
	len = vsprintf(buffer, fmt, ap);
	va_end(ap);
	puts(buffer);

	return len;
}
