#include <types.h>
#include <serial.h>
#include <pl011.h>
#include <arch/address_map.h>


#define UART_BASE_ADDR		LG1311_UART0_BASE

static void pl011_putc(uint32_t portnum, char c)
{
	static int inited = 0;
	if(!inited)
	{
		u32 v;

		/* Set CTOP */
		v = IO_READ(LG1311_B0_CTOP_LEFT_BASE + 0x0040);
		v &= ~(0x07 << 29);			// clear uart0_sel
		v |= (0x02 << 29);			// uart0_sel[31:29] -- (0: tz, 2:cpu0)
		IO_WRITE(LG1311_B0_CTOP_LEFT_BASE + 0x0040, v);
		
		/* Disable UART */
		IO_WRITE (UART_BASE_ADDR + UART_PL011_CR, 0x0);

		/* Set baudrate as 115200 */
		IO_WRITE (UART_BASE_ADDR + UART_PL011_IBRD, 0x6B);
		IO_WRITE (UART_BASE_ADDR + UART_PL011_FBRD, 0x1B);

		/* Configure UART to be 8 bits, 1 stop bit, no parity, fifo enabled. */
		IO_WRITE (UART_BASE_ADDR + UART_PL011_LCRH, (UART_PL011_LCRH_WLEN_8 | UART_PL011_LCRH_FEN));

		/* Enable UART */
		IO_WRITE (UART_BASE_ADDR + UART_PL011_CR, (UART_PL011_CR_UARTEN | UART_PL011_CR_TXE | UART_PL011_CR_RXE));

		inited = 1;
	}

	/* Wait until there is space in the FIFO */
	while (IO_READ (UART_BASE_ADDR + UART_PL01x_FR) & UART_PL01x_FR_TXFF);

	/* Send the character */
	IO_WRITE (UART_BASE_ADDR + UART_PL01x_DR, c);
}

void serial_putc(char c)
{
	pl011_putc(0, c);
}

void serial_puts(const char *str)
{
	while(*str)
	{
		if(*str == '\n')
			serial_putc('\r');

		serial_putc(*str++);
	}
}
