#include <stdio.h>
#include <ctype.h>
#include <emmc.h>





int main(void)
{
	printf("IN SHADOW....\n");

		
	return 0;
}






int raise (int signum){ return 0;}
void __aeabi_unwind_cpp_pr0(void){}
void __aeabi_unwind_cpp_pr1(void){}

