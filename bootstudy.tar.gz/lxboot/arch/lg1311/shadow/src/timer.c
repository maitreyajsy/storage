/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011-2014 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <string.h>
#include <arch/address_map.h>
#include <arch/timers.h>


#define CPU_MIN_CLOCK	(960*MHZ)
#define TIMER_CLOCK		(192*MHZ)

static timer_t *timer1 = TIMER(1);

uint32_t timer_tick(void)
{
	return (uint32_t)(TIMER1_RELOAD - timer1->value);
}

void loop_udelay(uint32_t usec)
{
	extern void cpu_loop(uint32_t count);	// start.S
	cpu_loop(CPU_MIN_CLOCK / 1000000 * usec);
}

void udelay(uint32_t  usec)
{
	loop_udelay(usec);
}

void mdelay(uint32_t msec)
{
	loop_udelay(msec*1000);
}

uint32_t timer_ticks2usec(uint32_t ticks)
{
	return (uint32_t)(ticks/TIMER_CLOCK);
}

/* in usec unit */
uint32_t timer_elapsed(uint32_t ticks)
{
	return timer_ticks2usec((uint32_t)(timer_tick() - ticks));
}


