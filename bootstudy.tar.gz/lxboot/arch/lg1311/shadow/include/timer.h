#ifndef _TIMER_H_
#define _TIMER_H_


uint64_t timer_usec(void);
uint32_t timer_msec(void);
uint32_t timer_sec(void);
uint32_t timer_tick(void);
uint32_t timer_ticks2usec(uint32_t ticks);
uint32_t timer_elapsed(uint32_t ticks);

void mdelay(uint32_t msec);
void udelay(uint32_t  usec);
void loop_udelay(uint32_t usec);
void loop_mdelay(uint32_t msec);

#endif //_TIMER_H_
