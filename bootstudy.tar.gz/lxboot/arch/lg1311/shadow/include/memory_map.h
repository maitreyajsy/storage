#ifndef _MEMORY_MAP_H_
#define _MEMORY_MAP_H_

#define SRAM_BASE		0xC0080000
#define SRAM_SIZE		0x00010000	/* 64KB */

#define TEXT_BASE		SRAM_BASE
#define STACK_TOP		(SRAM_BASE + SRAM_SIZE - 0x10)


#endif
