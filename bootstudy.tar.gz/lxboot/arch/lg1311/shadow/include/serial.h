#ifndef _SERIAL_H_
#define _SERIAL_H_

void serial_putc(char c);
void serial_puts(const char *str);

#endif
