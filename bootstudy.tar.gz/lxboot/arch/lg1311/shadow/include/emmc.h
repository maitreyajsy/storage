#ifndef _EMMC_H_
#define _EMMC_H_

#include <types.h>

int emmc_init(void);
int emmc_read(loff_t offset, size_t len, void* buf);

#endif //_EMMC_H_
