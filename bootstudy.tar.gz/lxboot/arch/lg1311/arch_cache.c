/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <mmu.h>
#include <arch/cpu.h>
#include <command.h>
#include <interrupt.h>
#include <thread.h>

#ifdef USE_DATA_CACHE
void dcache_flush_all(void)
{
	flush_dcache();
	dsb();
#if USE_L2_CACHE
	l2c_flush();
#endif
}

void dcache_clean_all(void)
{
	clean_dcache();
	dsb();
#if USE_L2_CACHE
	l2c_clean();
#endif
}

void dcache_inv_all(void)
{
	inv_dcache();
	dsb();
#if USE_L2_CACHE
	l2c_inv();
#endif
}

void dcache_flush_range(unsigned long start, unsigned long size)
{
	unsigned long nstart = start;
	unsigned long end = start + size;

	nstart &= ~(D_CACHE_LINE_SIZE-1);

	while(nstart < end)
	{
		asm ("mcr p15, 0, %0, c7, c14, 1": :"r" (nstart));	// clean & invalidate D / U line
		nstart += D_CACHE_LINE_SIZE;
	}
	dsb();

#if USE_L2_CACHE
	l2c_flush_range(start, size);
#endif
}

void dcache_clean_range(unsigned long start, unsigned long size)
{
	unsigned long nstart = start;
	unsigned long end = start + size;

	nstart &= ~(D_CACHE_LINE_SIZE-1);

	while(nstart < end)
	{
		asm ("mcr	p15, 0, %0, c7, c10, 1": :"r" (nstart));	// clean D / U line
		nstart += D_CACHE_LINE_SIZE;
	}
	dsb();

#if USE_L2_CACHE
	l2c_clean_range(start, size);
#endif
}

void dcache_inv_range(unsigned long start, unsigned long size)
{
	unsigned long nstart = start;
	unsigned long end = start + size;

	if( nstart & (D_CACHE_LINE_SIZE-1))
	{
		nstart &= ~(D_CACHE_LINE_SIZE-1);
		asm ("mcr	p15, 0, %0, c7, c10, 1": :"r" (nstart));	// clean D line
	}

	if( end & (D_CACHE_LINE_SIZE-1))
	{
		end &= ~(D_CACHE_LINE_SIZE-1);
		asm ("mcr p15, 0, %0, c7, c14, 1": :"r" (end));	// clean & invalidate D line
	}

	while(nstart < end)
	{
		asm ("mcr p15, 0, %0, c7, c6, 1": :"r" (nstart));	// invalidate D line
		nstart += D_CACHE_LINE_SIZE;
	}
	dsb();

#if USE_L2_CACHE
	l2c_inv_range(start, size);
#endif
}
#else
void dcache_flush_all(void);
void dcache_clean_all(void);
void dcache_inv_all(void);
void dcache_flush_range(unsigned long start, unsigned long size){}
void dcache_clean_range(unsigned long start, unsigned long size){}
void dcache_inv_range(unsigned long start, unsigned long size){}
#endif

void icache_disable(void)
{
	unsigned long reg;

	reg = read_cp15_sctlr();
	reg &= ~(CP15_SCTLR_I_ENABLE);	//turn i-cache off
	write_cp15_sctlr(reg);
}

void icache_enable(void)
{
	unsigned long reg;

	reg = read_cp15_sctlr();
	reg |= CP15_SCTLR_I_ENABLE;	//turn i-cache on
	write_cp15_sctlr(reg);
}

void cache_flush(void)
{
	asm ("mcr p15, 0, %0, c7, c5, 0": :"r"(0));		/* invalidate entire instruction cache. also flushed the branch target cache */
	flush_dcache();
}


#if USE_L2_CACHE
/*
#define L2C310_EVENT_CNT_CTRL		0x200
#define L2C310_EVENT_CNT1_CFG		0x204
#define L2C310_EVENT_CNT0_CFG		0x208
#define L2C310_EVENT_CNT1_VAL		0x20C
#define L2C310_EVENT_CNT0_VAL		0x210
#define L2C310_INTR_MASK			0x214
#define L2C310_MASKED_INTR_STAT		0x218
#define L2C310_RAW_INTR_STAT		0x21C
#define L2C310_INTR_CLEAR			0x220

#define L2C310_CLEAN_LINE_IDX		0x7B8
#define L2C310_CLEAN_INV_LINE_IDX	0x7F8

#define L2C310_LOCKDOWN_WAY_D		0x900
#define L2C310_LOCKDOWN_WAY_I		0x904
#define L2C310_TEST_OPERATION		0xF00
#define L2C310_LINE_DATA			0xF10
#define L2C310_LINE_TAG				0xF30

#define L2C310_DEBUG_CTRL			0xF40
#define L2C310_POWER_CTRL			0xF80
*/


#define L2C310_CACHE_ID				0x000
#define L2C310_CACHE_TYPE			0x004
#define L2C310_CTRL					0x100
#define L2C310_AUX_CTRL				0x104
#define L2C310_TAG_LATENCY_CTRL		0x108
#define L2C310_DATA_LATENCY_CTRL	0x10C

#define L2C310_CACHE_SYNC			0x730
#define L2C310_DUMMY_REG			0x740

#define L2C310_INV_LINE_PA			0x770
#define L2C310_INV_WAY				0x77C
#define L2C310_CLEAN_LINE_PA		0x7B0
#define L2C310_CLEAN_WAY			0x7BC
#define L2C310_CLEAN_INV_LINE_PA	0x7F0
#define L2C310_CLEAN_INV_WAY		0x7FC

#define L2C310_PREFETCH_CTRL		0xF60



#define L2C_TAG_LATENCY			0x011
#define L2C_DATA_LATENCY		0x022

#define L2C_LINE_SIZE			32
#define L2C_PREFETCH_OFFSET		0x7

#if 0
#define L2C_DEBUG(fmt, args...)		printf(fmt, ##args)
#else
#define L2C_DEBUG(fmt, args...)		do{}while(0)
#endif

static u32 l2c_way_mask;
static u32 l2c_size;

#if USE_MULTI_THREAD
static spin_lock_t l2c_lock = INIT_SPIN_LOCK;
#define L2C_LOCK(flags) 	do{spin_lock_save(&l2c_lock, flags);}while(0)
#define L2C_UNLOCK(flags)	do{spin_unlock_restore(&l2c_lock, flags);}while(0)
#else
#define L2C_LOCK(flags)		do{(void)(flags);}while(0)
#define L2C_UNLOCK(flags)	do{(void)(flags);}while(0)
#endif

static inline void l2c_sync(void)
{
	REG_WRITE(LG1311_L2CC_BASE + L2C310_CACHE_SYNC, 0);
}

#define l2c_wait_way(reg, mask)	while (REG_READ(reg) & mask)
#define l2c_clean_line(addr)	REG_WRITE(LG1311_L2CC_BASE + L2C310_CLEAN_LINE_PA, addr)
#define l2c_inv_line(addr)		REG_WRITE(LG1311_L2CC_BASE + L2C310_INV_LINE_PA, addr)
#define l2c_flush_line(addr)	REG_WRITE(LG1311_L2CC_BASE + L2C310_CLEAN_INV_LINE_PA, addr)


void l2c_flush_range(unsigned long start, unsigned long size)
{
	unsigned long end;
	unsigned long pstart, pend;
	unsigned long step;
	u32 flags;

	L2C_DEBUG("l2c_flush_range. start:0x%08x, size:%d\n", start, size);

	if(size >= l2c_size)
	{
		L2C_DEBUG("l2c_flush_all\n");
		l2c_flush();
		return;
	}

	end = start + size;
	start &= ~(L2C_LINE_SIZE-1);

	L2C_LOCK(flags);
	step = (MMU_SECTION_SIZE - (start&(MMU_SECTION_SIZE - 1)));
	while(start < end)
	{
		pstart = mmu_virt_to_phys(start);
		L2C_DEBUG("virt:0x%08x, phys:0x%08x, step:%d\n", start, pstart, step);

		size = min(step, (end-start));
		pend = pstart + size;
		while(pstart < pend)
		{
			l2c_flush_line(pstart);		// clean & invalidate line
			pstart += L2C_LINE_SIZE;
		}
		start += size;
		step = MMU_SECTION_SIZE;
	}
	l2c_sync();
	L2C_UNLOCK(flags);
	L2C_DEBUG("l2c_flush_range. done\n");
}

void l2c_clean_range(unsigned long start, unsigned long size)
{
	unsigned long end;
	unsigned long pstart, pend;
	unsigned long step;
	u32 flags;

	L2C_DEBUG("l2c_clean_range. start:0x%08x, size:%d\n", start, size);

	if(size >= l2c_size)
	{
		L2C_DEBUG("l2c_clean_all\n");
		l2c_clean();
		return;
	}

	end = start + size;
	start &= ~(L2C_LINE_SIZE-1);

	L2C_LOCK(flags);
	step = (MMU_SECTION_SIZE - (start&(MMU_SECTION_SIZE - 1)));
	while(start < end)
	{
		pstart = mmu_virt_to_phys(start);
		L2C_DEBUG("virt:0x%08x, phys:0x%08x\n", start, pstart);

		size = min(step, (end-start));
		pend = pstart + size;
		while(pstart < pend)
		{
			l2c_clean_line(pstart);			// clean line
			pstart += L2C_LINE_SIZE;
		}
		start += size;
		step = MMU_SECTION_SIZE;
	}
	l2c_sync();
	L2C_UNLOCK(flags);
	L2C_DEBUG("l2c_clean_range. done\n");
}

void l2c_inv_range(unsigned long start, unsigned long size)
{
	unsigned long end;
	unsigned long pstart, pend;
	unsigned long step;
	u32 flags;

	L2C_DEBUG("l2c_inv_range. start:0x%08x, size:%d\n", start, size);

	end = start + size;

	L2C_LOCK(flags);
	if( start & (L2C_LINE_SIZE-1))
	{
		start &= ~(L2C_LINE_SIZE-1);
		pstart = mmu_virt_to_phys(start);
		l2c_clean_line(pstart);		// clean line
	}

	if( end & (L2C_LINE_SIZE-1))
	{
		end &= ~(L2C_LINE_SIZE-1);
		pend = mmu_virt_to_phys(end);
		l2c_flush_line(pend);		// clean & invalidate line
	}

	step = (MMU_SECTION_SIZE - (start&(MMU_SECTION_SIZE - 1)));
	while(start < end)
	{
		pstart = mmu_virt_to_phys(start);
		L2C_DEBUG("virt:0x%08x, phys:0x%08x\n", start, pstart);

		size = min(step, (end-start));
		pend = pstart + size;
		while(pstart < pend)
		{
			l2c_inv_line(pstart);		// invalidate line
			pstart += L2C_LINE_SIZE;
		}
		start += size;
		step = MMU_SECTION_SIZE;
	}
	l2c_sync();
	L2C_UNLOCK(flags);
	L2C_DEBUG("l2c_inv_range. done\n");
}


void l2c_flush(void)
{
	u32 flags;

	L2C_LOCK(flags);

	REG_WRITE(LG1311_L2CC_BASE + L2C310_CLEAN_INV_WAY, l2c_way_mask);
	l2c_wait_way(LG1311_L2CC_BASE + L2C310_CLEAN_INV_WAY, l2c_way_mask);
	l2c_sync();
	L2C_UNLOCK(flags);
}

void l2c_clean(void)
{
	u32 flags;

	L2C_LOCK(flags);
	REG_WRITE(LG1311_L2CC_BASE + L2C310_CLEAN_WAY, l2c_way_mask);
	l2c_wait_way(LG1311_L2CC_BASE + L2C310_CLEAN_WAY, l2c_way_mask);
	l2c_sync();
	L2C_UNLOCK(flags);
}

void l2c_inv(void)
{
	u32 flags;

	L2C_LOCK(flags);
	REG_WRITE(LG1311_L2CC_BASE + L2C310_INV_WAY, l2c_way_mask);
	l2c_wait_way(LG1311_L2CC_BASE + L2C310_INV_WAY, l2c_way_mask);
	l2c_sync();
	L2C_UNLOCK(flags);
}


void l2c_disable(void)
{
	u32 ctrl;

	l2c_flush();

	/* if data or instruction prefetch is enabled, restore default setting */
	ctrl = REG_READ(LG1311_L2CC_BASE + L2C310_PREFETCH_CTRL);
	if(ctrl | 0x30000000)
		REG_WRITE(LG1311_L2CC_BASE + L2C310_PREFETCH_CTRL,0);

	REG_WRITE(LG1311_L2CC_BASE + L2C310_CTRL, 0);
	dsb();
}

void l2c_init(void)
{
	u32 ctrl, aux;
	int ways, way_size;

	ctrl = REG_READ(LG1311_L2CC_BASE + L2C310_CTRL);
	aux = REG_READ(LG1311_L2CC_BASE + L2C310_AUX_CTRL);
	aux |= (0x1 << 22);
	REG_WRITE(LG1311_L2CC_BASE + L2C310_AUX_CTRL, aux);

	if(aux & (0x1 << 16)) ways = 16;
	else ways = 8;

	way_size = 1 << (((aux >> 17) & 0x7) + 3);
	l2c_way_mask = (1 << ways) - 1;
	l2c_size = (way_size * ways) << 10;

	// L2C ID : 0x410000C5
	L2C_DEBUG("L2C ID : 0x%08x\n", REG_READ(LG1311_L2CC_BASE + L2C310_CACHE_ID));
	L2C_DEBUG("L2C PL310 : %d ways, %dKB way size, %d KB, aux:0x%08x, ctrl:0x%08x, way mask:0x%08x\n",
				ways, way_size, l2c_size/1024, aux, ctrl, l2c_way_mask);

	if(ctrl&0x1)
	{
		printf("^r^L2C is alread enabled !!!\n");
		l2c_disable();
	}

	REG_WRITE(LG1311_L2CC_BASE + L2C310_TAG_LATENCY_CTRL, L2C_TAG_LATENCY);
	REG_WRITE(LG1311_L2CC_BASE + L2C310_DATA_LATENCY_CTRL, L2C_DATA_LATENCY);

	ctrl = REG_READ(LG1311_L2CC_BASE + L2C310_PREFETCH_CTRL);
	ctrl &= 0xffffffe0;
	ctrl |= 0x10000000;
	ctrl |= L2C_PREFETCH_OFFSET;
	REG_WRITE(LG1311_L2CC_BASE + L2C310_PREFETCH_CTRL, ctrl);

	l2c_inv();
	REG_WRITE(LG1311_L2CC_BASE + L2C310_CTRL, 0x1);	/* enable L2C */


}
#endif


#if !defined(FIRST_BOOT)
static int cmd_cacheinfo(int argc, char* argv[])
{
	uint32_t value;

	uint32_t 	cache_lvl;
	uint32_t	CTypeX;

	/*
	* Read c0, Cache Type Register(CTR)
	**/
	asm volatile ("mrc	p15, 0, %0, c0, c0, 1\n" : "=r" (value):: "memory");
	printf("cp15 ctr[%08x]\n", value);

	/*
	* L1 instruction cache indexing and tagging policy.
	**/
	switch((value>>14)&0x03)
	{
		case 0x1:
			printf("ASID-tagged Virtual Index, Virtual Tag (AIVIVT) \n");
			break;

		case 0x2:
			printf("Virtual Index, Physical Tag (VIPT) \n");
			break;

		case 0x3:
			printf("Physical Index, Physical Tag (PIPT) \n");
			break;

		default:
			printf("Unknown L1 I-cache idx and tagging policy \n");
	}


	/*
	* Log2 of the number of words in the smallest cache line of all the
	* instruction caches that are controlled by the processor.
	**/
	printf("IminLine: %d words\n", 0x1<<(value&0xF));


	/*
	* Log2 of the number of words in the smallest cache line of all the
	* data caches that are controlled by the processor.
	**/
	printf("DminLine: %d words\n", 0x1<<((value>>16)&0xF));


	/*
	* Exclusives Reservation Granule. Log2 of the number of words of
	* the maximum size of the reservation granule that has been implemented
	* for the Load-Exclusive and Store-Exclusive instructions.
	**/
	printf("Exclusives Reservation Granule: %d words\n", 0x1<<((value>>20)&0xF));


	/*
	* Cache Writeback Granule. Log2 of the number of words of the maximum size of memory
	* that can be overwritten as a result of the eviction of a cache entry that has had a memory
	* location in it modified.
	* A value of 0b0000 indicates that the CTR does not provide Cache Writeback Granule
    * information and either:
    * . the architectural maximum of 512 words (2Kbytes) must be assumed
    * . the Cache Writeback Granule can be determined from maximum cache line size encoded in the Cache Size ID Registers.
    * Values greater than 0b1001 are reserved.
	**/
	if(((value>>24)&0xF) != 0x0)
	{
		printf("Cache Writeback Granule.: %d words\n", 0x1<<((value>>24)&0xF));
	}

	/*
	* Read c0, Cache Level ID Register(CLIDR)
	**/
	asm volatile ("mrc	p15, 1, %0, c0, c0, 1\n" : "=r" (value):: "memory");
	printf("cp15 clidr[%08x]\n", value);

	for(cache_lvl=0;cache_lvl<7;cache_lvl++)
	{
		CTypeX = (value << (cache_lvl*3))&0x7;

		if(CTypeX!=0x0)
		{
			printf("cache level [%d]",cache_lvl+1);

			switch(CTypeX)
			{
				case 0x1:
					printf("\t Instruction cache only\n");
					break;

				case 0x2:
					printf("\t Data cache only\n");
					break;

				case 0x3:
					printf("\t Separate Instruction and Data caches\n");
					break;

				case 0x4:
					printf("\t Unified cache\n");
					break;

				default:
					printf("\t There is no cache!!\n");
			}

			printf("Level of Unification Inner Shareable[%d]\n", (value >> 21) & 0x07);
			printf("Level of Coherency[%d]\n", (value >> 24) & 0x07);
			printf("Level of Unification Uniprocessor[%d]\n", (value >> 27) & 0x07);
		}
	}

	/*
	* Set Instruction Cache Size Selection.
	* Get Instruction Cache Size.
	**/
	asm volatile("mcr	p15, 2, %0, c0, c0, 0\n" :: "r" (1): "memory");			// Cache Size Selection
	asm volatile("mrc	p15, 1, %0, c0, c0, 0\n" : "=r" (value):: "memory");	// Cache Size ID

	printf("ICache Size Info:\n");
	printf("\t# of words in ICache line: %d words\n", 0x1<<((value&0x7) + 2));
	printf("\tAssociaivity of ICache: %d\n", ((value>>3)&0x3FF) + 1);
	printf("\t# of sets in ICache: %d\n", ((value>>13)&0x7FFF) + 1);
	printf("\tSupport Write-Allocation[%d]\n", (value>>28)&0x01);
	printf("\tSupport Real-Allocation[%d]\n", (value>>29)&0x01);
	printf("\tSupport Write-Back[%d]\n", (value>>30)&0x01);
	printf("\tSupport Write-Through[%d]\n", (value>>31)&0x01);


	/*
	* Set Data Cache Size Selection.
	* Get Data Cache  Size.
	**/
	asm volatile("mcr	p15, 2, %0, c0, c0, 0\n" :: "r" (0): "memory");			// Cache Size Selection
	asm volatile("mrc	p15, 1, %0, c0, c0, 0\n" : "=r" (value):: "memory");	// Cache Size ID
	printf("\nDCache Size Info:\n");
	printf("\t# of words in DCache line: %d words\n", 0x1<<((value&0x7) + 2));
	printf("\tAssociaivity of DCache: %d\n", ((value>>3)&0x3FF) + 1);
	printf("\t# of sets in DCache: %d\n", ((value>>13)&0x7FFF) + 1);
	printf("\tSupport Write-Allocation[%d]\n", (value>>28)&0x01);
	printf("\tSupport Real-Allocation[%d]\n", (value>>29)&0x01);
	printf("\tSupport Write-Back[%d]\n", (value>>30)&0x01);
	printf("\tSupport Write-Through[%d]\n", (value>>31)&0x01);

	return 0;
}

COMMAND(cacheinfo, cmd_cacheinfo, "display cache info", NULL);
#endif

