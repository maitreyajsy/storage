/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
/*----------------------------------------------------------------------------------------
  Control Constants
  ----------------------------------------------------------------------------------------*/
#undef	GFX_WA_FILL_ERROR

/*----------------------------------------------------------------------------------------
  File Inclusions
  ----------------------------------------------------------------------------------------*/
#if USE_BOOT_LOGO || USE_DISPLAY
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <command.h>
#include <partinfo.h>
#include <storage.h>
#include <util.h>
#include <timer.h>
#include <image.h>
#include <logo.h>
#include <decompress.h>
#include <malloc.h>
#include <thread.h>

#include <arch/ovi_config_m14a0.h>

/*----------------------------------------------------------------------------------------
  Constant Definitions
  ----------------------------------------------------------------------------------------*/
#define DE_ADDR_BASE		0xc0020000

#ifndef OSD_HEADER_BASE
#define OSD_HEADER_BASE		0x70000000			/* raxis.lim (2012/06/29) OSD header address should be fixed */
#endif
#define	OSD_PLTE_BUFFER		OSD_HEADER_BASE + 0x20
#define	OSD_FRAME_BUFFER	OSD_HEADER_BASE + 0x2000

static UINT32 OSD_ADDR_BASE;
#define	OSD_ADDR_BASE_Ax	0xc0035100			/* DE.OSD reg base (M14Ax) */
#define	OSD_ADDR_BASE_Bx	0xc0024100			/* DE.OSD reg base (M14Bx) */
#define	GFX_ADDR_BASE		0xc000b000
#define DISPLAY_WIDTH		1920
#define DISPLAY_HEIGHT		1080

/*----------------------------------------------------------------------------------------
  Macro Definitions
  ----------------------------------------------------------------------------------------*/
#define set_reg(base,offset,val)	REG_WRITE(base+offset,val)
#define get_reg(base,offset) 		REG_READ(base+offset)

/*----------------------------------------------------------------------------------------
  Type Definitions
  ----------------------------------------------------------------------------------------*/
typedef struct
{
	u32	addr;
	u32	value;
}
REG_T;

/*----------------------------------------------------------------------------------------
  External Function Prototype Declarations
  ----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
  External Variables
  ----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
  global Variables
  ----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
  Static Function Prototypes Declarations
  ----------------------------------------------------------------------------------------*/
static void OSD_Init(void);

/*----------------------------------------------------------------------------------------
  Static Variables
  ----------------------------------------------------------------------------------------*/

/*========================================================================================
  Implementation Group ( VIDEO & FRC )
  ========================================================================================*/

static void DISP_Init(struct disp_info* info)
{
	int i;
	int count;
	const OVI_REG_T *regs;
	struct ctop_disp *ctop_disp;
	u32 val;
	// M14B0 Base address
	u32 tcon_base_addr = 0xC0030000;
	u32 led_spi_base_addr = 0xC0040000;

	printf("DISP_Init-chip[%d]\n", get_chip_rev());
	printf("\tpanel_type[%d]/panel_inch[%d]/panel_tool[%d]/panel_maker[%d]/panel_backlight[%d]/panel_led_bar_type[%d]\n",
			info->panel_type,info->panel_inch,info->panel_tool,info->panel_maker,info->panel_backlight,info->panel_led_bar_type);
	printf("\toutput_type[%d]/mirror[%d]/lvds_type[%d]/lvds_bit[%d]\n",
			info->output_type,info->mirror,info->lvds_type,info->lvds_bit);
	printf("\tOVI DB version[%07x]\n", tcon_ver);

	/* PreStep : Set base address for M14A0/A1 */
	if (get_chip_rev() < CHIP_LG1311_B0)
	{
		tcon_base_addr = 0xC0040000;
		led_spi_base_addr = 0xC0030000;
	}

	/* Step 0. TCON/EPI SW reset assert - workaround solution for boot sequence problem */
	if(info->output_type == DISP_120HZ_FULLHD_EPI || info->output_type == DISP_60HZ_FULLHD_EPI)
	{
		if (get_chip_rev() < CHIP_LG1311_B0)
		{
			REG_WRITE(0xC001B05C, 0x6000);
		}
		else
		{
			REG_WRITE(0xC001F804, 0x11000);
		}
	}
	else if(info->output_type == DISP_120HZ_FULLHD_LVDS4)
	{
		if (get_chip_rev() < CHIP_LG1311_B0)
		{
			REG_WRITE(0xC001B05C, 0x4000);
		}
		else
		{
			REG_WRITE(0xC001F804, 0x01000);
		}
	}

	/* Step 1. Set DE/FRC/DPPA */
	regs	= disp_default_fhd_b0;
	count = sizeof(disp_default_fhd_b0)/sizeof(OVI_REG_T);

	if (get_chip_rev() < CHIP_LG1311_B0)
	{
		if(info->output_type == DISP_60HZ_FULLHD_EPI)
		{
			regs	= disp_60hz_fhd_a0;
			count	= sizeof(disp_60hz_fhd_a0)/sizeof(OVI_REG_T);
		}
		else if(info->output_type != DISP_60HZ_FULLHD_LVDS2 && info->output_type != DISP_60HZ_FULLHD_HSLVDS1)
		{
			regs	= disp_120hz_fhd_a0;
			count	= sizeof(disp_120hz_fhd_a0)/sizeof(OVI_REG_T);
		}
		else
		{
			regs	= disp_60hz_2x_fhd_a0;
			count	= sizeof(disp_60hz_2x_fhd_a0)/sizeof(OVI_REG_T);
		}
	}

	// Spread Spectrum off
	if(info->output_type == DISP_60HZ_FULLHD_LVDS2 && info->lvds_type == LVDS_JEIDA)
	{
		// M1/DISP PLL spread spectrum off in CP BOX mode
		if (get_chip_rev() >= CHIP_LG1311_B0)
		{
			REG_WRITE(0xC0019008, 0x01000000);
			REG_WRITE(0xC001900C, 0x981D4000);
			REG_WRITE(0xC001FA34, 0xC0290000);
		}
	}
	else if (info->output_type == DISP_120HZ_FULLHD_VX1)
	{
		// DISP PLL spread spectrum off in Vx1 mode
		if (get_chip_rev() >= CHIP_LG1311_B0)
		{
			REG_WRITE(0xC0019008, 0x81170000);
			REG_WRITE(0xC001900C, 0x83244009);
			REG_WRITE(0xC001FA34, 0xC0290000);
		}
	}

	for(i=0; i<count; i++)
	{
		REG_WRITE(regs[i].addr, regs[i].value);
	}

	/* Step 2. Set OSD Init setting */
	OSD_Init();

	//bypass in UD panel
	if(info->output_type != DISP_60HZ_FULLHD_HSLVDS1)
	{
		/* Step 2-1. OSD Vertical reverse when nessessary */
		if(info->mirror)
		{
			val = REG_READ(OSD_ADDR_BASE+0x100);
			val |= 0x00000100;						/* osd_v_reverse_en [8:8] = 0x1 */
			REG_WRITE(OSD_ADDR_BASE+0x100,val);

			val = REG_READ(OSD_ADDR_BASE+0x140);
			val |= 0x00000100;						/* osd_v_reverse_en [8:8] = 0x1 */
			REG_WRITE(OSD_ADDR_BASE+0x140,val);

			val = REG_READ(OSD_ADDR_BASE+0x1c0);
			val |= 0x00000100;						/* osd_v_reverse_en [8:8] = 0x1 */
			REG_WRITE(OSD_ADDR_BASE+0x1c0,val);

			val = REG_READ(OSD_ADDR_BASE+0x0ac);
			val |= (1<<31);							/* reg_vsync_v_reverse [31:31] = 0x1 */
			REG_WRITE(OSD_ADDR_BASE+0x0ac,val);
		}

		/* Step 3. Set TCON SOE Timing */
		switch(info->panel_type)
		{
			case PANEL_TYPE_V12 :
				regs = (OVI_REG_T*) tcon_soe_v12;
				count = sizeof(tcon_soe_v12)/sizeof(OVI_REG_T);
				break;
			case PANEL_TYPE_V13 :
				switch(info->panel_inch)
				{
					case PANEL_INCH_42 :
						regs = (OVI_REG_T*)tcon_soe_v13_42;
						count = sizeof(tcon_soe_v13_42)/sizeof(OVI_REG_T);
						break;
					case PANEL_INCH_55 :
						regs = (OVI_REG_T*)tcon_soe_v13_55;
						count = sizeof(tcon_soe_v13_55)/sizeof(OVI_REG_T);
						break;
					case PANEL_INCH_47 :
					default :
						regs = (OVI_REG_T*)tcon_soe_v13_47;
						count = sizeof(tcon_soe_v13_47)/sizeof(OVI_REG_T);
						break;
				}
				break;
			case PANEL_TYPE_V14 :
			default :
				switch(info->panel_inch)
				{
					case PANEL_INCH_32 :
						regs = (OVI_REG_T*)tcon_soe_v14_32_6lane_120Hz;
						count = sizeof(tcon_soe_v14_32_6lane_120Hz)/sizeof(OVI_REG_T);
						break;
					case PANEL_INCH_47 :
						regs = (OVI_REG_T*)tcon_soe_v14_47_8lane_120Hz;
						count = sizeof(tcon_soe_v14_47_8lane_120Hz)/sizeof(OVI_REG_T);
						break;
					case PANEL_INCH_49 :
						regs = (OVI_REG_T*)tcon_soe_v14_49_8lane_120Hz;
						count = sizeof(tcon_soe_v14_49_8lane_120Hz)/sizeof(OVI_REG_T);
						break;
					case PANEL_INCH_50 :
						regs = (OVI_REG_T*)tcon_soe_v14_50_8lane_120Hz;
						count = sizeof(tcon_soe_v14_50_8lane_120Hz)/sizeof(OVI_REG_T);
						break;
					case PANEL_INCH_55 :
						if(info->output_type == DISP_60HZ_FULLHD_EPI)
						{
							regs = (OVI_REG_T*)tcon_soe_v14_55_8lane_60Hz;
							count = sizeof(tcon_soe_v14_55_8lane_60Hz)/sizeof(OVI_REG_T);
						}
						else
						{
							regs = (OVI_REG_T*)tcon_soe_v14_55_8lane_120Hz;
							count = sizeof(tcon_soe_v14_55_8lane_120Hz)/sizeof(OVI_REG_T);
						}
						break;
					case PANEL_INCH_42 :
					default :
						if(info->output_type == DISP_60HZ_FULLHD_EPI)
						{
							regs = (OVI_REG_T*)tcon_soe_v14_42_4lane_60Hz;
							count = sizeof(tcon_soe_v14_42_4lane_60Hz)/sizeof(OVI_REG_T);
						}
						else
						{
							regs = (OVI_REG_T*)tcon_soe_v14_42_8lane_120Hz;
							count = sizeof(tcon_soe_v14_42_8lane_120Hz)/sizeof(OVI_REG_T);
						}
						break;
				}
				break;
		}

		for(i=0; i<count; i++)
		{
			REG_WRITE(tcon_base_addr + regs[i].addr, regs[i].value);
		}

		// Set TCON_DITHER_CARRY For M14Ax
		if ((info->output_type == DISP_120HZ_FULLHD_EPI || info->output_type == DISP_60HZ_FULLHD_EPI) && (get_chip_rev() < CHIP_LG1311_B0))
		{
			REG_WRITE(tcon_base_addr + 0x154, 0x2);
		}

		// Temp for EVAL board
		if(info->board_type == DISP_BOARD_TYPE_EVAL && info->panel_type != PANEL_TYPE_V14 && (get_chip_rev() < CHIP_LG1311_B0))
		{
			REG_WRITE(tcon_base_addr + 0x288, 0x00120003);
			REG_WRITE(tcon_base_addr + 0x28C, 0x45000000);
		}
	}


	/* Step 4. Set RTOP -> CTOP for display */
	switch(info->output_type)
	{
		case DISP_120HZ_FULLHD_EPI:
			if(info->panel_type == PANEL_TYPE_V13 && (info->panel_inch == PANEL_INCH_42 || info->panel_inch == PANEL_INCH_55))
			{
				ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE3_1];
				if (get_chip_rev() < CHIP_LG1311_B0)
				{
					ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE3_1];
				}
			}
			else if(info->panel_type == PANEL_TYPE_V14 && info->panel_inch != PANEL_INCH_32)
			{
				ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE3_3];
				if (get_chip_rev() < CHIP_LG1311_B0)
				{
					ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE3_3];
				}
			}
			else
			{
				ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE3];
				if (get_chip_rev() < CHIP_LG1311_B0)
				{
					ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE3];
				}
			}
			break;
		case DISP_120HZ_FULLHD_LVDS4:
			ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE6];
			if (get_chip_rev() < CHIP_LG1311_B0)
			{
				ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE6];
			}
			break;
		case DISP_120HZ_FULLHD_VX1:
			ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE1];
			if (get_chip_rev() < CHIP_LG1311_B0)
			{
				ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE1];
			}
			break;
		case DISP_60HZ_FULLHD_LVDS2:
			ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE7];
			if (get_chip_rev() < CHIP_LG1311_B0)
			{
				ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE7];
			}
			break;
		case DISP_60HZ_FULLHD_HSLVDS1:
			ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE8];
			if (get_chip_rev() < CHIP_LG1311_B0)
			{
				ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE8];
			}
			break;
		case DISP_60HZ_FULLHD_EPI:
			if(info->panel_type == PANEL_TYPE_V14 && info->panel_inch == PANEL_INCH_55)
			{
				ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE3_4];
				if (get_chip_rev() < CHIP_LG1311_B0)
				{
					ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE3_4];
				}
			}
			else
			{
				ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE3_2];
				if (get_chip_rev() < CHIP_LG1311_B0)
				{
					ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE3_2];
				}
			}
			break;
		default:
			ctop_disp = &ctop_disp_list_b0[CTOP_DISP_CASE6];
			if (get_chip_rev() < CHIP_LG1311_B0)
			{
				ctop_disp = &ctop_disp_list_a0[CTOP_DISP_CASE6];
			}
			break;
	}

	for(i=0; i<ctop_disp->count; i++)
	{
		REG_WRITE(ctop_disp->regs[i].addr, ctop_disp->regs[i].value);
	}

	//bypass in UD panel
	//mirror -> PA168
	if(info->output_type != DISP_60HZ_FULLHD_HSLVDS1)
	{
		/* Step 5. Set  H Reverse mode when nessessary */
		if(info->mirror)
		{
			switch(info->output_type)
			{
				case DISP_120HZ_FULLHD_EPI:
				case DISP_120HZ_FULLHD_LVDS4:
				case DISP_120HZ_FULLHD_VX1:
				case DISP_60HZ_FULLHD_LVDS2:
				case DISP_60HZ_FULLHD_EPI:
					val = REG_READ(tcon_base_addr + 0x26C);
					val &= ~(0x1);
					REG_WRITE(tcon_base_addr + 0x26C, val);

					val = REG_READ(tcon_base_addr + 0x9000);
					val |= (0x0C000000);
					REG_WRITE(tcon_base_addr + 0x9000, val);
					break;
				default:
					break;
			}
		}
	}

	/* Step 6. Set LVDS mode when nessessary (default 8bit/VESA mode) */
	if (info->output_type == DISP_120HZ_FULLHD_LVDS4
		|| info->output_type == DISP_60HZ_FULLHD_LVDS2
		|| info->output_type == DISP_60HZ_FULLHD_HSLVDS1)
	{
		if(info->lvds_bit == LVDS_10BIT)
		{
			val = REG_READ(tcon_base_addr + 0x9018);
			val &= ~(0x1 << 14);
			REG_WRITE(tcon_base_addr + 0x9018, val);

			if (get_chip_rev() < CHIP_LG1311_B0)
			{
				REG_WRITE(tcon_base_addr + 0x154, 0x6);
			}
			else
			{
				REG_WRITE(tcon_base_addr + 0x154, 0x66);
			}

			if (info->output_type == DISP_60HZ_FULLHD_LVDS2)
			{
				ctop_disp->channel_power |= 0x41;
			}
			else if (info->output_type == DISP_120HZ_FULLHD_LVDS4)
			{
				ctop_disp->channel_power |= 0x41000;
			}
		}

		if(info->lvds_type == LVDS_JEIDA)
		{
			val = REG_READ(tcon_base_addr + 0x9018);
			val &= ~(0x1 << 15);
			REG_WRITE(tcon_base_addr + 0x9018, val);
		}
	}

	/* Step 7-0. TCON/EPI SW reset de-assert - workaround solution for boot sequence problem */
	if(info->output_type == DISP_120HZ_FULLHD_EPI || info->output_type == DISP_60HZ_FULLHD_EPI || info->output_type == DISP_120HZ_FULLHD_LVDS4)
	{
		if (get_chip_rev() < CHIP_LG1311_B0)
		{
			REG_WRITE(0xC001B05C, 0x0);
		}
		else
		{
			REG_WRITE(0xC001F804, 0x0);
		}
	}

	/* Step 7-1. Set Combo TX Power */
	msleep(1);	// After 1ms sec, set CTR102

	if (get_chip_rev() < CHIP_LG1311_B0)
	{
		REG_WRITE(0xC001B198, ctop_disp->combo_tx_power);
	}
	else
	{
		REG_WRITE(0xC001FA08, ctop_disp->combo_tx_power);
	}

	/* Step 7-1.5. Vx1 Link reset */
	if (info->output_type == DISP_120HZ_FULLHD_VX1)
	{
		usleep(100);

		if (get_chip_rev() < CHIP_LG1311_B0)
		{
			REG_WRITE(0xC001B194, 0x0C014FFF);
		}
		else
		{
			REG_WRITE(0xC001FA04, 0x0C014800);
		}
	}

	/* Step 7-2. Set Channel Power */
	usleep(100);

	if (get_chip_rev() < CHIP_LG1311_B0)
	{
		REG_WRITE(0xC001B1BC, ctop_disp->channel_power);
	}
	else
	{
		REG_WRITE(0xC001FA2C, ctop_disp->channel_power);
	}

	// Temp for EVAL board
	if(info->board_type == DISP_BOARD_TYPE_EVAL && info->output_type == DISP_120HZ_FULLHD_EPI && info->panel_type != PANEL_TYPE_V14
		&& (get_chip_rev() < CHIP_LG1311_B0))
	{
		REG_WRITE(0xC001B1BC, 0x0000E00E);
	}

	/* Step 8. Local Dimming SPI setting */
	if (get_chip_rev() < CHIP_LG1311_B0)
	{
		val = REG_READ(0xC001B180);
		if (info->led_control == LED_CONTROL_ENABLE) REG_WRITE(0xC001B180, (val | 1));
		else REG_WRITE(0xC001B180, (val & ~0x1));
	}
	else
	{
		val = REG_READ(0xC001FA3C);
		if (info->led_control == LED_CONTROL_ENABLE) REG_WRITE(0xC001FA3C, (val | 1));
		else REG_WRITE(0xC001FA3C, (val & ~0x1));
	}

	count = 0;
	switch(info->panel_backlight)
	{
		case PANEL_BACKLIGHT_EDGE_LED :

			switch(info->panel_led_bar_type)
			{
				case PANEL_LED_BAR_6 :
					if (info->panel_inch == PANEL_INCH_49
						|| info->panel_inch == PANEL_INCH_55
						|| info->panel_inch == PANEL_INCH_60)
					{
						regs = led_spi_edge_49_55_60_lgd;
						count = sizeof(led_spi_edge_49_55_60_lgd)/sizeof(OVI_REG_T);
					}
					break;
				default :
					break;
			}
			break;
		case PANEL_BACKLIGHT_DIRECT_M :

			switch(info->panel_led_bar_type)
			{
				case PANEL_LED_BAR_6 :
					if (info->panel_inch == PANEL_INCH_60)
					{
						regs = led_spi_dm6_60_lgd;
						count = sizeof(led_spi_dm6_60_lgd)/sizeof(OVI_REG_T);
					}
					break;
				case PANEL_LED_BAR_8 :
					if (info->panel_inch == PANEL_INCH_65)
					{
						regs = led_spi_dm8_65_lgd;
						count = sizeof(led_spi_dm8_65_lgd)/sizeof(OVI_REG_T);
					}
					break;
				case PANEL_LED_BAR_10 :
					if (info->panel_inch == PANEL_INCH_47)
					{
						regs = led_spi_dm10_47_lgd;
						count = sizeof(led_spi_dm10_47_lgd)/sizeof(OVI_REG_T);
					}
					break;
				case PANEL_LED_BAR_12 :
					if (info->panel_inch == PANEL_INCH_50
						|| info->panel_inch == PANEL_INCH_55
						|| info->panel_inch == PANEL_INCH_60)
					{
						regs = led_spi_dm12_50_55_60_lgd;
						count = sizeof(led_spi_dm12_50_55_60_lgd)/sizeof(OVI_REG_T);
					}
					break;
				case PANEL_LED_BAR_15 :
					if (info->panel_inch == PANEL_INCH_42)
					{
						regs = led_spi_dm15_42_lgd;
						count = sizeof(led_spi_dm15_42_lgd)/sizeof(OVI_REG_T);
					}
					break;
				case PANEL_LED_BAR_16 :
					if (info->panel_inch == PANEL_INCH_65)
					{
						regs = led_spi_dm16_65_lgd;
						count = sizeof(led_spi_dm16_65_lgd)/sizeof(OVI_REG_T);
					}
					else if (info->panel_inch == PANEL_INCH_70 && info->panel_maker == PANEL_MAKER_SHARP)
					{
						regs = led_spi_dm16_70_sharp;
						count = sizeof(led_spi_dm16_70_sharp)/sizeof(OVI_REG_T);
					}
					break;
				default :
					break;
			}
			break;
		case PANEL_BACKLIGHT_DIRECT_L :
			regs = led_spi_dl;
			count = sizeof(led_spi_dl)/sizeof(OVI_REG_T);
			break;
		default :
			break;
	}

	for(i=0; i<count; i++)
	{
		REG_WRITE(led_spi_base_addr + regs[i].addr, regs[i].value);
	}
}

/*========================================================================================
  Implementation Group ( OSD & GFX )
  ========================================================================================*/
typedef struct
{
	UINT32                      	// OSD[0:3]_HDR0
		osd_hdr_ypos           :12, //  0:11
							   : 4,						// 12:15 reserved
							   osd_hdr_xpos           :11, // 16:26
							   : 4, 						// 27:30 reserved
							   osd_hdr_color_key_en   : 1; //    31

	UINT32                     		// OSD[0:3]_HDR1
		osd_hdr_h_mem         :12, 	//  0:11
							  : 4, 						// 12:15 reserved
							  osd_hdr_w_mem         :12;	// 16:27

	UINT32                     		// OSD[0:3]_HDR2
		osd_hdr_h_out         :12,	//  0:11
							  : 4,						// 12:15 reserved
							  osd_hdr_w_out         :12,	// 16:27
							  : 3,						// 28:30 reserved
							  osd_hdr_pixel_order   : 1; //    31

	UINT32							// OSD[0:3]_HDR3
		osd_hdr_wpl			  :16,	//  0:15
							  osd_hdr_global_alpha  : 8,	// 16:23
							  osd_hdr_format        : 4,	// 24:27
							  osd_hdr_depth         : 3,	// 28:30
							  osd_hdr_global_alpha_en: 1; //    31

	UINT32                     		// OSD[0:3]_HDR4
		osd_hdr_color_key      ;    // 31: 0

	UINT32							// OSD[0:3]_HDR5
		osd_hdr_ptr_plte		;	// 31: 0

	UINT32							// OSD[0:3]_HDR6
		osd_hdr_ptr_bmp			;    // 31: 0
}
OSD_HDR_T;

/** GFX pixel format
 *	see GFX register manual :)
 */
typedef enum
{
	eINDEX_0	= 0,
	eINDEX_1	= 0x1,
	eINDEX_2	= 0x2,
	eINDEX_4	= 0x3,
	eINDEX_8	= 0x4,
	eALPHA_8	= 0x5,
	eYCbCr444	= 0x6,
	eCb8Cr8422	= 0x7,
	eCb8Cr8420	= 0x8,
	eYCbCr655	= 0x9,
	eAYCbCr2644 = 0xa,
	eAYCbCr4633 = 0xb,
	eAYCbCr6433 = 0xc,
	eCbCr420	= 0xd,
	eAYCbCr8888	= 0xe,
	eY0Cb0Y1Cr422 = 0xf,
	eRGB565 	= 0x19,		// OSD : 0x8  ??
	eARGB1555	= 0x1a,
	eARGB4444	= 0x1b,
	eARGB6343	= 0x1c,
	eCbCr422	= 0x1d,
	eARGB8888	= 0x1e,	// OSD : 0xe ??
}
GFX_PIXEL_FORMAT_T;

static unsigned int g_gfx_output_depth = 4;	// output depth default value
static unsigned int g_gfx_output_fmt;
static unsigned int g_gfx_input_fmt;

/** initialize OSD hardware with default configuration
 *
 *
 */
static void OSD_Init(void)
{
	//printf("OSD REG 0x%08x\n", OSD_ADDR_BASE);

	if(get_chip_rev() < CHIP_LG1311_B0)
	{
		set_reg( 0xc0035000, 0x0000, 0x08000000);		/* DPPA.PIC_INIT */
	}
	else
	{
		set_reg( 0xc0024000, 0x0000, 0x01000000);		/* DPPA.PIC_INIT */
	}

	set_reg( OSD_ADDR_BASE, 0x00c0, 0x10ff3210);		/* OSD_MIXER_CTRL_MUX0 - disable video mix for preventing garbage screen over boot logo.
														   OSD_MIXER_CTRL_MUX0.video_layer_off	 = 0x1,
														   OSD_MIXER_CTRL_MUX0.video_layer_alpha = 0xff
														   OSD_MIXER_CTRL_MUX0.layer_mux_0		 = 0x3 - VIDEO
														   OSD_MIXER_CTRL_MUX0.layer_mux_1		 = 0x2 - OSD2
														   OSD_MIXER_CTRL_MUX0.layer_mux_2		 = 0x1 - OSD1
														   OSD_MIXER_CTRL_MUX0.layer_mux_3		 = 0x0 - OSD0
														 */
	/* initialize OSD register to be default */
	set_reg( OSD_ADDR_BASE , 0x100, 0x00000010);		/* OSD0_CTRL_MAIN - note that OSD header is written to register not memory */
	set_reg( OSD_ADDR_BASE , 0x108, 0x00000444);		/* OSD0_CTRL_SWAP */

	/* intialize OSD0 header */
	set_reg( OSD_ADDR_BASE , 0x120, 0x00000000 );		/* OSD0_CTRL_HDR0 */
	set_reg( OSD_ADDR_BASE , 0x124, 0x07800438 );		/* OSD0_CTRL_HDR1 */
	set_reg( OSD_ADDR_BASE , 0x128, 0x07800438 );		/* OSD0_CTRL_HDR2 */
	set_reg( OSD_ADDR_BASE , 0x12c, 0xEEFF03C0 );		/* OSD0_CTRL_HDR3 */
	set_reg( OSD_ADDR_BASE , 0x130, 0x00000000 );		/* OSD0_CTRL_HDR4 */
	set_reg( OSD_ADDR_BASE , 0x134, 0x00000000 );		/* OSD0_CTRL_HDR5 */
	set_reg( OSD_ADDR_BASE , 0x138, OSD_FRAME_BUFFER );	/* OSD0_CTRL_HDR6 */

	set_reg( OSD_ADDR_BASE , 0x140, 0x00000010);		/* OSD1_CTRL_MAIN - osd off */
	set_reg( OSD_ADDR_BASE , 0x180, 0x00000010);		/* OSD2_CTRL_MAIN - osd off */
	set_reg( OSD_ADDR_BASE , 0x1c0, 0x00000010);		/* OSD3_CTRL_MAIN - osd off */
}

/** read OSD header
 *
 */
static void OSD_RdFLHdr ( OSD_HDR_T* pHdr )
{
	UINT32	data[7];

	data[0] = get_reg( OSD_ADDR_BASE , 0x120 );		/* OSD0_CTRL_HDR0 */
	data[1] = get_reg( OSD_ADDR_BASE , 0x124 );		/* OSD0_CTRL_HDR1 */
	data[2] = get_reg( OSD_ADDR_BASE , 0x128 );		/* OSD0_CTRL_HDR2 */
	data[3] = get_reg( OSD_ADDR_BASE , 0x12c );		/* OSD0_CTRL_HDR3 */
	data[4] = get_reg( OSD_ADDR_BASE , 0x130 );		/* OSD0_CTRL_HDR4 */
	data[5] = get_reg( OSD_ADDR_BASE , 0x134 );		/* OSD0_CTRL_HDR5 */
	data[6] = get_reg( OSD_ADDR_BASE , 0x138 );		/* OSD0_CTRL_HDR6 */

	memcpy( pHdr, data, sizeof(OSD_HDR_T));
}

/** wrie OSD header
 *
 */
static void OSD_WrFLHdr ( OSD_HDR_T* pHdr )
{
	UINT32	data[7];
	memcpy( data, pHdr, sizeof(OSD_HDR_T));

	set_reg( OSD_ADDR_BASE , 0x120, data[0] );		/* OSD0_CTRL_HDR0 */
	set_reg( OSD_ADDR_BASE , 0x124, data[1] );		/* OSD0_CTRL_HDR1 */
	set_reg( OSD_ADDR_BASE , 0x128, data[2] );		/* OSD0_CTRL_HDR2 */
	set_reg( OSD_ADDR_BASE , 0x12c, data[3] );		/* OSD0_CTRL_HDR3 */
	set_reg( OSD_ADDR_BASE , 0x130, data[4] );		/* OSD0_CTRL_HDR4 */
	set_reg( OSD_ADDR_BASE , 0x134, data[5] );		/* OSD0_CTRL_HDR5 */
	set_reg( OSD_ADDR_BASE , 0x138, data[6] );		/* OSD0_CTRL_HDR6 */
}

/** initialize OSD pixel format
 *
 */
static void OSD_SetCfg(UINT32 in_xsize, UINT32 in_ysize, UINT32 xoffset, UINT32 yoffset, UINT32 out_xsize, UINT32 out_ysize, UINT32 output_format)
{
	OSD_HDR_T	osd_hdr;
	UINT32 depth, format, divide, swap_ctrl;

	OSD_RdFLHdr ( &osd_hdr );

	osd_hdr.osd_hdr_xpos	= xoffset;
	osd_hdr.osd_hdr_ypos	= yoffset;
	osd_hdr.osd_hdr_w_mem	= in_xsize;
	osd_hdr.osd_hdr_h_mem	= in_ysize;
	osd_hdr.osd_hdr_w_out	= out_xsize;
	osd_hdr.osd_hdr_h_out	= out_ysize;

	switch(output_format)
	{
		case eRGB565:
			depth = 0x4; format = 0x8; divide = 2; swap_ctrl = 0x446;
			g_gfx_output_depth= 2;
			break;

		case eARGB8888:
		default:
			depth = 0x6; format = 0xe; divide = 1; swap_ctrl = 0x444;
			g_gfx_output_depth= 4;
			break;
	}

	osd_hdr.osd_hdr_wpl			= in_xsize>>divide;
	osd_hdr.osd_hdr_format		= format;
	osd_hdr.osd_hdr_depth		= depth;
	osd_hdr.osd_hdr_ptr_plte	= OSD_PLTE_BUFFER;
	osd_hdr.osd_hdr_ptr_bmp		= OSD_FRAME_BUFFER;
	OSD_WrFLHdr ( &osd_hdr );

	set_reg( OSD_ADDR_BASE, 0x108, swap_ctrl );	/* OSD0_CTRL_SWAP */
}

/** enable OSD0 layer
 *
 */
static void OSD_Enable(void)
{
	UINT32			val;
	UINT32	cnt;

	/* sw workaround to remove the possible garbage data in G_BUS memry FIFO */
#if 1
	/* set gMAU.flush on */
	val = get_reg(0xc00240fc, 0x0);
	val |= (1<<28);
	set_reg(0xc00240fc, 0x0, val);

	/* check gMAU.flush_done */
	for (cnt=0; cnt<100; cnt++)
	{
		val = get_reg(0xc00240fc, 0x0);
		if (val & 0x40000000 ) break;
	}
	printf("gMAU.flush done. cnt = %d\n", cnt);

	/* set gMAU.flush off */
	val = get_reg(0xc00240fc, 0x0);
	val &= ~(1<<28);
	set_reg(0xc00240fc, 0x0, val);
#endif

	val = get_reg(OSD_ADDR_BASE, 0x100 );	/* read OSD0_CTRL_MAIN */
	val |= 0x1;								/* set bit[0] */
	set_reg( OSD_ADDR_BASE, 0x100, val );	/* write OSD0_CTRL_MAIN */
}

static void GFX_SetInputFormat(UINT32 input_format)
{
	if(g_gfx_input_fmt == input_format)
	{
		return;
	}

	switch(g_gfx_output_fmt)
	{
		case eRGB565:
			{
				set_reg( GFX_ADDR_BASE , 0x128 , 0x00000019);		// format (RGB565)
				set_reg( GFX_ADDR_BASE , 0x134 , 0x00000008);		// W control : COC enable
				if(input_format == eRGB565)
				{
					set_reg( GFX_ADDR_BASE , 0x07c , 0x001b001b);	// R0 COC control
					set_reg( GFX_ADDR_BASE , 0x138 , 0x001b001b);	// W COC control
				}
				else if(input_format == eY0Cb0Y1Cr422)
				{
					set_reg( GFX_ADDR_BASE , 0x07c , 0x001b0039);	// R0 COC control
					set_reg( GFX_ADDR_BASE , 0x138 , 0x00000039);	// W COC control
				}
				else if(input_format == eARGB8888)
				{
					set_reg( GFX_ADDR_BASE , 0x07c , 0x001b001b);	// R0 COC control
					set_reg( GFX_ADDR_BASE , 0x138 , 0x001b001b);	// W COC control
				}
			}
			break;

		case eARGB8888:
		default:
			{
				set_reg( GFX_ADDR_BASE , 0x128 , 0x0000001e);		// format (ARGB8888)
				set_reg( GFX_ADDR_BASE , 0x134 , 0x00000000);		// W control : none

				if(input_format == eRGB565)
				{
					set_reg( GFX_ADDR_BASE , 0x07c , 0x001b001b);	// R0 COC control
					set_reg( GFX_ADDR_BASE , 0x138 , 0x001b001b);	// W COC control
				}
				else if(input_format == eY0Cb0Y1Cr422)
				{
					set_reg( GFX_ADDR_BASE , 0x07c , 0x00930039);	// R0 COC control
					set_reg( GFX_ADDR_BASE , 0x138 , 0x001b0039);	// W COC control
				}
				else if(input_format == eARGB8888)
				{
					set_reg( GFX_ADDR_BASE , 0x07c , 0x001b001b);	// R0 COC control
					set_reg( GFX_ADDR_BASE , 0x138 , 0x001b001b);	// W COC control
				}
			}
			break;
	}

	g_gfx_input_fmt = input_format;
}

static void GFX_init ( UINT32 input_format , UINT32 output_format )
{
	set_reg( GFX_ADDR_BASE , 0x180 , 0x00000001);    // scale bypass
	set_reg( GFX_ADDR_BASE , 0x02c , 0x00000000);    // cmd delay
	set_reg( GFX_ADDR_BASE , 0x05c , 0xffffffff);    // alpha

#if 0 // moved to GFX_Blit_function
	set_reg( GFX_ADDR_BASE , 0x06c , 0x00000080);    // color key low threshold
	set_reg( GFX_ADDR_BASE , 0x070 , 0xffffffff);    // color key high threshold
	set_reg( GFX_ADDR_BASE , 0x068 , 0x00000004);    // 4 R0 control
	set_reg( GFX_ADDR_BASE , 0x07c , 0x001b0039);    // R0 COC control
#endif
	g_gfx_output_fmt = output_format;
	GFX_SetInputFormat(input_format);

	// filter coef. only for YCbCr->ARGB
	set_reg( GFX_ADDR_BASE , 0x140 , 0x129FFC98);
	set_reg( GFX_ADDR_BASE , 0x144 , 0xF775129F);
	set_reg( GFX_ADDR_BASE , 0x148 , 0x21D70000);
	set_reg( GFX_ADDR_BASE , 0x14c , 0x129F0000);
	set_reg( GFX_ADDR_BASE , 0x150 , 0x1CB00000);
	set_reg( GFX_ADDR_BASE , 0x154 , 0xFFF0FF80);
	set_reg( GFX_ADDR_BASE , 0x158 , 0xFF800000);
	set_reg( GFX_ADDR_BASE , 0x15c , 0x00000000);
}

/** flush GFX command queue and wait completion
 *
 *
 */
static void GFX_Flush(void)
{
	uint32_t tick;

	tick = timer_tick();
	set_reg( GFX_ADDR_BASE , 0x030 , 0x00000001);   // batch run ( execute GFX cmd )

	while(1)
	{
		volatile unsigned int val;

		mdelay(1);
		val = get_reg(GFX_ADDR_BASE , 0x8);
		if( (val&0x3ff0000) >= 0x1000000 )
		{
			break;
		}

		set_reg( GFX_ADDR_BASE , 0x030 , 0x00000001);   // batch run
		val = 0;
	}
}

/** clear all screen with constant color
 *	color should have the type of ARGB8888
 *
 */
static void GFX_Clear( UINT32 width, UINT32 height, UINT32 color )
{
	UINT32 out_addr = OSD_FRAME_BUFFER;

#ifdef GFX_WA_FILL_ERROR
	set_reg( GFX_ADDR_BASE , 0x020 , 0x00000002);   // opmode, rop
	set_reg( GFX_ADDR_BASE , 0x100 , 0x00000005);	// out_sel
	set_reg( GFX_ADDR_BASE , 0x110 , 0x00000005);	// ROP_CTRL, src1
	set_reg( GFX_ADDR_BASE , 0x050 , out_addr);		// SRC0 base address
	set_reg( GFX_ADDR_BASE , 0x054 , width*g_gfx_output_depth);      // src0 stride
	set_reg( GFX_ADDR_BASE , 0x058 , 0x0000000F);   // pixel format, X
	set_reg( GFX_ADDR_BASE , 0x080 , out_addr);		// SRC1 base address
	set_reg( GFX_ADDR_BASE , 0x084 , width*g_gfx_output_depth);      // src1 stride
	set_reg( GFX_ADDR_BASE , 0x088 , 0x00000000);   // pixel format, 0
	set_reg( GFX_ADDR_BASE , 0x08C , color);      	// constant color for src1
	set_reg( GFX_ADDR_BASE , 0x134 , 0x00000000);
#else
	set_reg( GFX_ADDR_BASE , 0x020 , 0x00000000);   // opmode, write only
#endif
	set_reg( GFX_ADDR_BASE , 0x124 , width*g_gfx_output_depth);							// output stride
	set_reg( GFX_ADDR_BASE , 0x12c , (unsigned int)((height << 16) | (width << 0)));	// width, height size

	set_reg( GFX_ADDR_BASE , 0x120 , out_addr);     // output image addr
	set_reg( GFX_ADDR_BASE , 0x130 , color);        // constant color when write only
	set_reg( GFX_ADDR_BASE , 0x034 , 0x00000001);   // start

#ifdef GFX_WA_FILL_ERROR
	GFX_Flush();
	set_reg( GFX_ADDR_BASE , 0x020 , 0x00000000);   // opmode, rop
	set_reg( GFX_ADDR_BASE , 0x100 , 0x00000000);
	set_reg( GFX_ADDR_BASE , 0x134 , 0x00000008);
#endif
}

/** blit
 *
 *	@param in_xsize [IN] width of input buffer
 *	@param in_ysize [IN] height of input buffer
 *	@param xoffset  [IN] horizontal offset in destination frame
 *	@param yoffset  [IN] vertical offset in destination frame
 *	@param format 	[IN] GFX pixel format
 *	@param out_xsize[IN] used to calcuate output frame stride
 *	@param addr		[IN] physical address for input frame
 *
 */
static void GFX_Blit(UINT32 in_xsize, UINT32 in_ysize, UINT32 xoffset, UINT32 yoffset, UINT32 format, UINT32 out_xsize, unsigned long addr)
{
	unsigned int in_stride , out_stride;
	unsigned int out_addr;

	if(in_xsize > out_xsize)
	{
		printf("out xsize should be larger than in_xsize\n");
		return;
	}

	switch(format)
	{
		case eCbCr422:
		case eYCbCr655:
		case eAYCbCr2644:
		case eAYCbCr4633:
		case eAYCbCr6433:
		case eCbCr420:
		case eY0Cb0Y1Cr422:
			{
				set_reg( GFX_ADDR_BASE , 0x06c , 0x00000080);    // color key low threshold
				set_reg( GFX_ADDR_BASE , 0x070 , 0xffffffff);    // color key high threshold
				set_reg( GFX_ADDR_BASE , 0x068 , 0x00000004);    // 4 R0 control
				//set_reg( GFX_ADDR_BASE , 0x07c , 0x001b0039);    // R0 COC control
				in_stride = in_xsize*2;
			}
			break;

		case eRGB565:
			{
				set_reg( GFX_ADDR_BASE , 0x068 , 0x00000000);    // 4 R0 control
				//set_reg( GFX_ADDR_BASE , 0x07c , 0x001b001b);    // R0 COC control
				set_reg( GFX_ADDR_BASE , 0x134 , 0x00000000);
				in_stride = in_xsize*2;
			}
			break;

		case eAYCbCr8888:
		case eARGB8888:
			{
				in_stride = in_xsize*4;
				set_reg( GFX_ADDR_BASE , 0x068 , 0x00000000);    // 4 R0 control
				//set_reg( GFX_ADDR_BASE , 0x07c , 0x001b001b);    // R0 COC control
				set_reg( GFX_ADDR_BASE , 0x134 , 0x00000000);
			}
			break;

		default:
			{
				return;
			}
			break;
	}

	out_stride = out_xsize * g_gfx_output_depth;		// the reason why output image is RGB565

	set_reg( GFX_ADDR_BASE , 0x020 , 0x00000001);		// opmode, read 1 port
	set_reg( GFX_ADDR_BASE , 0x058 , format | 0x00);	// format
	set_reg( GFX_ADDR_BASE , 0x054 , in_stride);		// read port 0 stride

	set_reg( GFX_ADDR_BASE , 0x100 , 0x00000000);		// OUT_SEL
	set_reg( GFX_ADDR_BASE , 0x124 , out_stride);		// output stride
	set_reg( GFX_ADDR_BASE , 0x12c , (unsigned int)((in_ysize << 16) | (in_xsize << 0)));    // width, height size

	set_reg( GFX_ADDR_BASE , 0x050 , addr);				// read port 0 addr
	out_addr = OSD_FRAME_BUFFER + xoffset*g_gfx_output_depth + out_xsize*g_gfx_output_depth*yoffset;

	set_reg( GFX_ADDR_BASE , 0x120 , out_addr);			// output image addr
	set_reg( GFX_ADDR_BASE , 0x130 , 0xffffffff);		// alpha

	set_reg( GFX_ADDR_BASE , 0x034 , 0x00000001);		// cmd start
}

/*========================================================================================
  Implementation Group ( main ctrl )
  ========================================================================================*/
void display_default_info(struct disp_info* info)
{
	info->panel_type	= PANEL_TYPE_V14;
	info->panel_inch	= PANEL_INCH_47;
	info->panel_tool	= PANEL_TOOL_LB67;
	info->panel_maker	= PANEL_MAKER_LGD;
	info->panel_backlight	= PANEL_BACKLIGHT_DIRECT_M;
	info->panel_led_bar_type	= PANEL_LED_BAR_10;
	info->output_type	= DISP_120HZ_FULLHD_EPI;
	info->lvds_type		= LVDS_VESA;
	info->lvds_bit		= LVDS_10BIT;
	info->mirror		= 0;
	info->board_type	= DISP_BOARD_TYPE_SYSTEM;
	info->led_control	= LED_CONTROL_ENABLE;
}

void display_init(struct disp_info* info)
{
	UINT32 output_format;
	UINT32 input_format;

	//	input_format = eY0Cb0Y1Cr422;
	input_format = eARGB8888;
	output_format= eARGB8888;

	if(get_chip_rev() < CHIP_LG1311_B0)
	{
		OSD_ADDR_BASE = OSD_ADDR_BASE_Ax;
	}
	else
	{
		OSD_ADDR_BASE = OSD_ADDR_BASE_Bx;
	}
	DISP_Init	( info );
	//OSD_Init	( );
	OSD_SetCfg	( DISPLAY_WIDTH, DISPLAY_HEIGHT, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT, output_format );	// or eRGB565

	GFX_init	( input_format, output_format );		// should be same as GFX_Blit input argument
	OSD_Enable	( );
}

int osd_blit(int x, int y, int w, int h, const void *pixmap, color_fmt_t format)
{
	if(format != COLOR_FMT_RGB8888)
	{
		printf("Not implemented color format\n");
		return -1;
	}
	if(x == -1) x = (DISPLAY_WIDTH - w) >> 1;
	if(y == -1) y = (DISPLAY_HEIGHT - h) >> 1;

	if((x+w) > DISPLAY_WIDTH || (y+h) > DISPLAY_HEIGHT)
	{
		printf("Over max range\n");
		return -1;
	}
#if USE_DATA_CACHE
	dcache_clean_range((unsigned long)pixmap, w*h*4);
#endif

	GFX_SetInputFormat(eARGB8888);
	GFX_Blit(w, h, x, y, eARGB8888, DISPLAY_WIDTH , (unsigned long)pixmap);
	GFX_Flush();

	return 0;
}

void osd_fill(int x, int y, int w, int h, uint32_t color)
{
	GFX_Clear(w, h, 0xff000000|color ); /* make color to be opaque !! */
}

void osd_sync(void)
{
	GFX_Flush();
}

#endif
