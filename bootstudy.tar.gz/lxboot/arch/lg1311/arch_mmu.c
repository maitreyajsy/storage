/*************************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 **************************************************************************************************/


/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	ks.hyun@lge.com 	release initial codes for lxboot in arch/lg1152 folder.
|	? 	? 	2011	yw.kim@lge.com		copy this file from arch/lg1152 to arch/lg1154 for evaluation.
|	Feb	26	2012	yw.kim@lge.com		add mmu_chk_l1_entry() and mmu_insert_l1_entry.
|
|============================================================================================================*/




#include <types.h>
#include <string.h>
#include <arch/cpu.h>
#include <mmu.h>

/*tlb(translation lookaside buffer)*/
void v7_flush_tlb_range(uint32_t, uint32_t);


#if USE_DATA_CACHE

#ifndef MMU_TLB_BASE
#error "Have to define MMU_TLB_BASE"
#endif

#ifndef MEM_MMU_TABLE
#error "Have to define MEM_MMU_TABLE"
#endif

static int mmu_table_inited = 0;
static mem_map_t map_table[] = MEM_MMU_TABLE;

void mmu_set_table(void)
{
	int 		i, j;
	uint32_t	*tlb = (uint32_t *)MMU_TLB_BASE;

	if(mmu_table_inited) return;

	memset(tlb, 0, MMU_TLB_SIZE);
	for(i=0; i<(sizeof(map_table)/sizeof(map_table[0])); i++)
	{
		unsigned long index, size;
		unsigned long section;

		index	= (map_table[i].virt) >> MMU_SECTION_ADDR_SHIFT;
		size 	= (map_table[i].size) >> MMU_SECTION_ADDR_SHIFT;
		section	= (map_table[i].phys) >> MMU_SECTION_ADDR_SHIFT;

	#if 0
		printf("Map from %08x - %08x (%-6s)\n",
			index<<20, size<<20,
			(map_table[i].flag & MMU_ATTR_DATA_CACHE)?"CACHED":
			(map_table[i].flag & MMU_ATTR_DATA_UNCACHE)?"UNCACHED":
			(map_table[i].flag & MMU_ATTR_DEVICE)?"DEVICE": "NONE" );
	#endif

		for(j=0; j<size; j++, index++, section++)
		{
			/*
			 * Level1 Section PTE Descriptor
			 *        +------------------------ 31..20  SB : section Base Address           |-> 11b => Read/Write access
			 *        |
			 *		  |		+-------------------   [19]  NS : Non-Secure bit
			 *		  |		|+------------------   [18]  Bit[18] : 0:Descriptor is for a Section., 1:Super section
			 *		  |		||+-----------------   [17]  nG : not Global
			 *		  |		|||+----------------   [16]  S : Sharable bit
			 *		  |		||||+---------------   [15]	 AP[2]:
			 *		  |		|||||  +----------- [14:12]  TEX: Memory Region Attribute
			 *        |     |||||  | +--------- [11:10]  AP[1:0] : Access Protection -------------|-> 00b => No access
			 *        |     |||||  | |  +------   [8:5]  DS : Domain Selector                |-> 10b => Read Only
			 *        |     |||||  | |  |  +---     [4]  XN : Execute-never bit
			 *        |     |||||  | |  |  |+--     [3]  C  : Cache Enable --------------------> 0/1 D-Cache Enable/Disable
			 *        |     |||||  | |  |  ||+-     [2]  B  : Write Buffer Enable -------------> 0/1 Buffer bit
			 *  [^^^^^^^^^^]^^^^^^^^^^0[^^]1||
			 *  10987654321098765432109876543210
			 *   3         2         1         0
			 */
			tlb[index] = (section << MMU_SECTION_ADDR_SHIFT) | IS_A_SECTION;

			switch(map_table[i].flag&MMU_ATTR_MASK)
			{
		#if USE_SMP
				case MMU_ATTR_DATA_CACHE:	tlb[index] |= S_SHARED_MEMORY; break;
				case MMU_ATTR_DATA_UNCACHE: tlb[index] |= S_SHARED_SO_MEMORY; break;
				case MMU_ATTR_DEVICE:		tlb[index] |= S_SHARED_DEVICE; break;
		#else
				case MMU_ATTR_DATA_CACHE:	tlb[index] |= S_MEMORY; break;
				case MMU_ATTR_DATA_UNCACHE:	tlb[index] |= S_SO_MEMORY; break;
				case MMU_ATTR_DEVICE:		tlb[index] |= S_DEVICE; break;
		#endif
			}
		}
	}
	mmu_table_inited = 1;
}

void mmu_init(void)
{
	uint32_t	value;
	uint32_t	*tlb = (uint32_t *)MMU_TLB_BASE;

	inv_dcache();	// invalidate data cache

	mmu_set_table();

	asm volatile ("mcr	p15, 0, %0, c2, c0, 0" :: "r" (tlb));
	asm volatile ("mcr	p15, 0, %0, c3, c0, 0" :: "r" (0xFFFFFFFF));	// Set full access for all domains
	asm volatile ("mcr	p15, 0, %0, c8, c7, 0" :: "r" (0));				// Invalidate TLBs


	/*
	 * CP15 R1 Register
	 *    +----------------------------------     29 [Force AP] : Force AP funcationality in the MMU
	 *    |+---------------------------------     28 [TEX Remap] : TEX remap functionality in the MMU
	 *    ||+--------------------------------     27 [NMFI] : FIQs behave as NMFIs if enabled
	 *    ||| +------------------------------     25 [EE] : CPSR E bit on takeing an exception
	 *    ||| | +----------------------------     23 [XP] : Configure extended page table configuration
	 *    ||| | |       +--------------------	  15 [L4] : LDR uses Arm Architecture 4
	 *    ||| | |       | +------------------	  13 [V ] : Location of Exception Vector
	 *    ||| | |       | |+-----------------	  12 [I ] : Enable Instruction Cache
	 *    ||| | |       | ||+----------------	  11 [Z ] : Enable Branch Predection
	 *    ||| | |       | ||| +--------------	   9 [R ] : Enable Rom-Protection
	 *    ||| | |       | ||| |+-------------	   8 [S ] : Enable System Protection
	 *    ||| | |       | ||| ||     +-------	   2 [C ] : Data Cache Enable
	 *    ||| | |       | ||| ||     |+------	   1 [A ] : Enable Address Alignment fault.
	 *    ||| |	|       | ||| ||     ||+-----	   0 [M ] : Enable MMU
	 *    ||| | |       | ||| ||     |||
	 *  \\^^^\^\^^000101^/^^^\^^\////^^^
	 *  10987654321098765432109876543210
	 *  3		   2		 1		   0
	 *
	 * \ => SBZ, / => SBO
	 */
	value = read_cp15_sctlr();
	value |=  CP15_SCTLR_M_ENABLE;		// M bit (MMU enabled)
	value &= ~CP15_SCTLR_A_ENABLE;		// A bit (Strict aligment checking)
	value |=  CP15_SCTLR_C_ENABLE;		// C bit (Data cache)
	value |=  CP15_SCTLR_Z_ENABLE;		// Z bit (Branch prediction)
	value |=  CP15_SCTLR_I_ENABLE;		// I bit (Instruction cache)
	write_cp15_sctlr(value);
	asm("nop");asm("nop");asm("nop");asm("nop");
}


void mmu_disable(void)
{
	unsigned long reg;

	asm ("mcr p15, 0, %0, c7, c5, 0": :"r"(0)); 	// invalidate I cache
//	flush_dcache();

	reg = read_cp15_sctlr();
	reg &= ~(CP15_SCTLR_M_ENABLE | CP15_SCTLR_C_ENABLE);	//turn MMU and cache off
	write_cp15_sctlr(reg);

	dsb();
	isb();
}

/*just check if load_addr exists in mmu master section table*/
uint32_t mmu_chk_l1_entry(uint32_t addr)
{
	uint32_t section_addr, ttb_base;

	ttb_base = read_cp15_ttbr0();
	section_addr = *((uint32_t*)(ttb_base+(addr >> MMU_SECTION_ADDR_SHIFT)*MMU_ENTRY_SIZE))&MMU_SECTION_ADDR_MASK;

	printf("section_addr[0x%x], ttb_base[0x%x]\n", section_addr, ttb_base);

	return (section_addr&(addr&MMU_SECTION_ADDR_MASK));
}

void mmu_insert_l1_entry(uint32_t addr, uint32_t size, uint32_t attr)
{
	uint32_t entry, entry_addr, ttb_base;


	entry = addr & MMU_SECTION_ADDR_MASK;

	switch(attr&MMU_ATTR_MASK)
	{
		case MMU_ATTR_DATA_CACHE:	entry |= S_MEMORY; break;
		case MMU_ATTR_DATA_UNCACHE:	entry |= S_SO_MEMORY; break;
		case MMU_ATTR_DEVICE:		entry |= S_DEVICE; break;
	}

	/*which is ttb used?*/
	 if((read_cp15_ttbcr()&0x3)==0)
	 {
	 	ttb_base = read_cp15_ttbr0();

		entry_addr = (ttb_base+(addr >> MMU_SECTION_ADDR_SHIFT)*MMU_ENTRY_SIZE);

		printf("entry_addr[0x%x]\n", entry_addr);

		*((volatile uint32_t*)entry_addr) = entry;

		dcache_clean_range(entry_addr, MMU_ENTRY_SIZE);

		dsb();

		v7_flush_tlb_range(addr,addr+size);
	 }
	 else
	 {
		printf("Please check, ttbcr[0x%x], ttbr0[0x%x], ttbr1[0x%x]\n", read_cp15_ttbcr(), read_cp15_ttbr0(),read_cp15_ttbr1());
	 }

}
#endif

uint8_t mmu_status(void)
{
    uint32_t value = 0;

    value = read_cp15_sctlr();

    if(value & CP15_SCTLR_M_ENABLE)
        return TRUE;
    else
        return FALSE;

    //TRUE : mmu on
    //FALSE : mmu off
}

unsigned long mmu_virt_to_phys(unsigned long vaddr)
{
	int idx;
	unsigned long section;
	unsigned long paddr;
	unsigned long *tlb = (unsigned long *)MMU_TLB_BASE;

	idx = vaddr >> MMU_SECTION_ADDR_SHIFT;
	section = tlb[idx];
	if(!(section&IS_A_SECTION))
	{
		printf("Not exist address(0x%08x) or not section in MMU\n", vaddr);
		return 0;
	}

	paddr = (section&MMU_SECTION_ADDR_MASK) + (vaddr&(MMU_SECTION_SIZE-1));

	return paddr;
}


//EOF
