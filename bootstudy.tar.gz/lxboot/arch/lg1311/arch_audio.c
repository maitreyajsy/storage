/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <timer.h>
#include <i2c.h>
#include <thread.h>
#include <audio.h>

#if defined(CONFIG_AUDIO) || USE_AUDIO
#include <arch/se_codec_m14.h>

#ifndef LG1311_ADEC_BASE
#error "Have to define the LG1311_ADEC_BASE address !!!"
#endif

//#define ADEC_DEBUG
//#define ENABLE_CTOP_REG_DEBUG
//#define ENABLE_ADEC_REG_DEBUG

#ifdef ADEC_DEBUG
#define ADEC_PRINT							printf
#else
#define ADEC_PRINT(format, args...)			do{} while(0)
#endif


/*
*******************************************************************************
*                  GLOBAL  MACROS
*******************************************************************************
*/

/* define delay value */
#define AUD_RESET_DELAY_5US			5		//5us

/* define ADEC register  address */
#define ADEC_AUD_SWRESET			(LG1311_ADEC_BASE + 0x238)
#define ADEC_AUD_DSP1OFFSET5		(LG1311_ADEC_BASE + 0x2B4)
#define ADEC_AUD_DSP1OFFSET6		(LG1311_ADEC_BASE + 0x2B8)
#define ADEC_AUD_CHIP_VERSION		(LG1311_ADEC_BASE + 0x6E8)

/* define DDR  memory address */
#ifndef AUDIO_DSP_BASE
#error "Have to define AUDIO_DSP_BASE !!!"
#endif

#define ADEC_DSP1_FW_ADDR			(AUDIO_DSP_BASE)
#define ADEC_DSP1_RUNNING_ADDR		(AUDIO_DSP_BASE + 0x10000)
#define ADEC_CHIP_VER_VALUE			(0x14B0)

/*
*******************************************************************************
*                  STATIC FUNCTIONS
*******************************************************************************
*/
static void ADEC_LoadDSP1Codec(void)
{
	uint32_t	ui32CodecSize = 0;
	uint32_t	*pui32Codec = NULL;
	uint32_t	*pui32CodecAddr = (uint32_t *)ADEC_DSP1_FW_ADDR;

#ifdef ENABLE_ADEC_REG_DEBUG
	uint32_t	addr, data;
#endif

	 ADEC_PRINT("ADEC_SetDTODClock start!!!\n");

	 //Set audio SPDIF clock using DTO-D clock
	 REG_WRITE(0xC001B004, 0x00000004);		//dto x1   -> audclk_out
	 REG_WRITE(0xC001B00C, 0x00002424);		//dto x1/2 -> fs20clk, fs21clk
	 REG_WRITE(0xC001B01C, 0x136B06E7);		//dto add_value
	 REG_WRITE(0xC001B020, 0x00000000);		//dto err_value
	 REG_WRITE(0xC001B018, 0x00000001);		//dto dto enable : if clk not out, check if 0xC001B000 bit[16] = 0
	 udelay(AUD_RESET_DELAY_5US);

#ifdef ENABLE_CTOP_REG_DEBUG
	 ADEC_PRINT("addr = 0xC001B004, data = 0x%X(0x4)\n", REG_READ(0xC001B004));
	 ADEC_PRINT("addr = 0xC001B00C, data = 0x%X(0x2424)\n", REG_READ(0xC001B00C));
	 ADEC_PRINT("addr = 0xC001B01C, data = 0x%X(0x136B06E7)\n", REG_READ(0xC001B01C));
	 ADEC_PRINT("addr = 0xC001B020, data = 0x%X(0x0)\n", REG_READ(0xC001B020));
	 ADEC_PRINT("addr = 0xC001B018, data = 0x%X(0x1)\n", REG_READ(0xC001B018));
#endif

	 ADEC_PRINT("ADEC_LoadDSP1Codec start!!!\n");

	//Reset Low : APB, SRC, ADEC DSP and AAD etc...
	REG_WRITE(ADEC_AUD_SWRESET, 0x0000);
	udelay(AUD_RESET_DELAY_5US);

#ifdef ENABLE_ADEC_REG_DEBUG
	addr = ADEC_AUD_SWRESET;
	data = REG_READ(addr);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x0023)\n", addr, data);
#endif

	//Reset High : APB and SPDIF etc...
	//Reset Low : ADEC DSP1
	REG_WRITE(ADEC_AUD_SWRESET, 0x0023);
	udelay(AUD_RESET_DELAY_5US);

	//set chip version
	REG_WRITE(ADEC_AUD_CHIP_VERSION, ADEC_CHIP_VER_VALUE);

	//set address for DSP1 fw and running memory
	REG_WRITE(ADEC_AUD_DSP1OFFSET5, ADEC_DSP1_FW_ADDR);
	REG_WRITE(ADEC_AUD_DSP1OFFSET6, ADEC_DSP1_RUNNING_ADDR);

#ifdef ENABLE_ADEC_REG_DEBUG
	addr = ADEC_AUD_SWRESET;
	data = REG_READ(addr);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x23)\n", addr, data);

	addr = ADEC_AUD_CHIP_VERSION;
	data = REG_READ(addr);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x%X)\n", addr, data, ADEC_CHIP_VER_VALUE);

	addr = ADEC_AUD_DSP1OFFSET5;
	data = REG_READ(addr);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x%X)\n", addr, data, ADEC_DSP1_FW_ADDR);

	addr = ADEC_AUD_DSP1OFFSET6;
	data = REG_READ(addr);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x%X)\n", addr, data, ADEC_DSP1_RUNNING_ADDR);
#endif

	//Copy LGSE codec for DSP1
	ui32CodecSize = sizeof(se_codec_m14);
	pui32Codec	  = (UINT32 *)se_codec_m14;

	//Copy codec fw from memory to dsp1 memory
	memcpy(pui32CodecAddr, pui32Codec, ui32CodecSize);

#ifdef ENABLE_ADEC_REG_DEBUG
	ADEC_PRINT ("ADEC LoadCodec : Done!!!\n" );
#endif

	//Set DSP1 swreset register
	REG_WRITE(ADEC_AUD_SWRESET, 0x2823);

#ifdef ENABLE_ADEC_REG_DEBUG
	addr = ADEC_AUD_SWRESET;
	data = REG_READ(addr);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x2823)\n", addr, data);
#endif

	ADEC_PRINT("ADEC_LoadDSP1Codec end!!!\n");
	return;
}

int  arch_audio_init(void)
{
#ifdef ADEC_DEBUG
	ADEC_PRINT("Audio_init start!!!\n");
#endif

	//check a chip revision.
	if (get_chip_rev() >= CHIP_LG1311_B0)
	{
		//Initializes the ADEC registers and load firmware.
		(void)ADEC_LoadDSP1Codec();

		printf("Audio_init!!!\n");
	}
	else
	{
		printf("Audio_init : Not Supported(chip = %d)\n", get_chip_rev());
	}

	return 0;
}
///////////////////////////////

#endif
