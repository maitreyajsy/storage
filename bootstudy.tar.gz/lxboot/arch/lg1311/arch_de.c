/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
/*----------------------------------------------------------------------------------------
     Control Constants
----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
     File Inclusions
----------------------------------------------------------------------------------------*/
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <thread.h>
#include <command.h>
#include <arch/de.h>
#include <arch/ctop_regs.h>
#include <arch/a0/de_ipc_reg_m14a0.h>
#include <arch/a0/de_fw_pak_m14a0.h>

/*----------------------------------------------------------------------------------------
    Constant Definitions
----------------------------------------------------------------------------------------*/
#ifndef DE_BASE
#error "Have to define the de base address !!!"
#endif

#define DE_DEBUG 1

#if DE_DEBUG > 1
#define DE_PRINT							printf
#else
#define DE_PRINT(format, args...)			do{}while(0)
#endif

#if DE_DEBUG > 0
#define DE_PRINT_ERROR						printf
#else
#define DE_PRINT_ERROR(format, args...)	do{}while(0)
#endif

#define RET_OK     0
#define RET_ERROR -1



#define USE_VIDEO_MCU_ROM_BASE_ADDR     0x50000000
#define DE_IPC_REG_M14_OFFSET           0x4e00
#define DE_IPC_FRM_M14_OFFSET           0x4c00
#define DE_IPC_REG_M14_BASE             (DE_BASE + DE_IPC_REG_M14_OFFSET) // 0xC0013000 + offset
#define DTVSOC_IPC_TOTAL_SIZE           0x100
#define DTVSOC_IPC_FROM_CPU_SIZE        (DTVSOC_IPC_TOTAL_SIZE/2)
#define DTVSOC_IPC_FROM_MCU_SIZE        (DTVSOC_IPC_TOTAL_SIZE/2)
#define DE_IPC_FRM_M14_BASE             (DE_BASE + DE_IPC_FRM_M14_OFFSET)
#define DTVSOC_IPC_FROM_CPU_M14_BASE    DE_IPC_FRM_M14_BASE
#define DTVSOC_IPC_FROM_MCU_M14_BASE    (DTVSOC_IPC_FROM_CPU_M14_BASE + DTVSOC_IPC_FROM_CPU_SIZE)
#define VIDEO_IPC_INTERRUPT_ARM_BIT     29
#define VIDEO_DMA_INTERRUPT_ARM_BIT     28

/*----------------------------------------------------------------------------------------
    Macro Definitions
----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
     Type Definitions
----------------------------------------------------------------------------------------*/
typedef struct {
	int  inx;
	int  size;
	char *pData;
} DE_FW_DWLD_T;

typedef struct {
	int (*download)(DE_FW_DWLD_T *pstParams, u32 fwBaseAddr);
	int (*send)(u32 ipcCmd, void *pMsg, u32 msgCnt);
	int (*get)(void *pMsg, u32 msgCnt);
} de_func_t;

/*----------------------------------------------------------------------------------------
     External Function Prototype Declarations
----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
     External Variables
----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
     global Variables
----------------------------------------------------------------------------------------*/
volatile DE_IPC_REG_M14A_T *gpIPC_REG = (DE_IPC_REG_M14A0_T*)DE_IPC_REG_M14_BASE;
u8 *pSendBufferToMCU = (u8*)DTVSOC_IPC_FROM_CPU_M14_BASE;
u8 *pSendBufferToCPU = (u8*)DTVSOC_IPC_FROM_MCU_M14_BASE;

DE_FW_DWLD_T sDeFirmwareFromHeader_M14A0[] = {
 { 3, sizeof(gDeFirmwareInDDR_PAK_M14A0),     (char *)gDeFirmwareInDDR_PAK_M14A0  }
};

/*----------------------------------------------------------------------------------------
     Static Function Prototypes Declarations
----------------------------------------------------------------------------------------*/
static int    _download_fw(void);
static int    _check_ipc_ready(int timeout);
static int    _put_data(u32 ipcCmd,                \
						void *pMsg,                   \
						u32 msgCnt,                \
						VIDEO_IPC_DATA_TYPE_T ipcType);
static int    _get_data(u8 *pBuffer, u32 size);
static int    _ipc_set_data(u32 ipcCmd, void *pMsg, u32 msgCnt);
static int    _ipc_get_data(void *pMsg, u32 msgCnt);
static int    _mcu_put_data(int argc, char **argv);
static int    _mcu_cmd_params(int argc, char* cmd, char* param0, char* param1,          \
							char* param2, char* param3, char* param4, char* param5,     \
							char* param6, char* param7);
static int    _mcu_execute(int argc, char **argv);

/*----------------------------------------------------------------------------------------
     Static Variables
----------------------------------------------------------------------------------------*/

/*========================================================================================
     Implementation Group
========================================================================================*/


int de_init(void)
{
	int ret = RET_OK;

	ret = _download_fw();
	if(ret)
	{
		DE_PRINT_ERROR("fail to download de-firmware\n");
		return ret;
	}

	de_init_firmware(LX_PANEL_TYPE_1920);

#if 0	
	LX_DE_FIRMWARE_INFO_T fw_info;
	de_get_version(&fw_info);
	DE_PRINT("fw_version[ %d ] yyyy/mm/dd = %04d/%02d/%02d\n", \
			fw_info.version, fw_info.date.year, fw_info.date.month, fw_info.date.day);
#endif

	de_set_vcr(TRUE);

#if 0 // TEST !!!    -  change uart0 source from de
	msleep(500);
	{
		CTR58 ctr58;
		ctr58 = ctop_regs->ctr58;
		ctr58.uart0_sel = 0x1;
		ctr58.uart1_sel = 0x1;
		ctop_regs->ctr58 = ctr58;
	}
	_mcu_cmd_params(1, "MV_PrintCurrentFrame", 0,0,0,0,0,0,0,0);
	msleep(500);
	_mcu_cmd_params(2, "5573", "1",0,0,0,0,0,0,0);
#endif

	DE_PRINT("de_init\n");

	return ret;
}

int de_init_firmware(LX_DE_PANEL_TYPE_T panel_type)
{
	LX_DE_PANEL_TYPE_T *pstParams = (LX_DE_PANEL_TYPE_T*)&panel_type;
	DE_IPC_CMD_T ipcCmd = DE_IPC_DE_INIT;
	
	return _ipc_set_data(ipcCmd, pstParams, sizeof(LX_DE_PANEL_TYPE_T));
}

int de_get_version(LX_DE_FIRMWARE_INFO_T *version)
{
	int ret = RET_OK;
	LX_DE_FIRMWARE_INFO_T *pstParams = (LX_DE_FIRMWARE_INFO_T*)version;
	DE_IPC_CMD_T ipcCmd = DE_IPC_GET_FIRMWARE_INFO;
	
	ret = _ipc_set_data(ipcCmd, pstParams, sizeof(LX_DE_FIRMWARE_INFO_T));
	ret = _ipc_get_data(pstParams, sizeof(LX_DE_FIRMWARE_INFO_T));

	return ret;
}

int de_set_vcr(int enb)
{
	return _mcu_cmd_params(4, "MVVCR"/*5727*/, (enb)?"1":"0", "1", "6",0,0,0,0,0);
}


/* start of m14 */
static int __check_ipc_ready_M14(void)
{
	M14A0_INT_INTR_ENABLE_T int_intr_enable;
	int_intr_enable = gpIPC_REG->int_intr_enable;
	return (int_intr_enable.ipc_interrupt_enable_mcu >> VIDEO_IPC_INTERRUPT_ARM_BIT);
}

static int __wait_interrupt_m14(u32 field, int timeout)
{
	int ret = RET_OK;
	M14A0_EXT_INTR_STATUS_T ext_intr_status; 
	M14A0_EXT_INTR_CLEAR_T  ext_intr_clear;
	u32 intr_status = 0;
	
	do {
		ext_intr_status = gpIPC_REG->ext_intr_status;
		ext_intr_clear  = gpIPC_REG->ext_intr_clear;
		intr_status = ext_intr_status.ipc_interrupt_status_arm;

		if(field == VIDEO_IPC_INTERRUPT_ARM_BIT)
		{
			if(intr_status & (1 << VIDEO_IPC_INTERRUPT_ARM_BIT))
			{
				ext_intr_clear.ipc_interrupt_clear_arm |= (1 << VIDEO_IPC_INTERRUPT_ARM_BIT);
				gpIPC_REG->ext_intr_clear = ext_intr_clear;
				break;
			}
		}
		if(field == VIDEO_DMA_INTERRUPT_ARM_BIT)
		{
			if(intr_status & (1 << VIDEO_DMA_INTERRUPT_ARM_BIT))
			{
				ext_intr_clear.ipc_interrupt_clear_arm |= (1 << VIDEO_DMA_INTERRUPT_ARM_BIT);
				gpIPC_REG->ext_intr_clear = ext_intr_clear;
				break;
			}
		}
		msleep(1);
	} while(--timeout);
	if(!timeout)
	{
		DE_PRINT_ERROR("__wait_interrupt_m14 : time-out   bit[%d]\n", field);
		ret = RET_ERROR;
	}
	//DE_PRINT("ack[%d] from mcu ! [%d]\n", field, timeout);
	return ret;
}

static int __send_interrupt_m14(u32 field)
{
	int ret = RET_OK;
	M14A0_INT_INTR_EVENT_T int_intr_event;
	
	int_intr_event = gpIPC_REG->int_intr_event;
	int_intr_event.ipc_interrupt_event_mcu |= (1 << field);
	gpIPC_REG->int_intr_event = int_intr_event;

	return ret;
}

static int __download_fw_m14(DE_FW_DWLD_T *pstParams, u32 fwBaseAddr)
{
	int ret = RET_OK;
	CTR25 ctr25;
	M14A0_SET_CTRL0_T set_ctrl0;
	M14A0_ATLAS_PORT_SEL_T atlas_port_sel;
	M14A0_SROM_BOOT_OFFSET_T srom_boot_offset;

	do {
		if(!pstParams) break;
		if (!pstParams->size) break;
		if (!pstParams->pData) break;

		set_ctrl0 = gpIPC_REG->set_ctrl0;
		if(!set_ctrl0.run_stall) break;
	
		ctr25 = ctop_regs->ctr25;
		ctr25.swrst_dee_de_dp = 1;
		ctop_regs->ctr25 = ctr25;
		ctr25.swrst_dee_de_dp = 0;
		ctop_regs->ctr25 = ctr25;
		
		set_ctrl0.run_stall = 1;
		set_ctrl0.sw_reset  = 0;
		gpIPC_REG->set_ctrl0 = set_ctrl0;

		atlas_port_sel = gpIPC_REG->atlas_port_sel;
		atlas_port_sel.sram2_atlas_port_sel = 0x5;
		atlas_port_sel.sram1_atlas_port_sel = 0x4;
		atlas_port_sel.sram0_atlas_port_sel = 0x3;
		atlas_port_sel.edma_atlas_port_sel  = 0x1;
		gpIPC_REG->atlas_port_sel = atlas_port_sel;
		memcpy((u8*)fwBaseAddr, pstParams->pData, pstParams->size);
		switch (pstParams->inx) {
			case 1 :
			case 2 :
			case 3 :
				DE_PRINT("Loading DE_FW_PAK_ADR5\n");
				srom_boot_offset = gpIPC_REG->srom_boot_offset;
				srom_boot_offset.boot_img_offset = (fwBaseAddr - USE_VIDEO_MCU_ROM_BASE_ADDR);
				gpIPC_REG->srom_boot_offset =  srom_boot_offset;
				
				set_ctrl0.start_vector_sel = 0;
				set_ctrl0.sw_reset = 1;
				gpIPC_REG->set_ctrl0 = set_ctrl0;
				msleep(1); 
				set_ctrl0.run_stall = 0;
				gpIPC_REG->set_ctrl0 = set_ctrl0;
			default :
				break;
		}
	} while (0);

	return ret;
}
/* end of m14 */

static int _download_fw(void)
{
	int ret = RET_OK;

	ret = __download_fw_m14(sDeFirmwareFromHeader_M14A0, 0x90000000);
	// wait mcu's ready
	ret = _check_ipc_ready(1000);
	
	return ret;
}

static int __request_send_data(u8 *pBuffer, u32 size)
{
	// copy ipc data to shared buffer
	memcpy(pSendBufferToMCU, pBuffer, size);

	// send event to mcu
	__send_interrupt_m14(VIDEO_IPC_INTERRUPT_ARM_BIT);

	// wait until mcu's ack
	__wait_interrupt_m14(VIDEO_DMA_INTERRUPT_ARM_BIT, 1000/*timeout 1000 msec*/);

	return RET_OK;
}

static int __request_get_data(u8 *pBuffer, u32 size)
{
	// wait until mcu's interrupt
	__wait_interrupt_m14(VIDEO_IPC_INTERRUPT_ARM_BIT, 1000/*timeout 1000 msec*/);
	
	// copy ipc data from shared buffer
	memcpy(pBuffer, &pSendBufferToCPU[4], size);

	memset(pSendBufferToCPU, 0, size);
	
	return RET_OK;
}

static int _check_ipc_ready(int timeout)
{
	do {
		msleep(1);
		if(__check_ipc_ready_m14()) break;
	} while(--timeout);
	if(!timeout)
	{
		DE_PRINT_ERROR("<error> timeout, de firmware is not working\n");
		return RET_ERROR;
	}
	return RET_OK;
}

static int _put_data(u32 ipcCmd, void *pMsg, u32 msgCnt, VIDEO_IPC_DATA_TYPE_T ipcType)
{
	int ret = RET_OK;
	int cmd_ptr = 0;
	u8 buffer[DTVSOC_IPC_FROM_CPU_SIZE];

	if(sizeof(ipcCmd) + msgCnt > DTVSOC_IPC_FROM_CPU_SIZE)
	{
		DE_PRINT_ERROR("wrong message size\n");
		return RET_ERROR;
	}
	
	memset(buffer, 0, DTVSOC_IPC_FROM_CPU_SIZE);
	buffer[VIDEO_IPC_SIZE] = ((ipcType == VIDEO_IPC_CMD_VAL)?sizeof(ipcCmd):0) + msgCnt;
	buffer[VIDEO_IPC_CONT] = 0;
	buffer[VIDEO_IPC_FROM] = VIDEO_IPC_FROM_HOST;
	buffer[VIDEO_IPC_TYPE] = ipcType;

	cmd_ptr += 4;

	if(ipcType == VIDEO_IPC_CMD_VAL)
	{
		memcpy(&buffer[cmd_ptr], (u8*)&ipcCmd, sizeof(ipcCmd));
		cmd_ptr += sizeof(ipcCmd);
	}

	memcpy(&buffer[cmd_ptr], pMsg, msgCnt);

	ret = __request_send_data(buffer, sizeof(ipcCmd) + msgCnt);

	return ret;
}

static int _get_data(u8 *pBuffer, u32 size)
{
	return __request_get_data(pBuffer, size);
}

static int _ipc_set_data(u32 ipcCmd, void *pMsg, u32 msgCnt)
{
	return _put_data(ipcCmd, pMsg, msgCnt, VIDEO_IPC_CMD_VAL);
}

static int _ipc_get_data(void *pMsg, u32 msgCnt)
{
	return _get_data(pMsg, msgCnt);
}

static int _mcu_cmd_params(int argc, char* cmd, char* param0, char* param1, char* param2,\
						char* param3, char* param4, char* param5, char* param6, char* param7)
{
	char *cmd_buf[9];

	if(argc < 1) return RET_ERROR;

	cmd_buf[0] = cmd;
	cmd_buf[1] = param0;
	cmd_buf[2] = param1;
	cmd_buf[3] = param2;
	cmd_buf[4] = param3;
	cmd_buf[5] = param4;
	cmd_buf[6] = param5;
	cmd_buf[7] = param6;
	cmd_buf[8] = param7;
	
	return  _mcu_execute(argc, (char**)cmd_buf);
}


// dbi(DeBug Interface) for firmware command
#define DBI2MCU(cmd, id)    {#cmd, 5500+id, _mcu_put_data}
#define ARRAY_SIZE(x)       (sizeof(x) / sizeof((x)[0]))
#define VIDEO_MSG_STR_MAX   64

typedef struct {
	char * CmdStr;
	u32 cmdId;
	int (* func) (int argc, char **argv);                                                                        
} DBI_CMD_T;

static char sndBuff[VIDEO_MSG_STR_MAX];
static DBI_CMD_T saVideoDbgList[] = {
	DBI2MCU(MV_PrintCurrentFrame		 ,7),
	DBI2MCU(MV_SetIrqShowOn				 ,73),
	DBI2MCU(MVBIT						 ,207),
	DBI2MCU(MVBW						 ,208),
	DBI2MCU(MVDVR						 ,213),
	DBI2MCU(MVPIP						 ,220),
	DBI2MCU(MVSRC						 ,225),
	DBI2MCU(MVVCR						 ,227),
	DBI2MCU(MVWP						 ,231),
	DBI2MCU(MVZI						 ,233),
	DBI2MCU(MVFRZ						 ,251),
	DBI2MCU(MVMVT						 ,255)
};

static int __is_XDigit(char *pString)
{
	int rtn		   = TRUE;
	int thereIsNum = FALSE;

	if ( pString ) {
		if (*pString == '-') pString++;
		if (*pString == '0') {
			pString++;
			if ((toupper(*pString) == 'X') && isxdigit(pString[1])) {
				pString++;
			} else if ((toupper(*pString) == 'U') && isdigit(pString[1])) {
				pString++;
			} else if ((toupper(*pString) == 'Z') && isxdigit(pString[1])) {
				pString++;
			}
			thereIsNum = TRUE;
		} else if ((toupper(*pString) == 'X') && isxdigit(pString[1])) {
			pString++;
			thereIsNum = TRUE;
		} else if ((toupper(*pString) == 'U') && isdigit(pString[1])) {
			pString++;
			thereIsNum = TRUE;
		} else if ((toupper(*pString) == 'Z') && isxdigit(pString[1])) {
			pString++;
			thereIsNum = TRUE;
		} else if (isdigit(*pString)) {
			pString++;
			thereIsNum = TRUE;
		}

		for ( ;*pString != '\0';++pString ) {
			if (isdigit(*pString)) {
				thereIsNum = TRUE;
			} else if (!isxdigit(*pString)) {
				rtn = FALSE;
				break;
			}
		}
	}

	return rtn;
}

static int __make_arg2str(int argc, char **argv, char *pStr)
{
	int ret = -1;
	int i;

	do {
		if (!argc) break;
		if (!pStr) {
			printf("pStr is Null\n");
			break;
		}
		ret = 0;
		strcpy(pStr, argv[0]);
		for (i=1;i<argc;i++) sprintf(pStr, "%s %s", pStr, argv[i]);
	} while (0);

	return ret;
}

static int __make_str2HexDec (const char *pStr, u32 *pVal)
{
    char inStr[128];

    printf ("%s: 0x", pStr);
    gets (&inStr[0]);
	*pVal = strtoul (inStr, (char **) NULL, 16);
	printf ("\n");

    return 0;
}

static int _mcu_put_data(int argc, char **argv)
{
	int		 ret;

	do {
		ret = __make_arg2str(argc, argv, sndBuff);
		if (ret) break;
		ret = _put_data(0, sndBuff, 64, VIDEO_IPC_CMD_CLI);
	} while (0);

	return ret;
}

static int _mcu_execute(int argc, char **argv)
{
	int ret = RET_ERROR;
	int	isNum;
	char *cmd;
	int i;

	cmd = argv[0];
	isNum = __is_XDigit(cmd);
	for(i=0;i<ARRAY_SIZE(saVideoDbgList);i++) {
		if (!isNum) {
			if (strcmp(cmd, saVideoDbgList[i].CmdStr)) continue;
		} else {
			if (saVideoDbgList[i].cmdId <= 0) continue;
			if(strtoul(cmd ,NULL ,0) != saVideoDbgList[i].cmdId ) continue;
		}
		ret = saVideoDbgList[i].func(argc, argv);
		break;
	}

	return ret;
}

static int _change_uart(void)
{
	CTR58 ctr58;
	
	ctr58 = ctop_regs->ctr58;
	ctr58.uart0_sel = 0x1;
	ctr58.uart1_sel = 0x1;
	ctop_regs->ctr58 = ctr58;
	
	do {
		if(!__wait_interrupt_m14(VIDEO_IPC_INTERRUPT_ARM_BIT, 100))
		{
			memset(pSendBufferToCPU, 0, DTVSOC_IPC_FROM_CPU_SIZE);
			ctr58.uart0_sel = 0x2;
			ctr58.uart1_sel = 0x7;
			ctop_regs->ctr58 = ctr58;
			break;
		}
		printf("*");
		msleep(100);
	} while(1);

	return RET_OK;
}

static int _de_command(int argc, char* argv[])
{
	u32	command;

	do {
		printf("\n========== [ De Debug Menu ] ============\n\n");
		printf("      0x01 :  Change uart0  cpu -> de mcu\n");
		printf("      0x02 :  Download firmware\n");
		printf("      0x03 :  Get version\n");
		printf("      0x04 :  Set panel sync type\n");
		printf("      0xFF :  Exit from this menu");
		printf("\n");

		__make_str2HexDec ("      Enter command", &command);

		switch(command)
		{
			case 0x01:
				{
					_change_uart();
				}
				break;
			case 0x02:
				{
					_download_fw();
				}
				break;
			case 0x03:
				{
					LX_DE_FIRMWARE_INFO_T fw_info;
					de_get_version(&fw_info);
					printf("fw_version[ %d ] yyyy/mm/dd = %04d/%02d/%02d\n", \
							fw_info.version, fw_info.date.year, fw_info.date.month, fw_info.date.day);
				}
				break;
			case 0x04:
				{
					LX_DE_PANEL_TYPE_T panel_type;
					printf("        0:FHD,        1:1366x768,  2:1024x768,  3:1365x768\n");
					printf("        4:3840x2160,  5:1280x720,  6:720x480,   7:640x480,    8:720x576\n");
					__make_str2HexDec ("      Select one", &panel_type);
					de_init_firmware(panel_type);
				}
				break;
			default:
				printf("Not used\n");
				break;
			case 0xFF:
				break;
		}
	} while(command != 0xFF);

	return 0;
}

COMMAND(mcu, _de_command, "command for de mcu", NULL);


