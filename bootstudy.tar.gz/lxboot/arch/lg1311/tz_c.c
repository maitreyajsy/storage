/***********************************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ************************************************************************************************************/


/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	yw.kim@lge.com 		Release initial codes for lxboot in arch/lg1152 folder for tzfw
|										loading and booting.
|	DEC ?	2011	yw.kim@lge.com		Add tzfw loading from emmc partition.
|	? 	? 	2011	yw.kim@lge.com		Copy this file from arch/lg1152 to arch/lg1154 for h13 evaluation.
|	Feb	22	2012	ks.hyun@lge.com		Change tzfw loading time before interrupt disable.
|	Feb 26	2012	yw.kim@lge.com		Loading address for tzfw from .data section is inserted into mmu table dynamically.
|	Mar	14	2012 	yw.kim@lge.com		Loading address for tzfw from emmc partition is inserted into mmu tablse dynamically.
| 	Mar	14	2012 	yw.kim@lge.com		Loading tzfw from .data section or emmc partition anywhere.
|============================================================================================================*/


#ifndef _TZ_C_
#define _TZ_C_


//=================================================================================================
// HEADER
//=================================================================================================

#include <autoconf.h>
#include <types.h>
#include <arch.h>
#include <platform.h>
#include <stdio.h>
#include <string.h>
#include <mmu.h>
#include <command.h>
#include <storage.h>
#include <debug.h>
#include <arch/tz.h>



/* move tz image (emmc -> ddr) */
#define TZ_DMA_MEM_BASE		(0x7f600000)


//=================================================================================================
// SYMBOLIC
//=================================================================================================
#define TZASC_BASE 				(0xC0226000)
#define TZASC_0_BASE			(TZASC_BASE + 0x0000)
#define TZASC_4_BASE			(TZASC_BASE + 0x4000)
#define TZASC_ATTR_0_OFFSET		(0x108)
#define TZASC_SP_Y_Y_Y_Y	    (0xF<<28)



//=================================================================================================
// DATA TYPE
//=================================================================================================

typedef struct _axi_en_reg_t {
	uint32_t
	reserved_0 	: 27,
	asc_en 		: 1,
	reserved_1	: 4;
} axi_en_reg_t;

typedef struct _tzasc_attr_reg_t {
	uint32_t
	attr 	: 32;
} tzasc_attr_reg_t;



//=================================================================================================
//  EXTERNAL FUNC
//=================================================================================================

extern void tz_start_trustworld(unsigned int addr);
extern void mmu_init(void);
extern void mmu_disable(void);



//=================================================================================================
// EXTERNAL VAR
//=================================================================================================



//=================================================================================================
// FUNCTION
//=================================================================================================
#if USE_TZ_PARTITION
/*load tz from emmc partition*/
static uint32_t _loadtz_from_storage(void)
{
	uint32_t load_addr = 0;
	uint8_t* buf = (uint8_t *)TZ_DMA_MEM_BASE;
	void* hdr;
	uint32_t img_size;
	uint64_t offset;
	uint32_t filesize;
	storage_partition_t partition;

	/*get tzfw partition*/
	if(storage_get_partition("tzfw", &partition) < 0 || partition.filesize == 0)
	{
		ERROR("Invalid tzfw partition\n");
		return 0;
	}
	offset = partition.offset;
	filesize = partition.filesize; /*header(16B) + program_size*/

	printf("tzfw partition offset[0x%llx], filesize[0x%x]\n", offset, filesize, DATA_BUF_BASE);


	/*read tzfw header*/
	if (storage_read(offset+TZFW_HDR_OFFSET, TZFW_HDR_SZ, buf) < 0)
	{
		ERROR("Can't read tzfw image\n");
		return 0;
	}

	/*check magic, loading addr, binary size*/
	hdr = (void*)buf;
	if(tzfw_check_magic(hdr))
	{
		load_addr = tzfw_get_load(hdr);
		img_size = tzfw_get_size(hdr);

		printf("tzfw load_addr[0x%x], img_size[0x%x] from emmc\n", load_addr, img_size);
	}
	else
	{
		ERROR("fault tzfw magic\n");
		return 0;
	}

	/*read tzfw binary*/
	if (storage_read(offset, img_size, (void*)buf) < 0)
	{
		ERROR("Can't read tzfw image\n");
		return 0;
	}
	else
	{	
	#if USE_DATA_CACHE
		/*check if load_addr exists in mmu master section table*/
		if(!mmu_chk_l1_entry(load_addr))
		{
			mmu_insert_l1_entry(load_addr, img_size, S_SO_MEMORY);
		}
	#endif
		/*load tzfw binary to execution address*/
		memcpy((char *)load_addr, (char*)buf, img_size);
		printf("success\n");
	}

	return load_addr;

}
#endif

#if USE_TZ_INCBIN
extern unsigned int tz_bin_start;
extern unsigned int tz_bin_end;

/*load tz from .data section in 2st lxboot*/
static uint32_t _loadtz_from_section(void)
{
	uint32_t load_addr = 0;
	void* hdr ;
	uint32_t img_size, bin_start;

	hdr = (void*)((uint8_t*)(&tz_bin_start)+TZFW_HDR_OFFSET);

	if(tzfw_check_magic(hdr))
	{
		load_addr = tzfw_get_load(hdr);
		img_size = tzfw_get_size(hdr);
		bin_start = (uint32_t)(&tz_bin_start);

		printf("tzfw load_addr[0x%x], img_size[0x%x] from .data section\n", load_addr, img_size);

	#if USE_DATA_CACHE
		/*check if load_addr exists in mmu master section table*/
		if(!mmu_chk_l1_entry(load_addr))
		{
			mmu_insert_l1_entry(load_addr, img_size, S_SO_MEMORY);
		}
	#endif

		memcpy((void*)load_addr,(void*)bin_start, img_size);
	}
	else
	{
		ERROR("fault tzfw magic\n");
		return 0;
	}

	return load_addr;
}
#endif

uint32_t loadtz(void)
{
	uint32_t load_addr=0;

#if USE_TZ_PARTITION
	/*load tzfw from emmc firstly.*/
	load_addr = _loadtz_from_storage();
	printf ("load from storage : 0x%08x \n", load_addr);
#endif

#if USE_TZ_INCBIN
	/*load tzfw from .data section.*/
	if(load_addr == 0)
	{
		load_addr = _loadtz_from_section();
		printf ("load from section : 0x%08x \n", load_addr);
	}

#endif

	return load_addr;
}


void tz_boot(uint32_t load_addr)
{
	/*build trust world.*/
	printf("---->goto tz, pc[0x%x]\n", load_addr);

	/*travel to trust world.*/
	tz_start_trustworld(load_addr);

	return;
}


int do_tz_cmd_test(int argc, char *argv[])
{
	tz_arg_t 			tz_arg;

	tz_arg.cmd_r0=TZ_CMD_INIT_IF;
	tz_nwd_exec_smc(&tz_arg);


	printf("Success\n");

	tz_arg.cmd_r0=TZ_CMD_INTR_TEST;
	tz_nwd_exec_smc(&tz_arg);

	return 0;
}

COMMAND(tzcmd, do_tz_cmd_test, "usage : nwsm t", NULL);


void tzasc_init(void)
{
	volatile axi_en_reg_t 		*axi_r_reg;
	volatile axi_en_reg_t 		*axi_w_reg;
	volatile tzasc_attr_reg_t 	*tzasc_attr_reg;

	/*M0 Port0 is connected ASC0.*/
	axi_r_reg = (volatile axi_en_reg_t *)(LG1311_M0_BASE + 0xC0);
	axi_w_reg = (volatile axi_en_reg_t *)(LG1311_M0_BASE + 0xE0);

	if(axi_r_reg->asc_en && axi_w_reg->asc_en)
	{
		tzasc_attr_reg = (volatile tzasc_attr_reg_t *)(TZASC_0_BASE + TZASC_ATTR_0_OFFSET);
		tzasc_attr_reg->attr =  TZASC_SP_Y_Y_Y_Y;
	}

	/*M1 Port0 is connected ASC4.*/
	axi_r_reg = (volatile axi_en_reg_t *)(LG1311_M1_BASE + 0xC0);
	axi_w_reg = (volatile axi_en_reg_t *)(LG1311_M1_BASE + 0xE0);

	if(axi_r_reg->asc_en && axi_w_reg->asc_en)
	{
		tzasc_attr_reg = (volatile tzasc_attr_reg_t *)(TZASC_4_BASE + TZASC_ATTR_0_OFFSET);
		tzasc_attr_reg->attr =  TZASC_SP_Y_Y_Y_Y;
	}
}


#endif /*_TZ_C_*/

