#ifndef __ARCH_IRQS_H__
#define __ARCH_IRQS_H__

/**
 * IPIs IDs
 */
#define IPI_0      0 /**< Inter Processor Interrupt ID 0 */
#define IPI_1      1 /**< Inter Processor Interrupt ID 1 */
#define IPI_2      2 /**< Inter Processor Interrupt ID 2 */
#define IPI_3      3 /**< Inter Processor Interrupt ID 3 */
#define IPI_4      4 /**< Inter Processor Interrupt ID 4 */
#define IPI_5      5 /**< Inter Processor Interrupt ID 5 */
#define IPI_6      6 /**< Inter Processor Interrupt ID 6 */
#define IPI_7      7 /**< Inter Processor Interrupt ID 7 */
#define IPI_8      8 /**< Inter Processor Interrupt ID 8 */
#define IPI_9      9 /**< Inter Processor Interrupt ID 9 */
#define IPI_10    10 /**< Inter Processor Interrupt ID 10 */
#define IPI_11    11 /**< Inter Processor Interrupt ID 11 */
#define IPI_12    12 /**< Inter Processor Interrupt ID 12 */
#define IPI_13    13 /**< Inter Processor Interrupt ID 13 */
#define IPI_14    14 /**< Inter Processor Interrupt ID 14 */
#define IPI_15    15 /**< Inter Processor Interrupt ID 15 */

#define SCHEDULER_IPI					IPI_0
#define CPU_WAKEUP_IPI					IPI_1
#define CPU_EXIT_IPI					IPI_2
#define CPU_EXIT2_IPI					IPI_3


#define IRQ_LOCALTIMER      29
#define IRQ_LOCALWDOG		30

#define IRQ_GIC_START		32

#define IRQ_UART0			(IRQ_GIC_START +  0)	/* UART 0 */
#define IRQ_UART1			(IRQ_GIC_START +  1)
#define IRQ_UART2			(IRQ_GIC_START +  2)
#define IRQ_TIMER0_1		(IRQ_GIC_START +  6)	/* Timer 0 and 1 */
#define IRQ_SDHC			(IRQ_GIC_START + 18)	/* emmc */

#define NR_IRQS				(IRQ_GIC_START + 128)
#define IRQ_GIC_END			NR_IRQS


#endif /* __IRQS_H__ */
