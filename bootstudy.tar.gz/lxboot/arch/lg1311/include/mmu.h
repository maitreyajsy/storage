/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	ks.hyun@lge.com 	Release initial codes for lxboot in arch/lg1152 folder.
|	Feb 26	2012	yw.kim@lge.com		Loading address for tzfw is inserted into mmu table dynamically.
|
|============================================================================================================*/


#ifndef __ARCH_MMU_H__
#define __ARCH_MMU_H__

#include <arm/mmu.h>

/*new function in lg1154*/
uint32_t mmu_chk_l1_entry(uint32_t addr);
void mmu_insert_l1_entry(uint32_t addr, uint32_t size, uint32_t attr);

#endif /* __ARCH_MMU_H__ */
