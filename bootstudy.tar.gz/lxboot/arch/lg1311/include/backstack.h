#ifndef __BACKSTACK_H__
#define __BACKSTACK_H__

#include <arch/cpu.h>

int16_t	get_frame_size(pPRINT_FUNC, uint32_t *, uint32_t *, uint32_t **, int);
#endif/*__BACKSTACK_H__*/
