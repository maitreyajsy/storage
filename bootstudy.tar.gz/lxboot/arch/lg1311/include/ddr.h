#ifndef __ARCH_DDR_H_
#define __ARCH_DDR_H_

/* M14A0 */
#define EXT_INFO_MAGIC_M14A0		0x48134130	/* 'H'+13+"A0" */

typedef struct
{
	uint32_t	op;
	uint32_t	addr;
	uint32_t	val;
	uint32_t	mask;
} ddr_params_t;

typedef struct
{
	uint32_t		magic;
	uint32_t		ddr_params;
	ddr_params_t	ddr_param[];
} ext_info_hdr_a0_t;


/* M14B0 */
#define EXT_INFO_MAGIC_M14B0		0x4D144230  /* 'M'14"B0" */

#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3
typedef struct
{
	uint32_t	opcode;
	uint32_t	operand;
} reg_param_t;

typedef struct
{
	uint32_t		magic;
	uint32_t		ddr_params;
	reg_param_t		ddr_param[];
} ext_info_hdr_b0_t;


#endif /* __ARCH_DDR_H_ */
