#ifndef __ARCH_DISPLAY_H__
#define __ARCH_DISPLAY_H__

typedef enum
{
	PANEL_TYPE_V12 = 0,
	PANEL_TYPE_V13,
	PANEL_TYPE_V14
} panel_type_t;

typedef enum
{
	PANEL_INCH_32 = 0,
	PANEL_INCH_42,
	PANEL_INCH_43,
	PANEL_INCH_47,
	PANEL_INCH_49,
	PANEL_INCH_50,
	PANEL_INCH_55,
	PANEL_INCH_60,
	PANEL_INCH_65,
	PANEL_INCH_70,
	PANEL_INCH_84
} panel_inch_t;

typedef enum
{
	PANEL_TOOL_LB67 = 0,
	PANEL_TOOL_LB69,
	PANEL_TOOL_LB72,
	PANEL_TOOL_LB87
} panel_tool_t;

typedef enum
{
	PANEL_MAKER_LGD = 0,
	PANEL_MAKER_SHARP
} panel_maker_t;

typedef enum
{
	PANEL_BACKLIGHT_EDGE_LED = 0,
	PANEL_BACKLIGHT_ALEF_LED,
	PANEL_BACKLIGHT_DIRECT_M,
	PANEL_BACKLIGHT_DIRECT_L,
	PANEL_BACKLIGHT_OLED,
	PANEL_BACKLIGHT_OTHER
} panel_backlight_t;

typedef enum
{
	PANEL_LED_BAR_6 = 0,	
	PANEL_LED_BAR_8,
	PANEL_LED_BAR_10,
	PANEL_LED_BAR_12,
	PANEL_LED_BAR_15,
	PANEL_LED_BAR_16,
	PANEL_LED_BAR_20,
	PANEL_LED_BAR_240,
	PANEL_LED_BAR_V8,
	PANEL_LED_BAR_OTHER
} panel_led_bar_type_t;

typedef enum
{
	DISP_120HZ_FULLHD_EPI = 0,
	DISP_120HZ_FULLHD_LVDS4,
	DISP_120HZ_FULLHD_VX1,
	DISP_60HZ_FULLHD_LVDS2,
	DISP_60HZ_FULLHD_HSLVDS1,
	DISP_60HZ_FULLHD_EPI
} disp_output_type_t;

typedef enum
{
	LVDS_VESA = 0,
	LVDS_JEIDA
} lvds_type_t;

typedef enum
{
	LVDS_10BIT = 0,
	LVDS_8BIT
} lvds_bit_t;

typedef enum
{
	DISP_BOARD_TYPE_SYSTEM = 0,
	DISP_BOARD_TYPE_EVAL,
} disp_board_type_t;

typedef enum
{
	LED_CONTROL_DISABLE = 0,
	LED_CONTROL_ENABLE,
} led_control_t;

struct disp_info
{
	panel_type_t		panel_type;
	panel_inch_t		panel_inch;
	panel_tool_t		panel_tool;
	panel_maker_t		panel_maker;
	panel_backlight_t	panel_backlight;
	panel_led_bar_type_t panel_led_bar_type;
	disp_output_type_t	output_type;
	lvds_type_t		lvds_type;
	lvds_bit_t			lvds_bit;
	int					mirror;
	disp_board_type_t	board_type;
	led_control_t		led_control;
};

#endif
