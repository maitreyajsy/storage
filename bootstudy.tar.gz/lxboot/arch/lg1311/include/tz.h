#ifndef _TZ_H_
#define _TZ_H_

/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 *****************************************************************************************/


//=================================================================================================
// HEADER FILES
//=================================================================================================
#include <interrupt.h>


//=================================================================================================
// SYMBOLIC
//=================================================================================================

#define TZFW_HDR_SZ			0x10 /*16 bytes*/
#define TZFW_HDR_OFFSET		0x20 /*32bytes vector table advance header*/






//=================================================================================================
// DATA TYPE
//=================================================================================================

typedef struct {
	u32	magic;
	u32 load;
	u32 size_0;
	u32 size_1;
} tzfw_hdr_t;


/*nwd->swd command*/
typedef enum {
	/* Trustzone CMDs */
	TZ_CMD_L2CC						= 0x01,
	TZ_CMD_INIT_IF					= 0x02,
	TZ_CMD_EXIT_IF					= 0x03,
	TZ_CMD_LOCK_DEBUG				= 0x04,
	TZ_CMD_UNLOCK_DEBUG				= 0x05,
	
	/* Security Core CMDs */
	TZ_CMD_RESET					= 0x10, 
	TZ_CMD_SET_KEY					= 0x11, 
	TZ_CMD_SET_IV					= 0x12, 
	TZ_CMD_ENCRYPT					= 0x13, 
	TZ_CMD_DECRYPT					= 0x14, 
	TZ_CMD_HASH						= 0x15, 
	TZ_CMD_RSA						= 0x16, 
	TZ_CMD_XOR						= 0x17,
	TZ_CMD_GET_RANDOM_NUMBER		= 0x18,
	TZ_CMD_GET_STATUS				= 0x19,
	TZ_CMD_EXTRACT_SECURE_DATA		= 0x1A,
	TZ_CMD_GEN_SECURE_DATA			= 0x1B,
	TZ_CMD_TAKE_SECURE_DATA			= 0x1C,
	TZ_CMD_TRANSFORM_SECURE_DATA	= 0x1D,
	TZ_CMD_PUSH_SECURE_DATA			= 0x1E,
	TZ_CMD_POP_SECURE_DATA			= 0x1F,
	TZ_CMD_GET_VERIFICATION			= 0x20,
	TZ_CMD_SET_VERIFICATION			= 0x21,
	TZ_CMD_GET_ADC					= 0x22,
	TZ_CMD_SET_ADC					= 0x23,

#if (CONFIG_SUPPORT_PM)
	TZ_CMD_PM_SUSPEND				= 0x31,
#if	(CONFIG_DBG_SUPPORT_PM)
	TZ_CMD_PM_RESUME				= 0x32,
#endif
#endif

	/* Debugging CMDs */
	TZ_CMD_INTR_TEST				= 0xF1,
#if (CONFIG_DBG_TZTIMER_TICK_SCHED)
	TZ_CMD_TZTIMER_TICK_SCHED_TEST	= 0xF2
#endif
} TZ_CMD_T;

/*Structure for holding values to go in registers r0-r7 before SMC issue.*/
typedef struct {
    unsigned int    cmd_r0; /*command type*/
    unsigned int    arg_r1; /*security commnad header*/
    unsigned int    arg_r2; /*wsm physical base addr*/
    unsigned int    arg_r3; /*wsm virtual base addr*/
    unsigned int    arg_r4; /*wsm data size in byte*/
    unsigned int    arg_r5; /**/
    unsigned int    arg_r6;
    unsigned int    arg_r7;
} tz_arg_t;



//=================================================================================================
// FUNCTION PROTO
//=================================================================================================



//=================================================================================================
// FUNCTION DEF
//=================================================================================================

/*
* tunnel to SWd.
**/
static inline void tz_nwd_exec_smc(tz_arg_t* tz_arg)
{
	asm volatile (
        "LDM    %1, {r0-r7}\n"
        ".word  0xe1600070 @SMC 0\n"
        "MOV    %0, r0\n"
        : "=r" (tz_arg->cmd_r0)
        : "r"  (tz_arg)
        : "r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7", "r12"
    );

}



static inline int tzfw_get_magic(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return (h->magic);
}

static inline int tzfw_check_magic(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return ((h->magic)==0x545A4657); /*TZFW*/
}


static inline uint32_t tzfw_get_load(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return (h->load);
}

static inline uint32_t tzfw_get_size(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return (h->size_0+h->size_1);
}


uint32_t loadtz(void);
void tz_boot(uint32_t load_addr);
void tzasc_init(void);

#endif /*_TZ_H_*/

