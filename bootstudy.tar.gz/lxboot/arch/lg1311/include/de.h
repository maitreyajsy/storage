/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

/*----------------------------------------------------------------------------------------
     Type Definitions
----------------------------------------------------------------------------------------*/
typedef struct {
	UINT16 year;            ///< year
	UINT16 month;           ///< month
	UINT16 day;             ///< day
} LX_DE_DATE_T;
 
typedef struct {
	UINT32  version;        ///< firmware version
	LX_DE_DATE_T date;      ///< updated date
} LX_DE_FIRMWARE_INFO_T;

// IPC command list
typedef enum {
	DE_IPC_DE_INIT	= 0x00000001		/* 0x00000001 */, ///< Initialize de module
	DE_IPC_GET_FIRMWARE_INFO			/* 0x00000002 */, ///< get information of Firmware
	DE_IPC_GET_INPUT_WIN				/* 0x00000003 */, ///< get scaler input window size and position.
	DE_IPC_GET_OUT_WIN					/* 0x00000004 */, ///< set scaler output window size and position.
	DE_IPC_SET_INPUT_WIN				/* 0x00000005 */, ///< set scaler input window size and position.
	DE_IPC_SET_OUT_WIN					/* 0x00000006 */, ///< get scaler input window size and position.
	DE_IPC_SET_FREEZE					/* 0x00000007 */, ///< set freeze of selected window
	DE_IPC_SET_INPUT_SRC				/* 0x00000008 */, ///< set source type comming into selected window
	DE_IPC_SET_DIS_OUT					/* 0x00000009 */, ///< set display size and position.
	DE_IPC_SET_DIS_FMT					/* 0x0000000a */, ///< set display pannel format
	DE_IPC_SET_MULTI_WIN     			/* 0x0000000b */, ///< select type of muliwindow
	DE_IPC_MULTI_WIN_ENALBE				/* 0x0000000c */, ///< determine selected multi window to turn On or Off
	DE_IPC_SET_CVI_SRC_TYPE				/* 0x0000000d */, ///< set source type comming into selected CVI
	DE_IPC_SET_CVI_CSC					/* 0x0000000e */, ///< send color space conversion matrix and offset for each external source information.
	DE_IPC_SET_POST_CSC					/* 0x0000000f */, ///< send color space conversion matrix for post processing block
	DE_IPC_GET_MVI_COLORIMETRY			/* 0x00000010 */, ///< get MVI source colorimetry information.
	DE_IPC_SET_ZLIST					/* 0x00000011 */, ///< set display size and position.
	DE_IPC_GRAB_PIXEL					/* 0x00000012 */, ///< grab video pixels of certain block size and position.
	DE_IPC_GET_MVI_TIMING_INFO			/* 0x00000013 */, ///< set source type comming into selected MVI
	DE_IPC_SET_DEINTERLACE				/* 0x00000014 */, ///< set deinterlace on/off control

	DE_IPC_SET_PRE3D_IN_MODE			/* 0x00000015 */, ///< select pre-3D input mode  (0: normal mode, 1:frame by frame mode)

	DE_IPC_SET_3D_OPR_MODE				/* 0x00000016 */, ///< control pre-3D block on/off (0: disable, 1: enable)
	DE_IPC_SET_PWM						/* 0x00000017 */, ///< set de PWN parameter. only used for 60Hz LCD panel.
	DE_IPC_SET_CVE						/* 0x00000018 */, ///< set de CVE parameter.
	DE_IPC_SET_VCS						/* 0x00000019 */, ///< set de VCS parameter.
	DE_IPC_GET_CAPTURE_WIN				/* 0x0000001a */, ///< get de captured video size and offset
	DE_IPC_SET_CAPTURE_WIN				/* 0x0000001b */, ///< set de captured video size and offset
	DE_IPC_SET_FR_RATE					/* 0x0000001c */, ///< set display frame rate
	DE_IPC_GET_OUT_FR_RATE				/* 0x0000001d */, ///< get display frame rate
	DE_IPC_SET_BG_COLOR					/* 0x0000001e */, ///< set back ground color of display
	DE_IPC_SET_WIN_BLANK				/* 0x0000001f */, ///< set blank of selected window and blank color
	DE_IPC_SET_IRE_PATTERN				/* 0x00000020 */, ///< set color and IRE levels of full pattern.
	DE_IPC_SET_SPREAD					/* 0x00000021 */, ///< set LVDS spread spectrum for 60Hz mode (PDP).
	DE_IPC_REG_RD						/* 0x00000022 */, ///< read Register
	DE_IPC_REG_WD						/* 0x00000023 */, ///< write Register
	DE_IPC_OIF_INIT						/* 0x00000024 */, ///< Initialize OIF module.
	DE_IPC_OIF_SET_LVDS_OUTPUT			/* 0x00000025 */, ///< Set LVDS OUTPUT Enable.
	DE_IPC_OIF_SET_LVDS_POWER			/* 0x00000026 */, ///< Set LVDS power on.
	DE_IPC_OIF_SET_DARK_SCREEN			/* 0x00000027 */, ///< Set LVDS dark screen.

	DE_IPC_OIF_SET_VESA_JEIDA			/* 0x00000028 */, ///< Select LVDS type(VESA/JEIDA).
	DE_IPC_OIF_SET_PANEL_IF				/* 0x00000029 */, ///< select LVDS inteface type(LVDS/mini-LVDS).
	DE_IPC_OIF_SET_PIXEL				/* 0x0000002a */, ///< set LVDS pixel type( single/dual/quad).
	DE_IPC_OIF_SET_BIT_DEPTH			/* 0x0000002b */, ///< set LVDS bit resolution(10bit/8bit).
	DE_IPC_OIF_SELECT_OUT_PATH			/* 0x0000002c */, ///< set LVDS signal path from DE/FRC/LED/ODC
	DE_IPC_OIF_SELECT_LVDS_PATH			/* 0x0000002d */, ///< set LVDS signal path from DE/FRC/LED/ODC
	DE_IPC_OIF_SELECT_OUT_CH			/* 0x0000002e */, ///< select output chanel number 1CH, 2CH, 4CH according to resolution and frame rate
	DE_IPC_OIF_SELECT_LED_PATH			/* 0x0000002f */, ///< select LED input path from DE/FRC.
	DE_IPC_OIF_SELECT_PWM_PATH			/* 0x00000030 */, ///< select PWM signal path from DE/FRC.
	DE_IPC_OIF_SELECT_LR_PATH			/* 0x00000031 */, ///< select LR signal path from DE/FRC.
	DE_IPC_OIF_GET_INFO					/* 0x00000032 */, ///< get OIF setting information.
	DE_IPC_OIF_GET_LVDS_IF_CTRL			/* 0x00000033 */, ///< get OIF setting information.
	DE_IPC_OIF_GET_LVDS_TX_CTRL			/* 0x00000034 */, ///< Control LVDS TX following TCON enable.
	DE_IPC_SET_CVI_FIR					/* 0x00000035 */, ///< send captured video fir coef for double/quad sampling case.
	DE_IPC_SET_CVI_TPG					/* 0x00000036 */, ///< set captured video test pattern generator to full mono color.
	DE_IPC_SET_CVI_CSAMPLE_MODE			/* 0x00000037 */, ///< set captured video color sampling mode(sub sampling or 3 tap filtering).
	DE_IPC_SET_CVI_SYNC_RESHAPE			/* 0x00000038 */, ///< reshape sync of captured video for PC input.
	DE_IPC_SET_PE_TEST_PATTERN_GEN		/* 0x00000039 */, ///< generate TPG in PE region.
	DE_IPC_SET_PE_BBD_CTRL				/* 0x0000003a */, ///< set PE0 black boundary detection control.
	DE_IPC_GET_PE_BBD_STATUS			/* 0x0000003b */, ///< get PE0 black boundary detection status.
	DE_IPC_SET_EDGE_CROP				/* 0x0000003c */, ///< generate TPG in PE region.
	DE_IPC_SET_DVR_FMT_CTRL				/* 0x0000003d */, ///< set DVR format control
	DE_IPC_FC_SET_WIN_INFO				/* 0x0000003e */, ///< set geomitery information of picture to be caputured.
	DE_IPC_FC_GET_FRAME_INFO			/* 0x0000003f */, ///< get address of picture to be caputured
	DE_IPC_SET_SUB_SC_FREEZE			/* 0x00000040 */, ///< set frame caputuring mode On or Off.
	DE_IPC_SET_3D_FULL_MODE				/* 0x00000041 */, ///< set UD & 3D mode.
	DE_IPC_SET_CVI_VIDEO_FRAME_BUFFER	/* 0x00000042 */, ///< copy frame buffer of certain block size and position.
	DE_IPC_GET_CVI_INFO					/* 0x00000043 */, ///< get information of cvi input.
	DE_IPC_SET_CVI_FREEZE				/* 0x00000044 */, ///< de cvi video frame buffer freeze
	DE_IPC_SET_LVDS_PATH_INFO			/* 0x00000045 */, ///< set lvds dual out mode for display sync control
	DE_IPC_SELECT_MULTI_WIN_SRC			/* 0x00000046 */, ///< de multi window source for cvi input
	DE_IPC_SET_UD_MODE					/* 0x00000047 */, ///< set UD mode.
	DE_IPC_SET_CVI_DELAY				/* 0x00000048 */, ///< set delay of gbr signal on cvi
	DE_IPC_SET_LOW_DELAY			    /* 0x00000049 */, ///< set low delay mode for frame delay
	DE_IPC_GET_PAR_INFO					/* 0x0000004a */, ///< get information of pixel aspect ratio
	DE_IPC_SET_PLATFORM_VERSION			/* 0x0000004b */, ///< set information of chip version
	DE_IPC_SET_MULTI_VISION				/* 0x0000004c */, ///< set information of multi vision
	DE_IPC_GET_FRAME_FOR_WEBOS			/* 0x0000004d */, ///< get frame address for WebOs to be caputured
	DE_IPC_SET_IF_CONFIG				/* 0x0000004e */, ///< set configure for DE
	DE_IPC_GET_LOW_DELAY			    /* 0x0000004f */, ///< get low delay mode for frame delay
	DE_IPC_GET_SCALER_INFO				/* 0x00000056 */, ///< get scaler infoi
} DE_IPC_CMD_T;


typedef enum {
	LX_PANEL_TYPE_1920 = 0, ///< full HD
	LX_PANEL_TYPE_1366,     ///< WXGA(HD)
	LX_PANEL_TYPE_1024,     ///< 1024x768
	LX_PANEL_TYPE_1365,     ///< 1365x768
	LX_PANEL_TYPE_3840,     ///< 3840x2160
	LX_PANEL_TYPE_1280,     ///< 1280x720
	LX_PANEL_TYPE_720,      ///< 720x480
	LX_PANEL_TYPE_640,      ///< 640x480
	LX_PANEL_TYPE_576,      ///< 720x576
	LX_PANEL_TYPE_MAX       ///< max number
} LX_DE_PANEL_TYPE_T;

typedef enum {
	VIDEO_IPC_SIZE ,
	VIDEO_IPC_CONT ,
	VIDEO_IPC_FROM ,
	VIDEO_IPC_TYPE ,
	VIDEO_IPC_DATA ,
} VIDEO_IPC_CMD_T;
 
typedef enum {
     VIDEO_IPC_FROM_UART = 1 ,
     VIDEO_IPC_FROM_HOST = 2 ,
} VIDEO_IPC_FROM_T;

typedef enum {
	VIDEO_IPC_CMD_CLI = 1 ,
	VIDEO_IPC_CMD_VAL = 2 ,
	VIDEO_IPC_CMD_PRT = 3 ,
} VIDEO_IPC_DATA_TYPE_T;


/*----------------------------------------------------------------------------------------
     External Function Prototype Declarations
----------------------------------------------------------------------------------------*/
int de_init(void);
int de_init_firmware(LX_DE_PANEL_TYPE_T panel_type);
int de_get_version(LX_DE_FIRMWARE_INFO_T *version);
int de_set_vcr(int enb);

