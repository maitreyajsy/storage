#ifndef __ARCH_TYPES_H__
#define __ARCH_TYPES_H__

typedef signed 		char 	s8;
typedef unsigned 	char 	u8;

typedef signed 		short 	s16;
typedef unsigned 	short 	u16;

typedef signed 		int 	s32;
typedef unsigned 	int 	u32;

typedef signed long long	s64;
typedef unsigned long long	u64;

typedef unsigned	int		dma_addr_t;


#define LONG_MIN		(-2147483647L - 1)	// Minimum (signed) long value
#define LONG_MAX		2147483647L			// Maximum (signed) long value
#define ULONG_MAX		0xffffffffUL		// Maximum unsigned long value



#define IO_WRITE(x,v)		(*((volatile u32 *)(x)) = v)
#define IO_READ(x)			(*((volatile u32 *)(x)))

#define IO_WRITE8(x,v)		(*((volatile u8 *)(x)) = v)
#define IO_READ8(x)			(*((volatile u8 *)(x)))

#define REG_WRITE(x,v)		IO_WRITE(x,v)
#define REG_READ(x)			IO_READ(x)

#endif // _TYPEDEF__HEADER_
