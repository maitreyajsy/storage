#ifndef __DSM_H__
#define __DSM_H__

#include <arch/cpu.h>

#define DSM_WINDOW_SZ	(8)

#endif/*__DSM_H__*/
