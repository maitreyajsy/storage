#ifndef __ARCH_MEMORY_MAP_H__
#define __ARCH_MEMORY_MAP_H__

#include "address_map.h"

#ifndef CONFIG_STACK_TOP
#error "CONFIG_STACK_TOP not defined in config"
#endif

/* memory map�� platform ���� �����ϰ� arch������ �ʿ��� macro�� define���θ� üũ�Ѵ�. */
#include <platform/memory_map.h>

#ifndef IRQ_STACK
#error "IRQ_STACK not defined in <platform/memory_map.h>"
#endif

#ifndef SYS_STACK
#error "SYS_STACK not defined in <platform/memory_map.h>"
#endif

#ifndef MMU_TLB_BASE
#error "MMU_TLB_BASE not defined in <platform/memory_map.h>"
#endif

#ifndef SYSTEM_MALLOC_BASE
#error "SYSTEM_MALLOC_BASE not defined in <platform/memory_map.h>"
#endif

#ifndef DMA_MALLOC_BASE
#error "DMA_MALLOC_BASE not defined in <platform/memory_map.h>"
#endif

#ifndef DATA_BUF_BASE
#error "DATA_BUF_BASE not defined in <platform/memory_map.h>"
#endif


#endif //__ARCH_MEMORY_MAP_H__