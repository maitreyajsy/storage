#ifndef _USB_TOP_REGS_H_
#define _USB_TOP_REGS_H_


#include <types.h>

/*----------------------------------------------------------------------------------------
    Control Constants
----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
    File Inclusions
----------------------------------------------------------------------------------------*/


#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
	0x0000 phy_ctlr_rst ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	resetn_hsusb1_utim_reset        : 1,	//     4
	resetn_hsusb1_core              : 1,	//     5
	resetn_hsusb1_bus               : 1,	//     6
	resetn_hsusb1_phy               : 1,	//     7
	                                : 4,	//  8:11 reserved
	resetn_hsusb0_utim_reset        : 1,	//    12
	resetn_hsusb0_core              : 1,	//    13
	resetn_hsusb0_bus               : 1,	//    14
	resetn_hsusb0_phy               : 1,	//    15
	                                : 5,	// 16:20 reserved
	resetn_ssusb1_core              : 1,	//    21
	resetn_ssusb1_bus               : 1,	//    22
	resetn_ssusb1_phy               : 1,	//    23
	                                : 5,	// 24:28 reserved
	resetn_ssusb0_core              : 1,	//    29
	resetn_ssusb0_bus               : 1,	//    30
	resetn_ssusb0_phy               : 1;	//    31
} PHY_CTLR_RST;

/*-----------------------------------------------------------------------------
	0x0008 ss0_ctlr_ctl ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	fladj_30mhz_reg                 : 6,	//  0: 5
	xhci_revision                   : 1,	//     6
	xhc_bme                         : 1,	//     7
	hub_vbus_inv                    : 1,	//     8
	hub_port_perm_attach            : 2,	//  9:10
	hub_oc_inv                      : 1,	//    11
	host_u3_port_disable            : 1,	//    12
	host_u2_port_disable            : 1,	//    13
	host_port_power_control_present : 1,	//    14
	host_msi_enable                 : 1,	//    15
	bigendian_gs                    : 1;	//    16
} SS0_CTLR_CTL;

/*-----------------------------------------------------------------------------
	0x000c ss0_ctlr_dbg0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	debug_info_l                    ;   	// 31: 0
} SS0_CTLR_DBG0;

/*-----------------------------------------------------------------------------
	0x0010 ss0_ctlr_dbg1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	debug_info_h                    :26;	//  0:25
} SS0_CTLR_DBG1;

/*-----------------------------------------------------------------------------
	0x0014 ss0_ctlr_logic_trc0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	logic_trace_l                   ;   	// 31: 0
} SS0_CTLR_LOGIC_TRC0;

/*-----------------------------------------------------------------------------
	0x0018 ss0_ctlr_logic_trc1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	logic_trace_h                   ;   	// 31: 0
} SS0_CTLR_LOGIC_TRC1;

/*-----------------------------------------------------------------------------
	0x001c ss0_ctlr_cur_belt ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	host_current_belt               :12;	//  0:11
} SS0_CTLR_CUR_BELT;

/*-----------------------------------------------------------------------------
	0x0040 ss0_phy_ctl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	mpll_refssc_clk_en              : 1,	//     1
	fsel                            : 6,	//  2: 7
	retenablen                      : 1,	//     8
	commononn                       : 1,	//     9
	lane0_tx2rx_loopbk              : 1,	//    10
	lane0_ext_pclk_req              : 1,	//    11
	                                : 5,	// 12:16 reserved
	bypasssel                       : 1,	//    17
	bypassdmen                      : 1,	//    18
	bypassdpen                      : 1,	//    19
	bypassdmdata                    : 1,	//    20
	bypassdpdata                    : 1,	//    21
	adpprbenb                       : 1,	//    22
	adpdischrg                      : 1,	//    23
	adpchrg                         : 1,	//    24
	otgdisable                      : 1,	//    25
	vatestenb                       : 2,	// 26:27
	test_powerdown_ssp              : 1,	//    28
	test_powerdown_hsp              : 1,	//    29
	loopbkenb                       : 1,	//    30
	phy_atereset                    : 1;	//    31
} SS0_PHY_CTL1;

/*-----------------------------------------------------------------------------
	0x0044 ss0_phy_ctl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	sqrxtune                        : 3,	//  0: 2
	otgtune                         : 3,	//  3: 5
	compdistune                     : 3,	//  6: 8
	ssc_ref_clk_sel                 : 9,	//  9:17
	ssc_range                       : 3,	// 18:20
	ssc_en                          : 1,	//    21
	ref_use_pad                     : 1,	//    22
	ref_ssp_en                      : 1,	//    23
	ref_clkdiv2                     : 1,	//    24
	mpll_multiplier                 : 7;	// 25:31
} SS0_PHY_CTL2;

/*-----------------------------------------------------------------------------
	0x0048 ss0_phy_ctl3 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	tx_vboost_lvl                   : 3,	//  0: 2
	                                : 1,	//     3 reserved
	pcs_tx_deemph_3p5db             : 6,	//  4: 9
	los_level                       : 5,	// 10:14
	txvreftune                      : 4,	// 15:18
	txrisetune                      : 2,	// 19:20
	txrestune                       : 2,	// 21:22
	txpreemppulsetune               : 1,	//    23
	txpreempamptune                 : 2,	// 24:25
	txhsxvtune                      : 2,	// 26:27
	txfslstune                      : 4;	// 28:31
} SS0_PHY_CTL3;

/*-----------------------------------------------------------------------------
	0x004c ss0_phy_ctl4 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	rtune_req                       : 1,	//     0
	los_bias                        : 3,	//  1: 3
	lane0_tx_term_offset            : 5,	//  4: 8
	pcs_tx_swing_full               : 7,	//  9:15
	pcs_tx_deemph_6db               : 6;	// 16:21
} SS0_PHY_CTL4;

/*-----------------------------------------------------------------------------
	0x0050 ss0_phy_ctl5 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	cr_ack                          : 1,	//     0
	rtune_ack                       : 1,	//     1
	                                :14,	//  2:15 reserved
	cr_data_out                     :16;	// 16:31
} SS0_PHY_CTL5;

/*-----------------------------------------------------------------------------
	0x0054 ss0_phy_ctl6 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	cr_data_in                      :16,	//  0:15
	cr_write                        : 1,	//    16
	cr_read                         : 1,	//    17
	cr_cap_data                     : 1,	//    18
	cr_cap_addr                     : 1;	//    19
} SS0_PHY_CTL6;

/*-----------------------------------------------------------------------------
	0x0080 ss1_ctlr_ctl ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	fladj_30mhz_reg                 : 6,	//  0: 5
	xhci_revision                   : 1,	//     6
	xhc_bme                         : 1,	//     7
	hub_vbus_inv                    : 1,	//     8
	hub_port_perm_attach            : 2,	//  9:10
	hub_oc_inv                      : 1,	//    11
	host_u3_port_disable            : 1,	//    12
	host_u2_port_disable            : 1,	//    13
	host_port_power_control_present : 1,	//    14
	host_msi_enable                 : 1,	//    15
	bigendian_gs                    : 1;	//    16
} SS1_CTLR_CTL;

/*-----------------------------------------------------------------------------
	0x0084 ss1_ctlr_dbg0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	debug_info_l                    ;   	// 31: 0
} SS1_CTLR_DBG0;

/*-----------------------------------------------------------------------------
	0x0088 ss1_ctlr_dbg1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	debug_info_h                    ;   	// 31: 0
} SS1_CTLR_DBG1;

/*-----------------------------------------------------------------------------
	0x008c ss1_ctlr_logic_trc0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	logic_trace_l                   ;   	// 31: 0
} SS1_CTLR_LOGIC_TRC0;

/*-----------------------------------------------------------------------------
	0x0090 ss1_ctlr_logic_trc1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	logic_trace_h                   ;   	// 31: 0
} SS1_CTLR_LOGIC_TRC1;

/*-----------------------------------------------------------------------------
	0x0094 ss1_ctlr_cur_belt ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	host_current_belt               :12;	//  0:11
} SS1_CTLR_CUR_BELT;

/*-----------------------------------------------------------------------------
	0x00a0 ss1_phy_ctl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	mpll_refssc_clk_en              : 1,	//     1
	fsel                            : 6,	//  2: 7
	retenablen                      : 1,	//     8
	commononn                       : 1,	//     9
	lane0_tx2rx_loopbk              : 1,	//    10
	lane0_ext_pclk_req              : 1,	//    11
	                                : 5,	// 12:16 reserved
	bypasssel                       : 1,	//    17
	bypassdmen                      : 1,	//    18
	bypassdpen                      : 1,	//    19
	bypassdmdata                    : 1,	//    20
	bypassdpdata                    : 1,	//    21
	adpprbenb                       : 1,	//    22
	adpdischrg                      : 1,	//    23
	adpchrg                         : 1,	//    24
	otgdisable                      : 1,	//    25
	vatestenb                       : 2,	// 26:27
	test_powerdown_ssp              : 1,	//    28
	test_powerdown_hsp              : 1,	//    29
	loopbkenb                       : 1,	//    30
	phy_atereset                    : 1;	//    31
} SS1_PHY_CTL1;

/*-----------------------------------------------------------------------------
	0x00a4 ss1_phy_ctl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	sqrxtune                        : 3,	//  0: 2
	otgtune                         : 3,	//  3: 5
	compdistune                     : 3,	//  6: 8
	ssc_ref_clk_sel                 : 9,	//  9:17
	ssc_range                       : 3,	// 18:20
	ssc_en                          : 1,	//    21
	ref_use_pad                     : 1,	//    22
	ref_ssp_en                      : 1,	//    23
	ref_clkdiv2                     : 1,	//    24
	mpll_multiplier                 : 7;	// 25:31
} SS1_PHY_CTL2;

/*-----------------------------------------------------------------------------
	0x00a8 ss1_phy_ctl3 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	tx_vboost_lvl                   : 3,	//  0: 2
	                                : 1,	//     3 reserved
	pcs_tx_deemph_3p5db             : 6,	//  4: 9
	los_level                       : 5,	// 10:14
	txvreftune                      : 4,	// 15:18
	txrisetune                      : 2,	// 19:20
	txrestune                       : 2,	// 21:22
	txpreemppulsetune               : 1,	//    23
	txpreempamptune                 : 2,	// 24:25
	txhsxvtune                      : 2,	// 26:27
	txfslstune                      : 4;	// 28:31
} SS1_PHY_CTL3;

/*-----------------------------------------------------------------------------
	0x00ac ss1_phy_ctl4 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	rtune_req                       : 1,	//     0
	los_bias                        : 3,	//  1: 3
	lane0_tx_term_offset            : 5,	//  4: 8
	pcs_tx_swing_full               : 7,	//  9:15
	pcs_tx_deemph_6db               : 6;	// 16:21
} SS1_PHY_CTL4;

/*-----------------------------------------------------------------------------
	0x00b0 ss1_phy_ctl5 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	cr_ack                          : 1,	//     0
	rtune_ack                       : 1,	//     1
	                                :14,	//  2:15 reserved
	cr_data_out                     :16;	// 16:31
} SS1_PHY_CTL5;

/*-----------------------------------------------------------------------------
	0x00b4 ss1_phy_ctl6 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	cr_data_in                      :16,	//  0:15
	cr_write                        : 1,	//    16
	cr_read                         : 1,	//    17
	cr_cap_data                     : 1,	//    18
	cr_cap_addr                     : 1;	//    19
} SS1_PHY_CTL6;

/*-----------------------------------------------------------------------------
	0x00c0 hs0_ctlr_ctl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	ss_hubsetup_min                 : 1,	//     0
	endian_ahbms_ohci_bufacc        : 1,	//     1
	endian_ahbms_ehci_bufacc        : 1,	//     2
	endian_ahbms_ohci               : 1,	//     3
	endian_ahbms_ehci               : 1,	//     4
	endian_ahbsl                    : 1,	//     5
	app_prt_ovrcur                  : 1,	//     6
	ss_ena_incrx_align              : 1,	//     7
	ss_ena_incr4                    : 1,	//     8
	ss_ena_incr8                    : 1,	//     9
	ss_ena_incr16                   : 1,	//    10
	ss_autoppd_on_overcur_en        : 1,	//    11
	ss_resume_utmi_pls_dis          : 1,	//    12
	ss_utmi_backward_enb            : 1,	//    13
	ss_word_if                      : 1,	//    14
	ss_fladj_val                    : 6,	// 15:20
	ss_fladj_val_host               : 6,	// 21:26
	ss_simulation_mode              : 1,	//    27
	ohci_susp_lgcy                  : 1,	//    28
	app_start_clk_i                 : 1;	//    29
} HS0_CTLR_CTL1;

/*-----------------------------------------------------------------------------
	0x00c4 hs0_ctlr_ctl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	ehci_xfer_cnt                   :11,	//  0:10
	ehci_prt_pwr                    : 1,	//    11
	ohci_bufacc                     : 1,	//    12
	ohci_sof_n                      : 1,	//    13
	ohci_smi_n                      : 1,	//    14
	ohci_rmtwkp                     : 1,	//    15
	ohci_rwe                        : 1,	//    16
	ohci_drwe                       : 1,	//    17
	ohci_globalsuspend              : 1,	//    18
	ehci_xfer_prdc                  : 1,	//    19
	ehci_usbsts                     : 6,	// 20:25
	ehci_lpsmc_status               : 4,	// 26:29
	ehci_pme_status                 : 1,	//    30
	ehci_bufacc                     : 1;	//    31
} HS0_CTLR_CTL2;

/*-----------------------------------------------------------------------------
	0x00c8 hs0_ctlr_ctl3 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	ohci_0_css                      : 1,	//     0
	ehci_power_state_ack            : 1;	//     1
} HS0_CTLR_CTL3;

/*-----------------------------------------------------------------------------
	0x00cc hs0_ctlr_ctl4 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	hsusb0_mon                      ;   	// 31: 0
} HS0_CTLR_CTL4;

/*-----------------------------------------------------------------------------
	0x00e0 hs0_phy_ctl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 2,	//  0: 1 reserved
	fsel                            : 3,	//  2: 4
	txrestune                       : 2,	//  5: 6
	txhsxvtune                      : 2,	//  7: 8
	txvreftune                      : 4,	//  9:12
	txrisetune                      : 2,	// 13:14
	txpreemppulsetune               : 1,	//    15
	txpreempamptune                 : 2,	// 16:17
	txfslstune                      : 4,	// 18:21
	sqrxtune                        : 3,	// 22:24
	compdistune                     : 3,	// 25:27
	commononn                       : 1,	//    28
	refclksel                       : 2,	// 29:30
	port_reset                      : 1;	//    31
} HS0_PHY_CTL1;

/*-----------------------------------------------------------------------------
	0x00e4 hs0_phy_ctl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	bypasssel                       : 1,	//     0
	bypassdmen                      : 1,	//     1
	bypassdpen                      : 1,	//     2
	bypassdmdata                    : 1,	//     3
	bypassdpdata                    : 1,	//     4
	otgdisable                      : 1,	//     5
	vatestenv                       : 2,	//  6: 7
	loopbkenb                       : 1,	//     8
	siddq                           : 1,	//     9
	                                : 6,	// 10:15 reserved
	testdatain                      : 8,	// 16:23
	testaddr                        : 4,	// 24:27
	testdataoutsel                  : 1,	//    28
	                                : 2,	// 29:30 reserved
	atereset                        : 1;	//    31
} HS0_PHY_CTL2;

/*-----------------------------------------------------------------------------
	0x00ec hs0_phy_ctl3 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	testdataout                     : 4;	//  0: 3
} HS0_PHY_CTL3;

/*-----------------------------------------------------------------------------
	0x00f0 hs1_ctlr_ctl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	ehci_xfer_cnt                   :11,	//  0:10
	ehci_prt_pwr                    : 1,	//    11
	ohci_bufacc                     : 1,	//    12
	ohci_sof_n                      : 1,	//    13
	ohci_smi_n                      : 1,	//    14
	ohci_rmtwkp                     : 1,	//    15
	ohci_rwe                        : 1,	//    16
	ohci_drwe                       : 1,	//    17
	ohci_globalsuspend              : 1,	//    18
	ehci_xfer_prdc                  : 1,	//    19
	ehci_usbsts                     : 6,	// 20:25
	ehci_lpsmc_status               : 4,	// 26:29
	ehci_pme_status                 : 1,	//    30
	ehci_bufacc                     : 1;	//    31
} HS1_CTLR_CTL2;

/*-----------------------------------------------------------------------------
	0x00f4 hs1_ctlr_ctl3 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	ohci_0_css                      : 1,	//     0
	ehci_power_state_ack            : 1;	//     1
} HS1_CTLR_CTL3;

/*-----------------------------------------------------------------------------
	0x00f8 hs1_ctlr_ctl4 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	hsusb1_mon                      ;   	// 31: 0
} HS1_CTLR_CTL4;

/*-----------------------------------------------------------------------------
	0x0100 hs1_ctlr_ctl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	ss_hubsetup_min                 : 1,	//     0
	endian_ahbms_ohci_bufacc        : 1,	//     1
	endian_ahbms_ehci_bufacc        : 1,	//     2
	endian_ahbms_ohci               : 1,	//     3
	endian_ahbms_ehci               : 1,	//     4
	endian_ahbsl                    : 1,	//     5
	app_prt_ovrcur                  : 1,	//     6
	ss_ena_incrx_align              : 1,	//     7
	ss_ena_incr4                    : 1,	//     8
	ss_ena_incr8                    : 1,	//     9
	ss_ena_incr16                   : 1,	//    10
	ss_autoppd_on_overcur_en        : 1,	//    11
	ss_resume_utmi_pls_dis          : 1,	//    12
	ss_utmi_backward_enb            : 1,	//    13
	ss_word_if                      : 1,	//    14
	ss_fladj_val                    : 6,	// 15:20
	ss_fladj_val_host               : 6,	// 21:26
	ss_simulation_mode              : 1,	//    27
	ohci_susp_lgcy                  : 1,	//    28
	app_start_clk_i                 : 1;	//    29
} HS1_CTLR_CTL1;

typedef struct {
	PHY_CTLR_RST                    	phy_ctlr_rst                    ;	// 0x0000 : ''
	UINT32                          	                 __rsvd_00[   1];	// 0x0004
	SS0_CTLR_CTL                    	ss0_ctlr_ctl                    ;	// 0x0008 : ''
	SS0_CTLR_DBG0                   	ss0_ctlr_dbg0                   ;	// 0x000c : ''
	SS0_CTLR_DBG1                   	ss0_ctlr_dbg1                   ;	// 0x0010 : ''
	SS0_CTLR_LOGIC_TRC0             	ss0_ctlr_logic_trc0             ;	// 0x0014 : ''
	SS0_CTLR_LOGIC_TRC1             	ss0_ctlr_logic_trc1             ;	// 0x0018 : ''
	SS0_CTLR_CUR_BELT               	ss0_ctlr_cur_belt               ;	// 0x001c : ''
	UINT32                          	                 __rsvd_01[   8];	// 0x0020 ~ 0x003c
	SS0_PHY_CTL1                    	ss0_phy_ctl1                    ;	// 0x0040 : ''
	SS0_PHY_CTL2                    	ss0_phy_ctl2                    ;	// 0x0044 : ''
	SS0_PHY_CTL3                    	ss0_phy_ctl3                    ;	// 0x0048 : ''
	SS0_PHY_CTL4                    	ss0_phy_ctl4                    ;	// 0x004c : ''
	SS0_PHY_CTL5                    	ss0_phy_ctl5                    ;	// 0x0050 : ''
	SS0_PHY_CTL6                    	ss0_phy_ctl6                    ;	// 0x0054 : ''
	UINT32                          	                 __rsvd_02[  10];	// 0x0058 ~ 0x007c
	SS1_CTLR_CTL                    	ss1_ctlr_ctl                    ;	// 0x0080 : ''
	SS1_CTLR_DBG0                   	ss1_ctlr_dbg0                   ;	// 0x0084 : ''
	SS1_CTLR_DBG1                   	ss1_ctlr_dbg1                   ;	// 0x0088 : ''
	SS1_CTLR_LOGIC_TRC0             	ss1_ctlr_logic_trc0             ;	// 0x008c : ''
	SS1_CTLR_LOGIC_TRC1             	ss1_ctlr_logic_trc1             ;	// 0x0090 : ''
	SS1_CTLR_CUR_BELT               	ss1_ctlr_cur_belt               ;	// 0x0094 : ''
	UINT32                          	                 __rsvd_03[   2];	// 0x0098 ~ 0x009c
	SS1_PHY_CTL1                    	ss1_phy_ctl1                    ;	// 0x00a0 : ''
	SS1_PHY_CTL2                    	ss1_phy_ctl2                    ;	// 0x00a4 : ''
	SS1_PHY_CTL3                    	ss1_phy_ctl3                    ;	// 0x00a8 : ''
	SS1_PHY_CTL4                    	ss1_phy_ctl4                    ;	// 0x00ac : ''
	SS1_PHY_CTL5                    	ss1_phy_ctl5                    ;	// 0x00b0 : ''
	SS1_PHY_CTL6                    	ss1_phy_ctl6                    ;	// 0x00b4 : ''
	UINT32                          	                 __rsvd_04[   2];	// 0x00b8 ~ 0x00bc
	HS0_CTLR_CTL1                   	hs0_ctlr_ctl1                   ;	// 0x00c0 : ''
	HS0_CTLR_CTL2                   	hs0_ctlr_ctl2                   ;	// 0x00c4 : ''
	HS0_CTLR_CTL3                   	hs0_ctlr_ctl3                   ;	// 0x00c8 : ''
	HS0_CTLR_CTL4                   	hs0_ctlr_ctl4                   ;	// 0x00cc : ''
	UINT32                          	                 __rsvd_05[   4];	// 0x00d0 ~ 0x00dc
	HS0_PHY_CTL1                    	hs0_phy_ctl1                    ;	// 0x00e0 : ''
	HS0_PHY_CTL2                    	hs0_phy_ctl2                    ;	// 0x00e4 : ''
	UINT32                          	                 __rsvd_06[   1];	// 0x00e8
	HS0_PHY_CTL3                    	hs0_phy_ctl3                    ;	// 0x00ec : ''
	HS1_CTLR_CTL2                   	hs1_ctlr_ctl2                   ;	// 0x00f0 : ''
	HS1_CTLR_CTL3                   	hs1_ctlr_ctl3                   ;	// 0x00f4 : ''
	HS1_CTLR_CTL4                   	hs1_ctlr_ctl4                   ;	// 0x00f8 : ''
	UINT32                          	                 __rsvd_07[   1];	// 0x00fc
	HS1_CTLR_CTL1                   	hs1_ctlr_ctl1                   ;	// 0x0100 : ''
} USB_TOP_CTRL_REG_T;

#ifdef __cplusplus
}
#endif

#endif	/* _#MOD#_REG_H_ */

