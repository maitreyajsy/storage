#ifndef __ARCH_TIMERS_H__
#define __ARCH_TIMERS_H__

#include <arm/timers.h>

#define TIMER0_PRESCALER	TIMER_CTRL_DIV1
#define TIMER0_INTERVAL  	(TIMER_CLK / TIMER_FREQ)
#define TIMER0_RELOAD    	(TIMER0_INTERVAL >> TIMER0_PRESCALER)

#define TIMER1_RELOAD		TIMER_MAX_LOAD_VALUE

#define TIMER(x)			(timer_t*)(LG1311_TIMER0_1_BASE + sizeof(timer_t) * (x))


#define LOCAL_TIMER(x)		(local_timer_t*)(LG1311_LOCALTIMER_BASE)

#endif /* __ARCH_TIMERS_H__ */
