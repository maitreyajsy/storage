#ifndef __CPU_EXT_H__
#define __CPU_EXT_H__

#ifndef __ASSEMBLY__
#ifndef FAST
 # define	FAST	register
#endif

typedef unsigned long	INSTR;
typedef	void			(*pVOIDFARGPTR)		(int);
typedef	int				(*pPRINT_FUNC)		(char *fmt, ...);

#define get_lr(_x) 	{ __asm__ ("mov %0, lr"   : /* no output */ :"r" (_x)); }
#define get_ra(_x) 	{ __asm__ ("mov %0, lr"   : /* no output */ :"r" (_x)); }
#define get_sp(_x) 	{ __asm__ ("mov %0, sp"   : /* no output */ :"r" (_x)); }
#define get_pc(_x) 	{ __asm__ ("mov %0, pc"   : /* no output */ :"r" (_x)); }

#define str_lr(_x) 	{ __asm__ ("str lr, [%0]" : /* no output */ :"r" (_x)); }
#define str_ra(_x) 	{ __asm__ ("str lr, [%0]" : /* no output */ :"r" (_x)); }
#define str_sp(_x) 	{ __asm__ ("str sp, [%0]" : /* no output */ :"r" (_x)); }
#define str_pc(_x) 	{ __asm__ ("str pc, [%0]" : /* no output */ :"r" (_x)); }

#define REG_PC_IDX	(15)
#define REG_LR_IDX	(14)
#define REG_SP_IDX	(13)

extern uint32_t			_start[];
extern uint32_t			__data_start__[];
#define _etext			__data_start__

static inline int isValidPc(uint32_t *pc)
{
	if (( (uint32_t)pc >= (uint32_t)_start) &&
		( (uint32_t)pc <= (uint32_t)_etext) &&
		(((uint32_t)pc & 0x3) == 0      )
	   )
		return 1;

	return 0;
}

#endif/*__ASSEMBLY__*/

#endif/*__CPU_EXT_H__*/
