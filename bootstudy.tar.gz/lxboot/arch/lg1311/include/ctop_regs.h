#ifndef __ARCH_CTOP_REGS_HEAD_H__
#define __ARCH_CTOP_REGS_HEAD_H__

#include <arch/a0/ctop_regs.h>
#include <arch/b0/ctop_regs.h>
#include <arch/b0/usb_top_regs.h>


#define CTOP_CTRL_READ(_top,_r)			(*((uint32_t*)(&(_top)->_r)))
#define CTOP_CTRL_WRITE(_top,_r,_v)		(*((uint32_t*)(&(_top)->_r)) = _v)


/* M14A0 */
extern volatile CTOP_CTRL_REG_T *ctop_regs;

/* M14B0 */
extern volatile CTOP_TOP_REG_M14B0_T	*ctop_top_regs;
extern volatile CTOP_LEFT_REG_M14B0_T	*ctop_left_regs;
extern volatile CTOP_RIGHT_REG_M14B0_T	*ctop_right_regs;

#endif	// __ARCH_CTOP_REGS_HEAD_H__
