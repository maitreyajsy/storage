/*************************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 **************************************************************************************************/


/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	ks.hyun@lge.com 	Release initial codes for lxboot in arch/lg1152/include folder.
|	? 	? 	2011	yw.kim@lge.com		Copy this file from arch/lg1152/include to arch/lg1154/include
|										for evaluation.
|	Feb	26	2012	yw.kim@lge.com		Add read_cp15_ttbr0(), read_cp15_ttbr1(), read_cp15_ttbcr() and
|	                                    v7_flush_tlb_range() functions to insert mmu entry dynamically.
| 	Mar	04	2012	yw.kim@lge.com		Add v7_read_nsacr(), v7_write_nsacr(), v7_read_actlr(), v7_write_actlr()
|										v7_read_scr() and v7_write_scr() macro for normal world cpu1 initialization.
|
|============================================================================================================*/

#ifndef __ARCH_CPU_H__
#define __ARCH_CPU_H__

#include <arm/registers.h>
#include <arm/cpu.h>
#include <arch/cpu_ext.h>

#ifndef __ASSEMBLY__

// in cacheops.S
void flush_dcache(void);
void clean_dcache(void);
void inv_dcache(void);

void dcache_enable(void);
void dcache_disable(void);


// in start.S
void scu_disable(void);
void scu_invalidate(void);
void scu_enable(void);
void cpu_loop(uint32_t count);

// in arch_cpu.c
int ace_reg_read(uint8_t slave, uint8_t addr, uint8_t *data);
int ace_reg_write(uint8_t slave, uint8_t addr, uint8_t data);

// in dmac.c
void DTVSOC_DMACInit( void );
void DTVSOC_DMAC_M_Pwr_Up_LLI( void );

// in arch_ctop.c
void ctop_detect_clk(void);
uint32_t ctop_get_cpu_clk(void);
uint32_t ctop_get_pclk(void);
uint32_t ctop_get_m0_clk(void);
uint32_t ctop_get_m1_clk(void);

uint32_t ctop_xhci_possible(void);


// in arch_ddr.c
void ddr_ctrl_init(void);

// in arch_shadown.c
int shadow(void);

// in arch_memprot.c
void memprot_init(void);

//in arch_addr_switch
void set_addr_switch(void);

// arch_usb.c
void arch_usb_init(void);
void arch_usb_start(void);
void arch_usb_stop(void);

#endif	// #ifndef __ASSEMBLY__

#endif /* __ARCH_CPU_H__ */
