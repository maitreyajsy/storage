#ifndef __ARCH_PWM_H__
#define __ARCH_PWM_H__

#ifndef BOOLEAN
#define BOOLEAN	int
#endif
#ifndef DTV_STATUS_T
#define DTV_STATUS_T	int
#endif

/* ############### BE PWM  ################ */

/**
 * BE PWM port number index
 *
 */
typedef enum {
	BE_PWM0 = 0, 	///< pwm port0
	BE_PWM1,		///< pwm port1
	BE_PWM2,		///< pwm port2
	BE_PWM3,		///< pwm port3
	BE_PWM_MAX
} BE_PWM_ID_T;

/**
 * BE PWM control index
 *
 */
typedef enum {
	BE_PWM_LOW	= 0,			///< PWM Output Signal Cotrol - Low
	BE_PWM_NORMAL,			///< PWM Output Signal Cotrol - Normal
	BE_PWM_HIGH,				///< PWM Output Signal Cotrol - High
	BE_PWM_INVERSION,			///< PWM Output Signal Cotrol - Inversion
} BE_PWM_OUT_CTRL_T;

/**
 * BE PWM output control parameter.
 *
 */
typedef struct
{
	BE_PWM_ID_T			port;		///< PWM number: PWM0~2.
	BOOLEAN					enable;
	BOOLEAN					pwmMode;	///< freerun(0) / locking(1) mode
	BE_PWM_OUT_CTRL_T		pwmOutput;	///< PWM Output signal control
	BOOLEAN					pwmScanning;
} BE_PWM_CTRL_T;

/**
 * BE PWM parameter.
 * Parameter for PWM Frequency Set.
 */
typedef struct
{
	BE_PWM_ID_T	port;		///< PWM number: PWM0~2.
	UINT32			frequency;	///< PWM Output Frequency Set
} BE_PWM_FREQ_T;

/**
 * BE PWM parameter.
 *
*/
typedef struct
{
	BE_PWM_ID_T	port;		///< PWM number: PWM0~2.
	UINT16			duty;		///< Set duty of PWM (0 ~ 255).
	UINT16			offset;		///< PWM Start Position (1~1125).
} BE_PWM_DUTY_T;

/**
 * BE PWM parameter.
 * get PWM Duty value for external port(FRC) .
 *
*/
typedef struct
{
	UINT16			frequency;		///< current frequency (locking mode frequncy)
    	UINT16			duty;		    	///< current duty of PWM (0 ~ 255).
} BE_EXTERNAL_PWM_T;

/*-----------------------------------------------------------------------------
	0x0370 dvo_pwm0_ctrl0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_en                         : 1,	//     0
	pwm0_freq_mode                  : 3,	//  1: 3
	pwm0_resolution                 : 2,	//  4: 5
	pwm0_inv                        : 1,	//     6
	pwm0_sel                        : 1,	//     7
	pwm0_width_falling_pos          :24;	//  8:31
} M14B0_FRC_DVO_PWM0_CTRL0_T;

/*-----------------------------------------------------------------------------
	0x0374 dvo_pwm0_ctrl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_free_width                 :24;	//  0:23
} M14B0_FRC_DVO_PWM0_CTRL1_T;

/*-----------------------------------------------------------------------------
	0x0378 dvo_pwm0_ctrl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_intr_mask                  :16,	//  0:15
	pwm0_method                     : 1,	//    16
	_rsvd_00                                : 3,	// 17:19 reserved
	pwm0_mux                        : 2,	// 20:21
	_rsvd_01                                : 8,	// 22:29 reserved
	pwm0_fc_h_disp                  : 1,	//    30
	pwm0_fc_l_disp                  : 1;	//    31
} M14B0_FRC_DVO_PWM0_CTRL2_T;

/*-----------------------------------------------------------------------------
	0x037C dvo_pwm1_ctrl0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm1_en                         : 1,	//     0
	pwm1_freq_mode                  : 3,	//  1: 3
	pwm1_resolution                 : 2,	//  4: 5
	pwm1_inv                        : 1,	//     6
	pwm1_sel                        : 1,	//     7
	pwm1_width_falling_pos          :24;	//  8:31
} M14B0_FRC_DVO_PWM1_CTRL0_T;

/*-----------------------------------------------------------------------------
	0x0380 dvo_pwm1_ctrl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm1_free_width                 :24;	//  0:23
} M14B0_FRC_DVO_PWM1_CTRL1_T;

/*-----------------------------------------------------------------------------
	0x0384 dvo_pwm1_ctrl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm1_intr_mask                  :16,	//  0:15
	pwm1_method                     : 1,	//    16
	_rsvd_00                                : 3,	// 17:19 reserved
	pwm1_mux                        : 2,	// 20:21
	_rsvd_01                                : 8,	// 22:29 reserved
	pwm1_fc_h_disp                  : 1,	//    30
	pwm1_fc_l_disp                  : 1;	//    31
} M14B0_FRC_DVO_PWM1_CTRL2_T;

/*-----------------------------------------------------------------------------
	0x0388 dvo_pwm2_ctrl0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm2_en                         : 1,	//     0
	pwm2_freq_mode                  : 3,	//  1: 3
	pwm2_resolution                 : 2,	//  4: 5
	pwm2_inv                        : 1,	//     6
	pwm2_sel                        : 1,	//     7
	pwm2_width_falling_pos          :24;	//  8:31
} M14B0_FRC_DVO_PWM2_CTRL0_T;

/*-----------------------------------------------------------------------------
	0x038C dvo_pwm2_ctrl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm2_free_width                 :24;	//  0:23
} M14B0_FRC_DVO_PWM2_CTRL1_T;

/*-----------------------------------------------------------------------------
	0x0390 dvo_pwm2_ctrl2 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm2_intr_mask                  :16,	//  0:15
	pwm2_method                     : 1,	//    16
	_rsvd_00                                : 3,	// 17:19 reserved
	pwm2_mux                        : 2,	// 20:21
	_rsvd_01                                : 8,	// 22:29 reserved
	pwm2_fc_h_disp                  : 1,	//    30
	pwm2_fc_l_disp                  : 1;	//    31
} M14B0_FRC_DVO_PWM2_CTRL2_T;

/*-----------------------------------------------------------------------------
	0x0394 dvo_pwm3_ctrl0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_en                         : 1,	//     0
	pwm3_freq_mode                  : 3,	//  1: 3
	_rsvd                                : 4,	//  4: 7 reserved
	pwm3_threshold                  :24;	//  8:31
} M14B0_FRC_DVO_PWM3_CTRL0_T;

/*-----------------------------------------------------------------------------
	0x0398 dvo_pwm3_ctrl1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_intr_mask1                 : 8,	//  0: 7
	_rsvd_00                                : 8,	//  8:15 reserved
	pwm3_intr_mask0                 : 1,	//    16
	_rsvd_01                                : 3,	// 17:19 reserved
	pwm3_in_mux                     : 2;	// 20:21
} M14B0_FRC_DVO_PWM3_CTRL1_T;

/*-----------------------------------------------------------------------------
	0x039c dvo_pwm3_0_low ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_0_low                      :24;	//  0:23
} M14B0_FRC_DVO_PWM3_0_LOW_T;

/*-----------------------------------------------------------------------------
	0x03a0 dvo_pwm3_0_high ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_0_high                     :24;	//  0:23
} M14B0_FRC_DVO_PWM3_0_HIGH_T;

/*-----------------------------------------------------------------------------
	0x03a4 dvo_pwm3_1_low ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_1_low                      :24;	//  0:23
} M14B0_FRC_DVO_PWM3_1_LOW_T;

/*-----------------------------------------------------------------------------
	0x03a8 dvo_pwm3_1_high ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_1_high                     :24;	//  0:23
} M14B0_FRC_DVO_PWM3_1_HIGH_T;

/*-----------------------------------------------------------------------------
	0x03ac dvo_pwm3_2_low ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_2_low                      :24;	//  0:23
} M14B0_FRC_DVO_PWM3_2_LOW_T;

/*-----------------------------------------------------------------------------
	0x03b0 dvo_pwm3_2_high ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_2_high                     :24;	//  0:23
} M14B0_FRC_DVO_PWM3_2_HIGH_T;

/*-----------------------------------------------------------------------------
	0x03b4 dvo_pwm3_3_low ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_3_low                      :24;	//  0:23
} M14B0_FRC_DVO_PWM3_3_LOW_T;

/*-----------------------------------------------------------------------------
	0x03b8 dvo_pwm3_3_high ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm3_3_high                     :24;	//  0:23
} M14B0_FRC_DVO_PWM3_3_HIGH_T;

/*-----------------------------------------------------------------------------
	0x03dc dvo_pwm_v_load_write ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_v_we                       : 1,	//     0
	pwm1_v_we                       : 1,	//     1
	pwm2_v_we                       : 1,	//     2
	pwm0_v_sub_we                   : 1,	//     3
	pwm1_v_sub_we                   : 1,	//     4
	pwm2_v_sub_we                   : 1,	//     5
	_rsvd                                : 2,	//  6: 7 reserved
	pwm0_v_sub_f_we                 : 1,	//     8
	pwm1_v_sub_f_we                 : 1,	//     9
	pwm2_v_sub_f_we                 : 1;	//    10
} M14B0_FRC_DVO_PWM_V_LOAD_WRITE_T;

/*-----------------------------------------------------------------------------
	0x03e0 dvo_pwm0_v_r ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_v_r                        :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm0_v_r_id                     : 4;	// 28:31
} M14B0_FRC_DVO_PWM0_V_R_T;

/*-----------------------------------------------------------------------------
	0x03e4 dvo_pwm0_v_f ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_v_f                        :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm0_v_f_id                     : 4;	// 28:31
} M14B0_FRC_DVO_PWM0_V_F_T;

/*-----------------------------------------------------------------------------
	0x03e8 dvo_pwm1_v_r ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm1_v_r                        :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm1_v_r_id                     : 4;	// 28:31
} M14B0_FRC_DVO_PWM1_V_R_T;

/*-----------------------------------------------------------------------------
	0x03ec dvo_pwm1_v_f ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm1_v_f                        :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm1_v_f_id                     : 4;	// 28:31
} M14B0_FRC_DVO_PWM1_V_F_T;

/*-----------------------------------------------------------------------------
	0x03f0 dvo_pwm2_v_r ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm2_v_r                        :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm2_v_r_id                     : 4;	// 28:31
} M14B0_FRC_DVO_PWM2_V_R_T;

/*-----------------------------------------------------------------------------
	0x03f4 dvo_pwm2_v_f ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm2_v_f                        :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm2_v_f_id                     : 4;	// 28:31
} M14B0_FRC_DVO_PWM2_V_F_T;

/*-----------------------------------------------------------------------------
	0x03f8 dvo_pwm0_v_sub_r ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_v_sub                      :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm0_v_sub_id                   : 4;	// 28:31
} M14B0_FRC_DVO_PWM0_V_SUB_R_T;

/*-----------------------------------------------------------------------------
	0x03fc dvo_pwm1_v_sub_r ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm1_v_sub                      :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm1_v_sub_id                   : 4;	// 28:31
} M14B0_FRC_DVO_PWM1_V_SUB_R_T;

/*-----------------------------------------------------------------------------
	0x0400 dvo_pwm2_v_sub_r ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm2_v_sub                      :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm2_v_sub_id                   : 4;	// 28:31
} M14B0_FRC_DVO_PWM2_V_SUB_R_T;

/*-----------------------------------------------------------------------------
	0x043c dvo_pwm0_v_sub_f ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm0_v_sub_f                    :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm0_v_sub_f_id                 : 4;	// 28:31
} M14B0_FRC_DVO_PWM0_V_SUB_F_T;

/*-----------------------------------------------------------------------------
	0x0440 dvo_pwm1_v_sub_f ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm1_v_sub_f                    :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm1_v_sub_f_id                 : 4;	// 28:31
} M14B0_FRC_DVO_PWM1_V_SUB_F_T;

/*-----------------------------------------------------------------------------
	0x0444 dvo_pwm2_v_sub_f ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pwm2_v_sub_f                    :16,	//  0:15
	_rsvd                                :12,	// 16:27 reserved
	pwm2_v_sub_f_id                 : 4;	// 28:31
} M14B0_FRC_DVO_PWM2_V_SUB_F_T;


int BE_PWM_Init(UINT32 type);
int BE_SetPwmControl(BE_PWM_CTRL_T *pstParams);
int BE_SetPwmFrequency(BE_PWM_FREQ_T *pstParams);
int BE_SetPwmDutyCycle(BE_PWM_DUTY_T *pstParams);

#endif
