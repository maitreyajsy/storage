/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <timer.h>
#include <util.h>
#include <stdio.h>
#include <string.h>
#include <env.h>
#include <command.h>
#include <mmu.h>
#include <arch.h>
#include <net.h>
#include <storage.h>
#include <app.h>
#include <platform.h>

/**
 * TODO :  please add below of archirecture specified commands..
 */
