../../../../tools/convert_cmm M14_B0_DDRC_Arbitration_Setting.cmm ddrc_arbitration_b0.h
../../../../tools/convert_cmm M14_B0_FlexNoC_Urgency_Setting.cmm flexnoc_urgency_b0.h
../../../../tools/convert_cmm M14_B0_ROUTER_Setting.cmm router_b0.h
cp *.h ../../include/bus/
rm -rf *.h
