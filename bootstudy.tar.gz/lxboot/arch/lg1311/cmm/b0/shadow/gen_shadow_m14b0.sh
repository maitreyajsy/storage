../../../../../tools/convert_cmm BUS_LM_GM_Reset.cmm bus_reset.h
../../../../../tools/convert_cmm IP_Reset.cmm  ip_reset.h
../../../../../tools/convert_cmm IP_on.cmm  ip_on.h
../../../../../tools/convert_cmm M14_B0_TOP.cmm  top.h
../../../../../tools/convert_cmm M14_B0_LM.cmm lm.h
../../../../../tools/convert_cmm M14_B0_GM.cmm gm.h
../../../../../tools/convert_cmm M14_C0_LM_SS.cmm lm_ss.h
../../../../../tools/convert_cmm M14_C0_GM_SS.cmm gm_ss.h


cp *.h ../../../shadow_rom/include/

rm -rf *.h
