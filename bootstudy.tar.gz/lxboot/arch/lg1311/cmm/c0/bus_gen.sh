../../../../tools/convert_cmm M14_C0_DDRC_Arbitration_Setting.cmm ddrc_arbitration_c0.h
../../../../tools/convert_cmm M14_C0_FlexNoC_Urgency_Setting.cmm flexnoc_urgency_c0.h
../../../../tools/convert_cmm M14_C0_ROUTER_Setting.cmm router_c0.h
cp *.h ../../include/bus/
rm -rf *.h
