#include <types.h>
#include <string.h>
#include <arch/irqs.h>
#include <arch/timers.h>
#include <system.h>
#include <command.h>
#include <arch/dsm.h>

#undef		INCLUDE_THYMB_DISASM
#define		INCLUDE_ARM_DISASM

/* ---------------- Output Functions --------------------- */

#define outc(h)			(dsmPrint("%c",h))
#define outf(f,s)		(dsmPrint(f,s))
#define outi(n)			outf("#%ld",(unsigned long)n)
#define outx(n)			(dsmPrint("0x%lx",(unsigned long)n))
#define outs(s)			(dsmPrint("%s", s), (strlen(s)))


/* ---------------- Bit twiddlers ------------------------ */

/*
 * The casts to uint32_t in bit() and bits() are redundant, but required by
 * some buggy compilers.
 */
#define bp(n)			(((uint32_t)1L<<(n)))
#define bit(n)			(((uint32_t)(instr & bp(n)))>>(n))
#define bits(m,n)		(((uint32_t)(instr & (bp(n)-bp(m)+bp(n))))>>(m))
#define ror(n,b)		(((n)>>(b))|((n)<<(32-(b)))) /* n right rotated b bits */

/**
   static variables...
 */

static pPRINT_FUNC dsmPrint = NULL;
/*******************************************************************************
*
* reg - display register name
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void reg( uint32_t	rno, int ch)
{
	/* Replace "r15" with "pc" */

	if (rno == 15) outs("pc");
	else           outf("r%d", rno);

	if (ch != 0)
		outc(ch);

	return;
} /* reg() */

/*******************************************************************************
*
* outh - display immediate value in hex
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void outh( uint32_t n, uint32_t pos )
{
	/* ARM assembler immediate values are preceded by '#' */
	outc('#');

	if (!pos)
		outc('-');

	/* decimal values by default, precede hex values with '0x' */

	if (n < 10) outf("%d", n);
	else        outx(n);

	return;
} /* outh() */

/*******************************************************************************
*
* spacetocol9 - tab to column 9
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void spacetocol9 (int l)
{
	for (; l < 9 ; l++)
		outc(' ');

	return;
} /* spacetocol9() */

/*******************************************************************************
*
* outregset - display register set of load/store multiple instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void outregset (uint32_t instr)
{
	bool		started = FALSE, string = FALSE;
	uint32_t	i, first = 0, last = 0;

	/* display the start of list char */

	outc('{');

	/* check for presence of each register in list */

	for (i = 0; i < 16; i++)
	{
		if (bit(i))
	    {
			/* register is in list */
			if (!started)
			{
				/* not currently doing a consecutive list of reg numbers */
				reg(i, 0);	/* print starting register */
				started = TRUE;
				first = last = i;
			}
			else /* currently in a list */
			{
				if (i == last+1)
				{
					string = TRUE;
					last = i;
				}
				else/* not consecutive */
				{
					if (i > last+1 && string)
					{
						outc((first == last-1) ? ',' : '-');
						reg(last, 0);
						string = FALSE;
					}
					outc(',');
					reg(i, 0);
					first = last = i;
				}
			}
		}
	} /* endfor */

	if (string)
	{
		outc((first == last-1) ? ',' : '-');
		reg(last, 0);
	}

	outc('}');
	return;
} /* outregset() */

/*******************************************************************************
*
* cond - display condition code of instruction
*
* RETURNS: number of characters written.
*
* NOMANUAL
*
*/

static int cond(uint32_t instr)
{
	const char *ccnames = "eq\0\0ne\0\0cs\0\0cc\0\0mi\0\0pl\0\0vs\0\0vc\0\0"
						  "hi\0\0ls\0\0ge\0\0lt\0\0gt\0\0le\0\0\0\0\0\0nv";

	return outs(ccnames+4*(int)bits(28,31));
} /* cond() */

/*******************************************************************************
*
* opcode - display the opcode of an ARM instruction
*
* This routine is also used in the display of a conditional branch ARM
* instruction.
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void opcode (uint32_t instr, const char *op, char ch)
{
	int l;
	/* display the opcode */

	l = outs(op);

	/* display any condition code */
	l += cond(instr);

	/* display any suffix character */

	if (ch != 0)
	{
		outc(ch);
		l++;
	}

	/* pad with spaces to column 9 */
	spacetocol9(l);

	return;
} /* opcode() */


#ifdef INCLUDE_ARM_DISASM
/*******************************************************************************
*
* freg - display FP register name
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void freg (uint32_t rno, int ch)
{
	outf("f%d", rno);

	if (ch != 0)
		outc(ch);

	return;
} /* freg() */

/*******************************************************************************
*
* shiftedreg - display shifted register operand
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void shiftedreg(uint32_t instr)
{
	char *shiftname = "lsl\0lsr\0asr\0rdr" + 4*(int)bits(5,6);

	/* display register name */
	reg(bits(0,3), 0); /* offset is a (shifted) reg */

	if (bit(4))
	{
		/* register shift */
		outf(",%s ", shiftname);
		reg(bits(8,11), 0);
	}
	else
	{
		if (bits(5,11) != 0)
    	{
    		/* immediate shift */
		    if (bits(5,11) == 3) outs(",rrx");
    		else
			{
				outf(",%s ", shiftname);
				if (bits(5,11) == 1 || bits(5,11) == 2) outi(32L);
				else                                    outi(bits(7,11));
			}
    	}
	}

return;
} /* shiftedreg() */

/*******************************************************************************
*
* outAddress - display an address as part of an instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void outAddress (uint32_t instr, uint32_t address, signed long offset, pVOIDFARGPTR prtAddress)
{
	if (bits(16,19) == 15 && bit(24) && !bit(25))
	{
		/* pc based, pre, imm */
		if (!bit(23))
		    offset = -offset;

		address = address + offset + 8;
		prtAddress(address);
	}
	else
	{
		outc('[');
		reg(bits(16,19), (bit(24) ? 0 : ']'));
		outc(',');

		if (!bit(25))
    	{
    		/* offset is an immediate */
    		outh(offset, bit(23));
    	}
		else
    	{
    		if (!bit(23)) outc('-');
    		shiftedreg(instr);
    	}

		if (bit(24))
    	{
    		outc(']');
    		if (bit(21)) outc('!');
    	}
	}
	return;
} /* outAddress() */

/*******************************************************************************
*
* generic_cpdo - display generic coprocessor data processing instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void generic_cpdo (uint32_t instr)
{
	opcode(instr, "cdp", 0);
	outf("p%d,", bits(8,11));
	outx(bits(20,23));
	outc(',');

	outf("c%d,", bits(12,15));	/* CRd */
	outf("c%d,", bits(16,19));	/* CRn */
	outf("c%d,", bits(0,3));	/* CRm */
	outh(bits(5,7),1);

	return;
} /* generic_cpdo() */

/*******************************************************************************
*
* generic_cprt - display generic coprocessor register transfer instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void generic_cprt (uint32_t instr)
{
	opcode(instr, (bit(20) ? "mrc" : "mcr"), 0);
	outf("p%d,", bits(8,11));
	outx(bits(21,23));
	outc(',');
	reg(bits(12,15), ',');

	outf("c%d,",bits(16,19));	/* CRn */
	outf("c%d,",bits(0,3));	/* CRm */
	outh(bits(5,7),1);

	return;
} /* generic_cprt() */

/*******************************************************************************
*
* generic_cpdt - display a generic coprocessor data transfer instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void generic_cpdt (uint32_t instr, uint32_t address, pVOIDFARGPTR prtAddress)
{
	opcode(instr, (bit(20) ? "ldc" : "stc"), (bit(22) ? 'l' : 0));
	outf("p%d,",bits(8,11));
	outf("c%d,",bits(12,15));

	outAddress(instr, address, 4*bits(0,7), prtAddress);
	return;
} /* generic_cpdt() */

/*******************************************************************************
*
* fp_dt_widthname - display floating-point data transfer width name
*
* RETURNS: the character representing the width specifier
*
* NOMANUAL
*
*/

static char fp_dt_widthname (uint32_t instr)
{
	return "sdep"[bit(15) + 2*bit(22)];
} /* fp_dt_widthname() */

/*******************************************************************************
*
* fp_widthname - display floating-point width name
*
* RETURNS: the character representing the width name
*
* NOMANUAL
*
*/

static char fp_widthname(uint32_t instr)
{
	return "sdep"[bit(7) + 2*bit(19)];
} /* fp_widthname() */

/*******************************************************************************
*
* fp_rounding - display floating-point rounding
*
* RETURNS: the character representing the rounding
*
* NOMANUAL
*
*/

static char *fp_rounding (uint32_t instr)
{
	return "\0\0p\0m\0z" + 2*bits(5,6);
} /* fp_rounding() */

/*******************************************************************************
*
* fp_mfield - display FP field
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void fp_mfield (uint32_t instr)
{
	uint32_t r = bits(0,2);

	if (bit(3))
	{
		if (r < 6) outi(r);
		else       outs((r == 6 ? "#0.5" : "#10"));
	}
	else
		freg(r, 0);

	return;
} /* fp_mfield() */

/*******************************************************************************
*
* fp_cpdo - display FP op
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void fp_cpdo (uint32_t instr, bool *oddity)
{
	char *opset;
	int l;

	if (bit(15))  /* unary */
		opset = "mvf\0mnf\0abs\0rnd\0sqt\0log\0lgn\0exp\0"
				"sin\0cos\0tan\0asn\0acs\0atn\0urd\0nrm";
	else
		opset = "adf\0muf\0suf\0rsf\0dvf\0rdf\0pow\0rpw\0"
				"rmf\0fml\0fdv\0frd\0pol\0xx1\0xx2\0xx3";

	l  = outs(opset + 4*bits(20,23));
	l += cond(instr);

	outc(fp_widthname(instr));
	l++;
	l += outs(fp_rounding(instr));
	spacetocol9(l);
	freg(bits(12,14), ',');			/* Fd */

	if (!bit(15)) freg(bits(16,18), ',');		/* Fn */
	else
	{
		if (bits(16,18) != 0)					/* odd monadic (Fn != 0) ... */
    		*oddity = TRUE;
	}
	fp_mfield(instr);

	return;
} /* fp_cpdo() */

/*******************************************************************************
*
* fp_cprt - display floating-point register transfer instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void fp_cprt (uint32_t instr)
{
	int op = (int)bits(20,23);

	if (bits(12,15) == 15)  /* ARM register = pc */
	{
		if ((op & 9) != 9) op = 4;
		else               op = (op>>1)-4;

		opcode(instr, "cmf\0\0cnf\0\0cmfe\0cnfe\0???" + 5*op, 0);
		freg(bits(16,18), ',');
		fp_mfield(instr);
		return;
	}
	else
	{
		int l;

		if (op > 7) op = 7;

		l  = outs("flt\0fix\0wfs\0rfs\0wfc\0rfc\0???\0???" + 4*op);
		l += cond(instr);
		outc(fp_widthname(instr));
		l++;
		l += outs(fp_rounding(instr));
		spacetocol9(l);
		if (bits(20,23) == 0) /* FLT */
		{
			freg(bits(16,18), ',');
		}

		reg(bits(12,15), 0);
		if (bits(20,23) == 1) /* FIX */
		{
			outc(',');
			fp_mfield(instr);
		}
	}
	return;
} /* fp_cprt() */

/*******************************************************************************
*
* fp_cpdt - display floating-point data transfer instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void fp_cpdt (uint32_t instr, uint32_t address, pVOIDFARGPTR	prtAddress)
{
	if (!bit(24) && !bit(21))
	{
		/* oddity: post and not writeback */
		generic_cpdt(instr, address, prtAddress);
	}
	else
	{
		opcode(instr, (bit(20) ? "ldf" : "stf"), fp_dt_widthname(instr));
		freg(bits(12,14), ',');
		outAddress(instr, address, 4*bits(0,7), prtAddress);
	}
	return;
} /* fp_cpdt() */

/*******************************************************************************
*
* fm_cpdt - display floating-point load/store multiple instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void fm_cpdt (uint32_t instr, uint32_t address, pVOIDFARGPTR prtAddress)
{
	if (!bit(24) && !bit(21))
	{
		/* oddity: post and not writeback */
		generic_cpdt(instr, address, prtAddress);
		return;
	}
	opcode(instr, (bit(20) ? "lfm" : "sfm"), 0);
	freg(bits(12,14), ',');

	{
		int count = (int)(bit(15) + 2*bit(22));
		outf("%d,", count==0 ? 4: count);
	}
	outAddress(instr, address, 4*bits(0,7), prtAddress);

	return;
} /* fm_cpdt() */

/*******************************************************************************
*
* disass_32 - disassemble an ARM (32-bit) instruction
*
* RETURNS: size of instruction, in bytes
*
* NOMANUAL
*
*/

static uint32_t disass_32 ( uint32_t instr, uint32_t address, pVOIDFARGPTR prtAddress)
{
    bool oddity = FALSE;

    switch (bits(24,27))
	{
		case 0:
		{
			if (bit(23) == 1 && bits(4,7) == 9)
			{
				/* Long Multiply */
				opcode(instr, bit(21) ? ((bit(22) ? "smlal" : "umlal")) : (bit(22) ? "smull" : "umull"), bit(20) ? 's' : 0);
				reg(bits(12,15), ',');
				reg(bits(16,19), ',');
				reg(bits(0,3), ',');
				reg(bits(8,11), 0);
				break;
			}
		}
		/* **** Drop through */
		case 1: case 2: case 3:
		{
			if (bit(4) && bit (7))
			{
				if (!bit(5) && !bit(6))
				{
					if (bits(22, 27) == 0)
					{
						opcode(instr, (bit(21) ? "mla" : "mul"),
						       (bit(20) ? 'S' : 0));
						reg(bits(16,19), ',');
						reg(bits(0,3), ',');
						reg(bits(8,11), 0);
						if (bit(21))
					    {
					    	outc(',');
					    	reg(bits(12,15), 0);
					    }
						break;
					}
					if (bits(23,27) == 2 && bits (8, 11) == 0)
					{
						/* Swap */
						opcode(instr, "swp", (bit(22) ? 'b' : 0));
						reg(bits(12,15), ',');
						reg(bits(0,3), ',');
						outc('[');
						reg(bits(16,19), ']');
						break;
					}
				}
				else
				{
			    	if (!bit(25) && (bit(20) || !bit(6)))
					{
						int l;

						l = outs(bit(20) ? "ldr" : "str");
						l += cond(instr);
						if (bit(6))
					    {
					    	outc('s');
					    	outc(bit(5) ? 'h' : 'b');
				        	l += 2;
					    }
						else
					    {
					    	outc('h');
					    	l++;
					    }

						spacetocol9(l);
						reg(bits(12,15), ',');
						outc('[');
						reg(bits(16,19), 0);

						if (bit(24)) outc(',');
						else
					    {
					    	outc(']');
					    	outc(',');
					    }

						if (bit(22))
					    {
					    	outh(bits(0, 3) + (bits(8,11)<<4), bit(23));
					    }
						else
					    {
					    	if (!bit(23)) outc('-');

							reg(bits(0,3),0);
					    }

						if (bit(24))
						{
							outc(']');
							if (bit(21)) outc('!');
						}
						break;
					}
			    }
			}

			if (bits(4, 27) == 0x12fff1)
			{
				opcode(instr, "bx", 0);
				reg(bits(0, 3), 0);
				break;
			}

			if (instr == 0xe1a00000L)
			{
				opcode(instr, "nop", 0);
				break;
			}

			{
				/* data processing */
				int op = (int)bits(21,24);
				const char *opnames = "and\0eor\0sub\0rsb\0add\0adc\0sbc\0rsc\0"
								      "tst\0teq\0cmp\0cmn\0orr\0mov\0bic\0mvn";

				if (op >= 8 && op < 12 && !bit(20))
			    {
			    	if ((op & 1) == 0)
					{
						opcode(instr, "mrs", 0);
						reg(bits(12,15), ',');

						if (op == 8) outs("cpsr");
						else         outs("spsr");

						oddity = (bits(0, 11) != 0 || bits(16, 19) != 15);
						break;
					}
			    	else
					{
					    char *rname = op == 9 ? "cpsr" : "spsr";
					    int rn = (int)bits(16, 19);
					    char *part = rn == 1 ? "ctl" :
					                 rn == 8 ? "flg" :
					                 rn == 9 ? "all" :
					                           "?";

					    opcode(instr, "msr", 0);
					    outs(rname);
					    outf("_%s,", part);
					    oddity = bits(12,15) != 15;
					}
			    }
				else
			    {
			    	int ch = (!bit(20)) ? 0 :
						(op>=8 && op<12) ? (bits(12,15)==15 ? 'P' : 0) : 'S';

					opcode(instr, opnames+4*op, ch);

				    if (!(op >= 8 && op < 12))
					{
						/* not TST TEQ CMP CMN */
						/* print the dest reg */
						reg(bits(12,15), ',');
					}

			    	if (op != 13 && op != 15)
					{
						/* not MOV MVN */
					reg(bits(16,19), ',');
					}
			    }

				if (bit(25))
			    {
					/* rhs is immediate */
			    	int shift = 2 * (int)bits(8,11);
			    	int32_t operand = ror(bits(0,7), shift);

			    	outh(operand, 1);
			    }
				else
			    {
					/* rhs is a register */
			    	shiftedreg(instr);
			    }
			}
			break;
		}
		case 0xA: case 0xB:
		{
		    opcode(instr, (bit(24) ? "bl" : "b"), 0);
			#if 0
			{
				extern uint32_t findSymByAddr(uint32_t addr, char **pSymName);
				char *symName = NULL;
				uint32_t  func_addr;
				int32_t offset = (((int32_t)bits(0,23))<<8)>>6; /* sign extend and * 4 */
				address += offset + 8;
				func_addr = (uint32_t)findSymByAddr(address, &symName);
				prtAddress(address);
				if(func_addr > 0) dsmPrint(" == %s()+0x%04x", symName, address - func_addr);
			}
			#else
			{
			int32_t offset = (((int32_t)bits(0,23))<<8)>>6; /* sign extend and * 4 */
			address += offset + 8;
			prtAddress(address);
			}
			#endif
		    break;
		}

		case 6: case 7:
		{
			/*
			 * Cope with the case where register shift register is specified
			 * as this is an undefined instruction rather than an LDR or STR
			 */
		    if (bit(4))
			{
				outs("Undefined Instruction");
				break;
			}
		}
		/* ***** Drop through to always LDR / STR case */
		case 4: case 5:
		{
		    int l;

		    l = outs(bit(20) ? "ldr" : "str");
		    l += cond(instr);
		    if (bit(22))
			{
				outc('b');
				l++;
			}
		    if (!bit(24) && bit(21))  /* post, writeback */
			{
				outc('t');
				l++;
			}
		    spacetocol9(l);
		    reg(bits(12,15), ',');
		    outAddress(instr, address, bits(0,11), prtAddress);
		    break;
		}


		case 8: case 9:
		{
			int l;

			l  = outs(bit(20) ? "ldm" : "stm");
			l += cond(instr);
			l += outs("da\0\0ia\0\0db\0\0ib" + 4*(int)bits(23,24));
			spacetocol9(l);
			reg(bits(16,19), 0);

			if (bit(21)) outc('!');
			outc(',');
			outregset(instr);
			if (bit(22)) outc('^');

			break;
		}


		case 0xF:
		{
		    opcode(instr, "swi", 0);
			{
				int32_t swino = bits(0,23);
				outx(swino);
			}
		    break;
		}

		case 0xE:
		{
			if (bit(4)==0)
			{ /* CP data processing */
				switch(bits(8,11))
			    {
				    case 1:
					fp_cpdo(instr, &oddity);
					break;

				    default:
					generic_cpdo(instr);
					break;
			    }
			}
		    else
			{ /* CP reg to/from ARM reg */
				switch (bits(8,11))
			    {
			    	case 1:
					fp_cprt(instr);
					break;

			    	default:
					generic_cprt(instr);
					break;
			    }
			}
			break;
		}

		case 0xC: case 0xD:
		{
		    switch (bits(8,11))
			{
				case 1:
			    	fp_cpdt(instr, address, prtAddress);
			    	break;
				case 2:
				    fm_cpdt(instr, address, prtAddress);
				    break;
				default:
				    generic_cpdt(instr, address, prtAddress);
				    break;
			}
		    break;
		}

		default:
		{
		    outs("equd    ");
		    outx(instr);
		    //errnoSet (S_dsmLib_UNKNOWN_INSTRUCTION);
		    break;
		}
    } /* endswitch */


	if (oddity) outs(" ; (?)");

	outc('\n');

	return 4;
} /* disass_32() */
#endif /* INCLUDE_ARM_DISASM */

#ifdef INCLUDE_THUMB_DISASM

/*******************************************************************************
*
* t_opcode - display the opcode of a Thumb instruction
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void t_opcode ( const char *op)
{
	int l;

	/* display the opcode */
	l = outs(op);

	/* pad with spaces to column 9 */
	spacetocol9(l);

	return;
} /* t_opcode() */


/*******************************************************************************
*
* disass_16 - disassemble a Thumb (16-bit) instruction
*
* RETURNS: size of instruction, in bytes
*
* NOMANUAL
*
*/

uint32_t disass_16 (uint32_t instr, uint32_t instr2, uint32_t address, pVOIDFARGPTR prtAddress)
{
	int32_t Rd, Rm, Rn, Ro;
	int32_t imm5, imm8, imm11;
	int32_t L, B;

	Rd = bits(0, 2);
	Rm = bits(3, 5);
	Rn = bits(6, 8);
	Ro = bits(8, 10);
	#define imm3 Rn
	imm11 = bits(0, 10);
	imm8 = bits(0, 7);
	imm5 = bits(6, 10);
	L = bit(11);
	#define SP L
	#define H L
	B = bit(10);
	#define S B
	#define I B

	switch (bits(11, 15))
	{
		case 3:
    	{
			if (bit(9) == 0 && I && imm3 == 0)
			{
				t_opcode("mov");
				reg(Rd, ',');
				reg(Rm, 0);
				break;
			}
    		t_opcode(bit(9) ? "sub" : "add");
    		reg(Rd, ',');

    		if (Rd != Rm) reg(Rm, ',');
    		(I) ? outh(imm3, 1) : reg(Rn, 0 );

   			break;
		}

		case 10: case 11:
		{
			t_opcode("str\0*strh\0strb\0ldsb\0ldr\0*ldrh\0ldrb\0ldsh" +
			bits(9, 11) * 5);
			reg(Rd, ',');
			outc('[');
			reg(Rm, ',');
			reg(Rn, ']');
			break;
		}

		case 12: case 13:
		    imm5 <<= 1;
		case 16: case 17:
		    imm5 <<= 1;
		case 14: case 15:
		{
			t_opcode("str\0*ldr\0*strb\0ldrb\0strh\0ldrh\0" +
			(bits(11, 15) - 12) * 5);
			reg(Rd, ',');
			outc('[');
			reg(Rm, ',');
			outh(imm5, 1);
			outc(']');
			break;
		}
		case 0: case 1: case 2:
		{
			t_opcode("lsl\0lsr\0asr" + bits(11, 12) * 4);
			reg(Rd, ',');

			if (Rd != Rm)
				reg(Rm, ',');

			outh(imm5, 1);
			break;
		}

		case 8:
		{
			int32_t op;

			op = bits(6, 10);
			if (op < 16)
			{
				t_opcode("and\0eor\0lsl\0lsr\0asr\0adc\0sbc\0ror\0"
				 		"tst\0neg\0cmp\0cmn\0orr\0mul\0bic\0mvn" + op * 4);
			}
			else
			{
				if (op & 2) Rd += 8;
				if (op & 1) Rm += 8;

				switch(op)
		    	{
				case 17: case 18: case 19:
					t_opcode("add");
					break;
				case 21: case 22: case 23:
					t_opcode("cmp");
					break;
				case 25: case 26: case 27:
					t_opcode("mov");
					break;
				case 16: case 20: case 24: case 30: case 31:
					t_opcode("Undefined");
					outc('\n');
					return 2;

				case 28: case 29:
					t_opcode("bx");
					reg(Rm, 0);
					outc('\n');
					return 2;
				} /* end switch(op) */

			} /* endelse (op >= 16) */

			reg(Rd, ',');
			reg(Rm, 0);
			break;

		} /* endcase 8 */

		case 4: case 5: case 6: case 7:
		{
			/* ADD/SUB/MOV/CMP (large) immediate */
			t_opcode("mov\0cmp\0add\0sub" + bits(11, 12) * 4);
			reg(Ro, ',');
			outh(imm8, 1);
			break;
		}
		case 18: case 19:
		{
			/*
			 * LDR/STR SP-relative. ARM disassembler code would try to look
			 * this up, but there seems little point in this. Display as
			 * LDR Ro, [SP, #imm]
			 */

			t_opcode("str\0ldr" + L * 4);
			reg(Ro, ',');
			imm8 <<= 2;
			outc('[');
			reg(13, ',');
			outh(imm8, 1);
			outc(']');
			break;
		}

		case 28:
		{
			/* unconditional branch */

		    t_opcode("b");
		    imm11 = (imm11 << 21) / (1 << 20);
		    prtAddress(address + imm11 + 4);
		    break;
		}

		case 22: case 23:
		{
			if (!bit(10))
			{
				if (bits(8, 11) != 0)
				{
					t_opcode("Undefined");
				}
				else
				{
					imm8 = (imm8 & 0x7f) << 2;
					t_opcode(bit(7) ? "sub" : "add");
					reg(13, ',');
					outh(imm8, 1);
				}
			}
			else
			{
				if (bit(9))
				{
					t_opcode("Undefined");
				}
				else
				{
					instr &= 0x1ff;
					if (instr & 0x100)
					{
						instr &= ~0x100;
						if (L) instr |= 0x8000;
						else   instr |= 0x4000;
					}
					t_opcode("push\0pop" + L * 5);
					outregset(instr);
				}
			}
			break;
		}

		case 9:
		{
			t_opcode("ldr");
			reg(Ro, ',');
			imm8 <<= 2;
			address = (address + 4) & ~3;
			prtAddress(address + imm8);
			break;
		}

		case 24: case 25:
		{
			instr &= 0xFF;
			t_opcode("stmia\0ldmia" + L * 6);
			reg(Ro, '!');
			outc(',');
			outregset(instr);
			break;
		}

		case 20: case 21:
		{
			t_opcode("adr\0add" + SP * 4);
			reg(Ro, ',');
			imm8 <<= 2;
			if (!SP)
			{
				address = (address + 4) & ~3;
				prtAddress(address + imm8);
			}
			else
			{
				reg(13, ',');
				outh(imm8, 1);
			}
			break;
		}

		case 26: case 27:
		{ /* Either SWI or conditional branch */
			int32_t op;

			op = bits(8, 11);
			if (op == 15)
			{
				/* SWI */
				t_opcode("swi");
				outx(imm8);
			}
			else
			{
				/* conditional branch: make up ARM instruction to display B?? */
				opcode(op << 28, "b", 0);
				imm8 = (imm8 << 24) / (1 << 23);
				prtAddress(address + imm8 + 4);
			}
			break;
		}

		case 30:
		{
			/*
			 * BL prefix: the BL Thumb instruction is actually TWO 16-bit
			 * instructions, the BL prefix and the BL itself.
			 */
			int32_t offset;

			if ((instr2 & 0xf800) == 0xf800)
			{
				/* if next instruction is the BL itself */
				t_opcode("bl");
				offset = instr2 & 0x7ff;
				offset = (((imm11 << 11) | offset) << 10) / (1 << 9);
				prtAddress(address + offset + 4);
				outc('\n');
				return 4; /* Note two 16-bit instructions */
			}
			else
			{
				/* BL prefix, not followed by BL: not defined */
				t_opcode("first half of bl instruction");
			}
			break;
		}

		case 31:
		{
			/*
			 * BL suffix, but we should already have dealt with it, if
			 * preceded by a BL prefix.
			 */
			t_opcode("second half of bl instruction");
			break;
		}

		default:
		{
			t_opcode("Undefined");
			break;
		}
	} /* endswitch */

	outc('\n');
	return 2;
} /* disass_16() */

#undef imm3
#undef SP
#undef S
#undef H
#undef H1
#undef H2

#endif/*INCLUDE_THUMB_DISASM*/

/*******************************************************************************
*
* nPrtAddress - print addresses as numbers
*
* RETURNS: N/A
*
* NOMANUAL
*
*/

static void nPrtAddress (int address)
{
	dsmPrint ("0x%x", address);
}

/*******************************************************************************
*
* dsmInst - disassemble and print a single instruction
*
* This routine disassembles and prints a single instruction on standard
* output.  The function passed as parameter <prtAddress> is used to print any
* operands that might be construed as addresses.  The function could be a
* subroutine that prints a number or looks up the address in a symbol table.
* The disassembled instruction will be prepended with the address passed as
* a parameter.
*
* ADDRESS-PRINTING ROUTINE
* Many assembly language operands are addresses.  In order to print these
* addresses symbolically, dsmInst() calls a user-supplied routine, passed as a
* parameter, to do the actual printing.  The routine should be declared as:
* .CS
*    void prtAddress (address)
*        int address;	/@ address to print @/
* .CE
*
* When called, the routine prints the address on standard output in either
* numeric or symbolic form.  For example, the address-printing routine used
* by l() looks up the address in the system symbol table and prints the
* symbol associated with it, if there is one.  If not, the routine prints the
* address as a hex number.
*
* If the <prtAddress> argument to dsmInst() is NULL, a default print routine is
* used, which prints the address as a hexadecimal number.
*
* The directive EQUD (declare word) is printed for unrecognized instructions.
*
* RETURNS : The size of the instruction in units of sizeof(INSTR).
*/

int dsmInst (FAST INSTR* binInst, int address, pVOIDFARGPTR	prtAddress)
{
	#ifdef INCLUDE_THUMB_DISASM
	UINT16 instr2 = 0;
	#endif

	/* If no address printing function has been supplied, use default */

	if (prtAddress == NULL)
		prtAddress = nPrtAddress;


	/* Print the address first, then the instruction in hex */

	#ifdef INCLUDE_ARM_DISASM
	dsmPrint("%08x  %08x  ", address, (uint32_t)*binInst);

	return (disass_32((uint32_t)*binInst, (uint32_t)address, prtAddress) / sizeof(INSTR));
	#endif

	#ifdef INCLUDE_THUMB_DISASM
	if (INSTR_IS((*(UINT16 *)binInst), T_BL0))
	{
		instr2 = *(((u16 *)binInst) + 1);
		if (INSTR_IS(instr2, T_BL1))
	    {
			/*
			 * Instruction is a BL: i.e. this instruction is a BL
			 * prefix and the next instruction is the BL itself. So, this
			 * instruction is effectively 32-bits long. Get the next 16-bit
			 * half of the instruction and display all of it as a 32-bit int.
			*/
			dsmPrint("%08x  %04x%04x  ", address, instr2, *(UINT16 *)binInst);
		}
		else
		{
			/* BL prefix not followed by BL suffix */
		    dsmPrint("%08x  %04x      ", address,  *(UINT16 *)binInst);
		}
	}
	else /* Normal (16-bit) Thumb instruction */
		dsmPrint("%08x  %04x      ", address,  *(UINT16 *)binInst);

	return (disass_16((uint32_t)(*(UINT16 *)binInst), (uint32_t)instr2, (uint32_t)address, prtAddress) / sizeof(INSTR));
	#endif
} /* dsmInst() */

/**
  bk1472 added code
 */
int regPrintDsmMode(uint32_t print_func)
{
	dsmPrint = (pPRINT_FUNC)print_func;

	return 0;
}

/*******************************************************************************
*
* dsmNbytes - determine the size of an instruction
*
* This routine reports the size, in bytes, of an instruction.
*
* RETURNS:
* The size of the instruction, or
* 0 if the instruction is unrecognized.
*
*/

int dsmNbytes (FAST INSTR * binInst)	/* Pointer to the instruction */
{
	#ifdef ARM_THUMB
    return INSTR_IS (*binInst, T_BL0) ? 2 * sizeof(INSTR) : sizeof(INSTR);
	#else
    return sizeof (INSTR);
	#endif
} /* dsmNbytes() */

static uint32_t	dsmaddr = (uint32_t)_start;
static inline uint32_t getaddr(void)
{
	return dsmaddr;
}

static inline void putaddr(uint32_t addr)
{
	dsmaddr = addr;
}

int dsm_cmd(int argc, char **argv)
{
static uint32_t	count = 9;
	uint32_t	addr  = getaddr();
	int			i;

	if (argc > 1)
	{
		addr = strtoul(argv[1], NULL, 16);
		if (argc == 3)
			count = strtoul(argv[2], NULL, 10);

		/*match alignment*/
		addr &= ~0x3;
	}
HasBack:
	regPrintDsmMode((uint32_t)printf);
	puts("\n\t[  Address | Hexcode |      Assembly code      ]\n");

	for (i = 0; i < count; i++, addr += 4)
	{
		if (isValidPc((uint32_t*)addr))
		{
			puts("\t  ");
			dsmInst((void *)addr, (uint32_t)addr, NULL);
		}
		else
		{
			printf("^r^%x is not valid address! ==> set default : %p\n", addr, _start);
			addr = (uint32_t)_start;
			putaddr(addr);
			count = 9;
			goto HasBack;
		}
	}
	putaddr(addr);

	return 0;
}
COMMAND(dsm, dsm_cmd, "dis assemble code", "[address [count]]");
