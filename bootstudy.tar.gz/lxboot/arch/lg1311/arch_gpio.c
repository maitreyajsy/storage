/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <string.h>
#include <arch/cpu.h>
#include <arch/ctop_regs.h>
#include <command.h>
#include <gpio.h>


#define GPIO_MAX_NUM			136
#define GPIO_SHARED_PIN_START	32

#define GPIO_BASE(p)			(LG1311_GPIO0_BASE + (((p)/8) * 0x10000))

#define READ_GPIO_DIR(p)		IO_READ(GPIO_BASE(p) + 0x400)
#define WRITE_GPIO_DIR(p,v)		IO_WRITE(GPIO_BASE(p) + 0x400, v)

#define READ_GPIO_DATA(p)		IO_READ(GPIO_BASE(p) + 0x3FC)
#define WRITE_GPIO_DATA(p,m,v)	IO_WRITE(GPIO_BASE(p) + m, v)


#if defined(CONFIG_PLATFORM_EV) && defined(CONFIG_BOARD_TYPE_FPGA)
int gpio_set_top(uint32_t port){ return 0;}
int gpio_set_direction(uint32_t port, int dir){ return 0;}
int gpio_set_value(uint32_t port, int value){ return 0;}

#else
int gpio_set_pin_mux(u32 port, int enable)
{
	uint32_t value;
	uint32_t mask;

	if(get_chip_rev() < CHIP_LG1311_B0)
	{
		if(port < GPIO_SHARED_PIN_START)
		{
			return 0;
		}
		else if(port < GPIO_MAX_NUM)
		{
			uint32_t offset;

			offset = (uint32_t)&ctop_regs->ctr33;
			offset += ((port - GPIO_SHARED_PIN_START)/8) * 4;

			value = REG_READ(offset);
			mask = 1 << ((port%8)*4 + 3);
			value = enable ? value | mask : value & (~mask);
			REG_WRITE(offset, value);
			return 0;
		}
		return -1;
	}
	else	/* M14B0 */
	{
		if(port <= 39)	/* Some ports are shared but default value is gpio */
		{
			return 0;
		}
		else if(port <= 70)
		{
			if(port == 56 || port == 57)
			{
				/* gpio56[3], gpio57[7] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr97);
				mask = (port == 56) ? (1 << 3) : (1 << 7);
				value = enable ? value | mask : value & (~mask);
				CTOP_CTRL_WRITE(ctop_left_regs, ctr97, value);
			}
			else if(port >= 64 && port <= 66)
			{
				/* gpio64[21] ~ gpio66[23] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr100);
				mask = 1 << (21 + (port - 64));
				value = enable ? value | mask : value & (~mask);
				CTOP_CTRL_WRITE(ctop_left_regs, ctr100, value);
			}
			else
			{
				if(port <= 47)
				{
					/* gpio40[12] ~ gpio47[5] */
					mask = 1 << (12 - (port - 40));
				}
				else if(port <= 55)
				{
					/* gpio48[20] ~ gpio55[13] */
					mask = 1 << (20 - (port - 48));
				}
				else if(port <= 63)
				{
					/* gpio58[26] ~ gpio63[21] */
					mask = 1 << (26 - (port - 58));
				}
				else
				{
					/* gpio67[30] ~ gpio70[27] */
					mask = 1 << (30 - (port - 67));
				}

				value = CTOP_CTRL_READ(ctop_top_regs, ctr08);
				value = enable ? value | mask : value & (~mask);
				CTOP_CTRL_WRITE(ctop_top_regs, ctr08, value);
			}
		}
		else if(port <= 71)
		{
			/* gpio71[31] */
			value = CTOP_CTRL_READ(ctop_left_regs, ctr97);
			mask = (1 << 31);
			value = enable ? value | mask : value & (~mask);
			CTOP_CTRL_WRITE(ctop_left_regs, ctr97, value);
		}
		else if(port <= 95)	/* GPIO72 ~ GPIO95 */
		{
			if(port >= 77 && port <= 79)
			{
				/* gpio77[18] ~ gpio79[20] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr100);
				mask = 1 << (18 + (port - 77));
				value = enable ? value | mask : value & (~mask);
				CTOP_CTRL_WRITE(ctop_left_regs, ctr100, value);
			}
			else
			{
				if(port <= 76)
				{
					/* gpio72[23] ~ gpio76[27] */
					mask = 1 << (23 + (port - 72));
				}
				else if(port <= 86)
				{
					/* gpio80[15] ~ gpio87[22] */
					mask = 1 << (15 + (port - 80));
				}
				else
				{
					/* gpio88[7] ~ gpio95[14] */
					mask = 1 << (7 + (port - 88));
				}
				value = CTOP_CTRL_READ(ctop_top_regs, ctr09);
				value = enable ? value | mask : value & (~mask);
				CTOP_CTRL_WRITE(ctop_top_regs, ctr09, value);
			}
		}
		else if(port <= 119)	/* GPIO96 ~ GPIO119 */
		{
			if(port == 112 || port == 113)
			{
				/* gpio112[3], gpio113[7] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr98);
				mask = (port == 112) ? (1 << 3) : (1 << 7);
				value = enable ? value | mask : value & (~mask);
				CTOP_CTRL_WRITE(ctop_left_regs, ctr98, value);
			}
			else
			{
				if(port <= 103)
				{
					/* gpio96[24] ~ gpio103[31] */
					mask = 1 << (24 + (port - 96));
				}
				else if(port <= 111)
				{
					/* gpio104[16] ~ gpio111[23] */
					mask = 1 << (16 + (port - 104));
				}
				else
				{
					/* gpio114[10] ~ gpio119[15] */
					mask = 1 << (10 + (port - 114));
				}
				value = CTOP_CTRL_READ(ctop_top_regs, ctr10);
				value = enable ? value | mask : value & (~mask);
				CTOP_CTRL_WRITE(ctop_top_regs, ctr10, value);
			}
		}
		else if(port <= 125)	/* GPIO120 ~ GPIO125 */
		{
			/* gpio120[16] ~ gpio125[21] */
			mask = 1 << (16 + (port - 120));
			value = CTOP_CTRL_READ(ctop_top_regs, ctr11);
			value = enable ? value | mask : value & (~mask);
			CTOP_CTRL_WRITE(ctop_top_regs, ctr11, value);
		}
		else if(port <= 127)	/* GPIO126 ~ GPIO127 */
		{
			/* gpio126[27], gpio127[31] */
			value = CTOP_CTRL_READ(ctop_left_regs, ctr98);
			mask = (port == 126) ? (1 << 27) : (1 << 31);
			value = enable ? value | mask : value & (~mask);
			CTOP_CTRL_WRITE(ctop_left_regs, ctr98, value);
		}
		else if(port <= 133)	/* GPIO128 ~ GPIO133 not exist */
		{
			return -1;
		}
		else if(port <= 135)	/* GPIO134 ~ GPIO135 */
		{
			/* gpio134[22] ~ gpio135[23] */
			value = CTOP_CTRL_READ(ctop_top_regs, ctr11);
			mask = 1 << (22 + (port - 134));
			value = enable ? value | mask : value & (~mask);
			CTOP_CTRL_WRITE(ctop_top_regs, ctr11, value);
		}
		else
		{
			return -1;
		}
		return 0;
	}

}

int gpio_get_pin_mux(uint32_t port)
{
	uint32_t value;
	uint32_t mask;

	if(get_chip_rev() < CHIP_LG1311_B0)
	{
		if(port < GPIO_SHARED_PIN_START)
		{
			return 1;
		}
		else if(port < GPIO_MAX_NUM)
		{
			uint32_t offset;

			offset = (uint32_t)&ctop_regs->ctr33;
			offset += ((port - GPIO_SHARED_PIN_START)/8) * 4;

			value = REG_READ(offset);
			mask = 1 << ((port%8)*4 + 3);
			return (value & mask) ? 1 : 0;
		}
		return -1;
	}
	else
	{
		if(port <= 39)	/* Some ports are shared but default value is gpio */
		{
			return 1;
		}
		else if(port <= 70)
		{
			if(port == 56 || port == 57)
			{
				/* gpio56[3], gpio57[7] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr97);
				mask = (port == 56) ? (1 << 3) : (1 << 7);
			}
			else if(port >= 64 && port <= 66)
			{
				/* gpio64[21] ~ gpio66[23] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr100);
				mask = 1 << (21 + (port - 64));
			}
			else
			{
				if(port <= 47)
				{
					/* gpio40[12] ~ gpio47[5] */
					mask = 1 << (12 - (port - 40));
				}
				else if(port <= 55)
				{
					/* gpio48[20] ~ gpio55[13] */
					mask = 1 << (20 - (port - 48));
				}
				else if(port <= 63)
				{
					/* gpio58[26] ~ gpio63[21] */
					mask = 1 << (26 - (port - 58));
				}
				else
				{
					/* gpio67[30] ~ gpio70[27] */
					mask = 1 << (30 - (port - 67));
				}
				value = CTOP_CTRL_READ(ctop_top_regs, ctr08);
			}
		}
		else if(port <= 71)
		{
			/* gpio71[31] */
			value = CTOP_CTRL_READ(ctop_left_regs, ctr97);
			mask = (1 << 31);
		}
		else if(port <= 95) /* GPIO72 ~ GPIO95 */
		{
			if(port >= 77 && port <= 79)
			{
				/* gpio77[18] ~ gpio79[20] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr100);
				mask = 1 << (18 + (port - 77));
			}
			else
			{
				if(port <= 76)
				{
					/* gpio72[23] ~ gpio76[27] */
					mask = 1 << (23 + (port - 72));
				}
				else if(port <= 79)
				{
					return 0;
				}
				else if(port <= 86)
				{
					/* gpio80[15] ~ gpio87[22] */
					mask = 1 << (15 + (port - 80));
				}
				else
				{
					/* gpio88[7] ~ gpio95[14] */
					mask = 1 << (7 + (port - 88));
				}
				value = CTOP_CTRL_READ(ctop_top_regs, ctr09);
			}
		}
		else if(port <= 119)	/* GPIO96 ~ GPIO119 */
		{
			if(port == 112 || port == 113)
			{
				/* gpio112[3], gpio113[7] */
				value = CTOP_CTRL_READ(ctop_left_regs, ctr98);
				mask = (port == 112) ? (1 << 3) : (1 << 7);
			}
			else
			{
				if(port <= 103)
				{
					/* gpio96[24] ~ gpio103[31] */
					mask = 1 << (24 + (port - 96));
				}
				else if(port <= 111)
				{
					/* gpio104[16] ~ gpio111[23] */
					mask = 1 << (16 + (port - 104));
				}
				else
				{
					/* gpio114[10] ~ gpio119[15] */
					mask = 1 << (10 + (port - 114));
				}
				value = CTOP_CTRL_READ(ctop_top_regs, ctr10);
			}
		}
		else if(port <= 125)	/* GPIO120 ~ GPIO125 */
		{
			/* gpio120[16] ~ gpio125[21] */
			value = CTOP_CTRL_READ(ctop_top_regs, ctr11);
			mask = 1 << (16 + (port - 120));
		}
		else if(port <= 127)	/* GPIO126 ~ GPIO127 */
		{
			/* gpio126[27], gpio127[31] */
			value = CTOP_CTRL_READ(ctop_left_regs, ctr98);
			mask = (port == 126) ? (1 << 27) : (1 << 31);
		}
		else if(port <= 133)	/* GPIO128 ~ GPIO133 not exist */
		{
			return -1;
		}
		else if(port <= 135)	/* GPIO134 ~ GPIO135 */
		{
			/* gpio134[22] ~ gpio135[23] */
			value = CTOP_CTRL_READ(ctop_top_regs, ctr11);
			mask = 1 << (22 + (port - 134));
		}
		else
		{
			return -1;
		}
		return (value & mask) ? 1 : 0;
	}
}

int gpio_set_top(uint32_t port)
{
	return gpio_set_pin_mux(port, 1);
}


int gpio_set_direction(uint32_t port, int dir)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		value = (dir == GPIO_DIR_OUTPUT) ? (value | mask) : (value & ~mask);
		WRITE_GPIO_DIR(port, value);

		return 0;
	}
	return -1;
}

int gpio_get_direction(uint32_t port)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		return (value & mask) ? GPIO_DIR_OUTPUT : GPIO_DIR_INPUT;
	}
	return -1;
}

int gpio_set_value(uint32_t port, int value)
{
	uint32_t mask;

	if(port < GPIO_MAX_NUM)
	{
		mask = 1 << (2 + (port%8));
		value = (value == GPIO_HIGH) ? 0xFF : 0;
		WRITE_GPIO_DATA(port, mask, value);
		return 0;
	}
	return -1;
}

int gpio_get_value(uint32_t port)
{
	uint32_t value;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DATA(port);
		value = (value >> (port%8)) & 0x01;

		return (value == 1) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}


static int gpio_ex_dir[2] = {-1, -1};

static void gpio_ex_init(void)
{
	static int inited = 0;

	if(inited) return;
	inited = 1;

	/* Set Interrupt Sense to get the value */
	ace_reg_write(0x28, 0x12, 0xFF);
	ace_reg_write(0x28, 0x13, 0xFF);

	/*
	(3) GPIO_IEV �� 1�ϸ� input level�� '1' �� ��� High, '0'�̸� Low
	(4) GPIO_IEV �� 0�ϸ� input level�� '0' �� ��� High, '1'�̸� Low
	*/
	ace_reg_write(0x28, 0x16, 0xFF);
	ace_reg_write(0x28, 0x17, 0xFF);
}

int gpio_ex_set_direction(uint32_t port, int dir)
{
	gpio_ex_init();
	if(port < 16)
	{
		int block = port/8;
		uint8_t addr, mask, value;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x10 : 0x11;

		if(gpio_ex_dir[block] == -1)
		{
			ace_reg_read(0x28, addr, &value);
			gpio_ex_dir[block] = value;
		}

		value = (dir == GPIO_DIR_INPUT) ? gpio_ex_dir[block] & (~mask) : gpio_ex_dir[block] | mask;

		if(gpio_ex_dir[block] != value)
		{
			ace_reg_write(0x28, addr, value);
			gpio_ex_dir[block] = value;
		}
		return 0;
	}
	return -1;
}

int gpio_ex_get_direction(uint32_t port)
{
	gpio_ex_init();
	if(port < 16)
	{
		int block = port/8;
		uint8_t addr, value, mask;

		mask = 1 << (port % 8);
		if(gpio_ex_dir[block] == -1)
		{
			addr = (port < 8) ? 0x10 : 0x11;
			ace_reg_read(0x28, addr, &value);
			gpio_ex_dir[block] = value;
		}

//		printf("DIR:0x%02x\n", gpio_ex_dir[block]);
		return (gpio_ex_dir[block] & mask) ? GPIO_DIR_OUTPUT : GPIO_DIR_INPUT;
	}
	return -1;
}

int gpio_ex_set_value(uint32_t port, int value)
{
	gpio_ex_init();
	if(port < 16)
	{
		uint8_t data, mask;
		uint8_t addr;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x00 : 0x01;

		ace_reg_read(0x28, addr, &data);
		data = (value == GPIO_LOW) ? data & (~mask) : data | mask;
//		printf("DATA:0x%02x\n", data);
		ace_reg_write(0x28, addr, data);
		return 0;
	}
	return -1;
}

int gpio_ex_get_value(uint32_t port)
{
	gpio_ex_init();
	if(port < 16)
	{
		uint8_t data, mask;
		uint8_t addr;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x1e : 0x1f;

		ace_reg_read(0x28, addr, &data);
//		printf("DATA:0x%02x\n", data);
		return (data & mask) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}

/* For Performance Improvement */
int gpio_ex_get_static_value(uint32_t port)
{
	static int value[2] = {-1, -1};

	gpio_ex_init();
	if(port < 16)
	{
		uint8_t mask = 1 << (port % 8);
		int block = port/8;

		if(value[block] == -1)
		{
			uint8_t data, addr;
			addr = (port < 8) ? 0x1e : 0x1f;
			ace_reg_read(0x28, addr, &data);
			value[block] = data;
		}

		return (value[block] & mask) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}



#if !defined(FIRST_BOOT)
/*********************************
 * GPIO TEST CODE START
 *********************************/
static void print_gpio_pin_mux(int value)
{
	printf("Direction : %s\n", (value == GPIO_DIR_INPUT) ? "INPUT" :
						(value == GPIO_DIR_OUTPUT) ? "OUTPUT" : "XXX");
}

static void print_gpio_direction(int value)
{
	printf("Direction : %s\n", (value == GPIO_DIR_INPUT) ? "INPUT" :
						(value == GPIO_DIR_OUTPUT) ? "OUTPUT" : "XXX");
}

static void print_gpio_value(int value)
{
	printf("Data : %s\n", (value == GPIO_LOW) ? "LOW" :
						(value == GPIO_HIGH) ? "HIGH" : "XXX");
}

static int input_gpio_pin_mux(void)
{
	int c;

	while(1)
	{
		printf("Input pin mux - normal(0), gpio(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? 0 : 1;
}

static int input_gpio_direction(void)
{
	int c;

	while(1)
	{
		printf("Input direction - input(0), output(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? GPIO_DIR_INPUT : GPIO_DIR_OUTPUT;
}

static int input_gpio_value(void)
{
	int c;

	while(1)
	{
		printf("Input value - Low(0), High(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? GPIO_LOW : GPIO_HIGH;
}

static int gpio_cmd(int argc, char **argv)
{
	char name[32];
	int len, port;
	char c;

	do{
		printf("###### GPIO Test #######\n");
		printf("========================\n");
		printf(" 1. SetPinMux\n");
		printf(" 2. GetPinMux\n");
		printf(" 3. SetDirection\n");
		printf(" 4. GetDirection\n");
		printf(" 5. SetValue\n");
		printf(" 6. GetValue\n");
		printf("========================\n");
		printf(" A. ExSetDirection\n");
		printf(" S. ExGetDirection\n");
		printf(" D. ExSetValue\n");
		printf(" F. ExGetValue\n");
		printf("========================\n");
		printf(" X. Exit\n");
		while(1)
		{
			printf("Select : ");
			c = getchar();
			if(isalnum(c))
				break;
			printf("\n");
		}

		printf("%c\n", isprint((int)c) ? c : ' ');

		if(toupper(c) == 'X')
			break;

		while(1)
		{
			printf("Input pin number : ");
			len = gets(name);
			printf("\n");
			if(len > 0) break;
		}
		port = strtoul(name, NULL, 10);

		switch(toupper(c))
		{
			case '1': gpio_set_pin_mux(port, input_gpio_pin_mux()); break;
			case '2': print_gpio_pin_mux(gpio_get_pin_mux(port)); break;
			case '3': gpio_set_direction(port, input_gpio_direction()); break;
			case '4': print_gpio_direction(gpio_get_direction(port)); break;
			case '5': gpio_set_value(port, input_gpio_value()); break;
			case '6': print_gpio_value(gpio_get_value(port)); break;

			case 'A': gpio_ex_set_direction(port, input_gpio_direction()); break;
			case 'S': print_gpio_direction(gpio_ex_get_direction(port)); break;
			case 'D': gpio_ex_set_value(port, input_gpio_value()); break;
			case 'F': print_gpio_value(gpio_ex_get_value(port)); break;

			default: printf("unknown \n");
		}
	}while(1);
	return 0;
}

COMMAND(gpio, gpio_cmd, "GPIO Test", NULL);
#endif	/* if !defined(FIRST_BOOT) */
#endif
