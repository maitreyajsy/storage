/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <serial.h>

#define PRINT_BUFFER_SIZE		2048
void puts(const char *str)
{
	while(*str)
	{
		if(*str == '\n')
			serial_putc(CONSOLE_UART_PORT, '\r');

		serial_putc(CONSOLE_UART_PORT, *str++);
	}
}

int printf(const char *fmt, ...)
{
	char buffer[PRINT_BUFFER_SIZE];
	va_list ap;
	int len;

	va_start(ap, fmt);
	len = vsprintf(buffer, fmt, ap);
	va_end(ap);
	puts(buffer);

	return len;
}

int getchar(void)
{
	while(!serial_check_rx(CONSOLE_UART_PORT));
	return serial_getc(CONSOLE_UART_PORT);
}

int putchar(char c)
{
	serial_putc(CONSOLE_UART_PORT, c);
	return 1;
}

int gets(char *s)
{
	int cnt = 0;
	char  c;

	while((c = getchar()) != ASCII_CR)
	{
		if(c != ASCII_BS)
		{
			cnt++;
			*s++ = c;
			printf("%c",c );
		}
		else
		{
			if(cnt > 0)
			{
				cnt--; *s-- = ' ';
				printf("\b \b");
			}

		}
	}
	*s = 0;

	return(cnt);
}

