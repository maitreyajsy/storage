
/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/


/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO			Modifications
|------------------------------------------------------------------------------------------------------------
|   Jun	01 2012		yw.kim@lge.com		Add lg1154 a0, a1 for clock auto detection.
|   Oct	23 2012		yw.kim@lge.com		Add lg1154 b0
|============================================================================================================*/

/* -------------------------------------------------------------------------------------------------
 *  HEADER
 * -------------------------------------------------------------------------------------------------
 */

#include <types.h>
#include <stdio.h>
#include <string.h>
#include <command.h>
#include <arch/ctop_regs.h>
#include <timer.h>

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT

/* -------------------------------------------------------------------------------------------------
 *  DATA TYPE
 * -------------------------------------------------------------------------------------------------
 */
typedef struct
{
 	uint32_t cpu_pll_out;
	uint32_t m0_pll_out;
	uint32_t m1_pll_out;
	uint32_t lm_ddr_clk;
	uint32_t gm_ddr_clk;
	uint32_t peri_bus_clk;
	uint32_t cpu_core_clk;

} clk_detect_t;


/* -------------------------------------------------------------------------------------------------
 *  MACRO
 * -------------------------------------------------------------------------------------------------
 */
#ifndef SYS_PLL_FREQ
#define SYS_PLL_FREQ CONFIG_SYS_PLL_FREQ
#endif

#define PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC) \
	( (((4*NPC+NSC)*(1<<pre_fd))*SYS_PLL_FREQ) / ((M+1)*(0x1<<od_fout)) )


/* -------------------------------------------------------------------------------------------------
 *  STATIC
 * -------------------------------------------------------------------------------------------------
 */
static clk_detect_t clk;


/* -------------------------------------------------------------------------------------------------
 *  FUNCTION
 * -------------------------------------------------------------------------------------------------
 */
void ctop_detect_clk(void)
{

	if(get_chip_rev() < CHIP_LG1311_B0)
	{//A0, A1
		/* pre_fd, od_fout, M setting */
		CTR74 ctr74; /*cpu pll, 0xC001B128*/
		CTR76 ctr76; /*m0 pll, 0xC001B130*/
		CTR78 ctr78; /*m1 pll, 0xC001B138*/

		/* NPC, NSC setting */
		CTR75 ctr75; /*cpu pll, 0xC001B12C*/
		CTR77 ctr77; /*m0 pll, 0xC001B134*/
		CTR79 ctr79; /*m1 pll, 0xC001B13C*/

		/* clk path */
		CTR32 ctr32; /*0xC001B080 */

		uint32_t pre_fd, od_fout, M, NPC, NSC;

		/* pre_fd, od_fout, M setting */
		ctr74 = ctop_regs->ctr74;
		ctr76 = ctop_regs->ctr76;
		ctr78 = ctop_regs->ctr78;

		/* NPC, NSC setting */
		ctr75 = ctop_regs->ctr75;
		ctr77 = ctop_regs->ctr77;
		ctr79 = ctop_regs->ctr79;

		/* clock path */
		ctr32 = ctop_regs->ctr32;

		/* get cpu pll out */
		pre_fd = ctr74.c_dr3p_pre_fd_ctrl;
		od_fout = ctr74.c_dr3p_od_fout_ctrl;
		M = ctr74.c_dr3p_m_ctrl;
		NPC = (ctr75.c_dr3p_npc_ctrl); /*bit[1] must be inverted*/
		NPC ^= 0x2;
		NSC = (ctr75.c_dr3p_nsc_ctrl); /*bit[1] must be inverted*/
		NSC ^= 0x2;
		clk.cpu_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
		clk.cpu_core_clk = clk.cpu_pll_out >> 1;


		/* get m0 pll out */
		pre_fd = ctr76.m1_dr3p_pre_fd_ctrl;
		od_fout = ctr76.m1_dr3p_od_fout_ctrl;
		M = ctr76.m1_dr3p_m_ctrl;
		NPC = ctr77.m1_dr3p_npc_ctrl;
		NSC = ctr77.m1_dr3p_nsc_ctrl;
		clk.m0_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);

		/* get m1 pll out */
		pre_fd = ctr78.m2_dr3p_pre_fd_ctrl;
		od_fout = ctr78.m2_dr3p_od_fout_ctrl;
		M = ctr78.m2_dr3p_m_ctrl;
		NPC = ctr79.m2_dr3p_npc_ctrl;
		NSC = ctr79.m2_dr3p_nsc_ctrl;
		clk.m1_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);

		/* check path and get peri clock */
		if(ctr32.pll_sel_core == 0)
			clk.peri_bus_clk = clk.m0_pll_out >> 3;
		else if(ctr32.pll_sel_core == 1)
			clk.peri_bus_clk = clk.m1_pll_out >> 3;

		/* check path and get lm ddr clock */
		if(ctr32.pll_sel_m1 == 0)
			clk.lm_ddr_clk = clk.m0_pll_out >> 1;
		else if(ctr32.pll_sel_m1 == 1)
			clk.lm_ddr_clk = clk.m1_pll_out >> 1;

		/* check path and get gm ddr clock */
		if(ctr32.pll_sel_m2 == 0)
			clk.gm_ddr_clk = clk.m1_pll_out >> 1;
		else if(ctr32.pll_sel_m2 == 1)
			clk.gm_ddr_clk = clk.m0_pll_out >> 1;
	}
	else
	{//B0
		/* pre_fd, od_fout, M setting */
		CTOP_TOP_CTR00_M14B0 ctr00; /*cpu pll, 0xc001_9000*/
		CTOP_TOP_CTR02_M14B0 ctr02; /*m0 pll, 0xc001_9008*/
		CTOP_TOP_CTR04_M14B0 ctr04; /*m1 pll, 0xc001_9010*/

		/* NPC, NSC setting */
		CTOP_TOP_CTR01_M14B0 ctr01; /*cpu pll, 0xc001_9004*/
		CTOP_TOP_CTR03_M14B0 ctr03; /*m0 pll, 0xc001_900c*/
		CTOP_TOP_CTR05_M14B0 ctr05; /*m1 pll, 0xc001_9014*/

		/* clk path */
		CTOP_TOP_CTR24_M14B0 ctr24; /*c001_9060*/

		uint32_t pre_fd, od_fout, M, NPC, NSC;

		/* pre_fd, od_fout, M setting */
		ctr00 = ctop_top_regs->ctr00;
		ctr02 = ctop_top_regs->ctr02;
		ctr04 = ctop_top_regs->ctr04;

		/* NPC, NSC setting */
		ctr01 = ctop_top_regs->ctr01;
		ctr03 = ctop_top_regs->ctr03;
		ctr05 = ctop_top_regs->ctr05;

		/* clock path */
		ctr24 = ctop_top_regs->ctr24;

		/* get cpu pll out */
		pre_fd = ctr00.c_dr3p_pre_fd_ctrl;
		od_fout = ctr00.c_dr3p_od_fout_ctrl;
		M = ctr00.c_dr3p_m_ctrl;
		NPC = (ctr01.c_dr3p_npc_ctrl); /*bit[1] must be inverted*/
		NPC ^= 0x2;
		NSC = (ctr01.c_dr3p_nsc_ctrl); /*bit[1] must be inverted*/
		NSC ^= 0x2;
		clk.cpu_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
		clk.cpu_core_clk = clk.cpu_pll_out >> 1;

		/* get m0 pll out */
		pre_fd = 0;
		od_fout = ctr03.ddr3pll_od_fout;
		M = ctr02.ddr3pll_m;
		NPC = ctr03.ddr3pll_npc;
		NSC = ctr02.ddr3pll_nsc;
		clk.m0_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);

		/* get m1 pll out */
		pre_fd = 0;
		od_fout = ctr05.m2_ddr3pll_od_fout;
		M = ctr04.m2_ddr3pll_m;
		NPC = ctr05.m2_ddr3pll_npc;
		NSC = ctr04.m2_ddr3pll_nsc;
		clk.m1_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);

		/* check path and get peri clock */
		if(ctr24.pll_sel_core == 0)
			clk.peri_bus_clk = clk.m0_pll_out >> 3;
		else if(ctr24.pll_sel_core == 1)
			clk.peri_bus_clk = clk.m1_pll_out >> 3;

		/* check path and get lm ddr clock */
		if(ctr24.pll_sel_m1 == 0)
			clk.lm_ddr_clk = clk.m0_pll_out >> 1;
		else if(ctr24.pll_sel_m1 == 1)
			clk.lm_ddr_clk = clk.m1_pll_out >> 1;

		/* check path and get gm ddr clock */
		if(ctr24.pll_sel_m2 == 0)
			clk.gm_ddr_clk = clk.m1_pll_out >> 1;
		else if(ctr24.pll_sel_m2 == 1)
			clk.gm_ddr_clk = clk.m0_pll_out >> 1;

	}
}

uint32_t ctop_get_cpu_clk(void)
{
	return clk.cpu_core_clk;
}

uint32_t ctop_get_pclk(void)
{
	return clk.peri_bus_clk;
}

uint32_t ctop_get_m0_clk(void)
{
	return clk.lm_ddr_clk;
}

uint32_t ctop_get_m1_clk(void)
{
	return clk.gm_ddr_clk;
}

int do_get_clk(int argc, char *argv[])
{
	ctop_detect_clk();
	printf("CPU CLK : %dMHz\n", ctop_get_cpu_clk());
	printf("BUS CLK : %dMHz\n", ctop_get_pclk());
	printf("M0  CLK : %dMHz\n", ctop_get_m0_clk());
	printf("M1  CLK : %dMHz\n", ctop_get_m1_clk());
	return 0;
}

COMMAND(clk, do_get_clk, "usage : clk", NULL);

#endif /*CONFIG_USE_DETECT_CLK*/


#define USB3_CR_CAP_ADDR (1<<19)
#define USB3_CR_ACK      (1<<16)

uint32_t ctop_xhci_possible(void)
{
	if(get_chip_rev() < CHIP_LG1311_B0)
	{//A0, A1

		uint32_t reg0;
		uint32_t check = 0;
		uint16_t address = 0x1018;


		volatile uint32_t * ptr_reg0;
		volatile uint32_t * ptr_reg1;

		ptr_reg0 = ( volatile uint32_t *)(LG1311_A0_TOPCTRL_BASE + 0x1E0);
		ptr_reg1 = ( volatile uint32_t *)(LG1311_A0_TOPCTRL_BASE + 0x1E4);

		/* capture address */
		reg0  = 0;
		reg0 |= address;
		*ptr_reg0 = reg0;
		reg0 |= USB3_CR_CAP_ADDR;
		*ptr_reg0 = reg0;

		mdelay(1);

		if((*ptr_reg1 & USB3_CR_ACK))
			check = 1;

		*ptr_reg0 = 0;

		return check;
	}
	else
		return 1;
}



