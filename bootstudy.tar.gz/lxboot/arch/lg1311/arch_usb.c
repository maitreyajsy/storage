/****************************************************************************************
 *   SIC Lab., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <string.h>
#include <timer.h>
#include <arch/ctop_regs.h>

/*
* In case of Android platform, 
* :there is no MW for USB HW setting
* So setting OVP here.
*/
#ifdef INCLUDE_GTV
#define OVP_SETTING_ON_LXBOOT
#endif //INCLUDE_GTV

#if !defined(CONFIG_BOARD_TYPE_FPGA)
volatile USB_TOP_CTRL_REG_T *usb_top_regs = (volatile USB_TOP_CTRL_REG_T *)LG1311_B0_USB_CTRL_BASE;

static void _arch_usb_reset(void)
{
	if(get_chip_rev() >= CHIP_LG1311_B0)
	{
		PHY_CTLR_RST rst;
		//SS1_PHY_CTL1 ss1_phy_ctl1;

		rst = usb_top_regs->phy_ctlr_rst;
		rst.resetn_ssusb0_phy = 1;
		rst.resetn_ssusb1_phy = 1;
		rst.resetn_hsusb0_phy = 1;
		rst.resetn_ssusb1_phy = 1;
		usb_top_regs->phy_ctlr_rst = rst;

		/* reset usb ohci1 phy, REG_WRITE(0xC001FA54, 0x0A800008) */
		ctop_left_regs->ctr101 = 0x0A800008;

		if(get_chip_rev() >= CHIP_LG1311_C0)
		{
			/* WiFi Eye, REG_WRITE(0xC001FA54, 0x0ABC0008) */
			ctop_left_regs->ctr101 = 0x0ABC0008;
		}
		mdelay(1);

		/* reset utmi for hsusb0 and hsusb1 */
		rst.resetn_hsusb0_utim_reset = 1;
		rst.resetn_hsusb1_utim_reset = 1;
		usb_top_regs->phy_ctlr_rst = rst;

		/* reset bus and core */
		rst.resetn_ssusb0_bus = 1;
		rst.resetn_ssusb0_core = 1;
		rst.resetn_ssusb1_bus = 1;
		rst.resetn_ssusb1_core = 1;
		rst.resetn_hsusb0_bus = 1;
		rst.resetn_hsusb0_core = 1;
		rst.resetn_hsusb1_bus = 1;
		rst.resetn_hsusb1_core = 1;
		usb_top_regs->phy_ctlr_rst = rst;

		/*
		 * after phy reset 
		 * usb port 1 u3 disable in phy.
		 * usb3.0 signal affect to hdmi, by jeongkyun.yim@lge.com
		 * 0xC00900A0
		 */
		//ss1_phy_ctl1 = usb_top_regs->ss1_phy_ctl1;
		//ss1_phy_ctl1.test_powerdown_ssp = 1;
		//usb_top_regs->ss1_phy_ctl1 = ss1_phy_ctl1;
	}
	else
	{
		CTR00 ctr00;

		ctr00 = ctop_regs->ctr00;
		ctr00.swrst_usb0_init = 1;	 /*usb2.0 host controller 0*/
		ctr00.swrst_usb1_init = 1;	 /*usb2.0 host controller 1*/
		ctr00.swrst_usb2_init = 1;	 /*usb2.0 host controller 2*/
		ctr00.swrst_usb_bt_init = 1; /*usb3.0 host controller*/
		ctop_regs->ctr00 = ctr00;
	}
}

static void _arch_ss_phy_init(void)
{
	if(get_chip_rev() >= CHIP_LG1311_B0)
	{
		SS0_PHY_CTL1 ss0_phy_ctl1;
		SS1_PHY_CTL1 ss1_phy_ctl1;
		SS0_PHY_CTL4 ss0_phy_ctl4;
		SS1_PHY_CTL4 ss1_phy_ctl4;

		SS0_PHY_CTL3 ss0_phy_ctl3;
		SS1_PHY_CTL3 ss1_phy_ctl3;
		HS0_PHY_CTL1 hs0_phy_ctl1;

		//SS1_CTLR_CTL ss1_ctlr_ctl;

		/*
		 * before phy reset 
		 * usb port 1 u3 disable.
		 * usb3.0 signal affect to hdmi, by jeongkyun.yim@lge.com 
		 * 0xC0090080
		 */
		//ss1_ctlr_ctl = usb_top_regs->ss1_ctlr_ctl;
		//ss1_ctlr_ctl.host_u3_port_disable = 1;
		//usb_top_regs->ss1_ctlr_ctl = ss1_ctlr_ctl;

		ss0_phy_ctl1 = usb_top_regs->ss0_phy_ctl1;
		ss0_phy_ctl1.lane0_ext_pclk_req = 1;
		usb_top_regs->ss0_phy_ctl1 = ss0_phy_ctl1;

		ss1_phy_ctl1 = usb_top_regs->ss1_phy_ctl1;
		ss1_phy_ctl1.lane0_ext_pclk_req = 1;
		usb_top_regs->ss1_phy_ctl1 = ss1_phy_ctl1;

		/* pcs_tx_swing_full = 7'h7F */
		ss0_phy_ctl4 = usb_top_regs->ss0_phy_ctl4;
		ss0_phy_ctl4.pcs_tx_swing_full = 0x7f;
		usb_top_regs->ss0_phy_ctl4 = ss0_phy_ctl4;

		ss1_phy_ctl4 = usb_top_regs->ss1_phy_ctl4;
		ss1_phy_ctl4.pcs_tx_swing_full = 0x7f;
		usb_top_regs->ss1_phy_ctl4 = ss1_phy_ctl4;

		/* modify usb txvreftune value for adjusting signal level of EYE Diagram */
		ss0_phy_ctl3 = usb_top_regs->ss0_phy_ctl3;
		ss0_phy_ctl3.txvreftune = 0x2;
		usb_top_regs->ss0_phy_ctl3 = ss0_phy_ctl3;

		ss1_phy_ctl3 = usb_top_regs->ss1_phy_ctl3;
		ss1_phy_ctl3.txvreftune = 0x1;
		usb_top_regs->ss1_phy_ctl3 = ss1_phy_ctl3;

		hs0_phy_ctl1 = usb_top_regs->hs0_phy_ctl1;
		hs0_phy_ctl1.txvreftune = 0x2;
		usb_top_regs->hs0_phy_ctl1 = hs0_phy_ctl1;

		if(get_chip_rev() >= CHIP_LG1311_C0)
		{
			ss0_phy_ctl3.txpreempamptune = 0x1;
			usb_top_regs->ss0_phy_ctl3 = ss0_phy_ctl3;
			ss1_phy_ctl3.txpreempamptune = 0x1;
			usb_top_regs->ss1_phy_ctl3 = ss1_phy_ctl3;
			hs0_phy_ctl1.txpreempamptune = 0x1;
			usb_top_regs->hs0_phy_ctl1 = hs0_phy_ctl1;
			/* WiFi Eye, REG_WRITE(0xC001FA5C, 0x11D37200) */
			ctop_left_regs->ctr103 = 0x11D37200;
		}

	}
	else
	{
		CTR72 ctr72;

		/* pclk always on */
		ctr72 = ctop_regs->ctr72;
		ctr72.lane0_ext_pclk_req = 1;
		ctr72.ssc_range = 0;
		ctop_regs->ctr72 = ctr72; /* REG_WRITE(0xC001B120, 0x04E81A10); */
	}
}

static void _arch_set_ovc(int enable)
{
	if(get_chip_rev() >= CHIP_LG1311_B0)
	{
		SS0_CTLR_CTL ss0_ctlr;
		if(enable)
		{
			ss0_ctlr = usb_top_regs->ss0_ctlr_ctl;
			ss0_ctlr.hub_oc_inv = 1;
			ss0_ctlr.hub_vbus_inv = 0;
			usb_top_regs->ss0_ctlr_ctl = ss0_ctlr;
		}
		else
		{
			ss0_ctlr = usb_top_regs->ss0_ctlr_ctl;
			ss0_ctlr.hub_oc_inv = 0;
			//ss0_ctlr.hub_vbus_inv = 1;
			usb_top_regs->ss0_ctlr_ctl = ss0_ctlr;
		}
	}
	else
	{
		CTR73 ctr73; /*us3.0 hub port over current polarity*/
		if(enable)
		{
			ctr73 = ctop_regs->ctr73;
			ctr73.hub_port_overcurrent_pol = 0x3;
			ctop_regs->ctr73 = ctr73;
		}
		else
		{
			ctr73 = ctop_regs->ctr73;
			ctr73.hub_port_overcurrent_pol = 0x0;
			ctop_regs->ctr73 = ctr73;
		}
	}
}


static void _arch_check_ovc(void)
{
	/*OVP setting will be processed on MW side. Skip here*/
	#ifdef OVP_SETTING_ON_LXBOOT
	if(get_chip_rev() >= CHIP_LG1311_B0)
	{
		if(REG_READ(LG1311_B0_USB_XHCI0_BASE + 0x420) | (0x1<<3))
		{
			SS0_CTLR_CTL ss0_ctlr;

			ss0_ctlr = usb_top_regs->ss0_ctlr_ctl;
			ss0_ctlr.hub_oc_inv = 1;
			ss0_ctlr.hub_vbus_inv = 0;
			usb_top_regs->ss0_ctlr_ctl = ss0_ctlr;
		}
	}
	else
	{
		if(ctop_xhci_possible())
		{
			/* usb3.0 phy control register suspend off
			REG_WRITE(LG1154_USB_XHCI4_BASE + 0xc2c0, 0x01240002); */

			/*check over current for usb3.0 xhci hc */
			if(REG_READ(LG1311_A0_USB_XHCI4_BASE + 0x420) | (0x1<<3))
			{
				CTR73 ctr73; /*us3.0 hub port over current polarity*/

				mdelay(1);

				ctr73 = ctop_regs->ctr73;
				ctr73.hub_port_overcurrent_pol = ~ctr73.hub_port_overcurrent_pol;
				/* ctr73.hub_vbus_pol = 0x3; */
				ctop_regs->ctr73 = ctr73;
			}
		}
	}
	#else
		return; //Skip..
	#endif //OVP_SETTING_ON_LXBOOT
}

static void _arch_ss_gbl_init(void)
{
	uint32_t temp;

	if(get_chip_rev() >= CHIP_LG1311_B0)
	{
		/* max burst size => 8 (512bits) */
		temp = REG_READ(LG1311_B0_USB_XHCI0_BASE + 0xC100) | 0x6;
		REG_WRITE(LG1311_B0_USB_XHCI0_BASE + 0xC100, temp);

		REG_WRITE(LG1311_B0_USB_XHCI0_BASE + 0xC10C, 0x0);

		temp = REG_READ(LG1311_B0_USB_XHCI0_BASE + 0xC12C) | 0x4000;
		REG_WRITE(LG1311_B0_USB_XHCI0_BASE + 0xC12C, temp);

		// UTMI Data width : 16bit. : GUSB2PHYCFGn = xhci base addr + 0xC200
		temp = REG_READ(LG1311_B0_USB_XHCI0_BASE + 0xC200) | (1<<3); //PHY Interface (PHYIf) :GUSB2PHYCFGn[3] = 1'b1
		REG_WRITE( LG1311_B0_USB_XHCI0_BASE + 0xC200, temp);

		/* max burst size => 8 (512bits) */
		temp = REG_READ(LG1311_B0_USB_XHCI1_BASE + 0xC100) | 0x6;
		REG_WRITE(LG1311_B0_USB_XHCI1_BASE + 0xC100, temp);

		REG_WRITE(LG1311_B0_USB_XHCI1_BASE + 0xC10C, 0x0);

		temp = REG_READ(LG1311_B0_USB_XHCI1_BASE + 0xC12C) | 0x4000;
		REG_WRITE(LG1311_B0_USB_XHCI1_BASE + 0xC12C, temp);

		// UTMI Data width : 16bit. : GUSB2PHYCFGn = xhci base addr + 0xC200
		temp = REG_READ(LG1311_B0_USB_XHCI1_BASE + 0xC200) | (1<<3); //PHY Interface (PHYIf) :GUSB2PHYCFGn[3] = 1'b1
		REG_WRITE( LG1311_B0_USB_XHCI1_BASE + 0xC200, temp);
	}
	else
	{
		if(ctop_xhci_possible())
		{
			/* max burst size => 8 (512bits) */
			temp = REG_READ(LG1311_A0_USB_XHCI4_BASE + 0xC100) | 0x6;
			REG_WRITE(LG1311_A0_USB_XHCI4_BASE + 0xC100, temp);

			REG_WRITE(LG1311_A0_USB_XHCI4_BASE + 0xC10C, 0x0);

			temp = REG_READ(LG1311_A0_USB_XHCI4_BASE + 0xC12C) | 0x4000;
			REG_WRITE(LG1311_A0_USB_XHCI4_BASE + 0xC12C, temp);
		}
	}
}
#endif

void arch_usb_init(void)
{
#if !defined(CONFIG_BOARD_TYPE_FPGA)
	_arch_ss_phy_init();
	_arch_usb_reset();
	_arch_check_ovc();
	_arch_ss_gbl_init();
#endif
}

void arch_usb_start(void)
{
	_arch_set_ovc(1);
}

void arch_usb_stop(void)
{
	_arch_set_ovc(0);
	arch_usb_init();
}

