/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <string.h>

#ifdef CONFIG_ARCH_SHADOW

#define MAGIC_APP_IMAGE		0x4C415050

typedef struct
{
	u32	magic;
	u32 start;
	u32 bss_start;
	u32 bss_end;

	u32 func;
} app_header_t;

typedef int app_main_t(int, char**);

static app_main_t *shadow_func;

static u32 load_app_image(u32 image, u32 size)
{
	app_header_t* header = (app_header_t*)image;

	if(header->magic != MAGIC_APP_IMAGE)
	{
		printf("invalid app image. magic:0x%08x !!!\n", header->magic);
		return 0;
	}

	memcpy((void*)header->start, (const void*)image, size);
#ifdef USE_DATA_CACHE
//	dcache_clean_range(header->start, size);
#endif
	memset((void*)header->bss_start, 0, header->bss_end - header->bss_start);

	return header->func;
}


int shadow(void)
{
	extern u8 shadow_bin_start[];
	extern u8 shadow_bin_end[];

	shadow_func = (app_main_t*)load_app_image((u32)shadow_bin_start, (u32)(shadow_bin_end - shadow_bin_start));

	return shadow_func(0, NULL);
}
#else
int shadow(void){return -1;}
#endif

