#if USE_MULTI_THREAD
#include <types.h>
#include <string.h>
#include <arch/irqs.h>
#include <arch/timers.h>
#include <thread.h>
#include <system.h>
#include <command.h>
#include <arch/backstack.h>

/*
**	Function Call/Return related Instruction sets
*/
#define	ARM_INST_STM_SP_MASK	0xffff0000		/*	Mask for STMDB sp!, {..	*/
#define ARM_INST_STR_SP_MASK	0xfffff000		/*  Mask for STR lr,[sp,#]! */
#define ARM_INST_STR_SP_MASK2	0xffff0000		/*  Mask for STR Rd,[sp,#]! */
#define	ARM_INST_ADD_SP_MASK	0xfffff000		/*	Mask for ADD sp,sp,#n	*/
#define	ARM_INST_LDR2PC_MASK	0x0c00f000		/*	Mask for LDR pc,[rn,#n	*/
#define	ARM_INST_MOV2PC_MASK	0x0ffff000		/*	Mask for MOVxx pc,rn	*/
#define	ARM_INST_PC2LR_MASK		0x0fffffff		/*	Mask for MOVxx lr,pc	*/
#define	ARM_INST_BL_MASK		0x0f000000		/*	Mask for BL	xxxx		*/
#define ARM_INST_REG_LR_MASK	0x00004000		/*  Mask for LR is in RegSet*/
#define ARM_INST_REG_PC_MASK	0x00008000		/*  Mask for PC is in RegSet*/

#define	ARM_INST_STMDB_SP		0xe92d0000		/*	STMDB sp!, {r#-r#,lr}	*/
#define	ARM_INST_LDMIA_SP		0xe8bd8000		/*	LDIMA sp!, {r#-r#,pc}	*/
#define ARM_INST_STR_LR2SP		0xe52de000		/*  STR   lr,[sp,#]!        */
#define ARM_INST_STR_Rx2SP		0xe52d0000		/*  STR   Rd,[sp,#]!        */
#define	ARM_INST_MOV_LR2PC		0x01a0f00e		/*	MOVxx pc,lr             */
#define	ARM_INST_MOV_rx2PC		0x01a0f000		/*	MOVxx pc,rx             */
#define	ARM_INST_MOV_PC2LR		0x01a0e00f		/*	MOVxx lr,pc             */
#define	ARM_INST_BX_LR			0xe12fff1e		/*	BX    lr                */
#define	ARM_INST_ADD_SP			0xe28dd000		/*	ADD   sp,sp,#n			*/
#define	ARM_INST_SUB_SP			0xe24dd000		/*	SUB   sp,sp,#n			*/
#define	ARM_INST_BL				0x0b000000		/*	BL    label				*/
#define	ARM_INST_LDR2PC			0x0400f000		/*	LDR   pc,[rn,#			*/

#define SHOW_GFS_STAT(_t)		if (_verboseTr) (*pFunc)(_t ": pc=0x%08x, fs=%3d, lr=0x%08x, sp=0x%08x, spc=0x%08x\n", pc, fs, lr, sp, savedPc);
#define	FIND_METHOD				2

static uint32_t _verboseTr = 0;

static int16_t get_sub_offset(uint32_t inst)
{
	int16_t	rotate_imm;
	int16_t	immed_8;

	rotate_imm = ((inst & 0xf00) >> 8);
	immed_8    = ((inst & 0x0ff)     );

	if (rotate_imm<8) return((immed_8) >> (2 *     rotate_imm) );
	else              return((immed_8) << (2 * (16-rotate_imm)));
}

int16_t	get_frame_size(pPRINT_FUNC pFunc, uint32_t *sp, uint32_t *pc, uint32_t **ra, int nTryStmdb)
{
	uint32_t	mask;					/* Mask variable to test regs set	*/
	#if	(FIND_METHOD == 0)
	uint32_t	*savedPc = pc;			/* Saved input program counter		*/
	#else
	uint32_t	*savedPc = 0;			/* Pc which has inst STR lr,[sp,#]	*/
	#endif /* (FIND_METHOD == 0) */
	uint32_t	*pcSubSp = 0;   		/* Pc which has inst SUB sp, #nn    */
	uint32_t	*pcBound = pc;			/* Boundary to search STR_LR2SP inst*/
	uint32_t	*lr      = 0;			/* New Return address searched		*/
	int16_t		fs       = 0, i;
	uint8_t		bSTMInst = 0;

	/* 1: Check whether pc is valid or not									*/
	if (!isValidPc(pc))
		return 0;

	SHOW_GFS_STAT("1  ");

	/*	2: Search STMDB instruction backword								*/
	while (1)
	{
		if ((uint32_t)pc < (uint32_t)_start)
			return -1;

		if (((pc[0] & ARM_INST_STM_SP_MASK) == ARM_INST_STMDB_SP) &&
		    ((pc[0] & ARM_INST_REG_LR_MASK)                     ) )
		{
			bSTMInst = 1;
			break;
		}

		if ((pc[0] & ARM_INST_ADD_SP_MASK) == ARM_INST_SUB_SP)
		{
			pcSubSp = pc;
		}

		#if	(FIND_METHOD > 0)
		/*	Check function entry start with STR lr,[sp,#]	*/
		if (((uint32_t)savedPc                ==                  0) &&
			((pc[0] & ARM_INST_STR_SP_MASK) == ARM_INST_STR_LR2SP) )
		{
			savedPc = pc;
			#if	(FIND_METHOD > 1)
			i  = 0;
			while ((pc[i] & ARM_INST_STR_SP_MASK2) == ARM_INST_STR_Rx2SP)
			{
				i  += 1;
				fs += 4;
			}
			break;
			#endif /* (FIND_METHOD > 1) */
		}
		#endif /* (FIND_METHOD > 0) */

		pc--;
	}
	SHOW_GFS_STAT("2  ");

	/* 3-1: Get size of frame to save registers via STMDB inst	*/
	if (bSTMInst)
	{
		for (mask = 0x4000; mask > 0; mask >>= 1)
		{
			if (pc[0] & mask) fs += 4;
		}
	}
	SHOW_GFS_STAT("3-1");

	/* 3-2: Get size of frame decremented by SUB inst			*/
	/* psip_main.c:Psip_Main() �Լ����� 9��°�� SUB inst�� ���� */
	/*   12���� ���̰�, �߰��� return ���ɾ ������ �����ϴ�	*/
	/*   ������� ����, LDMxx ���ɿ� ���ؼ��� ó���ؾ� �ϳ� 	*/
	/*   STMxx �� ����ϴ� �Լ��� 12�� �̻��� Instruction����	*/
	/*   �̷�����ϱ� ó������ �ʾƵ� ���� ��.					*/
	/* xm_hd3_draw.c:XmDRV_DrawPixmap() ������ 13��°�� SUB inst*/
	/*	 �� ���� --> 16���� ������.								*/
	for (i = 1; (pcSubSp != NULL) && (i <= 16); i++)
	{
		if ( ((pc[i] & ARM_INST_BL_MASK    ) == ARM_INST_BL       ) ||
		 	 ((pc[i] & ARM_INST_LDR2PC_MASK) == ARM_INST_LDR2PC   ) ||
			 ((pc[i] & ARM_INST_MOV2PC_MASK) == ARM_INST_MOV_rx2PC) )
			break;

		if ((pc + i) >= pcBound)
			break;

		if ((pc[i] & ARM_INST_ADD_SP_MASK) == ARM_INST_SUB_SP)
		{
			fs += get_sub_offset(pc[i]);
		}
	}
	SHOW_GFS_STAT("3-2");

	/* 4-0: Update return address stored in top of frame		*/
	pcBound = pc;
	lr = (uint32_t *)sp[(fs-4)/4]-1;
	SHOW_GFS_STAT("4-0");

	/* 5-1: Check whether new pc is valid or not				*/
	if ((nTryStmdb <= 1) && !isValidPc(lr))
	{
		/*	STMDB instruction is not for current function		*/
		/*	Check other type of function calls					*/
		pc = savedPc;
		#if	(FIND_METHOD == 0)
		while (pc > pcBound)
		{
			/*	Check function entry start with STR lr,[sp,#]	*/
			if ((pc[0] & ARM_INST_STR_SP_MASK) == ARM_INST_STR_LR2SP)
				break;
			pc--;
		}
		#endif /* (FIND_METHOD == 0) */

		fs = 0;
		if ((pc > pcBound) && ((pc[1] & ARM_INST_ADD_SP_MASK) == ARM_INST_SUB_SP))
		{
			fs += get_sub_offset(pc[1]);
		}

		lr = (uint32_t *)sp[fs/4];
		if ((pc > pcBound) && isValidPc(lr))
		{
			/*	Function entry start with STR lr,[sp,#]			*/
			if (ra) *ra = lr;
			SHOW_GFS_STAT("5-0");
			return(fs+4);
		}

		/* Function is small enough not to save link register	*/
		SHOW_GFS_STAT("5-1");
		return 0;
	}

	for (i = 0; i < nTryStmdb; i++, fs += 4)
	{
		lr = (uint32_t *)sp[(fs-4)/4] - 1;

		if (!isValidPc(lr))
			continue;

		/* 6: Check function call type								*/
		if		 ((lr[ 0] & ARM_INST_BL_MASK) == ARM_INST_BL       )
		{
			/* Function call via BL instruction */
			break;
		}
		else if (((lr[-1] & ARM_INST_PC2LR_MASK ) == ARM_INST_MOV_PC2LR) &&
				 ((lr[ 0] & ARM_INST_LDR2PC_MASK) == ARM_INST_LDR2PC   ) )
		{
			/* Function call via MOV lr,pc & LDR pc,[rx,$x] pair	*/
			break;
		}
		else if (((lr[-1] & ARM_INST_PC2LR_MASK ) == ARM_INST_MOV_PC2LR) &&
				 ((lr[ 0] & ARM_INST_MOV2PC_MASK) == ARM_INST_MOV_rx2PC) )
		{
			/* Function call via MOV lr,pc & MOV pc,rx		pair	*/
			break;
		}
		else
		{
			// Print("0x%08x: 0x%08x/0x%08x\n", pc, pc[-1], pc[0]);
		}
	}

	if (i >= nTryStmdb)
	{
		fs = -1;
	}

	SHOW_GFS_STAT("6-1");

	if (fs > 0)
	{
		/* 6-2: Update frame size for PC just above link reg	*/
	    if (bSTMInst && (pc[0] & ARM_INST_REG_PC_MASK))
		{
			fs += 4;
			SHOW_GFS_STAT("6-2");
		}

		for (i = -1; i >= -4; i--)
		{
			/* 6-3: Update frame size for inst "SUB   sp,sp,#n"		*/
			if ((pc[i] & ARM_INST_ADD_SP_MASK) == ARM_INST_SUB_SP)
			{
				fs += get_sub_offset(pc[i]);
				SHOW_GFS_STAT("6-3");
			}

			/* 6-4: Get size of frame to save r0-r3 via STMDB inst	*/
			else if ((pc[i] & ARM_INST_STM_SP_MASK) == ARM_INST_STMDB_SP)
			{
				for (mask = 0x8000; mask > 0; mask >>= 1)
					if (pc[i] & mask) fs += 4;
				SHOW_GFS_STAT("6-4");
			}

			/* 6-5: Update frame size for inst "LDR   rn,[sp,#4]!"		*/
			else if ((pc[i] & ARM_INST_STR_SP_MASK2) == ARM_INST_STR_Rx2SP)
			{
				fs += 4;
				SHOW_GFS_STAT("6-5");
			}
			else
			{
				break;
			}
		}
	}

	/* 7: Store searched return address							*/
	if (ra) *ra = lr;

	return(fs);
}
#endif/* USE_MULTI_THREAD */
