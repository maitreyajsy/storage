/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <stdio.h>

#if (defined(CONFIG_BOOT_SINGLE) || defined(FIRST_BOOT)) \
	&& (defined(CONFIG_ADDR_SWITCH) || USE_ADDR_SWITCH)

#ifndef USE_SMART_BALANCING
#ifdef	CONFIG_PLATFORM_EV
#define USE_SMART_BALANCING		0
#else
#define USE_SMART_BALANCING		1
#endif
#endif


#if 0
	/* It will generate address switch CMM for T32. Define USE_EARLY_PRINTF before you use it  */
#define REG_WRITE_ADDRSW(addr, val)	\
		do { \
			early_printf("D.S ASD:0x%08X %LONG 0x%08X\n", (u32)addr, (u32)val); \
			REG_WRITE(addr, val);	\
		} while(0)
#else
#define REG_WRITE_ADDRSW(addr, val)		REG_WRITE(addr, val)
#endif


static void set_addr_switch_a0(void)
{
#define LBUS_CTRL_BASE_ADDR		(0xC000E000)
#define GBUS_CTRL_BASE_ADDR		(0xC0010000)

#define LBUS	0
#define GBUS	1
#define MAX_ADDR_SWITCH			8
#define MAX_ADDR_SWITCH_IDX		(MAX_ADDR_SWITCH - 1)

	struct addr_switch {
		uint8_t	bustype;
		uint8_t	smartbalance;
		uint8_t	start;
		uint8_t	end;
		uint8_t offset;
	};

	struct mem_prot_range {
		uint8_t base;
		uint8_t end;
	};

/*
 * This is the address translation logic between bus and ip
 * physical address is already mapped to bus
 */

	/* ADDR SWITCH */

	/* A/V Driver 560MB */
#if USE_SMART_BALANCING
	const struct addr_switch aswitch[] = {
										/* Logical					Physical			  */
		{LBUS, 1, 0x00, 0x39, 0x00},	/* 0x00000000-0x39FFFFFF => 0x00000000-0x1CFFFFFF,0x80000000-0x9CFFFFFF : 928M */
		{GBUS, 0, 0x3A, 0x5C, 0x63},	/* 0x3A000000-0x4CFFFFFF => 0x9D000000-0xAFFFFFFF : 304M */
/* To make the contiguous memory */ 	/* 0x4D000000-0x5CFFFFFF => 0xB0000000-0xBFFFFFFF : 256M */

		{LBUS, 0, 0x5D, 0x7f, 0x00},	/* 0x5D000000-0x7FFFFFFF => 0x5D000000-0x7FFFFFFF : 560M */
		{GBUS, 0, 0x90, 0x9f, 0x20},	/* 0x90000000-0x9FFFFFFF => 0xB0000000-0xBFFFFFFF : 256M */
		{GBUS, 0, 0xa0, 0xff, 0x00},	/* 0xA0000000-0xFFFFFFFF => 0xA0000000-0xFFFFFFFF */
	};
#else
	const struct addr_switch aswitch[] = {
										/* Logical					Physical			  */
		{LBUS, 0, 0x00, 0x1C, 0x00},	/* 0x00000000-0x1CFFFFFF => 0x00000000-0x1CFFFFFF : 464M */
		{GBUS, 0, 0x1D, 0x5C, 0x63},	/* 0x1D000000-0x4CFFFFFF => 0x80000000-0xAFFFFFFF : 768M */
/* To make the contiguous memory */		/* 0x4D000000-0x5CFFFFFF => 0xB0000000-0xBFFFFFFF : 256M */

		{LBUS, 0, 0x5D, 0x7f, 0x00},	/* 0x5D000000-0x7FFFFFFF => 0x5D000000-0x7FFFFFFF : 560M */
		{GBUS, 0, 0x90, 0x9f, 0x20},	/* 0x90000000-0x9FFFFFFF => 0xB0000000-0xBFFFFFFF : 256M */
		{GBUS, 0, 0xa0, 0xff, 0x00},	/* 0xA0000000-0xFFFFFFFF => 0xA0000000-0xFFFFFFFF */
	};
#endif

	const struct mem_prot_range mrange[2] = {
		{0x00, 0x5C},	/* 0x00000000- 0x5CFFFFFF */
		{0x80, 0xAF}	/* 0x80000000- 0xAFFFFFFF */
	};


	/* CPU */
	const uint32_t cpu_addr_switch_regs[] = {
		LG1311_CPUTOP_BASE + 0x01C,		// CPU0
		LG1311_CPUTOP_BASE + 0x048,		// CPU1

		LG1311_CPUTOP_BASE + 0x074, 	// PERI0
		LG1311_CPUTOP_BASE + 0x0A0, 	// PERI1
		LG1311_CPUTOP_BASE + 0x0CC,		// ISOL
		LG1311_CPUTOP_BASE + 0x224, 	// SC
		LG1311_CPUTOP_BASE + 0x250, 	// USB
	};

	/* IP */
	const uint32_t ip_addr_switch_regs[] = {
		LBUS_CTRL_BASE_ADDR + 0x0180,	// AUD
		LBUS_CTRL_BASE_ADDR + 0x0280,	// GPU0
		LBUS_CTRL_BASE_ADDR + 0x0380,	// GPU1
		LBUS_CTRL_BASE_ADDR + 0x0480,	// GFX
		LBUS_CTRL_BASE_ADDR + 0x0580,	// ICOD
		LBUS_CTRL_BASE_ADDR + 0x0680,	// TE
		LBUS_CTRL_BASE_ADDR + 0x0780,	// VD_PRI
		LBUS_CTRL_BASE_ADDR + 0x0880,	// VD_SEC
		LBUS_CTRL_BASE_ADDR + 0x0980,	// VE_PRI
		LBUS_CTRL_BASE_ADDR + 0x0E80,	// DE_E_CVD
		LBUS_CTRL_BASE_ADDR + 0x0F80,	// DE_E_MCU
		LBUS_CTRL_BASE_ADDR + 0x1C80,	// CPU_MAIN

		GBUS_CTRL_BASE_ADDR + 0x0A80,	// DE_A
		GBUS_CTRL_BASE_ADDR + 0x0B80,	// DE_B
		GBUS_CTRL_BASE_ADDR + 0x0C80,	// DE_C
		GBUS_CTRL_BASE_ADDR + 0x0D80,	// DE_D
		GBUS_CTRL_BASE_ADDR + 0x1080,	// DPP_A
		GBUS_CTRL_BASE_ADDR + 0x1180,	// DVI
		GBUS_CTRL_BASE_ADDR + 0x1280,	// DVO
		GBUS_CTRL_BASE_ADDR + 0x1380,	// SRE
		GBUS_CTRL_BASE_ADDR + 0x1480,	// MEP_A
		GBUS_CTRL_BASE_ADDR + 0x1580,	// MEP_B
		GBUS_CTRL_BASE_ADDR + 0x1680,	// BVE_MCU
		GBUS_CTRL_BASE_ADDR + 0x1780,	// MC
		GBUS_CTRL_BASE_ADDR + 0x1A80,	// TCON
		GBUS_CTRL_BASE_ADDR + 0x1C80,	// CPU_SUB
	};

	/* Memory Protection Monitor */
	const uint32_t mem_prot_regs[] = {
		LBUS_CTRL_BASE_ADDR + 0x01B0,	// AUD
		LBUS_CTRL_BASE_ADDR + 0x04B0,	// GFX
		LBUS_CTRL_BASE_ADDR + 0x05B0,	// ICOD
		LBUS_CTRL_BASE_ADDR + 0x06B0,	// TE
		LBUS_CTRL_BASE_ADDR + 0x07B0,	// VDEC
		LBUS_CTRL_BASE_ADDR + 0x08B0,	// VDO & PDEC
		LBUS_CTRL_BASE_ADDR + 0x09B0,	// VENC
		LBUS_CTRL_BASE_ADDR + 0x0EB0,	// DE_E CVD
		LBUS_CTRL_BASE_ADDR + 0x0FB0,	// DE_E MCU

		GBUS_CTRL_BASE_ADDR + 0x0AB0,	// DE_A
		GBUS_CTRL_BASE_ADDR + 0x0BB0,	// DE_B
		GBUS_CTRL_BASE_ADDR + 0x0CB0,	// DE_C
		GBUS_CTRL_BASE_ADDR + 0x0DB0,	// DE_D
		GBUS_CTRL_BASE_ADDR + 0x11B0,	// DVI
		GBUS_CTRL_BASE_ADDR + 0x12B0,	// DVO
		GBUS_CTRL_BASE_ADDR + 0x14B0,	// MEP-A
		GBUS_CTRL_BASE_ADDR + 0x15B0,	// MEP-B
		GBUS_CTRL_BASE_ADDR + 0x16B0,	// BVE-MCU
		GBUS_CTRL_BASE_ADDR + 0x17B0,	// MC
		GBUS_CTRL_BASE_ADDR + 0x1AB0,	// TCON
	};


	int i,j;
	volatile uint32_t *ctrl_reg;
	uint32_t port, portL, portG;
	uint32_t val;
	const int count = sizeof(aswitch)/sizeof(struct addr_switch);

	STATIC_ASSERT((count <= MAX_ADDR_SWITCH), "Over max address switch bank");

	/* Change CPU Address space 0x0 ~ 0xAF... to 0x0 ~ 0xBF.. */
	REG_WRITE_ADDRSW(LG1311_CPUTOP_BASE + 0x270, (0x1 << 2));

	// Address Switch for CPU
	for(i=0; i<sizeof(cpu_addr_switch_regs)/sizeof(uint32_t); i++)
	{
		uint32_t smartbalance = 0;
		ctrl_reg = (volatile uint32_t *)cpu_addr_switch_regs[i];
		for(j=0; j<count; j++)
		{
			smartbalance |= (aswitch[j].smartbalance << j);
			if(j == MAX_ADDR_SWITCH_IDX)
				val = aswitch[j].start << 24 | smartbalance << 16 | aswitch[j].offset << 8;
			else
				val = aswitch[j].start << 24 | aswitch[j].end << 16 | aswitch[j].offset << 8;
			REG_WRITE_ADDRSW(&ctrl_reg[j], val);
		}

		if(j != MAX_ADDR_SWITCH)
		{
			val = (smartbalance << 16);
			REG_WRITE_ADDRSW(&ctrl_reg[MAX_ADDR_SWITCH_IDX], val);
		}
	}

	// Address Switch for IPs
	for(i=0; i<sizeof(ip_addr_switch_regs)/sizeof(uint32_t); i++)
	{
		ctrl_reg = (volatile uint32_t *)ip_addr_switch_regs[i];
		portL = ctrl_reg[0] & 0x03000000;
		portG = ctrl_reg[1] & 0x03000000;
		for(j=0; j<count; j++)
		{
			port = (aswitch[j].bustype == LBUS) ? portL : portG;
			val = port | aswitch[j].smartbalance << 28 | aswitch[j].offset << 16 | aswitch[j].end << 8 | aswitch[j].start;
			REG_WRITE_ADDRSW(&ctrl_reg[j], val);
		}
	}

	for(i=0; i<sizeof(mem_prot_regs)/sizeof(uint32_t); i++)
	{
		ctrl_reg = (volatile uint32_t *)mem_prot_regs[i];
		ctrl_reg[0] = mrange[0].base | (mrange[1].base << 8);
		ctrl_reg[1] = mrange[0].end | (mrange[1].end << 8);
	}

}

#define SMART_BLC 	0//TODO: temporary macro, will be changed USE_SMART_BALANCING
static void set_addr_switch_b0(void)
{
#define BUS_CTRL_ATOP_BASE 		(0xC0010000)
#define BUS_CTRL_BTOP_BASE 		(0xC0014000)

#define MAX_ASW					15
#define MAX_BLC 				8

	//address switch setup table
	const uint32_t asw[] =
	{
#if !SMART_BLC
		//lsaddr | offset , logical 				physical 				size
		0x00, 0x00, // 0 	0x00000000-0x26FFFFFF => 0x00000000-0x26FFFFFF : 624MB
		0x27, 0x59, // 1 	0x27000000-0x3BFFFFFF => 0x80000000-0x94FFFFFF : 336MB
					//  	0x3C000000-0x46FFFFFF => 0x95000000-0x9FFFFFFF : 176MB(1.5GB MODEL)
					// 1 	0x27000000-0x5BFFFFFF => 0x80000000-0xB4FFFFFF : 848MB(2GB MODEL)
		0x5C, 0x00, // 2 	NA
		0x67, 0x00, // 3 	0x67000000-0x7FFFFFFF => 0x67000000-0x7FFFFFFF : 400MB
		0x90, 0x25, // 4 	0x90000000-0x9AFFFFFF => 0xB5000000-0xBFFFFFFF : 176MB
		0x9B, 0x00,	// 5 	NA
		0xA0, 0x00,	// 6 	NA
		0xC0, 		// 7
#else
		//smart blc
		//lsaddr | offset , logical 				physical 				size
		0x00, 0x00, // 0 	0x00000000-0x29FFFFFF => 0x00000000-0x29FFFFFF : 672MB
		0x2A, 0x2B, // 1 	0x2A000000-0x3BFFFFFF => 0x55000000-0x66FFFFFF : 288MB
		0x3C, 0x59, // 2 	0x3C000000-0x46FFFFFF => 0x9500ffff-0x9FFFFFFF : 176MB
		0x47, 0x20, // 3 	0x47000000-0x5FFFFFFF => 0x67000000-0x7FFFFFFF : 400MB
		0x60, 0x00, // 4 	0x67000000-0x7FFFFFFF => 0x67000000-0x7FFFFFFF : 400MB
		0x90, 0x25, // 5 	0x90000000-0x9AFFFFFF => 0xB5000000-0xBFFFFFFF : 176MB
		0x9B, 0x65, // 6 	0x9B000000-0xBFFFFFFF => 0x00000000-
		0xC0,		// 7
#endif
	};

#if SMART_BLC
	//smart balancer setup table
	const uint32_t blc[] =
	{
		//lsaddr | esaddr
		0x00, 		0x29, 	// 0 0x00000000-0x29FFFFFF => 0x0-0x14FFFFFF, 0x80000000-0x94FFFFFF
	};
#if 0//don't use 2nd addreess switch
	//address switch setup 2nd table
	const uint32_t asw_2nd[] = 
	{
		0xFF, 0x00, // 0 	
		0xFF, 0x00, // 1 	
		0xFF, 0x00, // 2 	
		0xFF, 0x00, // 3 	
		0xFF, 0x00, // 4 	
		0xFF, 0x00, // 5 	
		0xFF, 0x00, // 6 	
		0xFF, 		// 7
	};
#endif
#endif

	//memory protector setup table
	const uint32_t mrange[4] =
	{//least address per 0x1000
		//base 		| 	end
		0x00000000, 	0x66FFF000, // 0 : 0x00000000-0x66FFFFFF
		0x80000000, 	0xb4FFF000, // 1 : 0x80000000-0xB4FFFFFF
	};

	const uint32_t asw_base[] =
	{
		//start0/offset0/start1/offset1/.../start7/ : 15byte
		BUS_CTRL_ATOP_BASE + 0x0040,
		BUS_CTRL_BTOP_BASE + 0x0040,
	};

#if SMART_BLC
	const uint32_t blc_base[] =
	{
		//start0/end0/start1/end1/.../start3/end3/ : 8byte
		BUS_CTRL_ATOP_BASE + 0x00C0,
		BUS_CTRL_BTOP_BASE + 0x00C0,
	};
	
#if 0//don't use 2nd addreess switch
	//address switch setup 2nd table
	const uint32_t asw_2nd_base[] = 
	{
		//start0/offset0/start1/offset1/.../start7/ : 15byte
		BUS_CTRL_ATOP_BASE + 0x0080,
		BUS_CTRL_BTOP_BASE + 0x0080,
	};
#endif
#endif

	const uint32_t mem_prot_base[] =
	{
		//D0/D4/D8/DC
		//base0/end0/base1/end1/ : 4byte
		BUS_CTRL_ATOP_BASE + 0x03D0, // VDEC 	0
		BUS_CTRL_ATOP_BASE + 0x05D0, // HEVC0 	1
		BUS_CTRL_ATOP_BASE + 0x07D0, // HEVC1 	2
		//BUS_CTRL_ATOP_BASE + 0x09D0, // CPU0
		//BUS_CTRL_ATOP_BASE + 0x0BD0, // GPU0
		//BUS_CTRL_ATOP_BASE + 0x0DD0, // USB0
		//BUS_CTRL_ATOP_BASE + 0x0FD0, // GPU1
		//BUS_CTRL_ATOP_BASE + 0x11D0, // CPU1
		//BUS_CTRL_ATOP_BASE + 0x13D0, // PERI
		BUS_CTRL_ATOP_BASE + 0x15D0, // VDEC_MCU 	3
		BUS_CTRL_ATOP_BASE + 0x17D0, // IDS_MCU 	4

		BUS_CTRL_BTOP_BASE + 0x03D0, // DPE 		5
		BUS_CTRL_BTOP_BASE + 0x05D0, // DPP 		6
		BUS_CTRL_BTOP_BASE + 0x07D0, // FDA 		7
		BUS_CTRL_BTOP_BASE + 0x09D0, // DEO 		8
		BUS_CTRL_BTOP_BASE + 0x0BD0, // DEM 		9
		BUS_CTRL_BTOP_BASE + 0x0DD0, // DEI 		10
		BUS_CTRL_BTOP_BASE + 0x0FD0, // CVD 		11
		BUS_CTRL_BTOP_BASE + 0x11D0, // TE 			12
		BUS_CTRL_BTOP_BASE + 0x15D0, // FDD1 		13
		BUS_CTRL_BTOP_BASE + 0x17D0, // FDB 		14
		BUS_CTRL_BTOP_BASE + 0x19D0, // FDC 		15
		BUS_CTRL_BTOP_BASE + 0x1BD0, // VENC 		16
		BUS_CTRL_BTOP_BASE + 0x1DD0, // GFX 		17
		BUS_CTRL_BTOP_BASE + 0x1FD0, // AUD 		18
	};


	int i,j;
	volatile uint32_t *ctrl_reg;
	const int count_asw 	= ARRAY_SIZE(asw);
#if SMART_BLC
	//const int count_asw_2nd = ARRAY_SIZE(asw_2nd);
	const int count_blc 	= ARRAY_SIZE(blc);
#endif

	STATIC_ASSERT((count_asw 		== MAX_ASW), "Over max asw bank");
#if SMART_BLC
	//STATIC_ASSERT((count_asw_2nd 	== MAX_ASW), "Over max asw bank");
	STATIC_ASSERT((count_blc 		<= MAX_BLC), "Over max blc bank");
#endif

	//address switch
	for(i = 0; i < ARRAY_SIZE(asw_base); i++)
	{
		ctrl_reg = (volatile uint32_t *)asw_base[i];
		for(j = (count_asw-1); j >=0 ; j--)
			REG_WRITE_ADDRSW(&ctrl_reg[j], (asw[j] << 24));
	}

#if SMART_BLC
	//smart balancer
	for(i = 0; i < ARRAY_SIZE(blc_base); i++)
	{
		ctrl_reg = (volatile uint32_t *)blc_base[i];
		for(j = (count_blc-1); j >= 0; j--)
			REG_WRITE_ADDRSW(&ctrl_reg[j], (blc[j] << 24));
	}

#if 0//don't use 2nd addreess switch
	//address switch 2nd
	//asw_2nd regs of CTOPB were not used,
	//asw_2nd regs of CTOPA control both m0 and m1
	ctrl_reg = (volatile uint32_t *)asw_2nd_base[0];//m0 hidden asw
	for(j = (count_asw_2nd-1); j >=0 ; j--)
		REG_WRITE_ADDRSW(&ctrl_reg[j], (asw_2nd[j] << 24));
#endif
#endif//SMART_BLC

	//memory protector
	for(i = 0; i < ARRAY_SIZE(mem_prot_base); i++)
	{
		ctrl_reg = (volatile uint32_t *)mem_prot_base[i];

		REG_WRITE_ADDRSW(&ctrl_reg[0], mrange[0]);
		REG_WRITE_ADDRSW(&ctrl_reg[1], mrange[1]);
		REG_WRITE_ADDRSW(&ctrl_reg[2], mrange[2]);
		REG_WRITE_ADDRSW(&ctrl_reg[3], mrange[3]);
	}

}

static void set_addr_switch_c0(void)
{
#define BUS_CTRL_ATOP_BASE 		(0xC0010000)
#define BUS_CTRL_BTOP_BASE 		(0xC0014000)

#define MAX_ASW					15
#define MAX_BLC 				8

	//address switch setup table
	const uint32_t asw[] =
	{
		//lsaddr | offset , logical 				physical 				size
		0x00, 0x00, // 0 	0x00000000-0x25FFFFFF => 0x00000000-0x25FFFFFF : 608MB
		0x26, 0x5A, // 1 	0x26000000-0x3AFFFFFF => 0x80000000-0x94FFFFFF : 336MB
					//  	0x3B000000-0x45FFFFFF => 0x95000000-0x9FFFFFFF : 176MB(1.5GB MODEL)
					// 1 	0x26000000-0x5AFFFFFF => 0x80000000-0xB4FFFFFF : 848MB(2GB MODEL)
		0x5B, 0x00, // 2 	NA
		0x66, 0x00, // 3 	0x66000000-0x7FFFFFFF => 0x66000000-0x7FFFFFFF : 416MB
		0x90, 0x25, // 4 	0x90000000-0x9AFFFFFF => 0xB5000000-0xBFFFFFFF : 176MB
		0x9B, 0x00,	// 5 	NA
		0xA0, 0x00,	// 6 	NA
		0xC0, 		// 7
	};

	//memory protector setup table
	const uint32_t mrange[4] =
	{//least address per 0x1000
		//base 		| 	end
		0x00000000, 	0x65FFF000, // 0 : 0x00000000-0x65FFFFFF
		0x80000000, 	0xb4FFF000, // 1 : 0x80000000-0xB4FFFFFF
	};

	const uint32_t asw_base[] =
	{
		//start0/offset0/start1/offset1/.../start7/ : 15byte
		BUS_CTRL_ATOP_BASE + 0x0040,
		BUS_CTRL_BTOP_BASE + 0x0040,
	};

	const uint32_t mem_prot_base[] =
	{
		//D0/D4/D8/DC
		//base0/end0/base1/end1/ : 4byte
		BUS_CTRL_ATOP_BASE + 0x03D0, // VDEC 	0
		BUS_CTRL_ATOP_BASE + 0x05D0, // HEVC0 	1
		BUS_CTRL_ATOP_BASE + 0x07D0, // HEVC1 	2
		//BUS_CTRL_ATOP_BASE + 0x09D0, // CPU0
		//BUS_CTRL_ATOP_BASE + 0x0BD0, // GPU0
		//BUS_CTRL_ATOP_BASE + 0x0DD0, // USB0
		//BUS_CTRL_ATOP_BASE + 0x0FD0, // GPU1
		//BUS_CTRL_ATOP_BASE + 0x11D0, // CPU1
		//BUS_CTRL_ATOP_BASE + 0x13D0, // PERI
		BUS_CTRL_ATOP_BASE + 0x15D0, // VDEC_MCU 	3
		BUS_CTRL_ATOP_BASE + 0x17D0, // IDS_MCU 	4

		BUS_CTRL_BTOP_BASE + 0x03D0, // DPE 		5
		BUS_CTRL_BTOP_BASE + 0x05D0, // DPP 		6
		BUS_CTRL_BTOP_BASE + 0x07D0, // FDA 		7
		BUS_CTRL_BTOP_BASE + 0x09D0, // DEO 		8
		BUS_CTRL_BTOP_BASE + 0x0BD0, // DEM 		9
		BUS_CTRL_BTOP_BASE + 0x0DD0, // DEI 		10
		BUS_CTRL_BTOP_BASE + 0x0FD0, // CVD 		11
		BUS_CTRL_BTOP_BASE + 0x11D0, // TE 			12
		BUS_CTRL_BTOP_BASE + 0x15D0, // FDD1 		13
		BUS_CTRL_BTOP_BASE + 0x17D0, // FDB 		14
		BUS_CTRL_BTOP_BASE + 0x19D0, // FDC 		15
		BUS_CTRL_BTOP_BASE + 0x1BD0, // VENC 		16
		BUS_CTRL_BTOP_BASE + 0x1DD0, // GFX 		17
		BUS_CTRL_BTOP_BASE + 0x1FD0, // AUD 		18
	};


	int i,j;
	volatile uint32_t *ctrl_reg;
	const int count_asw 	= ARRAY_SIZE(asw);

	STATIC_ASSERT((count_asw 		== MAX_ASW), "Over max asw bank");

	//address switch
	for(i = 0; i < ARRAY_SIZE(asw_base); i++)
	{
		ctrl_reg = (volatile uint32_t *)asw_base[i];
		for(j = (count_asw-1); j >=0 ; j--)
			REG_WRITE_ADDRSW(&ctrl_reg[j], (asw[j] << 24));
	}

	//memory protector
	for(i = 0; i < ARRAY_SIZE(mem_prot_base); i++)
	{
		ctrl_reg = (volatile uint32_t *)mem_prot_base[i];

		REG_WRITE_ADDRSW(&ctrl_reg[0], mrange[0]);
		REG_WRITE_ADDRSW(&ctrl_reg[1], mrange[1]);
		REG_WRITE_ADDRSW(&ctrl_reg[2], mrange[2]);
		REG_WRITE_ADDRSW(&ctrl_reg[3], mrange[3]);
	}

}


void set_addr_switch(void)
{
	if(get_chip_rev() < LX_CHIP_REV(M14 ,B0))
		set_addr_switch_a0();
	else if(get_chip_rev() < LX_CHIP_REV(M14 ,C0))
		set_addr_switch_b0();
	else
		set_addr_switch_c0();
}

#else
void set_addr_switch(void){}
#endif

