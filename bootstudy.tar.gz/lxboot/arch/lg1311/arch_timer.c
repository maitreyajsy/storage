#include <types.h>
#include <stdio.h>
#include <string.h>
#include <arch/irqs.h>
#include <arch/timers.h>
#include <system.h>
#include <interrupt.h>
#include <timer.h>
#include <thread.h>
#include <command.h>

#ifdef FIRST_BOOT
#define TIMER_INFO(fmt, args...)	do{}while(0)
#else
#define TIMER_INFO(fmt, args...)	printf(fmt, ##args)
#endif


#if USE_TIMER_IRQ
static timer_t *timer0 = TIMER(0);
#endif

static timer_t *timer1 = TIMER(1);

static u32 initial_clock = 0;
static int timer_tick_inited = 0;
static u32 loop_clk_base;
static u32 clk_rate;

static u32 last_tick;

#ifdef USE_TIMER_IRQ
static volatile uint32_t mticks;

static spin_lock_t	timer_spin_lock = INIT_SPIN_LOCK;

#define timer_lock(flags) \
	do{ flags = interrupt_save(); spin_lock(&timer_spin_lock); }while(0)

#define timer_unlock(flags) \
	do{ spin_unlock(&timer_spin_lock); interrupt_restore(flags); }while(0)



static u64 base_clock	= 0;
static u64 base_tick;
static u64 timer_clock(void)
{
	u64 clock;
	u32 flags, tick;

	timer_lock(flags);
	tick = timer_tick();
	clock = base_clock + timer_ticks2usec((uint32_t)(tick - last_tick));
	timer_unlock(flags);

	return clock;
}

static void timer_irq_handler(void *unused)
{
	u32 tick;
	u32 diff_tick;

	spin_lock(&timer_spin_lock);
	mticks += (1000/TIMER_FREQ);

	tick = timer_tick();
	diff_tick = (uint32_t)(tick - last_tick);
	base_clock += timer_ticks2usec(diff_tick);
	base_tick += diff_tick;
	last_tick = tick;

	spin_unlock(&timer_spin_lock);

	timer0->intclr = 0x01;		// clear interrupt flag
}

uint64_t timer_ltick(void)
{
	u64 ltick;
	u32 flags, tick;

	timer_lock(flags);
	tick = timer_tick();
	ltick = base_tick + (uint32_t)(tick - last_tick);
	timer_unlock(flags);

	return ltick;
}

uint64_t timer_lticks2usec(uint64_t lticks)
{
	return (uint32_t)(lticks/clk_rate);
}
#else
#define timer_lock(flags)	do{(void)flags;}while(0)
#define timer_unlock(flags)	do{(void)flags;}while(0)


static u32 wcount, wremainder;
static u64 wusec;
static u64 timer_clock(void)
{
	u32 tick;

	tick = timer_tick();
	if(tick < last_tick)	/* wrap around */
	{
		u64 wtick;
		wcount++;
		wtick = (u64)wcount << 32;
		wusec = wtick / clk_rate;
		wremainder = wtick % clk_rate;
	}
	last_tick = tick;

	return (wusec +	(tick + wremainder) / clk_rate);
}
#endif

#define TIME1_SET_VALUE		(TIMER_CTRL_FREERUN  | TIMER_CTRL_32BIT | TIMER_CTRL_ENABLE)
void early_timer_init(void)
{
	loop_clk_base = get_clk(CLK_DEV_CPU);
	clk_rate = get_clk(CLK_DEV_TIMER)/1000000;

	timer_tick_inited = 1;

	/* we will keep the time if the timer already started with same configuration */
	if(timer1->control != TIME1_SET_VALUE)
	{
		// enable timer1 to get high resoultion time
		timer1->control = TIMER_CTRL_DISABLE;
		timer1->load	= TIMER1_RELOAD;
		timer1->control = TIMER_CTRL_FREERUN  | TIMER_CTRL_32BIT | TIMER_CTRL_ENABLE;
	}
	else
	{
		u32 initial_tick	= timer_tick();

		initial_clock	= timer_ticks2usec(initial_tick);
#if USE_TIMER_IRQ
		last_tick		= initial_tick;
		base_clock		= initial_clock;
#endif
	}


}

u32 timer_initial_clock(void)
{
	return initial_clock;
}

void timer_init(void)
{
#if USE_TIMER_IRQ
	mticks = 0;

	// enable timer 0 to increse ms tick
	timer0->control	= TIMER_CTRL_DISABLE;
	timer0->load 	= TIMER0_RELOAD;
	timer0->control = TIMER_CTRL_PERIODIC | TIMER_CTRL_32BIT |
					  TIMER_CTRL_IE | TIMER_CTRL_ENABLE | TIMER0_PRESCALER;

	interrupt_request(IRQ_TIMER0_1, timer_irq_handler, NULL);
	interrupt_active(IRQ_TIMER0_1);
#endif

	TIMER_INFO("Timer Inited\n");

#if !defined(FIRST_BOOT)
	printf("Initial Time : %d.%03dms\n", initial_clock/1000, initial_clock%1000);
	printf("Elapsed Time : ROM[%d.%03dms], 1ST BOOT[%d.%03dms]\n",
		 get_bootrom_elapsed_time()/1000, get_bootrom_elapsed_time()%1000,
		 get_1stboot_elapsed_time()/1000, get_1stboot_elapsed_time()%1000);
#endif

}


uint64_t timer_usec(void)
{
	return timer_clock();
}

uint32_t timer_msec(void)
{
	u32 msec;
	msec = timer_clock()/1000;
	return msec;
}

uint32_t timer_sec(void)
{
	return timer_msec() / 1000;
}

void mdelay(uint32_t msec)
{
	uint32_t end_msec;
	volatile uint32_t cur_msec;

	if(!timer_tick_inited)
	{
		loop_mdelay(msec);
		return;
	}

	cur_msec = timer_msec();
	end_msec = cur_msec + msec;

	while( 1 )
	{
		cur_msec = timer_msec();
		if( cur_msec >= end_msec ) break;
		loop_udelay(100);	// 100 usec
	}
}

void udelay(uint32_t usec)
{
	volatile uint32_t tmo, ticks;

	if(!timer_tick_inited)
	{
		loop_udelay(usec);
		return;
	}

	ticks = clk_rate * usec;
	tmo = timer1->value;

	while((uint32_t)(tmo - timer1->value) < ticks);
}

uint32_t timer_tick(void)
{
	if(!timer_tick_inited) return 0;

	return (uint32_t)(TIMER1_RELOAD - timer1->value);
}

uint32_t timer_ticks2usec(uint32_t ticks)
{
	return (uint32_t)(ticks/clk_rate);
}

/* in usec unit */
uint32_t timer_elapsed(uint32_t ticks)
{
	return timer_ticks2usec((uint32_t)(timer_tick() - ticks));
}

void loop_udelay(uint32_t usec)
{
	cpu_loop(loop_clk_base / 1000000 * usec);
}

void loop_mdelay(uint32_t msec)
{
	uint32_t sec = msec/1000;
	uint32_t ms = msec%1000;

	while(sec != 0)
	{
		cpu_loop(loop_clk_base);
		--sec;
	}
	if(ms) cpu_loop(loop_clk_base / 1000 * ms);
}


#if USE_MULTI_THREAD

#ifdef THREAD_PREEMPTIVE
/* THREAD_PREEMPTIVE ����� ��� scheduler�� timer�� �ʿ����� �ʴ�.
 * �� timeout �����θ� ����ϸ� �Ǵµ� �� ��쿡�� timeout��������
 * ���ͷ�Ʈ�� �߻��ϵ��� �Ѵ�. */
#define SINGLE_LOCAL_TIMER
#endif

#define local_timer_lock(flags) \
	do{ flags = interrupt_save(); }while(0)

#define local_timer_unlock(flags) \
	do{ interrupt_restore(flags); }while(0)


#define LOCAL_TIMER_PRESCALER		0

#define LOCAL_TIMER_INTERVAL		1	/*1*/		/* ms unit */
#define LOCAL_TIMER_LOAD			(LOCAL_TIMER_INTERVAL*(local_timer_clk/1000) - 1)

/*
 *                  (PRESCALER_value+1)*(LOAD_value+1)
 * Timer Interval = -----------------------------------
 *                               PHRIPHCLK
 *
 * if PRESCALER = 0 the
 *   LOAD_value = Interval*CLK - 1;
 *
 *
 */


/* Local Timer(PrivateTimer) */
typedef struct local_timer_event
{
	int started;
	u32 timeout;
	u64 expired;
	u32 mode;
	void (*handler)(void*);
	void *arg;
} local_timer_event_t;

typedef void (*timer_handler_t)(void);

static local_timer_t *local_timer = LOCAL_TIMER(0);

#ifdef SINGLE_LOCAL_TIMER
static local_timer_event_t local_timer_event[CPU_NUM];
#else
static local_timer_event_t local_timer_event[CPU_NUM][LOCAL_TIMER_EVENT_NUM];
#endif

static uint32_t local_timer_clk;

static inline local_timer_event_t* get_local_timer_event(u32 eid)
{
#ifdef SINGLE_LOCAL_TIMER
	return &local_timer_event[get_cpu_id()];
#else
	local_timer_event_t* e = NULL;
	if(eid < LOCAL_TIMER_EVENT_NUM)
		e = (local_timer_event_t*)&local_timer_event[get_cpu_id()][eid];
	return e;
#endif
}

static void local_timer_irq_handler(void *args)
{
	u32 cpu_id = (u32)args;

	local_timer->intsts = 0x1;		// clear interrupt flag

#ifdef SINGLE_LOCAL_TIMER
	local_timer_event_t* event = &local_timer_event[cpu_id];

	if(event->started)
	{
		if(event->mode == LOCAL_TIMER_MODE_ONESHOT)
			event->started = 0;
		else	// REPEAT ����� ��� �̹� REPEAT ���� timer�� ������ �Ǿ���.
			event->expired = timer_usec() + event->timeout;

		event->handler(event->arg);
	}
	else
	{
		printf("^r^local_timer_irq_handler[%d] not started..\n", cpu_id);
	}
#else
	int i;
	volatile u64 usec;
	local_timer_event_t* event = local_timer_event[cpu_id];

	for(i=0; i<LOCAL_TIMER_EVENT_NUM; i++)
	{
		if(event[i].started)
		{
			usec = timer_usec();
			if(event[i].expired < usec)
			{
				if(event[i].mode == LOCAL_TIMER_MODE_ONESHOT)
					event[i].started = 0;
				else
					event[i].expired = usec + event[i].timeout;

				/* handler���� �� ����� ���������� ���� ������ �߿��� */
				event[i].handler(event[i].arg);
			}
		}
	}
#endif


}

void local_timer_init(void)
{
	local_timer_clk = get_clk(CLK_DEV_CPU) >> 1;

	local_timer->control = 0;

#if !defined(SINGLE_LOCAL_TIMER)
	local_timer->load = LOCAL_TIMER_LOAD;
	local_timer->control = (LOCAL_TIMER_CTRL_IRQ_ENABLE |
						 LOCAL_TIMER_CTRL_AUTO_RELOAD |
						 LOCAL_TIMER_CTRL_ENABLE);
#endif

	interrupt_request(IRQ_LOCALTIMER, local_timer_irq_handler, (void*)get_cpu_id());
	interrupt_active(IRQ_LOCALTIMER);
}

void local_timer_register(int eid, void (*handler)(void*), void* arg)
{
	local_timer_event_t* e = get_local_timer_event(eid);
	if(e == NULL) return;

	e->started = 0;
	e->handler = handler;
	e->arg = arg;
}

void local_timer_start(int eid, u32 timeout, u32 mode)
{
	u32 flags;
	local_timer_event_t* e = get_local_timer_event(eid);
	if(e == NULL) return;

	local_timer_lock(flags);

	e->timeout = timeout;
	e->mode = mode;
	e->expired = timer_usec() + timeout;
	e->started = 1;

#ifdef SINGLE_LOCAL_TIMER
	if(timeout == 0)
	{
		timeout = 1;
		printf("^r^local_timer_start. timeout is 0\n");
	}

//	local_timer->control = 0;
	local_timer->load = (timeout * (local_timer_clk/1000/1000) - 1);	// timeout : usec unit
	local_timer->control =
		LOCAL_TIMER_CTRL_IRQ_ENABLE |
		((mode == LOCAL_TIMER_MODE_ONESHOT) ?
			LOCAL_TIMER_CTRL_SINGLE_SHOT :
			LOCAL_TIMER_CTRL_AUTO_RELOAD) |
		LOCAL_TIMER_CTRL_ENABLE;

//	printf("Local Timer Start. %dus timeout, mode:%d\n", timeout, mode);
#endif

	local_timer_unlock(flags);
}

void local_timer_stop(int eid)
{
	u32 flags;
	local_timer_event_t* e = get_local_timer_event(eid);
	if(e == NULL) return;

	local_timer_lock(flags);
	e->started = 0;
#ifdef SINGLE_LOCAL_TIMER
	local_timer->control = 0;
#endif

	local_timer_unlock(flags);
}
#endif


static int timer_cmd(int argc, char **argv)
{
	u64 usec = timer_usec();
	printf("Current Time : %d.%06d Sec\n", (u32)(usec/1000000), (u32)(usec%1000000));

	if(argc >= 2)
	{
		if(!strcmp(argv[1], "initial"))
		{
			printf("Initial Time : %dus\n", initial_clock);
		}
		else if(!strcmp(argv[1], "tick"))
		{
			u32 tick = timer_tick();
			printf("Tick:0x%x(%dus)\n", tick, timer_ticks2usec(tick));
		}
		else if(!strcmp(argv[1], "loop"))
		{
			u32 stick, elapsed;

			stick = timer_tick();
			loop_mdelay(1);
			elapsed = timer_elapsed(stick);
			printf("Loop 1ms = %uus\n", elapsed);

			stick = timer_tick();
			loop_mdelay(300);
			elapsed = timer_elapsed(stick);
			printf("Loop 300ms = %ums\n", elapsed/1000);

			stick = timer_tick();
			loop_mdelay(3000);
			elapsed = timer_elapsed(stick);
			printf("Loop 3s = %ums\n", elapsed/1000);
		}
	}

	return 0;
}
COMMAND(time, timer_cmd, "Time", NULL);

