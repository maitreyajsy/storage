/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

/*===========================================================================================================
|  HISTORY
|------------------------------------------------------------------------------------------------------------
|   Date        	WHO					Modifications
|------------------------------------------------------------------------------------------------------------
|	? 	? 	2011	ks.hyun@lge.com 	Release initial codes for lxboot in arch/lg1152 folder.
|	? 	? 	2011	yw.kim@lge.com		Copy this file from arch/lg1152 to arch/lg1154 for m13 evaluation.
|	Mar	4	2012	yw.kim@lge.com		Add normal world secondary cpu initialization function.
|============================================================================================================*/

#include <types.h>
#include <string.h>
#include <arch/cpu.h>
#include <arch/irqs.h>
#include <arch/timers.h>
#include <interrupt.h>
#include <mmu.h>
#include <arch/ctop_regs.h>
#include <gpio.h>
#include <timer.h>
#include <i2c.h>
#include <system.h>
#include <command.h>
#include <serial.h>
#include <thread.h>
#ifdef CONFIG_SUPPORT_DISASM
#include <arch/dsm.h>
#endif
#ifdef CONFIG_SUPPORT_BACKTRACE
#include <backtrace.h>
#endif

#if USE_TZ_BOOT
#include <arch/tz.h>
#endif

extern void _data_abort(void);
extern void _undefined_instruction(void);
extern void _software_interrupt(void);
extern void _prefetch_abort(void);
extern void _not_used(void);
extern void _irq(void);
extern void _fiq(void);
static void exec_reset(void);

#define NUM_EXEC_VECTOR		8

#ifndef VECTOR_BASE
#define VECTOR_BASE			0x00
#endif

#ifndef M14A_I2C_CH
#define M14A_I2C_CH 8	/* M14A */
#endif

#define EXIT_JMP	(0)
#define EXIT_BOT	(1)

typedef struct
{
	unsigned long offset;
	void (*func)(void);
} exec_vector_t;

static exec_vector_t exec_vector[NUM_EXEC_VECTOR] =
{
	{0x00,	exec_reset				},
	{0x04,	_undefined_instruction	},
	{0x08,	_software_interrupt		},
	{0x0C,	_prefetch_abort			},
	{0x10,	_data_abort				},
	{0x14,	_not_used				},
	{0x18,	_irq					},
	{0x1C,	_fiq					},
};

typedef struct
{
	u32	exception;
	u32	cpsr;
	u32	spsr;

	u32	reg[16];
} exec_regs_t;


/* M14A0 */
volatile CTOP_CTRL_REG_T *ctop_regs = (volatile CTOP_CTRL_REG_T *)LG1311_A0_TOPCTRL_BASE;

/* M14B0 */
volatile CTOP_TOP_REG_M14B0_T *ctop_top_regs = (volatile CTOP_TOP_REG_M14B0_T *)LG1311_B0_CTOP_TOP_BASE;
volatile CTOP_LEFT_REG_M14B0_T *ctop_left_regs = (volatile CTOP_LEFT_REG_M14B0_T *)LG1311_B0_CTOP_LEFT_BASE;
volatile CTOP_RIGHT_REG_M14B0_T *ctop_right_regs = (volatile CTOP_RIGHT_REG_M14B0_T *)LG1311_B0_CTOP_RIGHT_BASE;

volatile int smp_inited = 0;

static uint32_t chip_rev = CONFIG_CHIP;
static uint32_t ace_rev = CONFIG_CHIP;


static void exec_reset(void)
{
	printf("exec_reset !!!\n");
	do{}while(0);

}


static void watchdog_init(void)
{
	watchdog_t *wdt = (watchdog_t*)LG1311_WATCHDOG_BASE;

	wdt->load = 0xFFFFFFFF;
	wdt->control = 0;	/* disable watchdog */
}


//#define HIGH_VECTOR_MODE
static u32 set_exec_vector(void)
{
#ifdef HIGH_VECTOR_MODE
	unsigned long vector_base = 0xFFFF0000;
	unsigned long value = read_cp15_sctlr();
	value |= CP15_SCTLR_VECTOR;
	write_cp15_sctlr(value);
#else
	unsigned long vector_base = VECTOR_BASE;
	/* armv7������ vector base�� ���� �����ϴ� */
	write_cp15_vbar(vector_base);
#endif
	return vector_base;
}

static void exec_vector_init(void)
{
	int i;
	unsigned long branch_offset;
	unsigned long vector_base = set_exec_vector();

	/*
	 * TEXT_BASE�� 0������ �ƴ� ��� ����� �ʿ��ϸ� 0xEA000000 = B �� �ǹ��Ѵ�.
	 * ARM ���۷��� ������
	 */
	for(i=0; i<NUM_EXEC_VECTOR; i++)
	{
		branch_offset = (unsigned long)exec_vector[i].func;
		branch_offset -= vector_base + exec_vector[i].offset + 0x08;

		*(unsigned long*)(exec_vector[i].offset + vector_base) = (0xEA000000 | (branch_offset >> 2));
	}

}


int ace_reg_read(uint8_t slave, uint8_t addr, uint8_t *data)
{
	int idx, res;
	for(idx=0; idx<3; idx++)
	{
		res = i2c_read(M14A_I2C_CH, slave, addr, 1, data, 1, 0);
		if(res != -1) break;
	}
	if(res == -1) printf("^r^ACE : can't read slave:0x%02x, addr:0x%02x\n", slave, addr);
	return res;
}

int ace_reg_write(uint8_t slave, uint8_t addr, uint8_t data)
{
	int idx, res;
	for(idx=0; idx<3; idx++)
	{
		res = i2c_write(M14A_I2C_CH, slave, addr, 1, &data, 1, 0);
		if(res != -1) break;
	}
	if(res == -1) printf("^r^ACE : can't write slave:0x%02x, addr:0x%02x\n", slave, addr);
	return res;
}

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
static clk_dev_t clk_dev[NUM_CLK_DEV];
#else
static const clk_dev_t clk_dev[NUM_CLK_DEV] =
{
	[CLK_DEV_CPU]	= CPU_CLOCK,
	[CLK_DEV_PERI]	= PCLK,
	[CLK_DEV_UART]	= UART_CLK,
	[CLK_DEV_TIMER] = TIMER_CLK,
	[CLK_DEV_I2C]	= I2C_CLK,
};
#endif


/* chip detection */
static void chip_detect(void)
{
	uint32_t version;

	version = REG_READ(0xFD3003C4);
	if(version == 0x20120314)
	{
		u8 value = IO_READ8(0xC0223170);
		if(value != 0x00) chip_rev = ARCH_LG1311 | REV_A1;
		else chip_rev = ARCH_LG1311 | REV_A0;
		ace_rev = ARCH_LG1311 | REV_A0;
	}
	else if(version == 0x20130221)
	{
	#if 0
		u8 value = IO_READ8(0xC0223170);
		if(value != 0xB1) chip_rev = ARCH_LG1311 | REV_B0;
		else chip_rev = ARCH_LG1311 | REV_B1;
	#else
		if(!(REG_READ(0xc000e018) & (1<<11)))
			chip_rev = ARCH_LG1311 | REV_B1;
		else
			chip_rev = ARCH_LG1311 | REV_C0;
	#endif
		ace_rev = ARCH_LG1311 | REV_B0;
	}
}

void cpu_init(void)
{
	chip_detect();

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
	ctop_detect_clk();
	clk_dev[CLK_DEV_CPU]	= ctop_get_cpu_clk();
	clk_dev[CLK_DEV_PERI]	= ctop_get_pclk();
	clk_dev[CLK_DEV_UART]	= clk_dev[CLK_DEV_PERI];
	clk_dev[CLK_DEV_TIMER]	= clk_dev[CLK_DEV_PERI];
	clk_dev[CLK_DEV_I2C]	= clk_dev[CLK_DEV_PERI];
#endif

#if USE_TZ_BOOT
	tzasc_init();
#endif

	early_timer_init();
	watchdog_init();

#ifdef CONFIG_USE_DMAC_LLI
	DTVSOC_DMACInit();
	DTVSOC_DMAC_M_Pwr_Up_LLI();
#endif

	ddr_ctrl_init();
	//memprot_init();

	exec_vector_init();

#if USE_DATA_CACHE
	mmu_init();
#else
	icache_enable();
#endif

#if USE_L2_CACHE
	l2c_init();
#endif

}

uint32_t get_clk(clk_dev_t dev)
{
	return clk_dev[dev];
}

void display_arch_info(void)
{
#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
	printf("^y^M0 CLK:%dMHz, M1 CLK:%dMHz, PERI CLK:%dMHz\n",
		ctop_get_m0_clk()/MHZ, ctop_get_m1_clk()/MHZ, ctop_get_pclk()/MHZ);
#endif

#ifdef CONFIG_USE_DMAC_LLI
	printf("^r^DMAC LLI ON\n");
#endif


}

#if USE_SMP

static volatile int *cpu_local_signal = (volatile int*)CPU_LOCAL_SIGNAL;
void set_local_signal(int signal)
{
	*cpu_local_signal = signal;
	dmb();

#if USE_DATA_CACHE
/* uncached �����ε� cache control ������ �޴��� üũ ???
 * wfi ������� CPU1�� ipi interrupt�� �߻��ص� ���� �����ʴ´�.
 * L1 memory system only wake-up in case of SCU coherency request. */
	dcache_flush_range((unsigned long)CPU_LOCAL_SIGNAL, 32);
#endif
}

static int wakeup_local_cpus(void)
{
	int timeout = 1000000;	// 1sec
	volatile u32* wakeup_signal = (volatile u32*)LG1311_SYS_FLAGSSET;

	// wake up local cpus
	*wakeup_signal = CONFIG_TEXT_BASE;
	dmb();

	set_local_signal(1);
	ipi_broadcast(CPU_WAKEUP_IPI);

	while(*cpu_local_signal != 0 && timeout > 0)
	{
		loop_udelay(1);
		timeout--;
		dmb();
	}

	return (*cpu_local_signal == 0) ? 0 : -1;
}

static void smp_exit_mode(int mode)
{
	u32 tick;
	u32	ipi = CPU_EXIT_IPI;

	int timeout = 1000000;	// 1sec

	printf("Smp Exit...");

	if (mode == EXIT_JMP) ipi = CPU_EXIT2_IPI;
	else                  ipi = CPU_EXIT_IPI;

	// change local cpu to waiting status
	set_local_signal(1);
	ipi_broadcast(ipi);

	tick = timer_tick();
	while(*cpu_local_signal != 0 && timeout > 0)
	{
		loop_udelay(1);
		timeout--;
		dmb();
	}

	if(*cpu_local_signal == 0)
	{
		printf("%dus elapsed\n", timer_elapsed(tick));
	}
	else
	{
		printf("Fail !!!. _cpu_local_signal:%d, timeout:%d\n", *cpu_local_signal, timeout);
		while(1)
			;
	}
	smp_inited = 0;
}

static void smp_exit(void)
{
	smp_exit_mode(EXIT_BOT);
}

static void smp_jmp_exit(void)
{
	smp_exit_mode(EXIT_JMP);
}
#endif

/* called before jumping to linux */
static void cpu_exit_mode(int mode)
{
#if USE_SMP
	if (mode == EXIT_BOT) smp_exit();
	else                  smp_jmp_exit();
#else
	smp_inited = 0;
#endif
	interrupt_disable();
	icache_disable();

#if USE_L2_CACHE
	l2c_disable();
#endif

#if USE_DATA_CACHE
	flush_dcache();
	dcache_disable();
	mmu_disable();
#else
	cache_flush();
#endif

#if USE_SMP
	scu_disable();
#endif
}

void cpu_exit(void)
{
	cpu_exit_mode(EXIT_BOT);
}

void cpu_jmp_exit(void)
{
	cpu_exit_mode(EXIT_JMP);
}

#if USE_SMP
void smp_init(void)
{
	u32 tick;
	int rc;

	printf("Smp Init...");

#if USE_DATA_CACHE
	flush_dcache();
#if USE_L2_CACHE
	l2c_flush();
#endif
#endif

	smp_inited = 1;
	tick = timer_tick();
	rc = wakeup_local_cpus();

	if(rc == 0) printf("%dus elapsed\n", timer_elapsed(tick));
	else printf("Fail !!!\n");

}

void cpu_local_init(void)
{
	set_exec_vector();	//set exception vector base

#if USE_DATA_CACHE
	mmu_init();
#else
	icache_enable();
#endif

	interrupt_local_init();
}

void cpu_local_exit(int exitMode)
{
	extern void _cpu_exit_2nd(int);	// start.S

	interrupt_disable();
	icache_disable();

#if USE_DATA_CACHE
	flush_dcache();
#if USE_L2_CACHE
	l2c_flush();		/* dcache flush => l2c flush => mmu disable */
#endif
	dcache_disable();
	mmu_disable();
#else
	cache_flush();
#endif

	_cpu_exit_2nd(exitMode);
}
#else
void smp_init(void)
{
//	wakeup_local_cpus();
	volatile u32* wakeup_signal = (volatile u32*)LG1311_SYS_FLAGSSET;
	*wakeup_signal = CONFIG_TEXT_BASE;
	dmb();

	ipi_broadcast(CPU_WAKEUP_IPI);
	smp_inited = 1;
}
#endif

uint32_t get_chip_rev(void)
{
	return chip_rev;
}

uint32_t get_ace_rev(void)
{
	return ace_rev;
}

__attribute__((weak))
void reset(void)
{
	//Watchdog reset
	watchdog_t *wdt = (watchdog_t*)LG1311_WATCHDOG_BASE;

	interrupt_disable();

	wdt->control = 2;	/* Enable Watchdog reset output */
	wdt->load = 0x0;

	mdelay(100);
	while(1);
}

#if 0
void local_reset(void)
{
	//Watchdog reset
	local_watchdog_t *wdt = (local_watchdog_t*)LG1311_LOCALWDOG_BASE;

	interrupt_disable();

	wdt->load = 0x1;
	wdt->control = (0x1 << 3) | (0x1 << 0);	/* Enable Watchdog reset output */

	mdelay(100);
	while(1);
}

static int lreset_cmd(int argc, char* argv[])
{
	local_reset();
	return 0;
}
COMMAND(lreset, lreset_cmd, "Reset using local wdog",	NULL);
#endif

int exc_print(const char *fmt, ...)
{
	char buffer[256];
	va_list ap;
	int len;

	va_start(ap, fmt);
	len = vsprintf(buffer, fmt, ap);
	va_end(ap);

	serial_puts(CONSOLE_UART_PORT, buffer);
	return len;
}

static const char* get_mode_str(u32 m)
{
	const char* str;
	switch(m&CPSR_MODE)
	{
		case CPSR_MODE_USER:str = "User"; break;
		case CPSR_MODE_FIQ: str = "FIQ"; break;
		case CPSR_MODE_IRQ: str = "IRQ"; break;
		case CPSR_MODE_SVC: str = "SVC"; break;
		case CPSR_MODE_ABT: str = "Abort"; break;
		case CPSR_MODE_UND: str = "Undefined"; break;
		case CPSR_MODE_SYS: str = "System"; break;
		default: str = "Unknown"; break;
	}
	return str;
}

#ifdef CONFIG_SUPPORT_DISASM
static void print_exception_dsm(uint32_t pc, uint32_t lr)
{
	uint32_t	*dsmPc = NULL;
	int			i;

	if (isValidPc((uint32_t *)pc))
	{
		extern int	regPrintDsmMode(uint32_t);
		extern int	dsmInst (void* binInst, int , void*);

		dsmPc = (uint32_t *)pc - DSM_WINDOW_SZ;
HasValidLR:
		regPrintDsmMode((uint32_t)exc_print);
		exc_print("\n");
		for (i = 0; i < 2*DSM_WINDOW_SZ+1; i++, dsmPc++)
		{
			if (dsmPc == (uint32_t*)pc) exc_print("     ** ");
			else                        exc_print("        ");

			dsmInst((void*)dsmPc, (uint32_t)dsmPc, NULL);
		}
		exc_print("\n");
	}
	else if (isValidPc((uint32_t *)lr))
	{
		exc_print("[Invalid PC --> alternate with LR]");
		dsmPc = (uint32_t*)lr - DSM_WINDOW_SZ;
		goto HasValidLR;
	}
}
#endif/*CONFIG_SUPPORT_DISASM*/

void show_exec_regs(void* regs)
{
	int i;
	const char* exception;
	exec_regs_t* exec_regs = (exec_regs_t*)regs;
	const char *str_arm_reg[16] =
	{
		"a1/r0", "a2/r1", "a3/r2", "a4/r3", "v1/r4", "v2/r5", "v3/r6", "v4/r7",
		"v5/r8", "v6/r9", "v7/r10", "v8/r11", "ip/r12", "sp/r13", "lr/r14", "pc/r15"
	};

#if USE_SMP
	serial_printf(CONSOLE_UART_PORT, "CPU[%d] : ", get_current_cpu());
#endif

	switch(exec_regs->exception)
	{
		case 'D': exception = "Data Abort"; break;
		case 'U': exception = "Undefined Instruction"; break;
		case 'S': exception = "Software Interrupt"; break;
		case 'P': exception = "Prefetch Abort"; break;
		case 'N': exception = "Not Used"; break;
		case 'F': exception = "FIQ"; break;
		case 'I': exception = "IRQ"; break;
		default: exception = "???"; break;
	}
	serial_printf(CONSOLE_UART_PORT, "%s(%08x)\n", exception, exec_regs->cpsr);

	serial_printf(CONSOLE_UART_PORT, "==== register map ====\n");
	for(i=0; i<16; i+=4)
	{
		serial_printf(CONSOLE_UART_PORT, "%-6s 0x%08x    %-6s 0x%08x    %-6s 0x%08x    %-6s 0x%08x\n",
			str_arm_reg[i+0], exec_regs->reg[i+0], str_arm_reg[i+1], exec_regs->reg[i+1],
			str_arm_reg[i+2], exec_regs->reg[i+2], str_arm_reg[i+3], exec_regs->reg[i+3]);
	}
	serial_printf(CONSOLE_UART_PORT, "cpsr   0x%08x", exec_regs->spsr);
	serial_printf(CONSOLE_UART_PORT, " => (N:%d Z:%d C:%d V:%d Q:%d ",
					(exec_regs->spsr&CPSR_N_FLAG) ? 1 : 0,
					(exec_regs->spsr&CPSR_Z_FLAG) ? 1 : 0,
					(exec_regs->spsr&CPSR_C_FLAG) ? 1 : 0,
					(exec_regs->spsr&CPSR_V_FLAG) ? 1 : 0,
					(exec_regs->spsr&CPSR_Q_FLAG) ? 1 : 0);
	serial_printf(CONSOLE_UART_PORT, "%s ", (exec_regs->spsr&CPSR_E_STATE) ? "Big" : "Little");
	serial_printf(CONSOLE_UART_PORT, "A:%s I:%s F:%s T:%s %s)\n",
				(exec_regs->spsr&CPSR_A_DISABLE) ? "off" : "on",
				(exec_regs->spsr&CPSR_I_DISABLE) ? "off" : "on",
				(exec_regs->spsr&CPSR_F_DISABLE) ? "off" : "on",
				(exec_regs->spsr&CPSR_T_STATE) ? "Thumb" : "ARM",
				get_mode_str(exec_regs->spsr));

	#ifdef CONFIG_SUPPORT_DISASM
	print_exception_dsm(exec_regs->reg[15/*pc*/], exec_regs->reg[14/*lr*/]);
	#endif
	#ifdef CONFIG_SUPPORT_BACKTRACE
	{
	extern void hex_dump(ulong addr, void *data, uint32_t size, uint8_t offset);
	ulong addr = exec_regs->reg[13] - 0xc0;
	serial_printf(CONSOLE_UART_PORT, "\t>>Exception Stack<<\n");
	hex_dump((ulong)addr, (void*)addr, 0xc0*2, 4);
	backtrace(0x2000, 32, NULL, (uint32_t*)&exec_regs->reg[0], (uint32_t)exc_print);
	}
	#endif

	while(1)
		;

//	reset();
}

#if 0
static int exeception_cmd(int argc, char* argv[])
{
	if(argc == 2)
	{
		char* input = argv[1];

		if(!strcmp("dabt", input))
		{
			char* k = (char*)0xA0000003;
			*k = 0x10;
			printf("?\n");
		}
		else if(!strcmp("pabt", input))
		{
			void (*a)(void) = (void (*)(void))0x00000001;
			a();
			printf("?\n");
		}
		else if(!strcmp("und", input))
		{
			void (*a)(void) = (void (*)(void))0x20000000;
			*((u32*)0x20000000) = 0xFFFFFFFF;		// undefined instruction
			isb();
			a();
			printf("?\n");
		}
		else if(!strcmp("swi", input))
		{

		}
		else if(!strcmp("fbt", input))
		{

		}

	}
	printf("I am ok !\n");

	return 0;
}
COMMAND(exc, exeception_cmd, "exception test",	"[dabt|pabt|und]");
#endif


