/****************************************************************************************
 *   SIC Lab., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <string.h>
#include <arch/cpu.h>
#include <command.h>
#include <timer.h>

typedef struct
{
	uint8_t	base;
	uint8_t	end;
} mem_prot_range_t;

typedef struct
{
	const char*			name;
	unsigned long		reg_base;
	mem_prot_range_t*	range[2];
} mem_prot_t;


enum {
	// LBUS
	AUD_MONITOR = 0,
	GFX_MONITOR,
	ICOD_MONITOR,
	TE_MONITOR,
	VDEC_MONITOR,
	VDO_PDEC_MONITOR,
	VENC_MONITOR,
	DE_E_CVD_MONITOR,
	DE_E_MCU_MONITOR,

	// GBUS
	DE_A_MONITOR,
	DE_B_MONITOR,
	DE_C_MONITOR,
	DE_D_MONITOR,
	DVI_MONITOR,
	DVO_MONITOR,
	MEP_A_MONITOR,
	MEP_B_MONITOR,
	BVE_MCU_MONITOR,
	MC_MONITOR,
	TCON_MONITOR,

	__MAX_MONITOR
};


static mem_prot_range_t range0_default = {0x00, 0x5F};
static mem_prot_range_t range1_default = {0x80, 0xAF};

#if 0
static mem_prot_range_t range_00_1f = {0x00, 0x1F};
static mem_prot_range_t range_80_af = {0x80, 0xAF};
#endif

static mem_prot_t mem_prot_list[__MAX_MONITOR] =
{
	[AUD_MONITOR] = {
		"AUDIO",
		0xC000E100,
		{&range0_default, &range1_default},
	},
	[GFX_MONITOR] = {
		"GFX",
		0xC000E400,
		{&range0_default, &range1_default}
	},
	[ICOD_MONITOR] = {
		"ICOD",
		0xC000E500,
		{&range0_default, &range1_default}
	},
	[TE_MONITOR] = {
		"TE",
		0xC000E600,
		{&range0_default, &range1_default}
	},
	[VDEC_MONITOR] = {
		"VDEC",
		0xC000E700,
		{&range0_default, &range1_default}
	},
	[VDO_PDEC_MONITOR] = {
		"VDO/PDEC",
		0xC000E800,
		{&range0_default, &range1_default}
	},
	[VENC_MONITOR] = {
		"VENC",
		0xC000E900,
		{&range0_default, &range1_default}
	},
	[DE_E_CVD_MONITOR] = {
		"DE_E CVD",
		0xC000EE00,
		{&range0_default, &range1_default}
	},
	[DE_E_MCU_MONITOR] = {
		"DE_E MCU",
		0xC000EF00,
		{&range0_default, &range1_default}
	},

	// GBUS
	[DE_A_MONITOR] = {
		"DE_A",
		0xC0010A00,
		{&range0_default, &range1_default}
	},
	[DE_B_MONITOR] = {
		"DE_B",
		0xC0010B00,
		{&range0_default, &range1_default}
	},
	[DE_C_MONITOR] = {
		"DE_C",
		0xC0010C00,
		{&range0_default, &range1_default}
	},
	[DE_D_MONITOR] = {
		"DE_D",
		0xC0010D00,
		{&range0_default, &range1_default}
	},
	[DVI_MONITOR] = {
		"DVI",
		0xC0011100,
		{&range0_default, &range1_default}
	},
	[DVO_MONITOR] = {
		"DE_E MCU",
		0xC0011200,
		{&range0_default, &range1_default}
	},
	[MEP_A_MONITOR] = {
		"MEP-A",
		0xC0011400,
		{&range0_default, &range1_default}
	},
	[MEP_B_MONITOR] = {
		"MEP-B",
		0xC0011500,
		{&range0_default, &range1_default}
	},
	[BVE_MCU_MONITOR] = {
		"BVE-MCU",
		0xC0011600,
		{&range0_default, &range1_default}
	},
	[MC_MONITOR] = {
		"MC",
		0xC0011700,
		{&range0_default, &range1_default}
	},
	[TCON_MONITOR] = {
		"BVE-MCU",
		0xC0011A00,
		{&range0_default, &range1_default}
	},
};
#define	N_MEM_PROT_LIST		(sizeof(mem_prot_list)/sizeof(mem_prot_t))

/*There are some bugs in bus register, so we have to change the APB clock or add some delays when MMU was enabled*/
#define BUS_REG_READ(addr)			({uint32_t _v; _v = REG_READ(addr); mdelay(1); _v;})
#define BUS_REG_WRITE(addr,value)	do{REG_WRITE(addr,value); mdelay(1);}while(0)

/* Memory Protection Monitor */
void memprot_init(void)
{
	int i;

	for(i=0; i<__MAX_MONITOR; i++)
	{
		if(mem_prot_list[i].name != NULL)
		{
			uint32_t start_addr = mem_prot_list[i].range[0]->base | (mem_prot_list[i].range[1]->base << 8);
			uint32_t end_addr = mem_prot_list[i].range[0]->end | (mem_prot_list[i].range[1]->end << 8);

			REG_WRITE(mem_prot_list[i].reg_base + 0xB0, start_addr);
			REG_WRITE(mem_prot_list[i].reg_base + 0xB4, end_addr);
		}
	}
}


static int cmd_memprot(int argc, char **argv)
{
	int i;
	const char *sub_cmd;

	if(argc < 2) goto usage;

	sub_cmd = argv[1];

	if(!strcmp(sub_cmd, "stat"))
	{
		printf("== Memory Protection Area ==\n");
		for(i=0; i<__MAX_MONITOR; i++)
		{
			if(mem_prot_list[i].name != NULL)
			{
				printf("%s\n", mem_prot_list[i].name);

				uint32_t start_addr, end_addr;

				start_addr	= BUS_REG_READ(mem_prot_list[i].reg_base + 0xB0);
				end_addr	= BUS_REG_READ(mem_prot_list[i].reg_base + 0xB4);
				printf("0x%02X000000 -- 0x%02XFFFFFF\n", (start_addr>>0)&0xFF, (end_addr>>0)&0xFF);
				printf("0x%02X000000 -- 0x%02XFFFFFF\n", (start_addr>>8)&0xFF, (end_addr>>8)&0xFF);
				printf("\n");
			}
		}
	}
	else if(!strcmp(sub_cmd, "list"))
	{
		printf("== Supported IP List ==\n");
		for(i=0; i<__MAX_MONITOR; i++)
		{
			if(mem_prot_list[i].name != NULL) printf("  %s\n", mem_prot_list[i].name);
		}
	}
	else if(!strcmp(sub_cmd, "set"))
	{
		uint32_t start_addr, end_addr;
		uint32_t in_start[2], in_end[2];
		mem_prot_t *prot = NULL;

		if(argc != 7) goto usage;

		for(i=0; i<__MAX_MONITOR; i++)
		{
			if(!stricmp(mem_prot_list[i].name, argv[2]))
			{
				prot = &mem_prot_list[i];
				break;
			}
		}
		if(prot == NULL)
		{
			printf("Not supported IP(%s)\n", argv[2]);
			goto usage;
		}

		printf("== Set Memory Protection ==\n");
		start_addr	= BUS_REG_READ(prot->reg_base + 0xB0);
		end_addr	= BUS_REG_READ(prot->reg_base + 0xB4);

		in_start[0]	= strtoul(argv[3], NULL, 16) & 0xFF;
		in_end[0]	= strtoul(argv[4], NULL, 16) & 0xFF;
		printf("RANGE1 : 0x%02X000000 -- 0x%02XFFFFFF\n", in_start[0], in_end[0]);

		in_start[1]	= strtoul(argv[5], NULL, 16) & 0xFF;
		in_end[1]	= strtoul(argv[6], NULL, 16) & 0xFF;
		printf("RANGE2 : 0x%02X000000 -- 0x%02XFFFFFF\n", in_start[1], in_end[1]);

		start_addr	= in_start[1] << 8 | in_start[0];
		end_addr	= in_end[1] << 8 | in_end[1];

		BUS_REG_WRITE(prot->reg_base + 0xB0, start_addr);
		BUS_REG_WRITE(prot->reg_base + 0xB4, end_addr);
	}

	return 0;
usage:
	command_error(argv[0]);
	return -1;
}
COMMAND(memprot, cmd_memprot, "memprot ",
			"stat\n"
			"memprot list\n"
			"memprot set IP_NAME s1 e1 s2 e2 // ex)set AUDIO 0x00 0x5f 0x80 0xAF");

