
//****************************
// Includes
//****************************
#include <stdio.h>		// fprintf, fopen, fread, _fileno(?)
#include <malloc.h>		// malloc
#include <string.h>		// strcmp

#include "lz4.h"
#include "lz4_old.h"


//**************************************
// Basic Types
//**************************************
typedef struct
{
	uint32_t	magic;		// 'L','Z','4','P'
	uint32_t	osize;		// original size
	uint32_t	csize;		// compressed size
	uint32_t	bsize;		// block size
	uint32_t	nblock;		// block count
	uint32_t	version;	// version
	uint32_t	reserved[2];
} lz4p_header_t;

//****************************
// Constants
//****************************
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
#define MAGIC(a,b,c,d)		((a) | (b) << 8 | (c) << 16 | (d) << 24)
#else
#define MAGIC(a,b,c,d)		((a) << 24 | (b) << 16 | (c) << 8 | (d))
#endif

#define LZ4P_MAGIC	MAGIC('L','Z','4','P')

#define wait_for_data(func, offset)	do{ if(func && func(offset) < 0) return -1; } while(0)


int lz4p_decompress(const unsigned char *src, size_t len, unsigned char *dst, int (*wait_func)(size_t))
{
	unsigned int next_size;
	const unsigned char *in, *in_end;
	unsigned char *out;
	int res;
	lz4p_header_t *header;
	unsigned int blocksize;
	unsigned int offset = 0;

	uint32_t* next_block_size;
	uint32_t n;
	int (*decomp_func)(const char*, char*, int);
	int (*decomp_func_unknown_outputsize)(const char*, char*, int, int);

	if(len < sizeof(lz4p_header_t)) return -1;

//	printf("lz4p_decompress. src:0x%08x, len:%d, dst:0x%08x\n", src, len, dst);

	in = src;
	out = dst;
	in_end = src + len;

	offset += sizeof(lz4p_header_t);	// header
	wait_for_data(wait_func, offset);

	header = (lz4p_header_t*)in;
	in += sizeof(lz4p_header_t);

	if(header->magic != LZ4P_MAGIC)
	{
		printf("Invalid magic[0x%08x] !!!\n", header->magic);
		return -1;
	}

	if(len < header->csize)
	{
		printf("Invalid size. len:%d, expected:%d\n", len, header->csize);
		return -1;
	}
	len = header->csize;
	blocksize = header->bsize;

	offset += sizeof(uint32_t)*header->nblock;
	wait_for_data(wait_func, offset);

	next_block_size = (uint32_t*)in;
	in += sizeof(uint32_t)*header->nblock;

	if(header->version == 0)
	{
		decomp_func = LZ4_OLD_uncompress;
		decomp_func_unknown_outputsize = LZ4_OLD_uncompress_unknownOutputSize;
	}
	else
	{
		decomp_func = LZ4_uncompress;
		decomp_func_unknown_outputsize = LZ4_uncompress_unknownOutputSize;
	}

	for(n=0; n<header->nblock; n++)
	{
		next_size = next_block_size[n];
		offset += next_size;
		wait_for_data(wait_func, offset);

		if(n < (header->nblock - 1))
		{
			res = decomp_func((char*)in, (char*)out, blocksize);
			if(res < 0) goto fail;
			if(res != next_size){ res = -res; goto fail;}

			in += next_size;
			out += blocksize;
		}
		else
		{
			res = decomp_func_unknown_outputsize((char*)in, (char*)out, next_size, blocksize);
			if(res < 0) goto fail;

			out += res;
			break;
		}
	}

	return (out - dst);

fail:
	printf("LZ4P Fail. res:%d, offset:%d, nsize:%d\n", res, offset, next_size);
	return res;
}

