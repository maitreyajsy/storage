#include <types.h>
#include <stdio.h>
#include <string.h>

#define GCC_VERSION (__GNUC__ * 100 + __GNUC_MINOR__)

#if (GCC_VERSION >= 302) || (__INTEL_COMPILER >= 800) || defined(__clang__)
#  define expect(expr,value)    (__builtin_expect ((expr),(value)) )
#else
#  define expect(expr,value)    (expr)
#endif

#define likely(expr)     expect((expr) != 0, 1)
#define unlikely(expr)   expect((expr) != 0, 0)

void *memset_bio(void *p, int c, uint32_t n);
void *memcpy_bio(void *dst, const void *src, uint32_t n);

void *memset_byte(void *p, int c, uint32_t n)
{
	u32 i;
	char *d = (char *)p;

	for(i = 0; i < n; i++)
		d[i] = c;

	return p;
}
void *memcpy_byte(void *dst, const void *src, uint32_t n)
{
	u32 i;
	char *d = (char *)dst;
	char *s = (char *)src;

	for(i = 0; i < n; i++)
		d[i] = s[i];
	
	return dst;
}


//addr : 8*n, count : 8*n : bio
//addr : 8*n,  : k
// : byte

void *memset(void *p, int c, uint32_t n)
{
	if(likely(!((ulong)p & 0x07)))
		memset_bio(p, c, n);
	else
		memset_byte(p, c, n);

	return p;
}

void *memcpy(void *dst, const void *src, uint32_t n)
{
	if(likely(!((ulong)dst & 0x07) && !((ulong)src & 0x07)))
		memcpy_bio(dst, src, n);
	else
		memcpy_byte(dst, src, n);

	return dst;
}
