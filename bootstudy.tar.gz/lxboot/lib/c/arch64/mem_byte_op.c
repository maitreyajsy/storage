
#if 1 // (USE_DATA_CACHE != 1)
#include <types.h>
#include <stdio.h>
#include <string.h>
void *memset(void *p, int c, uint32_t n)
{
	u32 i;
	char *d = (char *)p;

	for(i = 0; i < n; i++)
		d[i] = c;

	return p;
}
void *memcpy(void *dst, const void *src, uint32_t n)
{
	u32 i;
	char *d = (char *)dst;
	char *s = (char *)src;

	for(i = 0; i < n; i++)
		d[i] = s[i];
	
	return dst;
}
#endif
