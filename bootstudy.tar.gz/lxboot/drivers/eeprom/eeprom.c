/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifdef USE_EEPROM

#if SHADOW_ROM

#include <i2c.h>
#include <eeprom.h>
typedef uint32_t	timeout_id_t;
#define set_timeout(x,y)	tid = tid
#define is_timeout(x)		(1)

#else

#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <timer.h>
#include <i2c.h>
#include <util.h>
#include <command.h>
#include <eeprom.h>
#endif//#else SHADOW_ROM

#ifndef EEPROM_I2C_CH
 #error "define EEPROM_I2C_CH !!!"
#endif

#ifndef EEPROM_I2C_ADDR
 #define EEPROM_I2C_ADDR		0xA0
#endif

#ifndef EEPROM_I2C_CLOCK
 #define EEPROM_I2C_CLOCK		I2C_CLOCK_400KHZ
#endif



#define EEPROM_PAGE_SIZE		64
#define EEPROM_RETRY_CNT		3
#define EEPROM_POLLING_INTERVAL	20	/* in usec */

#define EEPROM_WRITE			0
#define EEPROM_READ				1

static int eeprom_transfer(u32 offset, u8 *buf, u32 len, int mode, int progress)
{
	u8 ch = EEPROM_I2C_CH;
	u32 clock = EEPROM_I2C_CLOCK;
	uint16_t slave_addr = EEPROM_I2C_ADDR;
	u32 page_max, page_len, page_offset;
	int i, remained;
	timeout_id_t tid;

	if((offset+len) > EEPROM_TOTAL_SIZE)
	{
		printf("Invalid parameter. offset=0x%x, len=0x%x, device=0x%x\n", offset, len, EEPROM_TOTAL_SIZE);
		return -1;
	}
	set_timeout(&tid, 0);

	i2c_set_clock(ch, clock);

	page_offset = offset;
	remained = len;
	while(remained > 0)
	{
		page_max = (EEPROM_PAGE_SIZE - offset%EEPROM_PAGE_SIZE);
		page_len = (page_max > remained) ? remained : page_max;

		//128KB �̻��� ����� ��� ���� �ʿ�. ks.hyun
		if(page_offset >= 0x10000)
			slave_addr |= 0x02;
		else
			slave_addr &= ~0x02;

		if(mode == EEPROM_READ)
		{
			for(i=0; i<EEPROM_RETRY_CNT; i++)
			{
				if(i2c_read(ch, slave_addr, (page_offset&0xffff), 2, buf, page_len, 0) == page_len)
					break;
				udelay(EEPROM_POLLING_INTERVAL);
			}

			if(i == EEPROM_RETRY_CNT)
			{
				return -1;
			}
		}
		else
		{
			u8 dummy[1];
			u32 timeout;
			u32 count;

			for(i=0; i<EEPROM_RETRY_CNT; i++)
			{
				if(i2c_write(ch, slave_addr, (page_offset&0xffff), 2, buf, page_len, 0) == page_len)
					break;
				udelay(EEPROM_POLLING_INTERVAL);
			}

			if(i == EEPROM_RETRY_CNT)
			{
				return -1;
			}


			//Check the eeprom's internal write cycle.
			timeout = ((page_len+1) * 4000)/clock + 20;
			count = (timeout * 1000) / EEPROM_POLLING_INTERVAL + 1;
			while(1)
			{
				if(i2c_read(ch, slave_addr, (page_offset&0xffff), 2, dummy, 1, 0) < 0)
				{
					udelay(EEPROM_POLLING_INTERVAL);
					count--;

					if(count == 0)
					{
						printf("eeprom_write. Waiting Timeout.....\n");
						break;
					}
				}
				else
				{
					break;
				}
			}

		}

		buf += page_len;
		page_offset += page_len;
		remained -= page_len;

		if(progress)
		{
			// with 500ms interval.
			if(is_timeout(&tid) || remained == 0)
			{
				int percent = (len - remained) * 100 / len;
				printf("\r%3d%% Completed...", percent);

				set_timeout(&tid, 500);
			}
		}
	}

	return len;
}

int eeprom_read(u32 offset, u8 *buf, u32 len)
{
	return eeprom_transfer(offset, buf, len, EEPROM_READ, 0);
}

int eeprom_write(u32 offset, u8 *buf, u32 len)
{
	return eeprom_transfer(offset, buf, len, EEPROM_WRITE, 0);
}

int eeprom_read_ex(u32 offset, u8 *buf, u32 len, int progress)
{
	return eeprom_transfer(offset, buf, len, EEPROM_READ, progress);
}

int eeprom_write_ex(u32 offset, u8 *buf, u32 len, int progress)
{
	return eeprom_transfer(offset, buf, len, EEPROM_WRITE, progress);
}


#if !SHADOW_ROM
static int eeprom_cmd(int argc, char *argv[])
{
	int rc;
	u32 offset, len;
	u8 *buf;

	if (argc < 2)
		goto usage;

	if(strcmp(argv[1], "clear") == 0)
	{
		if(argc == 2)
		{
			offset = 0;
			len = EEPROM_TOTAL_SIZE;
		}
		else
		{
			offset = (u32)strtoul(argv[2], NULL, 16);
			if(argc > 3)
				len = (u32)strtoul(argv[3], NULL, 16);
			else
				len = 16;
		}

		printf("EEPROM CLEAR : \n");
		buf = (u8*)malloc(len);
		if(buf == NULL) return 1;

		memset(buf, 0xff, len);

		rc = eeprom_write_ex(offset, buf, len, 1);
		printf("\n%s\n", rc < 0 ? "ERROR" : "OK");

		free(buf);
	}
	else if(strcmp(argv[1], "read") == 0 || strcmp(argv[1], "write") == 0)
	{
		ulong addr;
		int read = strcmp(argv[1], "read") == 0 ? 1 : 0;

		if(argc < 5)
			goto usage;

		printf("EEPROM %s : ", read ? "READ" : "WRITE");

		addr = (ulong)strtoul(argv[2], NULL, 16);
		offset = (u32)strtoul(argv[3], NULL, 16);
		len = (u32)strtoul(argv[4], NULL, 16);

		if(read)
			rc = eeprom_read_ex(offset, (u8*)addr, len, 0);
		else
			rc = eeprom_write_ex(offset, (u8*)addr, len, 0);

		printf("%s\n", rc < 0 ? "ERROR" : "OK");
	}
	else if(strcmp(argv[1], "dump") == 0)
	{
		offset = 0;
		len = 64;

		if(argc >= 3)
			offset = (u32)strtoul(argv[2], NULL, 16);

		if(argc >= 4)
			len = (u32)strtoul(argv[3], NULL, 16);

		buf = (u8*)malloc(len);
		if(buf == NULL) return 1;

		printf("EEPROM DUMP : offset=0x%x, len=0x%x(%d)\n", offset, len, len);
		rc = eeprom_read_ex(offset, buf, len, 0);
		if(rc < 0)
		{
			printf("ERROR\n");
		}
		else
		{
			hex_dump(offset, buf, len, 1);
		}

		free(buf);
	}
	else goto usage;

	return (rc < 0) ? -1 : 0;
usage:
	command_error(argv[0]);
	return -1;
}


COMMAND(eeprom,	eeprom_cmd,	"eeprom read, write, dump, clear",
		"read  addr offset len\n"
		"eeprom write addr offset len\n"
		"eeprom dump  [offset len]\n"
		"eeprom clear [offset len]\n");
#endif//#if !SHADOW_ROM
#endif

