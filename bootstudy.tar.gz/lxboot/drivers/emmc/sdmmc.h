#ifndef __SDMMC_H__
#define __SDMMC_H__
//----------------- +
// VOLTAGE SETTINGS |
//------------------+
#define MMC_VDD_17_18     0x00000020
#define MMC_VDD_18_19     0x00000040
#define MMC_VDD_19_20     0x00000080

#define MMC_VDD_20_21     0x00000100
#define MMC_VDD_21_22     0x00000200
#define MMC_VDD_22_23     0x00000400
#define MMC_VDD_23_24     0x00000800

#define MMC_VDD_24_25     0x00001000
#define MMC_VDD_25_26     0x00002000
#define MMC_VDD_26_27     0x00004000
#define MMC_VDD_27_28     0x00008000

#define MMC_VDD_28_29     0x00010000
#define MMC_VDD_29_30     0x00020000
#define MMC_VDD_30_31     0x00040000
#define MMC_VDD_31_32     0x00080000

#define MMC_VDD_32_33     0x00100000
#define MMC_VDD_33_34     0x00200000
#define MMC_VDD_34_35     0x00400000
#define MMC_VDD_35_36     0x00800000


/*************************************************/
/* REGISTERS											    */
/*************************************************/
#define EMMC_BASE_ADDRESS				EMMC_BASE
#define SD_BASE_ADDRESS					(EMMC_BASE+0x100)
#define EMMC_SDMA_ADDRESS				(0x00000000)
#define EMMC_BLOCK_COUNT				(0x00000004)
#define EMMC_ARG						(0x00000008)

/*************************************************/
#define EMMC_COMMAND					(0x0000000C)
#define EMMC_CMD_DMA_ENABLE				0
#define EMMC_CMD_BLOCK_COUNT_ENABLE		1
#define EMMC_CMD_AUTO_ENABLE			2			// 2bits
#define EMMC_CMD_DATA_DIRECTION			4
#define EMMC_CMD_MULTIBLOCK				5
#define EMMC_CMD_CND_COMP_ATA			6
#define EMMC_CMD_RESPONSE_TYPE			(0+16)		// 2bits
#define EMMC_CMD_CRC_CHECK_ENABLE		(3+16)
#define EMMC_CMD_INDEX_CHECK_ENABLE		(4+16)
#define EMMC_CMD_DATA_PRESENT			(5+16)
#define EMMC_CMD_TYPE					(6+16)		// 2bits
#define EMMC_CMD_INDEX					(8+16)		// 6bits


#define	EMMC_AUTOCMD12_EN			0x1
#define	EMMC_AUTOCMD23_EN			0x2



/*************************************************/
#define EMMC_RESPONSE_0					(0x00000010)
#define EMMC_RESPONSE_1					(0x00000014)
#define EMMC_RESPONSE_2					(0x00000018)
#define EMMC_RESPONSE_3					(0x0000001C)

#define EMMC_PIO_DATA					(0x00000020)
#define EMMC_PRESENT_STATE				(0x00000024)


/*************************************************/
#define EMMC_CTRL						(0x00000028)
#define EMMC_CTRL_LED					0
#define EMMC_CTRL_WIDTH					1
#define EMMC_CTRL_HIGHSPEED				2
#define EMMC_CTRL_DMA					3	// 2bis
#define EMMC_CTRL_EXT_WIDTH				5
#define EMMC_CTRL_CARD_DETECT			6
#define EMMC_CTRL_DETECT_SIGNAL			7
#define EMMC_CTRL_BUS_POWER				8
#define EMMC_CTRL_VOLTAGE_SELECT		9 	// 3bits
#define EMMC_CTRL_HARDWARE_RESET		12
#define EMMC_CTRL_STOP_BLOCK_GAP		16
#define EMMC_CTRL_CONTINUE_REQ			17
#define EMMC_CTRL_READ_WAIT				18
#define EMMC_CTRL_IRQ_BLOCK_GAP			19
#define EMMC_CTRL_SPI					20
#define EMMC_CTRL_BOOT_EN				21
#define EMMC_CTRL_ALT_BOOT_EN			22
#define EMMC_CTRL_WAKEUP_CARD			24
#define EMMC_CTRL_WAKEUP_INSERT			25
#define EMMC_CTRL_WAKEUP_REMOVE			26
#define EMMC_CTRL_WAKEUP_EN_IRQ			16
#define EMMC_CTRL_WAKEUP_EN_INSERT		17
#define EMMC_CTRL_WAKEUP_EN_REMOVE		18


/*************************************************/
#define EMMC_CLOCK_CTRL					(0x0000002C)
#define EMMC_CLOCK_INTERNAL_ENABLE		0
#define EMMC_CLOCK_INTERNAL_STABLE		1
#define EMMC_CLOCK_ENABLE				2
#define EMMC_CLOCK_GEN_SELECT			5
#define EMMC_CLOCK_UPPER_BITS			6	// 2bits
#define EMMC_CLOCK_SDCLK_DIV			8
#define EMMC_CLOCK_DATA_TIMEOUT			16	// 4bits
#define EMMC_CLOCK_ALL_RESET			24
#define EMMC_CLOCK_CMD_RESET			25
#define EMMC_CLOCK_DATA_RESET			26




/*************************************************/
#define EMMC_INT_STATUS					(0x00000030)
#define EMMC_INT_ENABLE					(0x00000034)
#define EMMC_INT_SIGNAL					(0x00000038)
#define EMMC_INT_COMMAND_COMPLETE		0
#define EMMC_INT_TRANSFER_COMPLETE		1
#define EMMC_INT_BLOCK_GAP_EVENT		2
#define EMMC_INT_DMA					3
#define EMMC_INT_BUFFER_WRITE_READY		4
#define EMMC_INT_BUFFER_READ_READY		5
#define EMMC_INT_CARD_INSERT			6
#define EMMC_INT_CARD_REMOVE			7
#define EMMC_INT_CARD					8
#define EMMC_INT_A						9
#define EMMC_INT_B						10
#define EMMC_INT_C						11
#define EMMC_INT_RETUNNG				12
#define EMMC_INT_BOOT_ACK				13
#define EMMC_INT_BOOT_TERMINATE			14
#define EMMC_INT_ERROR					15
#define EMMC_ERR_COMMAND_TIMEOUT		(0 + 16)
#define EMMC_ERR_COMMAND_CRC			(1 + 16)
#define EMMC_ERR_COMMAND_BIT			(2 + 16)
#define EMMC_ERR_COMMAND_INDEX			(3 + 16)
#define EMMC_ERR_DATA_TIMEOUT			(4 + 16)
#define EMMC_ERR_DATA_CRC				(5 + 16)
#define EMMC_ERR_DATA_END				(6 + 16)
#define EMMC_ERR_CURRENT_LIMIT			(7 + 16)
#define EMMC_ERR_AUTOCMD				(8 + 16)
#define EMMC_ERR_ADMA					(9 + 16)
#define EMMC_ERR_TUNING					(10 + 16)
#define EMMC_ERR_RESPONSE				(12 + 16)
#define EMMC_ERR_CEATA					(13 + 16)
#define EMMC_ERR_VENDOR					(14 + 16)

#define EMMC_CTRL2						(0x0000003C)
#define EMMC_UHS_MASK					0x070000
#define EMMC_UHS_SDR12					0x000000
#define EMMC_UHS_SDR25					0x010000
#define EMMC_UHS_SDR50					0x020000
#define EMMC_UHS_SDR104					0x030000
#define EMMC_UHS_DDR50					0x040000
#define EMMC_UHS_HS400					0x050000
#define EMMC_18_SIGNALING				0x080000

#define EMMC_CAPABLITY					(0x00000040)
#define EMMC_ADMA_ADDRESS				(0x00000058)


// Interuppt Flags
#define CARD_ADMA2_INT                0x01000000
#define CARD_INT_BUS_POWER            0x00800000
#define CARD_DATA_INT_END             0x00400000
#define CARD_DATA_INT_CRC             0x00200000
#define CARD_DATA_INT_TIMEOUT         0x00100000
#define CARD_CMD_INT_INDEX            0x00080000
#define CARD_CMD_END_BIT              0x00040000
#define CARD_CMD_INT_CRC              0x00020000
#define CARD_CMD_TIMEOUT              0x00010000

//Added for SD3.0
#define ERROR_INTERRUPT               0x00008000
#define SD_BOOT_TERMINATE             0x00004000
#define SD_BOOT_ACK_RCVD              0x00002000
#define RETUNING_EVENT                0x00001000
#define CARD_INT_C	       		      0x00000800
#define CARD_INT_B       		      0x00000400
#define CARD_INT_A       		      0x00000200

#define CARD_INT_STAT_EN              0x00000100
#define CARD_REMOVE_INT               0x00000080
#define CARD_INSERT_INT               0x00000040
#define CARD_READ_READY               0x00000020
#define CARD_WRITE_READY              0x00000010
#define CARD_INT_DMA_END              0x00000008
#define CARD_BLKGP_INT                0x00000004
#define CARD_DATA_FIN                 0x00000002
#define CARD_CMD_FIN                  0x00000001


//Added for eMMC
#define CARD_BOOT_ACK_RCV        	  0x00000200
#define CARD_BOOT_TERMINATE        	  0x00000400


#define CARD_CMD_MASK                 ( CARD_CMD_FIN     | CARD_CMD_TIMEOUT |    \
                                        CARD_CMD_INT_CRC | CARD_CMD_END_BIT |     \
                                        CARD_CMD_INT_INDEX)

#define CARD_DATA_MASK                ( CARD_DATA_FIN         | CARD_INT_DMA_END  |  \
                                        CARD_READ_READY       | CARD_WRITE_READY  |   \
                                        CARD_DATA_INT_TIMEOUT | CARD_DATA_INT_CRC |    \
                                        CARD_DATA_INT_END | CARD_BOOT_TERMINATE | CARD_BOOT_ACK_RCV)


/*************************************************/
/* EMMC COMMAND								          */
/*************************************************/
#define EMMC_CMD0_IDLE_STATE				0
#define EMMC_CMD1_SEND_OP_COND				1
#define EMMC_CMD2_ALL_SEND_CID				2
#define EMMC_CMD3_SET_RELATIVE_ADDR			3
#define EMMC_CMD4_SET_DSR					4
#define EMMC_CMD5_SLEEP_AWAKE				5
#define EMMC_CMD6_SWITCH					6
#define EMMC_CMD7_SELDESEL_CARD				7
#define EMMC_CMD8_SEND_EXT_CSD				8
#define EMMC_CMD9_SEND_CSD					9
#define EMMC_CMD10_SEND_CID					10
#define EMMC_CMD13_SEND_STATUS				13

#define EMMC_CMD16_SET_BLOCK_LENGTH			16
#define EMMC_CMD17_READ_SINGLE_BLOCK		17
#define EMMC_CMD18_READ_MULTI_EBLOCK		18

#define EMMC_CMD19_EXECUTE_TUNE				19
#define EMMC_CMD21_HS200_EXECUTE_TUNE		21

#define EMMC_CMD23_SET_BLOCK_COUNT			23
#define EMMC_CMD24_WRITE_SINGLE_BLOCK		24
#define EMMC_CMD25_WRITE_MULTI_EBLOCK		25

#define EMMC_CMD35_ERASE_SRART				35
#define EMMC_CMD36_ERASE_END				36
#define EMMC_CMD38_ERASE_DO					38

/*************************************************/
/* EMMC RESPONSE  									     */
/*************************************************/
#define RSP_TYPE_NONE		0x00
#define RSP_TYPE_136		0x01
#define RSP_TYPE_48			0x02
#define RSP_TYPE_48BUSY		0x03
#define RSP_CMD_CRC			0x08
#define RSP_CMD_INDEX		0x10
#define RSP_DATA_PRESENT	0x20

#define MMC_RESP_NONE		(0)
#define MMC_RESP_R1			(RSP_TYPE_48 | RSP_CMD_INDEX | RSP_CMD_CRC)
#define MMC_RESP_R1B		(RSP_TYPE_48BUSY | RSP_CMD_INDEX | RSP_CMD_CRC)
#define MMC_RESP_R2			(RSP_TYPE_136 | RSP_CMD_CRC)
#define MMC_RESP_R3			(RSP_TYPE_48)
#define MMC_RESP_R4			MMC_RESP_R3
#define MMC_RESP_R5			MMC_RESP_R1
#define MMC_RESP_R6			MMC_RESP_R1
#define MMC_RESP_R7			MMC_RESP_R1

#define MMC_CMD_MASK		(3 << 5)
#define MMC_CMD_AC			(0 << 5)
#define MMC_CMD_ADTC		(1 << 5)
#define MMC_CMD_BC			(2 << 5)
#define MMC_CMD_BCR			(3 << 5)

//------------------------+
// Hard Ware level Registers
//------------------------+
#define HOST_LEDON                    0x01
#define HOST_VENDOR_VERSION           0x00ff
#define HOST_BASECLOCK_MASK           0x0000ff00 // for SD3.0
#define HOST_TIMEOUTCLOCK_MASK        0x0000003f
#define HOST_BASECLOCK_UNIT           7
#define HOST_BASECLOCK_SHIFT          8
#define HOST_TIMEOUTCLOCK_UNIT        0x00000080
#define HOST_BLKLEN_MASK              0x00030000
#define HOST_BLKLEN_SHIFT             16


//------------------------+
// Clock Set
//------------------------+
#define EMMC_CLOCK_INIT					0
#define EMMC_CLOCK_NOMAL				1

#define EMMC_INT_CLK_ENABLE             0x00000001
#define EMMC_CLK_INT_STABLE             0x00000002
#define EMMC_CLK_START_BIT              0x00000004
#define EMMC_DIV8_SHIFT                 8
#define EMMC_DIV_UPPER2_SHIFT			6
#define EMMC_PROGRAMMABLE_CLOCK_MODE    0x00000020
#define EMMC_CLK_BASE_DIVIDER           0xFFFF00FF
#define EMMC_DISABLE                    0xFFFFFFFC
#define EMMC_CLK_EN_BIT                 0xFFFFFFFE


#endif	// __SDMMC_H__
