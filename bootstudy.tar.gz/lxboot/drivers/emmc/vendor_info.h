#ifndef __EMMC_VENDOR_INFO_H__
#define __EMMC_VENDOR_INFO_H__
#include "emmc_host.h"

#define VENDOR_HYNIX		0x90
#define VENDOR_SANDISK_1	0x45
#define VENDOR_SANDISK_2	0x02
#define VENDOR_TOSHIBA		0x11
#define VENDOR_SAMSUNG		0x15
#define VENDOR_MICRON		0xFE
#define VENDOR_MICRON_2		0x13

void emmc_vendor_tab(struct mmc_host *host);
unsigned int emmc_vendor_host_ds(struct mmc_host *host);
unsigned char emmc_vendor_card_ds(struct mmc_host *host);
void emmc_vendor_max_clock(struct mmc_host *host);
#endif
