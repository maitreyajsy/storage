/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if (USE_EMMC == 1)
#include <types.h>
#include <debug.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <command.h>
#include <util.h>
#include <partinfo.h>
#include <emmc.h>
#include <storage.h>
#include <env.h>

#ifdef FIRST_BOOT
#define EMMC_INFO(fmt, args...)
#else
#define EMMC_INFO(fmt, args...)			printf(fmt, ##args)
#endif
#define EMMC_ERROR(fmt, args...)		printf("^r^EMMC : "fmt, ##args)

unsigned int dcache_range_ops = DCACHE_RANGE;

static struct emmc_info _emmc_info;
static struct emmc_info* emmc = &_emmc_info;
static emmc_driver_t* driver;

static int emmc_inited = 0;
#if !defined(FIRST_BOOT)
unsigned int get_emmc_klog(void)
{
	char *emmclogchar;
	char *endptr;

	emmclogchar = env_get(ENV_EMMC_KLOG);
	if (emmclogchar)
	{
		return strtoul(emmclogchar, &endptr, 0);
	}

	return 0;
}
#endif

static int emmc_check_init(void)
{
	if(!emmc_inited)
	{
		EMMC_ERROR("not inited !\n");
		return -1;
	}
	return 0;
}

static int emmc_check_param(u64 offset, u64 len)
{
	if(emmc_check_init())
		return -1;

	if((offset + len) > emmc->chip_size)
	{
		EMMC_ERROR("offset + len is over chip size !\n");
		return -1;
	}

	if(len == 0)
	{
		EMMC_ERROR("length is zero !\n");
		return -1;
	}
	return 0;
}

#if USE_STORAGE_DMA_READ
typedef struct emmc_cmd_data
{
	loff_t			from;		// start offset
	size_t			len;		// size
	uint8_t*		buf;		// buffer

	size_t			current;	// read size

	struct
	{
		int			aligned;
		uint8_t*	buf;
		int			bytes;
		u32 		column;
	} last;

	emmc_callback_t*	user_callback;		// called after one block reading
} emmc_read_cmd_t;


static emmc_irq_callback_t irq_callback;

void emmc_dcache_ops_range(unsigned int bool)
{
	if (bool == DCACHE_RANGE)
		dcache_range_ops = DCACHE_RANGE;
	else
		dcache_range_ops = DCACHE_ALL;
}

static void emmc_request_read(emmc_read_cmd_t* cmd);

/* This function is called in interrupt mode. So keep in mind that ! */
static int emmc_dma_read_end(emmc_read_cmd_t* cmd, int result)
{
	if(cmd->user_callback)
	{
		cmd->user_callback(cmd->current, result);
	}

	if(driver->dma_read_stop) driver->dma_read_stop();
	free(cmd);

	return 0;
}

static void emmc_dma_read_next(void* data, int result)
{
	emmc_read_cmd_t* cmd = (emmc_read_cmd_t*)data;

	if(result)
	{
		EMMC_ERROR("read fail !\n");
		emmc_dma_read_end(cmd, EMMC_DMA_READ_STATUS_ERROR);
		return;
	}

	if(cmd->last.bytes)
	{
		if(cmd->last.aligned)
		{
	#if USE_DATA_CACHE
		if (dcache_range_ops == DCACHE_RANGE)
			dcache_inv_range((unsigned long)cmd->last.buf, cmd->last.bytes);
	#endif
		}
		else
		{
			memcpy(cmd->last.buf, emmc->data_buf + cmd->last.column, cmd->last.bytes);
		}
	}

	/* Call user function when one page reading is done ! */
	if(cmd->user_callback)
	{
		cmd->user_callback(cmd->current, 0);
	}

	if(cmd->current >= cmd->len)
	{
		if(cmd->current > cmd->len) printf("Check code !\n");

		emmc_dma_read_end(cmd, EMMC_DMA_READ_STATUS_COMPLETED);
		// Success! the end of operation.
	}
	else
	{
		/* Read next page */
		emmc_request_read(cmd);
	}

}

static void emmc_request_read(emmc_read_cmd_t* cmd)
{
	uint32_t column;
	int aligned;
	int rsize, size;
	void* rbuf;


	loff_t offset;
	uint8_t *buf;
	size_t len;

	offset = cmd->from + cmd->current;
	buf = cmd->buf + cmd->current;
	len = cmd->len - cmd->current;

	column = offset & (emmc->sector_size - 1);

	if(column)
	{
		rsize = min(emmc->sector_size - column, len);
		aligned = 0;
	}
	else
	{
		rsize = min(emmc->max_block_size, len);
		aligned = (rsize & (emmc->sector_size-1)) ? 0 : 1;
#if USE_DATA_CACHE
		if(aligned && ((unsigned long)buf&(D_CACHE_LINE_SIZE-1))) aligned = 0;
#endif
	}

	if(aligned)
	{
		rbuf = buf;
		size = rsize;
	}
	else
	{
		rbuf = emmc->data_buf;
		size = (rsize + (emmc->sector_size-1)) & ~(emmc->sector_size-1);
	}

	if(driver->dma_read_start(offset, size, rbuf, &irq_callback) < 0)
	{
		emmc_dma_read_end(cmd, EMMC_DMA_READ_STATUS_ERROR);
		return;
	}

	cmd->last.aligned = aligned;
	cmd->last.buf = buf;
	cmd->last.bytes = rsize;
	cmd->last.column = column;

	cmd->current += rsize;

}

int emmc_dma_read_start(loff_t offset, size_t len, void* buf, emmc_callback_t *callback)
{
	emmc_read_cmd_t* cmd;

	if(emmc_check_param(offset, len) < 0)
		return -1;

	cmd = (emmc_read_cmd_t*)calloc(1, sizeof(emmc_read_cmd_t));

	cmd->from	= offset;
	cmd->len	= len;
	cmd->buf	= (uint8_t*)buf;

	cmd->user_callback = callback;

	irq_callback.handler = emmc_dma_read_next;
	irq_callback.arg = cmd;

#if USE_DATA_CACHE
	if (dcache_range_ops == DCACHE_RANGE)
		dcache_flush_range((unsigned long)buf, len);
#endif

	emmc_request_read(cmd);

	return 0;
}

int emmc_dma_read_status(void)
{

	return 0;
}

int emmc_dma_read_stop(void)
{

	return 0;
}
#endif


int emmc_read(loff_t offset, size_t len, void* buf)
{
	uint32_t column;
	int aligned;
	int rsize, remained, size;
	void* rbuf;

	if(emmc_check_param(offset, len) < 0)
		return -1;

	remained = len;
	column = offset & (emmc->sector_size - 1);

#if USE_DATA_CACHE
	if (dcache_range_ops == DCACHE_RANGE)
		dcache_flush_range((unsigned long)buf, len);
#endif

	if(column)
	{
		rsize = min(emmc->sector_size - column, remained);
		offset &= ~((loff_t)(emmc->sector_size - 1));

		if(driver->read(offset, emmc->sector_size, emmc->data_buf) < 0)
			return -1;
		memcpy(buf, emmc->data_buf + column, rsize);

		remained -= rsize;
		if(remained <= 0)
			return rsize;

		buf = (uint8_t*)buf + rsize;
		offset += emmc->sector_size;
	}

	while(1)
	{
		rsize = min(emmc->max_block_size, remained);
		aligned = (rsize & (emmc->sector_size-1)) ? 0 : 1;
#if USE_DATA_CACHE
		if(aligned && ((unsigned long)buf&(D_CACHE_LINE_SIZE-1))) aligned = 0;
#endif

		if(aligned)
		{
			rbuf = buf;
			size = rsize;
		}
		else
		{
			rbuf = emmc->data_buf;
			size = (rsize + (emmc->sector_size-1)) & ~(emmc->sector_size-1);
		}

		if(driver->read(offset, size, rbuf) < 0)
		{
			return -1;
		}

		if(!aligned)
		{
			memcpy(buf, emmc->data_buf, rsize);
		}
#if USE_DATA_CACHE
		else
		{
			if (dcache_range_ops == DCACHE_RANGE)
				dcache_inv_range((unsigned long)buf, rsize);
		}
#endif

		remained -= rsize;
		if(remained <= 0)
			break;

		buf = (uint8_t*)buf + rsize;
		offset += rsize;
	}

	return (len - remained);
}


#define EMMC_PRINT_MSG(flag, fmt, args...)	\
	do{										\
		if(flag&EMMC_FLAG_MSG)		\
		{									\
			printf(fmt, ##args);			\
		}									\
	}while(0)
#define EMMC_MSG_INTERVAL		200

int emmc_write_ext(loff_t offset, size_t len, const void* buf, uint32_t flag)
{
	uint32_t column;
	int aligned;
	int wsize, remained, size;
	void* wbuf;
	timeout_id_t tid;

	if(emmc_check_param(offset, len) < 0)
		return -1;

	remained = len;
	column = offset & (emmc->sector_size-1);

	if(flag&EMMC_FLAG_MSG)
	{
		set_timeout(&tid, 0);
	}

	if(column)
	{
		wsize = min(emmc->sector_size - column, remained);

		offset &= ~((loff_t)(emmc->sector_size-1));
		if(driver->read(offset, emmc->sector_size, emmc->data_buf) < 0)
			goto error;

		memcpy(emmc->data_buf + column, buf, wsize);
		if(driver->write(offset, emmc->sector_size, emmc->data_buf) < 0)
			goto error;

		remained -= wsize;
		if(remained <= 0)
		{
			EMMC_PRINT_MSG(flag, "\r\33[K100% Completed...\n");
			return wsize;
		}

		buf = (uint8_t*)buf + wsize;
		offset += emmc->sector_size;
	}

	while(1)
	{
		wsize = min(emmc->max_block_size, remained);
		aligned = (wsize & (emmc->sector_size-1)) ? 0 : 1;

		if(aligned)
		{
			wbuf = (void*)buf;
			size = wsize;
#if USE_DATA_CACHE
			if (dcache_range_ops == DCACHE_RANGE)
				dcache_clean_range((unsigned long)buf, wsize);
#endif
		}
		else
		{
			/* if the end of block data is not aligned, first read from emmc  */
			size = (wsize + (emmc->sector_size-1)) & ~(emmc->sector_size-1);

			wbuf = emmc->data_buf;
			if(driver->read(offset, size, wbuf) < 0)
				goto error;

			memcpy(wbuf, buf, wsize);
		}

		if(driver->write(offset, size, wbuf) < 0)
			goto error;

		remained -= wsize;

		if(flag&EMMC_FLAG_MSG)
		{
			// with 500ms interval.
			if(is_timeout(&tid))
			{
				printf("\r\33[K%3d%% Completed...", percentage(len-remained, len));
				set_timeout(&tid, EMMC_MSG_INTERVAL);
			}
		}

		if(remained <= 0)
			break;

		buf = (uint8_t*)buf + wsize;
		offset += wsize;
	}

	EMMC_PRINT_MSG(flag, "\r\33[K100% Completed...\n");
	return (len - remained);

error:
	EMMC_PRINT_MSG(flag, "\t Fail. Offs:%08x, Src:%08x Size:%05x\n", offset, buf, wsize);
	return -1;
}

int emmc_write(loff_t offset, size_t len, const void* buf)
{
	return emmc_write_ext(offset, len, buf, 0);
}

int emmc_write_image(loff_t offset, size_t len, const void* buf)
{
	return emmc_write_ext(offset, len, buf, EMMC_FLAG_MSG);
}

int emmc_erase_ext(loff_t offset, u64 len, uint32_t flag)
{
	int block_size;
	timeout_id_t tid;

	if(emmc_check_param(offset, len) < 0)
		return -1;

	if((offset & (emmc->sector_size-1)) ||
		(len & (emmc->sector_size-1)))
	{
		printf("Do not support the size not aligned to sector size !\n");
		return -1;
	}

	if(flag&EMMC_FLAG_MSG)
	{
		set_timeout(&tid, 0);
	}

	block_size = emmc->max_block_size;
	if(driver->erase)
	{
	#if 0
		int esize, remained;

		remained = len;
		while(remained > 0)
		{
			esize = min(block_size, len);
			if(driver->erase(offset, esize) < 0)
				goto error;

			remained -= esize;
			offset += esize;

			if(flag&EMMC_FLAG_MSG)
			{
				if(is_timeout(&tid))
				{
					printf("\r\33[K%3d%% Completed...", percentage(len-remained, len));
					set_timeout(&tid, EMMC_MSG_INTERVAL);
				}
			}
		}
	#else
		if(driver->erase(offset, len) < 0) goto error;
		return 0;
	#endif
	}
	else
	{
		uint8_t* buf;
		int wsize, remained;

		buf = (uint8_t*)malloc(block_size);
		memset(buf, 0xff, block_size);

		remained = len;
		while(remained > 0)
		{
			wsize = min(block_size, len);
			if(emmc_write(offset, wsize, buf) < 0)
			{
				free(buf);
				goto error;
			}

			offset += wsize;
			remained -= wsize;

			if(flag&EMMC_FLAG_MSG)
			{
				if(is_timeout(&tid))
				{
					printf("\r\33[K%3d%% Completed...", percentage(len-remained, len));
					set_timeout(&tid, EMMC_MSG_INTERVAL);
				}
			}
		}
		free(buf);
	}

	EMMC_PRINT_MSG(flag, "\r\33[K100% Completed...\n");
	return 0;

error:
	EMMC_PRINT_MSG(flag, "\t Fail. Offs:%08x\n", offset);
	return -1;
}

int emmc_erase(loff_t offset, u64 len)
{
	return emmc_erase_ext(offset, len, 0);
}

struct emmc_info* get_emmc_info(void)
{
	return emmc;
}

int emmc_init(void)
{
	uint32_t capacity;

	driver = get_emmc_driver();
	if(driver == NULL)
		return -1;

	if(driver->init(emmc) < 0)
		return -1;

	if(emmc_inited)
	{
		capacity = emmc->chip_size/1024/1024;	// MB
		return 0;
	}

	emmc->data_buf = (uint8_t*)dma_malloc(emmc->max_block_size);

	capacity = emmc->chip_size/1024/1024;	// MB
	EMMC_INFO("EMMC Device : %s emmc %d.%dGB(%dMB)\n", emmc->product_name, capacity/1024, (capacity%1024)/10, capacity);
	emmc_inited = 1;

	return 0;
}

int emmc_test_init(unsigned int mode, unsigned int clock, unsigned int bus)
{
	return driver->ioctl(EMMC_IOCTL_INIT, (bus << 24) + (clock << 8) + mode);
}

STORAGE_FUNC_T emmc_func_tbl =
{
	.info   = (void*)get_emmc_info,
	.init   = (void*)emmc_init,
	.read   = (void*)emmc_read,
	.write  = (void*)emmc_write,
	.wimage = (void*)emmc_write_image,
	.erase  = (void*)emmc_erase,
	#if USE_STORAGE_DMA_READ
	.dmard  = (void*)emmc_dma_read_start,
	.cacheops = (void*)emmc_dcache_ops_range
	#endif
};

int init_emmc_table(void)
{
	return register_storage(STORAGE_TYPE_EMMC, &emmc_func_tbl);
}

int emmc_info(void)
{
	driver->ioctl(EMMC_IOCTL_INFO, 0);

	return 0;
}

int emmc_info_mini(void)
{
	driver->ioctl(EMMC_IOCTL_INFO_MINI, 0);

	return 0;
}

int tune_emmc_strb(unsigned int value)
{
	driver->ioctl(EMMC_IOCTL_TAB_STRB, value);

	return 0;
}

int tune_emmc_tab(unsigned int value)
{
	driver->ioctl(EMMC_IOCTL_TAB_TUNE, value);

	return 0;
}

int disable_emmc_tab(void)
{
	driver->ioctl(EMMC_IOCTL_TAB_DISABLE, 0);

	return 0;
}

int set_emmc_pon(unsigned int value)
{
	if (value == 0)
		return -1;

	if (value > 3)
		return -1;

	if (driver->ioctl(EMMC_IOCTL_SET_PON, value))
		return -1;

	return 0;
}

int set_emmc_tab(unsigned int value)
{
	driver->ioctl(EMMC_IOCTL_SET_TAB, value);

	return 0;
}

int set_emmc_ds(unsigned int value)
{
	driver->ioctl(EMMC_IOCTL_SET_DS, value);

	return 0;
}

unsigned int get_emmc_max_clock(void)
{
	unsigned int value;

	driver->ioctl(EMMC_IOCTL_GET_MAXCLOCK, (unsigned int)((unsigned long)&value));

	return value;
}

unsigned int get_emmc_tab_to_kernel(void)
{
	unsigned int value;

	driver->ioctl(EMMC_IOCTL_GET_TAB_TO_KERNEL, (unsigned int)((unsigned long)&value));

	return value;
}

int get_emmc_smart_report(unsigned char *buffer)
{
	driver->ioctl(EMMC_IOCTL_GET_SMARTREPORT, (unsigned int)((unsigned long)buffer));

	return 0;
}

unsigned int set_emmc_dlliff(unsigned int value)
{
	return driver->ioctl(EMMC_IOCTL_SET_DLL, value);
}

unsigned int get_emmc_dlliff(void)
{
	return driver->ioctl(EMMC_IOCTL_GET_DLL, 0);
}

unsigned int set_emmc_trmicp(unsigned int value)
{
	return driver->ioctl(EMMC_IOCTL_SET_TRM, value);
}

unsigned int get_emmc_trmicp(void)
{
	return driver->ioctl(EMMC_IOCTL_GET_TRM, 0);
}

unsigned int change_emmc_partition(unsigned int mode)
{
	return driver->ioctl(EMMC_IOCTL_CHANGE_PART, mode);
}

#endif
