#ifndef __EMMC_HOST_H__
#define __EMMC_HOST_H__

#define EMMC_EXECUTE_TUNNING

#define EMMC_KHZ 			1000
#define EMMC_MHZ 			(1000*EMMC_KHZ)

#define EMMC_400KHZ			(400 * EMMC_KHZ)
#define EMMC_25MHZ			(25 * EMMC_MHZ)
#define EMMC_50MHZ			(50 * EMMC_MHZ)
#define EMMC_100MHZ			(100 * EMMC_MHZ)
#define EMMC_200MHZ			(200 * EMMC_MHZ)

#define EMMC_HOST_MAX		(198 * EMMC_MHZ)

#define EMMC_SUPPORT_HS400	0x40
#define EMMC_SUPPORT_HS200	0x10
#define EMMC_SUPPORT_DDR50	0x04
#define EMMC_SUPPORT_HS		0x02
#define EMMC_SUPPORT_LEGACY	0x01

#define EMMC_HOST_DS_50ohm		0
#define EMMC_HOST_DS_33ohm		1
#define EMMC_HOST_DS_66ohm		2
#define EMMC_HOST_DS_100ohm		3
#define EMMC_HOST_DS_40ohm		4

#define STRB90_DEFAULT			0
#define STRB180_DEFAULT			0

#define STRB90_DONT_SET			255
#define STRB180_DONT_SET		255

#define EMMC_SECTOR_MODE		0
#define EMMC_BYTE_MODE			1

#define EMMC_ON					0
#define EMMC_OFF				1

#define EMMC_CHECK_BUSY			0
#define EMMC_IGNORE_BUSY		1

// IOS Defines
#define VDD_180                    0x04000000
#define VDD_300                    0x02000000
#define VDD_330                    0x01000000

#define SD_POWER_OFF    0
#define SD_POWER_UP     1
#define SD_POWER_ON     2

#define MMC_TIMEOUT_MAX 30000


/*************************************************/
/* Init Error Value										    */
/*************************************************/
#define EMMC_SUCCESS					0
#define EMMC_FAIL						1

#define EMMC_CLOCK_ERROR				0x100
#define EMMC_BUSWIDTH_ERROR				0x200

//-----------+
// Check Flags |
//-----------+
#define MMC_FLAG_COMMAND_ONLY   1
#define MMC_FLAG_DATA			2

typedef struct adma_list
{
    unsigned short	flag;
    unsigned short	size;
	unsigned int 	address;
}__attribute__((packed)) adma_list_t;

#define MMC_SECTOR_SIZE			512
#define MMC_ADMA_BLOCK_MAX		65536
#define MMC_ADMA_LIST_MAX		16
#define MMC_CHUNKSIZE_MAX		(MMC_ADMA_BLOCK_MAX * MMC_ADMA_LIST_MAX)	// 1MByte

#define EMMC_ERROR_NONE				0
#define EMMC_ERROR_SIZE_OVER		1
#define EMMC_ERROR_UNITSIZE_FALSE	2
#define EMMC_ERROR_BLOCKCOUNT_ZEEO	3
#define EMMC_ERROR_READY_TIMEOUT 	4

#define MMC_RCA_SHIFT				16

#define MMC_CMD_NONE				0
#define MMC_CMD_ONLY				1
#define MMC_CMD_DATA				2

#define MMC_CMD_NOT_FINISH			0
#define MMC_CMD_COMPLETE			1
#define MMC_DATA_COMPLETE			2

#define MMC_CMD_ERROR				0x10000
#define MMC_CMD_TIMEOUT				0x20000
#define MMC_DATA_ERROR				0x40000
#define MMC_DATA_TIMEOUT			0x80000
#define MMC_ETC_ERROR				0x100000


#define EMMC_SET_BLOCKSIZE			0
#define EMMC_SET_BLOCKCOUNT			1
#define EMMC_DATA_TRANSFER			2
#define EMMC_OPR_END				3

#define EMMC_DUMP_DISABLE			0
#define EMMC_DUMP_EN				1

#define MMC_READ					0
#define MMC_WRITE					1

#define EMMC_TIMEOUT_DISABLE		0
#define EMMC_TIMEOUT_ENABLE			1

//#define EMMC_FAST_INIT

#define EMMC_HOST_CONTROLLER_VER3 3
#define EMMC_HOST_CONTROLLER_VER2 2
#define EMMC_HOST_CONTROLLER_VER1 1

#define EMMC_DEFAULT		0
#define EMMC_BLOCK_TRANSFER	1
#define EMMC_READ_IRQ	0
#define EMMC_WRITE_IRQ	1

#define EMMC_IRQ_ERROR_RETRY	1
#define EMMC_MAX_RETRY			10

#define EMMC_MAXSPEED_INIT		0
#define EMMC_BASICSPEED_INIT	2

#define READY_FOR_DATA		0x100
#define DATA_READY 			0x100
#define DATA_NOT_READY		0x000

#define STATE_SHIFT_OFFSET	9
#define STATE_PRG 			7

struct mmc_timing_set
{
	unsigned int	step;
	unsigned int	in;
	unsigned int	out;
};

struct mmc_cmd
{
	unsigned char	cmd;
	unsigned char	flag;
	unsigned char	opr;
	unsigned int 	arg;
	unsigned int	done_check;
	unsigned int	ack;
	unsigned int	err;
	unsigned int 	timeout_ms;
};

struct sd_mmc_csd
{
	unsigned int		buffer[4];						// raw csd data
    unsigned char       csd_struct         :2;         //127-126 bits=4
    unsigned int        specs_ver          :4;         //125-122 bits=4
    unsigned int        reserve3           :2;         //121-120 bits=2
    //121-120 reserved
    unsigned char       taac;                          //119-112 bits=8
    unsigned char       nsac;                          //111-104 bits=8
    unsigned char       tran_speed;                    //103-96  bits-8
    unsigned short      ccc;                           //95-84 bits=12
    unsigned char       read_bl_len;                   //83-80 bits=4
    unsigned int        read_partial       :1,         //79-79 bits=1
                        write_misalign     :1,         //78-78 bits=1
                        read_misalign      :1;         //77-77 bits=1
    unsigned int        dsr_imp            :1;         //75-75 bits=1
    unsigned int        reserve2           :2;         //75-74 bits=2
    //75-74 bits=3  reserved
    unsigned int        c_size             :12;         //73-62 bits=12

    unsigned int        vdd_r_curr_min     :3;         //61-59 bits=3
    unsigned int        vdd_r_curr_max     :3;         //58-56 bits=3
    unsigned int        vdd_w_curr_min     :3;         //55-53 bits=3
    unsigned int        vdd_w_curr_max     :3;         //52-50 bits=3
    //50-61 bits=12 reserved previously
    unsigned            c_size_mult        :3;         //49-47 bits=3

    unsigned int        erase_grp_size     :5;         //46-42 bits=5
    unsigned int        erase_grp_mult     :5;         //41-32 bits=5
    unsigned int        wp_grp_size        :5;         //36-32 bits=5
    unsigned int        wp_grp_enable      :1;         //31-31 bits=2
    unsigned int        default_ecc        :2;         //30-29 bits=2
    //29-46 bits=18 reserved prevoiously
    unsigned int        r2w_factor         :3;         //28-26 bits=3
    unsigned int        write_bl_len       :4;         //25-22 bits=4
    unsigned            write_partial      :1;         //21-21 bits=1

    unsigned int        reserve1           :4;         //20-17 reserved
    unsigned int        content_prot_app   :1,         //16-16 bits=1
                        file_format_grp    :1,         //15-15 bits=1
                        copy               :1,         //14-14 bits=1
                        perm_write_protect :1,         //13-13 bits=1
                        tmp_write_prot     :1;         //12-12 bits=1
    unsigned int        file_format        :2;         //11-10 bits=2
    unsigned int        ecc                :2;         //09-08 bits=2
};

struct sd_mmc_ext_csd
{
	unsigned char       buffer[512];
	unsigned char       s_cmd_set;             // 1bit 504
	unsigned char		hpi_feature;			// 1byte 503
	unsigned int        cache_size;        		// 4byte
	unsigned char       power_off_long_time;        // 1byte 252~249
	unsigned char       ini_timeout_ap;        // 1byte 241
	unsigned char       pwr_cl_ddr_52_360;     // 1byte 239
	unsigned char       pwr_cl_ddr_52_195;     // 1byte 238
	unsigned char       min_perf_ddr_w8_52;    // 1byte 235
	unsigned char       min_perf_ddr_r8_52;    // 1byte 234
	unsigned char       trim_mult;    		   // 1byte 232
	unsigned char       sec_support;   		   // 1byte 231
	unsigned char       sec_erase_mult;    	   // 1byte 230
	unsigned char       sec_trim_mult;    	   // 1byte 229
	unsigned char       boot_info;    		   // 1byte 228
	unsigned char 		boot_size_mult;		   //1byte 226
	unsigned char 		access_size;		   //1byte 225
	unsigned char 		hc_erase_grp_size;	   //1byte 224
	unsigned char 		erase_timeout_multi;   //1byte 223
	unsigned char 		rel_wr_sec_cnt;   	   //1byte 222
	unsigned char 		hc_wp_grp_size;        //1byte 221
	unsigned char 		sleep_cur_vcc;   	   //1byte 220
	unsigned char 		sleep_cur_vccq;   	   //1byte 219
	unsigned char 		slp_awk_timeout;   	   //1byte 217
    unsigned int		sec_count;             // 4bit 215-212
	unsigned char       min_pref_w_8_52;       // 1bit 210
	unsigned char       min_pref_r_8_52;       // 1bit 209
	unsigned char       min_pref_w_8_26_4_52;  // 1bit 208
	unsigned char       min_pref_r_8_26_4_52;  // 1bit 207
	unsigned char       min_pref_w_4_26;       // 1bit 206
	unsigned char       min_pref_r_4_26;       // 1bit 205
	unsigned char       pwr_cl_26_360;         // 1bit 203
	unsigned char       pwr_cl_52_360;         // 1bit 202
	unsigned char       pwr_cl_26_195;         // 1bit 201
	unsigned char       pwr_cl_52_195;         // 1bit 200
	unsigned char       driver_strength;       // 1bit 197
	unsigned char       card_type;             // 1bit 196
	unsigned char       csd_structure;         // 1bit 194
	unsigned char       ext_csd_rev;           // 1bit 192

	//Modes segment

	unsigned char       cmd_Set;               //1bit 191  R/W
	unsigned char       cmd_set_rev;           //bit1 189
	unsigned char       power_class;           //bit1 187
	unsigned char       hs_timing;             //bit1 185
	unsigned char       bus_width;             //bit1 183
	unsigned char       erased_mem_cont;       //bit1 181
	unsigned char       boot_config;       	   //bit1 179
	unsigned char       boot_config_prot;  	   //1byte 178
	unsigned char       boot_bus_width;        //bit1 177
	unsigned char       erase_grp_defn;        //bit1 175
	unsigned char       boot_wp;        //1byte 173
	unsigned char       user_wp;        //1byte 171
	unsigned char       fw_config;      //1byte 169
	unsigned char       rpmb_size_mult; //1byte 168
	unsigned char       rst_n_func;     //1byte 162
	unsigned char       hpi;            //1byte 161
	unsigned char       part_support;   //1byte 160
	unsigned int        max_enh_size_mult;  //3bytes 157
	unsigned char       part_attrb;  //1byte 156
	unsigned char       part_set_complete;  //1byte 155
	unsigned int       GP_size_mult0;  //3byte 143
	unsigned int       GP_size_mult1;  //3byte 146
	unsigned int       GP_size_mult2;  //3byte 149
	unsigned int       GP_size_mult3;  //3byte 152
	unsigned int       enh_size_mult;  //3byte 140
	unsigned int       enh_start_addr;  //4byte 136
	unsigned char      sec_bad_blk_mngt;  //1byte 134
	unsigned char       power_off_noti;        // 1byte 34
	unsigned char       cache_enable;        // 1byte 33
};

struct sd_mmc_cid
{
	unsigned int	buffer[4];						// raw cid data

    unsigned int   manfid;           // 120-127 bits=8
    unsigned short card_bga;         // 113-112  =16 bits
    unsigned short oemid;            // 104-119 bits=16
    char           prod_name[5];     // 64-103 bits=40  5-character ASCII string
                                     // 56-63 bits=8   product revision(n.m)
    char           prod_name6;
    unsigned char  hwrev    :4;      // 60-63 bits=4     n-most significant
    unsigned char  fwrev    :4;      // 56-59 bits=4     m-least significant
    unsigned int   serial;           // 24-55 bits=32
                                     // 20-23             reserved
                                     // 8-19              manufacture date
    unsigned int   year;             // 12-19 bits=8-    mfg.year
    unsigned       month    :4;      // 8-11 bits=4-     mfg.month
                                     // 1-7 bits=7      crc
                                     // 0-0 bits=1      not used always 1
};

struct mmc_card
{
	unsigned int 			address_mode;
	unsigned int			rca;
	struct sd_mmc_csd		csd;
	struct sd_mmc_cid		cid;
	struct sd_mmc_ext_csd 	ext_csd;
};

#define EMMC_MODE_SDR25		1
#define EMMC_MODE_HS50		2
#define EMMC_MODE_DDR50		3
#define EMMC_MODE_HS200		4
#define EMMC_MODE_HS400		5

#define EMMC_TESTMODE_NONE		0
#define EMMC_TESTMODE_SDR25		EMMC_MODE_SDR25
#define EMMC_TESTMODE_HS50		EMMC_MODE_HS50
#define EMMC_TESTMODE_DDR50		EMMC_MODE_DDR50
#define EMMC_TESTMODE_HS200		EMMC_MODE_HS200
#define EMMC_TESTMODE_HS400		EMMC_MODE_HS400

struct mmc_host
{
	unsigned int 			ver;
	unsigned int 			inited;
	unsigned int 			initing;
	unsigned int 			irq_enable;
	unsigned int 			base;
	unsigned int 			bus_width;
	unsigned int 			ddr_mode;
	unsigned int 			clock;
	unsigned int 			base_clock;
	unsigned int 			max_clock;
	unsigned int 			tunned;
	unsigned int			driver_strength;	// 50ohm, 33ohm, 66ohm, 100ohm, 40ohm

	adma_list_t 			*mmc_adma_list;
	unsigned int			top_reg_address;
	struct mmc_timing_set 	tab_50;
	struct mmc_timing_set 	tab_200;
	struct mmc_timing_set 	tab_400;
	unsigned int 			strb90;
	unsigned int 			strb180;
	struct mmc_card 		card;
	struct mmc_cmd			cmd;

	// test & debug
	unsigned int 			noprint;
	unsigned int			usermode;		// 0 : SDR25
											// 1 : HishSpeed
											// 2 : DDR50
											// 3 : HS200
											// 4 : HS400

	unsigned int			userclock;		// hz
	unsigned int			userbus;		// 1,4,8
	unsigned int			usertab;		// 0: System Default, 1: User Tab Search
	unsigned int			max_retry;
};

#define READ_BITS(value,mask,shift,out)     \
{           \
	unsigned temp;          \
	temp = (value & mask);      \
	temp >>= shift;       \
	out = temp;     \
}

#endif	// __ARASAN_EMMC_H__
