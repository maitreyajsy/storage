#if (USE_EMMC == 1)
#include <types.h>
#include <debug.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <command.h>
#include <util.h>
#include <partinfo.h>
#include <emmc.h>

static int subcmd_emmc_init(int argc, char *argv[])
{
	char			*endptr;
	unsigned int	clock = 0;
	unsigned int	bus = 0;
	unsigned int	mode = 0;

	if (argc == 2)
	{
		if (emmc_init()  == 0)
			emmc_info_mini();
		return 0;
	}

	if (argc >= 3)
	{
		if (!strcmp(argv[2], "basic"))
		{
			mode = 1;
		}
		else if (!strcmp(argv[2], "hs50"))
		{
			mode = 2;
		}
		else if (!strcmp(argv[2], "ddr50"))
		{
			mode = 3;
		}
		else if (!strcmp(argv[2], "hs200"))
		{
			mode = 4;
		}
		else if (!strcmp(argv[2], "hs400"))
		{
			mode = 5;
		}
	}

	if (argc >= 4)
	{
		clock = strtoul(argv[3], &endptr, 0);
		if (clock > 200)
			clock = 200;

		if (clock < 1)
			clock = 1;
	}

	if (argc >= 5)
	{
		bus = strtoul(argv[4], &endptr, 0);
		if ((bus != 1) && (bus != 4) && (bus != 8))
			bus = 8;

		printf("EMMC BUS %ubit\n", bus);
	}

	if (emmc_test_init(mode,clock,bus) == 0)
		emmc_info_mini();

	return 0;
}



static int subcmd_emmc_info(int argc, char *argv[])
{
	emmc_info();
	return 0;
}

static int subcmd_emmc_smartreport(int argc, char *argv[])
{
	unsigned char *buff;

	buff = dma_malloc(512);

	memset(buff,0x0,512);
	get_emmc_smart_report(buff);
	hex_dump(0,buff,512,1);

	dma_free(buff);
	return 0;
}

static int subcmd_emmc_dump(int argc, char *argv[])
{
	uint8_t *pBuf = (uint8_t*)DATA_BUF_BASE;
	u64		size  = 0;
	u64		offset;

	if (argc != 3 && argc != 4)
		return -1;

	if(get_offset_size(argc - 2, argv + 2, &offset, &size) < 0)
		return -2;

	if (size == 0)
		size = 512;
	emmc_read(offset, size, pBuf);

	printf("^y^Offset %llu(0x%012llx) dump:\n", offset, offset);
	hex_dump(offset, pBuf, size, 1);

	return 0;
}

static int subcmd_emmc_erase(int argc, char *argv[])
{
	struct emmc_info	*emmc = get_emmc_info();
	u64					size, offset;
	int					rc;
	if(argc == 2)
	{
		int in_char;
		printf("Really erase all the data in emmc ? <y/N> ");
		in_char = getchar();
		printf("%c\n\n", isprint(in_char) ? in_char : ' ');

		if(in_char != 'y')
			return 0;

		offset = 0;
		size = emmc->chip_size;
	}
	else
	{
		if(get_offset_size2(argc - 2, argv + 2, &offset, &size) < 0)
			return -1;

		if(size == 0)
		{
			printf("invalid size\n");
			return -1;
		}
	}

	printf("emmc erase (0x%012llx ~ 0x%012llx) : ", offset, offset + size);
	rc = emmc_erase_ext(offset, size, EMMC_FLAG_MSG);

	printf("%s\n", rc == 0 ? "OK" : "Fail");

	return 0;
}

static int subcmd_emmc_rw(int argc, char *argv[])
{
	int		write = (strcmp(argv[1], "write") == 0) ? 1 : 0;
	unsigned long	addr;
	char	*endptr;
	u64		offset, size;
	u32		tick, elapsed, speed;
	int		rc;
	u32		no_cache_opr = 0;
	u32 	i;

 	for (i=2; i<argc; i++)
	{
		if (!strcmp(argv[i], "nc"))
		{
			no_cache_opr = 1;
			argc--;
#if !defined(FIRST_BOOT)
			printf("EMMC DCache control disable\n");
#else
			printf("'nc' option not supprot 1st boot\n");
#endif
			break;
		}
	}

	if (argc < 4)
		return -1;

	addr = strtoul(argv[2], &endptr, 0);
	if (*endptr != '\0')
		return -1;

	if(get_offset_size(argc - 3, argv + 3, &offset, &size) < 0)
		return -1;

	if(size == 0)
	{
		printf("invalid size\n");
		return -1;
	}

	printf("emmc %s: ", write ? "write" : "read");

	tick = timer_tick();
#if USE_STORAGE_DMA_READ
	if (no_cache_opr)
		emmc_dcache_ops_range(DCACHE_ALL);
#endif
	if(write) rc = emmc_write (offset, size, (void*)addr);
	else      rc = emmc_read  (offset, size, (void*)addr);
#if USE_STORAGE_DMA_READ
	if (no_cache_opr)
		emmc_dcache_ops_range(DCACHE_RANGE);
#endif

	elapsed = timer_elapsed(tick);

	if(elapsed < 1000) speed = (size/1024)*1000*1000 / elapsed;
	else               speed = (size/1024)*1000 / (elapsed/1000);

	printf(" %lld bytes %s: %s. %ldms elapsed, %ldKbps/sec\n",
			size,  write ? "written" : "read", rc < 0 ? "ERROR" : "OK", elapsed/1000, speed);

	return 0;
}

static int subcmd_emmc_test(int argc, char *argv[])
{
	int ret;

#if !defined(FIRST_BOOT)
	extern int test_emmc_speed(int argc, char *argv[]);

	ret = test_emmc_speed(argc, argv);
#else
	printf("This command not support 1st boot\n");
	ret = 0;
	#endif
	return ret;
	}

static int subcmd_emmc_reliability(int argc, char *argv[])
{
	int ret;

#if !defined(FIRST_BOOT)
	extern int test_emmc_reliability(int argc, char *argv[]);

	ret = test_emmc_reliability(argc, argv);
#else
	printf("This command not support 1st boot\n");
	ret = 0;
#endif
	return ret;
}

static int subcmd_emmc_part(int argc, char *argv[])
{
	volatile unsigned int 	arg = 0;

	if(strcmp(argv[2], "user") == 0)
	{
		arg = 0;
		printf("EMMC PARTITION CHANGE TO USER\n");
	}
	else if(strcmp(argv[2], "boot") == 0)
	{
		arg = 1;
		printf("EMMC PARTITION CHANGE TO BOOT 1\n");
	}
	else if(strcmp(argv[2], "boot1") == 0)
	{
		arg = 1;
		printf("EMMC PARTITION CHANGE TO BOOT 1\n");
	}
	else if(strcmp(argv[2], "boot2") == 0)
	{
		arg = 2;
		printf("EMMC PARTITION CHANGE TO BOOT 2\n");
	}
	else
	{
		printf("UNKNOWN ARG\n");
		return 0;
	}

	return change_emmc_partition(arg);
}

static int subcmd_emmc_ds(int argc, char *argv[])
{
	volatile unsigned int 	arg = 0;

//	printf("argc = %u\n",argc);
//	for (i=0; i<argc; i++)
//		printf("argv[%u] = %s\n",i, argv[i]);

	if(strcmp(argv[2], "auto") == 0)
	{
		arg = 255;
	}
	else if(strcmp(argv[2], "33") == 0)
	{
		arg = 1;
	}
	else if(strcmp(argv[2], "50") == 0)
	{
		arg = 0;
	}
	else if(strcmp(argv[2], "66") == 0)
	{
		arg = 2;
	}
	else if(strcmp(argv[2], "100") == 0)
	{
		arg = 3;
	}
	else if(strcmp(argv[2], "40") == 0)
	{
		arg = 4;
	}
	else
	{
		printf("Don't support value %sohm\n",argv[2]);
		return 0;
	}

	printf("EMMC Host Driver Strength Set to %sohm\n",argv[2]);

	return set_emmc_ds(arg);
}

static int subcmd_emmc_pon(int argc, char *argv[])
{
	volatile unsigned int	arg = 0;
	int result;

//	printf("argc = %u\n",argc);
//	for (i=0; i<argc; i++)
//		printf("argv[%u] = %s\n",i, argv[i]);

	if(strcmp(argv[2], "short") == 0)
	{
		arg = 2;
	}
	else if(strcmp(argv[2], "long") == 0)
	{
		arg = 3;
	}
	else
	{
		printf("Don't support optino %s\n",argv[2]);
		return 0;
	}

	printf("EMMC PON Set to %s\n",argv[2]);

	result = set_emmc_pon(arg);
	if (result < 0)
		printf("PON SET ERROR\n");

	return result;
}

static int subcmd_emmc_tab(int argc, char *argv[])
	{
	volatile unsigned int 	arg = 0;
	unsigned int 			temp;
	char					*endptr;
	unsigned int			i;

//	printf("argc = %u\n",argc);
//	for (i=0; i<argc; i++)
//		printf("argv[%u] = %s\n",i, argv[i]);

	for (i=2; i<argc; i++)
	{
		if ((strcmp(argv[i], "default") == 0) || (strcmp(argv[i], "d") == 0))
		{
			arg = 0x80;
			return set_emmc_tab(arg);;
		}
	}

	for (i=2; i<argc; i++)
	{
		if(strcmp(argv[i], "in") == 0)
		{
			temp = strtoul(argv[i+1], &endptr, 0);
			if (temp > 255)
				temp = 255;
			arg |= (0x1 + (temp << 8));
		}

		if(strcmp(argv[i], "out") == 0)
		{
			temp = strtoul(argv[i+1], &endptr, 0);
			if (temp > 15)
				temp = 15;
			arg |= (0x2 + (temp << 16));
		}

		if(strcmp(argv[i], "instep") == 0)
		{
			temp = strtoul(argv[i+1], &endptr, 0);
			if (temp > 3)
				temp = 3;
			arg |= (0x4 + (temp << 24));
		}

		if(strcmp(argv[i], "outstep") == 0)
		{
			temp = strtoul(argv[i+1], &endptr, 0);
			if (temp > 3)
				temp = 3;
			arg |= (0x8 + (temp << 28));
		}
	}

//	printf("arg 0x%X\n",arg);

	return set_emmc_tab(arg);;
}

static int subcmd_emmc_tune(int argc, char *argv[])
{
	volatile unsigned int 	arg = 0x3;
	unsigned int 			temp;
	char					*endptr;
	unsigned int		i;

//	printf("argc = %u\n",argc);
//	for (i=0; i<argc; i++)
//		printf("argv[%u] = %s\n",i, argv[i]);

	for (i=2; i<argc; i++)
	{
		if(strcmp(argv[i], "strball") == 0)
		{
			arg |= 0x10;
		}

		if(strcmp(argv[i], "trm") == 0)
		{
			arg |= 0x200;
		}

		if(strcmp(argv[i], "dll") == 0)
		{
			arg |= 0x100;
		}

		if(strcmp(argv[i], "v") == 0)
		{
			arg = 0x40;
			break;
		}

		if(strcmp(argv[i], "print") == 0)
		{
			arg |= 0x80;
		}

		if(strcmp(argv[i], "r") == 0)
		{
			arg &= 0xFFFFFFFC;
			arg |= 0x01;
		}

		if(strcmp(argv[i], "w") == 0)
		{
			arg &= 0xFFFFFFFC;
			arg |= 0x02;
		}

		if(strcmp(argv[i], "infix") == 0)
		{
			temp = strtoul(argv[i+1], &endptr, 0);
			arg |= 0x04;
			arg |= ((temp) << 24);
		}

		if(strcmp(argv[i], "outfix") == 0)
		{
			temp = strtoul(argv[i+1], &endptr, 0);
			arg |= 0x08;
			arg |= ((temp) << 24);
		}

		if(strcmp(argv[i], "clk") == 0)
		{
			temp = strtoul(argv[i+1], &endptr, 0);
			arg |= 0x20;
			if (temp >= 200)
				temp = 200;

			arg |= ((temp) << 16);
		}

		if(strcmp(argv[i], "hs50") == 0)
		{
			arg &= 0xFFFF1FFF;
			arg |= (EMMC_SEARCH_MODE_HS50 << 13);
		}

		if(strcmp(argv[i], "ddr50") == 0)
		{
			arg &= 0xFFFF1FFF;
			arg |= (EMMC_SEARCH_MODE_DDR50 << 13);
		}

		if(strcmp(argv[i], "hs200") == 0)
		{
			arg &= 0xFFFF1FFF;
			arg |= (EMMC_SEARCH_MODE_HS200 << 13);
		}

		if(strcmp(argv[i], "hs400") == 0)
		{
			arg &= 0xFFFF1FFF;
			arg |= (EMMC_SEARCH_MODE_HS400 << 13);
		}

	}

//	printf("arg 0x%X\n",arg);

	return tune_emmc_tab(arg);;
}

static int subcmd_emmc_strb(int argc, char *argv[])
{
	return tune_emmc_strb(0);
}

static int subcmd_emmc_dlliff(int argc, char *argv[])
{
	unsigned int 			temp;
	char					*endptr;

	if (argc == 2)
	{
		printf("EMMC DLL IFF  %u\n", get_emmc_dlliff());
		return 0;
	}
	else if (argc == 3)
	{
		temp = strtoul(argv[2], &endptr, 0);
		printf("EMMC DLL IFF SET %u\n",temp);
		return set_emmc_dlliff(temp);
	}
	else
	{
		printf("Worng argument\n");
		return 0;
	}
}

static int subcmd_emmc_trmicp(int argc, char *argv[])
{
		unsigned int			temp;
		char					*endptr;

		if (argc == 2)
		{
			printf("EMMC TRM ICP  %u\n", get_emmc_trmicp());
			return 0;
		}
		else if (argc == 3)
		{
			temp = strtoul(argv[2], &endptr, 0);
			printf("EMMC TRM ICP SET %u\n",temp);
			return set_emmc_trmicp(temp);
		}
		else
		{
			printf("Worng argument\n");
			return 0;
		}
}

typedef int (*SUB_FUNC_T)(int argc, char *argv[]);
static SUB_FUNC_T cmp_subcmd(char *str)
{
	typedef struct
	{
		char		*cmd;
		SUB_FUNC_T	func;
	} SUBCMD_T;

	SUBCMD_T cmd_tbl[] =
		{{ "init", subcmd_emmc_init   },
		 { "info", subcmd_emmc_info   },
		 { "smartreport", subcmd_emmc_smartreport   },
		 { "dump", subcmd_emmc_dump   },
		 { "erase",subcmd_emmc_erase  },
		 { "read", subcmd_emmc_rw     },
		 { "write",subcmd_emmc_rw     },
		 { "test", subcmd_emmc_test   },
		 { "tune", subcmd_emmc_tune   },
 		 { "dll", subcmd_emmc_dlliff   },
 		 { "trm", subcmd_emmc_trmicp   },
		 { "strb", subcmd_emmc_strb },
		 { "tab", subcmd_emmc_tab   },
		 { "ds", subcmd_emmc_ds   },
		 { "pon", subcmd_emmc_pon   },
		 { "reltest", subcmd_emmc_reliability },
		 { "part", subcmd_emmc_part },
		 {  NULL }};

	int		index;

	if (str == NULL)
		return NULL;

	for (index = 0; ; index++)
	{
		if (cmd_tbl[index].cmd == NULL)
			return NULL;

		if (!strcmp(cmd_tbl[index].cmd, str))
			break;
	}

	return (SUB_FUNC_T)cmd_tbl[index].func;
}

static int cmd_emmc(int argc, char* argv[])
{
	SUB_FUNC_T	func;

	if (argc < 2)
		goto usage;

	func = cmp_subcmd(argv[1]);

	if (func == NULL)
		goto usage;

	if(func(argc, argv) == 0)
		return 0;

usage:
	command_error(argv[0]);
	return -1;
}

COMMAND(emmc, cmd_emmc, "emmc init,info,tune,tab,ds,pon,smartreport,erase,dump,read,write,reltest",
		"emmc init\n"
		"emmc info\n"
		"emmc tune\n"
		"emmc tab\n"
		"emmc pon\n"
		"emmc smartreport\n"
		"emmc dump offset|partition size\n"
		"emmc erase offset|partition size\n"
		"emmc read  addr offset|partition size\n"
		"emmc write addr offset|partition size\n"
		"emmc reltest\n");
#endif/*USE_EMMC == 1 or 0*/
