#ifndef __ARASAN_EMMC_H__
#define __ARASAN_EMMC_H__

#define EMMC_ERROR_PRINT(fmt, args...)		do {if (!host->noprint) \
												printf("^r^ERROR[%d] : "fmt, __LINE__, ##args);} while (0)
#define EMMC_INFO_PRINT(fmt, args...)		do {if (!host->noprint) \
													printf(fmt, ##args);} while (0)
#if 0
#define EMMC_DEBUG_PRINT(fmt, args...)		printf(fmt, ##args)
#define EMMC_CORE_PRINT(fmt, args...)		printf(fmt, ##args)
#else
#define EMMC_DEBUG_PRINT(fmt, args...)		do{}while(0)
#define EMMC_CORE_PRINT(fmt, args...)		do{}while(0)
#endif

#if USE_EMMC_IRQ
struct emmc_irq_struct
{
	volatile unsigned int rw;
	volatile unsigned int states;
	volatile unsigned int buffer;
	volatile unsigned int size;
	volatile unsigned int totalsize;
	volatile unsigned int currentsize;
	volatile unsigned long long address;
	volatile unsigned int complete;
	volatile unsigned int error;
};
static struct emmc_irq_struct emmc_irq;

static emmc_irq_callback_t irq_callback;
#endif

#endif	// __ARASAN_EMMC_H__
