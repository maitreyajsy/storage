#include <types.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <interrupt.h>
#include <util.h>
#include <emmc.h>
#include <malloc.h>
#include <storage.h>

#include "arasan_emmc.h"
#include "vendor_info.h"
#include "emmc_host.h"
#include "sdmmc.h"

static struct mmc_host emmc_host;
static unsigned int arasan_emmc_inited = 0;
#if USE_EMMC_IRQ
static unsigned int emmc_interrupt_inited = 0;
#endif
#if !defined(FIRST_BOOT)
static unsigned int searchtabviewmode  = 1 + 2;
#endif

#define _SDMMC_BIT_READ(addr, bit)			((*(volatile unsigned int*)((unsigned long)addr) >> bit) & 0x1)
#define _SDMMC_REG_READ(addr)				*(volatile unsigned int*)((unsigned long)addr)
#define _SDMMC_REG_WRITE(addr,value)		*(volatile unsigned int*)((unsigned long)addr) = (value)

static inline unsigned int SDMMC_BIT_READ(struct mmc_host *host, unsigned int offset, unsigned int bit)
{
	unsigned int ret;

	ret = _SDMMC_BIT_READ(host->base + offset, bit);
	dsb();
	return ret;
}

static inline void SDMMC_BIT_SET(struct mmc_host *host, unsigned int offset, unsigned int bit)
{
	unsigned int reg;

	reg = _SDMMC_REG_READ(host->base + offset);
	dsb();
	reg |= (1 << bit);
	_SDMMC_REG_WRITE(host->base + offset, reg);
}

static inline void SDMMC_BIT_CLEAR(struct mmc_host *host, unsigned int offset, unsigned int bit)
{
	unsigned int reg;

	reg = _SDMMC_REG_READ(host->base + offset);
	dsb();
	reg &= ~(1 << bit);
	_SDMMC_REG_WRITE(host->base + offset, reg);
}

static inline unsigned int SDMMC_REG_READ(struct mmc_host *host, unsigned int offset)
{
	unsigned int ret;

	ret = _SDMMC_REG_READ(host->base + offset);
	dsb();
	return ret;
}

static inline void SDMMC_REG_WRITE(struct mmc_host *host, unsigned int offset, unsigned int value)
{
	dsb();
	_SDMMC_REG_WRITE(host->base + offset, value);
}

static inline unsigned int SDMMC_TOP_BIT_READ(struct mmc_host *host, unsigned int offset, unsigned int bit)
{
	unsigned int ret;

	ret =  _SDMMC_BIT_READ(host->top_reg_address + offset, bit);
	dsb();
	return ret;
}

static inline void SDMMC_TOP_BIT_SET(struct mmc_host *host, unsigned int offset, unsigned int bit)
{
	unsigned int reg;

	reg = _SDMMC_REG_READ(host->top_reg_address + offset);
	dsb();
	reg |= (1 << bit);
	_SDMMC_REG_WRITE(host->top_reg_address + offset, reg);
}

static inline void SDMMC_TOP_BIT_CLEAR(struct mmc_host *host, unsigned int offset, unsigned int bit)
{
	unsigned int reg;

	reg = _SDMMC_REG_READ(host->top_reg_address + offset);
	dsb();
	reg &= ~(1 << bit);
	_SDMMC_REG_WRITE(host->top_reg_address + offset, reg);
}

static inline unsigned int SDMMC_TOP_REG_READ(struct mmc_host *host, unsigned int offset)
{
	unsigned int ret;

	ret = _SDMMC_REG_READ(host->top_reg_address + offset);
	dsb();
	return ret;
}

static inline void SDMMC_TOP_REG_WRITE(struct mmc_host *host, unsigned int offset, unsigned int value)
{
	dsb();
	_SDMMC_REG_WRITE(host->top_reg_address + offset, value);
}

// Name        : sd_dump_ext_csd
//
// Argument  : *host: pointer to host controller register
//
//Returns      :void; Status: void
//
//Description : this function will dump the ext csd register definitions
//
#if 0
static void emmc_hex_dump(unsigned char *buffer, unsigned int size)
{
	unsigned int i;

	for(i=0; i<size; i+=16)
	{
			printf("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %3d \n",
			buffer[i],   buffer[i+1],
			buffer[i+2],   buffer[i+3],
			buffer[i+4],   buffer[i+5],
			buffer[i+6],   buffer[i+7],
			buffer[i+8],   buffer[i+9],
			buffer[i+10],   buffer[i+11],
			buffer[i+12],   buffer[i+13],
			buffer[i+14],   buffer[i+15]);
	}
	printf("===================================================\n");
}
#endif

static void emmc_dump_ext_csd(struct sd_mmc_ext_csd *ext_csd)
{
#if 0
	int i=0;

	printf("\n============= DUMPING EXT_CSD REGISTER =============\n");
	for(i=0; i<512; i+=16)
	{
		printf("%3d : %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X\n",i,
		ext_csd->buffer[i],   ext_csd->buffer[i+1],
		ext_csd->buffer[i+2], ext_csd->buffer[i+3],
		ext_csd->buffer[i+4], ext_csd->buffer[i+5],
		ext_csd->buffer[i+6], ext_csd->buffer[i+7],
		ext_csd->buffer[i+8], ext_csd->buffer[i+9],
		ext_csd->buffer[i+10],ext_csd->buffer[i+11],
		ext_csd->buffer[i+12],ext_csd->buffer[i+13],
		ext_csd->buffer[i+14],ext_csd->buffer[i+15]);
	}
	printf("===================================================\n");
#endif
	printf("\n==========DUMPING EXT_CSD REGISTER==================\n");

	printf("byte [33] is cache_enable           : [0x%x]\n", ext_csd->cache_enable);
	printf("byte [34] is power_off_noti         : [0x%x]\n", ext_csd->power_off_noti);
	printf("byte [134] is sec_bad_blk_mngt      : [0x%x]\n", ext_csd->sec_bad_blk_mngt);
	printf("byte [136] is enh_start_addr        : [0x%x]\n", ext_csd->enh_start_addr);
	printf("byte [140] is enh_size_mult         : [0x%x]\n", ext_csd->enh_size_mult);
	printf("byte [152] is GP_size_mult3         : [0x%x]\n", ext_csd->GP_size_mult3);
	printf("byte [149] is GP_size_mult2         : [0x%x]\n", ext_csd->GP_size_mult2);
	printf("byte [146] is GP_size_mult1         : [0x%x]\n", ext_csd->GP_size_mult1);
	printf("byte [143] is GP_size_mult0         : [0x%x]\n", ext_csd->GP_size_mult0);
	printf("byte [155] is part_set_complete     : [0x%x]\n", ext_csd->part_set_complete);
	printf("byte [156] is part_attrb            : [0x%x]\n", ext_csd->part_attrb);
	printf("byte [157] is max_enh_size_mult     : [0x%x]\n", ext_csd->max_enh_size_mult);
	printf("byte [160] is part_support          : [0x%x]\n", ext_csd->part_support);
	printf("byte [161] is hpi                   : [0x%x]\n", ext_csd->hpi);
	printf("byte [162] is rst_n_func            : [0x%x]\n", ext_csd->rst_n_func);
	printf("byte [168] is rpmb_size_mult        : [0x%x]\n", ext_csd->rpmb_size_mult);
	printf("byte [169] is fw_config             : [0x%x]\n", ext_csd->fw_config);
	printf("byte [171] is user_wp               : [0x%x]\n", ext_csd->user_wp);
	printf("byte [173] is boot_wp               : [0x%x]\n", ext_csd->boot_wp);
	printf("byte [175] is erase grp defn        : [0x%x]\n", ext_csd->erase_grp_defn);
	printf("byte [177] is boot bus width        : [0x%x]\n", ext_csd->boot_bus_width);
	printf("byte [179] is boot config           : [0x%x]\n", ext_csd->boot_config);
	printf("byte [181] is erased mem count      : [0x%x]\n", ext_csd->erased_mem_cont);
	printf("byte [183] is bus width mode        : [0x%x]\n", ext_csd->bus_width);
	printf("byte [185] is High Speed            : [0x%x]\n", ext_csd->hs_timing);
	printf("byte [187] is power class           : [0x%x]\n", ext_csd->power_class);
	printf("byte [191] is Cmd Set               : [0x%x]\n", ext_csd->cmd_set_rev);
	printf("byte [192] is Ext CSD Rev           : [0x%x]\n", ext_csd->ext_csd_rev);
	printf("byte [194] is CSD Structure         : [0x%x]\n", ext_csd->csd_structure);
	printf("byte [196] is Card Type             : [0x%x]\n", ext_csd->card_type);
	printf("byte [197] is Driving Strength      : [0x%x]\n", ext_csd->driver_strength);
	printf("byte [200] is pwr class 52_195      : [0x%x]\n", ext_csd->pwr_cl_52_195);
	printf("byte [201] is pwr class 26_195      : [0x%x]\n", ext_csd->pwr_cl_26_195);
	printf("byte [202] is pwr class 52_360      : [0x%x]\n", ext_csd->pwr_cl_52_360);
	printf("byte [203] is pwr class 26_360      : [0x%x]\n", ext_csd->pwr_cl_26_360);
	printf("byte [205] is min pref r 4_26       : [0x%x]\n", ext_csd->min_pref_r_4_26);
	printf("byte [206] is min pref w 4_26       : [0x%x]\n", ext_csd->min_pref_w_4_26);
	printf("byte [207] is min pref r 8_26_4_52  : [0x%x]\n", ext_csd->min_pref_r_8_26_4_52);
	printf("byte [208] is min pref w 8_26_4_52  : [0x%x]\n", ext_csd->min_pref_w_8_26_4_52);
	printf("byte [209] is min pref r 8_52       : [0x%x]\n", ext_csd->min_pref_r_8_52);
	printf("byte [210] is min pref w 8_52       : [0x%x]\n", ext_csd->min_pref_w_8_52);
	printf("byte [226] is boot size mult        : [0x%x]\n", ext_csd->boot_size_mult);
	printf("byte [225] is access size           : [0x%x]\n", ext_csd->access_size);
	printf("byte [224] is hc erase group        : [0x%x]\n", ext_csd->hc_erase_grp_size);
	printf("byte [221] is hc wp group size      : [0x%x]\n", ext_csd->hc_wp_grp_size);
	printf("byte [223] is erase_timeout_multi   : [0x%x]\n", ext_csd->erase_timeout_multi);
	printf("byte [222] is rel_wr_sec_cnt        : [0x%x]\n", ext_csd->rel_wr_sec_cnt);
	printf("byte [220] is sleep_cur_vcc         : [0x%x]\n", ext_csd->sleep_cur_vcc);
	printf("byte [219] is sleep_cur_vccq        : [0x%x]\n", ext_csd->sleep_cur_vccq);
	printf("byte [217] is slp_awk_timeout       : [0x%x]\n", ext_csd->slp_awk_timeout);
	printf("byte [215-212] is sec count         : [0x%x]\n", ext_csd->sec_count);
	printf("byte [241] is ini_timeout_ap        : [0x%x]\n", ext_csd->ini_timeout_ap);
	printf("byte [239] is pwr_cl_ddr_52_360     : [0x%x]\n", ext_csd->pwr_cl_ddr_52_360);
	printf("byte [238] is pwr_cl_ddr_52_195     : [0x%x]\n", ext_csd->pwr_cl_ddr_52_195);
	printf("byte [235] is min_perf_ddr_w8_52    : [0x%x]\n", ext_csd->min_perf_ddr_w8_52 );
	printf("byte [234] is min_perf_ddr_r8_52    : [0x%x]\n", ext_csd->min_perf_ddr_r8_52 );
	printf("byte [232] is trim_mult             : [0x%x]\n", ext_csd->trim_mult);
	printf("byte [231] is sec_support           : [0x%x]\n", ext_csd->sec_support);
	printf("byte [230] is sec_erase_mult        : [0x%x]\n", ext_csd->sec_erase_mult);
	printf("byte [229] is sec_trim_mult         : [0x%x]\n", ext_csd->sec_trim_mult );
	printf("byte [228] is boot_info             : [0x%x]\n", ext_csd->boot_info );
	printf("byte [226] is boot_size_mult        : [0x%x]\n", ext_csd->boot_size_mult       );
	printf("byte [247] is power_off_noti        : [0x%x]\n", ext_csd->power_off_long_time);
	printf("byte [248] is generic CMD6 time     : [0x%x]\n", ext_csd->buffer[248]);
	printf("byte [252-249] is cache_size        : [0x%x]\n", ext_csd->cache_size);
	printf("byte [503] is hpi_feature           : [0x%x]\n", ext_csd->hpi_feature);
	printf("byte [504] is supported cmd set     : [0x%x]\n", ext_csd->s_cmd_set);
	printf("========================================================\n");
}

static void emmc_decode_ext_csd(struct sd_mmc_ext_csd *pextcsd)
{
	unsigned char buffer[512];
	memcpy(buffer, pextcsd->buffer, 512);

	pextcsd->s_cmd_set =  buffer[504]; //1bits 504
	pextcsd->hpi_feature = buffer[503]; //1byte 503
	pextcsd->cache_size = ((buffer[252] << 24) | (buffer[251] << 16) | ( buffer[250] << 8) | buffer[249]);//4bits 252-249
	pextcsd->power_off_long_time =  buffer[247];
	pextcsd->ini_timeout_ap =  buffer[241]; //1bits 241
	pextcsd->pwr_cl_ddr_52_360 =  buffer[239]; //1bits 239
	pextcsd->pwr_cl_ddr_52_195 =  buffer[238]; //1bits 238
	pextcsd->min_perf_ddr_w8_52 =  buffer[235]; //1bits 235
	pextcsd->min_perf_ddr_r8_52 =  buffer[234]; //1bits 234
	pextcsd->trim_mult =  buffer[232]; //1bits 232
	pextcsd->sec_support                 =  buffer[231]; //1bits 231
	pextcsd->sec_erase_mult              =  buffer[230]; //1bits 230
	pextcsd->sec_trim_mult               =  buffer[229]; //1bits 229
	pextcsd->boot_info                   =  buffer[228]; //1bits 228
	pextcsd->boot_size_mult              =  buffer[226]; //1bits 226
	pextcsd->access_size                 =  buffer[225]; //1bits 225
	pextcsd->hc_erase_grp_size   =  buffer[224]; //1bits 224
	pextcsd->erase_timeout_multi =  buffer[223]; //1bits 223
	pextcsd->rel_wr_sec_cnt              =  buffer[222]; //1bits 222
	pextcsd->hc_wp_grp_size              =  buffer[221]; //1bits 221
	pextcsd->sleep_cur_vcc               =  buffer[220]; //1bits 220
	pextcsd->sleep_cur_vccq              =  buffer[219]; //1bits 219
	pextcsd->slp_awk_timeout     =  buffer[217]; //1bits 217

	pextcsd->sec_count = ( (buffer[215] << 24) | (buffer[214] << 16) | ( buffer[213] << 8) | buffer[212]);//4bits 215-212
	pextcsd->min_pref_w_8_52      = buffer[210];    //1bit 210
	pextcsd->min_pref_r_8_52      = buffer[209];    //1bit 209
	pextcsd->min_pref_w_8_26_4_52 = buffer[208];    //1bit 208
	pextcsd->min_pref_r_8_26_4_52 = buffer[207];    //1bit 207
	pextcsd->min_pref_w_4_26      = buffer[206];    //1bit 206
	pextcsd->min_pref_r_4_26      = buffer[205];    //1bit 205
	pextcsd->pwr_cl_26_360        = buffer[203];    //1bit 203
	pextcsd->pwr_cl_52_360        = buffer[202];    //1bit 202
	pextcsd->pwr_cl_26_195        = buffer[201];    //1bit 201
	pextcsd->pwr_cl_52_195        = buffer[200];    //1bit 200
	pextcsd->driver_strength      = buffer[197];    //1bit 197
	pextcsd->card_type            = buffer[196];    //1bit 196
	pextcsd->csd_structure        = buffer[194];    //1bit 194
	pextcsd->ext_csd_rev          = buffer[192];    //1bit 192

	// Modes segment
	pextcsd->cmd_Set              = buffer[191];    //1bit 191 r/w
	pextcsd->cmd_set_rev          = buffer[189];    //bit1 189
	pextcsd->power_class          = buffer[187];    //bit1 187
	pextcsd->hs_timing            = buffer[185];    //bit1 185
	pextcsd->bus_width            = buffer[183];    //bit1 183
	pextcsd->erased_mem_cont      = buffer[181];    //bit1 181
	pextcsd->boot_config                  = buffer[179];
	pextcsd->boot_config_prot     = buffer[178];
	pextcsd->boot_bus_width               = buffer[177];
	pextcsd->erase_grp_defn               = buffer[175];
	pextcsd->boot_wp                              = buffer[173];
	pextcsd->user_wp                              = buffer[171];
	pextcsd->fw_config                    = buffer[169];
	pextcsd->rpmb_size_mult               = buffer[168];
	pextcsd->rst_n_func                   = buffer[162];
	pextcsd->hpi                         = buffer[161];
	pextcsd->part_support                 = buffer[160];
	pextcsd->max_enh_size_mult    = (buffer[159] << 16)| (buffer[158] << 8) | buffer[157];
	pextcsd->part_attrb                   = buffer[156];
	pextcsd->part_set_complete    = buffer[155];
	pextcsd->GP_size_mult0                = (buffer[145] << 16) | (buffer[144] << 8) | buffer[143];
	pextcsd->GP_size_mult1                = (buffer[148] << 16) | (buffer[147] << 8) | buffer[146];
	pextcsd->GP_size_mult2                = (buffer[151] << 16) | (buffer[150] << 8) | buffer[149];
	pextcsd->GP_size_mult3                = (buffer[154] << 16) | (buffer[153] << 8) | buffer[152];
	pextcsd->enh_size_mult                = (buffer[142] << 16) | (buffer[141] << 8) | buffer[140];
	pextcsd->enh_start_addr       = (buffer[139] << 24) | (buffer[138] << 16) | (buffer[137] << 8) | buffer[136];
	pextcsd->sec_bad_blk_mngt     =  buffer[134];
	pextcsd->power_off_noti =  buffer[34];
	pextcsd->cache_enable =  buffer[33];
}

static void reg_set_bits(unsigned int reg_addr, unsigned int mask, unsigned int offset)
{
	unsigned int emmc_reg;

	emmc_reg = SDMMC_TOP_REG_READ(&emmc_host, 0);
	emmc_reg = emmc_reg | (mask << offset);
	SDMMC_TOP_REG_WRITE(&emmc_host, 0, emmc_reg);
}

static void reg_clear_bits(unsigned int reg_addr, unsigned int mask, unsigned int offset)
{
	unsigned int emmc_reg;

	emmc_reg = SDMMC_TOP_REG_READ(&emmc_host, 0);
	emmc_reg = emmc_reg & (~(mask << offset));
	SDMMC_TOP_REG_WRITE(&emmc_host, 0, emmc_reg);
}

static unsigned int reg_read_bits(unsigned int reg_addr, unsigned int mask, unsigned int offset)
{
	volatile unsigned int emmc_reg;

	emmc_reg = SDMMC_TOP_REG_READ(&emmc_host, 0);
	emmc_reg = emmc_reg & mask;
	emmc_reg = emmc_reg >> offset;

	return emmc_reg;
}

#if EMMC_HOST_CONTROLLER_VER2
/* TAB EN/DISABLE */
static void op_tab_en_v2(struct mmc_host *host)
{
	reg_set_bits(host->top_reg_address, 1, 20);
}

static void op_tab_dis_v2(struct mmc_host *host)
{
	reg_clear_bits(host->top_reg_address, 1, 20);
}

static void ip_tab_en_v2(struct mmc_host *host)
{
	reg_set_bits(host->top_reg_address, 1, 8);
}

static void ip_tab_dis_v2(struct mmc_host *host)
{
	reg_clear_bits(host->top_reg_address, 1, 8);
}

/* SET TAB VALUE */
static void set_otab_value_v2(struct mmc_host *host, unsigned int out)
{
	reg_clear_bits(host->top_reg_address, 0xF, 16);
	reg_set_bits(host->top_reg_address, out, 16);
}

static void set_itab_value_v2(struct mmc_host *host, unsigned int in)
{
	reg_clear_bits(host->top_reg_address, 0x3F, 0);
	reg_set_bits(host->top_reg_address, in, 0);
}

/* GET TAB VALUE */
static unsigned int get_op_tab_value_v2(struct mmc_host *host)
{
	return reg_read_bits(host->top_reg_address, 0xF0000, 16);
}

static unsigned int get_ip_tab_value_v2(struct mmc_host *host)
{
	return reg_read_bits(host->top_reg_address, 0x3F, 0);
}

static unsigned int get_op_tab_enable_v2(struct mmc_host *host)
{
	return reg_read_bits(host->top_reg_address, 0x100000, 20);
}

static unsigned int get_ip_tab_enable_v2(struct mmc_host *host)
{
	return reg_read_bits(host->top_reg_address, 0x100, 8);
}

#endif

#if EMMC_HOST_CONTROLLER_VER1
/* TAB EN/DISABLE */
static void op_tab_en_v1(struct mmc_host *host)
{
	reg_set_bits(host->top_reg_address, 1, 24);
}

static void op_tab_dis_v1(struct mmc_host *host)
{
	reg_clear_bits(host->top_reg_address, 1 , 24);
}

static void ip_tab_en_v1(struct mmc_host *host)
{
	reg_set_bits(host->top_reg_address, 1, 15);
}

static void ip_tab_dis_v1(struct mmc_host *host)
{
	reg_clear_bits(host->top_reg_address, 1 , 15);
}

/* SET TAB VALUE */
static void op_tab_step_v1(struct mmc_host *host, unsigned int step)
{
	reg_clear_bits(host->top_reg_address, 3 , 16);
	reg_set_bits(host->top_reg_address, step, 16);
}

static void ip_tab_step_v1(struct mmc_host *host, unsigned int step)
{
	reg_clear_bits(host->top_reg_address, 3 , 4);
	reg_set_bits(host->top_reg_address, step, 4);
}

static void set_otab_value_v1(struct mmc_host *host, unsigned int value)
{
	reg_clear_bits(host->top_reg_address, 0x3 , 16);
	reg_set_bits(host->top_reg_address, 3, 16);

	reg_clear_bits(host->top_reg_address, 0xF , 20);
	reg_set_bits(host->top_reg_address, value, 20);
}

static void set_itab_value_v1(struct mmc_host *host, unsigned int in)
{
	reg_clear_bits(host->top_reg_address, 0x3 , 4);
	reg_set_bits(host->top_reg_address, 3, 4);

	reg_clear_bits(host->top_reg_address, 0x3F , 8);
	reg_set_bits(host->top_reg_address, in, 8);
}

static unsigned int get_ip_tab_value_v1(struct mmc_host *host)
{
	return reg_read_bits(host->top_reg_address, 0x3F00, 8);
}

static unsigned int get_op_tab_value_v1(struct mmc_host *host)
{
	return reg_read_bits(host->top_reg_address, 0xF00000, 20);
}
#endif

static void op_tab_step(struct mmc_host *host, unsigned int step)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		op_tab_step_v1(host, step);
	}
}

static void ip_tab_step(struct mmc_host *host, unsigned int step)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		ip_tab_step_v1(host, step);
	}
}

static void op_tab_en(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		op_tab_en_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		op_tab_en_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		op_tab_en_v1(host);
	}
}

static void op_tab_dis(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		op_tab_dis_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		op_tab_dis_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		op_tab_dis_v1(host);
	}
}

static void set_otab_value(struct mmc_host *host, unsigned int value)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		set_otab_value_v2(host, value);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		set_otab_value_v2(host, value);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		set_otab_value_v1(host, value);
	}
}

static void ip_tab_dis(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		ip_tab_dis_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		ip_tab_dis_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		ip_tab_dis_v1(host);
	}
}

static void ip_tab_en(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		ip_tab_en_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		ip_tab_en_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		ip_tab_en_v1(host);
	}
}

static void set_itab_value(struct mmc_host *host, unsigned int in)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		set_itab_value_v2(host, in);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		set_itab_value_v2(host, in);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		set_itab_value_v1(host, in);
	}
}

static unsigned int get_op_tab_value(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		return get_op_tab_value_v1(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		return get_op_tab_value_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		return get_op_tab_value_v2(host);
	}

	return -1;
}

static unsigned int get_ip_tab_value(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		return get_ip_tab_value_v1(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		return get_ip_tab_value_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		return get_ip_tab_value_v2(host);
	}

	return -1;
}

static unsigned int get_auto_ip_tab_value(struct mmc_host *host)
{
	unsigned ret = 0;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
		ret = (SDMMC_TOP_REG_READ(host, 0x3C) >> 8) & 0x1F;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
		ret = (SDMMC_TOP_REG_READ(host, 0x48) >> 12) & 0x1F;

	return ret;
}

static unsigned int get_ip_tab_enable(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		return get_ip_tab_enable_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		return get_ip_tab_enable_v2(host);
	}

	return -1;
}

static unsigned int get_op_tab_enable(struct mmc_host *host)
{
	if (host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		return get_op_tab_enable_v2(host);
	}
	else if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		return get_op_tab_enable_v2(host);
	}

	return -1;
}

static void tab_in_delay_set(struct mmc_host *host, unsigned int in)
{
	ip_tab_dis(host);
	set_itab_value(host, in);
	ip_tab_en(host);
}

static void tab_out_delay_set(struct mmc_host *host,unsigned int out)
{
	op_tab_dis(host);
	set_otab_value(host, out);
	op_tab_en(host);
}

#if 0
static void get_tab_status(struct mmc_host *host)
{
	unsigned int tab_array[4] = {75,150,320,450};
	unsigned int ie, is, iv, oe, os, ov;

	if (host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		ie = ((*(unsigned int*)((unsigned long)host->top_reg_address)) >> 15) & 1;
		is = ((*(unsigned int*)((unsigned long)host->top_reg_address)) >> 4) & 0x3;
		iv = ((*(unsigned int*)((unsigned long)host->top_reg_address)) >> 8) & 0x1F;

		oe = ((*(unsigned int*)((unsigned long)host->top_reg_address)) >> 24) & 1;
		os = ((*(unsigned int*)((unsigned long)host->top_reg_address)) >> 16) & 0x3;
		ov = ((*(unsigned int*)((unsigned long)host->top_reg_address)) >> 20) & 0xF;

		printf("Tab Delay Info ======================\n");
		printf("In tab delay Enable = %u\n",ie);
		printf("In tab step = %u ps\n",tab_array[is]);
		printf("In tab Value = %u\n",iv);

		printf("Out tab delay Enable = %u\n",oe);
		printf("Out tab step = %u ps\n",tab_array[os]);
		printf("Out tab Value = %u\n",ov);
		printf("=====================================\n");
	}
}
#endif

static void tab_control_v1(struct mmc_host *host, unsigned int arg)
{
	unsigned int tab_array[4] = {75,150,320,450};
	unsigned int opr;
	unsigned int step;
	unsigned int delay;

	opr = arg & 0xFF;
	step = (arg  >> 8) & 0xFF;
	delay = (arg  >> 16) & 0xFF;

	if (arg & 0x1)
	{
		tab_in_delay_set(host, ((arg >> 8) & 0x3F));
		printf("IP TAB delay %u\n", ((arg >> 8) & 0x3F));
	}

	if (arg & 0x2)
	{
		tab_out_delay_set(host,  ((arg >> 16) & 0xF));
		printf("OP TAB delay %u\n", ((arg >> 16) & 0xF));
	}

	if (arg & 0x4)
	{
		ip_tab_step(host, ((arg >> 24) & 0x3));
		printf("IP TAB step %u ps\n", tab_array[((arg >> 24) & 0x3)]);
	}

	if (arg & 0x8)
	{
			op_tab_step(host, step);
		printf("OP TAB step %u ps\n", tab_array[((arg >> 28) & 0x3)]);
	}
}

static void tab_control_v2(struct mmc_host *host, unsigned int arg)
{
	if (arg & 0x1)
	{
		tab_in_delay_set(host, ((arg >> 8) & 0x3F));
		printf("IP TAB delay %u\n", ((arg >> 8) & 0x3F));
	}

	if (arg & 0x2)
	{
		tab_out_delay_set(host,  ((arg >> 16) & 0xF));
		printf("OP TAB delay %u\n", ((arg >> 16) & 0xF));
	}
}

static void tab_control(struct mmc_host *host, unsigned int arg)
{
	if(host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		tab_control_v2(host, arg);
	}
	else if(host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		tab_control_v2(host, arg);
	}
	else if(host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		tab_control_v1(host, arg);
	}
}

static void emmc_set_baseaddress(struct mmc_host *host, unsigned int address)
{
	host->base = address;
}

static void emmc_decode_csd(struct sd_mmc_csd *csd)
{
	//unsigned csd_struct = 0;
	unsigned m3_h,m3_l;


////////reading for all the mmc versions
//this is required for backward compatibility in code even if mmc version is >= 4.
	//reserved 3 bits
	{
		READ_BITS(csd->buffer[0],0xc0000000,30,csd->csd_struct);
		READ_BITS(csd->buffer[0],0x3c000000,26,csd->specs_ver);
		READ_BITS(csd->buffer[0],0x03000000,24,csd->reserve3);
		READ_BITS(csd->buffer[0],0x00FF0000,16,csd->taac);
		READ_BITS(csd->buffer[0],0x0000FF00,8,csd->nsac);
		READ_BITS(csd->buffer[0],0x000000FF,0,csd->tran_speed);

		READ_BITS(csd->buffer[1],0xFFF00000,20,csd->ccc);
		READ_BITS(csd->buffer[1],0x000F0000,16,csd->read_bl_len);
		READ_BITS(csd->buffer[1],0x00008000,15,csd->read_partial);
		READ_BITS(csd->buffer[1],0x00004000,14,csd->write_misalign);
		READ_BITS(csd->buffer[1],0x00002000,13,csd->read_misalign);
		READ_BITS(csd->buffer[1],0x00001000,12,csd->dsr_imp);
		READ_BITS(csd->buffer[1],0x00000c00,10,csd->reserve2);

		READ_BITS(csd->buffer[1],0x000003ff,0 ,m3_h);          //62-73 bits=12 overlap
		READ_BITS(csd->buffer[2],0xc0000000,30,m3_l);
		m3_h <<= 2; //to make upper part
		csd->c_size = m3_h | m3_l;

		READ_BITS(csd->buffer[2],0x38000000,27,csd->vdd_r_curr_min);
		READ_BITS(csd->buffer[2],0x07000000,24,csd->vdd_r_curr_max);
		READ_BITS(csd->buffer[2],0x00d00000,21,csd->vdd_w_curr_min);
		READ_BITS(csd->buffer[2],0x001c0000,18,csd->vdd_w_curr_max);

		READ_BITS(csd->buffer[2],0x00038000,15,csd->c_size_mult);
		READ_BITS(csd->buffer[2],0x00007c00,10,csd->erase_grp_size);
		READ_BITS(csd->buffer[2],0x000003e0,5 ,csd->erase_grp_mult);
		READ_BITS(csd->buffer[2],0x0000001F,0 ,csd->wp_grp_size);
		READ_BITS(csd->buffer[3],0x80000000,31,csd->wp_grp_enable);
		READ_BITS(csd->buffer[3],0x60000000,29,csd->default_ecc);
		READ_BITS(csd->buffer[3],0x1c000000,26,csd->r2w_factor);
		READ_BITS(csd->buffer[3],0x03c00000,22,csd->write_bl_len);
		READ_BITS(csd->buffer[3],0x00200000,21,csd->write_partial);
		READ_BITS(csd->buffer[3],0x001d0000,17,csd->reserve1);
		READ_BITS(csd->buffer[3],0x00010000,16,csd->content_prot_app);
		READ_BITS(csd->buffer[3],0x0000800 ,15,csd->file_format_grp);
		READ_BITS(csd->buffer[3],0x00004000,14,csd->copy);
		READ_BITS(csd->buffer[3],0x00002000,13,csd->perm_write_protect);
		READ_BITS(csd->buffer[3],0x00001000,12,csd->tmp_write_prot);
		READ_BITS(csd->buffer[3],0x00000c00,10,csd->file_format);
		READ_BITS(csd->buffer[3],0x00000300,8 ,csd->ecc);
	}
}

static void emmc_dump_csd(struct sd_mmc_csd *csd)
{
		printf("\n==========DUMPING MMC CSD REGISTER==================\n");
		printf("csd_struct        : [0x%0X] \n",csd->csd_struct);
		printf("specs_ver         : [0x%0X] \n",csd->specs_ver);
		printf("reserve3          : [0x%0X] \n",csd->reserve3);
		printf("taac              : [0x%0X] \n",csd->taac);
		printf("nsac              : [0x%0X] \n",csd->nsac);
		printf("tran_speed        : [0x%0X] \n",csd->tran_speed);
		printf("ccc               : [0x%0X] \n",csd->ccc);
		printf("read_bl_len       : [0x%0X] \n",csd->read_bl_len);
		printf("read_partial      : [0x%0X] \n",csd->read_partial);
		printf("write_misalign    : [0x%0X] \n",csd->write_misalign);
		printf("read_misalign     : [0x%0X] \n",csd->read_misalign);
		printf("dsr_imp           : [0x%0X] \n",csd->dsr_imp);
		printf("reserve2          : [0x%0X] \n",csd->reserve2);
		printf("c_size            : [0x%0X] \n",csd->c_size);
		printf("vdd_r_curr_min    : [0x%0X] \n",csd->vdd_r_curr_min);
		printf("vdd_r_curr_max    : [0x%0X] \n",csd->vdd_r_curr_max);
		printf("vdd_w_curr_min    : [0x%0X] \n",csd->vdd_w_curr_min);
		printf("vdd_w_curr_max    : [0x%0X] \n",csd->vdd_w_curr_max);
		printf("c_size_mult       : [0x%0X] \n",csd->c_size_mult);
		printf("erase_grp_size    : [0x%0X] \n",csd->erase_grp_size);
		printf("erase_grp_mult    : [0x%0X] \n",csd->erase_grp_mult);
		printf("wp_grp_size       : [0x%0X] \n",csd->wp_grp_size);
		printf("wp_grp_enable     : [0x%0X] \n",csd->wp_grp_enable);
		printf("default_ecc       : [0x%0X] \n",csd->default_ecc);
		printf("r2w_factor        : [0x%0X] \n",csd->r2w_factor);
		printf("write_bl_len      : [0x%0X] \n",csd->write_bl_len);
		printf("write_partial     : [0x%0X] \n",csd->write_partial);
		printf("reserve1          : [0x%0X] \n",csd->reserve1);
		printf("content_prot_app  : [0x%0X] \n",csd->content_prot_app);
		printf("file_format_grp   : [0x%0X] \n",csd->file_format_grp);
		printf("copy              : [0x%0X] \n",csd->copy);
		printf("perm_write_protect: [0x%0X] \n",csd->perm_write_protect);
		printf("tmp_write_prot    : [0x%0X] \n",csd->tmp_write_prot);
		printf("file_format       : [0x%0X] \n",csd->file_format);
		printf("ecc               : [0x%0X] \n",csd->ecc);
		printf("==================================================\n");
}

static void  emmc_decode_cid(struct sd_mmc_cid *cid)
{
	unsigned int serial_h,serial_l;

	READ_BITS(cid->buffer[0],0xff000000,24,cid->manfid);

	READ_BITS(cid->buffer[0],0x000000ff,0,cid->prod_name[0]);
	READ_BITS(cid->buffer[1],0xff000000,24,cid->prod_name[1]);
	READ_BITS(cid->buffer[1],0x00ff0000,16,cid->prod_name[2]);
	READ_BITS(cid->buffer[1],0x0000ff00,8,cid->prod_name[3]);
	READ_BITS(cid->buffer[1],0x000000ff,0,cid->prod_name[4]);

	READ_BITS(cid->buffer[0],0x00030000,16,cid->card_bga);
	READ_BITS(cid->buffer[0],0x0000ff00,8,cid->oemid);

	READ_BITS(cid->buffer[2],0xff000000,24,cid->prod_name6);
	READ_BITS(cid->buffer[2],0x00f00000,20,cid->hwrev);
	READ_BITS(cid->buffer[2],0x000f0000,16,cid->fwrev);
	READ_BITS(cid->buffer[2],0x0000ffff,0,serial_h);
	READ_BITS(cid->buffer[3],0xffff0000,16,serial_l);
	serial_h <<= 16;
	cid->serial = serial_h | serial_l;

	READ_BITS(cid->buffer[3],0x0000f000,12,cid->month);
	//emmc_cid.year = 0;
	READ_BITS(cid->buffer[3],0x00000f00,8,cid->year);
	cid->year = cid->year + 1997;
}

static void  emmc_dump_cid(struct sd_mmc_cid *cid)
{
	printf("==========DUMPING CID REGISTER==================\n");
	printf("VALUE OF MANFID       : %d \n", cid->manfid);
	printf("VALUE OF CARD_BGA IS  : %d \n", cid->card_bga);
	printf("VALUE OF OEMID IS     : %d \n", cid->oemid);
	printf("VALUE OF PROD_NAME IS : %c%c%c%c%c%c \n", cid->prod_name[0],cid->prod_name[1],cid->prod_name[2],cid->prod_name[3],cid->prod_name[4],cid->prod_name6);
	printf("PRODUCT REVISION      : %d.%d \n", cid->hwrev, cid->fwrev);
	printf("VALUE OF SERIAL IS    : %u \n", cid->serial);
	printf("VALUE OF YEAR IS      : %d \n", cid->year);
	printf("VALUE OF MONTH IS     : %d \n", cid->month);
	printf("==================================================\n");
}

static void emmc_ver_check(struct mmc_host *host)
{
	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		host->ver = EMMC_HOST_CONTROLLER_VER3;
		return;
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		host->ver = EMMC_HOST_CONTROLLER_VER3;
		return;
	}

	if(get_chip_rev() >= CHIP_LG1156_A0)
	{
		host->ver = EMMC_HOST_CONTROLLER_VER2;
	}
	else if ((get_chip_rev() >= CHIP_LG1311_B0) && (get_chip_rev() < CHIP_LG1156_A0))
	{
		host->ver = EMMC_HOST_CONTROLLER_VER2;
	}
	else
	{
		host->ver = EMMC_HOST_CONTROLLER_VER1;
	}
}

static void emmc_set_usertab(struct mmc_host *host)
{
	host->usertab = 1;
}

static void emmc_clear_usertab(struct mmc_host *host)
{
	host->usertab = 0;
}

static unsigned int emmc_get_usertab(struct mmc_host *host)
{
	return host->usertab;
}

static void emmc_tabbase_setting(struct mmc_host *host)
{
	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		host->top_reg_address = 0xC0CF0000;
		return;
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		host->top_reg_address = 0xC1CF0000;
		return;
	}

	if(get_chip_rev() >= CHIP_LG1156_A0)	// H14
		host->top_reg_address = 0xFD300280;
	else if ((get_chip_rev() >= CHIP_LG1311_B0) && (get_chip_rev() < CHIP_LG1156_A0))	// M14B0
		host->top_reg_address = 0xFD300280;
	else if ((get_chip_rev() >= CHIP_LG1311_A0) && (get_chip_rev() < CHIP_LG1311_B0))	// M14A0
		host->top_reg_address = 0xFD300288;
	else if ((get_chip_rev() >= CHIP_LG1154_B0) && (get_chip_rev() < CHIP_LG1311_A0))	//H13B0
		host->top_reg_address = 0xFD300288;
	else if ((get_chip_rev() >= CHIP_LG1154_A0) && (get_chip_rev() < CHIP_LG1154_B0))	//H13A0
		host->top_reg_address = 0xFD300288;
	else
		host->top_reg_address = 0x0;
}

static void emmc_tab_setting(struct mmc_host *host)
{
	if (emmc_get_usertab(host))
		return;

	emmc_vendor_tab(host);
}

static void emmc_delay(unsigned int usec)
{
	loop_udelay(usec);
}

static unsigned int emmc_ready_delay(struct mmc_host *host)
{
	unsigned int temp;
	uint32_t start_tick;

	if (host->tunned == 1) // hs200 tab tunning
	{
		return 0;
	}

	start_tick = timer_tick();
	while (1)
	{
		temp = SDMMC_REG_READ(host,EMMC_PRESENT_STATE) & 0x7FFFF;
		if (temp == 0x70000)
		{
			break;
		}

		if(timer_elapsed(start_tick) > (500*1000))
		{
			EMMC_ERROR_PRINT("EMMC BUS TIME OUT\n");
			return EMMC_ERROR_READY_TIMEOUT;
		}
	}

	return 0;
}

static unsigned int emmc_send_cmd(struct mmc_host *host, struct mmc_cmd *mmc)
{
	unsigned int result;

	result = emmc_ready_delay(host);
	if (result)
		return result;

	EMMC_DEBUG_PRINT("CMD %u FLAG %02X MODE %02X ARG 0x%08X\n",mmc->cmd,mmc->flag, mmc->opr, mmc->arg);

	host->cmd = *mmc;

	SDMMC_REG_WRITE(host,EMMC_ARG, mmc->arg);
	SDMMC_REG_WRITE(host,EMMC_COMMAND, (mmc->cmd << (16 + 8)) + (mmc->flag << (16)) + mmc->opr);

	return EMMC_SUCCESS;
}

static void emmc_cmd_reset(struct mmc_host *host)
{
	SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_CMD_RESET);
	emmc_delay(100);
}

static void emmc_data_reset(struct mmc_host *host)
{
	SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_DATA_RESET);
	emmc_delay(100);
}

static unsigned int emmc_flag_check(struct mmc_host *host)
{
	unsigned int cmd_mask;
	unsigned int data_mask;
	unsigned int temp;
	unsigned int irq_res = 0;
	uint32_t start_tick;
	unsigned int maxtime;
	unsigned int cmd_reg;
	unsigned int arg_reg;
	unsigned int cntl_reg;
	unsigned int cntl2_reg;
	unsigned int clk_reg;
	unsigned int status_reg;
	unsigned int i;
	volatile unsigned int data_null;

	cmd_mask = CARD_CMD_MASK;
	data_mask = CARD_DATA_MASK;

	cmd_reg = SDMMC_REG_READ(host,EMMC_COMMAND) >> 24;
	arg_reg = SDMMC_REG_READ(host,EMMC_ARG);
	cntl_reg = SDMMC_REG_READ(host,EMMC_CTRL);
	cntl2_reg = SDMMC_REG_READ(host,EMMC_CTRL2);
	clk_reg = SDMMC_REG_READ(host,EMMC_CLOCK_CTRL);

	status_reg = SDMMC_REG_READ(host,EMMC_INT_STATUS);
	EMMC_DEBUG_PRINT("EMMC_INT_STATUS = 0x%X\n", status_reg);
	if (status_reg & (1 << EMMC_INT_CARD_INSERT))
	{
		SDMMC_BIT_SET(host, EMMC_INT_STATUS, EMMC_INT_CARD_INSERT);
	}

	start_tick = timer_tick();
	do
	{
		status_reg = SDMMC_REG_READ(host,EMMC_INT_STATUS);
		EMMC_DEBUG_PRINT("EMMC_INT_STATUS2 = 0x%X\n", status_reg);
		if (status_reg & cmd_mask)
		{
			SDMMC_REG_WRITE(host,EMMC_INT_STATUS, (status_reg & cmd_mask));
			if (status_reg & CARD_CMD_FIN)
			{
				irq_res += MMC_CMD_COMPLETE;
				if (host->irq_enable)
					host->cmd.ack += MMC_CMD_COMPLETE;
				else
					break;
			}
			else
			{
				EMMC_ERROR_PRINT("CE = ERRORCODE 0x%04X, INT STATUS 0x%04X,(CMD%u, ARG:0x%X, CLKREG:0x%X, CNTRREG:0x%X, CNTR2REG:0x%X\n",\
								(status_reg >> 16), status_reg & 0xFFFF, cmd_reg, arg_reg, clk_reg, cntl_reg,cntl2_reg);
				status_reg = SDMMC_REG_READ(host,EMMC_INT_STATUS);
				SDMMC_REG_WRITE(host,EMMC_INT_STATUS, status_reg);

				emmc_cmd_reset(host);
				emmc_data_reset(host);

				host->cmd.err += MMC_CMD_ERROR;
				irq_res += MMC_CMD_ERROR;
				return irq_res;
			}
		}

		if ((SDMMC_REG_READ(host,EMMC_COMMAND) & 0x3F000000) == 0x15000000)
			break;

		if (host->irq_enable == 0)
		{
			if (timer_elapsed(start_tick) > (100*1000))
			{
				EMMC_ERROR_PRINT("CT = ERRORCODE 0x%04X, INT STATUS 0x%04X,(CMD%u, ARG:0x%X, CLKREG:0x%X, CNTRREG:0x%X, CNTR2REG:0x%X\n\n",\
								(status_reg >> 16), status_reg & 0xFFFF, cmd_reg, arg_reg, clk_reg, cntl_reg,cntl2_reg);
				status_reg = SDMMC_REG_READ(host,EMMC_INT_STATUS);
				SDMMC_REG_WRITE(host,EMMC_INT_STATUS, status_reg);

				emmc_cmd_reset(host);
				emmc_data_reset(host);

				irq_res += MMC_CMD_TIMEOUT;
				return irq_res;
			}
		}
	}while (host->irq_enable == 0);

	if (host->irq_enable == 0)
	{
		if (host->cmd.done_check == MMC_FLAG_COMMAND_ONLY)
		{
			return 0;
		}

		maxtime = (1000*1000);

		start_tick = timer_tick();
	}

	do
	{
		if (host->irq_enable == 0)
			status_reg = SDMMC_REG_READ(host,EMMC_INT_STATUS);
		if (status_reg & data_mask)
		{
			SDMMC_REG_WRITE(host,EMMC_INT_STATUS, (status_reg & data_mask));
			if(status_reg & CARD_DATA_FIN)
			{
				irq_res += MMC_DATA_COMPLETE;
				if (host->irq_enable)
					host->cmd.ack += MMC_DATA_COMPLETE;
				else
					break;
			}
			else if (status_reg & CARD_READ_READY)
			{
				for (i=0; i<(128/4); i++)
				{
					data_null = SDMMC_REG_READ(host, EMMC_PIO_DATA);
					emmc_delay(10);
				}
				break;
			}
			else
			{
				EMMC_ERROR_PRINT("DE = ERRORCODE 0x%04X, INT STATUS 0x%04X,(CMD%u, ARG:0x%X, CLKREG:0x%X, CNTRREG:0x%X, CNTR2REG:0x%X\n\n",\
								(status_reg >> 16), status_reg & 0xFFFF, cmd_reg, arg_reg, clk_reg, cntl_reg, cntl2_reg);

				status_reg = SDMMC_REG_READ(host,EMMC_INT_STATUS);
				SDMMC_REG_WRITE(host,EMMC_INT_STATUS, status_reg);

				emmc_cmd_reset(host);
				emmc_data_reset(host);

				host->cmd.err += MMC_DATA_ERROR;
				irq_res += MMC_DATA_ERROR;

				return irq_res;
			}
		}

		if (host->irq_enable == 0)
		{
			if(timer_elapsed(start_tick) > maxtime)	/* temporary value */
			{
				EMMC_ERROR_PRINT("DT = ERRORCODE 0x%04X, INT STATUS 0x%04X,(CMD%u, ARG:0x%X, CLKREG:0x%X, CNTRREG:0x%X, CNTR2REG:0x%X\n\n",\
								(status_reg >> 16), status_reg & 0xFFFF, cmd_reg, arg_reg, clk_reg, cntl_reg, cntl2_reg);
				status_reg = SDMMC_REG_READ(host,EMMC_INT_STATUS);
				SDMMC_REG_WRITE(host,EMMC_INT_STATUS, status_reg);

				emmc_cmd_reset(host);
				emmc_data_reset(host);

				irq_res += MMC_DATA_TIMEOUT;
				return irq_res;
			}
		}
	}while (host->irq_enable == 0);

	if (status_reg & 0x8000)
	{
		EMMC_ERROR_PRINT("OE = ERRORCODE 0x%04X, INT STATUS 0x%04X,(CMD%u, ARG:0x%X, CLKREG:0x%X, CNTRREG:0x%X, CNTR2REG:0x%X\n\n",\
						(status_reg >> 16), status_reg & 0xFFFF, cmd_reg, arg_reg, clk_reg, cntl_reg, cntl2_reg);
		temp = SDMMC_REG_READ(host,EMMC_INT_STATUS);
		SDMMC_REG_WRITE(host,EMMC_INT_STATUS, temp);

		irq_res += MMC_ETC_ERROR;
		return irq_res;
	}

	if (host->irq_enable == 0)
		return 0;
	else
		return irq_res;
}

static unsigned int emmc_int_check(struct mmc_host *host)
{
	unsigned int ret = 0;
	unsigned int timeout_ms;
	uint32_t start_tick;
	unsigned int endflag;

	if (host->irq_enable)
	{
		if (host->cmd.done_check == MMC_FLAG_COMMAND_ONLY)
			endflag = MMC_CMD_COMPLETE;
		else
			endflag = MMC_CMD_COMPLETE + MMC_DATA_COMPLETE;

		start_tick = timer_tick();
		if (host->cmd.timeout_ms == 0)
			timeout_ms = 1000 * 1000;
		else
			timeout_ms = host->cmd.timeout_ms * 1000;

		do {
			if(timer_elapsed(start_tick) > timeout_ms)	/* temporary value */
			{
				EMMC_ERROR_PRINT("TE =  CMD%u, arg:0X%x, TIMEOUT!(%u/%u)\n",host->cmd.cmd,host->cmd.arg,timeout_ms,host->cmd.timeout_ms);
				return MMC_DATA_TIMEOUT;;
			}

			if ((host->cmd.err & MMC_CMD_ERROR) || (host->cmd.err & MMC_DATA_ERROR))
			{
				ret = host->cmd.err;
				break;
			}
		} while (host->cmd.ack != endflag);
	}
	else
	{
		ret = emmc_flag_check(host);
	}

	return ret;
}

static unsigned int emmc_ffs(unsigned int value)
{
	unsigned int i;

	for (i=0; i<32; i++)
	{
		if ((1 << i) & value)
		{
			return (i + 1);
		}
	}

	return 0;
}

static void emmc_set_maxclock(struct mmc_host *host)
{
#if defined(CONFIG_BOARD_TYPE_FPGA)
	host->max_clock = 8000000;
#else
	if (host->userclock)
	{
		host->max_clock = host->userclock;
		return;
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210) // H15
	{
		host->max_clock = EMMC_HOST_MAX;
		emmc_vendor_max_clock(host);
		return;
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312) // M16
	{
		host->max_clock = EMMC_HOST_MAX;
		emmc_vendor_max_clock(host);
		return;
	}

	if(get_chip_rev() >= CHIP_LG1156_A0)	// H14
	{
		host->max_clock = EMMC_HOST_MAX;
	}
	else if ((get_chip_rev() >= CHIP_LG1311_B0) && (get_chip_rev() < CHIP_LG1156_A0))	// M14B0
	{
		host->max_clock = EMMC_HOST_MAX;
	}
	else if ((get_chip_rev() >= CHIP_LG1311_A0) && (get_chip_rev() < CHIP_LG1311_B0))	// M14A0
	{
		host->max_clock = 49500000;
	}
	else if ((get_chip_rev() >= CHIP_LG1154_B0) && (get_chip_rev() < CHIP_LG1311_A0))	//H13B0
	{
		host->max_clock = 49500000;
	}
	else if ((get_chip_rev() >= CHIP_LG1154_A0) && (get_chip_rev() < CHIP_LG1154_B0))	//H13A0
	{
		host->max_clock = 49500000;
	}
	else
	{
		host->max_clock = 49500000;
	}

	emmc_vendor_max_clock(host);
#endif
}

static unsigned int emmc_get_clock(struct mmc_host *host)
{
	unsigned int div;

	div = (SDMMC_REG_READ(host,EMMC_CLOCK_CTRL) >> EMMC_DIV8_SHIFT) & 0xFF;
	div = div + (((SDMMC_REG_READ(host,EMMC_CLOCK_CTRL) >> EMMC_DIV_UPPER2_SHIFT) & 0x3) << 8);

	if (div)
		return (host->base_clock / (div * 2));
	else
		return host->base_clock;
}

//#pragma GCC push_options
//#pragma GCC optimize ("O0")
static unsigned int emmc_set_clock (struct mmc_host *host, unsigned int clock, unsigned int timeout_enable)
{
	volatile unsigned int div;
	volatile unsigned int ctrl;
	volatile unsigned int div_upperbits;
	volatile unsigned int timeout;

	emmc_delay(100);

	if (!clock)
		return 0;

	ctrl = SDMMC_REG_READ(host,EMMC_CLOCK_CTRL);
	EMMC_DEBUG_PRINT("Value of CLK State 0x%x \n", ctrl & 0xFFFF);
	ctrl &= EMMC_DISABLE;
	SDMMC_REG_WRITE(host,EMMC_CLOCK_CTRL,ctrl);

	//Now writting 00    on the SDCLK Frequency select MSB which will be safer.
	ctrl &= EMMC_CLK_BASE_DIVIDER;
	SDMMC_REG_WRITE(host,EMMC_CLOCK_CTRL ,ctrl);

#if 0
	capab = SDMMC_REG_READ(host,EMMC_CAPABLITY);
	max_clock = (capab & HOST_BASECLOCK_MASK) >> HOST_BASECLOCK_SHIFT;
	max_clock = max_clock * 1000000;
#endif

	if (!host->userclock)
	{
		if (clock > host->max_clock)
			clock = host->max_clock;
	}

	if (clock > (host->base_clock / 2))
		div = 0;
	else
	{
		for (div = 1; div <= 0x3FF; div *= 2)
		{
//			printf("div %u, host->base_clock %u\n", div, host->base_clock);
			if ((host->base_clock / (div * 2)) <= clock)
				break;
		}
	}
	EMMC_DEBUG_PRINT("clock = %u\n",clock);

	ctrl |= ((div  & 0xFF) << EMMC_DIV8_SHIFT); // Common for SD2.0 & SD3.0
	ctrl &= EMMC_CLK_EN_BIT;

	div_upperbits = (div >> EMMC_DIV8_SHIFT ) & 0x3;
	ctrl &= 0xFFFFFF3F; // to clear
	ctrl |= (div_upperbits << 6);

	ctrl |= ((~EMMC_DISABLE) | (~EMMC_CLK_EN_BIT));
	SDMMC_REG_WRITE(host,EMMC_CLOCK_CTRL,ctrl);

	timeout = 10;
	while (!((ctrl = SDMMC_REG_READ(host,EMMC_CLOCK_CTRL)) & EMMC_CLK_INT_STABLE))
	{
		if (timeout == 0)
		{
			EMMC_ERROR_PRINT("E13\n");
			return EMMC_FAIL;
		}

		timeout--;
		emmc_delay(1000);
	}

	ctrl |= EMMC_CLK_START_BIT;
	SDMMC_REG_WRITE(host,EMMC_CLOCK_CTRL, ctrl);

	// DATA TIMEOUT CONTROL
	if (timeout_enable)
	{
		ctrl = SDMMC_REG_READ(host,EMMC_CLOCK_CTRL);
		ctrl &= 0xFFF1FFFF;
		ctrl |= 0x000E0000;
		SDMMC_REG_WRITE(host,EMMC_CLOCK_CTRL,ctrl);
	}
	else
	{
		ctrl = SDMMC_REG_READ(host,EMMC_CLOCK_CTRL);
		ctrl &= 0xFFF1FFFF;
		SDMMC_REG_WRITE(host,EMMC_CLOCK_CTRL,ctrl);
	}
	EMMC_DEBUG_PRINT("Change of CLK State 0x%x \n", ctrl & 0xFFFF);

	host->clock = emmc_get_clock(host);
//	printf("clk %u/%u\n",host->clock,host->max_clock);
	return 0;
}


static unsigned int emmc_init_power_n_clock(struct mmc_host *host)
{
	timeout_id_t tid;

	unsigned int reg;
	unsigned int temp;

	//Data Transfer Mode 4bit, SD Power On, 3V
	//*(volatile unsigned int*)EMMC_CTRL =		  0xD02;
	reg =  (1 << EMMC_CTRL_WIDTH) + (6 <<EMMC_CTRL_VOLTAGE_SELECT) + (1 << EMMC_CTRL_BUS_POWER);
	SDMMC_REG_WRITE(host,EMMC_CTRL, reg);

	set_timeout(&tid, 1000);
	while (1)
	{
		temp = SDMMC_REG_READ(host,EMMC_CTRL);
		if (temp == reg)
			break;
		SDMMC_REG_WRITE(host,EMMC_CTRL, reg);

		if (is_timeout(&tid))
		{
			  EMMC_ERROR_PRINT("EMMC RESET TIMER CONDITION OUT\n");
			  return EMMC_FAIL;
		}
	}

	// Internal Clock Enable/Stable/SD Clock Enable
	// divide 1024
	// data timeout TMCLK * 2^27
	emmc_set_clock(host, EMMC_400KHZ, EMMC_TIMEOUT_DISABLE);	// 0807

	reg = SDMMC_REG_READ(host,EMMC_CLOCK_CTRL);
	reg |= 0x7;
	EMMC_DEBUG_PRINT("EMMC_CLOCK_CTRL 0x%X\n",reg);

	set_timeout(&tid, 1000);
	while (1)
	{
		temp = SDMMC_REG_READ(host,EMMC_CLOCK_CTRL);
		if (temp == reg)
			break;
		SDMMC_REG_WRITE(host,EMMC_CLOCK_CTRL, reg);

		if (is_timeout(&tid))
		{
			EMMC_ERROR_PRINT("EMMC RESET TIMER CONDITION OUT\n");
			return EMMC_FAIL;
		}
	}

	emmc_delay(2000);

	return 0;
}

static void emmc_irq_config(struct mmc_host *host)
{
	timeout_id_t tid;
	uint32_t temp;

	SDMMC_REG_WRITE(host,EMMC_INT_ENABLE, 0x1FF0EFB);
	SDMMC_REG_WRITE(host,EMMC_INT_SIGNAL, 0x1FF0EFB);

	set_timeout(&tid, 10);
	while (1)
	{
		temp = SDMMC_REG_READ(host,EMMC_INT_STATUS);
		if (temp & 0x40)
		{
			break;
		}

		if (is_timeout(&tid))
		{
			break;
		}
	}

	SDMMC_BIT_SET(host, EMMC_INT_STATUS, EMMC_INT_CARD_INSERT);
}

static void emmc_set_adma(struct mmc_host *host, unsigned int bool)
{
	unsigned int temp;

	if (bool == EMMC_ON)
	{
		temp = SDMMC_REG_READ(host,EMMC_CTRL);
		temp |= 0x00000010;
		SDMMC_REG_WRITE(host,EMMC_CTRL,temp);
	}
	else
	{
		temp = SDMMC_REG_READ(host,EMMC_CTRL);
		temp &= 0xFFFFFFEF;
		SDMMC_REG_WRITE(host,EMMC_CTRL,temp);
	}

}

unsigned int emmc_send_status(struct mmc_host *host, unsigned int arg)
{
	unsigned int result;
	unsigned int response;
	unsigned int i;
	struct mmc_cmd mmc;

	mmc.cmd = EMMC_CMD13_SEND_STATUS;
	mmc.flag = MMC_RESP_R1;
	mmc.opr = 0x00;
	mmc.arg = 1 << MMC_RCA_SHIFT;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.timeout_ms = 100;

	i = 0;
	while (1)
	{
		mmc.ack = 0;
		mmc.err = 0;
		result = emmc_send_cmd(host, &mmc);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC CMD13 SEND ERROR with arg 0x%X\n",arg);
			return EMMC_FAIL;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC CMD13 CHECK ERROR with arg 0x%X\n",arg);
			return EMMC_FAIL;
		}

		response = SDMMC_REG_READ(host,EMMC_RESPONSE_0);
		if(response == 0x900)
			break;

		emmc_delay(1000);

		i++;

		if (i > 1000)
		{
			EMMC_ERROR_PRINT("EMMC CMD13 TIMEOUT(1S) with arg 0x%X\n",arg);
			return EMMC_FAIL;
		}
	}

	return 0;
}

int emmc_switch(struct mmc_host *host, unsigned char address, unsigned char value, unsigned int ignore_busy)
{
	struct mmc_cmd mmc;
	unsigned int result;

	mmc.cmd = EMMC_CMD6_SWITCH;
	mmc.arg = 0x03000000 + (address << 16) + (value << 8);
	mmc.flag = MMC_RESP_R1B;
	mmc.opr = 0x00;
	mmc.done_check = MMC_FLAG_DATA;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD6 SEND ERROR with arg 0x%X\n",mmc.arg);
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD6 CHECK ERROR with arg 0x%X\n",mmc.arg);
		return EMMC_FAIL;
	}

	emmc_delay(1000);

	if (ignore_busy == EMMC_IGNORE_BUSY)
	{
		return 0;
	}

	result = emmc_send_status(host, mmc.arg);
	if (result)
	{
		return EMMC_FAIL;
	}

	return 0;
}

int emmc_get_extcsd(struct mmc_host *host, int dump)
{
	unsigned int result;
	uint8_t *csd_dma_buf;
	struct mmc_cmd mmc;

	csd_dma_buf = (uint8_t*)dma_malloc(512);

	host->mmc_adma_list[0].address = (unsigned int)((unsigned long)csd_dma_buf);
	host->mmc_adma_list[0].size = 512;
	host->mmc_adma_list[0].flag = 0x23;

	SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS, (unsigned int)((unsigned long)host->mmc_adma_list));
	SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT, (1 << 16) + 512);

	mmc.cmd = EMMC_CMD8_SEND_EXT_CSD;
	mmc.flag = MMC_RESP_R1 | RSP_DATA_PRESENT;
	mmc.opr = 0x11;
	mmc.arg = 0x00000000;
	mmc.done_check = MMC_FLAG_DATA;
	mmc.ack = 0;
	mmc.timeout_ms = 100;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD8 SEND ERROR\n");
		dma_free(csd_dma_buf);
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD8 CHECK ERROR\n");
		dma_free(csd_dma_buf);
		return EMMC_FAIL;
	}

	memcpy(host->card.ext_csd.buffer, (void *)csd_dma_buf, 512);
	dma_free(csd_dma_buf);

	emmc_decode_ext_csd(&host->card.ext_csd);

	if (dump == EMMC_DUMP_EN)
		emmc_dump_ext_csd(&host->card.ext_csd);

	return 0;
}

int emmc_cache_enable(struct mmc_host *host)
{
	int result = 0;

	if ((host->card.ext_csd.cache_size > 0) && (host->card.ext_csd.ext_csd_rev >= 6))
	{
		result = emmc_switch(host, 33, 1, EMMC_CHECK_BUSY);
		if (result)
			return 1;

		result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
	}

	return result;
}

int emmc_cache_flush(struct mmc_host *host)
{
	int retult = 0;

	if (host->card.ext_csd.cache_enable > 0)
		retult = emmc_switch(host, 32, 1, EMMC_CHECK_BUSY);

	return retult;
}

int emmc_set_hpi(struct mmc_host *host)
{
	int retult = 0;

	retult = emmc_switch(host, 161, 1, EMMC_CHECK_BUSY);

	return retult;
}

int emmc_set_hcerasedef(struct mmc_host *host)
{
	int retult = 0;

	retult = emmc_switch(host, 175, 1, EMMC_CHECK_BUSY);

	return retult;
}

static unsigned int emmc_set_buswidth (struct mmc_host *host, unsigned int bus_width)
{
	unsigned char value = 2;
	unsigned int temp = 0;
	unsigned int result = 0;

	if (bus_width == 0)
		bus_width = 8;

	if (bus_width == 8)			value = 0x02;
	else if (bus_width == 4)	value = 0x01;
	else if (bus_width == 1)	value = 0x00;
	else						value = 0x02;

	result = emmc_switch(host, 0xB7, value, EMMC_CHECK_BUSY);
	if (!result)
	{
		if (bus_width == 8)
		{
			temp = SDMMC_REG_READ(host,EMMC_CTRL);
			temp &= 0xFFFFFFDD;
			temp |= 0x20;
			SDMMC_REG_WRITE(host,EMMC_CTRL,temp);
		}
		else if (bus_width == 4)
		{
			temp = SDMMC_REG_READ(host,EMMC_CTRL);
			temp &= 0xFFFFFFDD;
			temp |= 0x02;
			SDMMC_REG_WRITE(host,EMMC_CTRL,temp);
		}
		else if (bus_width == 1)
		{
			temp = SDMMC_REG_READ(host,EMMC_CTRL);
			temp &= 0xFFFFFFDD;
			temp |= 0x00;
			SDMMC_REG_WRITE(host,EMMC_CTRL,temp);
		}

		host->bus_width = bus_width;
	}
	else
	{
		return EMMC_FAIL;
	}

	return EMMC_SUCCESS;
}

static unsigned int emmc_set_pon(struct mmc_host *host, unsigned int mode)
{
	return emmc_switch(host, 0x22, mode, EMMC_CHECK_BUSY);
}

static void emmc_set_ds(unsigned int ds)
{
	unsigned int reg;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		if (ds > 4)
			ds = 1;

		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0xFF8FFFFF;
		reg |= (ds << 20);
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);

		emmc_delay(100);
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		if (ds > 4)
			ds = 1;

		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x24);
		reg &= 0xFF8FFFFF;
		reg |= (ds << 20);
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x24, reg);

		emmc_delay(100);
	}

}

static unsigned int emmc_get_ds(void)
{
	unsigned int reg;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0x00700000;
		reg = reg >> 20;

		if (reg == 0)
			return 50;
		else if (reg == 1)
			return 33;
		else if (reg == 2)
			return 66;
		else if (reg == 3)
			return 100;
		else if (reg == 4)
			return 40;
		else
			return 0;
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x24);
		reg &= 0x00700000;
		reg = reg >> 20;

		if (reg == 0)
			return 50;
		else if (reg == 1)
			return 33;
		else if (reg == 2)
			return 66;
		else if (reg == 3)
			return 100;
		else if (reg == 4)
			return 40;
		else
			return 0;
	}


	return 0;
}

static void emmc_set_pdb(void)
{
	unsigned int reg;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		if ((SDMMC_TOP_REG_READ(&emmc_host, 0x28) & 0x00040000) != 0x00040000)
		{
			reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
			reg &= 0xFFFBFFFF;
			reg |= 0x00040000;
			SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);	// eMMC_HOST_CONTROL_9 for HIGHSPEED SETTING NOT USE INIT
												// PDb Active : Must Settinng
												// CALIO Enable & RETRIM Enable < for HS400,HS200,DDR50,HIGHSPEED >
												// Driver Strength : DR_TY = 3'h3 < for HS400,HS200,DDR50,HIGHSPEED >
												// DLL Enable	& dll_iff = 3b100 & trm_icp = 8bxxxx1000 < for HS400,HS200,DDR50,HIGHSPEED >

			emmc_delay(10); 					// waiting for PDb Enable
		}
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		if ((SDMMC_TOP_REG_READ(&emmc_host, 0x24) & 0x00020000) != 0x00020000)
		{
			reg = SDMMC_TOP_REG_READ(&emmc_host, 0x24);
			reg &= 0xFFFDFFFF;
			reg |= 0x00020000;
			SDMMC_TOP_REG_WRITE(&emmc_host, 0x24, reg); // eMMC_HOST_CONTROL_9 for HIGHSPEED SETTING NOT USE INIT

												// PDb Active : Must Settinng
												// CALIO Enable & RETRIM Enable < for HS400,HS200,DDR50,HIGHSPEED >
												// Driver Strength : DR_TY = 3'h3 < for HS400,HS200,DDR50,HIGHSPEED >
												// DLL Enable	& dll_iff = 3b100 & trm_icp = 8bxxxx1000 < for HS400,HS200,DDR50,HIGHSPEED >

			emmc_delay(10); 					// waiting for PDb Enable
		}
	}

}

static void emmc_clear_dll(void)
{
	unsigned int reg;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0xFFFFF7FF;
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);
		udelay(100);
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x24);
		reg &= 0xFFFFFF7F;
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x24, reg);
		udelay(100);
	}
}

static void emmc_set_strb90(unsigned int strb90)
{
	unsigned int reg;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0xFFFFFFCF;

		if (strb90 > 3)
			strb90 = 3;

		if (strb90 == 1)
			reg |= 0x10;
		else if (strb90 == 2)
			reg |= 0x20;
		else if (strb90 == 3)
			reg |= 0x30;

		SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);
		udelay(100);
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x30);
		reg &= 0xFFFFFFFC;

		if (strb90 > 3)
			strb90 = 3;

		if (strb90 == 1)
			reg |= 0x1;
		else if (strb90 == 2)
			reg |= 0x2;
		else if (strb90 == 3)
			reg |= 0x3;

		SDMMC_TOP_REG_WRITE(&emmc_host, 0x30, reg);
		udelay(100);
	}
}

static void emmc_set_strb180(unsigned int strb180)
{
	unsigned int reg;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0xFFFFFF3F;

		if (strb180 > 3)
			strb180 = 3;

		if (strb180 == 1)
			reg |= 0x40;
		else if (strb180 == 2)
			reg |= 0x80;
		else if (strb180 == 3)
			reg |= 0xC0;

		SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);
		udelay(100);
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x30);
		reg &= 0xFFFFFFF3;

		if (strb180 > 3)
			strb180 = 3;

		if (180 == 1)
			reg |= 0x4;
		else if (180 == 2)
			reg |= 0x8;
		else if (180 == 3)
			reg |= 0xC;

		SDMMC_TOP_REG_WRITE(&emmc_host, 0x30, reg);
		udelay(100);
	}
}

static unsigned int emmc_set_dll(void)
{
	unsigned int reg;
	unsigned int count = 0;

	emmc_clear_dll();

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg |= 0x00000800;
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);
		udelay(100);

		while((SDMMC_TOP_REG_READ(&emmc_host, 0x3C) & 1) == 0)
		{
			udelay(100);
			count++;
			if (count > 10)
				return EMMC_FAIL;
		}
	}


	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x24);
		reg |= 0x00000080;
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x24, reg);
		udelay(100);

		while((SDMMC_TOP_REG_READ(&emmc_host, 0x48) & 1) == 0)
		{
			udelay(100);
			count++;
			if (count > 10)
				return EMMC_FAIL;
		}
	}

	return 0;
}

static unsigned int emmc_get_trm_icp(struct mmc_host *host)
{
	unsigned int reg = 0xFFFFFFFF;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0xF;
	}
	else if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x24);
		reg &= 0xF;
	}
	else
	{
		printf("TRM ICP - don't support this chip\n");
	}

	return reg;
}

static unsigned int emmc_set_trm_icp(struct mmc_host *host, unsigned int value)
{
	unsigned int ret = 1;
	unsigned int reg = 0;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0xFFFFFFF0;
		if (value > 15)
			value = 15;
		reg |= value;
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);
		ret = 0;
	}
	else if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x24);
		reg &= 0xFFFFFFF0;
		if (value > 15)
			value = 15;
		reg |= value;
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x24, reg);

		ret = 0;
	}
	else
	{
		printf("TRM ICP - don't support this chip\n");
	}

	return ret;
}

static unsigned int emmc_get_dll_iff(struct mmc_host *host)
{
	unsigned int reg = 0xFFFFFFFF;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28) >> 8;
		reg &= 0x7;
	}
	else
	{
		printf("DLL IFF - don't support this chip\n");
	}

	return reg;
}

static unsigned int emmc_set_dll_iff(struct mmc_host *host, unsigned int value)
{
	unsigned int ret = 1;
	unsigned int reg = 0;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		reg &= 0xFFFFF8FF;
		if (value > 7)
			value = 7;
		reg |= (value << 8);
		SDMMC_TOP_REG_WRITE(&emmc_host, 0x28, reg);
		ret = 0;
	}
	else
	{
		printf("DLL IFF - don't support this chip\n");
	}

	return ret;
}


#ifdef EMMC_EXECUTE_TUNNING

static void emmc_4bit_bus(struct mmc_host *host)
{
	unsigned int reg;

	reg = SDMMC_REG_READ(host,EMMC_CTRL);
	reg &= 0xFFFFFFDD;
	reg |= 0x02;
	SDMMC_REG_WRITE(host,EMMC_CTRL,reg);
}

static void emmc_8bit_bus(struct mmc_host *host)
{
	unsigned int reg;

	reg = SDMMC_REG_READ(host,EMMC_CTRL);
	reg &= 0xFFFFFFDD;
	reg |= 0x20;
	SDMMC_REG_WRITE(host,EMMC_CTRL,reg);
}

static unsigned int emmc_tunning_complete(struct mmc_host *host)
{
	if (host->tunned == 2)
		return 1;
	else
		return 0;
}

static unsigned int emmc_execute_tunning(struct mmc_host *host, unsigned int mode)
{
	volatile unsigned int reg;
	unsigned int result;
	struct mmc_cmd mmc;
	unsigned char cmd;
	uint32_t start_tick;
	uint32_t count;
	uint32_t i=0;
#if USE_EMMC_IRQ
uint32_t irq_status=0;
#endif
	if ((mode == EMMC_MODE_HS50) || (mode == EMMC_MODE_DDR50))
		cmd = EMMC_CMD19_EXECUTE_TUNE;
	else if ((mode == EMMC_MODE_HS400) || (mode == EMMC_MODE_HS200))
		cmd = EMMC_CMD21_HS200_EXECUTE_TUNE;
	else
		return EMMC_FAIL;

#if USE_EMMC_IRQ
	irq_status = host->irq_enable;
	if (irq_status)
	{
		interrupt_deactive(IRQ_SDHC);
		host->irq_enable = 0;
	}
#endif

	SDMMC_REG_WRITE(host,EMMC_INT_SIGNAL, 0x20);
	SDMMC_REG_WRITE(host,EMMC_INT_ENABLE, 0x20);

	reg = SDMMC_REG_READ(host,EMMC_CTRL2);
	reg |= (1 << 22); // Execute Tuning
	SDMMC_REG_WRITE(host, EMMC_CTRL2, reg);

	if ((mode == EMMC_MODE_HS400) || (mode == EMMC_MODE_HS200))
	{
		if (host->bus_width == 8)
			count = 128;
		else if (host->bus_width == 4)
			count = 64;
		else
			return EMMC_FAIL;
	}
	else
	{
		count = 64;
	}

	reg = SDMMC_REG_READ(host,EMMC_BLOCK_COUNT);
	reg = (1 << 16) + count;
	SDMMC_REG_WRITE(host, EMMC_BLOCK_COUNT, reg);


	host->tunned = 1;

	start_tick = timer_tick();
	do {
		i++;
		mmc.cmd = cmd;
		mmc.flag = MMC_RESP_R1 | MMC_CMD_ADTC;
		mmc.opr = 0x10;
		mmc.arg = 0;
		mmc.done_check = MMC_FLAG_DATA;
		mmc.timeout_ms = 100;
		mmc.ack = 0;
		mmc.err = 0;

		if (i > 32)
			emmc_4bit_bus(host); // forced to fail (32~39)

		result = emmc_send_cmd(host,&mmc);;
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC CMD%u SEND ERROR\n",cmd);
			goto tunning_error;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC CMD%u CHECK ERROR\n",cmd);
			goto tunning_error;
		}

		if (i > 32)
			emmc_8bit_bus(host);

		reg = SDMMC_REG_READ(host,EMMC_CTRL2);

		if(timer_elapsed(start_tick) > (500 * 1000))	/* temporary value */
		{
			EMMC_ERROR_PRINT("EMMC TUNNING TIMEOUT\n");
			goto tunning_error;
		}
	} while (reg & 0x400000);
	start_tick = timer_tick() - start_tick;
//	printf("EMMC TUNNING TIME %uus\n",timer_ticks2usec(start_tick));

	if (host->noprint == 0)
	{
		if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
			printf("EMMC tune reg 0x%X\n", (SDMMC_TOP_REG_READ(host, 0x3C) >> 8) & 0x1F);

		if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
			printf("EMMC tune reg 0x%X\n", (SDMMC_TOP_REG_READ(host, 0x48) >> 12) & 0x1F);
	}

	emmc_cmd_reset(host);
	emmc_data_reset(host);

	if (i != 40)
	{
		EMMC_ERROR_PRINT("EMMC TUNNING COUNT NOT 40\n");
		goto tunning_error;
	}

	if ((SDMMC_REG_READ(host,EMMC_CTRL2) & 0x800000) == 0)
	{
		EMMC_ERROR_PRINT("EMMC SAMPLED CLOCK NOT DETECTED\n");
		goto tunning_error;
	}

	host->tunned = 2;

	SDMMC_REG_WRITE(host,EMMC_INT_SIGNAL, 0x1FF0EFB);
	SDMMC_REG_WRITE(host,EMMC_INT_ENABLE, 0x1FF0EFB);


#if USE_EMMC_IRQ
	if (irq_status)
	{
		interrupt_active(IRQ_SDHC);
		host->irq_enable = 1;
	}
#endif

	return 0;

tunning_error:
	emmc_8bit_bus(host);
	SDMMC_REG_WRITE(host,EMMC_INT_SIGNAL, 0x1FF0EFB);
	SDMMC_REG_WRITE(host,EMMC_INT_ENABLE, 0x1FF0EFB);

#if USE_EMMC_IRQ
	if (irq_status)
	{
		interrupt_active(IRQ_SDHC);
		host->irq_enable = 1;
	}
#endif

	return EMMC_FAIL;
}
#endif

static int emmc_ds_setting(struct mmc_host *host)
{
	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		if (!host->driver_strength)
			emmc_set_ds(emmc_vendor_host_ds(host));
		else
		{
			unsigned int arg;
			switch (host->driver_strength)
			{
				case 33:
					arg = 1;
					break;
				case 40:
					arg = 4;
					break;
				case 50:
					arg = 0;
					break;
				case 66:
					arg = 2;
					break;
				case 100:
					arg = 3;
					break;
				default:
					arg = 1;
					break;
			}
			emmc_set_ds(arg);

			return 0;
		}
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		if (!host->driver_strength)
			emmc_set_ds(emmc_vendor_host_ds(host));
		else
		{
			unsigned int arg;
			switch (host->driver_strength)
			{
				case 33:
					arg = 1;
					break;
				case 40:
					arg = 4;
					break;
				case 50:
					arg = 0;
					break;
				case 66:
					arg = 2;
					break;
				case 100:
					arg = 3;
					break;
				default:
					arg = 1;
					break;
			}
			emmc_set_ds(arg);

			return 0;
		}
	}

	return 1;
}

static void emmc_pad_select_standard(void)
{
	SDMMC_TOP_BIT_SET(&emmc_host, 0x30, 4);
	SDMMC_TOP_BIT_SET(&emmc_host, 0x30, 5);
}

static void emmc_pad_select_dll(void)
{
	SDMMC_TOP_BIT_CLEAR(&emmc_host, 0x30, 4);
	SDMMC_TOP_BIT_CLEAR(&emmc_host, 0x30, 5);
}

static unsigned int emmc_set_highspeed(struct mmc_host *host, unsigned int intab, unsigned int outtab)
{
	unsigned int result;
	unsigned int reg;

	result = emmc_switch(host, 0xB9, 0x01, EMMC_IGNORE_BUSY);
	if (result)
		return EMMC_FAIL;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		emmc_pad_select_standard();
	}

	SDMMC_BIT_SET(host,EMMC_CTRL, EMMC_CTRL_HIGHSPEED);

	reg = SDMMC_REG_READ(host,EMMC_CTRL2);
	reg &= ~(EMMC_UHS_MASK + EMMC_18_SIGNALING);
	reg |= (EMMC_UHS_SDR25 | EMMC_18_SIGNALING);
	SDMMC_REG_WRITE(host,EMMC_CTRL2,reg);

	if ((host->userclock) && (host->userclock < EMMC_50MHZ))
		result = emmc_set_clock(host, host->userclock, EMMC_TIMEOUT_ENABLE);
	else
		result = emmc_set_clock(host, EMMC_50MHZ, EMMC_TIMEOUT_ENABLE);
	if (result)
		return EMMC_FAIL;

	result = emmc_set_dll();
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC DLL LOCK ERROR in HIGHSPEED\n");
		return EMMC_FAIL;
	}

	if (host->usertab)
	{
		tab_out_delay_set(host, outtab);
		tab_in_delay_set(host, intab);
	}
	else
	{
		tab_out_delay_set(host, host->tab_50.out);
		tab_in_delay_set(host, host->tab_50.in);
	}

	result = emmc_send_status(host, 0x3B90100);
	if (result)
	{
		return EMMC_FAIL;
	}

	result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
	if (result)
		return EMMC_FAIL;

	if (host->card.ext_csd.hs_timing != 0x1)
		return EMMC_FAIL;

	host->ddr_mode = 0;

	return 0;
}

static unsigned int emmc_set_ddr50(struct mmc_host *host, unsigned int intab, unsigned int outtab)
{
	volatile unsigned int reg;
	volatile unsigned int result;

	if (host->card.ext_csd.hs_timing != 1)
	{
		EMMC_ERROR_PRINT("ERROR! DDR MODE NEED HIGHSPEED MODE\n");
		return EMMC_FAIL;
	}

	result = emmc_switch(host, 0xB7, 0x6, EMMC_IGNORE_BUSY);
	if (result)
		return EMMC_FAIL;

	emmc_set_ds(0);	// driver strength set 50ohm

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		emmc_pad_select_standard();
	}

	if (host->usertab)
	{
		tab_out_delay_set(host, outtab);
		tab_in_delay_set(host, intab);
	}
	else
	{
		tab_out_delay_set(host, host->tab_50.out);
		tab_in_delay_set(host, host->tab_50.in);
	}

	reg = SDMMC_REG_READ(host,EMMC_CTRL2);
	reg &= ~(EMMC_UHS_MASK + EMMC_18_SIGNALING);
	reg |= (EMMC_UHS_DDR50 | EMMC_18_SIGNALING);
	SDMMC_REG_WRITE(host,EMMC_CTRL2,reg);

	result = emmc_send_status(host, 0x3B70600);
	if (result)
		return EMMC_FAIL;

	host->ddr_mode = 1;

	result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
	if (result)
		return EMMC_FAIL;

	return 0;
}


int emmc_set_hs200(struct mmc_host *host, unsigned int intab, unsigned int outtab)
{
	unsigned int result;
	unsigned int reg;
	unsigned char value;

	// SET TO HS200
//	value = (emmc_vendor_card_ds(host) << 4) | 0x2;
	reg = host->card.ext_csd.driver_strength;
	if ((reg & 0x12) == 0x12)
		value = 0x12;
	else if ((reg & 0x12) == 0x10)
		value = 0x42;
	else if ((reg & 0x12) == 0x2)
		value = 0x12;
	else
		value = 0x2;

	result = emmc_switch(host, 0xB9, value, EMMC_IGNORE_BUSY);
	if (result)
		return EMMC_FAIL;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		emmc_pad_select_dll();
	}

	emmc_ds_setting(host);

	if (host->usertab)
	{
		tab_out_delay_set(host, outtab);
		tab_in_delay_set(host, intab);
	}
	else
	{
		tab_out_delay_set(host, host->tab_200.out);
#ifdef EMMC_EXECUTE_TUNNING
		if (host->ver == EMMC_HOST_CONTROLLER_VER3)
			ip_tab_dis(host);
		else
			tab_in_delay_set(host, host->tab_200.in);
#else
		tab_in_delay_set(host, host->tab_200.in);
#endif
	}

	SDMMC_BIT_SET(host,EMMC_CTRL, EMMC_CTRL_HIGHSPEED);

	reg = SDMMC_REG_READ(host,EMMC_CTRL2);
	reg &= ~(EMMC_UHS_MASK + EMMC_18_SIGNALING);
	reg |= (EMMC_UHS_SDR104 | EMMC_18_SIGNALING);
	SDMMC_REG_WRITE(host, EMMC_CTRL2, reg);

	if (host->userclock)
		result = emmc_set_clock(host, host->userclock, EMMC_TIMEOUT_ENABLE);
	else
		result = emmc_set_clock(host, EMMC_200MHZ, EMMC_TIMEOUT_ENABLE);
	if (result)
		return EMMC_FAIL;

	result = emmc_set_dll();
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC DLL LOCK ERROR in HS200\n");
		return EMMC_FAIL;
	}

#ifdef EMMC_EXECUTE_TUNNING
	if ((host->usertab == 0) && (host->ver == EMMC_HOST_CONTROLLER_VER3))
	{
		if (emmc_execute_tunning(host, EMMC_MODE_HS200))
		{
			EMMC_ERROR_PRINT("ERROR HS200 AutoTune so Change Fixed Tab Mode\n");
			tab_in_delay_set(host, host->tab_200.in);
		}
	}
#endif
	host->ddr_mode = 0;

	result = emmc_send_status(host, 0x3B90200);
	if (result)
	{
		return EMMC_FAIL;
	}

	result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
	if (result)
		return EMMC_FAIL;

	if (host->card.ext_csd.buffer[185] != value)
		return EMMC_FAIL;

	return 0;
}

int emmc_set_hs400(struct mmc_host *host, unsigned int intab, unsigned int outtab, unsigned int strb90, unsigned int strb180)
{
	unsigned int result;
	unsigned int reg;
	unsigned char value;

	result = emmc_set_hs200(host, host->tab_200.in, host->tab_200.out);
	if (result)
	{
		EMMC_ERROR_PRINT("ERROR HS200 SET\n");
		return EMMC_FAIL;
	}

	result = emmc_set_highspeed(host, host->tab_50.in, host->tab_50.out);
	if (result)
	{
		EMMC_ERROR_PRINT("ERROR HS SET\n");
		return EMMC_FAIL;
	}

	/* change to DDR50 */
#if 1
	result = emmc_switch(host, 0xB7, 0x6, EMMC_IGNORE_BUSY);
	if (result)
	{
		EMMC_ERROR_PRINT("ERROR DDR50 SET\n");
		return EMMC_FAIL;
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		emmc_pad_select_standard();
	}

	tab_out_delay_set(host, host->tab_50.out);
	tab_in_delay_set(host, host->tab_50.in);

	reg = SDMMC_REG_READ(host,EMMC_CTRL2);
	reg &= ~(EMMC_UHS_MASK + EMMC_18_SIGNALING);
	reg |= (EMMC_UHS_DDR50 | EMMC_18_SIGNALING);
	SDMMC_REG_WRITE(host,EMMC_CTRL2,reg);

	host->ddr_mode = 1;
#else
	result = emmc_set_ddr50(host, host->tab_50.in, host->tab_50.out);
	if (result)
	{
		EMMC_ERROR_PRINT("ERROR DDR50 SET\n");
		return EMMC_FAIL;
	}
#endif

	if (strb90 != STRB90_DONT_SET)
		emmc_set_strb90(strb90);

	if (strb180 != STRB180_DONT_SET)
		emmc_set_strb180(strb180);

	// SET TO HS400
//	value = (emmc_vendor_card_ds(host) << 4) | 0x3;
    reg = host->card.ext_csd.driver_strength;
	if ((reg & 0x12) == 0x12)
		value = 0x13;
	else if ((reg & 0x12) == 0x10)
		value = 0x43;
	else if ((reg & 0x12) == 0x2)
		value = 0x13;
	else
		value = 0x3;

	result = emmc_switch(host, 0xB9, value, EMMC_IGNORE_BUSY);
	if (result)
	{
		EMMC_ERROR_PRINT("HS400 SWITCH ERROR\n");
		return EMMC_FAIL;
	}

	emmc_ds_setting(host);

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		emmc_pad_select_dll();
	}

	reg = SDMMC_REG_READ(host,EMMC_CTRL2);
	reg &= ~(EMMC_UHS_MASK + EMMC_18_SIGNALING);
	reg |= (EMMC_UHS_HS400 | EMMC_18_SIGNALING);
	SDMMC_REG_WRITE(host, EMMC_CTRL2, reg);

	result = emmc_set_clock(host, EMMC_200MHZ, EMMC_TIMEOUT_ENABLE);
	if (result)
		return EMMC_FAIL;

	result = emmc_set_dll();
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC DLL LOCK ERROR int HS400\n");
		return EMMC_FAIL;
	}

	if (host->usertab)
	{
		tab_out_delay_set(host, outtab);
		tab_in_delay_set(host, intab);
	}
	else
	{
		tab_out_delay_set(host, host->tab_400.out);
#ifdef EMMC_EXECUTE_TUNNING
		if (emmc_tunning_complete(host))
		{
			if (host->tab_400.in == host->tab_200.in)
				ip_tab_dis(host);
			else
				tab_in_delay_set(host, host->tab_400.in);
		}
		else
			tab_in_delay_set(host, host->tab_400.in);
#else
		tab_in_delay_set(host, host->tab_400.in);
#endif
	}

	result = emmc_send_status(host, 0x3B90300);
	if (result)
	{
		return EMMC_FAIL;
	}

	result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
	if (result)
	{
		EMMC_ERROR_PRINT("HS400 READ EXTCSD ERROR\n");
		return EMMC_FAIL;
	}

	if (host->card.ext_csd.buffer[185] != value)
	{
		EMMC_ERROR_PRINT("ERROR HS400 SET\n");
		return EMMC_FAIL;
	}

	host->ddr_mode = 1;

	return 0;
}

int emmc_set_relative_address(struct mmc_host *host, unsigned int rca)
{
	unsigned int result;
	struct mmc_cmd mmc;

	mmc.cmd = EMMC_CMD3_SET_RELATIVE_ADDR;
	mmc.flag = MMC_RESP_R1;
	mmc.opr = 0x00;
	mmc.arg = rca << MMC_RCA_SHIFT;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host, &mmc);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD3 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD3 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	return 0;
}

int emmc_set_seldsel_card(struct mmc_host *host, unsigned int rca)
{
	unsigned int result;
	struct mmc_cmd mmc;

	mmc.cmd = EMMC_CMD7_SELDESEL_CARD;
	mmc.flag = MMC_RESP_R1;
	mmc.opr = 0x00;
	mmc.arg = rca << MMC_RCA_SHIFT;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD7 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD7 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	return 0;
}

int emmc_autoset_buswidth(struct mmc_host *host)
{
	unsigned int temp;
	unsigned int i;
	unsigned int result;

	// 1 : 1 << 0
	// 4 : 1 << 2
	// 8 : 1 << 3
	for(i=0; i<4; i++)
	{
		temp = 3 - i;
		if (temp == 1)
			continue;
		emmc_set_buswidth(host, 1 << temp);
		result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC BUS WIDTH %u\n",1 << temp);
			continue;
		}
		else
		{
			return EMMC_SUCCESS;
		}
	}

	EMMC_ERROR_PRINT("BUS WIDTH SET ERROR\n");
	return EMMC_FAIL;
}

int emmc_change_partition(struct mmc_host *host, unsigned int mode)
{
	volatile unsigned int result;

	if (mode > 2)
		mode = 2;

	result = emmc_switch(host, 0xB3, mode, EMMC_CHECK_BUSY);
	if (result)
		return EMMC_FAIL;

	result = emmc_send_status(host, 0x3B30000 | (mode << 8));
	if (result)
		return EMMC_FAIL;

	return 0;

}

int emmc_go_idle(struct mmc_host *host)
{
	unsigned int result;
	struct mmc_cmd mmc;

	mmc.cmd = EMMC_CMD0_IDLE_STATE;
	mmc.flag = MMC_RESP_NONE;
	mmc.opr = 0x00;
	mmc.arg = 0x00000000;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD0 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD0 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	emmc_delay(1000);

	return 0;
}

int emmc_wakeup(struct mmc_host *host)
{
	timeout_id_t tid;
	unsigned int response;
	unsigned int result;
	unsigned int emmc_busy = 0;
	unsigned int capab;
	unsigned int ocr_avail;
	unsigned int ocr;

	struct mmc_cmd mmc;

	// CLOCK & VOLTAGE
	capab = SDMMC_REG_READ(host,EMMC_CAPABLITY);
	EMMC_DEBUG_PRINT("EMMC_CAPABLITY = 0x%X\n",capab);

	ocr_avail = 0;
	if (capab & VDD_330)
	{
		ocr_avail |= (MMC_VDD_33_34 | MMC_VDD_32_33);
	}
	else if (capab & VDD_300)
	{
		ocr_avail |= (MMC_VDD_29_30 | MMC_VDD_30_31);
	}
	else if (capab & VDD_180)
	{
		ocr_avail |= (MMC_VDD_18_19 | MMC_VDD_17_18);
	}

	// OPERATION VOLTAGE  CHECK
	mmc.cmd = EMMC_CMD1_SEND_OP_COND;
	mmc.flag = MMC_RESP_R3;
	mmc.opr = 0x00;
	mmc.arg = 0x40000000;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD1 SEND ERROR - first\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD1 CHECK ERROR - first\n");
		return EMMC_FAIL;
	}

	response = SDMMC_REG_READ(host,EMMC_RESPONSE_0);
	if (response & 0x80000000)
	{
		emmc_busy = 1;
	}
	emmc_delay(1000);

	unsigned int bit;
	response &= ocr_avail;
	bit = emmc_ffs(response);

	if (bit)
	{
		bit -= 1;
		ocr = 3 << bit;
	}
	else
	{
		ocr = 0;
	}

	/* It takes 240ms */
	if (emmc_busy == 0)
	{
		set_timeout(&tid, 1000);

		mmc.arg = 0x40000000 | ocr;

		while (1)
		{
			mmc.ack = 0;
			mmc.err = 0;
			result = emmc_send_cmd(host,&mmc);;
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC CMD1 SEND ERROR\n");
				return EMMC_FAIL;
			}

			result = emmc_int_check(host);
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC CMD1 CHECK ERROR\n");
				return EMMC_FAIL;
			}

			response = SDMMC_REG_READ(host,EMMC_RESPONSE_0);
			if (response & 0x80000000)
				break;

			emmc_delay(1000);

			if (is_timeout(&tid))
			{
				EMMC_ERROR_PRINT("EMMC CMD1 - TIMER CONDITION OUT\n");
				return EMMC_FAIL;
			}
		}
	}

	if (response & 0x40000000)
	{
		host->card.address_mode = EMMC_SECTOR_MODE;
	}
	else
	{
		host->card.address_mode = EMMC_BYTE_MODE;
	}

	return 0;
}

int emmc_get_cid(struct mmc_host *host, int dump)
{
	struct mmc_cmd mmc;
	unsigned int result;

	mmc.cmd = EMMC_CMD2_ALL_SEND_CID;
	mmc.flag = MMC_RESP_R2;
	mmc.opr = 0x00;
	mmc.arg = 0x00000000;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD2 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD2 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	host->card.cid.buffer[0] = (SDMMC_REG_READ(host,EMMC_RESPONSE_3) << 8) + (SDMMC_REG_READ(host,EMMC_RESPONSE_2) >> 24);
	host->card.cid.buffer[1] = (SDMMC_REG_READ(host,EMMC_RESPONSE_2) << 8) + (SDMMC_REG_READ(host,EMMC_RESPONSE_1) >> 24);
	host->card.cid.buffer[2] = (SDMMC_REG_READ(host,EMMC_RESPONSE_1) << 8) + (SDMMC_REG_READ(host,EMMC_RESPONSE_0) >> 24);
	host->card.cid.buffer[3] = (SDMMC_REG_READ(host,EMMC_RESPONSE_0) << 8);

	emmc_decode_cid(&host->card.cid);

	if (dump == EMMC_DUMP_EN)
		emmc_dump_cid(&host->card.cid);

	return 0;
}

int emmc_get_csd(struct mmc_host *host, int dump)
{
	unsigned int result;
	struct mmc_cmd mmc;

	mmc.cmd = EMMC_CMD9_SEND_CSD;
	mmc.flag = MMC_RESP_R2;
	mmc.opr = 0x00;
	mmc.arg = host->card.rca << MMC_RCA_SHIFT;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 100;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD9 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD9 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	host->card.csd.buffer[0] = (SDMMC_REG_READ(host,EMMC_RESPONSE_3) << 8) + (SDMMC_REG_READ(host,EMMC_RESPONSE_2) >> 24);
	host->card.csd.buffer[1] = (SDMMC_REG_READ(host,EMMC_RESPONSE_2) << 8) + (SDMMC_REG_READ(host,EMMC_RESPONSE_1) >> 24);
	host->card.csd.buffer[2] = (SDMMC_REG_READ(host,EMMC_RESPONSE_1) << 8) + (SDMMC_REG_READ(host,EMMC_RESPONSE_0) >> 24);
	host->card.csd.buffer[3] = (SDMMC_REG_READ(host,EMMC_RESPONSE_0) << 8);

	emmc_decode_csd(&host->card.csd);

	if (dump == EMMC_DUMP_EN)
		emmc_dump_csd(&host->card.csd);

	return 0;
}

static unsigned int emmc_get_sector_count(struct mmc_host *host)
{
	unsigned long int Capacity_in_bytes=0;
	unsigned int  Blocknr,Mult,Block_len;
	unsigned int sector_count;

	if (host->card.ext_csd.sec_count)
	{
		sector_count = host->card.ext_csd.sec_count;
	}
	else
	{
		Mult			  = 1 << (host->card.csd.c_size_mult +2);
		Blocknr 		  = (host->card.csd.c_size + 1) * Mult;
		Block_len		  = 1 << host->card.csd.read_bl_len;
		Capacity_in_bytes = Blocknr * Block_len;
		sector_count = Capacity_in_bytes / 512;
		EMMC_DEBUG_PRINT("Capacity %lu Bytes, no.Blocks[%d], Blk_len[%d] \n", Capacity_in_bytes,Blocknr,  Block_len);
 	}

	EMMC_DEBUG_PRINT("EMMC Sector count = %u\n",sector_count);
	return sector_count;
}

static unsigned int emmc_set_blocksize(struct mmc_host *host, unsigned int size)
{
	unsigned int result;
	struct mmc_cmd mmc;

	mmc.cmd = EMMC_CMD16_SET_BLOCK_LENGTH;
	mmc.flag = MMC_RESP_R1;
	mmc.opr = 0x00;
	mmc.arg = size;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD16 SEND ERROR\n");
		return result;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD16 CHECK ERROR\n");
		return result;
	}

	return result;
}

static unsigned int emmc_get_erase_size(struct mmc_host *host)
{
	unsigned int erase_size;

	if (host->card.ext_csd.erase_grp_defn & 0x1)
	{
		erase_size = host->card.ext_csd.hc_erase_grp_size * 512 * 1024;
	}
	else
	{
		erase_size = (host->card.csd.erase_grp_size + 1) * (host->card.csd.erase_grp_mult + 1);
		erase_size = (erase_size << host->card.csd.write_bl_len);
	}
//	printf("EMMC erase align & size : %u/0x%X\n",erase_size,erase_size);

	return erase_size;
}

static unsigned int emmc_get_trim_enable(struct mmc_host *host)
{
	if (host->card.ext_csd.ext_csd_rev >= 6) // 6 is emmc ver 4.5
	{
		return 1;
	}
	else if (host->card.ext_csd.ext_csd_rev == 5) // 6 is emmc ver 4.5
	{
		if (host->card.ext_csd.sec_support & 0x10)
		{
			return 1;
		}
	}

	return 0;
}

static unsigned int emmc_controller_reset(struct mmc_host *host)
{
	timeout_id_t tid;

	// HOST CONTROLLER RESET
	set_timeout(&tid, 100);
	SDMMC_BIT_SET(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_ALL_RESET);
	while (SDMMC_BIT_READ(host, EMMC_CLOCK_CTRL, EMMC_CLOCK_ALL_RESET))
	{
		if (is_timeout(&tid))
		{
			EMMC_ERROR_PRINT("EMMC RESET TIMER CONDITION OUT\n");
			return EMMC_FAIL;
		}
	}

	return 0;
}

static unsigned int init_emmc_basic(struct mmc_host *host)
{
	unsigned int result;

	EMMC_CORE_PRINT("EMMC Initialize Start\n");

	host->initing = 1;

	emmc_tabbase_setting(host);

	op_tab_dis(host);
	ip_tab_dis(host);

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		emmc_clear_dll();
		emmc_set_pdb();
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		SDMMC_TOP_REG_WRITE(host, 0x4, 0xe9ffe870);

		emmc_clear_dll();
		emmc_set_pdb();

		emmc_pad_select_dll();
	}

	if (host->inited == 0)
	{
		host->mmc_adma_list = (adma_list_t *)dma_malloc(sizeof(adma_list_t)*MMC_ADMA_LIST_MAX);
	}

	host->tunned = 0;
	host->bus_width = 0;
	host->ddr_mode = 0;
	host->clock = 0;
	host->max_clock = EMMC_HOST_MAX;
	host->card.rca = 1;

	if (host->inited < 0xFFFFFFFF)
		host->inited++;

	// HOST CONTROLLER RESET
	result = emmc_controller_reset(host);
	if (result)
		goto emmc_init_err;

	// IRQ CONFIG & CARD DETECTED
	emmc_irq_config(host);

	// SET POWER & CLOCK 400Khz  Set
	result = emmc_init_power_n_clock(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC POWER & CLOCK SET ERROR\n");
		goto emmc_init_err;
	}

	// WAKEUP
	result = emmc_go_idle(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC GO IDLE ERROR\n");
		goto emmc_init_err;
	}

	// OPERATION VOLTAGE  CHECK
	result = emmc_wakeup(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC WAKEUP ERROR\n");
		goto emmc_init_err;
	}

	//	GET CID REGISTER
	result = emmc_get_cid(host, EMMC_DUMP_DISABLE);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC GET CID ERROR\n");
		goto emmc_init_err;
	}

	//	SET RELATIVE ADDRESS ( set 1 )
	result = emmc_set_relative_address(host, host->card.rca);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC SET RCA ERROR\n");
		goto emmc_init_err;
	}

	//	GET CSD
	result = emmc_get_csd(host, EMMC_DUMP_DISABLE);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC GET CSD ERROR\n");
		goto emmc_init_err;
	}

	//	SET RCA SELECT CARD and OTHER CARD IS DESELECT
	result = emmc_set_seldsel_card(host, host->card.rca);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC SET SEL/DSEL ERROR\n");
		goto emmc_init_err;
	}

	result = emmc_set_clock(host, EMMC_400KHZ, EMMC_TIMEOUT_ENABLE);
	if (result)
    {
        EMMC_ERROR_PRINT("EMMC SET CLOCK TIMEOUT ERROR\n");
        goto emmc_init_err;
    }


	// EMMC ADMA ENABLE
	emmc_set_adma(host, EMMC_ON);

	// BUSWIDTH AUTO SEARCH & READ EXTCSD
	if (host->userbus == 0)
	{
		result = emmc_autoset_buswidth(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC SET BUSWIDTH ERROR\n");
			goto emmc_init_err;
		}
	}
	else
	{
		emmc_set_buswidth(host, host->userbus);
		result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC SET BUSWIDTH ERROR\n");
			goto emmc_init_err;
		}
	}

	// EMMC TAB  SETTING need CID
	emmc_tab_setting(host);

	// MAX EMMC BUS CLOCK SET
	emmc_set_maxclock(host);

	//SET BLOCK SIZE (DEFAULT 512)
	result = emmc_set_blocksize(host, MMC_SECTOR_SIZE);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC SET BLOCKSIZE ERROR\n");
		goto emmc_init_err;
	}

	host->initing = 0;

	return EMMC_SUCCESS;

emmc_init_err:
	EMMC_ERROR_PRINT("EMMC Basic Initialize Fail\n");

	host->initing = 0;

	return result;
}
static unsigned int init_emmc_highspeed(struct mmc_host *host)
{
	unsigned int result;
	unsigned int set_hs50 = 0;
	unsigned int set_ddr50 = 0;
	unsigned int set_hs200 = 0;
	unsigned int set_hs400 = 0;

	host->initing = 1;

	if (host->usermode == EMMC_TESTMODE_NONE)
	{
		if(host->ver == EMMC_HOST_CONTROLLER_VER3)	// HS400, HS200, DDR50,  HIGHSPEED SUPPORT
		{
			if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS400)
			{
				set_hs400 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS200)
			{
				set_hs200 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_DDR50)
			{
				set_hs50 = 1;
				set_ddr50 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS)
			{
				set_hs50 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_LEGACY)
			{
				host->initing = 0;
				return 0;
			}
		}
		else if(host->ver == EMMC_HOST_CONTROLLER_VER2)	// HS200, DDR50,  HIGHSPEED SUPPORT
		{
			if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS200)
			{
				set_hs200 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_DDR50)
			{
				set_hs50 = 1;
				set_ddr50 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS)
			{
				set_hs50 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_LEGACY)
			{
				host->initing = 0;
				return 0;
			}
		}
		else if(host->ver == EMMC_HOST_CONTROLLER_VER1)	// DDR50,  HIGHSPEED SUPPORT
		{
			if (host->card.ext_csd.card_type & EMMC_SUPPORT_DDR50)
			{
				set_hs50 = 1;
				set_ddr50 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS)
			{
				set_hs50 = 1;
			}
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_LEGACY)
			{
				host->initing = 0;
				return 0;
			}
		}
	}
	else
	{
		if (host->usermode == EMMC_TESTMODE_HS50)
		{
			set_hs50 = 1;
		}
		else if (host->usermode == EMMC_TESTMODE_DDR50)
		{
			set_hs50 = 1;
			set_ddr50 = 1;
		}
		else if (host->usermode == EMMC_TESTMODE_HS200)
		{
			set_hs200 = 1;
		}
		else if (host->usermode == EMMC_TESTMODE_HS400)
		{
			set_hs400 = 1;
		}

	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		emmc_set_trm_icp(host, 4);
	}

	if (set_hs50)
	{
		result = emmc_set_highspeed(host, 0 ,0);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC SET HIGHSPEED ERROR\n");
			goto emmc_init_err;
		}
	}

	if (set_ddr50)
	{
		result = emmc_set_ddr50(host, 0, 0);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC SET DDRMODE ERROR\n");
			goto emmc_init_err;
		}
	}

	if (set_hs200)
	{
		result = emmc_set_hs200(host, 0, 0);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC SET HS200 ERROR\n");
			goto emmc_init_err;
		}
	}

	if (set_hs400)
	{
		result = emmc_set_hs400(host, 0, 0, host->strb90, host->strb180);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC SET HS400 ERROR\n");
			goto emmc_init_err;
		}
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1311)
	{
		if (host->card.ext_csd.ext_csd_rev >= 3)
		{
			if (emmc_set_hcerasedef(host))
			{
				EMMC_ERROR_PRINT("EMMC HCERASE SET ERROR\n");
				return EMMC_FAIL;
			}
		}

		if ((host->card.ext_csd.hpi_feature & 1) == 1)
		{
			if (emmc_set_hpi(host))
			{
				EMMC_ERROR_PRINT("EMMC HPI SET ERROR\n");
				return EMMC_FAIL;
			}
		}
	}

	if (host->card.ext_csd.ext_csd_rev >= 6)
	{
		if (emmc_cache_enable(host))
		{
			EMMC_ERROR_PRINT("EMMC CACHE ENABLE ERROR\n");
			return EMMC_FAIL;
		}

		if (emmc_set_pon(host, 1))
		{
			EMMC_ERROR_PRINT("EMMC PON ERROR\n");
			return EMMC_FAIL;
		}
	}

	result = emmc_get_extcsd(host, EMMC_DUMP_DISABLE);
	if (result)
	{
		EMMC_ERROR_PRINT("FINAL READ EXTCSD ERROR\n");
		return EMMC_FAIL;
	}

	host->userclock = 0;
	host->userbus = 0;
	host->usertab = 0;

	host->initing = 0;

	return EMMC_SUCCESS;

emmc_init_err:
	EMMC_ERROR_PRINT("EMMC Highspeed Initialize Fail\n");

	host->initing = 0;

	return result;
}

static unsigned int init_emmc(struct mmc_host *host, unsigned int forced_basic)
{
	unsigned int result;
	unsigned int tick1, tick2;

	tick1 = timer_tick();

#if !defined(FIRST_BOOT)
		EMMC_CORE_PRINT("EMMC Initialize Start\n");
#endif
	result = init_emmc_basic(host);
	if (result)
		goto error;

#if defined(FIRST_BOOT)
	forced_basic = 2;
#endif

	if (host->usermode == 1)
		forced_basic = 2;

	if (forced_basic > 1) // if first &  second init try fail, eMMC operation 25Mhz
	{
		// EMMC CLOCK CONTROL
		result = emmc_set_clock(host, EMMC_25MHZ, EMMC_TIMEOUT_ENABLE);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC SET CLOCK 24.5Mhz ERROR\n");
		}

		if (host->usermode == 1)
			host->usermode = 0;

		goto end;
	}

	result = init_emmc_highspeed(host);
	if (result)
		goto error;
	else
		goto end;

end:
	tick2 = timer_tick();
#if !defined(FIRST_BOOT)
	EMMC_CORE_PRINT("EMMC Initialize End\n");
	if ((!host->noprint) && (host->inited == 1))
		printf("EMMC : %u hz, (%s), bus %u bit, init time %u us\n",host->clock , host->ddr_mode ? "DDR" : "SDR", host->bus_width, timer_ticks2usec(tick2-tick1));
#endif

	return result;

error:
#if !defined(FIRST_BOOT)
	EMMC_ERROR_PRINT("EMMC Initialize Fail\n");
#endif

	return EMMC_FAIL;

}

static unsigned int transfer_emmc_adma(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address, unsigned int r_w)
{
	unsigned int SectorAddress;
	unsigned short BlockCount;
	unsigned short BlockSize = MMC_SECTOR_SIZE;
	unsigned int result;
	struct mmc_cmd mmc;

	if (size & (BlockSize - 1))
	{
		EMMC_DEBUG_PRINT("512");
		return EMMC_ERROR_UNITSIZE_FALSE;
	}

	if (size > MMC_CHUNKSIZE_MAX)
	{
		EMMC_DEBUG_PRINT("t.s.o\n");
		return EMMC_ERROR_SIZE_OVER;
	}

	if (host->card.address_mode == EMMC_SECTOR_MODE)
		SectorAddress = (unsigned int)(address / MMC_SECTOR_SIZE);
	else
		SectorAddress = (unsigned int)address;

	unsigned int i;
	unsigned int size_count, size_mod;

//	printf("MMC READ SIZE = %u\n", size);

	size_count = size / MMC_ADMA_BLOCK_MAX;
	size_mod = size & (MMC_ADMA_BLOCK_MAX-1);
	if (size_mod)
		size_count++;

	for (i=0; i<(size_count-1); i++)
	{
		host->mmc_adma_list[i].address = buffer + (i*MMC_ADMA_BLOCK_MAX);
		host->mmc_adma_list[i].size = 0;
		host->mmc_adma_list[i].flag = 0x21;
	}
	host->mmc_adma_list[i].address = buffer + (i*MMC_ADMA_BLOCK_MAX);
	host->mmc_adma_list[i].size = size_mod;
	host->mmc_adma_list[i].flag = 0x23;

	BlockCount = (size / 512);

	SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(unsigned int)((unsigned long)host->mmc_adma_list));
	SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(BlockCount << 16) + BlockSize);


	mmc.opr = (1 << EMMC_CMD_DMA_ENABLE);

	if (r_w == MMC_READ)
	{
		if (BlockCount > 1)
			mmc.cmd = EMMC_CMD18_READ_MULTI_EBLOCK;
		else
			mmc.cmd = EMMC_CMD17_READ_SINGLE_BLOCK;

		mmc.opr = mmc.opr + (1 << EMMC_CMD_DATA_DIRECTION);
	}
	else
	{
		if (BlockCount > 1)
			mmc.cmd = EMMC_CMD25_WRITE_MULTI_EBLOCK;
		else
			mmc.cmd = EMMC_CMD24_WRITE_SINGLE_BLOCK;
	}
	mmc.flag = MMC_RESP_R1 | RSP_DATA_PRESENT;


	if (BlockCount > 1)
		mmc.opr = mmc.opr + (1 << EMMC_CMD_MULTIBLOCK) + (1 << EMMC_CMD_BLOCK_COUNT_ENABLE) + (EMMC_AUTOCMD12_EN << EMMC_CMD_AUTO_ENABLE); // opr = opr + 0x26;

	mmc.arg = SectorAddress;
	mmc.done_check = MMC_FLAG_DATA;
	mmc.ack = 0;
	mmc.timeout_ms = 10000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;

	return result;
}

static unsigned int read_emmc_adma(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	return transfer_emmc_adma(host, buffer, size, address, MMC_READ);
}


static unsigned int write_emmc_adma(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	return transfer_emmc_adma(host, buffer, size, address, MMC_WRITE);
}

#if USE_EMMC_IRQ
static unsigned int read_emmc_irq(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	unsigned int res;

	emmc_irq.rw = EMMC_READ_IRQ;
	emmc_irq.buffer = buffer;
	emmc_irq.totalsize = size;
	emmc_irq.currentsize = 0;
	emmc_irq.error = 0;

	if (size <= MMC_CHUNKSIZE_MAX)
		emmc_irq.size = size;
	else
		emmc_irq.size = MMC_CHUNKSIZE_MAX;
	emmc_irq.address = address;
	emmc_irq.complete = 0;

	emmc_irq.states = EMMC_BLOCK_TRANSFER;
	res = read_emmc_adma(host, emmc_irq.buffer, emmc_irq.size, emmc_irq.address);

	if (res == 0)
	 	interrupt_active(IRQ_SDHC);
	return res;
}

static unsigned int write_emmc_irq(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	unsigned int res;

	emmc_irq.rw = EMMC_WRITE_IRQ;
	emmc_irq.buffer = buffer;
	emmc_irq.totalsize = size;
	emmc_irq.currentsize = 0;
	emmc_irq.error = 0;

	if (size <= MMC_CHUNKSIZE_MAX)
		emmc_irq.size = size;
	else
		emmc_irq.size = MMC_CHUNKSIZE_MAX;
	emmc_irq.address = address;
	emmc_irq.complete = 0;

	emmc_irq.states = EMMC_BLOCK_TRANSFER;
	res = write_emmc_adma(host, emmc_irq.buffer, emmc_irq.size, emmc_irq.address);

	if (res == 0)
	 	interrupt_active(IRQ_SDHC);
	return res;
}

static int wait_emmc_transfer_irq(struct mmc_host *host, unsigned int timeout_time)
{
	u32 start_tick = timer_tick();

	while (emmc_irq.complete == 0)
	{
		if (emmc_irq.error & 0xFFFF0000)
		{
			EMMC_ERROR_PRINT("EMMC TRANSFER ERROR - %X\n",emmc_irq.error);
			emmc_irq.states = EMMC_DEFAULT;
			return -1;
		}

		if(timer_elapsed(start_tick) > timeout_time*1000)
		{
			EMMC_ERROR_PRINT("EMMC TRANSFER TIMEOUT ERROR, timout=%d\n", timeout_time);
			emmc_irq.states = EMMC_DEFAULT;
			return -2;
		}
	}

	emmc_irq.states = EMMC_DEFAULT;
	return 0;
}

static void emmc_interrupt_handler(void* param)
{
	volatile int ret = 0;
	volatile int status = 0;
	struct mmc_host *host;
	unsigned int retry_count = 0;
	unsigned int result;

	interrupt_deactive(IRQ_SDHC);

	host = (struct mmc_host *)param;

	status = emmc_flag_check(host);
#if EMMC_IRQ_ERROR_RETRY
	if ((status & 0xFFFF0000) && (host->initing == 0))
	{
		host->irq_enable = 0;
		for (retry_count=0; retry_count<host->max_retry; retry_count++)
		{
			result = init_emmc(host, EMMC_MAXSPEED_INIT);
			if (result)
			{
				printf("EMMC ReInit Error\n");
				continue;
			}

			printf("[%u] EMMC ERR in IRQ HANDLER mem:0x%X, emmc offset:0x%llX, size:0x%X\n",retry_count,emmc_irq.buffer, emmc_irq.address, emmc_irq.size);

			if (emmc_irq.rw == EMMC_READ_IRQ)
				result = read_emmc_adma(host,emmc_irq.buffer, emmc_irq.size, emmc_irq.address);
			else
				result = write_emmc_adma(host,emmc_irq.buffer, emmc_irq.size, emmc_irq.address);
			if (result)
				continue;

			result = emmc_int_check(host);
			if (result)
				continue;

			if (result == 0)
			{
				status = MMC_DATA_COMPLETE;
				break;
			}
		}
		host->irq_enable = 1;
	}
#endif
	if (emmc_irq.states == EMMC_DEFAULT)
	{
		interrupt_active(IRQ_SDHC);
		return;
	}

	emmc_irq.error = status & 0xFFFF0000;

 	if (emmc_irq.states == EMMC_BLOCK_TRANSFER)
	{
		if (status & MMC_DATA_COMPLETE)
		{

			emmc_irq.currentsize += emmc_irq.size;
			if (emmc_irq.currentsize >= emmc_irq.totalsize)
			{
				/*
					EMMC TRASNFER (READ or WRITE) COMPLETE
				*/
				emmc_irq.complete = 1;
			}
			else
			{
				emmc_irq.buffer += emmc_irq.size;
				emmc_irq.address += emmc_irq.size;

				if ((emmc_irq.totalsize - emmc_irq.currentsize) < MMC_CHUNKSIZE_MAX)
				{
					emmc_irq.size = emmc_irq.totalsize - emmc_irq.currentsize;
				}
				else
				{
					emmc_irq.size = MMC_CHUNKSIZE_MAX;
				}

				emmc_irq.states = EMMC_BLOCK_TRANSFER;

				if (emmc_irq.rw == EMMC_READ_IRQ)
				{
					ret = read_emmc_adma(host, emmc_irq.buffer, emmc_irq.size, emmc_irq.address);
				}
				else
				{
					ret = write_emmc_adma(host, emmc_irq.buffer, emmc_irq.size, emmc_irq.address);
				}
			}
		}
	}

	if (ret)
	{
		emmc_irq.error += (ret << 24);
	}

	if(irq_callback.handler)
	{
		if(emmc_irq.complete == 1)
		{
			irq_callback.handler(irq_callback.arg, 0);
		}
		else if(emmc_irq.error & 0xFFFF0000)
		{
			irq_callback.handler(irq_callback.arg, emmc_irq.error >> 16);
		}
	}

	interrupt_active(IRQ_SDHC);
}

static int emmc_interrupt_init(struct mmc_host *host)
{
	if (!emmc_interrupt_inited)
	{
		interrupt_request(IRQ_SDHC, emmc_interrupt_handler, host);
		emmc_interrupt_inited = 1;
	}
	interrupt_deactive(IRQ_SDHC);

	return 0;
}
#else	// #if USE_EMMC_IRQ
static unsigned int init_retry(struct mmc_host *host)
{
	unsigned int ret;

	emmc_delay(100000);

	ret = init_emmc(host, EMMC_MAXSPEED_INIT);

	return ret;
}

static unsigned int read_emmc(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	unsigned int resCMD = 0;
	unsigned int resCHECK = 0;
	unsigned int i;

	for (i=0; i<host->max_retry; i++)
	{
		if (i > 0)
		{
			printf("[%u] EMMC READ RETRY mem:0x%X, emmc offset:0x%llX, size:0x%X\n", i, buffer, address, size);
			if (init_retry(host))
				continue;
		}

		resCHECK = 0;
		resCMD = read_emmc_adma(host, buffer, size, address);
		if (resCMD)
		{
			EMMC_ERROR_PRINT("EMMC READ CMD SEND ERROR\n");
		}
		else
		{
			resCHECK = emmc_int_check(host);
			if (resCHECK)
				EMMC_ERROR_PRINT("EMMC READ CMD CHECK ERROR\n");
			else
				break;
		}
	}

	return resCMD + resCHECK;
}

static unsigned int write_emmc(struct mmc_host *host, unsigned int buffer, unsigned int size, unsigned long long address)
{
	unsigned int resCMD = 0;
	unsigned int resCHECK = 0;
	unsigned int i;

	for (i=0; i<host->max_retry; i++)
	{
		if (i > 0)
		{
			printf("[%u] EMMC WRITE RETRY mem:0x%X, emmc offset:0x%llX, size:0x%X\n", i, buffer, address, size);
			if (init_retry(host))
				continue;

		}
		resCHECK = 0;
		resCMD = write_emmc_adma(host, buffer, size, address);
		if (resCMD)
		{
			EMMC_ERROR_PRINT("EMMC WRITE CMD SEND ERROR\n");
		}
		else
		{
			resCHECK = emmc_int_check(host);
			if (resCHECK)
				EMMC_ERROR_PRINT("EMMC WRITE CMD CHECK ERROR\n");
			else
				break;
		}
	}

	emmc_cache_flush(host);

	return resCMD + resCHECK;
}
#endif

static unsigned int erase_emmc(struct mmc_host *host, unsigned long long address, unsigned long long size)
{
	unsigned int start;
	unsigned int end;
	unsigned short BlockSize = MMC_SECTOR_SIZE;
	unsigned int result;
	struct mmc_cmd mmc;

	if (size & (BlockSize - 1))
	{
		EMMC_DEBUG_PRINT("512");
		return EMMC_ERROR_UNITSIZE_FALSE;
	}

	if (host->card.address_mode == EMMC_SECTOR_MODE)
	{
		start = (unsigned int)(address / MMC_SECTOR_SIZE);
		end = start + (size / MMC_SECTOR_SIZE) - 1;
	}
	else
	{
		start = (unsigned int)address;
		end = start + size - 1;
	}

	EMMC_DEBUG_PRINT("EMMC ERASE start = %llx, end = %llx\n",address, address + size);

	mmc.cmd = EMMC_CMD35_ERASE_SRART;
	mmc.flag = MMC_RESP_R1;
	mmc.opr = 0x00;
	mmc.arg = start;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD35 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD35 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	mmc.cmd = EMMC_CMD36_ERASE_END;
	mmc.flag = MMC_RESP_R1;
	mmc.opr = 0x00;
	mmc.arg = end;
	mmc.done_check = MMC_FLAG_COMMAND_ONLY;
	mmc.ack = 0;
	mmc.timeout_ms = 1000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD36 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD36 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	mmc.cmd = EMMC_CMD38_ERASE_DO;
	mmc.flag = MMC_RESP_R1B;
	mmc.opr = 0x00;

	if (emmc_get_trim_enable(host) == TRUE)
		mmc.arg = 0x00000001;
	else
		mmc.arg = 0x00000000;
	mmc.done_check = MMC_FLAG_DATA;
	mmc.ack = 0;
	mmc.timeout_ms = 15000;
	mmc.err = 0;

	result = emmc_send_cmd(host,&mmc);;
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD38 SEND ERROR\n");
		return EMMC_FAIL;
	}

	result = emmc_int_check(host);
	if (result)
	{
		EMMC_ERROR_PRINT("EMMC CMD38 CHECK ERROR\n");
		return EMMC_FAIL;
	}

	return 0;
}

int emmc_get_smartreport(struct mmc_host *host, unsigned char *buff)
{
	struct mmc_cmd mmc;
	unsigned int result;
	int ret = 0;

	if (host->card.cid.manfid == VENDOR_HYNIX)
	{
		mmc.cmd = 60;
		mmc.flag = MMC_RESP_R1B | MMC_CMD_AC;
		mmc.opr = 0;
		mmc.arg = 0x534D4900;
		mmc.done_check = MMC_FLAG_COMMAND_ONLY;
		mmc.ack = 0;
		mmc.timeout_ms = 1000;
		mmc.err = 0;

		result = emmc_send_cmd(host,&mmc);;
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_send_status(host, mmc.arg);
		if (result)
		{
			ret = -1;
			goto end;
		}

		mmc.cmd = 60;
		mmc.flag = MMC_RESP_R1B | MMC_CMD_AC;
		mmc.opr = 0;
		mmc.arg = 0x48525054;
		mmc.done_check = MMC_FLAG_COMMAND_ONLY;
		mmc.ack = 0;
		mmc.timeout_ms = 1000;
		mmc.err = 0;

		result = emmc_send_cmd(host,&mmc);;
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_send_status(host, mmc.arg);
		if (result)
		{
			ret = -1;
			goto end;
		}

		mmc.cmd = EMMC_CMD8_SEND_EXT_CSD;
		mmc.flag = MMC_RESP_R1 | RSP_DATA_PRESENT;
		mmc.opr = 0x11;
		mmc.arg = 0x00000000;
		mmc.done_check = MMC_FLAG_DATA;
		mmc.ack = 0;
		mmc.timeout_ms = 1000;
		mmc.err = 0;

		host->mmc_adma_list[0].address = (unsigned int)((unsigned long)buff);
		host->mmc_adma_list[0].size = 512;
		host->mmc_adma_list[0].flag = 0x23;

		SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(unsigned int)((unsigned long)host->mmc_adma_list));
		SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(1 << 16) + 512);

		result = emmc_send_cmd(host,&mmc);;
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC CMD8 SEND ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC CMD8 CHECK ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_send_status(host, mmc.arg);
		if (result)
		{
			ret = -1;
			goto end;
		}
	}
	else if (host->card.cid.manfid == VENDOR_TOSHIBA)
	{
		buff[0] = 0x07;
		buff[4] = 0x6E;
		buff[5] = 0x2D;
		buff[6] = 0x66;
		buff[7] = 0xE0;

		mmc.cmd = 56;
		mmc.flag = MMC_RESP_R1B | MMC_CMD_AC | MMC_CMD_ADTC;
		mmc.opr = (1 << EMMC_CMD_DMA_ENABLE)+(1 << EMMC_CMD_BLOCK_COUNT_ENABLE);
 		mmc.arg = 0;
		mmc.done_check = MMC_FLAG_DATA;
		mmc.ack = 0;
		mmc.timeout_ms = 1000;
		mmc.err = 0;

		host->mmc_adma_list[0].address = (unsigned int)((unsigned long)buff);
		host->mmc_adma_list[0].size = 512;
		host->mmc_adma_list[0].flag = 0x23;
		SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(unsigned int)((unsigned long)host->mmc_adma_list));
		SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(1 << 16) + 512);

		result = emmc_send_cmd(host,&mmc);;
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_send_status(host, mmc.arg);
		if (result)
		{
			ret = -1;
			goto end;
		}

		mmc.cmd = 56;
		mmc.flag = MMC_RESP_R1B | MMC_CMD_AC | MMC_CMD_ADTC;
		mmc.opr = (1 << EMMC_CMD_DMA_ENABLE)+(1 << EMMC_CMD_BLOCK_COUNT_ENABLE) + (1 << EMMC_CMD_DATA_DIRECTION);
		mmc.arg = 1;
		mmc.done_check = MMC_FLAG_DATA;
		mmc.ack = 0;
		mmc.timeout_ms = 1000;
		mmc.err = 0;

		host->mmc_adma_list[0].address = (unsigned int)((unsigned long)buff);
		host->mmc_adma_list[0].size = 512;
		host->mmc_adma_list[0].flag = 0x23;
		SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(unsigned int)((unsigned long)host->mmc_adma_list));
		SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(1 << 16) + 512);

		result = emmc_send_cmd(host,&mmc);;
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC RD CMD56 SEND ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC RD CMD56 CHECK ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_send_status(host, mmc.arg);
		if (result)
		{
			ret = -1;
			goto end;
		}

	}
	else if (host->card.cid.manfid == VENDOR_SAMSUNG)
	{
#if 0
		{
			mmc.cmd = 62;
			mmc.flag = MMC_RESP_R1B | MMC_CMD_AC;
			mmc.opr = 0;
			mmc.arg = 0xEFAC62EC;
			mmc.done_check = MMC_FLAG_COMMAND_ONLY;
			mmc.ack = 0;
			mmc.timeout_ms = 1000;
			mmc.err = 0;

			result = emmc_send_cmd(host,&mmc);;
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_int_check(host);
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_send_status(host, mmc.arg);
			if (result)
			{
				ret = -1;
				goto end;
			}

			mmc.cmd = 62;
			mmc.flag = MMC_RESP_R1B | MMC_CMD_AC;
			mmc.opr = 0;
			mmc.arg = 0xCCEE;
			mmc.done_check = MMC_FLAG_COMMAND_ONLY;
			mmc.ack = 0;
			mmc.timeout_ms = 1000;
			mmc.err = 0;

			result = emmc_send_cmd(host,&mmc);;
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_int_check(host);
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_send_status(host, mmc.arg);
			if (result)
			{
				ret = -1;
				goto end;
			}

			// READ SINGLE DATA
			mmc.cmd = 17;
			mmc.flag = MMC_RESP_R1 | RSP_DATA_PRESENT;
			mmc.opr = (1 << EMMC_CMD_DMA_ENABLE);
			mmc.arg = 0;
			mmc.done_check = MMC_FLAG_DATA;
			mmc.ack = 0;
			mmc.timeout_ms = 1000;
			mmc.err = 0;

			host->mmc_adma_list[0].address = (unsigned int)((unsigned long)buff);
			host->mmc_adma_list[0].size = 512;
			host->mmc_adma_list[0].flag = 0x23;
			SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(unsigned int)((unsigned long)host->mmc_adma_list));
			SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(1 << 16) + 512);

			result = emmc_send_cmd(host,&mmc);;
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC RD CMD56 SEND ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_int_check(host);
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC RD CMD56 CHECK ERROR\n");
				ret = -1;
				goto end;
			}

			mmc.cmd = 62;
			mmc.flag = MMC_RESP_R1B | MMC_CMD_AC;
			mmc.opr = 0;
			mmc.arg = 0xEFAC62EC;
			mmc.done_check = MMC_FLAG_COMMAND_ONLY;
			mmc.ack = 0;
			mmc.timeout_ms = 1000;
			mmc.err = 0;

			result = emmc_send_cmd(host,&mmc);;
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_int_check(host);
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_send_status(host, mmc.arg);
			if (result)
			{
				ret = -1;
				goto end;
			}

			mmc.cmd = 62;
			mmc.flag = MMC_RESP_R1B | MMC_CMD_AC;
			mmc.opr = 0;
			mmc.arg = 0xDECCEE;
			mmc.done_check = MMC_FLAG_COMMAND_ONLY;
			mmc.ack = 0;
			mmc.timeout_ms = 1000;
			mmc.err = 0;

			result = emmc_send_cmd(host,&mmc);;
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
				return -1;
			}

			result = emmc_int_check(host);
			if (result)
			{
				EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
				ret = -1;
				goto end;
			}

			result = emmc_send_status(host, mmc.arg);
			if (result)
			{
				ret = -1;
				goto end;
			}
		}
#endif
	}
	else if ((host->card.cid.manfid == VENDOR_MICRON) || (host->card.cid.manfid == VENDOR_MICRON_2))
	{
#define MICRON_TOTAL 0x10
#define MICRON_MLC 0x11
#define MICRON_SLC 0x12

		mmc.cmd = 56;
		mmc.flag = MMC_RESP_R1B | MMC_CMD_AC | MMC_CMD_ADTC;
		mmc.opr = (1 << EMMC_CMD_DMA_ENABLE)+(1 << EMMC_CMD_BLOCK_COUNT_ENABLE);
		mmc.arg = 0x1 + (MICRON_MLC << 1);
		mmc.done_check = MMC_FLAG_DATA;
		mmc.ack = 0;
		mmc.timeout_ms = 1000;
		mmc.err = 0;

		host->mmc_adma_list[0].address = (unsigned int)((unsigned long)buff);
		host->mmc_adma_list[0].size = 512;
		host->mmc_adma_list[0].flag = 0x23;
		SDMMC_REG_WRITE(host,EMMC_ADMA_ADDRESS,(unsigned int)((unsigned long)host->mmc_adma_list));
		SDMMC_REG_WRITE(host,EMMC_BLOCK_COUNT,(1 << 16) + 512);

		result = emmc_send_cmd(host,&mmc);;
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 SEND ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_int_check(host);
		if (result)
		{
			EMMC_ERROR_PRINT("EMMC WR CMD56 CHECK ERROR\n");
			ret = -1;
			goto end;
		}

		result = emmc_send_status(host, mmc.arg);
		if (result)
		{
			ret = -1;
			goto end;
		}
	}


end:
	return ret;
}

static int arasan_emmc_init(struct emmc_info* emmc)
{
	struct mmc_host *host;
	unsigned int i;
	unsigned int ret = 0;

#define EMMC_INIT_RETRY 3

	if (!arasan_emmc_inited)
	{
		memset(&emmc_host, 0x0, sizeof(struct mmc_host));

		if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
		{
			emmc_host.strb90 = 0;
			emmc_host.strb180 = 0;
		}
		else
		{
			emmc_host.strb90 = STRB90_DONT_SET;
			emmc_host.strb180 = STRB180_DONT_SET;
		}
		arasan_emmc_inited = 1;
	}

	host = &emmc_host;
	host->max_retry = EMMC_MAX_RETRY;

	if (host->inited == 0)
	{
		emmc_set_baseaddress(host,EMMC_BASE_ADDRESS);
#if defined(CONFIG_BOARD_TYPE_FPGA)
		host->base_clock = 5000000;
		host->max_clock = 5000000;
#else
		host->base_clock = EMMC_HOST_MAX;
		host->max_clock = EMMC_HOST_MAX;
#endif

#if USE_EMMC_IRQ
		memset(&emmc_irq, 0x0, sizeof(struct emmc_irq_struct));

		emmc_interrupt_init(host);
		interrupt_active(IRQ_SDHC);
		host->irq_enable = 1;
#endif
		emmc_ver_check(host);
	}

	for (i=0; i<EMMC_INIT_RETRY; i++)
	{
		ret = init_emmc(host, EMMC_MAXSPEED_INIT);
		if (ret	== 0)
			break;
	}

	if (ret != 0)
		return -1;

	emmc->chip_size = (u64)emmc_get_sector_count(host) * 512;
	emmc->max_block_size = MMC_CHUNKSIZE_MAX;
	emmc->sector_size = MMC_SECTOR_SIZE;
	sprintf(emmc->product_name, "%.5s", host->card.cid.prod_name);

	return 0;
}

static int arasan_emmc_read(loff_t offset, size_t len, void* buf)
{
	struct mmc_host *host;
	unsigned int result;

	host = &emmc_host;
#if USE_EMMC_IRQ
	unsigned int timeout_time;

	result = read_emmc_irq(host, (unsigned int)((unsigned long)buf), len, offset);
	if (result)
		return result;

	timeout_time = ((len / (1024*1024))+1) * 5000;
	result = wait_emmc_transfer_irq(host, timeout_time);

	return result;
#else
	result = read_emmc(host, (unsigned int)((unsigned long)buf), len, offset);
	return result;
#endif
}

#if USE_EMMC_IRQ
static int arasan_emmc_dma_read_start(loff_t offset, size_t len, void* buf, emmc_irq_callback_t* callback)
{
	struct mmc_host *host;
	host = &emmc_host;

	if(read_emmc_irq(host, (unsigned int)((unsigned long)buf), len, offset) != 0)
		return -1;

	if(callback)
	{
		irq_callback.handler = callback->handler;
		irq_callback.arg = callback->arg;
	}
	return 0;
}

static int arasan_emmc_dma_read_stop(void)
{
	irq_callback.handler = NULL;
	return 0;
}
#endif


static int arasan_emmc_write(loff_t offset, size_t len, const void* buf)
{
	struct mmc_host *host;
	host = &emmc_host;

#if USE_EMMC_IRQ
	unsigned int result;
	unsigned int timeout_time;

	if(write_emmc_irq(host, (unsigned int)((unsigned long)buf), len, offset) != 0)
		return -1;

	timeout_time = ((len / (1024*1024))+1) * 5000;
	result = wait_emmc_transfer_irq(host, timeout_time);
	if (result < 0)
		return result;

	result = emmc_cache_flush(host);
	if (result)
		return -1;

	return 0;
#else
	if(write_emmc(host, (unsigned int)((unsigned long)buf), len, offset) != 0)
		return -1;

	return 0;
#endif
}

static int  arasan_emmc_zero_write(struct mmc_host *host, loff_t offset, u64 len)
{
#define ZW_SIZE 524288
	char *erase_buf;
	unsigned int count;
	unsigned int mod;
	unsigned int i = 0;

	erase_buf = (char *)dma_malloc(ZW_SIZE);
	memset(erase_buf,0x0,ZW_SIZE);

	count = len / ZW_SIZE;
	mod = len & (ZW_SIZE - 1);

	if (count)
	{
		for (i=0; i<count; i++)
		{
			if(arasan_emmc_write(offset + (i * ZW_SIZE), ZW_SIZE, erase_buf) != 0)
			{
				dma_free(erase_buf);
				return -1;
			}
		}
	}

	if (mod)
	{
		if(arasan_emmc_write(offset + (i * ZW_SIZE), mod, erase_buf) != 0)
		{
			dma_free(erase_buf);
			return -1;
		}
	}


	dma_free(erase_buf);

	return 0;
}

static int arasan_emmc_erase_ext(struct mmc_host *host, loff_t offset, u64 len)
{
	unsigned int unit_size;
	unsigned int i=0;
	unsigned int count;
	unsigned int erase_size;
	unsigned int erase_mod_size;
	unsigned int erase_unit_size;
	u64 erase_add_align;
	unsigned int erase_add_size;

	erase_unit_size = emmc_get_erase_size(host);

	erase_add_align = offset & ((loff_t)erase_unit_size - 1);
	if (erase_add_align)
	{
		erase_add_size = erase_unit_size - (unsigned int)(erase_add_align);
		arasan_emmc_zero_write(host, offset,erase_add_size);
	}

	unit_size = erase_unit_size * 64;
	if (unit_size > 0x4000000)
		unit_size = 0x4000000; // MAX 64M;

	/* get erase loop count */
	count = len / unit_size;
	if (len & (unit_size - 1))
	{
		count++;
	}
	/* erase per unit size */
	if (count > 1)
	{
		for (i=0; i<(count-1); i++)
		{
			if(erase_emmc(host, offset + (i*unit_size), unit_size) != 0)
				return -1;
		}
	}
	erase_size = len - (i*unit_size);

	if (emmc_get_trim_enable(host) == TRUE)
	{
		/* erase last */
		if(erase_emmc(host, offset + (i*unit_size), erase_size) != 0)
			return -1;
	}
	else
	{
		erase_mod_size = erase_size & (erase_unit_size - 1);

		if (erase_size >= erase_unit_size)
		{
			if(erase_emmc(host, offset + (i*unit_size), erase_size - erase_mod_size) != 0)
				return -1;
		}

		if (erase_mod_size)
		{
			arasan_emmc_zero_write(host, offset + (i*unit_size) + erase_size - erase_mod_size, erase_mod_size);
		}
	}

	return 0;
}

static int arasan_emmc_erase(loff_t offset, u64 len)
{
	u64		max_len    = 0x40000000;
	u64		tmp_len    = len;
	loff_t	tmp_offset = offset;
	int		rc;

	struct mmc_host *host;
	host = &emmc_host;

	while (1)
	{
		if (tmp_len <= max_len)
		{
			return arasan_emmc_erase_ext(host, tmp_offset, tmp_len);
		}

		if( (rc = arasan_emmc_erase_ext(host, tmp_offset, max_len)) < 0)
			return rc;
		tmp_len    -= max_len;
		tmp_offset += max_len;
	}

	return rc;
}

#ifdef FIRST_BOOT
static void search_tabvalue(struct mmc_host *host, unsigned int arg)
{
	host = host;
	arg = arg;
}
static void search_strbvalue(struct mmc_host *host, unsigned int arg)
{
	host = host;
	arg = arg;
}

#else

static unsigned char intab_array[128][128];
static unsigned char outtab_array[128][128];
static unsigned char compare_array[128][128];
static void view_tabvalue(struct mmc_host *host)
{
	unsigned int i,o,h,v;
	unsigned int imax=32,omax=16,h_max=32,v_max=16;

	if(host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		imax = 32;
		omax = 16;
	}
	else if(host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		imax = 64;
		omax = 16;
	}
	else if(host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		imax = 40;
		omax = 16;
	}

	h_max = imax;
	v_max = omax;

	printf("\n");

	if (searchtabviewmode & 1)
	{

		printf("[READ RESULT]\n");
			printf("horizontal axis is INTAB delay value (0 ~ %u)\n",h_max);
			printf("vertial axis is OUTTAB delay value (0 ~ %u)\n",v_max);

		printf("     "); // space x 5
		for (h=0; h<h_max; h++)
			printf("%2u ",h);
		printf("\n");

		for (h=0; h<(h_max + 3); h++)
			printf("---");
		printf("\n");

		for (v=0; v<v_max; v++)
		{
			printf("%2u : ",v);

			for (h=0; h<h_max; h++)
			{
				if (intab_array[h][v] == 1)
					printf(" R ");
				else
					printf(" . ");
			}

			printf("\n");
		}
		printf("\n");
	}

	if (searchtabviewmode & 2)
	{
		printf("[WRITE RESULT]\n");
		printf("horizontal axis is INTAB delay value (0 ~ %u)\n",h_max);
		printf("vertial axis is OUTTAB delay value (0 ~ %u)\n",v_max);

		printf("     "); // space x 5
		for (h=0; h<h_max; h++)
			printf("%2u ",h);
		printf("\n");

		for (h=0; h<(h_max + 3); h++)
			printf("---");
		printf("\n");

		for (v=0; v<v_max; v++)
		{
			printf("%2u : ",v);

			for (h=0; h<h_max; h++)
			{
				if (outtab_array[h][v] == 1)
					printf(" W ");
				else
					printf(" . ");
			}
			printf("\n");
		}
	}

	printf("\n");

	if ((searchtabviewmode & 3) == 3)
	{
		printf("[r/w COMPARE]\n");
		printf("horizontal axis is INTAB delay value (0 ~ %u)\n",omax);
		printf("vertial axis is OUTTAB delay value (0 ~ %u)\n",imax);

		printf("     "); // sapce x 5
		for (h=0; h<h_max; h++)
			printf("%2u ",h);
		printf("\n");

		for (h=0; h<(h_max+2); h++)
			printf("---");
		printf("\n");


		// r/w success compare
		for (v=0; v<v_max; v++)
		{
			for (h=0; h<h_max; h++)
			{
				i = h;
				o = v;

				if (intab_array[i][o] == outtab_array[i][o])
				{
					if (intab_array[i][o] == 1)
					{
						compare_array[i][o] = 0x1;
					}
					else
						compare_array[i][o] = 0x0;
				}
				else
					compare_array[i][o] = 0x0;
			}

			printf("%2u : ",v);
			for (h=0; h<h_max; h++)
			{
				i = h;
				o = v;

				if (compare_array[i][o] == 1)
					printf(" O ");
				else
					printf(" . ");
			}
			printf("\n");

		}
	}
}

static unsigned char strb_array[4][4];
static void view_strbvalue(struct mmc_host *host)
{
	unsigned int strb90,strb180;
	unsigned int strb90_max=4,strb180_max=4;

	if(host->ver != EMMC_HOST_CONTROLLER_VER3)
		return;
	printf("===============================================\n");
	printf("\n");
	printf("\n");
	printf("             strb90\n"); // sapce x 5
	printf("          "); // sapce x 5
	for (strb90=0; strb90<strb90_max; strb90++)
		printf("%2u ",strb90);
	printf("\n");

	for (strb90=0; strb90<(4+10); strb90++)
		printf("---");
	printf("\n");


	// r/w success compare
	for (strb180=0; strb180<strb180_max; strb180++)
	{
		printf("%2u : ",strb180);
		for (strb90=0; strb90<strb90_max; strb90++)
		{
			if (strb_array[strb90][strb180] == 0xff)
				printf(" O ");
			else
				printf(" . ");
		}
		printf("\n");

	}
	printf("strb180\n");
	printf("\n");
	printf("\n");

	}

static int strb_compare_data(char *src, char *dst, unsigned int size)
	{
	unsigned int i = 0;

	for (i=0; i<size; i++)
		{
		if (src[i] != dst[i])
			return 1;
		}

	return 0;
}

static void search_strbvalue(struct mmc_host *host, unsigned int arg)
{
	char 		*emmc_test_buf_read;
	char 		*emmc_test_buf_write;
	unsigned int test_start = 0;
	int			key;
	unsigned int test_size = 128 * 1024;
	unsigned int strb_90, strb_180;
	unsigned int backup90, backup180;
	unsigned int i,j;
	unsigned int loop_max = 2000;

#define PARTINFO_START				0x100000

	if (arg == 0x40)
	{
		view_strbvalue(host);
		return;
	}

	storage_partition_t partition_hib;
	storage_partition_t partition_data;
	if(storage_get_partition("hib", &partition_hib) < 0)
	{
		if(storage_get_partition("data", &partition_data) < 0)
		{
			printf("If you proceed with the test, all emmc will be erased.\n");
			printf("Do you want continue this test?\n");
			printf("----------\n");
			printf("y or n\n");
			key = getchar();
			if ((key != 'y') && (key != 'Y'))
				return;

			test_start = PARTINFO_START;
		}
		else
		{
			printf("If you proceed with the test, \"data\" partition will be erased.\n");
			printf("Do you want continue this test?\n");
			printf("----------\n");
			printf("y or n\n");
			key = getchar();
			if ((key != 'y') && (key != 'Y'))
				return;

			test_start = partition_data.offset;
		}
	}
	else
	{
		printf("If you proceed with the test, \"hib\" partition will be erased.\n");
		printf("Do you want continue this test?\n");
		printf("----------\n");
		printf("y or n\n");
		key = getchar();
		if ((key != 'y') && (key != 'Y'))
			return;

		test_start = partition_hib.offset;
	}

	host->noprint = 1;	// error print disable
	host->max_retry = 0;

	if(host->ver != EMMC_HOST_CONTROLLER_VER3)
	{
		return;
	}

	emmc_test_buf_write = (char *)DATA_BUF_BASE;
	emmc_test_buf_read = (char *)DATA_BUF_BASE + 0x100000;

	memset(strb_array,0xff,sizeof(strb_array));

	backup180 = host->strb180;
	backup90 = host->strb90;
	host->strb180 = STRB180_DONT_SET;
	host->strb90 = STRB90_DONT_SET;

	for (strb_90=0; strb_90<4; strb_90++)
	{
		for (strb_180=0; strb_180<4; strb_180++)
	{
			printf("EMMC STRB90 %u STRB180 %u\n",strb_90, strb_180);
			emmc_set_strb90(strb_90);
			emmc_set_strb180(strb_180);
			init_emmc(host, 0);

			for (j=0; j<test_size; j++)
				emmc_test_buf_write[j] = rand_num(0xff);

			for (i=0; i<loop_max; i++)
			{
				if(get_ctrl_c())
				{
					printf("\nInterrupted by ctrl + c\n");
					goto result_print;
				}

				printf("LOOP %u/%u\r",i+1,loop_max);
				emmc_write(test_start + (i*test_size), test_size, (void*)emmc_test_buf_write);

				memset(emmc_test_buf_read, 0x0, test_size);
				emmc_read(test_start + (i*test_size), test_size, (void*)emmc_test_buf_read);

				if (strb_compare_data(emmc_test_buf_write, emmc_test_buf_read, test_size))
				{
						strb_array[strb_90][strb_180] = 0x0;
					break;
				}
				}
			}
		}

		printf("\n");

result_print:
	host->strb180 = backup180;
	host->strb90 = backup90;
	host->userclock = 0;
	view_strbvalue(host);

	host->noprint = 0;
	host->max_retry = EMMC_MAX_RETRY;

	init_emmc(host, 0);
}

static void search_tabvalue(struct mmc_host *host, unsigned int arg)
{
	char* tmode[] = {"[READ TEST] ", "[WRITE TEST] "};

#define	READ_TEST		0
#define	WRITE_TEST		1

	unsigned int loop;
	unsigned int phase;
	unsigned int phase_start = 0;
	unsigned int phase_max = 0;
	unsigned int i, istart =0, imax = 0;
	unsigned int o, ostart =0, omax = 16;
	int			key;
	int 		result;
	unsigned int user_break = 0;
	unsigned int test_count = 0;
	unsigned int base_address_w;
	unsigned int base_address_r;
	unsigned char *test_buff_w;
	unsigned char *test_buff_r;
#define	ARG_TUNE_NONE		0x00
#define	ARG_TUNE_READ		0x01
#define	ARG_TUNE_WRITE		0x02
#define	ARG_TUNE_RW			(ARG_TUNE_READ | ARG_TUNE_WRITE)
#define	ARG_FIX_IN			0x04
#define	ARG_FIX_OUT			0x08
#define	ARG_STRBALL			0x10
#define	ARG_DLLALL			0x100
#define	ARG_TRMALL			0x200
#define	ARG_NOPRINT			0x80
#define	ARG_LOOPMASK		0xFF0000

#define TEST_BUFFER_NORMAL_SIZE	0x40000
#define TEST_BUFFER_NORMAL_LOOP	1
#define PARTINFO_START				0x100000
	unsigned int test_size = 0;
	unsigned int test_loop = 0;
	unsigned int test_start = 0;
	unsigned int strb = 0;
	unsigned int strb_loop = 1;

	unsigned int trm = 0;
	unsigned int trm_loop = 1;

	unsigned int dll = 0;
	unsigned int dll_loop = 1;

#define	EMMC_HS50 	1
#define EMMC_DDR50	2
#define EMMC_HS200	3
#define EMMC_HS400	4

	unsigned int emmc_tune_mode = 0;

	unsigned int speedmode = 0;

	if (arg == 0x40)
	{
		view_tabvalue(host);
		return;
	}

	if ((arg & 3) == ARG_TUNE_NONE)
	{
		return;
	}
	else if ((arg & 3) == ARG_TUNE_READ)
	{
		printf("READ TEST ONLY\n");
		phase_start = 0;
		phase_max = 1;
		searchtabviewmode = 1;
	}
	else if ((arg & 3) == ARG_TUNE_WRITE)
	{
		printf("WRITE TEST ONLY\n");
		phase_start = 1;
		phase_max = 2;
		searchtabviewmode = 2;
	}
	else if ((arg & 3) == ARG_TUNE_RW)
	{
		phase_start = 0;
		phase_max = 2;
		searchtabviewmode = 3;
	}

	storage_partition_t partition_hib;
	storage_partition_t partition_data;
	if(storage_get_partition("hib", &partition_hib) < 0)
	{
		if(storage_get_partition("data", &partition_data) < 0)
		{
			printf("If you proceed with the test, all emmc will be erased.\n");
			printf("Do you want continue this test?\n");
			printf("----------\n");
			printf("y or n\n");
			key = getchar();
			if ((key != 'y') && (key != 'Y'))
				return;

			test_start = PARTINFO_START;
		}
		else
		{
			printf("If you proceed with the test, \"data\" partition will be erased.\n");
			printf("Do you want continue this test?\n");
			printf("----------\n");
			printf("y or n\n");
			key = getchar();
			if ((key != 'y') && (key != 'Y'))
				return;

			test_start = partition_data.offset;
		}
	}
	else
	{
		printf("If you proceed with the test, \"hib\" partition will be erased.\n");
		printf("Do you want continue this test?\n");
		printf("----------\n");
		printf("y or n\n");
		key = getchar();
		if ((key != 'y') && (key != 'Y'))
			return;

		test_start = partition_hib.offset;
	}

	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		if (arg & ARG_STRBALL)
			strb_loop = 16;
	}
	test_size = TEST_BUFFER_NORMAL_SIZE;;
	test_loop = TEST_BUFFER_NORMAL_LOOP;

	speedmode = (arg >> 13) & 0x7;

	if (arg & 0x80)
		host->noprint = 0;	// error print enable
	else
		host->noprint = 1;	// error print disable

	host->max_retry = 0;

	memset(intab_array,0x0,sizeof(intab_array));
	memset(outtab_array,0x0,sizeof(outtab_array));
	memset(compare_array,0x0,sizeof(compare_array));

	if(host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		imax = 32;
	}
	else if(host->ver == EMMC_HOST_CONTROLLER_VER2)
	{
		imax = 64;
	}
	else if(host->ver == EMMC_HOST_CONTROLLER_VER1)
	{
		imax = 40;
	}
	else
		return;

	if (arg & 0x20)
		host->userclock = ((arg & ARG_LOOPMASK) >> 16) * 1000000;

	if (speedmode == EMMC_SEARCH_MODE_HS50)
		emmc_tune_mode = EMMC_HS50;
	else if (speedmode == EMMC_SEARCH_MODE_DDR50)
		emmc_tune_mode = EMMC_DDR50;
	else if (speedmode == EMMC_SEARCH_MODE_HS200)
		emmc_tune_mode = EMMC_HS200;
	else if (speedmode == EMMC_SEARCH_MODE_HS400)
		emmc_tune_mode = EMMC_HS400;
	else
	{
		if(host->ver == EMMC_HOST_CONTROLLER_VER3)
		{
			if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS400)
				emmc_tune_mode = EMMC_HS400;
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS200)
				emmc_tune_mode = EMMC_HS200;
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_DDR50)
				emmc_tune_mode = EMMC_DDR50;
			else
				emmc_tune_mode = EMMC_HS50;
		}
		else if(host->ver == EMMC_HOST_CONTROLLER_VER2)
		{
			if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS200)
				emmc_tune_mode = EMMC_HS200;
			else if (host->card.ext_csd.card_type & EMMC_SUPPORT_DDR50)
				emmc_tune_mode = EMMC_DDR50;
			else
				emmc_tune_mode = EMMC_HS50;
		}
		else if(host->ver == EMMC_HOST_CONTROLLER_VER1)
		{
			emmc_tune_mode = EMMC_DDR50;
		}
	}

	unsigned int tclock = 0;

	if (emmc_tune_mode == EMMC_HS50)
	{
		printf("HS50 tune mode\n");
		tclock = 50;
	}
	else if (emmc_tune_mode == EMMC_DDR50)
	{
		printf("DDR50 tune mode\n");
		tclock = 50;
	}
	else if (emmc_tune_mode == EMMC_HS200)
	{
		printf("HS200 tune mode\n");
		tclock = 198;
	}
	else if (emmc_tune_mode == EMMC_HS400)
	{
		printf("HS400 tune mode\n");
		tclock = 198;
	}

	if (arg & 0x20)
		tclock = host->userclock/1000000;

	printf("tune target clock %uMhz\n",tclock);


	if(host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		printf("Host Driver Strength %uohm\n",emmc_get_ds());
	}

	if (arg & ARG_FIX_IN)
	{
		istart = (arg >> 24) & 0xFF;
		imax = ((arg >> 24) & 0xFF)+1;
		printf("eMMC tune INTAB axis [%u] fixed\n", istart);
	}
	else if (arg & ARG_FIX_OUT)
	{
		ostart = (arg >> 24) & 0xFF;
		omax =  ((arg >> 24) & 0xFF)+1;
		printf("eMMC tune OUTTAB axis [%u] fixed\n", ostart);
	}

	if (host->ver == EMMC_HOST_CONTROLLER_VER3)
	{
		if (arg & ARG_STRBALL)
		{
			printf("INCLUDE DATA STROBE TEST\n");
		}
		else
		{
			if (host->strb90 != STRB90_DONT_SET)
				printf("DATA STROBE 90 Value : %u\n",host->strb90);
			else
				printf("DATA STROBE 90 Value POR DEFAULT\n");

			if (host->strb180 != STRB180_DONT_SET)
				printf("DATA STROBE 180 Value : %u\n",host->strb180);
			else
				printf("DATA STROBE 180 Value POR DEFAULT\n");
		}

		if (arg & ARG_DLLALL)
		{
			printf("INCLUDE DLL IFF TEST\n");
			dll_loop = 8;
		}
		else
		{
			if (emmc_get_dll_iff(host) != 0xFFFFFFFF)
				printf("DLL IFF value %u\n",emmc_get_dll_iff(host));
		}

		if (arg & ARG_TRMALL)
		{
			printf("INCLUDE TRM ICP TEST\n");
			trm_loop = 16;
		}
		else
		{
			if (emmc_get_trm_icp(host) != 0xFFFFFFFF)
				printf("TRM ICP value %u\n",emmc_get_trm_icp(host));
		}
	}

	printf("prepare eMMC Read tune....\n");
	init_emmc_basic(host);
	test_buff_w = dma_malloc(test_size);
	test_buff_r = dma_malloc(test_size);
	base_address_w = (unsigned int)((unsigned long)test_buff_w);
	base_address_r = (unsigned int)((unsigned long)test_buff_r);

	for (i=0; i<test_size; i++)
		test_buff_w[i] = rand_num(255);

	emmc_set_clock(host, EMMC_25MHZ, EMMC_TIMEOUT_ENABLE);

	result = write_emmc_adma(host, base_address_w, test_size,  test_start);
	if (result)
	{
		printf("EMMC TUNE FAIL - prepare data write cmd fail\n");
		dma_free(test_buff_r);
		dma_free(test_buff_w);
		return;
	}

	host->cmd.timeout_ms = 1000;
	result = emmc_int_check(host);
	if (result)
	{
		printf("EMMC TUNE FAIL - prepare data write check fail\n");
		dma_free(test_buff_r);
		dma_free(test_buff_w);
		return;
	}
	emmc_cache_flush(host);

	emmc_set_usertab(host);

	for (dll=0; dll<dll_loop; dll++)
	{
	for (trm=0; trm<trm_loop; trm++)
	{
	for (strb=0; strb<strb_loop; strb++)
	{
		unsigned int s90, s180;

		s90 = strb & 3;
		s180 = (strb >> 2) & 3;

		if ((strb_loop > 1) || (dll_loop > 1) || (trm_loop > 1))
		{
			printf("---------------------\n");
		}

		if (strb_loop > 1)
		{
			printf("STRB90:%u, STRB180:%u\n",s90, s180);
		}

		if (dll_loop > 1)
		{
			printf("DLL IFF:%u\n",dll);
		}

		if (trm_loop > 1)
		{
			printf("TRM ICP:%u\n",trm);
		}

		for(phase=phase_start; phase<phase_max; phase++)
		{
			test_count = 0;

			for (o=ostart; o<omax; o++)
			{
				for (i=istart; i<imax; i++)
				{
					if(get_ctrl_c())
					{
						printf("\nInterrupted by ctrl + c\n");
						user_break = 1;
						goto result_print;
					}

					test_count++;

					if (host->noprint == 0)
						printf("%s in:%u out:%u\n",tmode[phase],i, o);
					else
						printf("%s %u/%u\r",tmode[phase], test_count, (imax-istart) * (omax-ostart));

					result = init_emmc_basic(host);		// 25Mhz Normal speed mode init
					if (result)
					{
						if (phase == READ_TEST)
							intab_array[i][o] = 0x0;
						else
							outtab_array[i][o] = 0x0;

						continue;
					}

					if (dll_loop > 1)
					{
						emmc_set_dll_iff(host, dll);
					}

					if (trm_loop > 1)
					{
						emmc_set_trm_icp(host, trm);
					}

					if (emmc_tune_mode == EMMC_HS50)
					{
						if (!host->userclock)
							host->userclock = 49500000;
						result = emmc_set_highspeed(host, i, o);
					}
					else if (emmc_tune_mode == EMMC_DDR50)
					{
						if (!host->userclock)
							host->userclock = 49500000;
						emmc_clear_usertab(host);
						result = emmc_set_highspeed(host, 0, 0);
						emmc_set_usertab(host);
						if  (result == 0)
							result = emmc_set_ddr50(host, i, o);
					}
					else if (emmc_tune_mode == EMMC_HS200)
					{
						if (!host->userclock)
							host->userclock = EMMC_HOST_MAX;
						result = emmc_set_hs200(host, i, o);
					}
					else if (emmc_tune_mode == EMMC_HS400)
					{
						if (!host->userclock)
							host->userclock = EMMC_HOST_MAX;

						if (strb_loop == 1)
							result = emmc_set_hs400(host, i, o, host->strb90, host->strb180);
						else
							result = emmc_set_hs400(host, i, o, s90, s180);
					}

					if (result)
					{
						if (phase == READ_TEST)
							intab_array[i][o] = 0x0;
						else
							outtab_array[i][o] = 0x0;

						continue;
					}

					for (loop=0; loop<test_loop; loop++)
					{
						if (phase == READ_TEST)
						{
							memset(test_buff_r,0x0,test_size);
							result = read_emmc_adma(host, base_address_r, test_size,  test_start + (loop * test_size));
							host->cmd.timeout_ms = 500;
						}
						else
						{
							result = write_emmc_adma(host, base_address_w, test_size,  test_start + (loop * test_size));
							host->cmd.timeout_ms = 1000;
						}
						if (result)
							break;

						result = emmc_int_check(host);
						if (result)
							break;

						if (phase == WRITE_TEST)
							emmc_cache_flush(host);
					}

					if (!result)
					{
						if (phase == READ_TEST)
						{
							if (memcmp(test_buff_r, test_buff_w, test_size) == 0)
								intab_array[i][o] = 0x1;
							else
								intab_array[i][o] = 0x0;
						}
						else
							outtab_array[i][o] = 0x1;
					}
					else
					{
						if (phase == READ_TEST)
							intab_array[i][o] = 0x0;
						else
							outtab_array[i][o] = 0x0;
					}
				}
			}
			printf("\n");
		}

result_print:
		host->userclock = 0;
		view_tabvalue(host);
		if (user_break)
			goto search_end;

	}
	}
	}
search_end:
	dma_free(test_buff_r);
	dma_free(test_buff_w);

	emmc_clear_usertab(host);

	host->noprint = 0;
	host->max_retry = EMMC_MAX_RETRY;

	init_emmc(host, 0);
}
#endif

static void arasan_emmc_tabinfo(struct mmc_host *host)
{
#define EMMC_SAMPLED_CLOCK (16+7)

	if (get_ip_tab_enable(host))
		printf("EMMC IN TAB %u\n", get_ip_tab_value(host));
	else
	{
		if (SDMMC_BIT_READ(host, EMMC_CTRL2, EMMC_SAMPLED_CLOCK))
			printf("EMMC IN TAB %u (Using AutoTune)\n", get_auto_ip_tab_value(host));
		else
			printf("EMMC IN TAB DISABLE\n");
	}

	if (get_op_tab_enable(host))
		printf("EMMC OUT TAB %u\n", get_op_tab_value(host));
	else
		printf("EMMC OUT TAB DISABLE\n");
}
static void arasan_emmc_strobeinfo(struct mmc_host *host)
{
	unsigned int reg;
	unsigned int strb90;
	unsigned int strb180;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x28);
		strb90 = (reg & 0x30) >> 4;
		strb180 = (reg & 0xC0) >> 6;

		printf("STRB90:%u, STRB180:%u\n",strb90,strb180);
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)
	{
		reg = SDMMC_TOP_REG_READ(&emmc_host, 0x30);
		strb90 = (reg & 0x3);
		strb180 = (reg & 0xC) >> 2;

		printf("STRB90:%u, STRB180:%u\n",strb90,strb180);
	}
}

static void arasan_emmc_businfo(struct mmc_host *host)
{
	printf("EMMC CLOCK : %u hz (%s)\n",host->clock, host->ddr_mode ? "DDR" : "SDR");

	printf("EMMC BUS WIDTH : %u bit\n",host->bus_width);

}

static void emmc_vendor_info(struct mmc_host *host)
{
	unsigned int ver;
	ver = host->card.cid.manfid;

	printf("EMMC VENDOR ");
	switch (ver)
	{
		case VENDOR_TOSHIBA:
			printf("TOSHIBA\n");
			break;
		case VENDOR_HYNIX:
			printf("HYNIX\n");
			break;
		case VENDOR_SANDISK_1:
		case VENDOR_SANDISK_2:
			printf("SANDISK\n");
			break;
		case VENDOR_SAMSUNG:
			printf("SAMSUNG\n");
			break;
		case VENDOR_MICRON:
		case VENDOR_MICRON_2:
			printf("MICRON\n");
			break;
		default:
			printf("UNKNOWN\n");
			break;
	}
}

static void emmc_ver_info(struct mmc_host *host)
{
	unsigned int ver;
	ver = host->card.ext_csd.ext_csd_rev;

	switch (ver)
	{
		case 0:
			printf("EMMC VERSION 4.0\n");
			break;
		case 1:
			printf("EMMC VERSION 4.1\n");
			break;
		case 2:
			printf("EMMC VERSION 4.2\n");
			break;
		case 3:
			printf("EMMC VERSION 4.3\n");
			break;
		case 5:
			printf("EMMC VERSION 4.41\n");
			break;
		case 6:
			printf("EMMC VERSION 4.5\n");
			break;
		case 7:
			printf("EMMC VERSION 5.0\n");
			break;
		case 8:
			printf("EMMC VERSION 5.1\n");
			break;
		default:
			printf("EMMC VERSION unknown (ext_csd_rev %u)\n",ver);
			break;
	}
}

static int arasan_emmc_ioctl(unsigned int cmd, unsigned int arg)
{
	int ret = 0;
	unsigned int temp;
	unsigned char *buff;
	unsigned long parg;

	struct mmc_host *host;
	host = &emmc_host;

	if (cmd == EMMC_IOCTL_INFO)
	{
		emmc_dump_cid(&host->card.cid);
		emmc_dump_csd(&host->card.csd);
		emmc_dump_ext_csd(&host->card.ext_csd);
		printf("\n");
		emmc_vendor_info(host);
		emmc_ver_info(host);
		temp = emmc_get_sector_count(host) / 2048; // (sector_count * 512) / (1024 * 1024) == sector_count / 2048;
		printf("EMMC SIZE : %u MByte\n",temp);

		temp = emmc_get_erase_size(host);
		printf("EMMC ERASE SIZE : %u Byte\n",temp);

		arasan_emmc_businfo(host);
		arasan_emmc_tabinfo(host);
		arasan_emmc_strobeinfo(host);

		if (host->ver == EMMC_HOST_CONTROLLER_VER3)
			printf("Host Driver Strength %uohm\n",emmc_get_ds());

#if USE_EMMC_IRQ
		printf("USE EMMC IRQ\n");
#endif
		printf("\n");
	}
	else if (cmd == EMMC_IOCTL_INFO_MINI)
	{
		arasan_emmc_businfo(host);
		arasan_emmc_tabinfo(host);
		if (host->ver == EMMC_HOST_CONTROLLER_VER3)
			printf("Host Driver Strength %uohm\n",emmc_get_ds());
#if USE_EMMC_IRQ
		printf("USE EMMC IRQ\n");
#endif
		printf("\n");
	}
	else  if (cmd == EMMC_IOCTL_TAB_TUNE)
	{
		search_tabvalue(host, arg);
	}
	else  if (cmd == EMMC_IOCTL_TAB_STRB)
	{
		if (host->ver == EMMC_HOST_CONTROLLER_VER3)
		{
				search_strbvalue(host, arg);
			}
		else
		{
			printf("This chip don't support data strobe\n");
		}
	}
	else if (cmd == EMMC_IOCTL_SET_TAB)
	{
		if (arg & 0x80)
		{
			emmc_clear_usertab(host);
			emmc_tab_setting(host);

			if (host->ver == EMMC_HOST_CONTROLLER_VER1)
			{
				tab_out_delay_set(host, host->tab_50.out);
				tab_in_delay_set(host, host->tab_50.in);
			}
			else if (host->ver == EMMC_HOST_CONTROLLER_VER2)
			{
				tab_out_delay_set(host, host->tab_200.out);
				tab_in_delay_set(host, host->tab_200.in);
			}
			else if (host->ver == EMMC_HOST_CONTROLLER_VER3)
			{
				tab_out_delay_set(host, host->tab_400.out);
				tab_in_delay_set(host, host->tab_400.in);
			}
			else
			{
				tab_out_delay_set(host, host->tab_400.out);
				tab_in_delay_set(host, host->tab_400.in);
			}

			arasan_emmc_tabinfo(host);
		}
		else
		{
			emmc_set_usertab(host);
			tab_control(host,arg);
		}
	}
	else if (cmd == EMMC_IOCTL_GET_TAB_TO_KERNEL)
	{
		// bitmap
		// out : 4bit
		// in : 6bit
		// 2bit 10bit   10bit   10bit
		//       in  out in out  in  out
		//       HS400 HS200 DDR52

		unsigned int tab;

		tab = (host->tab_50.out) + (host->tab_50.in << 4);
		tab |= ((host->tab_200.out) + (host->tab_200.in << 4)) << 10;
		tab |= ((host->tab_400.out) + (host->tab_400.in << 4)) << 20;

		*(unsigned int*)((unsigned long)arg) = tab;

		ret = 0;
	}
	else if (cmd ==  EMMC_IOCTL_GET_SMARTREPORT)
	{
		parg = (unsigned long)arg;
		buff = (unsigned char*)parg;
		ret = emmc_get_smartreport(host, buff);
	}
	else if (cmd == EMMC_IOCTL_INIT)
	{
		struct mmc_host *host;

		host = &emmc_host;

		host->usermode = arg & 0xFF;
		host->userclock = ((arg & 0xFFFF00) >> 8) * EMMC_MHZ;
		host->userbus = (arg & 0xFF000000) >> 24;

		ret = init_emmc(host, EMMC_MAXSPEED_INIT);
	}
	else if (cmd == EMMC_IOCTL_TAB_DISABLE)
	{
		// this condition temporary workaround
		if (host->ver == EMMC_HOST_CONTROLLER_VER3)
		{
			ip_tab_dis(host);
			op_tab_dis(host);
		}
	}
	else if (cmd == EMMC_IOCTL_SET_DS)
	{
		// this condition temporary workaround
		if (host->ver == EMMC_HOST_CONTROLLER_VER3)
		{
			switch (arg)
			{
				case 0:
					host->driver_strength = 50;
					break;
				case 1:
					host->driver_strength = 33;
					break;
				case 2:
					host->driver_strength = 66;
					break;
				case 3:
					host->driver_strength = 100;
					break;
				case 4:
					host->driver_strength = 40;
					break;
				case 255:
					host->driver_strength = 0;	// auto
					break;
				default:
					host->driver_strength = 0;	// auto
					break;
			}

			if (arg == 255)
				emmc_set_ds(emmc_vendor_host_ds(host));
			else
				emmc_set_ds(arg);

		}
	}
	else if (cmd == EMMC_IOCTL_SET_PON)
	{
		emmc_set_pon(host, arg);
	}
	else if (cmd == EMMC_IOCTL_GET_MAXCLOCK)
	{
		*(unsigned int*)((unsigned long)arg) = host->max_clock;
	}
	else if (cmd == EMMC_IOCTL_GET_DLL)
	{
		ret = emmc_get_dll_iff(host);
	}
	else if (cmd == EMMC_IOCTL_SET_DLL)
	{
		ret = emmc_set_dll_iff(host,arg);
	}
	else if (cmd == EMMC_IOCTL_GET_TRM)
	{
		ret = emmc_get_trm_icp(host);
	}
	else if (cmd == EMMC_IOCTL_SET_TRM)
	{
		ret = emmc_set_trm_icp(host,arg);
	}
	else if (cmd == EMMC_IOCTL_CHANGE_PART)
	{
		ret = emmc_change_partition(host,arg);
	}
	else
	{
		ret = -2;
	}

	return ret;
}

static emmc_driver_t arasan_emmc_driver =
{
	.init = arasan_emmc_init,
	.ioctl = arasan_emmc_ioctl,
	.read = arasan_emmc_read,
	.write = arasan_emmc_write,
	.erase = arasan_emmc_erase,
#if USE_EMMC_IRQ
	.dma_read_start	= arasan_emmc_dma_read_start,
	.dma_read_stop	= arasan_emmc_dma_read_stop,
#endif
};

emmc_driver_t* get_emmc_driver(void)
{
	return &arasan_emmc_driver;
}
