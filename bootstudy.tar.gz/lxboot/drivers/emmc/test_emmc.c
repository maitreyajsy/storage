#if (USE_EMMC == 1)
#include <types.h>
#include <debug.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <command.h>
#include <util.h>
#include <partinfo.h>
#include <emmc.h>

#define EMMC_TEST_LOG 		0


static void emmc_make_testdata(unsigned int *buff, unsigned int sector_addr, unsigned int size)
{
	unsigned int i;

	for (i=0; i<(size/4); i++)
	{
		buff[i] = sector_addr;

		if (((i % 0x7F) == 0) && (i > 0))
			sector_addr++;
	}
}

static u32  emmc_test_transfer(void *buff, u32 offset, u32 size, u32 write , u32 alert_speed, u32 *time)
{
	u32 tick, elapsed, speed;;
	int rc;

	tick = timer_tick();

	if (write)
		rc = emmc_write(offset, size, (void*)buff);
	else
		rc = emmc_read(offset, size, (void*)buff);
	elapsed = timer_elapsed(tick);

//	if(elapsed < 1000) speed = (size/1024)*1000*1000 / elapsed;
//	else speed = (size/1024)*1000 / (elapsed/1000);

	speed = (size/1024)*1000 * 100 /(elapsed/10);
	*(u32*)time = elapsed;

#if 0
	#if (EMMC_TEST_LOG > 0)
	printf("0x%08X(0x%08X) - %8ld bytes %s: %s. %8ldus elapsed, %8ldKbps/sec\n",
			offset, size + offset, size, write > 0 ? "write" : "read ", rc < 0 ? "ER" : "OK", elapsed, speed);
	#endif

	if (speed < alert_speed)
	{
		printf("0x%08X(0x%08X) - %7ld bytes %s: %s. %3ld.%3ldms elapsed, %7ldKbps/sec\n",
			offset, size + offset, size, write > 0 ? "write" : "read ", rc < 0 ? "ER" : "OK",
			elapsed/1000, elapsed%1000, speed);
	}
#endif
	return speed;
}

int test_emmc_speed(int argc, char *argv[])
{
	static char		*emmc_test_buf;
	//static int		emmc_test_buf_inited = 0;
	char			*endptr;
	u32				i, loop;
	u32				rand_limit;

	u32				e_start;
	u32				e_size;
	u32				e_chunk;
	u32				e_write;
	u32				chunk_loop_end = 0;
	u32				chunk_loop_size[6] = {0x200000,0x100000,0x80000,0x40000,0x20000,0x10000};

	u32				speed= 0;
	u32				r_speed = 0, r_speed_min = 0xFFFFFFFF, r_speed_max = 0;
	u32				w_speed = 0, w_speed_min = 0xFFFFFFFF, w_speed_max = 0;
	u32				r_count = 0;
	u32				w_count = 0;
	u32				alert_speed;
	u32				chunk_sz;
	struct emmc_info* pemmc;
	u64				offset, size;

	u32				time = 0;
	u32				r_time_min = 0xFFFFFFFF;
	u32				r_time_max = 0;

	u32				w_time_min = 0xFFFFFFFF;
	u32				w_time_max = 0;
	#if (EMMC_TEST_LOG < 1)
	u32				percent;
	#endif
	u32				no_cache_opr = 0;

	emmc_test_buf = (char *)DATA_BUF_BASE;
	memset(emmc_test_buf, 0xA5, 1024*1024);

/*
	for (i=2; i<argc; i++)
	{
		//printf("argv[%u] = %s\n",i,argv[i]);
		if (i >= 3)
		{
			strtoul(argv[i], &endptr, 0);
			if(*endptr != '\0')
				return -1;
		}
	}
*/
/**
 *	case1 : sequential read
 *	case2 : sequential read
 *	case3 : random read
 *	case4 : random write
 *	case5 : same address write
 *	case6 : random read & write
 */
 	for (i=2; i<argc; i++)
	{
		if (!strcmp(argv[i], "nc"))
		{
			no_cache_opr = 1;
			argc--;
#if !defined(FIRST_BOOT)
			printf("EMMC DCache control disable\n");
#else
			printf("'nc' option not supprot 1st boot\n");
#endif
			break;
		}
	}

	if (argc == 3)
	{
		e_start = 1024 * 1024;
		e_size =  1024 * 1024 * 1024;
		e_chunk = 1024 * 1024;
	}
	else if (argc == 6)
	{
		e_start = strtoul(argv[3], &endptr, 0);
		e_size = strtoul(argv[4], &endptr, 0);
		e_chunk = strtoul(argv[5], &endptr, 0);
	}
	else
	{
		return -1;
	}

	if((strcmp(argv[2], "case3") == 0) || (strcmp(argv[2], "case4") == 0) || (strcmp(argv[2], "case6") == 0))
	{
		loop = (50*1024*1024)/e_chunk;
		rand_limit = e_size/e_chunk;
	}
	else
	{
		loop = e_size / e_chunk;
		rand_limit = 1024;
	}

	if(strcmp(argv[2], "case0") == 0)	alert_speed = 30*1024;
	if(strcmp(argv[2], "case1") == 0)	alert_speed = 30*1024;
	if(strcmp(argv[2], "case2") == 0)	alert_speed = 5*1024;
	if(strcmp(argv[2], "case3") == 0)	alert_speed = 1024;
	if(strcmp(argv[2], "case4") == 0)	alert_speed = 20;
	if(strcmp(argv[2], "case5") == 0)	alert_speed = 1024;
	if(strcmp(argv[2], "case6") == 0)	alert_speed = 1024;

	if((strcmp(argv[2], "case1") == 0) || (strcmp(argv[2], "case3") == 0))
	{
		e_write = 0;
	}
	else
	{
		e_write = 1;
	}

	pemmc = get_emmc_info();
	chunk_sz = e_chunk;

chunk_loop:

	if(strcmp(argv[2], "case0") == 0)
	{
		e_size =  (u32)1024 * 1024 * 1024 * 2;
		e_chunk = chunk_loop_size[chunk_loop_end/2];

		if (chunk_loop_end & 1)
			e_write = 0;
		else
			e_write = 1;

		chunk_sz = e_chunk;
		chunk_loop_end++;

		loop = e_size / e_chunk;
	}

	printf("EMMC START ADDR  = 0x%X\n",e_start);
	printf("EMMC TEST  CHUNK = %u Byte\n",e_chunk);
	printf("EMMC TEST  LOOP  = %u\n",loop);
	printf("EMMC TEST  SIZE  = %u Byte\n",e_chunk*loop);
	printf("\n");
//	printf("===============================================================\n");

	r_speed		= 0;
	r_speed_min	= 0xFFFFFFFF;
	r_speed_max	= 0;
	w_speed		= 0;
	w_speed_min	= 0xFFFFFFFF;
	w_speed_max = 0;
	r_count		= 0;
	w_count		= 0;

	for (i=0; i < loop ; i++)
	{
		if((strcmp(argv[2], "case1") == 0) || (strcmp(argv[2], "case2") == 0) || (strcmp(argv[2], "case0") == 0))
		{
			offset = e_start + (i * e_chunk);
		}
		else if((strcmp(argv[2], "case3") == 0) || (strcmp(argv[2], "case4") == 0) || (strcmp(argv[2], "case6") == 0))
		{
			offset = e_start + (rand_num(rand_limit) * e_chunk);
		}
		else if(strcmp(argv[2], "case5") == 0)
		{
			offset = e_start;
		}
		else
		{
			return -1;
		}

		if(strcmp(argv[2], "case6") == 0)
		{
			e_write = rand_num(1024) & 0x1;
		}
		size = e_chunk;

#if USE_STORAGE_DMA_READ
		if (no_cache_opr)
			emmc_dcache_ops_range(DCACHE_ALL);
#endif
		speed = emmc_test_transfer(emmc_test_buf,offset,size,e_write, alert_speed, &time);
#if USE_STORAGE_DMA_READ
		if (no_cache_opr)
			emmc_dcache_ops_range(DCACHE_RANGE);
#endif
		#if (EMMC_TEST_LOG < 1)
		percent = (i*100)/((e_size / e_chunk));
		printf("Progress = %u\r",percent);
		#endif
		if (e_write == 0)
		{
			r_speed = r_speed + speed;
			r_count++;

			if (speed < r_speed_min)
				r_speed_min = speed;
			if (speed > r_speed_max)
				r_speed_max = speed;

			if (time >= r_time_max)
				r_time_max = time;
			if (r_time_min >= time)
				r_time_min = time;
		}
		else
		{
			w_speed = w_speed + speed;
			w_count++;

			if (speed < w_speed_min)
				w_speed_min = speed;
			if (speed > w_speed_max)
				w_speed_max = speed;

			if (time >= w_time_max)
				w_time_max = time;
			if (w_time_min >= time)
				w_time_min = time;
		}
	}

	if (r_count)
	{
		printf("EMMC READ  Chunk %7d: %2u.%03u %2u.%03u %2u.%03u Mbyte/sec\n",
			chunk_sz, (r_speed/r_count)/1000, (r_speed/r_count)%1000,
			r_speed_min/1000, r_speed_min%1000, r_speed_max/1000, r_speed_max%1000);
		printf("\n");
		printf("===============================================================\n");
	}

	if (w_count)
	{
		printf("EMMC WRITE Chunk %7d: %2u.%03u %2u.%03u %2u.%03u Mbyte/sec\n",
			chunk_sz, (w_speed/w_count)/1000, (w_speed/w_count)%1000,
			w_speed_min/1000, w_speed_min%1000, w_speed_max/1000, w_speed_max%1000);

		printf("\n");
		printf("===============================================================\n");
	}

	if(strcmp(argv[2], "case0") == 0)
	{
		if (chunk_loop_end < 12)
			goto chunk_loop;
	}

	return 0;
}

int test_emmc_reliability(int argc, char *argv[])
{
	struct emmc_info	*emmc = get_emmc_info();
#define RWSIZE			(128 * 1024)
#define EMMC_OFFSET		16
	unsigned int		*buff = NULL;
	unsigned int		*compare = NULL;
	unsigned char		*smartbuff = NULL;

	unsigned int		loop;
	unsigned int		loop_start;
	unsigned int		i;
	unsigned int 		ppercent = 0;
	unsigned int 		percent = 0;
	unsigned int 		percent_backup = 2000;
	int					rc;
	int					key;
	loff_t				chip_size;

	unsigned int 		smartreport_test = 0;

	buff = (unsigned int*)dma_malloc(RWSIZE);
	compare = (unsigned int*)dma_malloc(RWSIZE);
	smartbuff = (unsigned char*)dma_malloc(512);

	printf("If you proceed with the test data will be erased.\n");
	printf("Do you want continue this test?\n");
	printf("----------\n");
	printf("y or n\n");
	key = getchar();

	if ((key == 'y') || (key == 'Y'))
		goto reltest_go;

	dma_free(buff);
	dma_free(compare);
	dma_free(smartbuff);

	return 0;

reltest_go:

	if (argc == 3)
	{
		if(strcmp(argv[2], "smartreport") == 0)
		{
			smartreport_test = 0x1;
		}
	}

	memset(buff ,0xa6, RWSIZE);

	chip_size = emmc->chip_size;
	loop = (chip_size / RWSIZE);
	loop_start = EMMC_OFFSET; // (1024*1024) / rwsize;

	if (smartreport_test)
		printf("EMMC reliability TEST START with SMARTREPORT\n");
	else
		printf("EMMC reliability TEST START\n");

	printf("TEST DATA Write\n");
	for (i=loop_start,percent_backup = 2000; i < loop ; i++)
	{
		emmc_make_testdata(buff,i * (RWSIZE/512), RWSIZE);

		if ((smartreport_test) && ((rand_num(1024) & 0x3F) == 5))
		{
			// get_smart_report
			get_emmc_smart_report(smartbuff);
		}

		rc = emmc_write(((loff_t)i * RWSIZE), RWSIZE, (void*)buff);
		if (rc != RWSIZE)
			printf("EMMC WRITE 0x%llX FAIL\n",(i * RWSIZE));

		percent = ((i * 1000) / loop);
		if (percent != percent_backup)
		{
			percent_backup = percent;
			ppercent = percent+1;
			printf("W: %u.%u percent\r",ppercent/10,ppercent%10);
		}
	}

	printf("\n\n");
	printf("TEST DATA Read\n");
	for (i=loop_start,percent_backup = 2000; i < loop ; i++)
	{
		memset(buff, 0x0, RWSIZE);
		emmc_make_testdata(compare,i * (RWSIZE/512),RWSIZE);

		if ((smartreport_test) && ((rand_num(1024) & 0x3F) == 5))
		{
			// get_smart_report
			get_emmc_smart_report(smartbuff);
		}

		rc = emmc_read(((loff_t)i * RWSIZE), RWSIZE, (void*)buff);
		if (rc != RWSIZE)
			printf("EMMC WRITE 0x%llX FAIL\n",(i * RWSIZE));

		if (memcmp(buff,compare,RWSIZE/4))
		{
			printf("EMMC TEST FAIL! : addr 0x%llX(%d) expected 0x%X, read 0x%X\n",((loff_t)i * RWSIZE),compare[0],buff[0]);
		}

		percent = ((i * 1000) / loop);
		if (percent != percent_backup)
		{
			percent_backup = percent;
			ppercent = percent+1;
			printf("R: %u.%u percent\r",ppercent/10,ppercent%10);
		}
	}
	printf("\n\n");

	dma_free(buff);
	dma_free(compare);
	dma_free(smartbuff);

	return 0;
}
#endif/*USE_EMMC == 1 or 0*/
