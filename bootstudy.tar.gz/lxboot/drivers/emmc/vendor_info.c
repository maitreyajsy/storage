#include <types.h>
#include "emmc_host.h"
#include "vendor_info.h"

void emmc_vendor_tab(struct mmc_host *host)
{
	host->tab_400.step = 0xFFFFFFFF;
	host->tab_400.in = 0;						// for HS400
	host->tab_400.out = 0;

	host->tab_200.step = 0xFFFFFFFF;
	host->tab_200.in = 0;						// for HS200
	host->tab_200.out = 0;

	host->tab_50.step = 0xFFFFFFFF;				// for DDR50
	host->tab_50.in = 0;
	host->tab_50.out = 0;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210) // H15
	{
		if (host->card.cid.manfid == VENDOR_TOSHIBA)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 16;						// for HS400
			host->tab_400.out = 2;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 16;						// for HS200
			host->tab_200.out = 6;

			host->tab_50.step = 0xFFFFFFFF;				// for DDR50
			host->tab_50.in = 27;
			host->tab_50.out = 6;
		}
		else if (host->card.cid.manfid == VENDOR_SANDISK_1)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 7;						// for HS400
			host->tab_400.out = 2;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 7;						// for HS200
			host->tab_200.out = 7;

			host->tab_50.step = 0xFFFFFFFF;				// for DDR50
			host->tab_50.in = 26;
			host->tab_50.out = 6;
		}
		else if (host->card.cid.manfid == VENDOR_HYNIX)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 9;						// for HS400
			host->tab_400.out = 2;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 9;						// for HS200
			host->tab_200.out = 7;

			host->tab_50.step = 0xFFFFFFFF;				// for DDR50
			host->tab_50.in = 26;
			host->tab_50.out = 6;
		}
		else if (host->card.cid.manfid == VENDOR_MICRON)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 13;						// for HS400
			host->tab_400.out = 3;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 13;						// for HS200
			host->tab_200.out = 6;

			host->tab_50.step = 0xFFFFFFFF;				// for DDR50
			host->tab_50.in = 27;
			host->tab_50.out = 6;
		}
		else if (host->card.cid.manfid == VENDOR_MICRON_2)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 13;						// for HS400
			host->tab_400.out = 3;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 13;						// for HS200
			host->tab_200.out = 6;

			host->tab_50.step = 0xFFFFFFFF;				// for DDR50
			host->tab_50.in = 27;
			host->tab_50.out = 6;
		}
		else if (host->card.cid.manfid == VENDOR_SAMSUNG)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 7;						// for HS400
			host->tab_400.out = 2;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 7;						// for HS200
			host->tab_200.out = 6;

			host->tab_50.step = 0xFFFFFFFF;				// for DDR50
			host->tab_50.in = 27;
			host->tab_50.out = 6;
		}
		else
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 23;						// for HS400
			host->tab_400.out = 2;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 14;						// for HS200
			host->tab_200.out = 6;

			host->tab_50.step = 0xFFFFFFFF;				// for DDR50
			host->tab_50.in = 27;
			host->tab_50.out = 6;
		}

		return;
	}

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312)		// M16
	{
		if (host->card.cid.manfid == VENDOR_TOSHIBA)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 7;						// for HS400
			host->tab_400.out = 4;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 7;						// for HS200
			host->tab_200.out = 4;

			host->tab_50.step = 0xFFFFFFFF; 			// for DDR50
			host->tab_50.in = 12;
			host->tab_50.out = 4;
		}
		else if (host->card.cid.manfid == VENDOR_SAMSUNG)
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 26;						// for HS400
			host->tab_400.out = 6;
			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 25;						// for HS200
			host->tab_200.out = 7;
			host->tab_50.step = 0xFFFFFFFF; 			// for DDR50
			host->tab_50.in = 15;
			host->tab_50.out = 7;
		}
		else
		{
			host->tab_400.step = 0xFFFFFFFF;
			host->tab_400.in = 8;						// for HS400
			host->tab_400.out = 5;

			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 8;						// for HS200
			host->tab_200.out = 5;

			host->tab_50.step = 0xFFFFFFFF; 			// for DDR50
			host->tab_50.in = 11;
			host->tab_50.out = 6;
		}

		return;
	}

	if(get_chip_rev() >= CHIP_LG1156_A0)	// H14
	{
		host->tab_200.step = 0xFFFFFFFF;
		host->tab_200.in = 31;
		host->tab_200.out = 2;
	}
	else if ((get_chip_rev() >= CHIP_LG1311_B0) && (get_chip_rev() < CHIP_LG1156_A0))	// M14B0
	{
		host->tab_50.step = 0xFFFFFFFF;				// for DDR50
		host->tab_50.in = 16;
		host->tab_50.out = 6;

		if (host->card.ext_csd.ext_csd_rev <= 6)
		{
			host->tab_200.step = 0xFFFFFFFF;
			host->tab_200.in = 29;
			host->tab_200.out = 2;

			/* workaround Micron EMMC */
			if (host->card.cid.manfid == VENDOR_MICRON)
				host->tab_200.in  = 25;
			/****************************************/
		}
		else // if (host->card.ext_csd.ext_csd_rev >= 7)
		{
			if (host->card.cid.manfid == VENDOR_TOSHIBA)
			{
				host->tab_200.step = 0xFFFFFFFF;
				host->tab_200.in = 35;
				host->tab_200.out = 2;
			}
			else if (host->card.cid.manfid == VENDOR_HYNIX)
			{
				host->tab_200.step = 0xFFFFFFFF;
				host->tab_200.in = 26;
				host->tab_200.out = 2;
			}
			else if (host->card.cid.manfid == VENDOR_SAMSUNG)
			{
				host->tab_200.step = 0xFFFFFFFF;
				host->tab_200.in = 23;
				host->tab_200.out = 2;
			}
			else
			{
				host->tab_200.step = 0xFFFFFFFF;
				host->tab_200.in = 29;
				host->tab_200.out = 2;
			}
		}
	}
	else if ((get_chip_rev() >= CHIP_LG1311_A0) && (get_chip_rev() < CHIP_LG1311_B0))	// M14A0
	{
		host->tab_50.step = 3;
		host->tab_50.in = 25;
		host->tab_50.out = 9;
	}
	else if ((get_chip_rev() >= CHIP_LG1154_B0) && (get_chip_rev() < CHIP_LG1311_A0))	//H13B0
	{
		host->tab_50.step = 3;
		host->tab_50.in = 38;
		host->tab_50.out = 9;
	}
	else if ((get_chip_rev() >= CHIP_LG1154_A0) && (get_chip_rev() < CHIP_LG1154_B0))	//H13A0
	{
		host->tab_50.step = 2;
		host->tab_50.in = 12;
		host->tab_50.out = 10;
	}
}

unsigned int emmc_vendor_host_ds(struct mmc_host *host)
{
	unsigned int ret = EMMC_HOST_DS_50ohm;

	if((get_chip_rev() & MASK_ARCH) == ARCH_LG1210) // H15
	{
		if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS400)
		{
				ret = EMMC_HOST_DS_33ohm;
		}
		else if (host->card.ext_csd.card_type & EMMC_SUPPORT_HS200)
		{
				ret = EMMC_HOST_DS_33ohm;
		}
	}
	else if((get_chip_rev() & MASK_ARCH) == ARCH_LG1312) // M16
	{
		ret = EMMC_HOST_DS_33ohm;
	}

	return ret;
}

unsigned char emmc_vendor_card_ds(struct mmc_host *host)
{
	unsigned char ret = EMMC_HOST_DS_50ohm;

	if (host->card.ext_csd.ext_csd_rev == 7)
	{
		if (host->card.cid.manfid == VENDOR_TOSHIBA)
			ret = EMMC_HOST_DS_40ohm;
	}

	return ret;
}

void emmc_vendor_max_clock(struct mmc_host *host)
{
	if ((get_chip_rev() >= CHIP_LG1311_B0) && (get_chip_rev() < CHIP_LG1156_A0))	// M14B0
	{
		/* workaround Micron EMMC */
		if (host->card.cid.manfid == VENDOR_MICRON)
			host->max_clock = 99000000;
		/****************************************/
	}
}
