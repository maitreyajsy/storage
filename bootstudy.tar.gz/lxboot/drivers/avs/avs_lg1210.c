/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if (CONFIG_ARCH == ARCH_LG1210)
#include <types.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <interrupt.h>
#include <util.h>
#include <malloc.h>
#include <storage.h>

#ifdef USE_AVS
//#define AVS_NOTI_LONG
//#define AVS_GPU_ENABLE

#define H15_EFUSE_BASE			0xC0273000
#define H15_EDS_OFFSET			0x68
#define H15_FT_OFFSET			0x78

#define H15_AVS_EDS_ALL_ZERO	1
#define H15_AVS_EDS_CRC_FAIL	2
#define H15_AVS_FT_ALL_ZERO		4
#define H15_AVS_FT_CRC_FAIL		8

#define H15_AVS_FREQ_OD			0
#define H15_AVS_FREQ_ND			1
#define H15_AVS_FREQ_UD 		2

#define H15_SIDD_CPU			0
#define H15_SIDD_GPU			1
#define H15_SIDD_CORE			2

#define H15_HPM_RVT_CPU			0
#define H15_HPM_RVT_GPU			1
#define H15_HPM_HVT_CPU			2
#define H15_HPM_RVT_LEFT		3

#define H15_TS_CPU				0
#define H15_TS_GPU				1
#define H15_TS_LEFT				2

#define H15_WAFER_ID			0
#define H15_LOT_ID1				1
#define H15_LOT_ID2				2


#define H15_CPU_SIDD_THRESHOLD	900		// mA
#define H15_CPU_HPM_THRESHOLD	2700	// 10KH unit

#define H15_GPU_SIDD_THRESHOLD	230		// mA
#define H15_GPU_HPM_THRESHOLD	2650	// 10KH unit

const unsigned char crc8_table[256] = {
	0, 7, 14, 9, 28, 27, 18, 21, 56, 63, 54, 49, 36, 35, 42, 45,
	112, 119, 126, 121, 108, 107, 98, 101, 72, 79, 70, 65, 84, 83, 90, 93,
	224, 231, 238, 233, 252, 251, 242, 245, 216, 223, 214, 209, 196, 195, 202, 205,
	144, 151, 158, 153, 140, 139, 130, 133, 168, 175, 166, 161, 180, 179, 186, 189,
	199, 192, 201, 206, 219, 220, 213, 210, 255, 248, 241, 246, 227, 228, 237, 234,
	183, 176, 185, 190, 171, 172, 165, 162, 143, 136, 129, 134, 147, 148, 157, 154,
	39, 32, 41, 46, 59, 60, 53, 50, 31, 24, 17, 22, 3, 4, 13, 10,
	87, 80, 89, 94, 75, 76, 69, 66, 111, 104, 97, 102, 115, 116, 125, 122,
	137, 142, 135, 128, 149, 146, 155, 156, 177, 182, 191, 184, 173, 170, 163, 164,
	249, 254, 247, 240, 229, 226, 235, 236, 193, 198, 207, 200, 221, 218, 211, 212,
	105, 110, 103, 96, 117, 114, 123, 124, 81, 86, 95, 88, 77, 74, 67, 68,
	25, 30, 23, 16, 5, 2, 11, 12, 33, 38, 47, 40, 61, 58, 51, 52,
	78, 73, 64, 71, 82, 85, 92, 91, 118, 113, 120, 127, 106, 109, 100, 99,
	62, 57, 48, 55, 34, 37, 44, 43, 6, 1, 8, 15, 26, 29, 20, 19,
	174, 169, 160, 167, 178, 181, 188, 187, 150, 145, 152, 159, 138, 141, 132, 131,
	222, 217, 208, 215, 194, 197, 204, 203, 230, 225, 232, 239, 250, 253, 244, 243 };

static unsigned int cpu_voltable[3][2]={{1050000, 1000000},{940000, 890000},{800000, 800000}};
static unsigned int cpu_avs_select = 0;

static unsigned int gpu_voltable[3][2]={{1000000, 950000},{940000, 890000},{800000, 800000}};
static unsigned int gpu_avs_select = 0;

int calc_crc8(unsigned char *buf)
{
	unsigned char crc = 0;
	unsigned int i;

	for (i = 0;i < 24 ; i++)
		crc = crc8_table[crc ^ buf[i]];

	return crc;
}

static unsigned int h15_get_ts(unsigned int select)
	{
	unsigned int *efuse_buf;
	unsigned int ts = 0;

	efuse_buf = (unsigned int*)(H15_EFUSE_BASE + H15_EDS_OFFSET);

	if (select == H15_TS_CPU)
		ts = (efuse_buf[3] >> 16) & 0xf;
	else if (select == H15_TS_GPU)
		ts = (efuse_buf[3] >> 12) & 0xf;
	else if (select == H15_TS_LEFT)
		ts = (efuse_buf[3] >> 8) & 0xf;

	return ts;
	}

static unsigned int h15_get_id(unsigned int select)
	{
	unsigned int *efuse_buf;
	unsigned int id = 0;

	efuse_buf = (unsigned int*)(H15_EFUSE_BASE + H15_EDS_OFFSET);

	if (select == H15_WAFER_ID)
		id = (efuse_buf[1] >> 16) & 0xff;
	else if (select == H15_LOT_ID1)
		id = (efuse_buf[0] & 0xffffff0) >> 4;
	else if (select == H15_LOT_ID2)
		id = ((efuse_buf[0] & 0xf) << 8) + ((efuse_buf[1] >> 24) & 0xff);

	return id;
}

static unsigned int h15_get_xx(void)
{
	unsigned char *efuse_buf;
	unsigned int xx = 0;

	efuse_buf = (unsigned char*)(H15_EFUSE_BASE + H15_EDS_OFFSET);

	xx = efuse_buf[5];

	return xx;
}

static unsigned int h15_get_yy(void)
{
	unsigned char *efuse_buf;
	unsigned int yy = 0;

	efuse_buf = (unsigned char*)(H15_EFUSE_BASE + H15_EDS_OFFSET);

	yy = efuse_buf[4];

	return yy;
}

static unsigned int h15_get_sidd(unsigned int select)
{
	unsigned int *efuse_buf;
	unsigned int sidd = 0;

	efuse_buf = (unsigned int*)(H15_EFUSE_BASE + H15_EDS_OFFSET);

	if (select == H15_SIDD_CPU)
		sidd = (efuse_buf[2] >> 20);
	else if (select == H15_SIDD_GPU)
		sidd = (efuse_buf[2] >> 8) & 0xFFF;
	else if (select == H15_SIDD_CORE)
		sidd = (efuse_buf[3] >> 20);

	return sidd;
}

static int h15_get_hpm(unsigned int select)
{
	unsigned int *efuse_buf;
	unsigned int hpm = 0;

	efuse_buf = (unsigned int*)(H15_EFUSE_BASE + H15_FT_OFFSET);

	if (select == H15_HPM_RVT_CPU)
		hpm = (efuse_buf[0] >> 20);
	else if (select == H15_HPM_RVT_GPU)
		hpm = (efuse_buf[0] >> 8) & 0xFFF;
	else if (select == H15_HPM_HVT_CPU)
		hpm = (efuse_buf[1] >> 20);
	else if (select == H15_HPM_RVT_LEFT)
		hpm = (efuse_buf[1] >> 8) & 0xFFF;

	return hpm;
}

int h15_efuse_valid_check(void)
{
	unsigned int *efuse_buf;
	unsigned int zero_buf[4];
	unsigned int crc_buf[6];
	unsigned int error = 0;
	unsigned char crc8;

	memset(zero_buf, 0x0, 16);

	efuse_buf = (unsigned int*)(H15_EFUSE_BASE + H15_EDS_OFFSET);
	if (memcmp(zero_buf, efuse_buf, 16) == 0)
		error |= H15_AVS_EDS_ALL_ZERO;

	efuse_buf = (unsigned int*)(H15_EFUSE_BASE + H15_FT_OFFSET);
	if (memcmp(zero_buf, efuse_buf, 8) == 0)
		error |= H15_AVS_FT_ALL_ZERO;

	efuse_buf = (unsigned int*)(H15_EFUSE_BASE + H15_EDS_OFFSET);

	if ((error & H15_AVS_EDS_ALL_ZERO) == 0)
	{
		memset(crc_buf, 0x0, 24);
		memcpy(crc_buf, efuse_buf, 16);

		crc_buf[3] &= 0xffffff00;
		crc8 = (unsigned char)(efuse_buf[3] & 0xff);

		if (crc8 != calc_crc8((unsigned char*)crc_buf))
			error |= H15_AVS_EDS_CRC_FAIL;
	}

	if ((error & H15_AVS_FT_ALL_ZERO) == 0)
	{
		memset(crc_buf, 0x0, 24);
		memcpy(crc_buf, efuse_buf, 24);

		crc_buf[3] &= 0xffffff00;
		crc_buf[5] &= 0xffffff00;
		crc8 = (unsigned char)(efuse_buf[5] & 0xff);

		if (crc8 != calc_crc8((unsigned char*)crc_buf))
			error |= H15_AVS_FT_CRC_FAIL;
}

	if (error)
{
		if (error & H15_AVS_EDS_ALL_ZERO)
			printf("AVS EDS EFUSE ALL ZERO\n");
		if (error & H15_AVS_EDS_CRC_FAIL)
			printf("AVS EDS EFUSE CRC FAIL\n");
		if (error & H15_AVS_FT_ALL_ZERO)
			printf("AVS FT EFUSE ALL ZERO\n");
		if (error & H15_AVS_FT_CRC_FAIL)
			printf("AVS FT EFUSE CRC FAIL\n");

		return -1;
	}

	return 0;
}

unsigned int avs_init(void)
{
	unsigned char lot[3];
	printf("H15 AVS INIT\n");

	cpu_avs_select = 0;
	gpu_avs_select = 0;

	if (h15_efuse_valid_check() == 0)
	{
		lot[0] = (h15_get_id(H15_LOT_ID1) >> 16) & 0xFF;
		lot[1] = (h15_get_id(H15_LOT_ID1) >> 8) & 0xFF;
		lot[2] = h15_get_id(H15_LOT_ID1) & 0xFF;

#ifdef AVS_NOTI_LONG
		printf("H15 AVS LOT ID %c%c%c%X\n",lot[0],lot[1],lot[2],h15_get_id(H15_LOT_ID2));
		printf("H15 AVS WAFER ID 0x%X\n",h15_get_id(H15_WAFER_ID));
		printf("H15 AVS SIDD CPU %u\n",h15_get_sidd(H15_SIDD_CPU));
		printf("H15 AVS SIDD GPU %u\n",h15_get_sidd(H15_SIDD_GPU));
		printf("H15 AVS SIDD CORE %u\n",h15_get_sidd(H15_SIDD_CORE));
		printf("H15 AVS HPM RVT CPU %u\n",h15_get_hpm(H15_HPM_RVT_CPU));
		printf("H15 AVS HPM RVT GPU %u\n",h15_get_hpm(H15_HPM_RVT_GPU));
		printf("H15 AVS HPM HVT CPU %u\n",h15_get_hpm(H15_HPM_HVT_CPU));
		printf("H15 AVS HPM RVT LEFT %u\n",h15_get_hpm(H15_HPM_RVT_LEFT));
		printf("H15 AVS XX %u\n",h15_get_xx());
		printf("H15 AVS YY %u\n",h15_get_yy());
		printf("H15 AVS TS CPU %u\n",h15_get_ts(H15_TS_CPU));
		printf("H15 AVS TS GPU %u\n",h15_get_ts(H15_TS_GPU));
		printf("H15 AVS TS LEFT %u\n",h15_get_ts(H15_TS_LEFT));
#else
		printf("H15 AVS INFO ID:%c%c%c%X/0x%X, ",lot[0],lot[1],lot[2],h15_get_id(H15_LOT_ID2),h15_get_id(H15_WAFER_ID));
		printf("SIDD:%u/%u/%u, ",h15_get_sidd(H15_SIDD_CPU),h15_get_sidd(H15_SIDD_GPU),h15_get_sidd(H15_SIDD_CORE));
		printf("HPM:%u/%u/%u/%u, ",h15_get_hpm(H15_HPM_RVT_CPU),h15_get_hpm(H15_HPM_RVT_GPU),h15_get_hpm(H15_HPM_HVT_CPU),h15_get_hpm(H15_HPM_RVT_LEFT));
		printf("AXIS:%u/%u, ",h15_get_xx(),h15_get_yy());
		printf("TS:%u/%u/%u\n",h15_get_ts(H15_TS_CPU),h15_get_ts(H15_TS_GPU),h15_get_ts(H15_TS_LEFT));
#endif
		if ((h15_get_sidd(H15_SIDD_CPU) >= H15_CPU_SIDD_THRESHOLD) && (h15_get_hpm(H15_HPM_RVT_CPU) >= H15_CPU_HPM_THRESHOLD))
		{
			printf("FAST CHIP\n");
			cpu_avs_select = 1;
		}

#ifdef AVS_GPU_ENABLE
		if ((h15_get_sidd(H15_SIDD_GPU) >= H15_GPU_SIDD_THRESHOLD) && (h15_get_hpm(H15_HPM_RVT_CPU) >= H15_GPU_HPM_THRESHOLD))
			gpu_avs_select = 1;
#endif
	}

	return 0;
}

unsigned int avs_get_table(unsigned int freq_index)
	{
	return cpu_voltable[freq_index][cpu_avs_select];
	}

unsigned int get_gpuavs_enable(void)
{
	return gpu_avs_select;	//0 disabel, 1 enable
}

unsigned int gpuavs_get_table(unsigned int freq_index)
{
	return gpu_voltable[freq_index][gpu_avs_select];
}

#endif
#endif

