/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if (CONFIG_ARCH == ARCH_LG1312)
#include <types.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <interrupt.h>
#include <util.h>
#include <env.h>
#include <malloc.h>
#include <storage.h>

#ifdef USE_AVS

//static unsigned int avs_select = 0;


/* FT/EDS  make CRC(8bit) data using 16 byte region (source of CRC) in effuse.
   and the CRC is written at the 12nd byte in 16 byte region while contaminating
   CRC source region. we consider 12nd byte is 0, getting CRC as if CRC is not written yet */

#define CONSIDER_PREV_FT

#define EFUSE_BASE	0xC1123000

#ifdef CONSIDER_PREV_FT
#define CRC_SRC_SIZE	16
#else
#define CRC_SRC_SIZE	12
#endif

#define CRC_BYTE_OFFSET	12

/* xor operation 's result is recoded by crc8_table  */
const unsigned char crc8_table[256] = {
0, 7, 14, 9, 28, 27, 18, 21, 56, 63, 54, 49, 36, 35, 42, 45,
112, 119, 126, 121, 108, 107, 98, 101, 72, 79, 70, 65, 84, 83, 90, 93,
224, 231, 238, 233, 252, 251, 242, 245, 216, 223, 214, 209, 196, 195, 202, 205,
144, 151, 158, 153, 140, 139, 130, 133, 168, 175, 166, 161, 180, 179, 186, 189,
199, 192, 201, 206, 219, 220, 213, 210, 255, 248, 241, 246, 227, 228, 237, 234,
183, 176, 185, 190, 171, 172, 165, 162, 143, 136, 129, 134, 147, 148, 157, 154,
39, 32, 41, 46, 59, 60, 53, 50, 31, 24, 17, 22, 3, 4, 13, 10,
87, 80, 89, 94, 75, 76, 69, 66, 111, 104, 97, 102, 115, 116, 125, 122,
137, 142, 135, 128, 149, 146, 155, 156, 177, 182, 191, 184, 173, 170, 163, 164,
249, 254, 247, 240, 229, 226, 235, 236, 193, 198, 207, 200, 221, 218, 211, 212,
105, 110, 103, 96, 117, 114, 123, 124, 81, 86, 95, 88, 77, 74, 67, 68,
25, 30, 23, 16, 5, 2, 11, 12, 33, 38, 47, 40, 61, 58, 51, 52,
78, 73, 64, 71, 82, 85, 92, 91, 118, 113, 120, 127, 106, 109, 100, 99,
62, 57, 48, 55, 34, 37, 44, 43, 6, 1, 8, 15, 26, 29, 20, 19,
174, 169, 160, 167, 178, 181, 188, 187, 150, 145, 152, 159, 138, 141, 132, 131,
222, 217, 208, 215, 194, 197, 204, 203, 230, 225, 232, 239, 250, 253, 244, 243 };




unsigned int core_cpu_sidd = 0;//core_sidd [31:16] cpu_sidd[15:0

static volatile unsigned int kernel_avs_enable = 1;

unsigned int avs_get_info(void)
{
	return core_cpu_sidd;
}

int get_avs_enable(void)
{
        return kernel_avs_enable;
}

static unsigned int m16_get_sidd(void)
{
	unsigned char *efuse_buf;

	efuse_buf = (unsigned char*)(EFUSE_BASE + (0x80));
	core_cpu_sidd =( efuse_buf[8] + (efuse_buf[9] << 8)) |
			 (efuse_buf[10] + (efuse_buf[11] << 8)) << 16 ;
	//printf("core_sidd %x\n",core_cpu_sidd >>16 & 0xffff);
	//printf(" cpu_sidd %x\n",core_cpu_sidd &0xffff );

	return core_cpu_sidd;
}

static unsigned int m16_get_xx(void)
{
	unsigned char *efuse_buf;
	unsigned int xx = 0;

	efuse_buf = (unsigned char*)(EFUSE_BASE + (0x80));

	xx = efuse_buf[5];
	//printf("xx %u\n",xx);

	return 0;
}

static unsigned int m16_get_yy(void)
{
	unsigned char *efuse_buf;
	unsigned int yy = 0;
	efuse_buf = (unsigned char*)(EFUSE_BASE + (0x80));

	yy = efuse_buf[6];
	//printf("yy %u\n",yy);

	return 0;
}


int m16_efuse_valid_check(void)
{
	unsigned char efuse_buf[CRC_SRC_SIZE],crc_byte;
	unsigned int i;
	unsigned char crc = 0;
	unsigned char nzerocnt = 0;

	memcpy(efuse_buf, (unsigned char *)(EFUSE_BASE + 0x80), CRC_SRC_SIZE);

	crc_byte = efuse_buf[CRC_BYTE_OFFSET];

	/* exclude CRC_BYTE in CRC */
	efuse_buf[CRC_BYTE_OFFSET] = 0x0;

	for (i = 0;i < CRC_SRC_SIZE ; i++)
	{
		if(efuse_buf[i] != 0)
			nzerocnt++;

		//printf("crc[%2x] ^ buf[%2x]",crc, efuse_buf[i]);
		//printf("=[%2x] crctable[%3d]=[%2x]\n",crc ^ efuse_buf[i], crc ^ efuse_buf[i],crc8_table[crc ^ efuse_buf[i]]);
		crc = crc8_table[crc ^ efuse_buf[i]];
	}

	//printf("calcuated crc[%2x] crc[%2x]\n",crc, crc_byte);
	if( nzerocnt > 0 &&  crc == crc_byte)
	{
		return 0;
	}
	else
	{	//avs info is set as a 0 in case of invalid efuse 	
		kernel_avs_enable = 0;	
		core_cpu_sidd = 0;
		return 1;
	}


}

unsigned int avs_init(void)
{
        char *avschar;
        char *endptr;

        avschar = env_get(ENV_AVS_ENABLE);

        if (avschar)
        {
                kernel_avs_enable = strtoul(avschar, &endptr, 0);
		//printf("[%d]\n",kernel_avs_enable);
        }
	
	m16_get_sidd();
	m16_get_xx();
	m16_get_yy();
	m16_efuse_valid_check();
	printf("avsinfo[%x]\n",avs_get_info());

	return 0;
}
#endif
#endif

