/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if USE_DTVSOC_I2C

#if SHADOW_ROM
#include <i2c.h>
#define loop_udelay				udelay
#define get_clk(CLK_DEV_I2C) 	(198*MHZ)
#else
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <timer.h>
#include <i2c.h>
#include <thread.h>
#endif

#ifndef I2C_BASE
#error "Have to define the i2c base address !!!"
#endif

#define I2C_DEBUG 0

#if I2C_DEBUG > 1
#define I2C_PRINT							printf
#else
#define I2C_PRINT(format, args...)			do{}while(0)
#endif

#if I2C_DEBUG > 0
#define I2C_PRINT_ERROR						printf
#else
#define I2C_PRINT_ERROR(format, args...)	do{}while(0)
#endif

/*
*******************************************************************************
*                  GLOBAL  MACROS
*******************************************************************************
*/

/* Read/write mode for the command register */
#define I2C_WRITE_MODE  0x0
#define I2C_READ_MODE   0x1


/* Control Register 0 bit definitions I2CMSCTR0 */
#define SET_START_SEQ	0x80
#define SET_STOP_SEQ  	0x40
#define RESTART_SEQ		0x20
#define NTB_1_BYTE		0x00
#define NTB_2_BYTE		0x08
#define NTB_3_BYTE		0x10
#define NTB_4_BYTE		0x18
#define INT_ACK			0x02
#define TRANSFER_GO		0x01

/* Control Register 1 bit definitions I2CMSCTR0 */
#define TRANS_MASTER_TX	0x00
#define TRANS_MASTER_RX	0x40
#define SLAVE_MODE_OP	0x80
#define CORE_ENABLE		0x20
#define INT_ENABLE		0x10
#define CLR_MASTER_FIFO	0x08
#define CLR_SLAVE_FIFO	0x04
#define SOFT_RESET		0x02
#define CLEAR_FIFOS		0x0C
#define CLEAR_REG       0x00

/* FIFO defines */
#define FIFO_EMPTY		0x0
#define FIFO_1BYTE_DATA	0x20 /* 0010-0000 */
#define FIFO_2BYTE_DATA	0x40 /* 0100-0000 */
#define FIFO_3BYTE_DATA	0x60 /* 0110-0000 */
#define FIFO_FULL		0x80 /* 1000-0000 */

/* Master status register */
#define MASTER_STAT_MFS	0xE0
#define MASTER_STAT_MIS	0x04
#define MASTER_STAT_SNB	0x02
#define MASTER_STAT_MTB	0x01


/* Slave status register */
#define SLAVE_STAT_STB	0x01
#define SLAVE_STAT_MNB	0x02
#define SLAVE_STAT_SIS	0x04
#define SLAVE_STAT_TRM	0x08
#define SLAVE_STAT_SAR	0x10
#define SLAVE_STAT_SFS	0xE0


#define LSB8(value) (value & 0x00FF)
#define MSB8(value) ((value & 0xFF00) >> 8)

#define I2C_OK					0
#define I2C_ERR_NOACK			-1
#define I2C_ERR_TIMEOUT			-2

#define I2C_POLLING_INTERVAL	10		/* in usecs */
#define I2C_MIN_WAIT_TIME		50		/* 50ms */

#define I2C_MAX_FIFO_SIZE		4


#define I2C_CHECK_INITED(dev)											\
	do{																	\
		if(dev == NULL) return -1;										\
		if (!dev->inited )												\
		{																\
			I2C_PRINT("I2C CH[%d] is not inited \n", dev->ch);			\
			return -1;													\
		}																\
	} while(0)


#define I2C_CHECK_PARAM(dev, alen, len) 													\
	do{																						\
		if ((alen > 4) || (len == 0) )														\
		{																					\
			I2C_PRINT("Invalid parameter in I2C CH[%d] : sub addr len=%d, buf len=%d\n",	\
				dev->ch, alen, len );														\
			return -1;																		\
		}																					\
	} while(0)


#define I2C_REG_WRITE(dev, reg, value)		(dev->reg_base->reg = value)
#define I2C_REG_READ(dev, reg)				(dev->reg_base->reg)



typedef enum
{
	I2C_NACK_LAST_BYTE         = 0x0010,	/* NACK last byte read from slave   */
	I2C_START_BEFORE_READ      = 0x0020,	/* During a read transaction, gen.  */
											/* a repeated START after writing   */
											/* the slave addr(just before read) */
	I2C_STOP_START_BEFORE_READ = 0x0040,	/* During a read transaction, gen.  */
											/* a STOP & START after writing     */
											/* the slave addr(just before read) */
} I2C_READ_OPTION;


/* I2CMS registers typedefined structure */
typedef struct I2C_REG
{
	volatile uint32_t I2CMMD;		/* Master Data Register */
	volatile uint32_t I2CMSSD;		/* Slave Data Register */
	volatile uint32_t I2CMSSA;		/* Slave Address Register */
	volatile uint32_t I2CMCTR0;		/* Control Register 0 */
	volatile uint32_t I2CMCTR1;		/* Control Register 1 */
	volatile uint32_t I2CMMS;		/* Master Status Register */
	volatile uint32_t I2CMSSS;		/* Slave Status Register */
	volatile uint32_t reserved;		/* Reserved */
	volatile uint32_t I2CMPREH;		/* Clock Pre-Scale Register High */
	volatile uint32_t I2CMPREL;		/* Clock Pre-Scale Register Low */
} I2C_REG_T;


typedef struct I2C_DEVICE
{
	uint8_t				ch;
	uint8_t				inited;
	uint32_t			clock;
	I2C_REG_T			*reg_base;
} I2C_DEVICE_T, *I2C_DEVICE_HANDLE;


#define I2C_NUM_DEVICE		(sizeof(_i2c_base_addr)/sizeof(unsigned long))

static unsigned long _i2c_base_addr[] = I2C_BASE;
static I2C_DEVICE_T _i2c_device[I2C_NUM_DEVICE];
static void I2C_SetClock(I2C_DEVICE_HANDLE dev, uint32_t clock);

#if USE_MULTI_THREAD
static mutex_t i2c_mutex[I2C_NUM_DEVICE];
#define I2C_INIT_LOCK(ch)	mutex_init(&i2c_mutex[ch])
#define I2C_LOCK(ch)		mutex_lock(&i2c_mutex[ch])
#define I2C_UNLOCK(ch)		mutex_unlock(&i2c_mutex[ch])
#else
#define I2C_INIT_LOCK(ch)	do{}while(0)
#define I2C_LOCK(ch)		do{}while(0)
#define I2C_UNLOCK(ch)		do{}while(0)
#endif

static uint32_t i2c_clk;

static I2C_DEVICE_HANDLE I2C_GetDevice(uint8_t ch)
{
	if(ch < I2C_NUM_DEVICE)
	{
		return &_i2c_device[ch];
	}

	I2C_PRINT("CH[%d] is not exist !!!\n", ch);
	return NULL;
}

static void I2C_Reset(I2C_DEVICE_HANDLE dev)
{
	I2C_REG_WRITE (dev, I2CMMD, SOFT_RESET);
}

int I2C_InitDevice(uint8_t ch)
{
	I2C_DEVICE_HANDLE dev = I2C_GetDevice(ch);

	if(dev == NULL)
		return -1;

	if(dev->inited)
	{
		I2C_PRINT("CH[%d] is already inited\n", ch);
		return -1;
	}

	if(ch >= I2C_NUM_DEVICE)
	{
		ERROR("Not supported ch[%d]\n",ch);
		return -1;
	}

	dev->reg_base = (I2C_REG_T*)_i2c_base_addr[ch];
	dev->ch = ch;
	dev->clock = 0;;

	I2C_Reset(dev);
	I2C_SetClock(dev, I2C_CLOCK_400KHZ);

	dev->inited = 1;
	return 0;
}

static void I2C_SetClock(I2C_DEVICE_HANDLE dev, uint32_t clock)
{
	uint16_t clockPrescale;
	uint32_t numerator;
	uint32_t mclock;

	if(dev->clock == clock)
		return;

	/* How to calculate the presacle value ? (�ܼ��� �����ϰ� ���� ������ ���� ���� �����Ѵ�.)
	 *  prescale = PCLK(MHZ) * 100 / i2c clock(KHZ)
	 *
	 * if pclk = 198MHz, i2c clock = 100Khz then
	 * prescale = 198 * 100 / 100 = 198 = 0xC6
	 *
	 * ����) prescale ���� ���� ���� i2c clock�� �� ũ��.
	 * �� �Ҽ��� ���Ͽ� ���Ͽ� ������ �� ��� �� ū clock ���� ������ �̿� ���� ������ �ʿ��ϴ�.
	 */
	switch(clock)
	{
		case I2C_CLOCK_50KHZ:	mclock = 45; break;
		case I2C_CLOCK_200KHZ:	mclock = 190; break;
		case I2C_CLOCK_400KHZ:	mclock = 380; break;
		case I2C_CLOCK_100KHZ:	mclock = 90; break;
		default:	mclock = clock*9/10; break;
	}

	numerator = (i2c_clk/MHZ) * 100;
	clockPrescale = (uint16_t)(numerator/mclock + ((numerator%mclock) ? 1 : 0));

	I2C_REG_WRITE (dev, I2CMPREH, MSB8(clockPrescale));
	I2C_REG_WRITE (dev, I2CMPREL, LSB8(clockPrescale));

	dev->clock = clock;
}

static int I2C_WaitForCompletion(I2C_DEVICE_HANDLE dev, uint8_t numBytes, uint8_t mode)
{
	uint8_t status;
	uint32_t timeout = (numBytes * 9)/dev->clock + I2C_MIN_WAIT_TIME;
	uint32_t count = (timeout * 1000) / I2C_POLLING_INTERVAL + 1;

	while(1)
	{
		status = I2C_REG_READ (dev, I2CMMS);

		if(status & MASTER_STAT_MIS)
		{
			uint8_t ctr0 = I2C_REG_READ(dev, I2CMCTR0);
			I2C_REG_WRITE(dev, I2CMCTR0, ctr0 | INT_ACK);
			break;
		}

		if(count == 0)
		{
			I2C_PRINT("I2C_WaitForCompletion.Timeout. I2C CH[%d]: status=0x%x !!!\n", dev->ch, status);
			return I2C_ERR_TIMEOUT;
		}

		loop_udelay(I2C_POLLING_INTERVAL);
		count--;
	}

	if(mode == I2C_WRITE_MODE)
	{
		if(status & MASTER_STAT_SNB)
		{
			I2C_PRINT("I2C_WaitForCompletion.No Ack in I2C CH[%d]. status=0x%x !!!\n", dev->ch, status);
			return I2C_ERR_NOACK;
		}

		if((status & MASTER_STAT_MFS))
		{
			I2C_PRINT("I2C_WaitForCompletion. Buffer is not empty. status=0x%x !!!\n", status);
		}
	}
	else
	{
		if((status & MASTER_STAT_MFS) != (numBytes << 5))
		{
			I2C_PRINT("I2C_WaitForCompletion. Buffer is not correct. status=0x%x !!!\n", status);
		}
	}

	return 0;
}

static int I2C_SendFifoData(I2C_DEVICE_HANDLE dev, uint8_t size, uint8_t ctr0)
{
	uint8_t ntb;

	switch(size)
	{
		case 1: ntb = NTB_1_BYTE; break;
		case 2: ntb = NTB_2_BYTE; break;
		case 3: ntb = NTB_3_BYTE; break;
		case 4: ntb = NTB_4_BYTE; break;
		default: return -1;
	}

	I2C_REG_WRITE (dev, I2CMCTR0, ntb | ctr0);

	//Wait for interrupt
	if(I2C_WaitForCompletion( dev, size, I2C_WRITE_MODE ) < 0)
	{
		return -1;
	}

	return 0;
}

static int I2C_ReceiveFifoData(I2C_DEVICE_HANDLE dev, uint8_t size, uint8_t ctr0)
{
	uint8_t ntb;

	switch(size)
	{
		case 1: ntb = NTB_1_BYTE; break;
		case 2: ntb = NTB_2_BYTE; break;
		case 3: ntb = NTB_3_BYTE; break;
		case 4: ntb = NTB_4_BYTE; break;
		default: return -1;
	}

	I2C_REG_WRITE (dev, I2CMCTR0, ntb | ctr0);

	//Wait for interrupt
	if(I2C_WaitForCompletion( dev, size, I2C_READ_MODE ) < 0)
	{
		return -1;
	}

	return 0;
}

#if (I2C_DEBUG > 0)
static uint32_t I2C_GetSubAddr(uint8_t subAddrSize, uint8_t *subAddr)
{
	uint32_t addr = 0;
	uint8_t index = 0;

	for(index=0; index<subAddrSize; index++)
		addr = (addr << 8) | subAddr[index];

	return addr;
}
#endif

static int I2C_ReadCmd(I2C_DEVICE_HANDLE dev, uint8_t slaveAddr, uint8_t subAddrSize, uint8_t *subAddr, uint8_t *buf, uint32_t bufSize, uint32_t flag)
{
	int res = -1;
	uint32_t index;
	uint8_t status;
	uint8_t fifoSize = 0;
	uint8_t sta = SET_START_SEQ;
	uint8_t ctr0;

	status = I2C_REG_READ (dev, I2CMMS);
	if((status & MASTER_STAT_MTB))
	{
		// If there's no interrupt in previous cmd then this status is happend, but have to ignore this.
		I2C_PRINT("I2C CH[%d]. master is busy... status=0x%x\n", dev->ch, status);
	}

	//Set the mode to master
	I2C_REG_WRITE (dev, I2CMCTR1,CLEAR_FIFOS |INT_ENABLE | CORE_ENABLE);

	if (subAddrSize > 0)
	{
		/* Send the slave address along with the write mode bit set */
		I2C_REG_WRITE (dev, I2CMMD, slaveAddr | I2C_WRITE_MODE);
		fifoSize++;

		for(index = 0; index<subAddrSize; index++)
		{
			//Write the register address to read from
			I2C_REG_WRITE (dev, I2CMMD, subAddr[index]);
			fifoSize++;

			if(fifoSize == 4 || (index+1) == subAddrSize)
			{
				ctr0 = INT_ACK | TRANSFER_GO;
				if((index+1) == subAddrSize)
				{
					if(flag & I2C_STOP_START_BEFORE_READ)
						ctr0 |= SET_STOP_SEQ;
					else if(flag & I2C_START_BEFORE_READ)
						ctr0 |= RESTART_SEQ;
				}

				if(sta)
				{
					ctr0 |= sta;
					sta = 0;
				}

				//Wait for interrupt
				if(I2C_SendFifoData(dev, fifoSize, ctr0) < 0)
				{
					I2C_PRINT("I2C CH[%d]: SlaveAddr=0x%02x, subAddrSize=%d, subAddr=0x%0x, bufSize=%d, index=%d\n",
						dev->ch, slaveAddr, subAddrSize, I2C_GetSubAddr(subAddrSize, subAddr), bufSize, index);
					goto end;
				}
				fifoSize = 0;
			}
		}


		/* Send the slave address along with the readmode bit set */
		I2C_REG_WRITE (dev, I2CMMD, slaveAddr | I2C_READ_MODE);

		ctr0 = INT_ACK | TRANSFER_GO;
		if( flag & (I2C_STOP_START_BEFORE_READ) )
			ctr0 |= SET_START_SEQ;

		I2C_REG_WRITE (dev, I2CMCTR0, ctr0);
	}
	else
	{
		/* Send the slave address along with the readmode bit set */
		I2C_REG_WRITE (dev, I2CMMD, slaveAddr | I2C_READ_MODE);
		I2C_REG_WRITE (dev, I2CMCTR0, INT_ACK | TRANSFER_GO | SET_START_SEQ);
	}

	if(I2C_WaitForCompletion( dev, 1, I2C_WRITE_MODE ) < 0)
	{
		I2C_PRINT("I2C CH[%d]: SlaveAddr=0x%02x, subAddrSize=%d, subAddr=0x%0x, bufSize=%d\n",
				dev->ch, slaveAddr, subAddrSize, I2C_GetSubAddr(subAddrSize, subAddr), bufSize);
		goto end;
	}

	/* Change the I2C ip to read mode to read from the slave */
	I2C_REG_WRITE (dev, I2CMCTR1, TRANS_MASTER_RX | INT_ENABLE | CORE_ENABLE | CLEAR_FIFOS);

	index = 0;
	while(index < bufSize)
	{
		if((index+I2C_MAX_FIFO_SIZE) < bufSize)
		{
			fifoSize = I2C_MAX_FIFO_SIZE;
			ctr0 = INT_ACK | TRANSFER_GO;
		}
		else
		{
			fifoSize = bufSize - index;
			ctr0 = INT_ACK | SET_STOP_SEQ | TRANSFER_GO;
		}

		if(I2C_ReceiveFifoData(dev, fifoSize, ctr0) < 0)
		{
			I2C_PRINT_ERROR("I2C CH[%d]: SlaveAddr=0x%02x, subAddrSize=%d, subAddr=0x%0x, bufSize=%d, index=%d\n",
				dev->ch, slaveAddr, subAddrSize, I2C_GetSubAddr(subAddrSize, subAddr), bufSize, index);
			goto end;
		}

		while(fifoSize--)
		{
			buf [index++] = I2C_REG_READ (dev, I2CMMD);
		}
	}

	res = bufSize;

end:
	return res;
}


static int I2C_WriteCmd(I2C_DEVICE_HANDLE dev, uint8_t slaveAddr, uint8_t subAddrSize, uint8_t *subAddr, uint8_t *buf, uint32_t bufSize, uint32_t flag)
{
	int res = -1;
	uint32_t index;
	uint8_t status;
	uint8_t fifoSize = 0;
	uint8_t sta = SET_START_SEQ;
	uint8_t ctr0;

	status = I2C_REG_READ (dev, I2CMMS);
	if((status & MASTER_STAT_MTB))
	{
		// If there's no interrupt in previous cmd then this status is happend, but have to ignore this.
		I2C_PRINT("I2C CH[%d]. master is busy... status=0x%x\n", dev->ch, status);
	}

	//Set the mode to master tx, clear fifos and enable int & core
	I2C_REG_WRITE (dev, I2CMCTR1, CLEAR_FIFOS |INT_ENABLE | CORE_ENABLE);

	/* Send the slave address along with the write mode bit set */
	I2C_REG_WRITE (dev, I2CMMD, slaveAddr | I2C_WRITE_MODE);
	fifoSize++;

	//Send sub address if it has.
	if(subAddrSize > 0)
	{
		for(index = 0; index<subAddrSize; index++)
		{
			//Write the register address to write
			I2C_REG_WRITE (dev, I2CMMD, subAddr[index]);
			fifoSize++;

			if(fifoSize == I2C_MAX_FIFO_SIZE)
			{
				ctr0 = INT_ACK | TRANSFER_GO;
				if(sta)
				{
					ctr0 |= sta;
					sta = 0;
				}

				if(I2C_SendFifoData(dev, I2C_MAX_FIFO_SIZE, ctr0) < 0)
				{
					I2C_PRINT("I2C CH[%d]: SlaveAddr=0x%02x, subAddrSize=%d, subAddr=0x%0x, bufSize=%d, index=%d\n",
									dev->ch, slaveAddr, subAddrSize, I2C_GetSubAddr(subAddrSize, subAddr), bufSize, index);
					goto end;
				}
				fifoSize = 0;
			}
		}
	}

	/* Send the data here */
	for(index = 0; index<bufSize; index++)
	{
		//Write the data
		I2C_REG_WRITE (dev, I2CMMD, buf[index]);
		fifoSize++;

		if(fifoSize == 4 || (index+1) == bufSize)
		{
			if((index+1) == bufSize)
				ctr0 = INT_ACK | TRANSFER_GO | SET_STOP_SEQ;
			else
				ctr0 = INT_ACK | TRANSFER_GO;

			if(sta)
			{
				ctr0 |= sta;
				sta = 0;
			}

			//Wait for interrupt
			if(I2C_SendFifoData(dev, fifoSize, ctr0) < 0)
			{
				I2C_PRINT_ERROR("I2C CH[%d]: SlaveAddr=0x%02x, subAddrSize=%d, subAddr=0x%0x, bufSize=%d, index=%d\n",
					dev->ch, slaveAddr, subAddrSize, I2C_GetSubAddr(subAddrSize, subAddr), bufSize, index);
				goto end;
			}
			fifoSize = 0;
		}
	}
	res = bufSize;

end:

	return res;
}


int i2c_init(void)
{
	static int inited = 0;
	int i;

	if(inited) return 0;

	i2c_clk = get_clk(CLK_DEV_I2C);

	for(i=0; i<I2C_NUM_DEVICE; i++)
	{
		I2C_INIT_LOCK(i);
		I2C_InitDevice(i);
	}

	inited = 1;
	return 0;
}

int i2c_set_clock(uint8_t ch, uint32_t clock)
{
	I2C_DEVICE_HANDLE dev = I2C_GetDevice(ch);
	I2C_CHECK_INITED(dev);

	I2C_LOCK(dev->ch);
	I2C_SetClock(dev, clock);
	I2C_UNLOCK(dev->ch);

	return 0;
}

int i2c_write(uint8_t ch, uint16_t slave, uint32_t addr, int alen, uint8_t *buf, int len, uint32_t flag )
{
	int rc;
	int i, shift;
	uint8_t sub_addr[4];
	I2C_DEVICE_HANDLE dev = I2C_GetDevice(ch);

	I2C_CHECK_INITED(dev);
	I2C_CHECK_PARAM(dev, alen, len);

	shift = alen;
	for(i=0; i<alen; i++)
	{
		shift--;
		sub_addr[i] = (addr >> (8*shift)) & 0xFF;
	}
	I2C_LOCK(dev->ch);
	rc = I2C_WriteCmd(dev, slave, alen, sub_addr, buf, len, 0);
	I2C_UNLOCK(dev->ch);

	return rc;
}

int i2c_read(uint8_t ch, uint16_t slave, uint32_t addr, int alen, uint8_t *buf, int len, uint32_t flag)
{
	int rc;
	int i, shift;
	uint8_t sub_addr[4];
	I2C_DEVICE_HANDLE dev = I2C_GetDevice(ch);

	I2C_CHECK_INITED(dev);
	I2C_CHECK_PARAM(dev, alen, len);

	shift = alen;
	for(i=0; i<alen; i++)
	{
		shift--;
		sub_addr[i] = (addr >> (8*shift)) & 0xFF;

	}

	I2C_LOCK(dev->ch);
	rc = I2C_ReadCmd(dev, slave, alen, sub_addr, buf, len, I2C_START_BEFORE_READ);
	I2C_UNLOCK(dev->ch);

	return rc;
}

#endif	/* #ifdef USE_DTVSOC_I2C */
