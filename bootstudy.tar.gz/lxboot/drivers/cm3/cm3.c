/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifdef USE_PMS
#if (CONFIG_ARCH == ARCH_LG1210)
#include <types.h>
#include <debug.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <command.h>
#include <util.h>
#include <partinfo.h>
#include <emmc.h>
#include <storage.h>
#include <env.h>
#include <console.h>

/*****************************************************************************************/
// DEFINES
/*****************************************************************************************/
#define PMS_FW_SHADOW_MAGIC_1	0x706d6677		// 0~3
#define PMS_FW_SHADOW_MAGIC_2	0x73686472		// 4~7
#define PMS_FW_MAGIC            0x141106A0		// 8~11
#define PMS_FW_SECURE_FLAG		0x75636573		// 12~15

#define PMS_FW_HEADER_SIZE		512

#define PMS_PARTITION						"pmsfw"

#define CM3_DEBUGPRINT						0
#if CM3_DEBUGPRINT
#define CM3_DEBUG_PRINT(fmt, args...)		printf(fmt, ##args)
#else
#define CM3_DEBUG_PRINT(fmt, args...)		do{}while(0)
#endif

#define CM3_BIT_READ(addr, bit)				((*(volatile unsigned int*)((unsigned long)addr) >> bit) & 0x1)
#define CM3_BIT_SET(addr, bit)				*(volatile unsigned int*)((unsigned long)addr) |= (1 << bit)
#define CM3_BIT_CLEAR(addr, bit)			*(volatile unsigned int*)((unsigned long)addr) &= ~(1 << bit)
#define CM3_REG_READ(addr)					*(volatile unsigned int*)((unsigned long)addr)
#define CM3_REG_WRITE(addr,value)			*(volatile unsigned int*)((unsigned long)addr) = (value)

#define CPU_NOP				0xaa000000
#define CPU_FS				0xaa000001
#define CPU_VS				0xaa000002
#define CPU_PWR				0xaa000004
#define CPU_DVFS_READY		0xaa001000

#define PMS_RES				0xaa000100
#define PMS_DVFS			0xaa000010
#define PMS_DVFS_DONE		0xaa000020

#define GPU_FS				0x55000001
#define GPU_VS				0x55000002
#define GPU_PMS_RES			0x55000005

#define CM3FW_BASE_ADDRESS	0xC1000000
#define CM3FW_RUN_STOP		0xC103F000	//  0:STALL, 1:RUN
#define CM3FW_UART_MUX		0xc8601084	// 0x22508000


#define CM3_IRQ_BASE	0xC1020110
#define CM3_IPC_BASE	0xC1013E00
#define CA15_CMD		CM3_IPC_BASE
#define CA15_RESP		(CM3_IPC_BASE + 0x20)
#define TZ_CMD			(CM3_IPC_BASE + 0x40)
#define TZ_RESP			(CM3_IPC_BASE + 0x60)
#define GPU_CMD			(CM3_IPC_BASE + 0x80)
#define GPU_RESP		(CM3_IPC_BASE + 0xA0)

#define PMS_INFO_BASE	(CM3_IPC_BASE + 0xC0)

#define TEST_MODE_DVFS			1
#define TEST_MODE_HOTPLUG		2

#define TEST_CPU1_ON			0
#define TEST_CPU1_OFF			1


/*****************************************************************************************/
// VARIABLES
/*****************************************************************************************/
static unsigned int cm3_inited = 0;

static volatile unsigned int kernel_pms_enable = 1;
static volatile unsigned int kernel_pms_gdetect = 0;
static volatile unsigned int cpu_freq = 0;
static volatile unsigned int cpu_vol = 0;
static volatile unsigned int gpu_freq = 0;
static volatile unsigned int gpu_vol = 0;
static volatile unsigned int cmd_count = 0;

/*****************************************************************************************/
// DECLARATIONS
/*****************************************************************************************/
//unsigned int load_firmware_check(void);


/*****************************************************************************************/
// MAIN
/*****************************************************************************************/
int load_pms_config(void)
{
	char *cm3char;
	char *endptr;

	cm3char = env_get(ENV_PMS_ENABLE);
	if (cm3char)
	{
		kernel_pms_enable = strtoul(cm3char, &endptr, 0);
	}

	cm3char = env_get(ENV_CPUFREQ);
	if (cm3char)
	{
		cpu_freq = strtoul(cm3char, &endptr, 0);
	}

	cm3char = env_get(ENV_CPUVOL);
	if (cm3char)
	{
		cpu_vol = strtoul(cm3char, &endptr, 0);
	}

	cm3char = env_get(ENV_GPUFREQ);
	if (cm3char)
	{
		gpu_freq = strtoul(cm3char, &endptr, 0);
	}

	cm3char = env_get(ENV_GPUVOL);
	if (cm3char)
	{
		gpu_vol = strtoul(cm3char, &endptr, 0);
	}

	cm3char = env_get(ENV_GDETECT);
	if (cm3char)
	{
		kernel_pms_gdetect = strtoul(cm3char, &endptr, 0);
	}

	return 0;
}

int get_pms_enable(void)
{
	return kernel_pms_enable;
}

int get_pms_gdetect(void)
{
	return kernel_pms_gdetect;
}

int get_pms_tfreq(void)
{
	return cpu_freq;
}

int get_pms_tvol(void)
{
	return cpu_vol;
}

static void dump_ipc_mem(void)
{
	unsigned int i = 0;

	printf("0xF7083E00 : 0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X\n",	CM3_REG_READ(CA15_CMD + ((i++)*4)));


	printf("0xF7083E20 : 0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X ",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
	printf("0x%08X\n",	CM3_REG_READ(CA15_CMD + ((i++)*4)));
}

unsigned int send_cmd_to_cm3_ver3(unsigned int cmd,unsigned int freq,unsigned int vol, unsigned int cpu, unsigned int flag)
{
	unsigned int cm3resp_header;
	unsigned int cm3resp_key;
 	unsigned int cm3_intr_flag;
	u32 start_tick;

//	CM3_REG_WRITE(CM3_IRQ_BASE+0x04, 0xfc);

	CM3_REG_WRITE(CA15_CMD, cmd);
	CM3_REG_WRITE(CA15_CMD+0x4, freq);
	CM3_REG_WRITE(CA15_CMD+0x8, vol);
	CM3_REG_WRITE(CA15_CMD+0xC, cpu);
	CM3_REG_WRITE(CA15_CMD+0x10, 0);
	CM3_REG_WRITE(CA15_CMD+0x14, flag);
	CM3_REG_WRITE(CA15_CMD+0x18, 0);
	CM3_REG_WRITE(CA15_CMD+0x1C, ++cmd_count);

	CM3_BIT_SET(CM3_IRQ_BASE, 0);

	start_tick = timer_tick();
	while(1)
	{
		cm3resp_header = CM3_REG_READ(CA15_RESP);
		cm3resp_key = CM3_REG_READ(CA15_RESP + 0x1C);

		if ((cm3resp_header == PMS_RES) && (cm3resp_key == cmd_count))
			break;

		if(timer_elapsed(start_tick) > 1000*1000)
		{
			while (1)
			{
				printf("CM3 RESPONSE TIMEOUT\n");
				printf("CM3 resp_header 0x%08X\n",cm3resp_header);
				printf("CM3 resp_key 0x%08X\n",cm3resp_key);
				printf("CM3 request_key 0x%08X\n",cmd_count);
				dump_ipc_mem();
				mdelay(100);
			}
		}
	}

	start_tick = timer_tick();
	while (1)
	{
		cm3_intr_flag =  CM3_REG_READ(CM3_IRQ_BASE);
		if ((cm3_intr_flag & 0x1) == 0)
			break;

		if(timer_elapsed(start_tick) > 1000*1000)
		{
			while (1)
			{
				printf("CM3 INTR CLEAR TIMEOUT\n");
				dump_ipc_mem();
				mdelay(100);
			}
		}
	}

	if (cmd == CPU_FS)
		return (CM3_REG_READ(CA15_RESP + 0x4) / KHZ);

	if (cmd == CPU_VS)
		return (CM3_REG_READ(CA15_RESP + 0x8) / 1000);


	return 0;
}

unsigned int send_gpucmd_to_cm3_ver3(unsigned int cmd,unsigned int freq,unsigned int vol)
{
	unsigned int cm3resp_header;
	unsigned int cm3resp_key;
	unsigned int cm3_intr_flag;

//	CM3_REG_WRITE(CM3_IRQ_BASE+0x04, 0xfc);

	CM3_REG_WRITE(GPU_CMD, cmd);
	CM3_REG_WRITE(GPU_CMD+0x4, freq);	// Khz
	CM3_REG_WRITE(GPU_CMD+0x8, vol);	//uV
	CM3_REG_WRITE(GPU_CMD+0xC, 0);
	CM3_REG_WRITE(GPU_CMD+0x10, 0);
	CM3_REG_WRITE(GPU_CMD+0x14, 0);
	CM3_REG_WRITE(GPU_CMD+0x18, 0);
	CM3_REG_WRITE(GPU_CMD+0x1C, ++cmd_count);

	CM3_BIT_SET(CM3_IRQ_BASE, 1);

	mdelay(100);
	while(1)
	{
		cm3resp_header = CM3_REG_READ(GPU_RESP);
		cm3resp_key = CM3_REG_READ(GPU_RESP + 0x1C);

		if ((cm3resp_header == GPU_PMS_RES) && (cm3resp_key == cmd_count))
			break;
	}

	while (1)
	{
		cm3_intr_flag =  CM3_REG_READ(CM3_IRQ_BASE);
		if ((cm3_intr_flag & 0x2) == 0)
			break;
	}

	if (cmd == GPU_FS)
		return (CM3_REG_READ(GPU_RESP + 0x4) / KHZ);

	if (cmd == GPU_VS)
		return (CM3_REG_READ(GPU_RESP + 0x8) / 1000);

	return 0;
}

unsigned int send_cmd_to_cm3(unsigned int cmd,unsigned int freq,unsigned int vol, unsigned int cpu, unsigned int flag)
{
	unsigned int ret = 0;

	ret = send_cmd_to_cm3_ver3(cmd, freq*KHZ, vol*1000, cpu ,flag);

	return ret;
}

unsigned int send_gpucmd_to_cm3(unsigned int cmd,unsigned int freq,unsigned int vol)
{
	unsigned int ret = 0;

	ret = send_gpucmd_to_cm3_ver3(cmd, freq*KHZ, vol * 1000);

	return ret;
}

unsigned int load_firmware_check(void)
{
	unsigned int i = 0;

	CM3_REG_WRITE(PMS_INFO_BASE + 0x3C, 0x0);
	while (1)
	{
		if (CM3_REG_READ(PMS_INFO_BASE + 0x3C) > 0)
		{
			printf("PMS Firmeare version 0x%X\n",REG_READ(PMS_INFO_BASE));
			return  0;
		}

		mdelay(10);

		i++;

		if (i > 20)
			break;
	}

	return 1;
}

static void* load_cm3fw(void)
{
	extern u8 cm3_bin_start[];
	u8 *pcm3_start;

	pcm3_start = cm3_bin_start;

	return (void *)pcm3_start;
}

void check_pmsfw_partition(void)
{
	storage_partition_t partition;
	uint32_t			offset;
	uint32_t			temp[512/4];
	unsigned int 		*cm3fw_buff;
	unsigned int 		*crc_buff;
	unsigned int		crc;
	unsigned int		i;
	unsigned int		pmsfw_write = 0;

	cm3fw_buff = load_cm3fw();

	if(storage_get_partition(PMS_PARTITION, &partition) >= 0)
	{
		crc = 0;
		crc_buff = cm3fw_buff + (PMS_FW_HEADER_SIZE / 4);
		for (i=0; i<(65536/4); i++)
		{
			crc ^= crc_buff[i];
		}

		offset = partition.offset;
		if(storage_read(offset, 512, (void *)temp) == 512)
		{
			if ((temp[0] != PMS_FW_SHADOW_MAGIC_1) || (temp[1] != PMS_FW_SHADOW_MAGIC_2) ||
				(temp[2] != PMS_FW_MAGIC) || (temp[3] != PMS_FW_SECURE_FLAG))
			{
				pmsfw_write = 1;
				printf("PMS Firmware HEADER is none\n");
			}

			if (crc != temp[8])
			{
				pmsfw_write = 1;
				printf("PMS Firmware CRC value is broken\n");
			}
		}

		if (pmsfw_write)
		{
			storage_write(offset, 0x10000 + 512, (void *)cm3fw_buff);

			memset(temp, 0x0, 512);
			memcpy(temp, (void *)cm3fw_buff, 512);

			temp[0] = PMS_FW_SHADOW_MAGIC_1;
			temp[1] = PMS_FW_SHADOW_MAGIC_2;
			temp[2] = PMS_FW_MAGIC;
			temp[3] = PMS_FW_SECURE_FLAG;
			temp[8] = crc;
			storage_write(offset, 512, (void *)temp);

			printf("PMS Firmware write pmsfw partition\n");
		}
	}
}

void preload_pms_firmware(void)
{
	unsigned int *cm3fw_buff;

	if (load_firmware_check() == 0)
	{
		printf("PMS Firmware already loaded!\n");
		cm3_inited = 1;
		goto PMSFW_WRITE;
	}

	// CM3 STOP
	CM3_REG_WRITE(CM3FW_RUN_STOP, 0);

	// COPY CM3 FIRMWARE TO CM3 INTERNAL DDR DRAM
	cm3fw_buff = (load_cm3fw() + 512);
	memcpy((void *)CM3FW_BASE_ADDRESS, cm3fw_buff, 0x10000);

	// LIVE WORD CLEAR
	CM3_REG_WRITE(PMS_INFO_BASE, 0x0);
	CM3_REG_WRITE(PMS_INFO_BASE + 0X3C, 0x0);

	// CM3 RUN
	CM3_REG_WRITE(CM3FW_RUN_STOP, 1);

	if (load_firmware_check() == 0)
	{
		printf("PMS Firmware Load\n");
		cm3_inited = 2;
	}
	else
	{
		ERROR("PMS Firmware Load Fail!\n");
	}

PMSFW_WRITE:
	// UARTMUX CHANGE
	CM3_REG_WRITE(CM3FW_UART_MUX, 0x22508000);

	check_pmsfw_partition();
}

int load_pms_firmware(void)
{
	unsigned int ret = 0;

	check_pmsfw_partition();

	if (cm3_inited == 0)
	{
		printf("PMS Firmware Don't Load pms system not working\n");
	}

	if ((cpu_freq == 0) && (cpu_vol == 0) && (gpu_freq == 0) && (gpu_vol == 0))
	{
		return 0;
	}

	printf("==================================================\n");
	if (cpu_freq)
	{
		send_cmd_to_cm3(CPU_VS,0,1200,0x0,0x0);
		ret = send_cmd_to_cm3(CPU_FS,cpu_freq,0,0x0,0x0);
		printf("CPU CLOCK = %u Mhz\n",ret);
	}

	if (cpu_vol)
	{
		ret = send_cmd_to_cm3(CPU_VS,0,cpu_vol,0x0,0x0);
		printf("CPU VOL = %u mv\n",ret);
	}

	if (gpu_freq)
	{
		  ret = send_gpucmd_to_cm3(GPU_FS,gpu_freq,0);
		  printf("GPU FREQ = %u Mhz\n",ret);
	}

	if (gpu_vol)
	{
		ret = send_gpucmd_to_cm3(GPU_VS,0,gpu_vol);
		printf("GPU VOL = %u mv\n",ret);
	}
	printf("==================================================\n");

	return 0;
}
#endif
#else
int load_pms_config(void)
{
	return 0;
}

int get_pms_enable(void)
{
	return 1;
}

int get_pms_gdetect(void)
{
	return 0;
}

int get_pms_tfreq(void)
{
	return 0;
}

int get_pms_tvol(void)
{
	return 0;
}

void preload_pms_firmware(void)
{
	return;
}

int load_pms_firmware(void)
{
	return 0;
}
#endif

