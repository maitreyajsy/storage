#include <types.h>
#include <serial.h>

#include "pl011.h"

#ifndef PL011_UART_BASE
#error "Have to define the uart port base address !!!"
#endif

static ulong port[] = PL011_UART_BASE;
static uint32_t uart_clk;

static void pl011_set_baudrate(uint32_t portnum, uint32_t baudrate)
{
	unsigned int temp;
	unsigned int divider;
	unsigned int remainder;
	unsigned int fraction;

	/*
	 * Set baud rate
	 *
	 * IBRD = UART_CLK / (16 * BAUD_RATE)
	 * FBRD = ROUND((64 * MOD(UART_CLK,(16 * BAUD_RATE))) / (16 * BAUD_RATE))
	 */

	temp = 16 * baudrate;
	divider = uart_clk / temp;
	remainder = uart_clk % temp;
	temp = (8 * remainder) / baudrate;
	fraction = (temp >> 1) + (temp & 1);

	IO_WRITE (port[portnum] + UART_PL011_IBRD, divider);
	IO_WRITE (port[portnum] + UART_PL011_FBRD, fraction);

}

static void pl011_enable(uint32_t portnum)
{
	IO_WRITE (port[portnum] + UART_PL011_CR,
			(UART_PL011_CR_UARTEN | UART_PL011_CR_TXE | UART_PL011_CR_RXE));
}

static void pl011_disable(uint32_t portnum)
{
	IO_WRITE (port[portnum] + UART_PL011_CR, 0x0);
}

static void pl011_putc(uint32_t portnum, char c)
{
	/* Wait until there is space in the FIFO */
	while (IO_READ (port[portnum] + UART_PL01x_FR) & UART_PL01x_FR_TXFF);

	/* Send the character */
	IO_WRITE (port[portnum] + UART_PL01x_DR, c);
}

static int	pl011_check_rx(uint32_t portnum)
{
	if(IO_READ (port[portnum] + UART_PL01x_FR) & UART_PL01x_FR_RXFE)
		return 0;

	return 1;
}

static int pl011_getc(uint32_t portnum)
{
	uint32_t data;

#if 0
	/* Wait until there is data in the FIFO */
	while (IO_READ (port[portnum] + UART_PL01x_FR) & UART_PL01x_FR_RXFE);
#else
	if(IO_READ (port[portnum] + UART_PL01x_FR) & UART_PL01x_FR_RXFE)
		return -1;
#endif

	data = IO_READ (port[portnum] + UART_PL01x_DR);

	/* Check for an error flag */
	if (data & 0xFFFFFF00)
	{
		/* Clear the error */
		IO_WRITE (port[portnum] + UART_PL01x_ECR, 0xFFFFFFFF);
		return -1;
	}

	return (int)data;
}

static void pl011_init(uint32_t portnum, uint32_t baudrate)
{
	uart_clk = get_clk(CLK_DEV_UART);

	/* Disable UART */
	pl011_disable(portnum);

	/* Set baud rate */
	pl011_set_baudrate(portnum, baudrate);

	/* Configure UART to be 8 bits, 1 stop bit, no parity, fifo enabled. */
	IO_WRITE (port[portnum] + UART_PL011_LCRH, (UART_PL011_LCRH_WLEN_8 | UART_PL011_LCRH_FEN));

	/* Enable UART */
	pl011_enable(portnum);
}


static serial_driver_t pl011_driver =
{
	.init = pl011_init,
	.set_baudrate = pl011_set_baudrate,
	.enable = pl011_enable,
	.disable = pl011_disable,
	.putchar = pl011_putc,
	.check_rx = pl011_check_rx,
	.getchar = pl011_getc,
};

serial_driver_t* get_serial_driver(void)
{
	return &pl011_driver;
}

