
#include <types.h>
#include "dtvsoc_nfc.h"

#if USE_NAND
nfc_conf_t nfc_conf_default =
{
	0x00230001,		//nand_class.	ex) 0x00220001 : Cycle 22 Type 1
	0x800,			//page_size.	one page size
	64,				//block_pages.	pages per block
	0,
#if 0
	5000,			//nand_tr.		data transfer time from cell to register
	5,				//nand_trea.	RE access time
	2,				//nand_talh.	ALE(Address Latch Enable) hold time
	4,				//nand_div_trp.	clock divider value for read enable low pulse width
	7,				//nand_div_trc.	clock divider value for read cycle time
	16,				//nand_tadl.	address to data loading time
	7				//nand_div_twp.	clock divider value for write enable low pulse width
#else
	42100,			//nand_tr.		data transfer time from cell to register
	9,				//nand_trea.	RE access time
	3,				//nand_talh.	ALE(Address Latch Enable) hold time
	11,				//nand_div_trp. clock divider value for read enable low pulse width
	16,				//nand_div_trc. clock divider value for read cycle time
	26, 			//nand_tadl.	address to data loading time
	11				//nand_div_twp. clock divider value for write enable low pulse width
#endif
};

static nfc_conf_t nfc_conf_NAND08Gx3BxC =
{
	0x00230001,		//nand_class.	ex) 0x00220001 : Cycle 22 Type 1
	0x800,			//page_size.	one page size
	64,				//block_pages.	pages per block
	0,

	5000,			//nand_tr.		data transfer time from cell to register
	5,				//nand_trea.	RE access time
	2,				//nand_talh.	ALE(Address Latch Enable) hold time
	4,				//nand_div_trp.	clock divider value for read enable low pulse width
	7,				//nand_div_trc.	clock divider value for read cycle time
	16,				//nand_tadl.	address to data loading time
	7				//nand_div_twp.	clock divider value for write enable low pulse width
};

static nfc_conf_t nfc_conf_K9F8G08UxM =
{
	0x00230001,		//nand_class.	ex) 0x00220001 : Cycle 22 Type 1
	0x800,			//page_size.	one page size
	64,				//block_pages.	pages per block
	0,

	5000,			//nand_tr.		data transfer time from cell to register
	5,				//nand_trea.	RE access time
	2,				//nand_talh.	ALE(Address Latch Enable) hold time
	4,				//nand_div_trp.	clock divider value for read enable low pulse width
	7,				//nand_div_trc.	clock divider value for read cycle time
	16,				//nand_tadl.	address to data loading time
	7				//nand_div_twp.	clock divider value for write enable low pulse width
};

/* Toshiba NAND 1GB */
static nfc_conf_t nfc_conf_TC58DVG3S =
{
	0x00230001, 	//nand_class.	ex) 0x00220001 : Cycle 22 Type 1
	0x1000, 		//page_size.	one page size
	64, 			//block_pages.	pages per block
	0,

#if (CONFIG_CHIP < CHIP_LG1152_A0)
	5050,			//nand_tr.		data transfer time from cell to register
	4,				//nand_trea.	RE access time
	1,				//nand_talh.	ALE(Address Latch Enable) hold time
	3,				//nand_div_trp. clock divider value for read enable low pulse width
	5,				//nand_div_trc. clock divider value for read cycle time
	17, 			//nand_tadl.	address to data loading time
	3				//nand_div_twp. clock divider value for write enable low pulse width
#elif (CONFIG_CHIP == CHIP_LG1152_A0)
	6060,			//nand_tr.		data transfer time from cell to register
	6,				//nand_trea.	RE access time
	2,				//nand_talh.	ALE(Address Latch Enable) hold time
	4,				//nand_div_trp. clock divider value for read enable low pulse width
	7,				//nand_div_trc. clock divider value for read cycle time
	21, 			//nand_tadl.	address to data loading time
	4				//nand_div_twp. clock divider value for write enable low pulse width
#endif
};


/* Toshiba NAND 1GB */
static nfc_conf_t nfc_conf_SPENSOR =
{
	0x00230001, 	//nand_class.	ex) 0x00220001 : Cycle 22 Type 1
	0x800,			//page_size.	one page size
	64, 			//block_pages.	pages per block
	0,
#if 1
	5000,			//nand_tr.		data transfer time from cell to register
	5,				//nand_trea.	RE access time
	2,				//nand_talh.	ALE(Address Latch Enable) hold time
	4,				//nand_div_trp. clock divider value for read enable low pulse width
	7,				//nand_div_trc.	clock divider value for read cycle time
	16,				//nand_tadl.	address to data loading time
	7				//nand_div_twp.	clock divider value for write enable low pulse width
#else
	42100,			//nand_tr.		data transfer time from cell to register
	9,				//nand_trea.	RE access time
	3,				//nand_talh.	ALE(Address Latch Enable) hold time
	11, 			//nand_div_trp. clock divider value for read enable low pulse width
	16, 			//nand_div_trc. clock divider value for read cycle time
	26, 			//nand_tadl.	address to data loading time
	11				//nand_div_twp. clock divider value for write enable low pulse width
#endif

};

static nfc_conf_t nfc_conf_HYNIX =
{
	0x00220001, 	//nand_class.	ex) 0x00220001 : Cycle 22 Type 1
	0x800,			//page_size.	one page size
	64, 			//block_pages.	pages per block
	0,
#if 0
	5000,			//nand_tr.		data transfer time from cell to register
	5,				//nand_trea.	RE access time
	2,				//nand_talh.	ALE(Address Latch Enable) hold time
	4,				//nand_div_trp. clock divider value for read enable low pulse width
	7,				//nand_div_trc.	clock divider value for read cycle time
	16,				//nand_tadl.	address to data loading time
	7				//nand_div_twp.	clock divider value for write enable low pulse width
#else
	42100,			//nand_tr.		data transfer time from cell to register
	9,				//nand_trea.	RE access time
	3,				//nand_talh.	ALE(Address Latch Enable) hold time
	11, 			//nand_div_trp. clock divider value for read enable low pulse width
	16, 			//nand_div_trc. clock divider value for read cycle time
	26, 			//nand_tadl.	address to data loading time
	11				//nand_div_twp. clock divider value for write enable low pulse width
#endif

};


#define NAND_ID_SIGNATURE(a,b,c,d)		(a << 24 | b << 16 | c << 8 | d)
struct nfc_conf_id nfc_conf_ids[] =
{
	{NAND_ID_SIGNATURE(0x20, 0xD3, 0x51, 0x95), &nfc_conf_NAND08Gx3BxC	},
	{NAND_ID_SIGNATURE(0x20, 0xA3, 0x51, 0x15), &nfc_conf_NAND08Gx3BxC	},

	{NAND_ID_SIGNATURE(0xEC, 0xD3, 0x10, 0xA6), &nfc_conf_K9F8G08UxM	},
	{NAND_ID_SIGNATURE(0x98, 0xD3, 0x90, 0x26), &nfc_conf_TC58DVG3S		},

	{NAND_ID_SIGNATURE(0x01, 0xAC, 0x90, 0x15), &nfc_conf_SPENSOR		},
	{NAND_ID_SIGNATURE(0xad, 0xf1, 0x80, 0x1d), &nfc_conf_HYNIX		},

	{0,											&nfc_conf_default		},	// default
};
#endif
