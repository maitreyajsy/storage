#include <types.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <interrupt.h>
#include <nand.h>
#include <util.h>
#include <malloc.h>
#include <system.h>

#include "dtvsoc_nfc.h"
#include "dtvsoc_nand.h"

#if USE_NAND
#define NFC_BLKERASE_TIMEOUT		50		/* 50ms */
#define NFC_PROGRAM_TIMEOUT			10		/* 10ms */
#define NFC_WAITQUEUE_TIMEOUT		100		/* 100ms */
#define NFC_READ_TIMEOUT			10		/* 10ms */
#define NFC_RESET_TIMEOUT			100

typedef struct dtvsoc_nand_cmd {
	u32 	cmd:	9;
	u32 	rnw:	1;
	u32 	ecc:	1;
	u32 	hold:	1;
	u32 	wp:		3;
	u32 	intl:	1;
	u32 	tag:	8;
	u32 	rnb:	1;
	u32 	readst: 2;
	u32 	intr:	1;
	u32 	prio:	1;
	u32 	chip:	3;

	u16		oob_size;
	u16		data_size;
	u32		data_addr;
	u32		oob_addr;
	u32		row;
	u32		col;
}dtvsoc_nand_cmd_t;


#if USE_NAND_IRQ
typedef struct nand_irq_status
{
	u32 int_flag;

	u32 err_cnt;
	u32 ecc_fail;

	// nand write status value
	u32 status;


} nand_irq_status_t;

static volatile nand_irq_status_t _nand_irq_status;
static nand_irq_callback_t _nand_irq_callback;
#endif

volatile static u8 _nand_cmd_tag;

static u8 _nand_tag(void)
{
	return ++_nand_cmd_tag;
}

static u32 _nand_readl(u32 off)
{
	volatile u32 *p;
	p = (volatile u32 *)((ulong)(NFC_BASE + off));
	return *p;
}

static void _nand_writel(u32 off, u32 const *buf, size_t cnt)
{
	volatile u32 *p;
	size_t i;

	p = (u32 *)((ulong)(NFC_BASE + off));

	for(i = 0; i < cnt; ++i)
		p[i] = buf[i];
}

static void _nand_queue_cmd(const dtvsoc_nand_cmd_t *cmd)
{
	timeout_id_t tid;

	set_timeout(&tid, NFC_WAITQUEUE_TIMEOUT);
	/* wait for command queue available */
	while((_nand_readl(CMDQCNT) & 0x03) == 3)
	{
		loop_udelay(1);
		if(is_timeout(&tid))
		{
			NAND_ERROR("_nand_queue_cmd: wait timeout !!!\n");
			return;
		}
	}

	_nand_writel(CMDQ, (u32 const *)cmd, sizeof(struct dtvsoc_nand_cmd) / sizeof(u32));
}

#if USE_NAND_IRQ
static void _nand_interrupt_control(int enable)
{
	u32 ctrl;

	ctrl = (enable == ON) ? 1 : 0;
	_nand_writel(INTRCTRL, &ctrl, 1);
}


static void _nand_interrupt_handler(void* arg)
{
	volatile u32 stat, tag;

	_nand_interrupt_control(OFF);

	stat = _nand_readl(INTRSTAT);
	if(!(stat&(INT_STAT_MAIN|INT_STAT_ERROR)))
		return;

	if((stat&INT_STAT_RCMD))
	{
		do {
			tag = _nand_readl(RDCMDTAG);

			if(RDCMDTAG_ECCFAIL(tag))
				_nand_irq_status.ecc_fail++;

			if(RDCMDTAG_BITERRS(tag))
				_nand_irq_status.err_cnt++;

		} while(!RDCMDTAG_INTR(tag));

		_nand_irq_status.int_flag++;

		if(_nand_irq_callback.handler)
		{
			_nand_irq_callback.handler(_nand_irq_callback.arg, _nand_irq_status.ecc_fail);
		}
	}

	if((stat&(INT_STAT_WCMD | INT_STAT_WECMD)))
	{
		if((stat&INT_STAT_WECMD))
			tag = _nand_readl(WREMDTAG);
		else
			tag = _nand_readl(WRCMDTAG);

		_nand_irq_status.int_flag++;
		_nand_irq_status.status = WRCMDTAG_STAT(tag);
	}

	_nand_interrupt_control(ON);
}

static void _nand_interrupt_clear(void)
{
	memset((void*)&_nand_irq_status, 0, sizeof(_nand_irq_status));
}

static int _nand_wait_interrupt(int timeout)
{
	timeout_id_t tid;

	set_timeout(&tid, timeout);

	while(_nand_irq_status.int_flag == 0)
	{
		if(timeout == 0) break;
		else if(is_timeout(&tid))
		{
			NAND_ERROR("timeout[%dus]\n", timeout);
			return DTVSOC_NAND_ERR_TIMEOUT;
		}
		loop_udelay(1);
	}

	return 0;
}
#endif

static int _nand_wait_reading(const dtvsoc_nand_cmd_t *cmd, int timeout)
{
#if USE_NAND_IRQ
	if(cmd->intr == ON)
	{
		_nand_wait_interrupt(timeout);

		if(_nand_irq_status.ecc_fail > 0)
			return DTVSOC_NAND_ERR_ECC;

		return DTVSOC_NAND_OK;
	}
	else
#endif
	{
		volatile u32 rdcmdtag;
		volatile int ecc_fail = 0;
		timeout_id_t tid;

		set_timeout(&tid, timeout);

		/* skip all unhandled tags */
		while(1)
		{
			while(_nand_readl(RDCMDTAGCNT) == 0)
			{
				if(is_timeout(&tid))
				{
					NAND_ERROR("read timeout !!!\n");
					return DTVSOC_NAND_ERR_TIMEOUT;
				}
				loop_udelay(1);
			}

			rdcmdtag = _nand_readl(RDCMDTAG);
			if(RDCMDTAG_TAG(rdcmdtag) == _nand_cmd_tag)
				break;

			NAND_ERROR("It's not my tag. my=0x%x, read=0x%x\n", _nand_cmd_tag, RDCMDTAG_TAG(rdcmdtag));
		}

		/* handle all tags of mine */
		while(RDCMDTAG_ECCFAIL(rdcmdtag) ||
		      RDCMDTAG_BITERRS(rdcmdtag))
		{
			if(RDCMDTAG_ECCFAIL(rdcmdtag))
				ecc_fail = 1;

			while(_nand_readl(RDCMDTAGCNT) == 0)
			{
				if(is_timeout(&tid))
				{
					NAND_ERROR("timeout !!!\n");
					return DTVSOC_NAND_ERR_TIMEOUT;
				}
				loop_udelay(1);
			}

			rdcmdtag = _nand_readl(RDCMDTAG);
		}

		/* handle ECC error due to the erased block */
		if(ecc_fail)
		{
			return DTVSOC_NAND_ERR_ECC;
		}

		return 0;
	}

}

static int _nand_wait_writing(const dtvsoc_nand_cmd_t *cmd, int timeout)
{
	volatile u32 status;
#if USE_NAND_IRQ
	if(cmd->intr == ON)
	{
		if(_nand_wait_interrupt(timeout) != 0)
			return DTVSOC_NAND_ERR_TIMEOUT;

		status = _nand_irq_status.status;
	}
	else
#endif
	{
		volatile u32 wrcmdtag_cnt;
		volatile u32 wrcmdtag;
		volatile u32 wremdtag_cnt;
		volatile u32 wremdtag;

		timeout_id_t tid;

		set_timeout(&tid, timeout);
		while(1)
		{
			wremdtag_cnt = _nand_readl(WREMDTAGCNT);
			while((wremdtag_cnt = _nand_readl(WREMDTAGCNT)) == 0 &&
			      (wrcmdtag_cnt = _nand_readl(WRCMDTAGCNT)) == 0)
			{
				if(is_timeout(&tid))
				{
					NAND_ERROR("write timeout !!!\n");
					return DTVSOC_NAND_ERR_TIMEOUT;
				}
				loop_udelay(1);
			}

			if(wremdtag_cnt > 0)
			{
				wremdtag = _nand_readl(WREMDTAG);
				if(WREMDTAG_TAG(wremdtag) == _nand_cmd_tag)
				{
					NAND_ERROR("_nand_wait_writing. error !!!\n");
					return DTVSOC_NAND_ERR_WRITE;
				}
				continue;
			}

			wrcmdtag = _nand_readl(WRCMDTAG);
			if(WRCMDTAG_TAG(wrcmdtag) == _nand_cmd_tag)
			{
				status = WRCMDTAG_STAT(wrcmdtag);
				break;
			}

			NAND_ERROR("It's not my tag. my=0x%x, read=0x%x\n", _nand_cmd_tag, RDCMDTAG_TAG(wrcmdtag));
		}
	}

	if(status & 0x01)
	{
		return DTVSOC_NAND_ERR_WRITE;
	}

	if(!(status & 0x80))
	{
		NAND_ERROR("nand write protected ! 0x%X\n",status);
		return DTVSOC_NAND_ERR_WRITE_PROTECT;
	}

	return DTVSOC_NAND_OK;
}

#if 0
static int _nand_waiting(const dtvsoc_nand_cmd_t *cmd, int timeout)
{
	if(cmd->rnw == WRITE)
		return _nand_wait_writing(cmd, timeout);
	else
		return _nand_wait_reading(cmd, timeout);
}
#endif

static void dtvsoc_nand_read_id(u8* data_addr)
{
	struct dtvsoc_nand_cmd cmd;

	cmd.chip = 0;
	cmd.prio = 1;
#if USE_NAND_IRQ
	cmd.intr = ON;
#else
	cmd.intr = OFF;
#endif
	cmd.readst = 0;
	cmd.rnb = 0;
	cmd.tag = _nand_tag();
	cmd.intl = OFF;
	cmd.wp = 0;
	cmd.hold = OFF;
	cmd.ecc = OFF;
	cmd.rnw = READ;
	cmd.cmd = 2;
	cmd.data_size = 0;
	cmd.oob_size  = 8;
	cmd.data_addr = 0;
	cmd.oob_addr  = (u32)(unsigned long long)(unsigned int*)data_addr;
	cmd.row = 0;
	cmd.col = 0;

#if USE_NAND_IRQ
	_nand_interrupt_clear();
#endif

	_nand_queue_cmd(&cmd);
	_nand_wait_reading(&cmd, NFC_READ_TIMEOUT);
}

static int dtvsoc_nand_erase_block(u32 page)
{
	struct dtvsoc_nand_cmd cmd;

	cmd.chip = 0;
	cmd.prio = 1;
#if USE_NAND_IRQ
	cmd.intr = ON;
#else
	cmd.intr = OFF;
#endif
	cmd.readst = 0;
	cmd.rnb = ON;
	cmd.tag = _nand_tag();
	cmd.intl = OFF;
	cmd.wp = 1;
	cmd.hold = OFF;
	cmd.ecc = OFF;
	cmd.rnw = WRITE;
	cmd.cmd = 10;
	cmd.data_size = 0;
	cmd.oob_size  = 0;
	cmd.data_addr = 0;
	cmd.oob_addr  = 0;
	cmd.row = page;
	cmd.col = 0;

#if USE_NAND_IRQ
	_nand_interrupt_clear();
#endif

	_nand_queue_cmd(&cmd);

	return _nand_wait_writing(&cmd, NFC_BLKERASE_TIMEOUT);
}

static int dtvsoc_nand_read_page(u32 page, u16 data_size, u16 oob_size, void* data_addr, void* oob_addr)
{
	struct dtvsoc_nand_cmd cmd;
	int rc;

	NAND_DEBUG("dtvsoc_nand_read_page. page=0x%x(%d,%d)\n", page, data_size, oob_size);

	cmd.chip = 0;
	cmd.prio = 1;
#if USE_NAND_IRQ
	cmd.intr = ON;
#else
	cmd.intr = OFF;
#endif
	cmd.readst = 0;
	cmd.rnb = OFF;
	cmd.tag = _nand_tag();
	cmd.intl = OFF;
	cmd.wp = 3;
	cmd.hold = ON;
	cmd.ecc = ON;
	cmd.rnw = READ;
	cmd.cmd = 56;
	cmd.data_size = 0;
	cmd.oob_size  = 0;
	cmd.data_addr = 0;
	cmd.oob_addr  = 0;
	cmd.row = page;
	cmd.col = 0;

	_nand_queue_cmd(&cmd);

	cmd.chip = 0;
	cmd.prio = 1;
#if USE_NAND_IRQ
	cmd.intr = ON;
#else
	cmd.intr = OFF;
#endif
	cmd.readst = 0;
	cmd.rnb = 0;
	cmd.tag = _nand_tag();
	cmd.intl = OFF;
	cmd.wp = 4;
	cmd.hold = OFF;
	cmd.ecc = ON;
	cmd.rnw = READ;
	cmd.cmd = 64;
	cmd.data_size = data_size;
	cmd.oob_size  = oob_size;
	cmd.data_addr = (u32)(unsigned long long)(unsigned int*)data_addr;
	cmd.oob_addr  = (u32)(unsigned long long)(unsigned int*)oob_addr;
	cmd.row = 0;
	cmd.col = 0;

#if USE_NAND_IRQ
	_nand_interrupt_clear();
#endif

	_nand_queue_cmd(&cmd);

	rc = _nand_wait_reading(&cmd, NFC_READ_TIMEOUT);

	if(rc == DTVSOC_NAND_ERR_ECC)
	{
		int i;
		// it takes a long time, just check the oob data.
		for(i=0; i<oob_size/4; i++)
		{
			if(((u32*)oob_addr)[i] != 0xffffffff) goto err_ecc;
		}
		rc = DTVSOC_NAND_OK;
	}
	return rc;

err_ecc:
	NAND_ERROR("dtvsoc_nand_read_page. ecc error...\n");

	return rc;
}


#if USE_NAND_IRQ
static int dtvsoc_nand_read_nonblock(u32 page, u16 data_size,
								u16 oob_size, void* data_addr, void* oob_addr,
								nand_irq_callback_t* callback)
{
	struct dtvsoc_nand_cmd cmd;
	u8 tag = _nand_tag();

	cmd.chip = 0;
	cmd.prio = 1;
	cmd.intr = ON;
	cmd.readst = 0;
	cmd.rnb = OFF;
	cmd.tag = tag;
	cmd.intl = OFF;
	cmd.wp = 3;
	cmd.hold = ON;
	cmd.ecc = ON;
	cmd.rnw = READ;
	cmd.cmd = 56;
	cmd.data_size = 0;
	cmd.oob_size  = 0;
	cmd.data_addr = 0;
	cmd.oob_addr  = 0;
	cmd.row = page;
	cmd.col = 0;

	_nand_queue_cmd(&cmd);

	cmd.chip = 0;
	cmd.prio = 1;
	cmd.intr = ON;
	cmd.readst = 0;
	cmd.rnb = 0;
	cmd.tag = tag;
	cmd.intl = OFF;
	cmd.wp = 4;
	cmd.hold = OFF;
	cmd.ecc = ON;
	cmd.rnw = READ;
	cmd.cmd = 64;
	cmd.data_size = data_size;
	cmd.oob_size  = oob_size;
	cmd.data_addr = (u32)(unsigned long long)(unsigned int*)data_addr;
	cmd.oob_addr  = (u32)(unsigned long long)(unsigned int*)oob_addr;
	cmd.row = 0;
	cmd.col = 0;

	_nand_interrupt_clear();

	if(callback)
	{
		_nand_irq_callback.handler = callback->handler;
		_nand_irq_callback.arg = callback->arg;
	}

	_nand_queue_cmd(&cmd);

	return 0;
}

static int dtvsoc_nand_read_nonblock_stop(void)
{
	memset(&_nand_irq_callback, 0, sizeof(_nand_irq_callback));
	return 0;
}
#endif


#if 0
int dtvsoc_nand_cache_read_start(int page)
{
	struct dtvsoc_nand_cmd cmd;
	u8 tag = _nand_tag();

	cmd.chip = 0; cmd.prio = 1; cmd.intr = OFF; cmd.readst = 0; cmd.rnb = OFF;
	cmd.tag  = tag; cmd.intl = OFF; cmd.wp = 3; cmd.hold = OFF; cmd.ecc = ON; cmd.rnw = READ; cmd.cmd = 56;
	cmd.data_size = 0;
	cmd.oob_size  = 0;
	cmd.data_addr = NULL;
	cmd.oob_addr  = NULL;
	cmd.row       = page;
	cmd.col       = 0;

	_nand_queue_cmd(&cmd);

	return 0;
}

int dtvsoc_nand_cache_read_process(u16 data_size, u16 oob_size, void* data_addr, void* oob_addr)
{
	struct dtvsoc_nand_cmd cmd;
	u8 tag = _nand_cmd_tag;
	int rc;

	cmd.chip = 0;
	cmd.prio = 1;
	cmd.intr = OFF;
	cmd.readst = 0;
	cmd.rnb = OFF;
	cmd.tag = tag;
	cmd.intl = OFF;
	cmd.wp	= 6;		// Cache Read CMD Delay WP Table value (3us)
	cmd.hold = OFF;
	cmd.ecc = ON;
	cmd.rnw = READ;
	cmd.cmd = 96;		// Cache Read CMD Start Address
	cmd.data_size = 0;
	cmd.oob_size  = 0;
	cmd.data_addr = NULL;
	cmd.oob_addr  = NULL;
	cmd.row       = 0;
	cmd.col       = 0;

	_nand_queue_cmd(&cmd);

#if USE_NAND_IRQ
	cmd.intr = ON;
#else
	cmd.intr = OFF;
#endif
	cmd.tag = tag;
	cmd.wp = 4;
	cmd.hold = OFF;
	cmd.ecc = ON;
	cmd.cmd = 64;
	cmd.data_size = data_size;
	cmd.oob_size  = oob_size;
	cmd.data_addr = data_addr;
	cmd.oob_addr  = oob_addr;


#if USE_NAND_IRQ
	_nand_interrupt_clear();
#endif

	_nand_queue_cmd(&cmd);

	rc = _nand_wait_reading(&cmd, NFC_READ_TIMEOUT);

	if(rc == DTVSOC_NAND_ERR_ECC)
	{
		int i;

		// it takes a long time, just check the oob data.
		for(i=0; i<oob_size/4; i++)
		{
			if(((u32*)oob_addr)[i] != 0xffffffff) goto err_ecc;
		}
	}
	return 0;

err_ecc:
	NAND_DEBUG("dtvsoc_nand_cache_read_process. ecc error. to do something...\n");

	return rc;
}

int dtvsoc_nand_cache_read_end(u16 data_size, u16 oob_size, void* data_addr, void* oob_addr)
{
	struct dtvsoc_nand_cmd cmd;
	u8 tag = _nand_cmd_tag;
	int rc;

	// Send Cache Read End Command
	cmd.chip = 0;
	cmd.prio = 1;
	cmd.intr = OFF;
	cmd.readst = 0;
	cmd.rnb = OFF;
	cmd.tag = tag;
	cmd.intl = OFF;
	cmd.wp  = 6;  // Cache Read CMD Delay WP Table value (3us)
	cmd.hold = ON;
	cmd.ecc = ON;
	cmd.rnw = READ;
	cmd.cmd = 98; // Cache END CMD Start Address
	cmd.data_size = 0;
	cmd.oob_size  = 0;
	cmd.data_addr = NULL;
	cmd.oob_addr  = NULL;
	cmd.row       = 0;
	cmd.col       = 0;

	_nand_queue_cmd(&cmd);

#if USE_NAND_IRQ
	cmd.intr = ON;
#else
	cmd.intr = OFF;
#endif
	cmd.tag = tag;
	cmd.wp = 4;
	cmd.hold = OFF;
	cmd.ecc = ON;
	cmd.cmd = 64;
	cmd.data_size = data_size;
	cmd.oob_size  = oob_size;
	cmd.data_addr = data_addr;
	cmd.oob_addr  = oob_addr;

#if USE_NAND_IRQ
	_nand_interrupt_clear();
#endif

	_nand_queue_cmd(&cmd);

	rc = _nand_wait_reading(&cmd, NFC_READ_TIMEOUT);
	if(rc == DTVSOC_NAND_ERR_ECC)
	{
		int i;

		// it takes a long time, just check the oob data.
		for(i=0; i<oob_size/4; i++)
		{
			if(((u32*)oob_addr)[i] != 0xffffffff) goto err_ecc;
		}
	}
	return 0;

err_ecc:
	NAND_DEBUG("dtvsoc_nand_cache_read_end. crc error. to do something...\n");

	return rc;

}

int dtvsoc_nand_cache_read(int page, int len, u16 page_size, u16 oob_size, void* data_addr, void* oob_addr)
{
	int page_cnt, index;
	u8* data;
	u8* oob;
	int read = 0;

	NAND_DEBUG("dtvsoc_nand_cache_read. page=%d, len=%d\n", page, len);

	page_cnt = ((len-1) / page_size) + 1;

	data = (u8*)data_addr;
	oob = (u8*)oob_addr;

	dtvsoc_nand_cache_read_start(page);
	for(index=1; index<page_cnt; index++)
	{
		dtvsoc_nand_cache_read_process(page_size, oob_size, data, oob);
		read += page_size;
		data += page_size;
		oob += oob_size;
	}

	dtvsoc_nand_cache_read_end(page_size, oob_size, data, oob);

	return 0;
}
#endif

int dtvsoc_nand_prog_page(u32 page, u16 data_size, u16 oob_size, const void* data_addr, const void* oob_addr)
{
	struct dtvsoc_nand_cmd cmd;

	NAND_DEBUG("dtvsoc_nand_prog_page. page=0x%x(%d,%d)\n", page, data_size, oob_size);

	cmd.chip = 0;
	cmd.prio = 1;
#if USE_NAND_IRQ
	cmd.intr = ON;
#else
	cmd.intr = OFF;
#endif
	cmd.readst = 0;
	cmd.rnb = ON;
	cmd.tag = _nand_tag();
	cmd.intl = OFF;
	cmd.wp = 2;
	cmd.hold = OFF;
	cmd.ecc = ON;
	cmd.rnw = WRITE;
	cmd.cmd = 17;
	cmd.data_size = data_size;
	cmd.oob_size  = oob_size;
	cmd.data_addr = (u32)(unsigned long long)(unsigned int*)data_addr;
	cmd.oob_addr  = (u32)(unsigned long long)(unsigned int*)oob_addr;
	cmd.row = page;
	cmd.col = 0;

#if USE_NAND_IRQ
	_nand_interrupt_clear();
#endif

	_nand_queue_cmd(&cmd);

	return _nand_wait_writing(&cmd, NFC_PROGRAM_TIMEOUT);
}

void dtvsoc_nand_reset(void)
{
	struct dtvsoc_nand_cmd cmd;

	memset(&cmd, 0, sizeof(cmd));

	cmd.chip = 0;
	cmd.prio = 1;
	cmd.intr = OFF;
	cmd.readst = 0;
	cmd.rnb = ON;
	cmd.tag = _nand_tag();
	cmd.intl = OFF;
	cmd.wp = 0;
	cmd.hold = OFF;
	cmd.ecc = OFF;
	cmd.rnw = WRITE;
	cmd.cmd = 0;

	_nand_queue_cmd(&cmd);
	_nand_wait_writing(&cmd, NFC_RESET_TIMEOUT);
}

void dtvsoc_nand_read_status(void* data_addr)
{
	// fake status
	((u8*)data_addr)[0] = 0xc0;
}


static void _nand_nfc_init(nfc_conf_t* conf)
{
	NFC_Conf_Init(conf);
	NFC_Init();

	dtvsoc_nand_reset();
}

#define NAND_ID_ARRARY(id)		(id[0] << 24 | id[1] << 16 | id[2] << 8 | id[3])
static void dtvsoc_nfc_init(struct nand_info *nand, u8 *id)
{
	nfc_conf_t		*conf;

	/* If do not inited then reconfigure nfc to optimize the speed */
	if (boot_param_nand_inited() == 0)
	{
		int index = 0;

		while(1)
		{
			if(nfc_conf_ids[index].id == 0 ||
				nfc_conf_ids[index].id == NAND_ID_ARRARY(id))
			{
				conf = nfc_conf_ids[index].conf;
				//NAND_DEBUG("MATCHED ID = 0x%x\n", nand_conf_ids[index].id);
				break;
			}
			index++;
		}

		conf->page_size = nand->page_size;

		_nand_nfc_init(conf);
	#if USE_NAND_IRQ
		_nand_interrupt_control(ON);
	#endif
	}

}

int dtvsoc_nand_init(struct nand_info *nand)
{
	u8 *id;
	const nand_dev_info_t *dev_info;
	const nand_vendor_info_t *vendor_info;
	u32 ecc_bytes;

	if(boot_param_nand_inited() == 0)
	{
		NAND_INFO("Flash Device Init! ");

		// set the default param.
		_nand_nfc_init(NULL);
	}
	else
	{
		NAND_INFO("Flash Inited at First Boot! ");
	}
	NAND_INFO("%dBit ECC Mode\n", NAND_ECC_BIT);

#if USE_NAND_IRQ
	interrupt_request(IRQ_NAND, _nand_interrupt_handler, NULL);
	interrupt_active(IRQ_NAND);

	_nand_interrupt_control(ON);
#endif

	id = dma_malloc(8);
	dtvsoc_nand_read_id(id);
	NAND_DEBUG("dtvsoc_nand_init. id[0x%02x 0x%02x 0x%02x 0x%02x]\n", id[0], id[1], id[2], id[3]);
	printf("dtvsoc_nand_init. id[0x%02x 0x%02x 0x%02x 0x%02x]\n", id[0], id[1], id[2], id[3]);

	dev_info = nand_dev_infos;
	while(dev_info->id)
	{
		if(dev_info->id == id[1])
			break;

		dev_info++;
	}

	if(dev_info->id == 0)
	{
		NAND_ERROR("Can't detect NAND Device !\n");
		dma_free(id);
		return -1;
	}

	vendor_info = nand_vendor_infos;
	while(vendor_info->id)
	{
		if(vendor_info->id == id[0])
			break;

		vendor_info++;
	}

	nand->dev_info = dev_info;
	nand->vendor_info = vendor_info;

	if(dev_info->old_info == NULL)
	{
		nand->page_size = (1024) << (id[3]&0x03);
		nand->oob_size = (8 << ((id[3]>>2)&0x01)) * (nand->page_size >> 9);
		nand->block_size = (64*1024) << ((id[3]>>4) & 0x03);
	}
	else
	{
		nand->page_size = dev_info->old_info->page_size;
		nand->block_size = dev_info->old_info->block_size;
		nand->oob_size = nand->page_size >> 5;
	}

	nand->chip_size = (dev_info->chip_size << 20) / 8;

	nand->block_shift = shift(nand->block_size);
	nand->page_shift = shift(nand->page_size);

	nand->badmark_offset = (nand->page_size > 512) ? 0 : 5;

	if (NAND_ECC_BIT == 8)
		ecc_bytes = 13;
	else if (NAND_ECC_BIT == 4)
		ecc_bytes = 7;
	else if (NAND_ECC_BIT == 2)
		ecc_bytes = 4;
	else // if (NAND_ECC_BIT == 1)
		ecc_bytes = 2;

	nand->user_oob = nand->oob_size - (nand->page_size >> 9) * ecc_bytes;

	dtvsoc_nfc_init(nand, id);

	dma_free(id);

	return 0;
}

static nand_driver_t dtvsoc_nand_driver =
{
	.init = dtvsoc_nand_init,
	.read_id =	dtvsoc_nand_read_id,
	.erase_block = dtvsoc_nand_erase_block,
	.read_page = dtvsoc_nand_read_page,
	.write_page = dtvsoc_nand_prog_page,

#if USE_NAND_IRQ
	.dma_read_start	= dtvsoc_nand_read_nonblock,
	.dma_read_stop	= dtvsoc_nand_read_nonblock_stop,
#endif
};


nand_driver_t* get_nand_driver(void)
{
	return &dtvsoc_nand_driver;
}
#endif
