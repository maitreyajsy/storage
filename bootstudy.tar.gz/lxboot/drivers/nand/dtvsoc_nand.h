
#ifndef _DTVSOC_NAND_H_
#define _DTVSOC_NAND_H_

#include "dtvsoc_nfc.h"

#define CMDQCNT				0x2018
#define RDCMDTAGCNT			0x2024
#define RDCMDTAG			0x2028
#define WRCMDTAGCNT			0x202c
#define WRCMDTAG			0x2030
#define WREMDTAGCNT			0x2034
#define WREMDTAG			0x2038
#define INTRSTAT			0x2040
#define INTRCTRL			0x203c
#define CMDQ				0x3000

#define RDCMDTAG_INTR(t)	(((t) >> 21) & 0x01)
#define RDCMDTAG_ECCFAIL(t)	(((t) >> 20) & 0x01)
#define RDCMDTAG_TAG(t)		(((t) >> 9) & 0xff)
#define RDCMDTAG_BITERRS(t)	((t) & 0x0f)

#define WRCMDTAG_INTR(t)	(((t) >> 20) & 0x01)
#define WRCMDTAG_CHIP(t)	(((t) >> 17) & 0x07)
#define WRCMDTAG_RNB(t)		(((t) >> 16) & 0x01)
#define WRCMDTAG_STAT(t)	(((t) >> 8) & 0xff)
#define WRCMDTAG_TAG(t)		((t) & 0xff)

#define WREMDTAG_INTR(t)	(((t) >> 20) & 0x01)
#define WREMDTAG_CHIP(t)	(((t) >> 17) & 0x07)
#define WREMDTAG_RNB(t)		(((t) >> 16) & 0x01)
#define WREMDTAG_STAT(t)	(((t) >> 8) & 0xff)
#define WREMDTAG_TAG(t)		((t) & 0xff)


#define INT_STAT_MAIN		(1<<31)		// 0x80 00 00 00
#define INT_STAT_ERROR		(1<<30)		// 0x40 00 00 00
#define INT_STAT_WCMD		(1<<29)		// 0x20 00 00 00
#define INT_STAT_RCMD		(1<<28)		// 0x10 00 00 00
#define INT_STAT_WECMD		(1<<27)		// 0x08 00 00 00
#define INT_STAT_RECMD		(1<<26)		// 0x04 00 00 00
#define INT_STAT_BERROR		(1<<25)		// 0x02 00 00 00


#define ON	1
#define OFF	0
#define READ	0
#define WRITE	1

#define DTVSOC_NAND_OK					0
#define DTVSOC_NAND_ERR_TIMEOUT			-1
#define DTVSOC_NAND_ERR_ECC				-2
#define DTVSOC_NAND_ERR_WRITE			-3
#define DTVSOC_NAND_ERR_READ			-4
#define DTVSOC_NAND_ERR_WRITE_PROTECT	-5
#endif
