/*****************************************************************************
	System IC Business Team, LG ELECTRONICS INC., SEOUL, KOREA
	Copyright(c) 2008 by LG Electronics Inc.

	All rights reserved. No part of this work may be reproduced,
	stored in a retrieval system, or transmitted by any means without
	prior written permission of LG Electronics Inc.
	1. �� �� �� �� :	Solid State Driver
	2. ���� �ý��� :	Nand Controller Device Driver
	3. ��  ��   �� :	Nand_Controller.c
	4. �� �� �� �� :	Nand Controller Device Driver Interface
	5. ��  ��   �� :	Ha Shinsoo
	6. ��       �� :
	7. �� �� �� �� :
	(1)	2008.Oct.20 by Ha Shinsoo (the first editiion)

	8. �� �� �� �� :

*****************************************************************************/

/* ========================================================================
				INCLUDE FILE DISCRIPTION
   ========================================================================	*/
#include <types.h>
#include <string.h>
#include "dtvsoc_nfc.h"

#if USE_NAND
/* ========================================================================
				LOCAL MACRO/TYPE DEFINITION & DECLARATION
   ========================================================================	*/
#define DATA_COUNT(x)						(x << 16)
#define SPARE_COUNT(x)						(x << 0)

#define CMD_TYPE(x)							(x << 6)
#define CMD_TABLE(x)						(x << 0)
#define DATA_TYPE(x)						(x << 4)
#define DATA_CNT(x)							(x << 0)
#define ADDR_PORT(x)						(x << 3)
#define ADDR_CNT(x)							(x << 0)
#define END_CMD								0xFF


#define CMD_TYPE_CMD   						(0x0)       /* CMD */
#define CMD_TYPE_ADDR  						(0x1)       /* Address Port, Address CNT*/
#define CMD_TYPE_WDATA 						(0x2)       /* DATA Type, DATA CNT */
#define CMD_TYPE_RDATA 						(0x3)       /* DATA Type, DATA CNT */


#define DATA_TYPE_DATA						0x0
#define DATA_TYPE_ECC 						0x1
#define DATA_TYPE_ETC 						0x2
#define DATA_TYPE_RST   					0x3

#define ADDR_PORT_COL						0x0
#define ADDR_PORT_ROW						0x4



/* ----- Define are related to the CMD_LIST[] --------------------------------*/
#define CMD_00h								( 0)
#define CMD_30h								( 1)
#define CMD_35h								( 2)
#define CMD_90h								( 3)
#define CMD_FFh								( 4)
#define CMD_80h								( 5)
#define CMD_85h								( 6)
#define CMD_10h								( 7)
#define CMD_60h								( 8)
#define CMD_D0h								( 9)
#define CMD_05h								(10)
#define CMD_E0h								(11)
#define CMD_70h								(12)
#define CMD_F1h								(13)
#define CMD_F2h								(14)
#define CMD_3Fh								(17)
#define CMD_31h								(18)


/* ----- Define are related to the ADDR_CNT_LIST[] -------------------------------*/
#define ADDR_0x02							( 0)
#define ADDR_0x03							( 1)
#define ADDR_0x05							( 2)
#define ADDR_0x01							( 3)
#define ADDR_0x00							( 4)


/* ----- Define are related to the DATA_CNT_LIST[]  --------------------------*/
#define DATA_0x0001							(0)
#define DATA_0x0004							(1)
#define DATA_0x0008							(2)
#define DATA_0x0200							(3)
#define DATA_ECC							(4) // ECC
#define DATA_ETC_PAGE						(5) // ETC

const unsigned short int ECC_Size[4] =
{
	13,	/*ECC size 13B per 512B*/
	2,	/*ECC size  2B per 512B*/
	4,	/*ECC size  4B per 512B*/
	7	/*ECC size  7B per 512B*/
};





/* ========================================================================
				GLOBAL VARIABLE
   ========================================================================	*/

static nfc_conf_t nand_header;


/* ========================================================================
				STATIC VARIABLE
   ========================================================================	*/
#define ALIGNEDBY4 __attribute__((aligned(4)))

const unsigned char CMD_LIST[] ALIGNEDBY4 =
{
	0x00, 0x30, 0x35, 0x90,
	0xFF, 0x80, 0x85, 0x10,
	0x60, 0xD0, 0x05, 0xE0,
	0x70, 0xF1, 0xF2, 0x30,
	0x35, 0x3F, 0x31, 0x00,
};


const unsigned char ADDR_CNT_LIST[] ALIGNEDBY4 =
{
	0x02, 0x03, 0x05, 0x01,
	0x00, 0x00, 0x00, 0x00,
};


const unsigned short int DATA_CNT_LIST[] ALIGNEDBY4 =
{
	0x0001, 0x0004,
	0x0008, 0x0200,
};


const unsigned int WPTR_LIST[] ALIGNEDBY4 =
{
	2,    // READ ID, READ STATUS
	10,   //9720, // Block Erase
	10,   // PAGE PROGRAM
	425,  // PAGE READ_ADDR
	1,    // PAGE READ_DATA
	1780, // TWO Plane Program
	52, // Cache Read.
	8000, //EMPTY
};

const unsigned char CMDQ_LIST_DEFAULT[] ALIGNEDBY4 =
{
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_FFh),/* '0' reset */
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_90h),/* '2' read id */
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x01),

	CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ETC)  | DATA_CNT(DATA_0x0008),
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_70h),/* '6' read status */
	CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_RST) | DATA_CNT(DATA_0x0001),

	END_CMD,
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_60h),/* '10' Erase */
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW) | ADDR_CNT(ADDR_0x03),

	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_D0h),
	END_CMD,
	END_CMD,
	END_CMD
	// !!!! Aligned by 4
};


const unsigned char CMDQ_LIST_AUTO_DETECT[] ALIGNEDBY4 =
{
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '112' cycle 1-2 type 1 detection page read - address */
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x01),
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x02),
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_30h),

	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '117' cycle 2-2 type 1 detection page read - address */
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x02),
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x02),

	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_30h),
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '122' cycle 2-3 type 1 detection page read - address */
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x02),

	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x03),
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_30h),
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '127' cycle 1-2 type 2 detection page read - address */

	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x01),
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x02),
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '131' cycle 2-2 type 2 detection page read - address */

	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x02),
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x02),
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '135' cycle 2-3 type 2 detection page read - address */

	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x02),
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x03),
	END_CMD,
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '139' cycle 1-3 type 1 detection page read - address */ //////////////////////////////

	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x01),
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x03),
	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_30h),
	END_CMD,

	CMD_TYPE(CMD_TYPE_CMD)   | CMD_TABLE(CMD_00h),/* '144' cycle 1-3 type 2 detection page read - address */
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_COL)  | ADDR_CNT(ADDR_0x01),
	CMD_TYPE(CMD_TYPE_ADDR)  | ADDR_PORT(ADDR_PORT_ROW)  | ADDR_CNT(ADDR_0x03),
	END_CMD,

	CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200),/* '148' detection page read - data */
	CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ECC)  | DATA_CNT(DATA_ECC),
	END_CMD,
	END_CMD
	// !!!! Aligned by 4
};



const unsigned int NSCM_LIST[] ALIGNEDBY4 =
{
    6,
    6,
    6,
    0x000101BF,
    0x000101BF,
    0x000101BF
};

/* ========================================================================n

	1. ��  ��   �� :   NFC_Init
	2. ��       �� :
	3. �� �� �� �� :
	4. �� �� �� �� :
	5. ��  ȯ   �� :
	6. ��  ��   �� :
	7. �� �� �� �� :

	(1)	2008.Oct.20 by Ha Shinsoo (the first editiion)

	8. �� �� �� �� :

==========================================================================*/

void NFC_Init(void)
{
	unsigned int	*val;
	volatile int	*ptr;
	unsigned char	reg_data8;
	unsigned int	reg_data32;
	uint32_t		i, j;
	uint32_t		tmp_div_trc;
	unsigned int	base_addr = NFC_BASE_ADDR(0);
	int				data_512_count;
	int				tmp_numofsec;

	uint16_t		ecc_size_per512;
	uint32_t		etc_size;

	unsigned int reg;

	// NAND CNTR RESET HOLD
	reg = *(volatile unsigned int*)0xc1cf0038;
	reg |= 0x400;
	*(volatile unsigned int*)0xc1cf0038 = reg;

	// NAND CNTR RESET RELEASE
	reg = *(volatile unsigned int*)0xc1cf0038;
	reg &= 0xFFFFFBFF;
	*(volatile unsigned int*)0xc1cf0038 = reg;


	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));
	ptr[NSG_CNTR1] = (ENABLE(0) | WP_SCALE(9) | TALH(2) | TREA(6) | TADL(17) | RDIV(2) | WDIV(2) | CDIV(4));

	DBG_PRINT("nand_class = 0x%x\n", nand_header.nand_class);
	DBG_PRINT("page_size  = 0x%x\n", nand_header.page_size);

	data_512_count = nand_header.page_size / 512;

	ecc_size_per512 = ECC_Size[nand_header.ecc_mode];
	etc_size	= (16 - ecc_size_per512) * data_512_count;

	val = (unsigned int *)&CMDQ_LIST_DEFAULT[0];
	ptr = (volatile int *)((ulong)NFC_MEM_CMDQ(base_addr));

	DBG_PRINT("CMDQ_LIST_DEFAULT \n");
	for( i = 0; i < (sizeof(CMDQ_LIST_DEFAULT)/sizeof(uint32_t) ); i++ )
	{
		ptr[i] = val[i];
		if( val[i] != ptr[i] ) DBG_PRINT("Register Write Error i = %d \n",i);
	}


	// ###########################################################
	DBG_PRINT("CMDQ_LIST_WRITE  \n");
	// address 16 to 19
	reg_data8  = END_CMD;
	reg_data32 = reg_data8;

	reg_data8  = CMD_TYPE(CMD_TYPE_CMD) | CMD_TABLE(CMD_80h);
	reg_data32 = (reg_data32 & 0xFF) | (reg_data8 << 8);

	if((nand_header.nand_class & 0x00F00000) == 0x00100000) // 00120001, 00130001, 00120002, 00120002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_COL) | ADDR_CNT(ADDR_0x01);
	}
	else // + if((nand_header.nand_class & 0x00F00000) == 0x00200000) // 00220001, 00230001, 00220002, 00230002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_COL) | ADDR_CNT(ADDR_0x02);
	}
	reg_data32 = (reg_data32 & 0xFFFF) | (reg_data8 << 16);

	if((nand_header.nand_class & 0x000F0000) == 0x00020000) // 00120001, 00220001, 00120002, 00220002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_ROW) | ADDR_CNT(ADDR_0x02);
	}
	else // + if((nand_header.nand_class & 0x000F0000) == 0x00030000) // 00130001, 00230001, 00130002, 00230002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_ROW) | ADDR_CNT(ADDR_0x03);
	}
	reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

	ptr[CMDQ_WRITE] = reg_data32;
	if( reg_data32 != ptr[CMDQ_WRITE] )
		DBG_PRINT("Register Write Error \n");

	/* page size �� 512 bytes �� ��� */
	if(data_512_count == 1)
	{
		// address 20 to 23
		reg_data8  = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
		reg_data32 = reg_data8;

		reg_data8  = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_ECC) | DATA_CNT(DATA_ECC);
		reg_data32 = (reg_data32 & 0xFF) | (reg_data8 << 8);

		reg_data8  = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_ETC) | DATA_CNT(DATA_ETC_PAGE);	// etc area 3, 9, 12, 14
		reg_data32 = (reg_data32 & 0xFFFF) | (reg_data8 << 16);

		reg_data8  = CMD_TYPE(CMD_TYPE_CMD) | CMD_TABLE(CMD_10h);
		reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

		ptr[CMDQ_WRITE+1] = reg_data32;

		if( reg_data32 != ptr[CMDQ_WRITE+1] )
			DBG_PRINT("Register Write Error \n");

		// address 24 to 27
		reg_data8  = END_CMD;
		reg_data32 = reg_data8;
		reg_data32 = (reg_data32 &     0xFF) | (reg_data8 <<  8);
		reg_data32 = (reg_data32 &   0xFFFF) | (reg_data8 << 16);
		reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

		ptr[CMDQ_WRITE+2] = reg_data32;
		if( reg_data32 != ptr[CMDQ_WRITE+2] )
			DBG_PRINT("Register Write Error \n");
	}
	else
	{
		// address 20 to 20+2*data_512_count-1
		for(i = 0; i < data_512_count/2; i++)
		{
			reg_data8  = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
			reg_data32 = reg_data8;

			reg_data8  = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_ECC) | DATA_CNT(DATA_ECC);
			reg_data32 = (reg_data32 & 0xFF) | (reg_data8 << 8);

			reg_data8  = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
			reg_data32 = (reg_data32 & 0xFFFF) | (reg_data8 << 16);

			reg_data8  = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_ECC) | DATA_CNT(DATA_ECC);
			reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

			ptr[CMDQ_WRITE+1+i] = reg_data32;
			if( reg_data32 != ptr[CMDQ_WRITE+1+i] )
				DBG_PRINT("Register Write Error \n");
		}


		reg_data8 = CMD_TYPE(CMD_TYPE_WDATA) | DATA_TYPE(DATA_TYPE_ETC) | DATA_CNT(DATA_ETC_PAGE); // etc area 3,9,12,14 // 12,36,48,56 // 24,72,96,112// 48, 144, 192, 224
		reg_data32 = reg_data8;

		reg_data8  = CMD_TYPE(CMD_TYPE_CMD) | CMD_TABLE(CMD_10h);
		reg_data32 = (reg_data32 &     0xFF) | (reg_data8 << 8);

		reg_data8  = END_CMD;
		reg_data32 = (reg_data32 &   0xFFFF) | (reg_data8 << 16);
		reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

		ptr[CMDQ_WRITE+1+data_512_count/2] = reg_data32;
		if( reg_data32 != ptr[CMDQ_WRITE+1+data_512_count/2] )
			DBG_PRINT("Register Write Error \n");
	}

	// ###########################################################
	DBG_PRINT("CMDQ_LIST_READ  \n");

	// address 56 to 59
	reg_data8  = CMD_TYPE(CMD_TYPE_CMD) | CMD_TABLE(CMD_00h);
	reg_data32 = reg_data8;

	if((nand_header.nand_class & 0x00F00000) == 0x00100000) // 00120001, 00130001, 00120002, 00120002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_COL) | ADDR_CNT(ADDR_0x01);
	}
	else // + if((nand_header.nand_class & 0x00F00000) == 0x00200000) // 00220001, 00230001, 00220002, 00230002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_COL) | ADDR_CNT(ADDR_0x02);
	}
	reg_data32 = (reg_data32 & 0xFF) | (reg_data8 << 8);

	if((nand_header.nand_class & 0x000F0000) == 0x00020000) // 00120001, 00220001, 00120002, 00220002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_ROW) | ADDR_CNT(ADDR_0x02);
	}
	else // + if((nand_header.nand_class & 0x000F0000) == 0x00030000) // 00130001, 00230001, 00130002, 00230002
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_ADDR) | ADDR_PORT(ADDR_PORT_ROW) | ADDR_CNT(ADDR_0x03);
	}
	reg_data32 = (reg_data32 & 0xFFFF) | (reg_data8 << 16);

	if((nand_header.nand_class & 0x0000000F) == 0x00000001) // 00120001, 00130001, 00220001, 00230001
	{
		reg_data8 = CMD_TYPE(CMD_TYPE_CMD) | CMD_TABLE(CMD_30h);
	}
	else // + if((nand_header.nand_class & 0x0000000F) == 0x00000002) // 00120002, 00130002, 00220002, 00230002
	{
		reg_data8 = END_CMD;
	}
	reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

	ptr[CMDQ_READ] = reg_data32;
	if( reg_data32 != ptr[CMDQ_READ] )
		DBG_PRINT("Register Write Error \n");

	// address 60 to 63
	reg_data8  = END_CMD;
	reg_data32 = reg_data8;
	reg_data32 = (reg_data32 &     0xFF) | (reg_data8 << 8);
	reg_data32 = (reg_data32 &   0xFFFF) | (reg_data8 << 16);
	reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

	ptr[CMDQ_READ+1] = reg_data32;
	if( reg_data32 != ptr[CMDQ_READ+1] )
		DBG_PRINT("Register Write Error \n");

	if(data_512_count == 1)
	{
		// address 64 to 67
		reg_data8  = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
		reg_data32 = reg_data8;

		reg_data8  = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ECC)  | DATA_CNT(DATA_ECC);
		reg_data32 = (reg_data32 & 0xFF) | (reg_data8 << 8);

		reg_data8  = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ETC) | DATA_CNT(DATA_ETC_PAGE); // etc area 3, 9, 12, 14
		reg_data32 = (reg_data32 & 0xFFFF) | (reg_data8 << 16);

		reg_data8  = END_CMD;
		reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

		ptr[CMDQ_READ+2] = reg_data32;
		if( reg_data32 != ptr[CMDQ_READ+2] )
			DBG_PRINT("Register Write Error \n");
	}
	else
	{
		// address 64 to 64+2*data_512_count-1
		for(i = 0; i < data_512_count/2; i++)
		{
			reg_data8  = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
			reg_data32 = reg_data8;

			reg_data8 = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ECC)  | DATA_CNT(DATA_ECC);
			reg_data32 = (reg_data32 &      0xFF) | (reg_data8 << 8);

			reg_data8  = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
			reg_data32 = (reg_data32 &    0xFFFF) | (reg_data8 << 16);

			reg_data8 = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ECC)  | DATA_CNT(DATA_ECC);
			reg_data32 = (reg_data32 &  0xFFFFFF) | (reg_data8 << 24);

			ptr[CMDQ_READ+2+i] = reg_data32;
			if( reg_data32 != ptr[CMDQ_READ+2+i] )
				DBG_PRINT("Register Write Error \n");
		}


		reg_data8 = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ETC) | DATA_CNT(DATA_ETC_PAGE); // etc area 3, 9, 12, 14 // 12, 36, 48, 56 // 24, 72, 96, 112 // 48, 144, 192, 224
		reg_data32 = reg_data8;

		reg_data8  = END_CMD;
		reg_data32 = (reg_data32 &     0xFF) | (reg_data8 << 8);
		reg_data32 = (reg_data32 &   0xFFFF) | (reg_data8 << 16);
		reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

		ptr[CMDQ_READ+2+data_512_count/2] = reg_data32;
		if( reg_data32 != ptr[CMDQ_READ+2+data_512_count/2] )
			DBG_PRINT("Register Write Error \n");
	}

	reg_data32 = (END_CMD<<24) | ( (CMD_TYPE(CMD_TYPE_CMD) | CMD_TABLE(CMD_3Fh) ) << 16 ) | (END_CMD<<8) | (CMD_TYPE(CMD_TYPE_CMD) | CMD_TABLE(CMD_31h));
	ptr[24] = reg_data32;
	// ###########################################################
	if((nand_header.page_size == 4096) || (nand_header.page_size == 8192))
	{
		DBG_PRINT("CMDQ_LIST_2K_READ  \n");

		// address 100 ~ 103, 104 ~ 107
		for(i = 0; i < 2; i++)
		{
			reg_data8  = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
			reg_data32 = reg_data8;

			reg_data8 = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ECC)  | DATA_CNT(DATA_ECC);
			reg_data32 = (reg_data32 &     0xFF) | (reg_data8 << 8);

			reg_data8  = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_DATA) | DATA_CNT(DATA_0x0200);
			reg_data32 = (reg_data32 &   0xFFFF) | (reg_data8 << 16);

			reg_data8 = CMD_TYPE(CMD_TYPE_RDATA) | DATA_TYPE(DATA_TYPE_ECC)  | DATA_CNT(DATA_ECC);
			reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

			ptr[CMDQ_READ_2K+i] = reg_data32;
			if( reg_data32 != ptr[CMDQ_READ_2K+i] )
				DBG_PRINT("Register Write Error \n");
		}

		// address 108 ~ 111
		reg_data8  = END_CMD;
		reg_data32 = reg_data8;
		reg_data32 = (reg_data32 &     0xFF) | (reg_data8 << 8);
		reg_data32 = (reg_data32 &   0xFFFF) | (reg_data8 << 16);
		reg_data32 = (reg_data32 & 0xFFFFFF) | (reg_data8 << 24);

		ptr[CMDQ_READ_2K+2] = reg_data32;
		if( reg_data32 != ptr[CMDQ_READ_2K+2] )
			DBG_PRINT("Register Write Error \n");
	}

	// ###########################################################
	val = (unsigned int *)&CMDQ_LIST_AUTO_DETECT[0];
	DBG_PRINT("WRITE CMDQ_LIST_AUTO_DETECT \n");
	for( i = 0; i < (sizeof(CMDQ_LIST_AUTO_DETECT)/sizeof(uint32_t)); i++ ) // address 112 ~
	{
		ptr[CMDQ_AUTO_DETECT+i] = val[i];
		if( val[i] != ptr[CMDQ_AUTO_DETECT+i] )
			DBG_PRINT("Register Write Error i = %d \n",i);
	}

	// ###########################################################
	val = (unsigned int *)&CMD_LIST[0];
	ptr = ( volatile int *)((ulong)NFC_MEM_CMDT(base_addr));
	DBG_PRINT("CMD_LIST  \n");
	for( i = 0; i < (sizeof(CMD_LIST)/sizeof(uint32_t) ); i++ )
	{
		ptr[i] = val[i];
		if( val[i] != ptr[i] )
			DBG_PRINT("Register Write Error i = %d\n",i);
	}


	val = (unsigned int *)&ADDR_CNT_LIST[0];
	ptr = ( volatile int *)((ulong)NFC_MEM_ADDT(base_addr));
	DBG_PRINT("ADDR_CNT_LIST  \n");
	for( i = 0; i < (sizeof(ADDR_CNT_LIST)/sizeof(uint32_t) ); i++ )
	{
		ptr[i] = val[i];
		if( val[i] != ptr[i] )
			DBG_PRINT("Register Write Error val[%d] = %x ptr[%d] = %x\n",i,val[i],i,ptr[i]);
	}

	val = (unsigned int *)&DATA_CNT_LIST[0];
	ptr = ( volatile int *)((ulong)NFC_MEM_DATT(base_addr));
	DBG_PRINT("DATA_CNT_LIST  \n");
	for( i = 0; i < (sizeof(DATA_CNT_LIST)/sizeof(uint32_t) ); i++ )
	{
		ptr[i] = val[i];
		if( val[i] != ptr[i] )
			DBG_PRINT("Register Write Error i = %d\n",i);
	}

	/* ECC Setting Start */
	i = sizeof(DATA_CNT_LIST)/sizeof(uint32_t);

	reg_data32 = (0xFFFF & ecc_size_per512) | (etc_size << 16); // DATA_ECC, DATA_ETC_PAGE
	ptr[i] = reg_data32;
	if( reg_data32 != ptr[i] )
		DBG_PRINT("Register Write Error \n");
	/* ECC Setting End */

	val = (unsigned int *)&WPTR_LIST[0];
	ptr = ( volatile int *)((ulong)NFC_WPTR_REG(base_addr));
	DBG_PRINT("WPTR_LIST  \n");
	for( i = 0; i < sizeof(WPTR_LIST)/sizeof(uint32_t); i++ )
	{
		ptr[i] = val[i];
		if( val[i] != ptr[i] )
			DBG_PRINT("Register Write Error \n");
	}

	ptr[3] = nand_header.nand_tr / 10; // PAGE READ ADDR


	val = (unsigned int *)&NSCM_LIST[0];
	ptr = ( volatile int *)((ulong)NFC_NSCM_REG(base_addr));

	DBG_PRINT("NSCM_LIST  \n");
	for( i = 0; i < sizeof(NSCM_LIST)/sizeof(uint32_t); i++ )
	{
		ptr[i] = val[i];
		if( val[i] != ptr[i] )
			DBG_PRINT("Register Write Error \n");
	}

	DBG_PRINT("nand_header.nand_tr      = %d\n", nand_header.nand_tr);
	DBG_PRINT("nand_header.nand_trea    = %d\n", nand_header.nand_trea);
	DBG_PRINT("nand_header.nand_talh    = %d\n", nand_header.nand_talh);
	DBG_PRINT("nand_header.nand_div_trp = %d\n", nand_header.nand_div_trp);
	DBG_PRINT("nand_header.nand_div_trc = %d\n", nand_header.nand_div_trc);
	DBG_PRINT("nand_header.nand_tadl    = %d\n", nand_header.nand_tadl);
	DBG_PRINT("nand_header.nand_div_twp = %d\n", nand_header.nand_div_twp);

	tmp_div_trc = nand_header.nand_div_trc-1;
	tmp_numofsec = data_512_count - 1;

	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	ptr[NSG_CNTR2] = ECC_MODE(nand_header.ecc_mode) | NUMOFSEC(tmp_numofsec) | TRHZ(30);

	ptr[NSG_CNTR1] = (ENABLE(0) | WP_SCALE(9) | TALH(nand_header.nand_talh) | TREA(nand_header.nand_trea) | TADL(nand_header.nand_tadl) | RDIV(nand_header.nand_div_trp) | WDIV(nand_header.nand_div_twp) | CDIV(tmp_div_trc));
	ptr[NSG_CNTR1] = (ENABLE(1) | WP_SCALE(9) | TALH(nand_header.nand_talh) | TREA(nand_header.nand_trea) | TADL(nand_header.nand_tadl) | RDIV(nand_header.nand_div_trp) | WDIV(nand_header.nand_div_twp) | CDIV(tmp_div_trc));

	// Interrupt Disable
	ptr[NSG_INTR_CNTR] = 0;

	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));
	i = ptr[NSG_RCMDTAG_CNT];

	while(i--)
	{
		j = ptr[NSG_RCMDTAG];
	}

}

#if 0
void NFC_Interrupt_Control(int bEnable)
{
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);

	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	// Interrupt Enable(1)/Disable(0)
	ptr[NSG_INTR_CNTR] = bEnable;
}


unsigned int NFC_ReadID( nfc_cmd_t * cmd )
{
	unsigned int i;
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | RNW(READ)| CMD_READID;
	ptr[1] = DATA_COUNT(cmd->data_cnt) | SPARE_COUNT(cmd->spare_cnt);
	ptr[2] = 0;
	ptr[3] = (int) cmd->spare_ptr;
	ptr[4] = 0;
	ptr[5] = 0;


	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	i = 0;

	while ( ptr[NSG_RCMDTAG_CNT] == 0 ) {}
	i = ptr[NSG_RCMDTAG];

	return NFC_OK;
}


/* ========================================================================

    1. ��  ��   �� :   NFC_BlockErase
	2. ��       �� :
	3. �� �� �� �� :
	4. �� �� �� �� :
	5. ��  ȯ   �� :
	6. ��  ��   �� :
	7. �� �� �� �� :

	(1) 2008.Oct.20 by Ha Shinsoo     (the first editiion)
	(2) 2009.July.28 by Yim JeongKyun (the second editiion)


==========================================================================*/
unsigned int NFC_BlockErase( nfc_cmd_t * cmd )
{
	unsigned int i;
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_BLOCKERASE;
	ptr[1] = 0;
	ptr[2] = 0;
	ptr[3] = 0;
	ptr[4] = cmd->row_num;
	ptr[5] = 0;


	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	i = 0;
	while ( (ptr[NSG_WNCMDTAG_CNT] == 0) && (ptr[NSG_WECMDTAG_CNT] == 0) )
	{
		if( i > BLKERASE_TIMEOUT )
			return NFC_TIME_OUT;
		i++;
	}

	if( ptr[NSG_WNCMDTAG_CNT] != 0 )
	{
		i = ptr[NSG_WNCMDTAG];
		return NFC_OK;

	}

	if( ptr[NSG_WECMDTAG_CNT] != 0 )
	{
		i = ptr[NSG_WECMDTAG];
		return NFC_ERROR_ERASE;
	}

	return NFC_STATUS_FAIL;
}

/* ========================================================================

1. ��  ��   �� :   NFC_Reset
2. ��       �� :
3. �� �� �� �� :
4. �� �� �� �� :
5. ��  ȯ   �� :
6. ��  ��   �� :
7. �� �� �� �� :

(1) 2008.Oct.20 by Ha Shinsoo     (the first editiion)
(2) 2009.July.28 by Yim JeongKyun (the second editiion)


==========================================================================*/
unsigned int NFC_Reset( nfc_cmd_t * cmd )
{
	unsigned int i;
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_RESET;
	ptr[1] = 0;
	ptr[2] = 0;
	ptr[3] = 0;
	ptr[4] = 0;
	ptr[5] = 0;


	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	while ( (ptr[NSG_WNCMDTAG_CNT] == 0) && (ptr[NSG_WECMDTAG_CNT] == 0)  );

	i = ptr[NSG_WNCMDTAG_CNT];

	if(i)
	{
		i = ptr[NSG_WNCMDTAG];
		return NFC_OK;
	}

	i = ptr[NSG_WECMDTAG_CNT];

	if(i)
	{
		i = ptr[NSG_WECMDTAG];
		return NFC_STATUS_FAIL;
	}

	return NFC_STATUS_FAIL;
}


/* ========================================================================

1. ��  ��   �� :   NFC_PageProgram
2. ��       �� :
3. �� �� �� �� :
4. �� �� �� �� :
5. ��  ȯ   �� :
6. ��  ��   �� :
7. �� �� �� �� :

(1) 2008.Oct.20 by Ha Shinsoo     (the first editiion)
(2) 2009.July.28 by Yim JeongKyun (the second editiion)


==========================================================================*/
unsigned int NFC_PageProgram( nfc_cmd_t * cmd )
{
	unsigned int i;
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | RNB(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_PAGEPROGRAM;
	ptr[1] = DATA_COUNT(cmd->data_cnt) | SPARE_COUNT(cmd->spare_cnt );
	ptr[2] = cmd->data_ptr;
	ptr[3] = cmd->spare_ptr;
	ptr[4] = cmd->row_num;
	ptr[5] = cmd->col_num;

	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	i = 0;
	while ( (ptr[NSG_WNCMDTAG_CNT]  == 0) && (ptr[NSG_WECMDTAG_CNT]  == 0)  )
	{
		if( i > PROGRAM_TIMEOUT )
			return NFC_TIME_OUT;

//		i++;
	}

	if( ptr[NSG_WNCMDTAG_CNT] != 0 )
	{
		i = ptr[NSG_WNCMDTAG];
		return NFC_OK;

	}
	if( ptr[NSG_WECMDTAG_CNT] != 0 )
	{
		i = ptr[NSG_WECMDTAG];
		DBG_PRINT(" Page Program Fail Status = %x \n",i);
		return NFC_ERROR_ERASE;
	}


	return NFC_STATUS_FAIL;
}


/* ========================================================================

1. ��  ��   �� :   NFC_PageRead
2. ��       �� :
3. �� �� �� �� :
4. �� �� �� �� :
5. ��  ȯ   �� :
6. ��  ��   �� :
7. �� �� �� �� :

(1) 2008.Oct.20 by Ha Shinsoo     (the first editiion)
(2) 2009.July.28 by Yim JeongKyun (the second editiion)


==========================================================================*/
unsigned int NFC_PageRead( nfc_cmd_t * cmd )
{
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);
	unsigned int status;

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_PAGEREAD_ADDR;
	ptr[1] = DATA_COUNT(0) | SPARE_COUNT(0);
	ptr[2] = 0;
	ptr[3] = 0;
	ptr[4] = cmd->row_num;
	ptr[5] = 0;


	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_PAGEREAD_DATA;
	ptr[1] = DATA_COUNT(cmd->data_cnt) | SPARE_COUNT(cmd->spare_cnt);
	ptr[2] = cmd->data_ptr;
	ptr[3] = cmd->spare_ptr;
	ptr[4] = 0;
	ptr[5] = 0;

	while( (status = NFC_Check_Read_Status()) == NFC_READ_NOT_DONE ) {}

	return status;
}

unsigned int NFC_Read_Page_Command( nfc_cmd_t * cmd )
{
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_PAGEREAD_ADDR;
	ptr[1] = DATA_COUNT(0) | SPARE_COUNT(0);
	ptr[2] = 0;
	ptr[3] = 0;
	ptr[4] = cmd->row_num;
	ptr[5] = 0;


	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_PAGEREAD_DATA;
	ptr[1] = DATA_COUNT(cmd->data_cnt) | SPARE_COUNT(cmd->spare_cnt);
	ptr[2] = cmd->data_ptr;
	ptr[3] = cmd->spare_ptr;
	ptr[4] = 0;
	ptr[5] = 0;

	return NFC_OK;
}


unsigned int NFC_Check_Read_Status(void)
{
	unsigned int i;
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);
	int eccfail_count = 0;

	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	if(ptr[NSG_RCMDTAG_CNT] == 0)
	{
		return NFC_READ_NOT_DONE;
	}
	else
	{
		i = ptr[NSG_RCMDTAG];

		if( (RTECCFAIL(i) != 0) || (RTECCCNT(i) != 0) )
		{
			if(RTECCFAIL(i) != 0) { eccfail_count++; }

			while(1)
			{
				while(ptr[NSG_RCMDTAG_CNT] == 0) {}
				i = ptr[NSG_RCMDTAG];

				if(RTECCFAIL(i) != 0) { eccfail_count++; }

				if( (RTECCFAIL(i) == 0) && (RTECCCNT(i) == 0) )
				{
					if(eccfail_count == 0)
					{
						return NFC_OK;
					}
					else
					{
						DBG_PRINT(" PAGE READ COMMAND ECC Fail : %d !\n", eccfail_count);
						return NFC_READ_ECC_FAIL;
					}
				}
			}
		}
		else
		{ return NFC_OK; }
	}

	return NFC_OK;
}


unsigned int NFC_2K_Read( nfc_cmd_t * cmd )
{
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);
	unsigned int status;

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_PAGEREAD_ADDR;
	ptr[1] = DATA_COUNT(0) | SPARE_COUNT(0);
	ptr[2] = 0;
	ptr[3] = 0;
	ptr[4] = cmd->row_num;
	ptr[5] = cmd->col_num;


	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | CMD_READ_2K_DATA;
	ptr[1] = DATA_COUNT(cmd->data_cnt) | SPARE_COUNT(cmd->spare_cnt);
	ptr[2] = (int) cmd->data_ptr;
	ptr[3] = (int) cmd->spare_ptr;
	ptr[4] = 0;
	ptr[5] = 0;

	while( (status = NFC_Check_Read_Status()) == NFC_READ_NOT_DONE ) {}

	return status;
}



unsigned int NFC_DetectionRead( nfc_cmd_t * cmd, unsigned int cmd_read_addr, unsigned int cmd_read_data )
{
	volatile int *ptr;
	unsigned int base_addr = NFC_BASE_ADDR(0);
	unsigned int status;

	while (NFC_GetCMDQCount(cmd->chip) > 0) {}

	ptr = ( volatile int *)((ulong)NFC_CMDQ_REG(base_addr));

	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | cmd_read_addr;
	ptr[1] = DATA_COUNT(0) | SPARE_COUNT(0);
	ptr[2] = 0;
	ptr[3] = 0;
	ptr[4] = cmd->row_num;
	ptr[5] = 0;


	ptr[0] = CHIP_NUM(cmd->chip) | PRIO(1) | INTRGEN(cmd->interrupt) | CMD_TAG(cmd->tag) | INTL(0) | cmd_read_data;
	ptr[1] = DATA_COUNT(cmd->data_cnt) | SPARE_COUNT(cmd->spare_cnt);
	ptr[2] = (int) cmd->data_ptr;
	ptr[3] = (int) cmd->spare_ptr;
	ptr[4] = 0;
	ptr[5] = 0;

	while( (status = NFC_Check_Read_Status()) == NFC_READ_NOT_DONE ) {}

	return status;
}


/*=	=======================================================================


1. ��  ��   �� :   NFC_GetCMDQCount
2. ��       �� :
3. �� �� �� �� :
4. �� �� �� �� :
5. ��  ȯ   �� :
6. ��  ��   �� :
7. �� �� �� �� :

(1) 2008.Oct.20 by Ha Shinsoo     (the first editiion)
(2) 2009.July.28 by Yim JeongKyun (the second editiion)


==========================================================================*/

unsigned int NFC_GetCMDQCount(unsigned int chip)
{
	volatile int *ptr;
	unsigned int cmdcnt;
	int q_status;
	unsigned int base_addr = NFC_BASE_ADDR(0);

	ptr = ( volatile int *)((ulong)NFC_CNTR_REG(base_addr));

	q_status = ptr[NSG_HCMDQ0];

	cmdcnt = ( q_status >> (chip * 2) ) & 0x3;

	return cmdcnt;
}
#endif



#define NFC_ECC_MODE(x)			\
		((x==8) ? ECC_8BIT :	\
		 (x==4) ? ECC_4BIT :	\
		 (x==2) ? ECC_2BIT :	\
		 (x==1) ? ECC_1BIT : 0)
void NFC_Conf_Init(nfc_conf_t *conf)
{
	if(conf == NULL)
	{
		conf = &nfc_conf_default;
	}

	memcpy(&nand_header, conf, sizeof(nfc_conf_t));
	nand_header.ecc_mode = NFC_ECC_MODE(NAND_ECC_BIT);
}
#endif
