/*****************************************************************************
    System IC Business Team, LG ELECTRONICS INC., SEOUL, KOREA
    Copyright(c) 2008 by LG Electronics Inc.

    All rights reserved. No part of this work may be reproduced,
    stored in a retrieval system, or transmitted by any means without
    prior written permission of LG Electronics Inc.
    1. �� �� �� �� :	Solid State Driver
    2. ���� �ý��� :	Nand Controller Device Driver
    3. ��  ��   �� :	Nand_Controller_Define.h
    4. �� �� �� �� :	Main Header file of Nand Controller with Global MACRO/T
    5. ��  ��   �� :	Ha Shinsoo
    6. ��       �� :
    7. �� �� �� �� :
        (1)	2008.Oct.20 by Ha Shinsoo (the first editiion)

    8. �� �� �� �� :

*****************************************************************************/
#ifndef _DTVSOC_NFC_H_
#define _DTVSOC_NFC_H_

#define DEBUG_MODE						0

#define NAND_ECC_BIT					8

#if (DEBUG_MODE > 0)
#define DBG_PRINT(fmt, args...)			printf(fmt, ##args)
#else
#define DBG_PRINT(fmt, args...)			do { } while (0)
#endif

#if (DEBUG_MODE > 1)
#define NAND_PRINT(fmt, args...)		printf(fmt, ##args)
#else
#define NAND_PRINT(fmt, args...) 		do { } while (0)
#endif

#define CMD_RESET							(READ_ST(0)|RNB(1)|WPTR(0)|H2NCMD(OFF)|ECC(OFF)|RNW(WRITE)|CMD_NUM(0))
#define CMD_READID							(READ_ST(0)|RNB(0)|WPTR(0)|H2NCMD(OFF)|ECC(OFF)|RNW(READ)|CMD_NUM(2))
#define CMD_READSTATUS						(READ_ST(0)|RNB(1)|WPTR(0)|H2NCMD(OFF)|ECC(OFF)|RNW(READ)|CMD_NUM(6))

#define CMD_BLOCKERASE						(READ_ST(0)|RNB(1)|WPTR(1)|H2NCMD(OFF)|ECC(OFF)|RNW(WRITE)|CMD_NUM(10))
#define CMD_PAGEPROGRAM						(READ_ST(0)|RNB(1)|WPTR(2)|H2NCMD(OFF)|ECC(ON)|RNW(WRITE)|CMD_NUM(17))
#define CMD_PAGEREAD_ADDR					(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(56))
#define CMD_PAGEREAD_DATA					(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(64))

#define CMD_PAGEREAD_CACHE					(READ_ST(0)|RNB(0)|WPTR(6)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(96))
#define CMD_PAGEREAD_CACHE_END					(READ_ST(0)|RNB(0)|WPTR(6)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(98))

#define CMD_READ_2K_DATA					(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(100))


#define CMD_CYCLE12_TYPE1_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(112))
#define CMD_CYCLE12_TYPE1_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))

#define CMD_CYCLE22_TYPE1_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(117))
#define CMD_CYCLE22_TYPE1_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))

#define CMD_CYCLE23_TYPE1_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(122))
#define CMD_CYCLE23_TYPE1_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))

#define CMD_CYCLE12_TYPE2_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(127))
#define CMD_CYCLE12_TYPE2_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))

#define CMD_CYCLE22_TYPE2_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(131))
#define CMD_CYCLE22_TYPE2_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))

#define CMD_CYCLE23_TYPE2_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(135))
#define CMD_CYCLE23_TYPE2_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))

#define CMD_CYCLE13_TYPE1_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(139))
#define CMD_CYCLE13_TYPE1_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))

#define CMD_CYCLE13_TYPE2_READ_ADDR			(READ_ST(0)|RNB(0)|WPTR(3)|H2NCMD(ON) |ECC(ON)|RNW(READ)|CMD_NUM(144))
#define CMD_CYCLE13_TYPE2_READ_DATA			(READ_ST(0)|RNB(0)|WPTR(4)|H2NCMD(OFF)|ECC(ON)|RNW(READ)|CMD_NUM(148))


#define NFC_BASE_ADDR(x)				(NFC_BASE + (x*0x10000))
#define NFC_MEM_CMDQ(x)					(x                    )
#define NFC_MEM_CMDT(x)					(x           + (1<<11))
#define NFC_MEM_ADDT(x)					(x           + (2<<11))
#define NFC_MEM_DATT(x)					(x           + (3<<11))
#define NFC_CNTR_REG(x)					(x + (1<<13) + (0<<11))
#define NFC_WPTR_REG(x)					(x + (1<<13) + (1<<11))
#define NFC_CMDQ_REG(x)					(x + (1<<13) + (2<<11))
#define NFC_NSCM_REG(x)					(x + (1<<13) + (3<<11))

#define CMDQ_WRITE						4
#define CMDQ_READ						14
#define CMDQ_READ_2K					25
#define CMDQ_AUTO_DETECT				28

/* NFC_CNTR_REG */
#define NSG_CNTR1						0
#define NSG_CNTR2						1
#define NSG_WP0  						2    //WP0 , WP1
#define NSG_WP1  						3    //WP2 , WP3
#define NSG_WP2  						4    //WP4 , WP5
#define NSG_WP3  						5    //WP6 , WP7
#define NSG_HCMDQ0						6    // CMDQ_CNT0, CMDQ_CNT1, CMDQ_CNT2, CMDQ_CNT3
#define NSG_LCMDQ0						7    // CMDQ_CNT0, CMDQ_CNT1, CMDQ_CNT2, CMDQ_CNT3
#define NSG_CMDQ0 						8    // CMDQ_CNT0, CMDQ_CNT1, CMDQ_CNT2, CMDQ_CNT3
#define NSG_RCMDTAG_CNT 				9    // 27'b0 + rcmd_tag_cnt[4:0]
#define NSG_RCMDTAG     				10   // 24'b ecc_fail_no[2:0] * 8 + rcmd_tag
#define NSG_WNCMDTAG_CNT				11   // 27'b0 + wcmd_tag_cnt[4:0]
#define NSG_WNCMDTAG    				12   // 24'b0 + wcmd_tag
#define NSG_WECMDTAG_CNT				13   // 27'b0 + wcmd_tag_cnt[4:0]
#define NSG_WECMDTAG 					14   // 24'b0 + wcmd_tag
#define NSG_INTR_CNTR					15   //
#define NSG_INTR_STATUS					16   //

/* INTR REGISTER */
#define INTR_ENABLE(x)					(1 & x)
#define INTR_INTR						(1<<31)
#define INTR_EINTR						(1<<30)
#define INTR_WCMD						(1<<29)
#define INTR_RCMD						(1<<28)
#define INTR_WECMD						(1<<27)
#define INTR_RECMD						(1<<26)
#define INTR_EBUFF						(1<<25)
#define INTR_EDUF						(1<<17)
#define INTR_EDOF						(1<<16)
#define INTR_RSUF						(1<<15)
#define INTR_RSOF						(1<<14)
#define INTR_WSUF						(1<<13)
#define INTR_WSOF						(1<<12)
#define INTR_REUF						(1<<11)
#define INTR_REOF						(1<<10)
#define INTR_WEUF						(1<< 9)
#define INTR_WEOF						(1<< 8)
#define INTR_RDUF						(1<< 7)
#define INTR_RDOF						(1<< 6)
#define INTR_WDUF						(1<< 5)
#define INTR_WDOF						(1<< 4)
#define INTR_RDMAUF						(1<< 3)
#define INTR_RDMAOF						(1<< 2)
#define INTR_WDMAUF						(1<< 1)
#define INTR_WDMAOF						(1<< 0)


//Nand Signal Generater Control Register1
#define ENABLE(x)						((x & 0x01)<<31)
#define WP_SCALE(x)						((x & 0x1F)<<26)
#define TALH(x)							((x & 0x07)<<23)
#define TREA(x)							((x & 0x1F)<<18)
#define TADL(x)							((x & 0x3F)<<12)
#define RDIV(x)							((x & 0x0F)<< 8)
#define WDIV(x)							((x & 0x0F)<< 4)
#define CDIV(x)							((x & 0x0F)<< 0)

//Nand Signal Generater Control Register2
#define NUMOFSEC(x)						((x & 0x1F)<< 7)
#define TRHZ(x)							((x & 0x3F)<< 1)


/* NFC_CMD */
#define ON								1
#define OFF								0
#define READ							0
#define WRITE							1
#define CMD_NUM(x)						((x & 0x1FF)<< 0)
#define RNW(x)							((x & 0x001)<< 9)
#define ECC(x)							((x & 0x001)<<10)
#define H2NCMD(x)						((x & 0x001)<<11)
#define WPTR(x)							((x & 0x007)<<12)
#define INTL(x)							((x & 0x001)<<15)
#define CMD_TAG(x)						((x & 0x0FF)<<16)
#define RNB(x)							((x & 0x001)<<24)
#define READ_ST(x)						((x & 0x003)<<25)
#define INTRGEN(x)						((x & 0x001)<<27)
#define PRIO(x)							((x & 0x001)<<28)
#define CHIP_NUM(x)						((x & 0x007)<<29)

//NFC RCMD TAG REG
#define RTINTR(x)						((x >>21) & 0x01 )
#define RTECCFAIL(x)					((x >>20) & 0x01 )
#define RTCHIP(x)   					((x >>17) & 0x07 )
#define RTTAG(x)    					((x >> 9) & 0xFF )
#define RTSEC(x)    					((x >> 4) & 0x1F )
#define RTECCCNT(x) 					((x >> 0) & 0x0F )


/*According to Nand Flash Controller ECC size, yw.kim@lge.com */
#define ECC_8BIT						0 /*ECC size 13B per 512B*/
#define ECC_1BIT						1 /*ECC size  2B per 512B*/
#define ECC_2BIT						2 /*ECC size  4B per 512B*/
#define ECC_4BIT						3 /*ECC size  7B per 512B*/

#define ECC_MODE(x)						((x&0x03)<<12)


#define READID_TIMEOUT					100
#define BLKERASE_TIMEOUT				10000
#define PROGRAM_TIMEOUT					5000
#define RESET_TIMEOUT					1000

typedef enum
{
   NFC_OK = 0,                       /*  Error None                      */
   NFC_ERROR_UNKNOW,         		/*  Error with unknown reason       */
   NFC_ERROR_PARAM,                 /*  Error with Parameters           */
   NFC_ERROR_READ,                  /*  Error Reading from Part         */
   NFC_ERROR_PROGRAM,               /*  Error Programming to Part       */
   NFC_ERROR_ERASE,                 /*  Error Erasing Part              */
   NFC_STATUS_FAIL,                 /*  Error Status Fail               */
   NFC_ERROR_TAG,
   NFC_TIME_OUT,					/* 8 */
   NFC_READ_NOT_DONE,				/* 9 */
   NFC_READ_ECC_FAIL,

	END
} nfc_error_t;


typedef struct
{
	uint32_t data_size;		/* size of data area */
	uint32_t spare_size;	/* size of spare area */
	uint32_t etc_size;		/* size of etc area */
	uint32_t block_pages;	/* pages per block */
} nfc_nand_info_t;

typedef struct
{
	uint32_t nand_class;		// ex) 0x00220001 : Cycle 22 Type 1
	uint32_t page_size;			// one page size
	uint16_t block_pages;		// pages per block
	uint16_t ecc_mode;

	uint32_t nand_tr;			// data transfer time from cell to register
	uint32_t nand_trea;			// RE access time
	uint32_t nand_talh;			// ALE(Address Latch Enable) hold time
	uint32_t nand_div_trp;		// clock divider value for read enable low pulse width
	uint32_t nand_div_trc;		// clock divider value for read cycle time
	uint32_t nand_tadl;			// address to data loading time
	uint32_t nand_div_twp;		// clock divider value for write enable low pulse width
} nfc_conf_t;

typedef struct
{
   unsigned int chip;
   unsigned int interrupt;
   unsigned int tag;
   unsigned int data_cnt;
   unsigned int spare_cnt;
   unsigned int data_ptr;
   unsigned int spare_ptr;
   unsigned int row_num;
   unsigned int col_num;

} nfc_cmd_t;


struct nfc_conf_id
{
	uint32_t	id;
	nfc_conf_t	*conf;
};

void				NFC_Init(void);
void				NFC_Conf_Init(nfc_conf_t* conf);

#if 0
void				NFC_Interrupt_Control( int );
unsigned int		NFC_ReadID( nfc_cmd_t * cmd );
unsigned int		NFC_BlockErase( nfc_cmd_t * cmd );
unsigned int		NFC_Reset( nfc_cmd_t * cmd );
unsigned int		NFC_PageProgram( nfc_cmd_t * cmd );
unsigned int		NFC_PageRead( nfc_cmd_t * cmd );
unsigned int		NFC_2K_Read( nfc_cmd_t * cmd );
unsigned int		NFC_Read_Page_Command( nfc_cmd_t * cmd );
unsigned int		NFC_Check_Read_Status(void);
unsigned int		NFC_AutoDetectionRead( nfc_cmd_t * cmd );
unsigned int		NFC_GetCMDQCount( unsigned int chip );
#endif

extern nfc_conf_t nfc_conf_default;
extern struct nfc_conf_id nfc_conf_ids[];


#endif /* #ifndef _DTVSOC_NFC_H_ */
