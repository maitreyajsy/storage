#include <types.h>
#include <nand.h>


// flash ����
const nand_dev_info_t nand_dev_infos[] =
{
	//ID	NAME						SIZE	OPTION	OLD_INFO
    // 4 Gigabit
    {0xAC,	"NAND 512M 1.8V 8 bit",		512,	0, 		NULL},
    {0xDC,	"NAND 512M 3.3V 8 bit",		512,	0, 		NULL},
    {0xBC,	"NAND 512M 1.8V 16 bit",	512,	0, 		NULL},
    {0xCC,	"NAND 512M 3.3V 16 bit",	512,	0, 		NULL},

    // 8 Gigabit
    {0xA3,	"NAND 1G 1.8V 8 bit",		1024,	0, 		NULL},
//    {0xD3,	"NAND 1G 3.3V 8 bit",			1024,	0, 		NULL},
    {0xF1,	"NAND 1G 3.3V 8 bit",		1024,	0, 		NULL},
    {0xB3,	"NAND 1G 1.8V 16 bit",		1024,	0, 		NULL},
    {0xC3,	"NAND 1G 3.3V 16 bit",		1024,	0, 		NULL},

    // 16 Gigabit
    {0xA5,	"NAND 2G 1.8V 8 bit",		2048,	0, 		NULL},
    {0xDA,	"NAND 2G 3.3V 8 bit",		2048,	0, 		NULL},
    {0xB5,	"NAND 2G 1.8V 16 bit",		2048,	0, 		NULL},
    {0xC5,	"NAND 2G 3.3V 16 bit",		2048,	0, 		NULL},

    // 32 Gigabit
    {0xA7,	"NAND 4G 1.8V 8 bit",		4096,	0, 		NULL},
    {0xD7,	"NAND 4G 3.3V 8 bit",		4096,	0, 		NULL},
    {0xB7,	"NAND 4G 1.8V 16 bit",		4096,	0, 		NULL},
    {0xC7,	"NAND 4G 3.3V 16 bit",		4096,	0, 		NULL},

	{0x00,	"Unknown",					0,		0,		NULL},

};

// ��ü����
const nand_vendor_info_t nand_vendor_infos[] =
{
	{ .id = 0xEC,	.name = "Samsung",  },
	{ .id = 0x98,	.name = "Toshiba",  },
	{ .id = 0x20,	.name = "ST Micro", },
	{ .id = 0x2C,	.name = "Micron",	},
	{ .id = 0x01,	.name = "Spensor", 	},
	{ .id = 0xAD,	.name = "Hynix", 	},
	{ .id = 0,		.name = "Unknown", 	}
};


