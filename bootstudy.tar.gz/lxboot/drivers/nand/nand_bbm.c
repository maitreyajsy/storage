/*
 * nand_bbm.c
 *
 * Nand Bad Block Management by junorion
 *
 * Copyright (C)
 */


#if (USE_NAND && USE_NAND_BBM)
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <command.h>
#include <nand.h>
#include <nand_bbm.h>


struct nand_bad_block_mng * nand_bbm = NULL;
struct bbm_blkmap nand_bbm_blkmap;
unsigned int * nand_bbm_bitmap = NULL;
unsigned int nand_bbm_check = 0;
unsigned int assign_index = 0;
unsigned int bb_count_data = 0;
unsigned int bb_count_redirect = 0;
unsigned int redirect_size;
unsigned int redirect_start;

int bbm_dirty_flag;
int nand_bbm_debug;


static unsigned int bbm_pos = 0;
#if (BBM_INFO_DUP)
static unsigned int bbm_backup_pos = 0;
#endif

static int need_save_info = 0;

static unsigned int block_count;
static unsigned int bbm_data_size;

static int nand_bbm_init_data(struct nand_info* nand)
{
	block_count = BLOCK_INDEX(nand, nand->chip_size);

	// calculate the size of nand_bad_block_mng
	bbm_data_size = 3*sizeof(unsigned int) + sizeof(struct bbm_mapinfo)*block_count;
	//bbmsize = ((bbmsize + nand->page_size - 1)/nand->page_size) * nand->page_size;	// align on page_size

	if(nand_bbm) free(nand_bbm);
	if(nand_bbm_bitmap) free(nand_bbm_bitmap);

	nand_bbm = (struct nand_bad_block_mng *)malloc(bbm_data_size);
	nand_bbm_bitmap = (unsigned int *)malloc(sizeof(unsigned int)*block_count);

	if(nand_bbm == NULL || nand_bbm_bitmap == NULL)
	{
		bbm_print("malloc failed\n");
		return -1;
	}

	return 0;
}

static unsigned int nand_bbm_find_pos(struct nand_info * nand)
{
#if (!BBM_INFO_DUP)
	bbm_pos = BBM_INFO_POS;
#else
	unsigned int pos = 0;

//	bbm_debug("nand_bbm_check = %d\n", nand_bbm_check);

	bbm_pos = bbm_backup_pos = 0;

	for (pos = BBM_INFO_START; pos < BBM_INFO_END; pos += nand->block_size)
	{
		if (nand_block_isbad(pos) == 0)
		{
			bbm_pos = pos;
			break;
		}
	}

	if(pos == BBM_INFO_END)
	{
		bbm_print("Find bbm info failed... All block is bad block in BBM info region\n");
		return 0;
	}

	for (pos = (BBM_INFO_END-nand->block_size); pos > bbm_pos; pos -= nand->block_size)
	{
		if (nand_block_isbad(pos) == 0)
		{
			bbm_backup_pos = pos;
			break;
		}
	}

	if(pos == bbm_pos)
	{
		bbm_print("Find bbm info failed... All block is bad block in BBM info region\n");
		return 0;
	}
#endif
	return 0;
}

/*
 * badpos�� �ش��ϴ� block�� bad blockó���ϰ� reserved ������ block�� �Ҵ��Ѵ�.
 * �űԷ� �Ҵ�� block�� orgpos��ġ�� replace �ǵ��� bbm_bitmap ������ ������Ʈ �Ѵ�.
 */
unsigned int nand_bbm_assign_block(struct nand_info * nand, unsigned int orgpos, unsigned int badpos, int blkcopy)
{
	unsigned int pos = 0;
	unsigned int old_nand_bbm_check;

	bbm_debug("badpos = 0x%08x, assign_index = %x\n", (u32)badpos, (u32)assign_index);
	bbm_debug("BLOCK_INDEX(BBM_REDIR_START) = %x, BLOCK_INDEX(BBM_REDIR_END) = %x\n",
			(u32)BLOCK_INDEX(nand, BBM_REDIR_START), (u32)BLOCK_INDEX(nand, BBM_REDIR_END));

	old_nand_bbm_check = nand_bbm_check;
	nand_bbm_check = 0;

	do {
		if(assign_index <= BLOCK_INDEX(nand, BBM_REDIR_START))
		{
			bbm_print("There is no reserved block : plz check bbm info\n");
			return badpos;
		}

		bbm_debug("check bad block (index:%d, pos:%08x)\n", (u32)assign_index, (u32)BLOCK_POS(nand, assign_index));

		// assign index�� ������ bad block�� �ƴϸ� nand_bbm_bitmap�� ���� �����ϰ� break
		if(nand_block_isbad(BLOCK_POS(nand, assign_index)) == 0)
		{
			nand_bbm_bitmap[BLOCK_INDEX(nand, orgpos)] = (BBM_BB_MASK | assign_index) ;
			nand_bbm_bitmap[assign_index] |= BBM_REDIR_MASK ;
			pos = BLOCK_POS(nand, assign_index);
			assign_index--;
			bb_count_data++;
			bbm_dirty_flag++;
			break;
		}
		nand_bbm_bitmap[assign_index] |= BBM_BB_MASK ;
		bb_count_redirect++;
		assign_index--;
	} while(1);

#if 0 /* in kernel */
	if(blkcopy) {
		// copy badpos -> redirectpos
		badpos = BLOCK_POS(chip, BLOCK_INDEX(chip, badpos));
		//nand_bbm_erase_block(nand, pos);
		nand_bbm_copy_block(nand, badpos, pos);
	}
#endif

	/* �̹� replace�� block�� bad block�� ��쿡 ���� ó�� */
	if(orgpos != badpos)
	{
		nand_bbm_bitmap[BLOCK_INDEX(nand, badpos)] = (BBM_BB_MASK | BLOCK_INDEX(nand, badpos)) ;
	}

	nand_bbm_check = old_nand_bbm_check;

	bbm_debug("return pos(0x%08x)\n", (u32)pos);
	return pos;
}

/*
 * bbm bitmap ������ �ʱ�ȭ �Ѵ�. �� bad block�� ���� ���·� �����.
 */
void nand_bbm_info_init(struct nand_info * nand)
{
	unsigned int pos;

	bbm_debug("Init nand bad block information...\n");

	assign_index = (BBM_REDIR_END/nand->block_size) - 1;
	bb_count_data = bb_count_redirect = 0;

	nand_bbm->magic = BBM_MAGIC;
	nand_bbm->bb_count = 0;
	nand_bbm->assign_index = assign_index;

	for(pos = 0; pos < nand->chip_size; pos += nand->block_size)
	{
		nand_bbm_bitmap[BLOCK_INDEX(nand, pos)] = BLOCK_INDEX(nand, pos);
	}

}

/*
 * nand flash���� bbm ������ �ε��Ͽ� bbm_bitmap ������ bad block ������ �ݿ��Ѵ�.
 * �� �������� BBM ������ bbm_bitmap �� �̿��Ͽ� ó���ϰ� �ȴ�.
 */
static int nand_bbm_info_load(struct nand_info *nand)
{
	unsigned int pos, bb_index, reloc_index;
	unsigned int rindex;
	int ret = 0, i;
#if BBM_INFO_DUP
	int check = 0;
#endif

	nand_bbm_find_pos(nand);

	pos = bbm_pos;

#if BBM_INFO_DUP
load_bbm_info:
#endif
	/* load bad block info */
	bbm_debug ("Loading nand bad block info(%p+%p)...\n", (void*)pos, (void*)bbm_data_size);

//	printf("NAND BBM INFO OFFSET : 0x%X\n",pos);
//	printf("NAND BBM DATA SIZE : 0x%X\n",bbm_data_size);
	ret = nand_read(pos, bbm_data_size, (void*)nand_bbm);
	if(ret < 0)
	{
		bbm_print("nand read failed...(%d) --;;\n", ret);
		return ret;
	}

	if(nand_bbm->magic == BBM_PHY_MAGIC) {
		bbm_debug("First boot after Gang writing(magic : %x)\n", nand_bbm->magic);
		nand_bbm->magic = BBM_MAGIC;
		need_save_info = 1;
	}
	else if (nand_bbm->magic == BBM_PHY_MAGIC_BIG_ENDIAN)
	{
		bbm_debug("First boot after Gang writing with Big Endian(magic : %x)\n", nand_bbm->magic);
		nand_bbm->magic = BBM_MAGIC;
		nand_bbm->bb_count = SWAP32(nand_bbm->bb_count);
		nand_bbm->assign_index = SWAP32(nand_bbm->assign_index);

		if(nand_bbm->bb_count > block_count)
		{
			bbm_print("bb count is over block count. bb_count=%d\n", nand_bbm->bb_count);
			nand_bbm->bb_count = block_count;
		}

		for(pos = 0; pos < nand_bbm->bb_count; pos++)
		{
			nand_bbm->maps[pos].bb_index = SWAP32(nand_bbm->maps[pos].bb_index);
			nand_bbm->maps[pos].reloc_index= SWAP32(nand_bbm->maps[pos].reloc_index);
		}
		need_save_info = 1;
	}

	bbm_debug("bbm->magic = %lx\n", nand_bbm->magic);
	if(nand_bbm->magic == BBM_MAGIC) {

		// �켱 nand_bbm_bitmap�� ��� 1:1 �������� �ʱ�ȭ �Ѵ�.
		for(pos = 0; pos < nand->chip_size; pos += nand->block_size) {
			nand_bbm_bitmap[BLOCK_INDEX(nand, pos)] = BLOCK_INDEX(nand, pos);
		}

		// bb_count�� block_count�� ũ�� bb count over... �׷��� �׷�����....
		bbm_debug("nand_bbm->bb_count = %lx\n", nand_bbm->bb_count);
		if(nand_bbm->bb_count > block_count)
		{
			bbm_print("bb count is over block count. bb_count=%d\n", nand_bbm->bb_count);
			nand_bbm->bb_count = block_count;
		}

		bb_count_data = bb_count_redirect = 0;
		rindex = (BBM_REDIR_END/nand->block_size) ; // rindex�� ������ ������ index
		for(i=0; i<nand_bbm->bb_count; i++)
		{
			bbm_debug("%s] [%d] maps(%x, %x)\n", __func__, i,
					(u32)nand_bbm->maps[i].bb_index, (u32)nand_bbm->maps[i].reloc_index);

			bb_index = nand_bbm->maps[i].bb_index;
			reloc_index = nand_bbm->maps[i].reloc_index;

			if(!bb_index && !reloc_index)
				break;

			rindex = min(rindex, reloc_index);

			nand_bbm_bitmap[bb_index] = BBM_BB_MASK | reloc_index;
			nand_bbm_bitmap[reloc_index] |= BBM_REDIR_MASK;

			if(BLOCK_POS(nand, bb_index) != BLOCK_POS(nand, reloc_index))
			{
				bbm_debug("bb_count_data : BLOCK_POS(nand, bb_index) = %lx, BLOCK_POS(nand, reloc_index) = %lx\n",
					BLOCK_POS(nand, bb_index), BLOCK_POS(nand, reloc_index));
				bb_count_data++;
			}

			if(bb_index >= BLOCK_INDEX(nand, BBM_REDIR_START))
			{
				bbm_debug("bb_count_redirect : BLOCK_POS(nand, bb_index) = %lx, BLOCK_POS(nand, reloc_index) = %lx\n",
					BLOCK_POS(nand, bb_index), BLOCK_POS(nand, reloc_index));
				bb_count_redirect++;
			}
		}

		for(i=rindex; i<BLOCK_INDEX(nand, BBM_REDIR_END); i++)
		{
			if(!(nand_bbm_bitmap[i] & (BBM_BB_MASK|BBM_REDIR_MASK)))
			{
				nand_bbm_bitmap[i] = BBM_BB_MASK | i;
				bb_count_redirect++;
			}
		}

		// check bad count
		if(nand_bbm->bb_count != (bb_count_data+bb_count_redirect)) {
			bbm_print("Bad block count(%lx) is unmatched(%d+%d)\n",
				nand_bbm->bb_count, (int)bb_count_data, (int)bb_count_redirect);
			//goto not_ok;
		}

		// check assign index
		assign_index = (rindex-1);
		bbm_debug("rindex = %lx, assign_index = %lx\n", rindex, assign_index);
		if(assign_index != nand_bbm->assign_index) {
			bbm_print("Somthing wrong ...!!! assign_index(%lx) is unmatched\n", nand_bbm->assign_index);
			goto not_ok;
		}

		goto load_ok;
	}
	else
	{
	#if !defined(FIRST_BOOT)
		printf("ERROR :: %s: Invalid bbm magic %lx should be %x\n", __func__, nand_bbm->magic, BBM_MAGIC);
	#endif
	}

	#if BBM_INFO_DUP
	if(check++)
		goto not_ok;

	if(bbm_backup_pos) {
		pos = bbm_backup_pos;
		goto load_bbm_info;
	}
	#endif
not_ok:
	bbm_debug ("%s: Load backup bbm info failed...\n", __func__);
	return (1);

load_ok:
	bbm_debug ("%s: Loading nand bad block info...ok\n", __func__);
	return 0;
}

/*
 * nand_bbm_bitmap�� �����ϴ� BBM ������ nand_bad_block_mng ����ü�� �°�(nand_bbm)
 * �����Ͽ� flash�� �����Ѵ�.
 */
static int nand_bbm_info_save(struct nand_info * nand)
{
#if !defined(FIRST_BOOT)
	unsigned int pos;
	int rc, i;
	int index;

#if BBM_INFO_DUP
	int check = 0;
#endif

	memset(nand_bbm, 0, bbm_data_size);

	nand_bbm->magic = BBM_MAGIC;
	nand_bbm->bb_count = (bb_count_data + bb_count_redirect);
	nand_bbm->assign_index = assign_index;

	index = 0;
	for(i=BBM_BLK_DATA; i<=BBM_BLK_INFO; i++)
	{
		bbm_blkinfo_t * blkinfo = BBM_BLK_MAP(i);
		unsigned int start, end;
		start = blkinfo->offset;
		end = start + blkinfo->length;
		for(pos = start; pos < end; pos += nand->block_size)
		{
			if(nand_bbm_bitmap[BLOCK_INDEX(nand,pos)] & BBM_BB_MASK)
			{
				nand_bbm->maps[index].bb_index = BLOCK_INDEX(nand,pos);
				nand_bbm->maps[index].reloc_index = nand_bbm_bitmap[BLOCK_INDEX(nand,pos)] & BBM_IDX_MASK;
				bbm_debug("%08x -> %08x\n", (u32)nand_bbm->maps[index].bb_index, (u32)nand_bbm->maps[index].reloc_index);
				index++;
			}
		}
	}

	if(nand_bbm_find_pos(nand))
	{
		printf("find bbm pos error --;\n");
		return (-1);
	}

	pos = bbm_pos;

#if BBM_INFO_DUP
save_bbm_info:
#endif
	/* save bbm info */
	bbm_debug("save bbm info(%p)\n", (void*)pos);

	rc = nand_write(pos, bbm_data_size, (void*)nand_bbm);
// TODO: fail�� ��쿡 ���� ó���� �Ǿ�� �� ��...

#if BBM_INFO_DUP
	if(check++)
		return 0;

	if(bbm_backup_pos)
	{
		pos = bbm_backup_pos;
		goto save_bbm_info;
	}
#endif

#endif	// #if !defined(FIRST_BOOT)
	return 0;
}

/*
 * nand�� ��ĵ�ϸ� bad block�� ��� bbm_bitmap ������ ������Ʈ �Ѵ�.
 * ���� ����Ÿ�� �ʱ�ȭ �ϰų� �ϴ� ��ƾ�� �������� ������
 * bad block�� ������ ��� ���� bbm_bitmap����Ÿ�� �߰��� �ȴ�.
 */
static int nand_bbm_info_setup(struct nand_info * nand)
{
	unsigned int ofs;
	int i;

	for(i=BBM_BLK_DATA; i<BBM_BLK_INFO; i++)
	{
		bbm_blkinfo_t * blkinfo = BBM_BLK_MAP(i);
		unsigned int start, end;
		start = blkinfo->offset;
		end = start + blkinfo->length;
		for(ofs = start; ofs < end; ofs += nand->block_size)
		{
			unsigned int to;
			if(nand_block_isbad(ofs))
			{
				bbm_print("\t0x%08x is bad block => ", (unsigned int)ofs);
				to = nand_bbm_assign_block(nand, ofs, ofs, 0);
				bbm_print("0x%08x\n", (unsigned int)to);
			}
		}
	}

	return 0;
}

static const char *bbm_blkmap_str[] =
{
	"data block ",
	"info block ",
	"redir block"
};

static void nand_bbm_blkmap_print(void)
{
	bbm_blkinfo_t * blkinfo;
	int i;

	printf("block map : \n");
	for(i=BBM_BLK_DATA; i<=BBM_BLK_REDIR; i++)
	{
		blkinfo = BBM_BLK_MAP(i);
		printf("\t %s : ", bbm_blkmap_str[i]);
		printf("0x%08x (+0x%08x)\n", (u32)blkinfo->offset, (u32)blkinfo->length);
	}
}

static void nand_bbm_print(struct nand_info * nand)
{
	unsigned int bb_count, index;

	bb_count = bb_count_data + bb_count_redirect;

	printf("nand bad block information:\n");
	nand_bbm_blkmap_print();
	printf("magic = 0x%08lx\n", nand_bbm->magic);
	printf("bad block count = %ld(%ld+%ld)\n", bb_count, bb_count_data, bb_count_redirect);
	printf("assign index = %ld\n", assign_index);

	for (index = 0; index < bb_count; index++)
	{
		printf(" %08x -> %08x\n", (u32)nand_bbm->maps[index].bb_index, (u32)nand_bbm->maps[index].reloc_index);
	}

	for (index = 0; index < block_count; index++)
	{
		if((index%32)==0)
			printf("[%04lx~%04lx] ", index, index+31);

		if(nand_bbm_bitmap[index] & BBM_BB_MASK)
		{
			printf("B ");
		}
		else if(nand_bbm_bitmap[index] & BBM_REDIR_MASK)
		{
			printf("R ");
		}
		else
		{
			printf(". ");
		}

		if((index%32) == 31)
			printf("\n");
	}

}


/*
 * nand flash�� bad block ������ ����Ѵ�.
 */
static int nand_bbm_info_bad(struct nand_info * nand)
{
	unsigned int from;
	unsigned int badcount = 0;

	for (from = 0; from < nand->chip_size; from += nand->block_size)
	{
		if (nand_block_isbad(from))
		{
			++badcount;
			printf("0x%8.8lx is bad (%ld)\n", from, badcount);
		}
	}
	printf("bad count = %ld\n", badcount);
	return 0;
}



int nand_bbm_init(struct nand_info *nand)
{
	nand_bbm_debug = NAND_BBM_DEBUG;

	bbm_debug("Init nand bad block information...\n");

	redirect_size	= (nand->chip_size >> 5);
	redirect_start	= (nand->chip_size - redirect_size);

	bbm_debug("redirect_size = %lx, redirect_start = %lx\n", redirect_size, redirect_start);
/*
	printf("NAND BBM : redirect_size = 0x%X\n",redirect_size);
	printf("NAND BBM : redirect_start = 0x%X\n",redirect_start);

	printf("NAND BBM : BBM_DATA_POS 0x%X\n",BBM_DATA_POS);
	printf("NAND BBM : BBM_DATA_POS 0x%X\n",BBM_DATA_SIZE);
	printf("NAND BBM : BBM_INFO_POS 0x%X\n",BBM_INFO_POS);
	printf("NAND BBM : BBM_INFO_SIZE 0x%X\n",BBM_INFO_SIZE);
	printf("NAND BBM : BBM_REDIR_POS 0x%X\n",BBM_REDIR_POS);
	printf("NAND BBM : BBM_REDIR_SIZE 0x%X\n",BBM_REDIR_SIZE);
*/
	// init block map
	nand_bbm_blkmap.blkinfo[0].offset = BBM_DATA_POS;
	nand_bbm_blkmap.blkinfo[0].length = BBM_DATA_SIZE;
	nand_bbm_blkmap.blkinfo[1].offset = BBM_INFO_POS;
	nand_bbm_blkmap.blkinfo[1].length = BBM_INFO_SIZE;
	nand_bbm_blkmap.blkinfo[2].offset = BBM_REDIR_POS;
	nand_bbm_blkmap.blkinfo[2].length = BBM_REDIR_SIZE;

	if(nand_bbm_debug) nand_bbm_blkmap_print();

	assign_index = (BBM_REDIR_END / nand->block_size) - 1;
	nand_bbm_check = 0;

	need_save_info = 0;

	nand_bbm_init_data(nand);

	if(nand_bbm_info_load(nand))
	{
		nand_bbm_info_init(nand);
	#if !defined(FIRST_BOOT)
		printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("ERROR :: Failed to load bbminfo. Check bbminfo structure!.\n");
		printf("         Here initialize bbminfo but don't save it.\n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
		//nand_bbm_info_save(nand);
	#endif
	}
	else
	{
#if !defined(FIRST_BOOT)
		printf("NAND BBM : Initialized\n");
#endif
	}

#if !defined(FIRST_BOOT)
	if (need_save_info)
		nand_bbm_info_save(nand);
#endif

#if BBM_INFO_DUP
	if((bbm_pos) && (bbm_pos != bbm_backup_pos))
#endif
	nand_bbm_check = 1;

	bbm_debug("End bbm init\n");

	return 0;
}

int nand_bbm_update(struct nand_info * nand)
{
	if(bbm_dirty_flag && nand_bbm_check)
	{
		bbm_debug("bbm dirty : saveinfo\n");

		nand_bbm_check = 0;
		nand_bbm_info_save(nand);
		nand_bbm_check = 1;

		bbm_dirty_flag = 0;
	}

	return 0;
}


static int nand_bbm_cmd(int argc, char **argv)
{
	struct nand_info* nand = get_nand_info();

	if(argc == 1)
	{
		nand_bbm_print(nand);
		return 0;
	}

	if(argc == 2)
	{
		nand_bbm_check = 0;

		if(strcmp(argv[1], "init")==0)
		{
			nand_bbm_info_init(nand);
		}
		else if(strcmp(argv[1], "load")==0)
		{
			nand_bbm_info_load(nand);
		}
		else if(strcmp(argv[1], "save")==0)
		{
			nand_bbm_info_save(nand);
		}
		else if(strcmp(argv[1], "bad")==0)
		{
			nand_bbm_info_bad(nand);
		}
		else if(strcmp(argv[1], "setup")==0)
		{
			nand_bbm_info_init(nand);
			nand_bbm_info_setup(nand);
			nand_bbm_info_save(nand);
		}
		else
		{
			nand_bbm_print(nand);
		}

		nand_bbm_check = 1;

		return 0;
	}

#if NAND_BBM_DEBUG
	if((argc == 3) && strcmp(argv[1], "debug")==0)
	{
		nand_bbm_debug = (int)strtoul(argv[2], NULL, 10);
		return 0;
	}
#endif

	command_error(argv[0]);
	return 0;
}

COMMAND(bbm, nand_bbm_cmd,
		"nand bad block management",
		"bbm init/load/save/print \\n");


#endif

