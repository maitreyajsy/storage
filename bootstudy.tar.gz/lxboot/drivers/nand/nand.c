/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if USE_NAND
#include <types.h>
#include <debug.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <partinfo.h>
#include <nand.h>
#include <nand_bbm.h>
#include <command.h>
#include <util.h>
#include <storage.h>

static struct nand_info _nand_info;

static struct nand_info* nand = &_nand_info;
static nand_driver_t* driver;

static int nand_inited = 0;

#define NOT_ALIGNED(x,s)			(((x) & (s-1)) != 0)

#define OFFSET_TO_PAGE(o)			((o)>>nand->page_shift)
#define OFFSET_TO_BLOCK(o)			((o)>>nand->block_shift)

#define PAGE_TO_OFFSET(p)			((p)<<nand->page_shift)
#define BLOCK_TO_OFFSET(b)			((b)<<nand->block_shift)

#define BLOCK_TO_PAGE(b)			((b)<<(nand->block_shift-nand->page_shift))



static inline int nand_check_init(void)
{
	if(!nand_inited)
	{
		printf("^r^Nand is not inited !\n");
		return -1;
	}
	return 0;
}

#if USE_STORAGE_DMA_READ
typedef struct nand_cmd_data
{
	uint32_t		from;		// start offset
	uint32_t		len;		// size
	uint8_t*		buf;		// buffer

	uint32_t		current;

	struct
	{
		int			aligned;
		uint8_t*	buf;
		int			bytes;
		u32 		column;
	} last;

	nand_callback_t*	user_callback;		// called after one page reading
} nand_read_cmd_t;


static nand_irq_callback_t nand_irq_callback;

static void nand_request_read(nand_read_cmd_t* cmd);

/* This function is called in interrupt mode. So keep in mind that ! */
static int nand_read_nonblock_end(nand_read_cmd_t* cmd, int result)
{
	if(cmd->user_callback)
	{
		cmd->user_callback(cmd->current, result);
	}

	if(driver->dma_read_stop) driver->dma_read_stop();
	free(cmd);

	return 0;
}


static void nand_read_nonblock_next(void* data, int ecc_fail)
{
	nand_read_cmd_t* cmd = (nand_read_cmd_t*)data;

	if(ecc_fail)
	{
		int i;
		//printf("nand_read_next. ecc fail !\n");

		// it takes a long time, just check the oob data.
		for(i=0; i<nand->oob_size/4; i++)
		{
			if(((uint32_t*)nand->oob_buf)[i] != 0xffffffff)
			{
				printf("ECC ERROR!\n");
				nand_read_nonblock_end(cmd, NAND_DMA_READ_STATUS_ECC_ERROR);
				return;
			}
		}
	}

	if(cmd->last.bytes)
	{
		if(cmd->last.aligned)
		{
	#if USE_DATA_CACHE
			dcache_inv_range((unsigned long)cmd->last.buf, cmd->last.bytes);
	#endif
		}
		else
		{
			memcpy(cmd->last.buf, nand->data_buf + cmd->last.column, cmd->last.bytes);
		}
	}

	/* Call user function when one page reading is done ! */
	if(cmd->user_callback)
	{
		cmd->user_callback(cmd->current, 0);
	}

	if(cmd->current >= cmd->len)
	{
		if(cmd->current > cmd->len) printf("Check code !\n");

		nand_read_nonblock_end(cmd, NAND_DMA_READ_STATUS_COMPLETED);
		// Success! the end of operation.
	}
	else
	{
		/* Read next page */
		nand_request_read(cmd);
	}

}


static void nand_request_read(nand_read_cmd_t* cmd)
{
	u32 page_virt, page_phys;
	u32 column;
	void* rbuf;
	int aligned;
	int rsize;

	uint32_t offset;
	uint8_t *buf;
	size_t len;

	offset = cmd->from + cmd->current;
	buf = cmd->buf + cmd->current;
	len = cmd->len - cmd->current;

	page_virt = offset >> nand->page_shift;
	column = offset & (nand->page_size - 1);

	rsize = min(nand->page_size - column, len);
	aligned = (rsize == nand->page_size);

	page_phys = page_virt;
	NAND_BBM_ADJUST_PAGE(nand, page_phys);


	rbuf = aligned ? buf : nand->data_buf;

#if USE_DATA_CACHE
	if(aligned)
	{
		dcache_inv_range((unsigned long)buf, nand->page_size);
	}
#endif

	if(driver->dma_read_start(page_phys, nand->page_size, nand->oob_size, rbuf, nand->oob_buf, &nand_irq_callback) < 0)
	{
		nand_read_nonblock_end(cmd, NAND_DMA_READ_STATUS_DRV_ERROR);
		return;
	}

	cmd->last.aligned = aligned;
	cmd->last.buf = buf;
	cmd->last.bytes = rsize;
	cmd->last.column = column;

	cmd->current += rsize;

}


int nand_dma_read_start(uint32_t offset, size_t len, void* buf, nand_callback_t *callback)
{
	nand_read_cmd_t* cmd;

	if(nand_check_init() < 0)
		return -1;

	if((offset + len) > nand->chip_size)
	{
		WARN("It's over nand chip size\n");
		return -1;
	}

	cmd = (nand_read_cmd_t*)calloc(1, sizeof(nand_read_cmd_t));

	cmd->from = (uint32_t)offset;
	cmd->len = (uint32_t)len;
	cmd->buf = (uint8_t*)buf;

	cmd->user_callback = callback;

	nand_irq_callback.handler = nand_read_nonblock_next;
	nand_irq_callback.arg = cmd;

	nand_request_read(cmd);

	return 0;
}

int nand_dma_read_stop(void)
{
	return 0;
}
#endif


int nand_erase_block(uint32_t block, size_t count, int scrub)
{
	int rc;
	int remained;
#if USE_NAND_BBM
	uint32_t block_phys;
	unsigned int old_nand_bbm_check = 0;
#endif

	if(nand_check_init() < 0)
		return -1;

	remained = count;

#if USE_NAND_BBM
	if(scrub)
	{
		old_nand_bbm_check = nand_bbm_check;
		nand_bbm_check = 0;
	}
#endif

	while (remained > 0)
	{
#if USE_NAND_BBM
		block_phys = block;
		NAND_BBM_ADJUST_CHECK_BLOCK(nand, block_phys, 0);
		rc = driver->erase_block(BLOCK_TO_PAGE(block_phys));
		if(rc < 0 && nand_bbm_check)
		{
			nand_bbm_assign_block(nand, BLOCK_TO_OFFSET(block), BLOCK_TO_OFFSET(block_phys), 0);
			continue;
		}
#else
		if(!scrub && nand_block_isbad(BLOCK_TO_OFFSET(block)))
		{
			WARN("can't erase. block is bad\n");
			return -1;
		}

		rc = driver->erase_block(BLOCK_TO_PAGE(block));
#endif
		if(rc < 0)
		{
			printf("^y^erase fail. offset=0x%08x(%d)\n", BLOCK_TO_OFFSET(block), block);
			if(!scrub) return -1;
		}

		remained--;
		block++;
	}

#if USE_NAND_BBM
	if(scrub)
	{
		nand_bbm_check = old_nand_bbm_check;
	}
#endif

	return 0;
}

int nand_erase(uint32_t offset, size_t len)
{
	if(nand_check_init() < 0)
		return -1;

	if(NOT_ALIGNED(offset, nand->block_size) || NOT_ALIGNED(len, nand->block_size))
	{
		NAND_ERROR("addr or len is not align on block size\n");
		return -1;
	}

	return nand_erase_block(OFFSET_TO_BLOCK(offset), OFFSET_TO_BLOCK(len), 0);
}

int nand_write_page(uint32_t page, size_t count, const void* buf)
{
	int remained;
	uint32_t page_phys;
	int ret;

	if(nand_check_init() < 0)
		return -1;

	if(!count) return 0;

	remained = count;
	while(remained > 0)
	{
		page_phys = page;
		NAND_BBM_ADJUST_PAGE(nand, page_phys);

		memcpy(nand->data_buf, buf, nand->page_size);
		memset(nand->oob_buf, 0xff, nand->user_oob);

		ret = driver->write_page(page_phys, nand->page_size, nand->user_oob, nand->data_buf, nand->oob_buf);
#if !defined(NOT_USE_NAND_VERIFY_WRITE)
		if(ret == 0)
		{
			ret = driver->read_page(page_phys, nand->page_size, nand->oob_size, nand->data_buf, nand->oob_buf);
			if(ret == 0)
			{
				ret = memcmp(buf, nand->data_buf, nand->page_size);
				if(ret != 0)
				{
					WARN("verify error !!!. page=0x%x\n", page);
				}
			}
			else
			{
				printf("nand verify read fail!\n");
			}
		}
		else
		{
			printf("nand write fail!\n");
		}
#endif

		if(ret)
		{
#if USE_NAND_BBM
			uint32_t org = PAGE_TO_OFFSET(page);
			uint32_t ofs = PAGE_TO_OFFSET(page_phys);
			//chip->block_markbad(mtd, PAGE_POS(chip,realpage));
			bbm_print("\t%s] 0x%08x is bad block => ", __func__, (unsigned int)ofs);
			ofs = nand_bbm_assign_block(nand, (unsigned int)org, (unsigned int)ofs, 1);
			bbm_print("0x%08x\n", (unsigned int)ofs);
//			bbm_print("\n\n Re-Try nand write ops (page = %p)\n", ((void*)page));
			continue;
#else
			break;
#endif
		}

		remained--;
		page++;
		buf += nand->page_size;
	}

	return (count - remained);

}


#define FLAG_NAND_WRITE_MSG		0x01
#define NAND_WRITE_MSG(flag, fmt, args...)	\
	do{										\
		if(flag&FLAG_NAND_WRITE_MSG)		\
		{									\
			printf(fmt, ##args);			\
		}									\
	}while(0)

static int _nand_write(uint32_t offset, size_t len, const void* buf, int flag)
{
	static uint8_t	wbuf[NAND_MAX_BLOCK_SIZE];
	const uint8_t*	data;
	uint32_t 		start, block_offset;
	int				remained, rc;
	int 			sz;

	if(nand_check_init() < 0)
		return -1;

	block_offset = offset % nand->block_size;
	start  = offset - block_offset;

	data = (const uint8_t*)buf;
	remained = len;

	do
	{
		rc = nand_read(start, nand->block_size, wbuf);

		if (remained <= (nand->block_size - block_offset))
		{
			sz = remained;
			remained = 0;
		}
		else
		{
			sz = nand->block_size - block_offset;
			remained -= (nand->block_size - block_offset);
		}
		NAND_WRITE_MSG(flag, "\t w[Offs:%08x, Src:%08x Size:%05x]", start, data, sz);

		if(memcmp(wbuf + block_offset, data, sz) == 0)
		{
			NAND_WRITE_MSG(flag, " -> Skip\n");
		}
		else
		{
			memcpy(wbuf + block_offset, data, sz);
			NAND_WRITE_MSG(flag, ", Erasing");

			rc = nand_erase_block(OFFSET_TO_BLOCK(start), 1, 0);
			if(rc < 0) goto error;

			NAND_WRITE_MSG(flag, ", Writing  ");
			rc = nand_write_page(OFFSET_TO_PAGE(start), OFFSET_TO_PAGE(nand->block_size), wbuf);
			if(rc < 0) goto error;

			NAND_WRITE_MSG(flag, "\b\b -> Done\n");
		}

		start += nand->block_size;
		data += sz;

		if(block_offset) block_offset = 0;

	} while (remained > 0);

	nand_sync();

	return 0;

error:
	NAND_WRITE_MSG(flag, "\b\b -> Fail\n");
	return -1;
}

int nand_write(uint32_t offset, size_t len, const void* buf)
{
	return _nand_write(offset, len, buf, 0);
}


/*
 * nand_write with message(writing status)
 */
int nand_write_image(uint32_t offset, size_t len, const void* buf)
{
	return _nand_write(offset, len, buf, FLAG_NAND_WRITE_MSG);
}

static int nand_block_bad(uint32_t offset)
{
	uint32_t page;

	if(nand_check_init() < 0)
		return -1;

	page = offset >> nand->page_shift;
	driver->read_page(page, nand->page_size, nand->oob_size, nand->data_buf, nand->oob_buf);

	if(nand->oob_buf[nand->badmark_offset] != 0xff)
	{
		return 1;
	}

	return 0;
}

int nand_block_isbad(uint32_t offset)
{
	if(nand_check_init() < 0)
		return -1;

	NAND_BBM_ADJUST_CHECK(nand, offset, 0);
	return nand_block_bad(offset);
}

int nand_block_markbad(uint32_t offset)
{
	uint8_t *oob_data;
	int page;

	if(nand_check_init() < 0)
		return -1;

	if (nand_block_isbad(offset) > 0)
	{
		return 0;
	}

	NAND_BBM_ADJUST_CHECK(nand, offset, 0);

	page = (int)(offset >> nand->page_shift);

	driver->read_page(page, nand->page_size, nand->oob_size, nand->data_buf, nand->oob_buf);

	oob_data = (uint8_t*)nand->oob_buf;
	oob_data[nand->badmark_offset] = 0;

	driver->write_page(page, nand->page_size, nand->user_oob, nand->data_buf, nand->oob_buf);

	return 0;
}

int nand_read(uint32_t offset, size_t len, void* buf)
{
	u32 page_virt, page_phys;
	u32 column;
	void* rbuf;
	int aligned;
	int rsize, remained;

	if(nand_check_init() < 0)
		return -1;

	if((offset + len) > nand->chip_size)
	{
		WARN("It's over nand chip size\n");
		return -1;
	}

	remained = len;
	page_virt = offset >> nand->page_shift;
	column = offset & (nand->page_size - 1);

	while(1)
	{
		rsize = min(nand->page_size - column, remained);
		aligned = (rsize == nand->page_size);

		page_phys = page_virt;
		NAND_BBM_ADJUST_PAGE(nand, page_phys);

		rbuf = aligned ? buf : nand->data_buf;

#if USE_DATA_CACHE
		if(aligned)
		{
			dcache_inv_range((unsigned long)buf, nand->page_size);
		}
#endif

		if(driver->read_page(page_phys, nand->page_size, nand->oob_size, rbuf, nand->oob_buf) < 0)
		{
			WARN("read fail. page=%d\n", page_phys);
			return -1;
		}

		if(!aligned)
		{
			memcpy(buf, nand->data_buf + column, rsize);
		}
#if USE_DATA_CACHE
		else
		{
			dcache_inv_range((unsigned long)buf, nand->page_size);
		}
#endif


		buf = (uint8_t*)buf + rsize;
		remained -= rsize;

		if(remained <= 0)
			break;

		column = 0;

		page_virt++;
	}

	return (len - remained);
}

int nand_read_raw(uint32_t offset, void* data_buf, void* oob_buf)
{
	int rc;
	uint32_t page = offset >> nand->page_shift;

	if(nand_check_init() < 0)
		return -1;

#if USE_DATA_CACHE
	rc = driver->read_page(page, nand->page_size, nand->oob_size, nand->data_buf, nand->oob_buf);
	memcpy(data_buf, nand->data_buf, nand->page_size);
	memcpy(oob_buf, nand->oob_buf, nand->oob_size);
#else
	rc = driver->read_page(page, nand->page_size, nand->oob_size, data_buf, oob_buf);
#endif

	return rc;
}

void nand_sync(void)
{
	if(nand_check_init() < 0)
		return;

	NAND_BBM_UPDATE(nand);
}

struct nand_info* get_nand_info(void)
{
	return nand;
}
/*
 * NAND DRIVER�� lge nfc�� ���� �κ� ���������� �����Ͽ���.
 * �ٸ� controller�� ����Ҹ� ���� �� ���� layer�� �����Ѵٸ� ���⵵�� ������ �� ���Ƽ�...
 */
int nand_init(void)
{
	if(nand_inited)
		return 0;

	driver = get_nand_driver();
	if(driver == NULL)
		return -1;

	if(driver->init(nand) < 0)
		return -1;

	nand->data_buf = (uint8_t*)dma_malloc(NAND_MAX_PAGE_SIZE);
	nand->oob_buf = (uint8_t*)dma_malloc(NAND_MAX_OOB_SIZE);

	NAND_INFO("NAND Device : %s %s\n", nand->vendor_info->name, nand->dev_info->name);
	NAND_INFO("NAND Block Size : %u MByte\n", nand->chip_size / 1048576);

	nand_inited = 1;

#if USE_NAND_BBM
	nand_bbm_init(nand);
#endif

	return 0;
}

#ifndef FIRST_BOOT
static int cmd_nand(int argc, char* argv[])
{
	char *sub_cmd;
	u64 offset, size;
	u32 addr;
	char *endptr;
	int rc;

	if(argc < 2)
		goto usage;

	sub_cmd = argv[1];

	if(strcmp(sub_cmd, "init") == 0)
	{
		nand_init();
	}
	else if(strcmp(sub_cmd, "dump") == 0)
	{
		uint8_t *data;

		if(argc != 3) goto usage;

		offset = strtoul(argv[2], &endptr, 0);
		if(*endptr != '\0') goto usage;

		data = (uint8_t*)malloc(nand->page_size + nand->oob_size);
		nand_read_raw(offset, data, data + nand->page_size);

		printf("Page %08x(%08x) dump:\n", offset >> nand->page_shift, offset);

		hex_dump(offset, data, nand->page_size, 1);

		printf("OOB:\n");
		hex_dump(0, data + nand->page_size, nand->oob_size, 1);

		free(data);
	}
	else if(strcmp(sub_cmd, "erase") == 0 || strcmp(sub_cmd, "scrub") == 0)
	{
		int scrub = (strcmp(sub_cmd, "scrub") == 0) ? 1 : 0;

		if(argc == 2)
		{
			int in_char;
			printf("Really %s all the data in NAND ? <y/N> ", sub_cmd);
			in_char = getchar();
			printf("%c\n\n", isprint(in_char) ? in_char : ' ');

			if(in_char != 'y')
				return 0;

			offset = 0;
			size = nand->chip_size;
		}
		else
		{
			if(get_offset_size(argc - 2, argv + 2, &offset, &size) < 0)
				goto usage;
		}

		printf("NAND %s : ", scrub ? "scrub" : "erase");
		rc = nand_erase_block(OFFSET_TO_BLOCK(offset), OFFSET_TO_BLOCK(size), scrub);
		printf("%s\n", rc == 0 ? "OK" : "Fail");
	}
	else if(strcmp(sub_cmd, "write") == 0 || strcmp(sub_cmd, "read") == 0)
	{
		u32 tick, elapsed, speed;
		int write = (strcmp(sub_cmd, "write") == 0) ? 1 : 0;

		if(argc < 4) goto usage;

		addr = strtoul(argv[2], &endptr, 0);
		if(*endptr != '\0') goto usage;

		if(get_offset_size(argc - 3, argv + 3, &offset, &size) < 0)
			goto usage;

		printf("NAND %s: ", write ? "write" : "read");

		tick = timer_tick();
		if(write) rc = nand_write(offset, size, (void*)((ulong)addr));
		else rc = nand_read(offset, size, (void*)((ulong)addr));

		elapsed = timer_elapsed(tick);
		speed = (size/1024)*1000 / (elapsed/1000);

		printf(" %ld bytes %s: %s. %ldms elapsed, %ldKbps/sec\n", size,
					   write ? "written" : "read", rc < 0 ? "ERROR" : "OK", elapsed/1000, speed);

	}

	return 0;

usage:
	command_error(argv[0]);
	return -1;
}

COMMAND(nand, cmd_nand, "nand init,dump,erase,scrub,read,write",
		"init\n"
		"nand dump offset\n"
		"nand erase offset|partition size\n"
		"nand scrub offset|partition size\n"
		"nand read  addr offset|partition size\n"
		"nand write addr offset|partition size\n");
#endif


static int nand_read64(loff_t offset, size_t len, void* buf)
{
	return nand_read((uint32_t)offset, len, buf);
}

static int nand_write64(loff_t offset, size_t len, const void* buf)
{
	return nand_write((uint32_t)offset, len, buf);
}

static int nand_write64_image(loff_t offset, size_t len, const void* buf)
{
	return nand_write_image((uint32_t)offset, len, buf);
}

static int nand_erase64(loff_t offset, u64 len)
{
	return nand_erase((uint32_t)offset, (size_t)len);
}

#if USE_STORAGE_DMA_READ
static int nand_dma_read64_start(loff_t offset, size_t len, void* buf, nand_callback_t *callback)
{
	return nand_dma_read_start((uint32_t)offset, len, buf, callback);
}
#endif

STORAGE_FUNC_T nand_func_tbl =
{
	.info   = (void*)get_nand_info,
	.init   = (void*)nand_init,
	.read   = (void*)nand_read64,
	.write  = (void*)nand_write64,
	.wimage = (void*)nand_write64_image,
	.erase  = (void*)nand_erase64,
	#if USE_STORAGE_DMA_READ
	.dmard  = (void*)nand_dma_read64_start
	#endif
};

int init_nand_table(void)
{
	return register_storage(STORAGE_TYPE_NAND, &nand_func_tbl);
}
#endif	// #if USE_NAND
