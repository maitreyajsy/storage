/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <timer.h>
#include <i2c.h>
#include <thread.h>
#include <audio.h>


/*
*******************************************************************************
*                  GLOBAL FUNCTIONS
*******************************************************************************
*/
int __attribute__((weak))is_skip_audio_init(void){return 0;}
int __attribute__((weak))arch_audio_init(void){printf("arch_audio_init : enter\n");return 0;}

int audio_init(void)
{
	if(is_skip_audio_init())
		return 0;

	arch_audio_init();

	return 0;
}
