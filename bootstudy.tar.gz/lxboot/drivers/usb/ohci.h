/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifndef _OHCI_H_
#define _OHCI_H_


/* 4.2 Endpoint Descriptor */
typedef struct ohci_ed ohci_ed_t;
struct ohci_ed
{
	volatile u32	Control;
	volatile u32	TailP;
	volatile u32	HeadP;
	volatile u32	NextED;

//	usb_device_t*	dev;

	usb_pipe_t*		pipe;
	usb_req_t* 		req;
	u16				td_cnt;
	u16				td_processed;
} __attribute__((aligned(16)));


#define OHCI_ED_EPNUM_SHIFT		7
#define OHCI_ED_MPS_SHIFT		16

#define OHCI_ED_FADDR		(0x7F << 0)		/* FunctionAddress */
#define OHCI_ED_EPNUM		(0xF << 7)		/* EndpointNumber */
#define OHCI_ED_DIR			(0x3 << 11)		/* Direction */
#define OHCI_ED_DIR_FROM_TD		(0x0 << 11)
#define OHCI_ED_DIR_OUT			(0x1 << 11)
#define OHCI_ED_DIR_IN			(0x2 << 11)
#define OHCI_ED_SPEED		(0x1 << 13)
#define OHCI_ED_SKIP		(0x1 << 14)		/* sKip */
#define OHCI_ED_FORMAT		(0x1 << 15)		/* Format */
#define OHCI_ED_MPS			(0x7FF << 16)	/* MaximumPacketSize */

#define OHCI_ED_ADDR_MASK	0xFFFFFFF0
#define OHCI_ED_HALT_MASK	0x01

#define GET_OHCI_ED_FADDR(v)	(((v)&OHCI_ED_FADDR) >> 0)
#define GET_OHCI_ED_EPNUM(v)	(((v)&OHCI_ED_EPNUM) >> 7)

#define GET_OHCI_ED_ADDR(a)	((ulong)(a)&OHCI_ED_ADDR_MASK)


/* 4.3 Transfer Descriptors */
typedef struct ohci_td ohci_td_t;
struct ohci_td
{
	volatile u32	Control;
	volatile u32	CBP;		/* Current Buffer Pointer */
	volatile u32	NextTD;		/* Next TD */
	volatile u32	BE;			/* Buffer End */

	int				num;
	ohci_ed_t*		ed;
	u32				buf;
} __attribute__((aligned(16)));

#define OHCI_TD_ADDR_MASK	0xFFFFFFF0

#define OHCI_TD_R			(1 << 18)	/* bufferRounding */
#define OHCI_TD_DP			(0x3 << 19)	/* Direction/PID */
#define OHCI_TD_DP_SETUP		(0x0 << 19)
#define OHCI_TD_DP_OUT			(0x1 << 19)
#define OHCI_TD_DP_IN			(0x2 << 19)
#define OHCI_TD_DI			(0x7 << 21)	/* DelayInterrupt */
#define OHCI_TD_T			(0x3 << 24)	/* DataToggle */
#define OHCI_TD_T_TOGGLE		(0x0 << 24)
#define OHCI_TD_T_DATA0			(0x2 << 24)
#define OHCI_TD_T_DATA1			(0x3 << 24)
#define OHCI_TD_EC			(0x3 << 26)	/* ErroCount */
#define OHCI_TD_CC			(0xF << 28)	/* ConditionCode */

#define SET_OHCI_TD_DI(v)	(((v) << 21)&OHCI_TD_DI)
#define GET_OHCI_TD_CC(v)	(((v)&OHCI_TD_CC) >> 28)
#define SET_OHCI_TD_CC(v)	(((v) << 28)&OHCI_TD_CC)

#define GET_OHCI_TD_ADDR(a)	((ulong)(a)&OHCI_TD_ADDR_MASK)

/* 4.3.3 Completion Codes */
#define OHCI_CC_NE			0x0		/* No Error */
#define OHCI_CC_CRC			0x1
#define OHCI_CC_BS			0x2
#define OHCI_CC_DTM			0x3
#define OHCI_CC_STALL		0x4
#define OHCI_CC_DNR			0x5
#define OHCI_CC_PCF			0x6
#define OHCI_CC_UPID		0x7
#define OHCI_CC_DOVER		0x8
#define OHCI_CC_DUNDER		0x9
#define OHCI_CC_BOVER		0xC
#define OHCI_CC_BUNDER		0xD
#define OHCI_CC_NA			0xF		/* Not Accessed */




/* 4.4.1 Host Controller Communication Area Format */
typedef struct
{
	volatile u32		interrupt_table[32];
	volatile u16		frame_number;
	volatile u16		pad1;
	volatile u32		done_head;
	volatile u8			reserved[116];
} __attribute__((packed)) ohci_hcca_t;






/* 7. OPERATIONAL REGISTERS */
typedef struct ohci_reg
{
	/* The Control and Status Partition */
	volatile u32 const	hr;				/* HcRevision */
	volatile u32		hc;				/* HcControl */
	volatile u32		hcs;			/* HcCommandStatus */
	volatile u32		his;			/* HcInterruptStatus */
	volatile u32		hie;			/* HcInterruptEnable */
	volatile u32		hid;			/* HcInterruptDisable */

	/* Memory Pointer Partition */
	volatile u32		hhcca;			/* HcHCCA */
	volatile u32 const	hpced;			/* HcPeriodCurrentED */
	volatile u32		hched;			/* HcControlHeadED */
	volatile u32		hcced;			/* HcControlCurrentED */
	volatile u32		hbhed;			/* HcBulkHeadED */
	volatile u32		hbced;			/* HcBulkCurrentED */
	volatile u32 const	hdh;			/* HcDoneHead */

	/* Frame Counter Partition */
	volatile u32		hfi;			/* HcFmInterval */
	volatile u32 const	hfr;			/* HcFmRemaining */
	volatile u32 const	hfn;			/* HcFmNumber */
	volatile u32		hps;			/* HcPeriodicStart */
	volatile u32		hlst;			/* HcLSThreshold */

	/* Root Hub Partition */
	volatile u32		hrda;			/* HcRhDescriptorA */
	volatile u32		hrdb;			/* HcRhDescriptorB */
	volatile u32		hrs;			/* HcRhStatus */
	volatile u32		hrps[15];		/* HcRhPortStatus[15] */
}ohci_reg_t;


/* The Control and Status Partition */
#define HcRevision				(0x00)
#define HcControl				(0x04)
#define HcCommandStatus			(0x08)
#define HcInterruptStatus		(0x0C)
#define HcInterruptEnable		(0x10)
#define HcInterruptDisable		(0x14)

/* Memory Pointer Partition */
#define HcHCCA					(0x18)		/* Host Controller Communication Area */
#define HcPeriodCurrentED		(0x1C)
#define HcControlHeadED			(0x20)
#define HcControlCurrentED		(0x24)
#define HcBulkHeadED			(0x28)
#define HcBulkCurrentED			(0x2C)
#define HcDoneHead				(0x30)

/* Frame Counter Partition */
#define HcFmInterval			(0x34)
#define HcFmRemaining			(0x38)
#define HcFmNumber				(0x3C)
#define HcPeriodicStart			(0x40)
#define HcLSThreshold			(0x44)

/* Root Hub Partition */
#define HcRhDescriptorA			(0x48)
#define HcRhDescriptorB			(0x4C)
#define HcRhStatus				(0x50)
#define HcRhPortStatus			(0x54)



/*
 * 7.1.2 HcControl Register
 */
#define OHCI_CONTROL_CBSR	(3 << 0)	/* ControlBulkServiceRatio */
	#define OHCI_CBSR_11		(0 << 0)	/* 1 : 1*/
	#define OHCI_CBSR_21		(1 << 0)	/* 2 : 1*/
	#define OHCI_CBSR_31		(2 << 0)	/* 3 : 1*/
	#define OHCI_CBSR_41		(3 << 0)	/* 4 : 1*/
#define OHCI_CONTROL_PLE	(1 << 2)	/* PeriodicListEnable */
#define OHCI_CONTROL_IE		(1 << 3)	/* IsochronousEnable */
#define OHCI_CONTROL_CLE	(1 << 4)	/* ControlListEnable */
#define OHCI_CONTROL_BLE	(1 << 5)	/* BulkListEnable */
#define OHCI_CONTROL_HCFS	(3 << 6)	/* HostControllerFunctionalState */
	#define OHCI_HCFS_RESET			(0 << 6)
	#define OHCI_HCFS_RESUME		(1 << 6)
	#define OHCI_HCFS_OPERATIONAL	(2 << 6)
	#define OHCI_HCFS_SUSPEND		(3 << 6)
#define OHCI_CONTROL_IR		(1 << 8)	/* InterruptRouting */
#define OHCI_CONTROL_RWC	(1 << 9)	/* RemoteWakeupConnected */
#define OHCI_CONTROL_RWE	(1 << 10)	/* RemoteWakeupEnable */

/*
 * 7.1.3 HcCommandStatus Register
 */
#define OHCI_CMDSTS_HCR		(1 << 0)	/* HostControllerReset */
#define OHCI_CMDSTS_CLF		(1 << 1)	/* ControlListFilled */
#define OHCI_CMDSTS_BLF		(1 << 2)	/* BulkListFilled */
#define OHCI_CMDSTS_OCR		(1 << 3)	/* OwnershipChangeRequest */
#define OHCI_CMDSTS_SOC		(3 << 16)	/* SchedulingOverrunCount */

/*
 * 7.1.4, 7.1.5, 7.1.6 HcInterrupt[Status,Enable,Disable] Register
 */
#define OHCI_INT_SO			(1 << 0)	/* SchedulingOverrun */
#define OHCI_INT_WDH		(1 << 1)	/* WritebackDoneHead */
#define OHCI_INT_SF			(1 << 2)	/* StartFrame */
#define OHCI_INT_RD			(1 << 3)	/* ResumeDetected */
#define OHCI_INT_UE			(1 << 4)	/* UnrecoverableError */
#define OHCI_INT_FNO		(1 << 5)	/* FrameNumberOverflow */
#define OHCI_INT_RHSC		(1 << 6)	/* RootHubStatusChange */
#define OHCI_INT_OC			(1 << 30)	/* OwnershipChange */
#define OHCI_INT_MIE		(1 << 31)	/* MasterInterruptEnable */

#define OHCI_INT_ALL		(OHCI_INT_SO | OHCI_INT_WDH | OHCI_INT_SF | OHCI_INT_RD | OHCI_INT_UE | \
							OHCI_INT_FNO | OHCI_INT_RHSC | OHCI_INT_OC | OHCI_INT_MIE)


/*
 * 7.3.1 HcFmInterval Register
 */
#define OHCI_FI_FI			(0x3FFF << 0)	/* FrameInterval */
#define OHCI_FI_FSMPS		(0x7FFF << 16)	/* FSLargestDataPacket */
#define OHCI_FI_FIT			(1 << 31)		/* FrameIntervalToggle */


/*
 * 7.4.1 HcRhDescriptorA Register
 */
#define OHCI_HRDA_NDP		(0xFF << 0)		/* NumberDownstreamPorts */
#define OHCI_HRDA_PSM		(1 << 8)		/* PowerSwitchingMode */
#define OHCI_HRDA_NPS		(1 << 9)		/* NoPowerSwitching */
#define OHCI_HRDA_DT		(1 << 10)		/* DeviceType */
#define OHCI_HRDA_OCPM		(1 << 11)		/* OverCurrentProtectionMode */
#define OHCI_HRDA_NOCP		(1 << 12)		/* NoOverCurrentProtection */
#define OHCI_HRDA_POTPGT	(0xFF << 24)	/* PowerOnToPowerGoodTime */

#define SET_OHCI_HRDA_POTPGT(v)		(((v) << 24)&OHCI_HRDA_POTPGT)
#define GET_OHCI_HRDA_POTPGT(v)		(((v)&OHCI_HRDA_POTPGT) >> 24)

/*
 * 7.4.2 HcRhDescriptorB Register
 */
#define OHCI_HRDB_DR		(0xFFFF << 0)	/* DeviceRemovable */
#define OHCI_HRDB_PPCM		(0xFFFF << 16)	/* PortPowerControlMask */

/*
 * 7.4.3 HcRhStatus Register
 */
#define OHCI_HRS_LPS		(1 << 0)		/* LocalPowerStatus */
#define OHCI_HRS_OCI		(1 << 1)		/* OverCurrentIndicator */
#define OHCI_HRS_DRWE		(1 << 15)		/* DeviceRemoteWakeupEnable */
#define OHCI_HRS_LPSC		(1 << 16)		/* LocalPowerStatusChange */
#define OHCI_HRS_OCIC		(1 << 17)		/* OverCurrentIndicatorChange */
#define OHCI_HRS_CRWE		(1 << 31)		/* ClearRemoteWakeupEnable */

/*
 * 7.4.4 HcRhPortStatus Register
 */
#define OHCI_HRPS_CCS		(1 << 0)		/* R:CurrentConnectStatus, W:ClearPortEnable */
#define OHCI_HRPS_PES		(1 << 1)		/* R:PortEnableStatus, W:SetPortEnable */
#define OHCI_HRPS_PSS		(1 << 2)		/* R:PortSuspendStatus, W:SetPortSuspend */
#define OHCI_HRPS_POCI		(1 << 3)		/* R:PortOverCurrentIndicator, W:ClearSuspendStatus */
#define OHCI_HRPS_PRS		(1 << 4)		/* R:PortResetStatus, W:SetPortReset */

#define OHCI_HRPS_PPS		(1 << 8)		/* R:PortPowerStatus, W:SetportPower */
#define OHCI_HRPS_LSDA		(1 << 9)		/* R:LowSpeedDeviceAttached, W:ClearPortPower */

#define OHCI_HRPS_CSC		(1 << 16)		/* CurrentConnectStatusChange */
#define OHCI_HRPS_PESC		(1 << 17)		/* PortEnableStatusChange */
#define OHCI_HRPS_PSSC		(1 << 18)		/* PortSuspendStatusChange */
#define OHCI_HRPS_OCIC		(1 << 19)		/* PortOverCurrentIndicatorChange */
#define OHCI_HRPS_PRSC		(1 << 20)		/* PortResetStatusChange */


#define OHCI_HRPS_CPE		(1 << 0)		/* W:ClearPortEnable */
#define OHCI_HRPS_SPE		(1 << 1)		/* W:SetPortEnable */

#define OHCI_HRPS_SPS		(1 << 2)		/* W:SetPortSuspend */
#define OHCI_HRPS_CSS		(1 << 3)		/* W:ClearSuspendStatus */

#define OHCI_HRPS_SPR		(1 << 4)		/* W:SetPortReset */

#define OHCI_HRPS_SPP		(1 << 8)		/* W:SetPortPower */
#define OHCI_HRPS_CPP		(1 << 9)		/* W:ClearPortPower */


#endif
