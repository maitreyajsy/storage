/****************************************************************************************
 *   SIC R&D Lab., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011-2013 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifndef _XHCI_H_
#define _XHCI_H_

/*
 * eXtensible Host Controller Interface for Universal Serial Bus(xHCI)
 * Revision 1.0
 */

/* 5.3 Host Controller Capability Registers */
typedef u32 xhci_cap_reg_t;

#define XHCI_HCCAPBASE			0x00
#define XHCI_CAPLENGTH(v)			(((v) >>  0) & 0xFF)	/* Capability Register Length */
#define XHCI_HCIVERSION(v)			(((v) >> 16) & 0xFFFF)	/* Interface Version Number */
#define XHCI_HCIVERSION_MAJOR(v)	(((v) >> 24) & 0xFF)	/* Interface Version Number Major */
#define XHCI_HCIVERSION_MINOR(v)	(((v) >> 16) & 0xFF)	/* Interface Version Number Minor */

#define XHCI_HCSPARAMS1			0x04	/* Structural Parameters 1 */
#define XHCI_HCS1_MAX_SLOTS(v)		(((v) >>  0) & 0xFF)	/* Number of Device Slots */
#define XHCI_HCS1_MAX_INTRS(v)		(((v) >>  8) & 0x3FF)	/* Number of Interrupters */
#define XHCI_HCS1_MAX_PORTS(v)		(((v) >> 24) & 0xFF)	/* Number of Ports */

#define XHCI_HCSPARAMS2			0x08	/* Structural Parameters 2 */
#define XHCI_HCS2_IST(v)			(((v) >>  0) & 0x0F)	/* Isochronous Scheduling Threshold */
#define XHCI_HCS2_ERST_MAX(v)		(((v) >>  4) & 0x0F)	/* Event Ring Segment Table Max (ERST Max) */
#define XHCI_HCS2_SPR(v)			(((v) >> 26) & 0x01)	/* Scratchpad Restore (SPR) */
#define XHCI_HCS2_MSB(v)			(((v) >> 27) & 0x1F)	/* Max Scratchpad Buffers */

#define XHCI_HCSPARAMS3			0x0C	/* Structural Parameters 3 */
#define XHCI_HCS3_U1_DEL(v)			(((v) >>  0) & 0xFF)	/* U1 Device Exit Latency */
#define XHCI_HCS3_U2_DEL(v)			(((v) >> 16) & 0xFFFF)	/* U2 Device Exit Latency */


#define XHCI_HCCPARAMS			0x10	/* Capability Parameters */
#define XHCI_HCC_AC64(v)			(((v) >>  0) & 0x01)	/* 64-bit Addressing Capability */
#define XHCI_HCC_BNC(v)				(((v) >>  1) & 0x01)	/* BW Negotiation Capability */
#define XHCI_HCC_CSZ(v)				(((v) >>  2) & 0x01)	/* Context Size */
#define XHCI_HCC_PPC(v)				(((v) >>  3) & 0x01)	/* Port Power Control */
#define XHCI_HCC_PIND(v)			(((v) >>  4) & 0x01)	/* Port indicators */
#define XHCI_HCC_LHRC(v)			(((v) >>  5) & 0x01)	/* Light HC Reset Capability */
#define XHCI_HCC_LTC(v)				(((v) >>  6) & 0x01)	/* Latency Tolerance Messaging Capability */
#define XHCI_HCC_NSS(v)				(((v) >>  7) & 0x01)	/* No Secondary SID Support */
#define XHCI_HCC_MAX_PSA_SIZE(v)	(((v) >> 12) & 0x0F)	/* Maximum Primary Stream Array Size */
#define XHCI_HCC_XECP(v)			(((v) >> 16) & 0xFFFF)	/* xHCI Extended Capabilities Pointer */


#define XHCI_DBOFF				0x14	/* Doorbell Offset */
#define XHCI_DBOFF_GET(v)		((v) & 0xFFFFFFFC)		/* 31:2 */

#define XHCI_RTSOFF				0x18	/* Runtime Register Space Offset */
#define XHCI_RTSOFF_GET(v)		((v) & 0xFFFFFFE0)		/* 31:5 */




/* 5.4 Host Controller Operational Registers */
typedef u32 xhci_op_reg_t;


#define XHCI_USBCMD			0x00	/* USB Command */
#define XHCI_USBCMD_RUN			(0x01 << 0)		/* Run/Stop */
#define XHCI_USBCMD_HCRST		(0x01 << 1)		/* Host Controller Reset */
#define XHCI_USBCMD_INTE		(0x01 << 2)		/* Interrupter Enable */
#define XHCI_USBCMD_HSEE		(0x01 << 3)		/* Host System Error Enable */
#define XHCI_USBCMD_LHCRST		(0x01 << 7)		/* Light Host Controller Reset */
#define XHCI_USBCMD_CSS			(0x01 << 8)		/* Controller Save State */
#define XHCI_USBCMD_CRS			(0x01 << 9)		/* Controller Restore State */
#define XHCI_USBCMD_EWE			(0x01 << 10)	/* Enable Wrap Event */
#define XHCI_USBCMD_EU3S		(0x01 << 11)	/* Enable U3 MFINDEX Stop */


#define XHCI_USBSTS			0x04	/* USB Status */
#define XHCI_USBSTS_HCH			(0x01 <<  0)	/* HCHalted */
#define XHCI_USBSTS_HSE			(0x01 <<  2)	/* Host System Error */
#define XHCI_USBSTS_EINT		(0x01 <<  3)	/* Event Interrupt */
#define XHCI_USBSTS_PCD			(0x01 <<  4)	/* Port Change Detect */
#define XHCI_USBSTS_SSS			(0x01 <<  8)	/* Save State Status */
#define XHCI_USBSTS_RSS			(0x01 <<  9)	/* Restore State Status */
#define XHCI_USBSTS_SRE			(0x01 << 10)	/* Save/Restore Error */
#define XHCI_USBSTS_CNR			(0x01 << 11)	/* Controller Not Ready */
#define XHCI_USBSTS_HCE			(0x01 << 12)	/* Host Controller Error */


#define XHCI_PAGESIZE		0x08	/* Page Size Register */

#define XHCI_DNCTRL			0x14	/* Device Notification Control Register */

#define XHCI_CRCR			0x18	/* Command Ring Control Register */
#define XHCI_CRCR_RCS			(0x01 <<  0)	/* Ring Cycle State */
#define XHCI_CRCR_CS			(0x01 <<  1)	/* Command Stop */
#define XHCI_CRCR_CA			(0x01 <<  2)	/* Command Abort */
#define XHCI_CRCR_CRR			(0x01 <<  3)	/* Command Ring Running */

#define XHCI_DCBAAP			0x30	/* Device Context Base Address Array Pointer Register */

#define XHCI_CONFIG			0x38	/* Configure Register */

#define XHCI_PORTSC(n)		(0x400 + (0x10*((n)-1)))	/* Port Status and Control Register */
#define XHCI_PORTSC_CCS			(0x01 <<  0)		/* Current Connect Status. 1 : present */
#define XHCI_PORTSC_PED			(0x01 <<  1)		/* Port Enabled/Disabled */
#define XHCI_PORTSC_OCA			(0x01 <<  3)		/* Over-current Active */
#define XHCI_PORTSC_PR			(0x01 <<  4)		/* Port Reset */
#define XHCI_PORTSC_PLS_MASK	(0x0F <<  5)		/* Port Link State */
#define XHCI_PORTSC_PLS(v)		(((v) >> 5) & 0xF)
#define XHCI_PORTSC_PLS_U0			0
#define XHCI_PORTSC_PLS_U3			3		/* U3 State (Device Suspended) */
#define XHCI_PORTSC_PLS_DISABLED	4
#define XHCI_PORTSC_PLS_RECOVERY	8
#define XHCI_PORTSC_PLS_HOTRESET	9

#define XHCI_PORTSC_PP			(0x01 <<  9)		/* Port Power */
#define XHCI_PORTSC_PS_MASK		(0x0F << 10)		/* Port Speed */
#define XHCI_PORTSC_PS(v)		(((v) >> 10) & 0xF)
#define XHCI_PORTSC_PIC_MASK	(0x03 << 14)		/* Port Indicator Control */
#define XHCI_PORTSC_PIC(v)		(((v) >> 14) & 0x3)
#define XHCI_PORTSC_LWS			(0x01 << 16)		/* Port Link State Write Strobe */
#define XHCI_PORTSC_CSC			(0x01 << 17)		/* Connect Status Change */
#define XHCI_PORTSC_PEC			(0x01 << 18)		/* Port Enable/Disable Change */
#define XHCI_PORTSC_WRC			(0x01 << 19)		/* Warm Port Reset Change */
#define XHCI_PORTSC_OCC			(0x01 << 20)		/* Over-current Change */
#define XHCI_PORTSC_PRC			(0x01 << 21)		/* Port Reset Change */
#define XHCI_PORTSC_PLC			(0x01 << 22)		/* Port Link State Change */
#define XHCI_PORTSC_CEC			(0x01 << 23)		/* Port Config Error Change */
#define XHCI_PORTSC_CAS			(0x01 << 24)		/* Cold Attach Status */
#define XHCI_PORTSC_WCE			(0x01 << 25)		/* Wake on Connect Enable */
#define XHCI_PORTSC_WDE			(0x01 << 26)		/* Wake on Disconnect Enable */
#define XHCI_PORTSC_WOE			(0x01 << 27)		/* Wake on Over-current Enable */
#define XHCI_PORTSC_DR			(0x01 << 30)		/* Device Removable */
#define XHCI_PORTSC_WPR			(0x01 << 31)		/* Warm Port Reset */

#define XHCI_PORTSC_CLEAR		(XHCI_PORTSC_CCS | XHCI_PORTSC_OCA | XHCI_PORTSC_PLS_MASK | \
								 XHCI_PORTSC_PP | XHCI_PORTSC_PS_MASK | XHCI_PORTSC_PIC_MASK | \
								 XHCI_PORTSC_CAS | XHCI_PORTSC_WCE | XHCI_PORTSC_WDE | \
								 XHCI_PORTSC_WOE | XHCI_PORTSC_DR)

#define XHCI_PORTPMSC(n)		(0x404 + (0x10*((n)-1)))	/* Port PM Status and Control Register */
#define XHCI_PORTPMSC_U1TO		(0xFF <<  0)		/* U1 Timeout */
#define XHCI_PORTPMSC_U2TO		(0xFF <<  8)		/* U2 Timeout */
#define XHCI_PORTPMSC_FLA		(0x01 << 16)		/* Force Link PM Accept */

/* 5.5 Host Controller Runtime Registers */
typedef u32 xhci_rt_reg_t;

/* 5.5.2.1 Interrupter Management Register */
#define XHCI_IMAN(n)		(0x20 + (32*(n)))
#define XHCI_IMAN_IP			(0x01 << 0)		/* Interrupt Pending */
#define XHCI_IMAN_IE			(0x01 << 1)		/* Interrupt Enable */

/* 5.5.2.2 Interrupter Moderation Register */
#define XHCI_IMOD(n)		(0x24 + (32*(n)))
#define XHCI_IMOD_IMODI(v)		(((v) >> 0) & 0xFFFF)
#define XHCI_IMOD_SET_IMODI(v)	(((v)&0xFFFF) << 0)
#define XHCI_IMOD_IMODC(v)		(((v) >> 16) & 0xFFFF)



/* 5.5.2.3 Event Ring Registers */
#define XHCI_ERSTSZ(n)		(0x28 + (32*(n)))	/* Event Ring Segment Table Size Register */
#define XHCI_ERSTBA(n)		(0x30 + (32*(n)))	/* Event Ring Segment Table Base Address Register */
#define XHCI_ERDP(n)		(0x38 + (32*(n)))	/* Event Ring Dequeue Pointer Register */
#define XHCI_ERDP_DESI_MASK		(0x07 <<  0)		/* Dequeue ERST Segment Index */
#define XHCI_ERDP_SET_DESI(v)	(((v) & 0x07) << 0)
#define XHCI_ERDP_EHB			(0x01 <<  3)		/* Event Handler Busy */
#define XHCI_ERDP_ERDQ_MASK		(0xFFFFFFF0 <<  4)	/* Event Ring Dequeue Pointer */



/* 5.6 Doorbell Registers */
typedef u32 xhci_db_reg_t;

#define XHCI_DB_HOST_CONTROLLER		0

#define XHCI_DB_TARGET_COMMAND		0

#define XHCI_DB_SET_TARGET(v)		((v) & 0xFF)
#define XHCI_DB_SET_STREAM_ID(v)	((v) << 16)

/* 6 Data Structures */

/* Table 49. Data Structure Max Size, Boudnary and Alignment */

#define XHCI_DEVICE_CONTEXT_MAX_SIZE		2048



/* 6.1 Device Context Base Address Array */
typedef struct xhci_dcba	xhci_dcba_t;
struct xhci_dcba
{
	volatile u64	dcba;		/* Device Context Base Address. This is aligned on a 64 byte boundary */
};

typedef struct xhci_sbba	xhci_sbba_t;
struct xhci_sbba
{
	volatile u64	sbba;		/* Scratchpad Buffer Base Address */
};


#define XHCI_NUM_ERST				1	/* Number of Event Ring Segment Table */

#define XHCI_MAX_EVENT_TRBS			64	//128
#define XHCI_MAX_COMMAND_TRBS		32

#define XHCI_MAX_TRANSFER_TRBS		128


/* 6.2.2 Slot Context */
typedef struct xhci_slot_ctx xhci_slot_ctx_t;
struct xhci_slot_ctx
{
	volatile u32	slot_ctx0;
	volatile u32	slot_ctx1;
	volatile u32	slot_ctx2;
	volatile u32	slot_ctx3;
	volatile u32	rsvd[4];
} __attribute__((packed));


#define XHCI_SLOT_CTX0_ROUTE_STRING(v)		((v) & 0xFFFFF)
#define XHCI_SLOT_CTX0_SPEED(v)				(((v) >> 20) & 0xF)
#define XHCI_SLOT_CTX0_SET_SPEED(v)			(((v) & 0xF) << 20)
#define XHCI_SLOT_CTX0_MTT					(0x1 << 25)
#define XHCI_SLOT_CTX0_HUB					(0x1 << 26)
#define XHCI_SLOT_CTX0_ENTRIES_MASK			(0x1F << 27)
#define XHCI_SLOT_CTX0_ENTRIES(v)			(((v) >> 27) & 0x1F)
#define XHCI_SLOT_CTX0_SET_ENTRIES(v)		(((v) & 0x1F) << 27)

#define XHCI_SLOT_CTX1_MAX_EXIT_LATENCY(v)	((v) & 0xFFFF)
#define XHCI_SLOT_CTX1_ROOT_HUB_PORT(v)		(((v) >> 16) & 0xFF)
#define XHCI_SLOT_CTX1_SET_ROOT_HUB_PORT(v)	(((v) & 0xFF) << 16)
#define XHCI_SLOT_CTX1_NUM_OF_PORTS(v)		(((v) >> 24) & 0xFF)
#define XHCI_SLOT_CTX1_SET_NUM_OF_PORTS(v)	(((v) & 0xFF) << 24)

#define XHCI_SLOT_CTX2_SET_TT_HUB_SLOT(v)	(((v) & 0xFF) << 0)
#define XHCI_SLOT_CTX2_SET_TT_PORT_NUM(v)	(((v) & 0xFF) << 8)
#define XHCI_SLOT_CTX2_SET_TT_THINK_TIME(v)	(((v) & 0x03) << 16)


#define XHCI_SLOT_CTX3_DEV_ADDRESS(v)		(((v) >>  0) & 0xFF)
#define XHCI_SLOT_CTX3_SLOT_STATE(v)		(((v) >> 27) & 0x1F)
#define XHCI_SLOT_STATE_DISABLED	0
#define XHCI_SLOT_STATE_DEFAULT		1
#define XHCI_SLOT_STATE_ADDRESSED	2
#define XHCI_SLOT_STATE_CONFIGURED	3


/* 6.2.3 Endpoint Context */
typedef struct xhci_ep_ctx xhci_ep_ctx_t;
struct xhci_ep_ctx
{
	volatile u32	ep_ctx0;
	volatile u32	ep_ctx1;
	union {
		struct { volatile u32 ep_ctx2_lo, ep_ctx2_hi; };
		volatile u64	ep_ctx2;
	};
	volatile u32	ep_ctx4;
	volatile u32	rsvd[3];
} __attribute__((packed));

#define XHCI_EP_CTX0_EP_STATE(v)				((v) & 0x07)
#define XHCI_EP_CTX0_EP_STATE_DIABLED	0
#define XHCI_EP_CTX0_EP_STATE_RUNNING	1
#define XHCI_EP_CTX0_EP_STATE_HALTED	2
#define XHCI_EP_CTX0_EP_STATE_STOPPED	3
#define XHCI_EP_CTX0_EP_STATE_ERROR		4
#define XHCI_EP_CTX0_MULT(v)					(((v) >> 8) & 0x03)
#define XHCI_EP_CTX0_SET_MULT(v)				(((v) & 0x03) << 8)
#define XHCI_EP_CTX0_MAX_PSTREAMS(v)			(((v) >> 10) & 0x1F)
#define XHCI_EP_CTX0_SET_MAX_PSTREAMS(v)		(((v) & 0x1F) << 10)
#define XHCI_EP_CTX0_LSA(v)						(((v) >> 15) & 0x01)
#define XHCI_EP_CTX0_INTERVAL(v)				(((v) >> 16) & 0xFF)

#define XHCI_EP_CTX1_CERR(v)					(((v) >> 1) & 0x03)
#define XHCI_EP_CTX1_SET_CERR(v)				(((v) & 0x03) << 1)
#define XHCI_EP_CTX1_EP_TYPE(v)					(((v) >> 3) & 0x07)
#define XHCI_EP_CTX1_SET_EP_TYPE(v)				(((v) & 0x07) << 3)
#define XHCI_EP_CTX1_EP_TYPE_IN				(0x4 << 3)
#define XHCI_EP_CTX1_EP_TYPE_OUT			(0x0 << 3)
#define XHCI_EP_CTX1_EP_TYPE_ISOCH			(0x1 << 3)
#define XHCI_EP_CTX1_EP_TYPE_BULK			(0x2 << 3)
#define XHCI_EP_CTX1_EP_TYPE_INTR			(0x3 << 3)
#define XHCI_EP_CTX1_EP_TYPE_CONTROL		XHCI_EP_CTX1_SET_EP_TYPE(4)


#define XHCI_EP_CTX1_HID(v)						(((v) >> 7) & 0x01)	/* Host Initiate Disable */
#define XHCI_EP_CTX1_MBS(v)						(((v) >> 8) & 0xFF)	/* Max Burst Size */
#define XHCI_EP_CTX1_SET_MBS(v)					(((v) & 0xFF) << 8)
#define XHCI_EP_CTX1_MPS(v)						(((v) >> 16) & 0xFFFF)	/* Max Packet Size */
#define XHCI_EP_CTX1_SET_MPS(v)					(((v) & 0xFFFF) << 16)

#define XHCI_EP_CTX2_DCS						0x01	/* Dequeue Cycle State */

#define XHCI_EP_CTX4_AVERAGE_TRB_LEN(v)			((v) & 0xFFFF)
#define XHCI_EP_CTX4_MAX_ESTI_PAYLOAD(v)		(((v) >> 16) & 0xFFFF)
#define XHCI_EP_CTX4_SET_MAX_ESTI_PAYLOAD(v)	(((v) & 0xFFFF) << 16)




/* 6.2.1 Device Context */
typedef struct xhci_device_ctx xhci_device_ctx_t;
struct xhci_device_ctx
{
	xhci_slot_ctx_t		*slot;
	xhci_ep_ctx_t		*ep[31];
	u8					*ptr;		/* Allocated Memory */
};


/* 6.2.5 Input Context */
typedef struct xhci_input_ctrl_ctx xhci_input_ctrl_ctx_t;
struct xhci_input_ctrl_ctx
{
	volatile u32	drop_ctx_flags;
	volatile u32	add_ctx_flags;
	volatile u32	rsvd[6];
} __attribute__((packed));


typedef struct xhci_input_ctx xhci_input_ctx_t;
struct xhci_input_ctx
{
	xhci_input_ctrl_ctx_t	*ctrl;
	xhci_slot_ctx_t			*slot;
	xhci_ep_ctx_t			*ep[31];
	u8						*ptr;		/* Allocated Memory */
};



/* 64. Transfer Request Block (TRB) */
typedef struct xhci_trb		xhci_trb_t;
struct xhci_trb
{
	union {
		struct { volatile u32 trb0_lo, trb0_hi; };
		volatile u64	trb0;
	};
	volatile u32	trb2;
	volatile u32	trb3;
} __attribute__((packed));


#define XHCI_TRB3_TYPE(v)			(((v) >> 10) & 0x3F)
#define XHCI_TRB3_SET_TYPE(v)		(((v) & 0x3F) << 10)
#define XHCI_TRB3_C					(0x01 <<  0)	/* Cycle bit */


#define XHCI_TRB3_DIR			(0x01 << 16)
#define XHCI_TRB3_DIR_OUT		(0x00 << 16)
#define XHCI_TRB3_DIR_IN		(0x01 << 16)




/* 6.4.1 Transfer TRBs */
/* 6.4.1.1 Normal TRB */

#define XHCI_TRB2_TRANSFER_LEN(v)		((v) & 0x1FFFF)
#define XHCI_TRB2_SET_TRANSFER_LEN(v)	((v) & 0x1FFFF)
#define XHCI_TRB2_TD_SIZE(v)			(((v) >> 17) & 0x1FF)
#define XHCI_TRB2_SET_TD_SIZE(v)		(((v) & 0x1FF) << 17)
#define XHCI_TRB2_INTERRUPT_TARGET(v)		(((v) >> 22) & 0x3FF)
#define XHCI_TRB2_SET_INTERRUPT_TARGET(v)	(((v) & 0x3FF) << 22)

#define XHCI_TRB3_ENT		(0x01 << 1)	/* Evaluate Next TRB */
#define XHCI_TRB3_ISP		(0x01 << 2)	/* Interrupt-on Short Packet */
#define XHCI_TRB3_NS		(0x01 << 3)	/* No Snoop */
#define XHCI_TRB3_CH		(0x01 << 4) /* Chain bit */
#define XHCI_TRB3_IOC		(0x01 << 5)	/* Interrupt On Completion */
#define XHCI_TRB3_IDT		(0x01 << 6)	/* Immediate Data */
#define XHCI_TRB3_BEI		(0x01 << 9)	/* Block Event Interrupt */


#define XHCI_TRB_MAX_TX_BUF_SIZE	(64*1024)	/* 64KB */
#define XHCI_TRB_BOUNDARY			(64*1024)


/* 6.4.1.2 Control TRBs */

/* 6.4.1.2.1 Setup Stage TRB */
#define XHCI_SETUP_TRB0_REQUEST_TYPE(v)			((v) & 0xFF)
#define XHCI_SETUP_TRB0_SET_REQUEST_TYPE(v)		((v) & 0xFF)
#define XHCI_SETUP_TRB0_REQUEST(v)				(((v) >> 8) & 0xFF)
#define XHCI_SETUP_TRB0_SET_REQUEST(v)			(((v) & 0xFF) << 8)
#define XHCI_SETUP_TRB0_VALUE(v)				(((v) >> 16) & 0xFFFF)
#define XHCI_SETUP_TRB0_SET_VALUE(v)			(((v) & 0xFFFF) << 16)

#define XHCI_SETUP_TRB1_INDEX(v)				((v) & 0xFFFF)
#define XHCI_SETUP_TRB1_SET_INDEX(v)			((v) & 0xFFFF)
#define XHCI_SETUP_TRB1_LENGTH(v)				(((v) >> 16) & 0xFFFF)
#define XHCI_SETUP_TRB1_SET_LENGTH(v)			(((v) & 0xFFFF) << 16)

#define XHCI_SETUP_TRB3_TRT(v)					(((v) >> 16) & 0x03)
#define XHCI_SETUP_TRB3_SET_TRT(v)				(((v) & 0x03) << 16)
#define XHCI_SETUP_TRT_NO_DATA		0
#define XHCI_SETUP_TRT_OUT_DATA		2
#define XHCI_SETUP_TRT_IN_DATA		3




/* 6.4.2 Event TRBs */
#define XHCI_TRB3_SLOT_ID(v)		(((v) >> 24) & 0xFF)
#define XHCI_TRB3_SET_SLOT_ID(v)	(((v) & 0xFF) << 24)


/* 6.4.2.1 Transfer Event TRB */
#define XHCI_TRB3_ED				(0x01 << 2)		/* Event Data */
#define XHCI_TRB3_EP_ID(v)			(((v) >> 16) & 0x1F)
#define XHCI_TRB3_SET_EP_ID(v)		(((v) & 0x1F) << 16)



/* 6.4.2.2 Command Completion Event TRB */
#define XHCI_TRB2_COMPLETION_CODE(v)	(((v) >> 24) & 0xFF)
#define XHCI_TRB3_VF_ID(v)				(((v) >> 16) & 0xFF)

/* 6.4.2.3 Port Status Change Event TRB */
#define XHCI_TRB0_PORT_ID(v)			(((v) >> 24) & 0xFF)

/* 6.4.3 Command TRBs */

/* 6.4.3.4 Address Device Command TRB */
#define XHCI_TRB3_BSR				(0x01 << 9)		/* Block Set Address Request */

/* 6.4.4.1 Link TRB */
#define XHCI_LINK_TRB3_TC			(0x01 <<  1)	/* Toggle Cycle */

/* 6.4.5 TRB Completion Codes */
#define XHCI_TRB_CODE_INVALID				0
#define XHCI_TRB_CODE_SUCCESS				1
#define XHCI_TRB_CODE_DATA_BUFFER_ERROR		2
#define XHCI_TRB_CODE_BABBLE_DETECTED_ERROR	3
#define XHCI_TRB_CODE_USB_TRANSACTION_ERROR	4
#define XHCI_TRB_CODE_TRB_ERROR				5
#define XHCI_TRB_CODE_STALL_ERROR			6
#define XHCI_TRB_CODE_RESOURCE_ERROR		7
#define XHCI_TRB_CODE_BANDWIDTH_ERROR		8
#define XHCI_TRB_CODE_NO_SLOTS_AVAILABLE	9
#define XHCI_TRB_CODE_INVALID_STREAM_TYPE	10
#define XHCI_TRB_CODE_SLOT_NOT_ENABLED		11
#define XHCI_TRB_CODE_ENDPOINT_NOT_ENABLED	12
#define XHCI_TRB_CODE_SHORT_PACKET			13
#define XHCI_TRB_CODE_RING_UNDERRUN			14
#define XHCI_TRB_CODE_RING_OVERRUN			15
#define XHCI_TRB_CODE_VF_EVENT_RING_FULL	16
#define XHCI_TRB_CODE_PARAMETER_ERROR		17
#define XHCI_TRB_CODE_BANDWIDTH_OVERRUN		18
#define XHCI_TRB_CODE_CONTEXT_STATE_ERROR	19
#define XHCI_TRB_CODE_NO_PING_RESPONSE		20
#define XHCI_TRB_CODE_EVENT_RING_FULL		21
#define XHCI_TRB_CODE_INCOMPATIBLE_DEVICE	22
#define XHCI_TRB_CODE_MISSED_SERVICE		23
#define XHCI_TRB_CODE_COMMAND_RING_STOPPED	24
#define XHCI_TRB_CODE_COMMAND_ABORTED		25
#define XHCI_TRB_CODE_STOPPED				26
#define XHCI_TRB_CODE_LENGTH_INVALID		27
#define XHCI_TRB_CODE_MEL_TOO_LARGE			29
#define XHCI_TRB_CODE_ISOCH_BUFFER_OVERRUN	31
#define XHCI_TRB_CODE_EVENT_LOST_ERROR		32
#define XHCI_TRB_CODE_UNDEFINED_ERROR		33
#define XHCI_TRB_CODE_INVALID_STREAM_ID		34
#define XHCI_TRB_CODE_SECONDARAY_BW_ERROR	35
#define XHCI_TRB_CODE_SPLIT_TRANSACTION		36



/* 6.4.6 TRB Types */
#define XHCI_TRB_TYPE_NORMAL			1
#define XHCI_TRB_TYPE_SETUP				2	/* Setup  Stage */
#define XHCI_TRB_TYPE_DATA				3	/* Data Stage */
#define XHCI_TRB_TYPE_STATUS			4	/* Status Stage */
#define XHCI_TRB_TYPE_ISOCH				5
#define XHCI_TRB_TYPE_LINK				6
#define XHCI_TRB_TYPE_EVENT				7	/* Event Data */
#define XHCI_TRB_TYPE_NOP				8
#define XHCI_TRB_TYPE_ENABLE_SLOT		9	/* Enable Slot Command */
#define XHCI_TRB_TYPE_DISABLE_SLOT		10	/* Disable Slot Command */
#define XHCI_TRB_TYPE_ADDR_DEV			11	/* Address Device Command */
#define XHCI_TRB_TYPE_CFG_EP			12	/* Configure Endpoint Command */
#define XHCI_TRB_TYPE_EVAL_CTX			13	/* Evaluate Context Command */
#define XHCI_TRB_TYPE_RST_EP			14	/* Reset Endpoint Command */
#define XHCI_TRB_TYPE_STOP_EP			15	/* Stop Endpoint Command */
#define	XHCI_TRB_TYPE_SET_TR_DEQUEUE	16
#define	XHCI_TRB_TYPE_RESET_DEVICE		17
#define	XHCI_TRB_TYPE_FORCE_EVENT		18
#define	XHCI_TRB_TYPE_NEGO_BW			19
#define	XHCI_TRB_TYPE_SET_LATENCY_TOL  	20
#define	XHCI_TRB_TYPE_GET_PORT_BW		21
#define	XHCI_TRB_TYPE_FORCE_HEADER		22
#define	XHCI_TRB_TYPE_NOP_CMD			23

#define	XHCI_TRB_TYPE_TRANSFER				32
#define	XHCI_TRB_TYPE_CMD_COMPLETION		33
#define	XHCI_TRB_TYPE_PORT_STATUS_CHANGE	34
#define	XHCI_TRB_TYPE_BW_REQUEST			35
#define	XHCI_TRB_TYPE_DOORBELL				36
#define	XHCI_TRB_TYPE_HOST_CONTROLLER		37
#define	XHCI_TRB_TYPE_DEVICE_NOTIFICATION	38
#define	XHCI_TRB_TYPE_MFINDEX_WRAP			39



/* 6.5 Event Ring Segment Table */
typedef struct xhci_erst	xhci_erst_t;
struct xhci_erst
{
	volatile u64	addr;
	volatile u32	size;
	volatile u32	rsvd;
} __attribute__((packed));


/* 7. xHCI Extended Capabilities */
#define XHCI_EXT_CAP_ID(v)			((v) & 0xFF)
#define XHCI_EXT_NEXT_POINTER(v)	(((v) >> 8) & 0xFF)

#define XHCI_EXT_CAP_ID_SUPPORTED_PROTOCOL		2

/* 7.2 xHCI Supported Protocol Capability */
#define XHCI_EXT_SPC_MAJOR(v)			(((v) >> 24) & 0xFF)
#define XHCI_EXT_SPC_MINOR(v)			(((v) >> 16) & 0xFF)

#define XHCI_EXT_SPC_PORT_OFFSET(v)		(((v) >>  0) & 0xFF)
#define XHCI_EXT_SPC_PORT_COUNT(v)		(((v) >>  8) & 0xFF)
#define XHCI_EXT_SPC_PROTO_DEFINED(v)	(((v) >> 16) & 0xFF)
#define XHCI_EXT_SPC_PSIC(v)			(((v) >> 28) & 0x0F)	/* Protocol Speed ID Count */


/* 7.2.2.1.1 Default USB Speed ID Mapping */
#define XHCI_SPEED_FULL		1
#define XHCI_SPEED_LOW		2
#define XHCI_SPEED_HIGH		3
#define XHCI_SPEED_SUPER	4


#endif
