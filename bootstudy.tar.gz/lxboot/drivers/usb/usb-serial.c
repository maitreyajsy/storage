/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#if (USE_USB_SERIAL_CONSOLE == 1)
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <malloc.h>
#include <usb.h>
#include <serial.h>
#include <console.h>

//#define USE_USB_SERIAL_INFO

#ifdef USE_USB_SERIAL_INFO
#define USB_SERIAL_INFO(fmt, args...)	usb_printf(fmt, ##args)
#else
#define USB_SERIAL_INFO(fmt, args...)	do{}while(0)
#endif

#if 0
#define USB_SERIAL_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define USB_SERIAL_DEBUG(fmt, args...)	do{}while(0)
#endif

#if 1
#define USB_SERIAL_ERROR(fmt, args...)	usb_printf("\x1b[31mUSB-SERIAL:"fmt"\x1b[0m", ##args)
#else
#define USB_SERIAL_ERROR(fmt, args...)	do{}while(0)
#endif


#define USB_CDC_SET_LINE_CODING		0x20
#define USB_CDC_GET_LINE_CODING		0x21

/* USB CDC 6.2.13 GetLineCoding �� ���� */
typedef struct usb_serial_line usb_serial_line_t;
struct usb_serial_line
{
	u32		dwDTERate;
	u8		bCharFormat;
	u8		bParityType;
	u8		bDataBits;
} __attribute__ ((packed));


#define MAX_USB_SERIAL_DEVICE	2

#define IN_MSG_BUF_SIZE			2048
#define OUT_MSG_BUF_SIZE		512
typedef struct
{
	u8			in[IN_MSG_BUF_SIZE];
	int			in_head, in_tail;

	u8			out[OUT_MSG_BUF_SIZE];
	int			out_pos;
} usb_serial_buffer_t;


typedef struct usb_serial
{
	usb_device_t*	dev;
//	usb_pipe_t*		intr_pipe;

	usb_pipe_t* 	in_pipe;
	int				in_mps;
	u8*				in_buf;

	usb_pipe_t* 	out_pipe;
	int 			out_mps;

	usb_serial_buffer_t*	buffer;

	int				input_size;
} usb_serial_t;


static usb_serial_t* usb_serial_dev[MAX_USB_SERIAL_DEVICE];


static int usb_serial_vendor_request(usb_device_t* dev, u16 value, u16 index)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_VENDOR | USB_REQTYPE_REC_DEVICE,
						0x01, value, index, NULL, 0);
}

static int usb_serial_set_baudrate(usb_device_t* dev, u32 baudrate)
{
	usb_serial_line_t data;

	USB_SERIAL_DEBUG("usb_serial_set_baudrate. baudrate=%d\n", baudrate);

	data.dwDTERate = baudrate;
	data.bCharFormat = 0;
	data.bParityType = 0;
	data.bDataBits = 8;

	return usb_device_request(dev, USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_CLASS | USB_REQTYPE_REC_INTERFACE,
					USB_CDC_SET_LINE_CODING, 0, 0, &data, sizeof(usb_serial_line_t));
}

#define next_pos(i,max)		(((i) + (max) + 1) % (max))
static int usb_serial_rx_callback(usb_req_t* req)
{
	if(req->status == USB_REQ_STATUS_DONE)
	{
		int i;
		usb_serial_t *usb_serial = req->pipe->dev->priv;
		usb_serial_buffer_t* buffer = usb_serial->buffer;
		u8* input = (u8*)req->dma_buf;

		//USB_SERIAL_INFO("USB RX[%d]\n", req->xfer_len);
#ifdef USE_USB_CACHED_BUFFER
		if(req->xfer_len > 0)
		{
			int asize = (req->xfer_len + D_CACHE_LINE_SIZE - 1) & ~(D_CACHE_LINE_SIZE-1);
			dcache_inv_range((unsigned long)req->dma_buf, asize);
		}
#endif

		for(i=0; i<req->xfer_len; i++)
		{
			if(next_pos(buffer->in_tail, IN_MSG_BUF_SIZE) == buffer->in_head)
			{
				USB_SERIAL_ERROR("Buffer Overflow !!!. input size[%d]\n", req->xfer_len);
				// If Buffer is full !!!, Overwrite it
				buffer->in_head = next_pos(buffer->in_head, IN_MSG_BUF_SIZE);
			}
			buffer->in[buffer->in_tail] = input[i];
			buffer->in_tail = next_pos(buffer->in_tail, IN_MSG_BUF_SIZE);
		}
		usb_serial->input_size += req->xfer_len;
		usb_free_request(req);

		/* Restart !!! */
		usb_request(usb_serial->in_pipe, NULL, usb_serial->in_mps, usb_serial_rx_callback);
		return 0;
	}

	USB_SERIAL_ERROR("usb_serial_rx_callback. error !!!\n");
	usb_free_request(req);

	return -1;
}

int usb_serial_attach(usb_device_t* dev)
{
	int i;
	usb_endpoint_desc_t	*ep_desc;
	usb_serial_t *usb_serial = NULL;
	usb_serial_buffer_t *buffer = NULL;
	int idx = -1;

	for(i=0; i<MAX_USB_SERIAL_DEVICE; i++)
	{
		if(usb_serial_dev[i] == NULL)
		{
			idx = i;
			break;
		}
	}

	if(idx == -1)
	{
		USB_SERIAL_ERROR("Exceeded the maximum number of devices\n");
		return -1;
	}


	usb_serial = (usb_serial_t*)calloc(sizeof(usb_serial_t), 1);

	USB_SERIAL_DEBUG("usb_serial_attatch !!!\n");
	for(i=0; i<dev->num_ep_desc; i++)
	{
		ep_desc = dev->ep_desc[i];

		if(IS_USB_EP_INTERRUPT(ep_desc->bmAttributes))
		{
		#if 0
			if(usb_serial->intr_pipe == NULL)
			{
				usb_serial->intr_pipe = usb_open_pipe(dev, ep_desc);
			}
		#endif
			USB_SERIAL_DEBUG("INTERRUPT EP\n");
	    }
		else if(IS_USB_EP_IN(ep_desc->bEndpointAddress))
		{
			if(usb_serial->in_pipe == NULL)
			{
				usb_serial->in_pipe = usb_open_pipe(dev, ep_desc);
				usb_serial->in_mps = UTOHS(ep_desc->wMaxPacketSize);
				usb_serial->in_buf = (u8*)malloc(usb_serial->in_mps);
			}
			USB_SERIAL_DEBUG("INPUT EP\n");
	    }
		else
		{
			if(usb_serial->out_pipe == NULL)
			{
				usb_serial->out_pipe = usb_open_pipe(dev, ep_desc);
				usb_serial->out_mps = UTOHS(ep_desc->wMaxPacketSize);
			}
			USB_SERIAL_DEBUG("OUTPUT EP\n");
	    }
	#ifdef USE_USB_SERIAL_INFO
		usb_dump_descriptor(dev, ep_desc, sizeof(usb_endpoint_desc_t));
	#endif
	}

	if(usb_serial->in_pipe == NULL || usb_serial->out_pipe == NULL)
	{
		USB_SERIAL_ERROR("In or Out EP descriptor is missed !!!\n");
		goto error;
	}

	buffer = (usb_serial_buffer_t*)malloc(sizeof(usb_serial_buffer_t));
	buffer->in_head = buffer->in_tail = 0;
	buffer->out_pos = 0;
	usb_serial->buffer = buffer;
	usb_serial->dev = dev;

	dev->priv = usb_serial;

	if(dev->dev_desc.bMaxPacketSize0 == 0x40)
	{
		usb_serial_vendor_request(dev, 0x02, 0x44);

		/* Reset upstream data pipes */
		usb_serial_vendor_request(dev, 0x08, 0x00);
		usb_serial_vendor_request(dev, 0x09, 0x00);
	}
	usb_serial_set_baudrate(dev, CONSOLE_UART_BAUDRATE);

	/* Start USB Serial Rx !!! */
//	usb_request(usb_serial->intr_pipe, NULL, usb_serial->in_mps, usb_serial_intr_callback);
	usb_request(usb_serial->in_pipe, NULL, usb_serial->in_mps, usb_serial_rx_callback);

	usb_serial_dev[idx] = usb_serial;
	if(idx == 0) register_usb_console(usb_serial);

	printf("USB-TO-SERIAL[%d] registered\n", idx);
	return 0;

error:
	if(usb_serial != NULL) free(usb_serial);
	if(buffer != NULL) free(buffer);

	return -1;
}

static int usb_serial_tx_data(usb_serial_t* usb_serial, void* data, int len)
{
	return usb_request_timeout(usb_serial->out_pipe, data, len, 100);
}

void usb_serial_putc(struct usb_serial* usb_serial, char c)
{
	usb_serial_buffer_t* buffer;

	if(usb_serial == NULL)	// || usb_serial->status == USB_SERIAL_STATUS_IN_PROCESS)
		return;

	buffer = usb_serial->buffer;
	if(buffer->out_pos >= OUT_MSG_BUF_SIZE)
	{
		usb_serial_flush(usb_serial);
	}
	buffer->out[buffer->out_pos++] = (u8)c;
}

void usb_serial_flush(struct usb_serial* usb_serial)
{
	usb_serial_buffer_t* buffer;

	if(usb_serial == NULL)
		return;

	buffer = usb_serial->buffer;
	if(buffer->out_pos > 0)
	{
		usb_serial_tx_data(usb_serial, buffer->out, buffer->out_pos);
		buffer->out_pos = 0;
	}
}

void usb_serial_puts(struct usb_serial* usb_serial, const char* str)
{
	if(usb_serial == NULL)
		return;

	while(*str)
	{
		if(*str == '\n') usb_serial_putc(usb_serial, '\r');
		usb_serial_putc(usb_serial, *str++);
	}
	usb_serial_flush(usb_serial);
}

int	usb_serial_check_rx(struct usb_serial* usb_serial)
{
	usb_serial_buffer_t* buffer;

	if(usb_serial == NULL)
		return 0;

	buffer = usb_serial->buffer;
	if(buffer->in_head != buffer->in_tail)
		return 1;

	return 0;
}

int usb_serial_getc(struct usb_serial* usb_serial)
{
	int res;
	usb_serial_buffer_t* buffer;

	if(usb_serial == NULL)
		return -1;

	buffer = usb_serial->buffer;
	if(buffer->in_head == buffer->in_tail)	/* empty buffer */
		return -1;

	res = buffer->in[buffer->in_head];
	buffer->in_head = next_pos(buffer->in_head, IN_MSG_BUF_SIZE);

	return res;
}

struct usb_serial*	usb_serial_open(int no)
{
	if(no < 0 || no >= MAX_USB_SERIAL_DEVICE || usb_serial_dev[no] == NULL)
	{
		printf("Unregisterd num[%d]\n", no);
		return NULL;
	}
	return usb_serial_dev[no];
}

int	usb_serial_close(struct usb_serial* usb_serial)
{
	// TODO:
	return 0;
}

#endif
