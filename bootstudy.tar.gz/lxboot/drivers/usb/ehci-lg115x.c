/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#if (USE_USB_EHCI == 1)
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <util.h>
#include <malloc.h>
#include <usb.h>
#include <list.h>
#include <thread.h>

#include "ehci.h"


//#define DUMP_EHCI_INFO

#if 0
#define EHCI_INFO(fmt, args...)		usb_printf(fmt, ##args)
#else
#define EHCI_INFO(fmt, args...)		do{}while(0)
#endif

#if 0
#define EHCI_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define EHCI_DEBUG(fmt, args...)	do{}while(0)
#endif

#if 0
#define EHCI_DESC_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define EHCI_DESC_DEBUG(fmt, args...)	do{}while(0)
#endif


#if 1
#define EHCI_ERROR(fmt, args...)	usb_printf("\x1b[31m"fmt"\x1b[0m", ##args)
#else
#define EHCI_ERROR(fmt, args...)	do{}while(0)
#endif


#define EHCI_RESET_DELAY	50	/* 50ms */


typedef struct ehci_xfer
{
	ehci_qh_t		*qh;

	usb_req_t		*req;

	LIST_ENTRY(ehci_xfer)   link;
} ehci_xfer_t;
typedef LIST_HEAD(ehci_xfer_head, ehci_xfer) ehci_xfer_head_t;


typedef struct ehci
{
	ehci_cap_reg_t		*cap_reg;
	ehci_op_reg_t		*op_reg;

	ehci_qh_t			*qh_root;

	int					num_ports;
	int					roothub_addr;


	ehci_xfer_head_t	xfer_head;

} ehci_t;


#define EHCI_CAP_REG_ADDR(ehci,r)		((ulong)(ehci->cap_reg) + r)
#define EHCI_OP_REG_ADDR(ehci,r)		((ulong)(ehci->op_reg) + r)

#if 0
#define EHCI_REG_READ(ehci,r)		(ehci->reg->r)
#define EHCI_REG_WRITE(ehci,r, v)	(ehci->reg->r = v)
#else
#define EHCI_CAP_REG_READ(ehci,r)		USB_REG_READ((ulong)(ehci->cap_reg) + r)
#define EHCI_CAP_REG_WRITE(ehci,r, v)	USB_REG_WRITE((ulong)(ehci->cap_reg) + r, v)

#define EHCI_OP_REG_READ(ehci,r)		USB_REG_READ((ulong)(ehci->op_reg) + r)
#define EHCI_OP_REG_WRITE(ehci,r, v)	USB_REG_WRITE((ulong)(ehci->op_reg) + r, v)
#endif

#if (CONFIG_ARCH == ARCH_LG1311)
static unsigned long ehci_base_addr_a0[] = USB_EHCI_BASE_A0;
static unsigned long ehci_base_addr_b0[] = USB_EHCI_BASE_B0;
static unsigned long *ehci_base_addr;
#else
#define EHCI_NUM_DEVICE		(sizeof(ehci_base_addr)/sizeof(unsigned long))
static unsigned long ehci_base_addr[] = USB_EHCI_BASE;
#endif

//static unsigned long ehci_base_addr[] = {LG1154_USB_EHCI1_BASE};


static usb_device_descriptor_t ehci_rh_dev_desc =
{
    sizeof(usb_device_descriptor_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_DEVICE,			/* bDescriptorType */
    HTOUS(0x0200),			/* bcdUSB */
    USB_CLASS_HUB,			/* bDeviceClass */
    0,						/* bDeviceSubClass */
    0,						/* bDeviceProtocol */
    64,						/* bMaxPacketSize0 */
    HTOUS(0),				/* idVendor */
    HTOUS(0),				/* idProduct */
    HTOUS(0x0110),			/* bcdDevice */
    1,						/* iManufacturer */
    2,						/* iProduct */
    0,						/* iSerialNumber */
    1						/* bNumConfigurations */
};

static usb_config_desc_t ehci_rh_cfg_desc =
{
    sizeof(usb_config_desc_t),			/* bLength */
    USB_DESCRIPTOR_TYPE_CONFIGURATION,	/* bDescriptorType */
	HTOUS(sizeof(usb_config_desc_t) +
		sizeof(usb_interface_desc_t) +
		sizeof(usb_endpoint_desc_t)),	/* wTotalLength */
    1,						/* bNumInterfaces */
    1,						/* bConfigurationValue */
    0,						/* iConfiguration */
    USB_CONFIG_SELF_POWERED,		/* bmAttributes */
    0						/* MaxPower */
};

static usb_interface_desc_t ehci_rh_if_desc =
{
    sizeof(usb_interface_desc_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_INTERFACE,	/* bDescriptorType */
    0,						/* bInterfaceNumber */
    0,						/* bAlternateSetting */
    1,						/* bNumEndpoints */
    USB_CLASS_HUB,			/* bInterfaceClass */
    0,						/* bInterfaceSubClass */
    0,						/* bInterfaceProtocol */
    0						/* iInterface */
};

static usb_endpoint_desc_t ehci_rh_ep_desc =
{
    sizeof(usb_endpoint_desc_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_ENDPOINT,	/* bDescriptorType */
    (USB_EP_ADDR_DIR_IN | 1),	/* bEndpointAddress */
    USB_EP_ATTR_INTERRUPT,		/* bmAttributes */
    HTOUS(8),					/* wMaxPacketSize */
    255							/* bInterval */
};

static usb_hub_desc_t ehci_rh_hub_desc =
{
	sizeof(usb_hub_desc_t),		/* bDescLength */
	USB_DESCRIPTOR_TYPE_HUB,	/* bDescriptorType */
	0,		/* bNbrPorts */
	0,		/* wHubCharacteristics */
	0,		/* bPwrOn2PwrGood */
	0,		/* bHubContrCurrent */
	{0},	/* DeviceRemovable[1] */
	{0},	/* PortPwrCtrlMask[1] */
};

#if (CONFIG_ARCH == ARCH_LG1311)
static ehci_t *_ehci;
static usb_hcd_t *_usb_hcd;
#else
static ehci_t _ehci[EHCI_NUM_DEVICE];
static usb_hcd_t _usb_hcd[EHCI_NUM_DEVICE];
#endif



static int ehci_wait_status(u32 addr, u32 mask, u32 value, int timeout)
{
	timeout_id_t t;
	uint32_t v;

	set_timeout(&t, timeout);
	while(1)
	{
		v = USB_REG_READ((ulong)addr);
		if((v&mask) == value) return 0;
		if(is_timeout(&t)) return -1;
		udelay(5);
	}
}

static int ehci_start(usb_hcd_t *hcd)
{
	ehci_t *ehci = (ehci_t*)hcd->bus;
	uint32_t v;


	EHCI_INFO("Capability Reg Base : 0x%08x\n", (u32)ehci->cap_reg);
	EHCI_INFO("Operation Reg Base : 0x%08x\n", (u32)ehci->op_reg);

	v = EHCI_CAP_REG_READ(ehci, HCCAPBASE);
	EHCI_INFO("CAPLENGTH:%d\n", CAPLENGTH(v));
	EHCI_INFO("HCIVERSION:%d.%d\n", HCIVERSION_MAJOR(v), HCIVERSION_MINOR(v));

	v = EHCI_CAP_REG_READ(ehci, HCSPARAMS);
	EHCI_INFO("HCSPARAMS : 0x%08x\n", v);
	EHCI_INFO("Number of Companion Controller : %d\n", HCS_N_CC(v));
	EHCI_INFO("Number of Ports per Companion Controller : %d\n", HCS_N_PCC(v));
	EHCI_INFO("Port Power Control : %d\n", HCS_PPC(v));
	EHCI_INFO("N_PORTS : %d\n", HCS_N_PORTS(v));
	ehci->num_ports = HCS_N_PORTS(v);

	v = EHCI_CAP_REG_READ(ehci, HCCPARAMS);
	EHCI_INFO("64-bit Addressing Capability : %d\n", HCC_64BIT_ADDR(v));


	/* 4.1 Host Controller Initialization */

	/* Software should not set HCRESET bit to a one when the HCHalted bit in the USBSTS register
	 * is a zero */
	EHCI_OP_REG_WRITE(ehci, EHCI_USBCMD, 0);
	if(ehci_wait_status(EHCI_OP_REG_ADDR(ehci, EHCI_USBSTS), EHCI_USBSTS_HCH, EHCI_USBSTS_HCH, 100) < 0)
	{
		EHCI_ERROR("Not Halted\n");
		return -1;
	}

	/* After HCRESET, all of the operational registers will be at their default values */
	EHCI_OP_REG_WRITE(ehci, EHCI_USBCMD, EHCI_USBCMD_HCRESET);
	if(ehci_wait_status(EHCI_OP_REG_ADDR(ehci, EHCI_USBCMD), EHCI_USBCMD_HCRESET, 0, 1000) < 0)
	{
		EHCI_ERROR("Reset timeout\n");
		return -1;
	}
	v = EHCI_OP_REG_READ(ehci, EHCI_USBCMD);
	EHCI_INFO("USBCMD default value : 0x%08x\n", v);


	ehci_qh_t *qh = ehci->qh_root;

	memset(qh, 0, sizeof(ehci_qh_t));
	qh->hlink	= (ulong)qh | EHCI_QHLP_TYPE_QH;
	qh->ep1		= EHCI_EP1_H(1) | EHCI_EP1_EPS_HIGH;
//	qh->ep2		= EHCI_EP2_MULT(1);
	qh->cur_qtd	= EHCI_QTD_TERMINATE;

	qh->overlay.next_qtd		= EHCI_QTD_TERMINATE;
	qh->overlay.alt_next_qtd	= EHCI_QTD_TERMINATE;
	qh->overlay.qtd_token		= EHCI_QTD_STATUS_HALTED;



	/* Set async list address */
	EHCI_OP_REG_WRITE(ehci, EHCI_ASYNCLISTADDR, (ulong)qh);


	/* Start Host Controller */
	v = EHCI_OP_REG_READ(ehci, EHCI_USBCMD);
#if 0
	v = (v & EHCI_USBCMD_FLS_MASK) | EHCI_USBCMD_ITC_8 | EHCI_USBCMD_RUN;
#else
	v &= ~(EHCI_USBCMD_IAAD | EHCI_USBCMD_ASE | EHCI_USBCMD_PSE | EHCI_USBCMD_HCRESET);
	v |= EHCI_USBCMD_RUN;
#endif
	EHCI_OP_REG_WRITE(ehci, EHCI_USBCMD, v);


	/* To route all ports to the EHCI controller */
	EHCI_OP_REG_WRITE(ehci, EHCI_CONFIGFLAG, EHCI_CONFIGFLAG_CF);


	v = EHCI_OP_REG_READ(ehci, EHCI_USBSTS);
	EHCI_INFO("USB Status : 0x%08x\n", v);
	EHCI_OP_REG_WRITE(ehci, EHCI_USBSTS, v | 0x3F);

	v = EHCI_OP_REG_READ(ehci, EHCI_USBINTR);
	EHCI_INFO("Intr Enable : 0x%08x\n", v);

	ehci->roothub_addr = 0;

	list_init_head(&ehci->xfer_head);

//EHCI_DEBUG("End of echi_start. waiting...\n");
//getchar();

	return 0;
}

static void ehci_stop(usb_hcd_t *hcd)
{
	ehci_t *ehci = (ehci_t*)hcd->bus;
	EHCI_OP_REG_WRITE(ehci, EHCI_USBCMD, 0);
}

#if 0
static void ehci_port_handover(int port)
{
	u32 status;
	u32 portsc;

	portsc = EHCI_PORTSC(port);

	status = EHCI_OP_REG_READ(ehci, portsc);
	status &= ~(EHCI_PORTSC_CSC | EHCI_PORTSC_PEDC | EHCI_PORTSC_OCC);
	status |= EHCI_PORTSC_PO;
	EHCI_OP_REG_WRITE(ehci, portsc, status);
}
#endif

static int ehci_rh_transfer(usb_hcd_t *hcd, usb_req_t* req, usb_device_request_t* dev_req)
{
	u8 data[128];
	u16 wValue, wIndex;
	int len = 0;
	ehci_t* ehci = (ehci_t*)hcd->bus;

	u8 *ptr = data;


	wValue = UTOHS(dev_req->wValue);
	wIndex = UTOHS(dev_req->wIndex);

#define OP(r, rt)	((u16)(r) << 8 | (rt))
	switch(OP(dev_req->bRequest, dev_req->bmRequestType))
	{
		case OP(USB_HUB_REQ_GET_STATUS,	USB_REQTYPE_DIR_IN | USB_REQTYPE_HUB):
		{
			usb_hub_status_t *hub_status = (usb_hub_status_t*)data;

			hub_status->wHubStatus = USB_HUB_STATUS_LPS;
			hub_status->wHubChange = 0;

			len = sizeof(usb_hub_status_t);
			break;
		}

		case OP(USB_HUB_REQ_GET_STATUS, USB_REQTYPE_DIR_IN | USB_REQTYPE_PORT):
		{
			u32 status;
			usb_port_status_t *port_status = (usb_port_status_t*)data;

			if(wIndex < 1 || wIndex > ehci->num_ports) goto invalid;
			status = EHCI_OP_REG_READ(ehci, EHCI_PORTSC(wIndex-1));

			port_status->wPortStatus = 0;
			port_status->wPortChange = 0;

			if((status&EHCI_PORTSC_CCS))	port_status->wPortStatus |= USB_PORT_STATUS_CONNECT;
			if((status&EHCI_PORTSC_PED))	port_status->wPortStatus |= USB_PORT_STATUS_ENABLED;
			if((status&EHCI_PORTSC_S))		port_status->wPortStatus |= USB_PORT_STATUS_SUSPEND;
			if((status&EHCI_PORTSC_PR))		port_status->wPortStatus |= USB_PORT_STATUS_RESET;
			if((status&EHCI_PORTSC_PP)) 	port_status->wPortStatus |= USB_PORT_STATUS_POWER;

			port_status->wPortStatus |= USB_PORT_STATUS_HIGHSPEED;

			if((status&EHCI_PORTSC_CSC))	port_status->wPortChange |= USB_PORT_CHANGE_CONNECT;
			if((status&EHCI_PORTSC_PEDC))	port_status->wPortChange |= USB_PORT_CHANGE_ENABLED;
			if((status&EHCI_PORTSC_OCC))	port_status->wPortChange |= USB_PORT_CHANGE_OCURRENT;

			EHCI_INFO("port_status->wPortStatus : 0x%08x\n", port_status->wPortStatus);

			len = sizeof(usb_port_status_t);
			break;
		}

		case OP(USB_HUB_REQ_CLEAR_FEATURE, USB_REQTYPE_DIR_OUT | USB_REQTYPE_PORT):
		{
			u32 status;
			u32 portsc;

			if(wIndex < 1 || wIndex > ehci->num_ports) goto invalid;

			portsc = EHCI_PORTSC(wIndex-1);
			status = EHCI_OP_REG_READ(ehci, portsc);
			status &= ~EHCI_PORTSC_CLEAR;
			switch(wValue)
			{
				case USB_PORT_FEATURE_ENABLE:
					EHCI_OP_REG_WRITE(ehci, portsc, status & ~EHCI_PORTSC_PED); break;
				case USB_PORT_FEATURE_SUSPEND:
					EHCI_OP_REG_WRITE(ehci, portsc, status & ~EHCI_PORTSC_S); break;
				case USB_PORT_FEATURE_POWER:
					EHCI_OP_REG_WRITE(ehci, portsc, status & ~EHCI_PORTSC_PP); break;
				case USB_PORT_FEATURE_C_CONNECTION:
					EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_CSC); break;
				case USB_PORT_FEATURE_C_ENABLE:
					EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_PEDC); break;
				case USB_PORT_FEATURE_C_OVER_CURRENT:
					EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_OCC); break;
			}
			break;
		}

		case OP(USB_HUB_REQ_SET_FEATURE, USB_REQTYPE_DIR_OUT | USB_REQTYPE_PORT):
		{
			u32 status;
			u32 portsc;

			if(wIndex < 1 || wIndex > ehci->num_ports) goto invalid;

			portsc = EHCI_PORTSC(wIndex-1);
			status = EHCI_OP_REG_READ(ehci, portsc);

			if((status&EHCI_PORTSC_PO)) break;	/* Not high speed */

			status &= ~EHCI_PORTSC_CLEAR;
			switch(wValue)
			{
				case USB_PORT_FEATURE_ENABLE:
					EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_PED); break;
				case USB_PORT_FEATURE_SUSPEND:
					EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_S); break;
				case USB_PORT_FEATURE_POWER:
					EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_PP); break;
				case USB_PORT_FEATURE_RESET:
				{
					if((status&EHCI_PORTSC_LS_MASK) == EHCI_PORTSC_LS_LOW)	/* Low Speed */
					{
						EHCI_INFO("Low Speed Device !!!\n");
						EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_PO);
						break;
					}

					status &= ~EHCI_PORTSC_PED;
					status |= EHCI_PORTSC_PR;
					EHCI_OP_REG_WRITE(ehci, portsc, status);

					msleep(EHCI_RESET_DELAY);

					status &= ~EHCI_PORTSC_PR;
					EHCI_OP_REG_WRITE(ehci, portsc, status);
					if(ehci_wait_status(EHCI_OP_REG_ADDR(ehci, portsc), EHCI_PORTSC_PR, 0, 2) < 0)
					{
						EHCI_ERROR("PORT RESET Timeout\n");
						return -1;
					}

					status = EHCI_OP_REG_READ(ehci, portsc);
					if((status&EHCI_PORTSC_PED))
					{
						EHCI_INFO("High Speed Device !!!\n");
					}
					else
					{
						EHCI_INFO("Port not enabled. Give up ownership !\n");
						EHCI_OP_REG_WRITE(ehci, portsc, status | EHCI_PORTSC_PO);
					}
				}
				break;
			}
			break;
		}

		case OP(USB_REQUEST_GET_DESCRIPTOR,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			switch(wValue >> 8)
			{
				case USB_DESCRIPTOR_TYPE_DEVICE:
					ptr = (u8*)&ehci_rh_dev_desc;
					len = sizeof(ehci_rh_dev_desc);
					break;

				case USB_DESCRIPTOR_TYPE_CONFIGURATION:
					memcpy(ptr, &ehci_rh_cfg_desc, sizeof(usb_config_desc_t));
					len += sizeof(usb_config_desc_t);
					memcpy(ptr + len, &ehci_rh_if_desc, sizeof(usb_interface_desc_t));
					len += sizeof(usb_interface_desc_t);
					memcpy(ptr + len, &ehci_rh_ep_desc, sizeof(usb_endpoint_desc_t));
					len += sizeof(usb_endpoint_desc_t);
					break;
			}
			break;

		case OP(USB_REQUEST_GET_DESCRIPTOR, USB_REQTYPE_DIR_IN | USB_REQTYPE_HUB):
		{
			usb_hub_desc_t *hub_desc = (usb_hub_desc_t*)data;

			EHCI_DEBUG("USB_REQUEST_GET_DESCRIPTOR(USB_REQTYPE_TYPE_CLASS). wValue=0x%x\n", wValue);

			memcpy(hub_desc, &ehci_rh_hub_desc, sizeof(ehci_rh_hub_desc));
			hub_desc->bNbrPorts = ehci->num_ports;

			len = sizeof(usb_hub_desc_t);
			break;
		}

		case OP(USB_REQUEST_GET_CONFIGURATION,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			goto undefined;

		case OP(USB_REQUEST_SET_ADDRESS,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			EHCI_DEBUG("USB_REQUEST_SET_ADDRESS. wValue=%d\n", wValue);
			ehci->roothub_addr = wValue;
			break;

		case OP(USB_REQUEST_SET_CONFIGURATION,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			EHCI_DEBUG("USB_REQUEST_SET_CONFIGURATION. wValue=%d\n", wValue);
			break;

		default:
			goto undefined;

	}

	if(len > 0)
	{
		len = min(len, req->size);
		memcpy(req->dma_buf, ptr, len);
	#ifdef USE_USB_CACHED_BUFFER
		dcache_clean_range((unsigned long)req->dma_buf, len);
	#endif
	}

	req->xfer_len = len;
	req->status = USB_REQ_STATUS_DONE;

	return len;

undefined:
	EHCI_ERROR("Not implemented request[0x%04x]\n", OP(dev_req->bRequest, dev_req->bmRequestType));
	return -1;

invalid:
	EHCI_ERROR("Invalid param : request[0x%04x], wValue:%d, wIndex:%d, wLength:%d \n",
			OP(dev_req->bRequest, dev_req->bmRequestType),
			dev_req->wValue, dev_req->wIndex, dev_req->wLength);
	return -1;
}

static int ehci_set_qtd_buffer(ehci_qtd_t *qtd, void *buf, int size)
{
	ulong addr;
	int wsize, remained;
	int i;

	if(size <= 0) return 0;

	addr = (ulong)buf;
	remained = size;
	EHCI_DEBUG("##ehci_set_qtd_buffer. addr:0x%08x, size:%d\n", addr, size);
	for(i=0; i<EHCI_QTD_BUFFER_CNT; i++)
	{
		qtd->buffer[i] = addr;
		addr = (addr + EHCI_QTD_BUFFER_ALIGMENT) & ~(EHCI_QTD_BUFFER_ALIGMENT - 1);
		wsize = addr - qtd->buffer[i];
		remained -= wsize;

		EHCI_INFO("\t[%d] : 0x%08x,%d\n", i, qtd->buffer[i], wsize);
		if(remained <= 0) break;
	}

	if(i == EHCI_QTD_BUFFER_CNT)
	{
		EHCI_ERROR("Over max qTD buffer, remained=%d\n", remained);
		return -1;
	}

	return 0;
}

#if 0
static void display_qtd_list(ehci_qh_t *qh)
{
	ehci_qtd_t *qtd;

	list_foreach(&qh->qtd_head, link, qtd)
	{
		EHCI_INFO("qTD(0x%08x)T(0x%08x)", (u32)qtd, qtd->qtd_token);
		if(list_is_last(&qh->qtd_head, qtd))
		{
			EHCI_INFO("\n");
			break;
		}
		else
		{
			EHCI_INFO(" ==> ");
		}
	}
}
#endif

static ehci_xfer_t* ehci_add_xfer(ehci_t* ehci, ehci_qh_t *qh, usb_req_t* req)
{
	ehci_xfer_t *xfer;

	xfer		= (ehci_xfer_t*)malloc(sizeof(ehci_xfer_t));
	xfer->qh	= qh;
	xfer->req	= req;

	EHCI_DEBUG("ehci_add_xfer. xfer:%p, qh:%p\n", xfer, qh);

	if(list_empty(&ehci->xfer_head))
	{
		ehci_qh_t *qh_root = ehci->qh_root;

		qh->hlink = (ulong)ehci->qh_root | EHCI_QHLP_TYPE_QH;
		qh_root->hlink = (ulong)qh | EHCI_QHLP_TYPE_QH;
	}
	else
	{
		ehci_xfer_t *xfer_last = list_last(&ehci->xfer_head);
		ehci_qh_t *qh_last = xfer_last->qh;

		qh->hlink = qh_last->hlink;
		qh_last->hlink = (ulong)qh | EHCI_QHLP_TYPE_QH;
	}

	list_insert_tail(&ehci->xfer_head, xfer, link);

	return xfer;
}


static void ehci_remove_xfer(ehci_t *ehci, ehci_xfer_t *xfer)
{
	ehci_qh_t	*qh, *pre_qh;
	ehci_qtd_t	*qtd, *_qtd;

	EHCI_DEBUG("ehci_remove_xfer. xfer:%p, qh:%p\n", xfer, xfer->qh);

	qh = xfer->qh;
	if(list_is_first(&ehci->xfer_head, xfer))
	{
		pre_qh = ehci->qh_root;
	}
	else
	{
		pre_qh = qh->link.pre;
	}
	pre_qh->hlink = qh->hlink;


	list_remove(&ehci->xfer_head, xfer, link);

	/* Free resources */
	list_foreach_safe(&qh->qtd_head, link, qtd, _qtd)
	{
		dma_free(qtd);
	}
	dma_free(qh);
	free(xfer);
}


static void echi_proc_xfer(ehci_t *ehci)
{
	ehci_xfer_t	*xfer, *_xfer;
	ehci_qh_t	*qh;
	ehci_qtd_t	*qtd;
	usb_req_t	*req;
	u32			status, xfer_size;
	int			done;

	EHCI_INFO("## echi_proc_xfer ##\n");
	list_foreach_safe(&ehci->xfer_head, link, xfer, _xfer)
	{
		done = 0;
		qh = xfer->qh;
		req = xfer->req;
		xfer_size = req->size;

		list_foreach(&qh->qtd_head, link, qtd)
		{
			status = qtd->qtd_token;
			if(status&EHCI_QTD_STATUS_ACTIVE){ EHCI_INFO("SKIP: STATUS=0x%08x\n", status); break;}

			if(status&EHCI_QTD_STATUS_HALTED)
			{
				EHCI_INFO("Xfer halted ... STATUS:0x%08x \n", status);
				xfer->req->status = USB_REQ_STATUS_STALL;
				done = 1;
				break;
			}

			if(EHCI_QTD_TOKEN_GET_TBT(status))
			{
				EHCI_INFO("Remained.... %d\n", EHCI_QTD_TOKEN_GET_TBT(status));
				xfer_size -= EHCI_QTD_TOKEN_GET_TBT(status);
			}
			EHCI_INFO(" T:%d", EHCI_QTD_TOKEN_GET_DT(status));

			if(list_is_last(&qh->qtd_head, qtd))	/* last qTD */
			{
				if(xfer_size != req->size)
					EHCI_ERROR("xfer size is diff. req size:%d, xfer:%d\n", req->size, xfer_size);

				req->xfer_len = xfer_size;
				req->status = USB_REQ_STATUS_DONE;

				req->pipe->toggle = EHCI_QTD_TOKEN_GET_DT(status);
				//req->pipe->toggle ^= 1;

				EHCI_INFO("DONE. status:0x%08x\n", status);

				done = 1;
				break;
			}
		}
		EHCI_INFO("\n");

		if(done)
		{
			ehci_remove_xfer(ehci, xfer);
			if(req->callback) req->callback(req);
		}
	}
}

static ehci_qtd_t* ehci_add_qtd(ehci_t *ehci, ehci_qh_t *qh, u32 token, void* data, int size)
{
	ehci_qtd_t *qtd, *pre_qtd;

	qtd = (ehci_qtd_t*)dmalloc_align(sizeof(ehci_qtd_t), EHCI_QTD_ALIGMENT);
	memset(qtd, 0, sizeof(ehci_qtd_t));

	qtd->next_qtd		= EHCI_QTD_TERMINATE;
	qtd->alt_next_qtd	= EHCI_QTD_TERMINATE;
	qtd->qtd_token		= token;

	ehci_set_qtd_buffer(qtd, data, size);

	if(list_empty(&qh->qtd_head))
	{
		pre_qtd = &qh->overlay;
	}
	else
	{
		pre_qtd = list_last(&qh->qtd_head);
	}
	pre_qtd->next_qtd = (ulong)qtd;

	list_insert_tail(&qh->qtd_head, qtd, link);

	return qtd;
}


static ehci_qh_t *ehci_get_qh(ehci_t* ehci, usb_pipe_t* pipe)
{
	ehci_qh_t *qh;
	usb_device_t* dev = pipe->dev;

	EHCI_DEBUG("ehci_get_qh. addr:%d, parent addr:%d, port:%d, num:%d, mps:%d\n",
		dev->address, dev->parent->address, dev->port, pipe->num, pipe->mps);

	qh = (ehci_qh_t*)dmalloc_align(sizeof(ehci_qh_t),EHCI_QH_ALIGMENT);
	memset(qh, 0, sizeof(ehci_qh_t));

	qh->ep1 =	EHCI_EP1_DEVADDR(dev->address) |
				EHCI_EP1_ENDPT(pipe->num) |
				EHCI_EP1_EPS_HIGH | 	/* temporal value */
				EHCI_EP1_MPL(pipe->mps) |
				EHCI_EP1_DTC(1) |
				EHCI_EP1_C(0) |
				EHCI_EP1_RL(8);

	qh->ep2 =	EHCI_EP2_HA(dev->parent->address) |
				EHCI_EP2_PN(dev->port) |
				EHCI_EP2_MULT(1);

	qh->overlay.next_qtd = EHCI_QTD_TERMINATE;

	list_init_head(&qh->qtd_head);

	return qh;
}

static int ehci_transfer(usb_hcd_t *hcd, usb_req_t* req, usb_device_request_t* dev_req)
{
	usb_pipe_t* pipe = req->pipe;
	usb_device_t* dev = pipe->dev;
	ehci_t* ehci = (ehci_t*)hcd->bus;

	ehci_qh_t	*qh;
	ehci_xfer_t	*xfer;
	u32			token;
	u8			*buf;
	int 		size;

	u32 v;


	if(dev->address == ehci->roothub_addr)		// root hub
	{
		return ehci_rh_transfer(hcd, req, dev_req);
	}
	EHCI_DEBUG("##### ehci_transfer. #####\n");

	if(!IS_USB_PIPE_CONTROL(pipe) && !IS_USB_PIPE_BULK(pipe))
	{
		EHCI_ERROR("Not supported type !!!\n");
		return -1;
	}
	buf = req->dma_buf;
	size = req->size;


	EHCI_DEBUG("CONTROL: req:%p, devreq:%p, buf:%p, size:%d\n", req, dev_req, buf, size);
	if(IS_USB_PIPE_CONTROL(pipe))
	{
		EHCI_INFO("Control Transfer \n");

		qh = ehci_get_qh(ehci, pipe);

		token =	EHCI_QTD_TOKEN_DT(0) |
				EHCI_QTD_TOKEN_TBT(sizeof(usb_device_request_t)) |
				EHCI_QTD_TOKEN_EC(3) |
				EHCI_QTD_TOKEN_PID_SETUP |
				EHCI_QTD_STATUS_ACTIVE;

		ehci_add_qtd(ehci, qh, token, dev_req, sizeof(usb_device_request_t));

		if(size > 0)
		{
			token = EHCI_QTD_TOKEN_DT(1) |
					EHCI_QTD_TOKEN_TBT(size) |
					EHCI_QTD_TOKEN_EC(3) |
					(IS_USB_PIPE_IN(pipe) ? EHCI_QTD_TOKEN_PID_IN : EHCI_QTD_TOKEN_PID_OUT) |
					EHCI_QTD_STATUS_ACTIVE;

			ehci_add_qtd(ehci, qh, token, buf, size);
		}
		/* Invert the current EP direction */
		token = EHCI_QTD_TOKEN_DT(1) |
				EHCI_QTD_TOKEN_TBT(0) |
				EHCI_QTD_TOKEN_IOC(1) |
				EHCI_QTD_TOKEN_EC(3) |
				(IS_USB_PIPE_IN(pipe) ? EHCI_QTD_TOKEN_PID_OUT : EHCI_QTD_TOKEN_PID_IN) |
				EHCI_QTD_STATUS_ACTIVE;

		ehci_add_qtd(ehci, qh, token, NULL, 0);

		xfer = ehci_add_xfer(ehci, qh, req);

		/* Clear status */
		v = EHCI_OP_REG_READ(ehci, EHCI_USBSTS);
//		EHCI_INFO("USB Status : 0x%08x\n", v);
		EHCI_OP_REG_WRITE(ehci, EHCI_USBSTS, v & 0x3F);


		v = EHCI_OP_REG_READ(ehci, EHCI_USBCMD);
		v |= EHCI_USBCMD_ASE;
		EHCI_OP_REG_WRITE(ehci, EHCI_USBCMD, v);
//		EHCI_INFO("### Enable ASE ###\n");

		if(ehci_wait_status(EHCI_OP_REG_ADDR(ehci, EHCI_USBSTS), EHCI_USBSTS_ASS, EHCI_USBSTS_ASS, 100) < 0)
		{
			EHCI_ERROR("ASS timeout\n");
			ehci_remove_xfer(ehci, xfer);
			return -1;
		}

	}
	else
	{
		int toggle = pipe->toggle;
		int remained, wsize;
		#define EHCI_QTD_MAX_SIZE	(EHCI_QTD_BUFFER_ALIGMENT * (EHCI_QTD_BUFFER_CNT-1))

		EHCI_INFO("Bulk Transfer %s [%dbytes] T:%d\n",
			IS_USB_PIPE_IN(pipe) ? "IN" : "OUT", size, pipe->toggle);

		qh = ehci_get_qh(ehci, pipe);
//		qh->ep1 &= ~EHCI_EP1_DTC(1);
//		qh->overlay.qtd_token = EHCI_QTD_TOKEN_DT(pipe->toggle);

		remained = size;
		while(remained > 0)
		{
			wsize = min(remained, EHCI_QTD_MAX_SIZE);

			token = EHCI_QTD_TOKEN_DT(toggle) |
					EHCI_QTD_TOKEN_TBT(wsize) |
					EHCI_QTD_TOKEN_IOC(1) |
					EHCI_QTD_TOKEN_EC(3) |
					(IS_USB_PIPE_IN(pipe) ? EHCI_QTD_TOKEN_PID_IN : EHCI_QTD_TOKEN_PID_OUT) |
					EHCI_QTD_STATUS_ACTIVE;

			ehci_add_qtd(ehci, qh, token, buf, wsize);

			if((wsize/pipe->mps) & 1) toggle ^= 1;

			remained -= wsize;
			buf += wsize;
		}

		xfer = ehci_add_xfer(ehci, qh, req);

//		display_qtd_list(qh);

		/* Clear status */
//		v = EHCI_OP_REG_READ(ehci, EHCI_USBSTS);
//		EHCI_OP_REG_WRITE(ehci, EHCI_USBSTS, v & EHCI_USBSTS_INTR_MASK);

		v = EHCI_OP_REG_READ(ehci, EHCI_USBCMD);
		v |= EHCI_USBCMD_ASE;
		EHCI_OP_REG_WRITE(ehci, EHCI_USBCMD, v);

		if(ehci_wait_status(EHCI_OP_REG_ADDR(ehci, EHCI_USBSTS), EHCI_USBSTS_ASS, EHCI_USBSTS_ASS, 100) < 0)
		{
			EHCI_ERROR("ASS timeout\n");
			ehci_remove_xfer(ehci, xfer);
			return -1;
		}


	}

	return 0;
}


static int ehci_interrupt(usb_hcd_t *hcd)
{
	ehci_t* ehci = (ehci_t*)hcd->bus;
	u32 status;


	status = (EHCI_OP_REG_READ(ehci, EHCI_USBSTS) & EHCI_USBSTS_INTR_MASK);
	if(status == 0) return 0;

	EHCI_INFO("ehci_interrupt: status=0x%08x\n", status);

	/* Clear bit */
	EHCI_OP_REG_WRITE(ehci, EHCI_USBSTS, status);

	if((status&EHCI_USBSTS_HSE))
	{
		EHCI_ERROR("Controller error !!!\n");
	}

	if((status&EHCI_USBSTS_PCD))
	{
		EHCI_INFO("Port change detected\n");
	}

	echi_proc_xfer(ehci);

	return 0;
}


static usb_hcd_func_t hcd_func =
{
	.start		= ehci_start,
	.stop		= ehci_stop,
	.transfer	= ehci_transfer,
	.interrupt	= ehci_interrupt,
};

int usb_ehci_init(void)
{
	int i;
	char name[MAX_USBD_NAME_LENGTH + 1];
#if (CONFIG_ARCH == ARCH_LG1311)
	int EHCI_NUM_DEVICE;

	if(get_chip_rev() < CHIP_LG1311_B0)
	{//A0, A1
		EHCI_NUM_DEVICE = (sizeof(ehci_base_addr_a0)/sizeof(unsigned long));
		ehci_base_addr = ehci_base_addr_a0;
	}
	else
	{//B0
		EHCI_NUM_DEVICE = (sizeof(ehci_base_addr_b0)/sizeof(unsigned long));
		ehci_base_addr = ehci_base_addr_b0;
	}

	_ehci = (ehci_t *)calloc(1, sizeof(ehci_t) * EHCI_NUM_DEVICE);
	if(_ehci == NULL)
	{
		EHCI_ERROR("fail malloc\n");
		return -1;
	}

	_usb_hcd = (usb_hcd_t *)calloc(1, sizeof(usb_hcd_t) * EHCI_NUM_DEVICE);
	if(_usb_hcd == NULL)
	{
		EHCI_ERROR("fail malloc\n");
		return -1;
	}
#endif

	for(i=0; i<EHCI_NUM_DEVICE; i++)
	{
		_ehci[i].cap_reg	= (ehci_cap_reg_t*)(ehci_base_addr[i] + 0x00);
		_ehci[i].op_reg		= (ehci_op_reg_t*)(ehci_base_addr[i] + 0x10);
		_ehci[i].qh_root	= (ehci_qh_t*)dmalloc_align(sizeof(ehci_qh_t), EHCI_QH_ALIGMENT);

		_usb_hcd[i].bus		= (void*)&_ehci[i];
		_usb_hcd[i].func	= &hcd_func;
		_usb_hcd[i].rev		= USB_REV_2_0;

		sprintf(name, "EHCI[%d]", i);
		usb_register_hcd(name, &_usb_hcd[i]);
	}

	return 0;
}
#endif
