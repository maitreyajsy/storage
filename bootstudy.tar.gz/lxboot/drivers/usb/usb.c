/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if (USE_USB == 1)
#include <types.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <console.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <malloc.h>
#include <serial.h>
#include <thread.h>
#include <usb.h>

//#define USB_DUMP_DESCRIPTOR

#if 0
#define USB_INFO(fmt, args...)		usb_printf(fmt, ##args)
#else
#define USB_INFO(fmt, args...)		do{}while(0)
#endif

#if 0
#define USB_SCAN_INFO(fmt, args...)	usb_printf(fmt, ##args)
#else
#define USB_SCAN_INFO(fmt, args...)	do{}while(0)
#endif

#if 0
#define USB_DEBUG(fmt, args...)		usb_printf(fmt, ##args)
#else
#define USB_DEBUG(fmt, args...)		do{}while(0)
#endif

#if 0
#define USB_REQ_DEBUG(fmt, args...)		usb_printf(fmt, ##args)
#else
#define USB_REQ_DEBUG(fmt, args...)		do{}while(0)
#endif


#if 1
#define USB_ERROR(fmt, args...)		usb_printf("\x1b[31mUSB[%d]:"fmt"\x1b[0m", __LINE__, ##args)
#else
#define USB_ERROR(fmt, args...)		do{}while(0)
#endif


#define USB_SCAN_HUB	/* Scan USB Hub to detect device */

#define HCD_FROM_PIPE(p)		(p->dev->usbd->hcd)
#define HCD_FROM_DEVICE(d)		(d->usbd->hcd)

#define ROOTHUB_ADDR			1

#define USB_POLL_TIME_INTERVAL	10	/* 10ms */
#define USB_MAX_CONTROLLERS		8


#ifndef OHCI_INIT_LEVEL
#define OHCI_INIT_LEVEL			USB_INIT_LEVEL_1
#endif

#ifndef EHCI_INIT_LEVEL
#define EHCI_INIT_LEVEL			USB_INIT_LEVEL_1
#endif

#ifndef XHCI_INIT_LEVEL
#define XHCI_INIT_LEVEL			USB_INIT_LEVEL_2
#endif


#ifdef USB_SCAN_HUB
#define USB_SCAN_TIME_INTERVAL	100	/* 100ms */
#define USB_MAX_HUBS		(USB_MAX_CONTROLLERS +1) /* For hub type built-in BT/WiFi Combo */
#define USB_SCAN_HUB_ONCE		/* if coonected before, never try it again */
static usb_device_t *usb_hub[USB_MAX_HUBS];
static int usb_scan_timer_id = -1;
#endif

static usb_usbd_t usb_driver[USB_MAX_CONTROLLERS];

static int usb_timer_id = -1;

static int usb_inited;
static int vbus_enable = 0;

static int usb_hub_attatch(usb_device_t* dev);
static char* usb_get_string(usb_device_t* dev, int idx);


static usb_req_t* _usb_request( usb_pipe_t* pipe,
								void* buf, int size,
								usb_device_request_t *devreq,
								int (*callback)(usb_req_t*)
								)
{
	usb_req_t *req;
	usb_hcd_t *hcd = HCD_FROM_PIPE(pipe);

	req = (usb_req_t*)calloc(sizeof(usb_req_t), 1);

	if(size > 0) {
		int asize = (size + D_CACHE_LINE_SIZE - 1) & ~(D_CACHE_LINE_SIZE-1);

	#ifdef USE_USB_CACHED_BUFFER
		req->dma_buf = malloc_align(asize, 64);
	#else
		req->dma_buf = dma_malloc(asize);
	#endif

		if(IS_USB_PIPE_OUT(pipe)) {
			memcpy(req->dma_buf, buf, size);
		#ifdef USE_USB_CACHED_BUFFER
			dcache_clean_range((unsigned long)req->dma_buf, asize);
		#endif
		} else {
		#ifdef USE_USB_CACHED_BUFFER
			dcache_inv_range((unsigned long)req->dma_buf, asize);
		#endif
		}
		req->buf = buf;
	}

	req->pipe		= pipe;
	req->status		= USB_REQ_STATUS_RUN;
	req->size		= size;
	req->callback	= callback;

	if(hcd->func->transfer(hcd, req, devreq) < 0) {
		USB_ERROR("Can't execute transfer !\n");
		usb_free_request(req);
		return NULL;
	}

	return req;
}

usb_req_t* usb_request(usb_pipe_t* pipe, void* buf, int size, int (*callback)(usb_req_t*))
{
	return _usb_request(pipe, buf, size, NULL, callback);
}

int usb_request_timeout(usb_pipe_t* pipe, void* buf, int size, int timeout/*ms*/)
{
	usb_req_t *req;

	req = _usb_request(pipe, buf, size, NULL, NULL);
	if(req) {
		int rc = usb_wait(req, timeout);
		if(rc != USB_ERR_TIMEOUT) usb_free_request(req);
		return (rc == USB_OK) ? req->xfer_len : rc;
	}

	return USB_ERR_REQUEST;
}

int usb_free_request(usb_req_t *req)
{
	if(req->dma_buf) {
	#ifdef USE_USB_CACHED_BUFFER
		free(req->dma_buf);
	#else
		dma_free(req->dma_buf);
	#endif
	}
	free(req);

	return 0;
}

int usb_wait(usb_req_t* req, int timeout)
{
	timeout_id_t	t;
	usb_pipe_t		*pipe = req->pipe;
	usb_hcd_t		*hcd = HCD_FROM_PIPE(pipe);
	int	rc = USB_OK;

	set_timeout(&t, timeout);
	while(req->status == USB_REQ_STATUS_RUN) {
		if(is_timeout(&t)) {
			if(hcd->func->cancel_transfer) {
				hcd->func->cancel_transfer(hcd, req);
			}
			USB_INFO("usb_wait:timeout !!!\n");
			return USB_ERR_TIMEOUT;
		}
		hcd->func->interrupt(hcd);
	}

	if(req->status == USB_REQ_STATUS_DONE) {
		if((pipe->flag&USB_PIPE_DIR_IN) && req->xfer_len > 0) {
		#ifdef USE_USB_CACHED_BUFFER
			int asize = (req->xfer_len + D_CACHE_LINE_SIZE - 1) & ~(D_CACHE_LINE_SIZE-1);
			dcache_inv_range((unsigned long)req->dma_buf, asize);
		#endif

			if(req->xfer_len > req->size) usb_printf("XXXXXXXXXX over max size \n");
			memcpy(req->buf, req->dma_buf, req->xfer_len);
		}
	} else {
		USB_INFO("usb_wait: status=0x%08x\n", req->status);
		rc = (req->status == USB_REQ_STATUS_STALL) ? USB_ERR_STALL : USB_ERR_INTERNAL;
	}

	return rc;
}

int usb_device_request_timeout(usb_device_t* dev, u8 reqtype, u8 req,
								u16 value, u16 index, void* buf, u16 size, int timeout)
{
	usb_device_request_t *dev_req;
	usb_req_t* usb_req;
	usb_pipe_t* pipe;
	int rc;

	USB_REQ_DEBUG("usb_device_request. req=0x%x, reqtype=0x%x, value=0x%x, index=%d\n",
				req, reqtype, value, index);

	dev_req = dev->dev_req;

	dev_req->bmRequestType	= reqtype;
	dev_req->bRequest		= req;
	dev_req->wValue			= HTOUS(value);
	dev_req->wIndex			= HTOUS(index);
	dev_req->wLength		= HTOUS(size);

	pipe = (reqtype&USB_REQTYPE_DIR_IN) ? dev->pipes[0] : dev->pipes[1];

	usb_req = _usb_request(pipe, buf, size, dev_req, NULL);
	if(usb_req == NULL) {
		dma_free(dev_req);
		return USB_ERR_REQUEST;
	}

	rc = usb_wait(usb_req, timeout);

	if(rc != USB_ERR_TIMEOUT) usb_free_request(usb_req);

	if(rc < 0) {
		USB_DEBUG("usb_device_request. rc:%d\n", rc);
		return rc;
	}

	return usb_req->xfer_len;
}


int usb_device_request(usb_device_t* dev, u8 reqtype, u8 req,
						u16 value, u16 index, void* buf, u16 size)
{
	return usb_device_request_timeout(dev, reqtype, req, value, index, buf, size, 100);
}


#ifdef USB_DUMP_DESCRIPTOR
void usb_dump_descriptor(usb_device_t* dev, void *desc, int len)
{
	u8 *ptr, *endptr;
	const char *eptattribs[4] = {"Control","Isoc","Bulk","Interrupt"};
	usb_device_descriptor_t *devdscr;
	usb_config_desc_t *cfgdscr;
	usb_interface_desc_t *ifdscr;
	usb_endpoint_desc_t *epdscr;
	usb_ss_ep_comp_desc_t *sscompdscr;
	usb_hub_desc_t *hub_desc;

	ptr = (u8*)desc;
	endptr = ptr + len;

    while (ptr < endptr) {
		u8 len	= ptr[0];
		u8 type	= ptr[1];

		if(len == 0) {
			usb_printf("^r^Invalid descriptor !!!\n");
			return;
		}

		switch (type) {
			case USB_DESCRIPTOR_TYPE_DEVICE:
				devdscr = (usb_device_descriptor_t *) ptr;
				usb_printf("---------------------------------------------------\n");
				usb_printf("DEVICE DESCRIPTOR\n");
				usb_printf("bLength         = %d\n",devdscr->bLength);
				usb_printf("bDescriptorType = %d\n",devdscr->bDescriptorType);
				usb_printf("bcdUSB          = %04X\n", devdscr->bcdUSB);
				usb_printf("bDeviceClass    = %d\n",devdscr->bDeviceClass);
				usb_printf("bDeviceSubClass = %d\n",devdscr->bDeviceSubClass);
				usb_printf("bDeviceProtocol = %d\n",devdscr->bDeviceProtocol);
				usb_printf("bMaxPktSize0    = %d\n",devdscr->bMaxPacketSize0);
				if (endptr-ptr <= 8) break;
				usb_printf("idVendor        = %04X (%d)\n", devdscr->idVendor, devdscr->idVendor);
				usb_printf("idProduct       = %04X (%d)\n", devdscr->idProduct, devdscr->idProduct);
				usb_printf("bcdDevice       = %04X\n", devdscr->bcdDevice);
#if 1
				usb_printf("iManufacturer   = %d (%s)\n",
						devdscr->iManufacturer,
						usb_get_string(dev,devdscr->iManufacturer));
				usb_printf("iProduct        = %d (%s)\n",
						devdscr->iProduct,
						usb_get_string(dev,devdscr->iProduct));
				usb_printf("iSerialNumber   = %d (%s)\n",
						devdscr->iSerialNumber,
						usb_get_string(dev,devdscr->iSerialNumber));
						usb_printf("bNumConfigs     = %d\n",devdscr->bNumConfigurations);
#endif
				break;
			case USB_DESCRIPTOR_TYPE_CONFIGURATION:
				cfgdscr = (usb_config_desc_t *) ptr;
				usb_printf("---------------------------------------------------\n");
				usb_printf("CONFIG DESCRIPTOR\n");
				usb_printf("bLength         = %d\n",cfgdscr->bLength);
				usb_printf("bDescriptorType = %d\n",cfgdscr->bDescriptorType);
				usb_printf("wTotalLength    = %d\n",cfgdscr->wTotalLength);
				usb_printf("bNumInterfaces  = %d\n",cfgdscr->bNumInterface);
				usb_printf("bConfigValue    = %d\n",cfgdscr->bConfigurationValue);
				usb_printf("iConfiguration  = %d (%s)\n",
				       cfgdscr->iConfiguration,
				       usb_get_string(dev,cfgdscr->iConfiguration));
				usb_printf("bmAttributes    = %02X\n",cfgdscr->bmAttributes);
				usb_printf("MaxPower        = %d (%dma)\n",cfgdscr->bMaxPower,cfgdscr->bMaxPower*2);
				break;
			case USB_DESCRIPTOR_TYPE_INTERFACE:
				ifdscr = (usb_interface_desc_t *) ptr;

				usb_printf("---------------------------------------------------\n");
				usb_printf("INTERFACE DESCRIPTOR\n");
				usb_printf("bLength         = %d\n",ifdscr->bLength);
				usb_printf("bDescriptorType = %d\n",ifdscr->bDescriptorType);
				usb_printf("bInterfaceNum   = %d\n",ifdscr->bInterfaceNumber);
				usb_printf("bAlternateSet   = %d\n",ifdscr->bAlternateSetting);
				usb_printf("bNumEndpoints   = %d\n",ifdscr->bNumEndpoints);
				usb_printf("bInterfaceClass = %d\n",ifdscr->bInterfaceClass);
				usb_printf("bInterSubClass  = %d\n",ifdscr->bInterfaceSubClass);
				usb_printf("bInterfaceProto = %d\n",ifdscr->bInterfaceProtocol);
				usb_printf("iInterface      = %d (%s)\n",
				       ifdscr->iInterface,
				       usb_get_string(dev,ifdscr->iInterface));
				break;
			case USB_DESCRIPTOR_TYPE_ENDPOINT:
				epdscr = (usb_endpoint_desc_t *) ptr;
				usb_printf("---------------------------------------------------\n");
				usb_printf("ENDPOINT DESCRIPTOR\n");
				usb_printf("bLength         = %d\n",epdscr->bLength);
				usb_printf("bDescriptorType = %d\n",epdscr->bDescriptorType);
				usb_printf("bEndpointAddr   = %02X (%d,%s)\n",
				       epdscr->bEndpointAddress,
				       epdscr->bEndpointAddress & 0x0F,
				       (epdscr->bEndpointAddress & USB_EP_ADDR_DIR_IN) ? "IN" : "OUT"
				       );
				usb_printf("bmAttrbutes     = %02X (%s)\n",
				       epdscr->bmAttributes,
				       eptattribs[epdscr->bmAttributes&3]);
				usb_printf("wMaxPacketSize  = %d\n",epdscr->wMaxPacketSize);
				usb_printf("bInterval       = %d\n",epdscr->bInterval);
				break;
			case USB_DESCRIPTOR_TYPE_SS_EP_COMPANION:
				sscompdscr = (usb_ss_ep_comp_desc_t*)ptr;
				usb_printf("---------------------------------------------------\n");
				usb_printf("SuperSpeed Endpoint Companion Descriptor\n");
				usb_printf("bLength         = %d\n",sscompdscr->bLength);
				usb_printf("bDescriptorType = %d\n",sscompdscr->bDescriptorType);
				usb_printf("bMaxBurst       = %d\n",sscompdscr->bMaxBurst);
				usb_printf("bmAttributes    = 0x%02x\n",sscompdscr->bmAttributes);
				usb_printf("wBytesPerInterval= %d\n",sscompdscr->wBytesPerInterval);
				break;
			case USB_DESCRIPTOR_TYPE_HUB:
				hub_desc = (usb_hub_desc_t*)ptr;
				usb_printf("HUB DESCRIPTOR\n");
				usb_printf("bLength				= %d\n",hub_desc->bDescLength);
				usb_printf("bNbrPorts			= %d\n",hub_desc->bNbrPorts);
				usb_printf("wHubCharacteristics	= 0x%04x\n",hub_desc->wHubCharacteristics);
				usb_printf("bPwrOn2PwrGood		= %d\n",hub_desc->bPwrOn2PwrGood);
				usb_printf("bHubContrCurrent	= %d\n",hub_desc->bHubContrCurrent);
				break;
			default:
				usb_printf("---------------------------------------------------\n");
				usb_printf("UNKNOWN DESCRIPTOR\n");
				usb_printf("bLength         = %d\n", len);
				usb_printf("bDescriptorType = %d\n", type);
				usb_printf("Data Bytes      = \n");
				hex_dump(0, ptr, len, 1);
				usb_printf("\n");
				break;
		}

		ptr += len;
	}
}
#else
void usb_dump_descriptor(usb_device_t* dev, void *desc, int len){}
#endif


static inline int usb_get_descriptor(usb_device_t* dev, u8 reqtype, u8 desc_type, int idx, void* buf, int size)
{
	return usb_device_request(dev, reqtype, USB_REQUEST_GET_DESCRIPTOR, desc_type << 8 | idx, 0, buf, size);
}

int usb_get_device_descriptor(usb_device_t* dev, void* desc, int size)
{
	return usb_get_descriptor(dev, USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE,
						USB_DESCRIPTOR_TYPE_DEVICE, 0, desc, size);
}

int usb_get_config_descriptor(usb_device_t* dev, usb_config_desc_t* desc, int no, int size)
{
	return usb_get_descriptor(dev, USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE,
						USB_DESCRIPTOR_TYPE_CONFIGURATION, no, desc, size);
}

int usb_get_hub_descriptor(usb_device_t* dev, usb_hub_desc_t* desc, int size)
{
	return usb_get_descriptor(dev, USB_REQTYPE_DIR_IN | USB_REQTYPE_HUB,
						USB_DESCRIPTOR_TYPE_HUB, 0, desc, size);
}

int usb_get_string_descriptor(usb_device_t* dev, int idx, int lagnid, void* desc, int size)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE,
						USB_REQUEST_GET_DESCRIPTOR, USB_DESCRIPTOR_TYPE_STRING << 8 | idx, lagnid, desc, size);
}


static char* usb_get_string(usb_device_t* dev, int idx)
{
	static char string[128];
	char buf[256];
	int rc, len;
	usb_string_desc_t *string_desc;

	if(idx == 0) goto empty;

	string_desc = (usb_string_desc_t*)buf;
	if(dev->lang_id == -1) {
		rc = usb_get_string_descriptor(dev, 0, 0, string_desc, 4);
		if(rc < 2 || string_desc->bLength < 4) goto empty;

		/* we use the first language id.
		 * if possible and have a lot of time, will implement the language priroity  */
		dev->lang_id = (string_desc->bString[1] << 8) | string_desc->bString[0];
		USB_DEBUG("Lang ID=0x%x\n", dev->lang_id);
	}

	rc = usb_get_string_descriptor(dev, idx, dev->lang_id, string_desc, 2);
	if(rc < 2) goto empty;

	USB_DEBUG("string_desc->bLength : %d\n", string_desc->bLength);
	len = (string_desc->bLength > 255 ) ? 255 : string_desc->bLength;

	rc = usb_get_string_descriptor(dev, idx, dev->lang_id, string_desc, len);
	if(rc < 2) goto empty;

	len = rc - 2;
	/* convert unicode to ASCII character, but we do not consider any errors */
	for(idx=0; idx < len; idx += 2) {
		string[idx/2] = string_desc->bString[idx];
	}
	string[idx/2] = '\0';
	return string;

empty:
	string[0] = '\0';
	return string;
}

int usb_set_address(usb_device_t* dev, int addr)
{
	int res;
	usb_hcd_t *hcd = dev->usbd->hcd;

	if(addr != ROOTHUB_ADDR && hcd->func->set_address) {	/* if not roothub & hcd has a set_address function */
		res  = hcd->func->set_address(hcd, dev, addr);
	} else {
		res = usb_device_request(dev,
						USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE,
						USB_REQUEST_SET_ADDRESS, addr, 0, NULL, 0);
	}

	if(res == 0) {
		dev->address = addr;
		dev->usbd->devices[addr - 1] = dev;
	}

	return res;
}

int usb_set_config(usb_device_t* dev, int config)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE,
						USB_REQUEST_SET_CONFIGURATION, config, 0, NULL, 0);
}



/* usb hub functions */
int usb_hub_get_hub_status(usb_device_t* dev, usb_hub_status_t* status)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_IN | USB_REQTYPE_HUB,
						USB_HUB_REQ_GET_STATUS, 0, 0, status, sizeof(usb_hub_status_t));
}

int usb_hub_get_port_status(usb_device_t* dev, usb_port_status_t* status, int port)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_IN | USB_REQTYPE_PORT,
						USB_HUB_REQ_GET_STATUS, 0, port, status, sizeof(usb_port_status_t));
}

int usb_hub_clear_port_feature(usb_device_t* dev, int port, int feature)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_OUT | USB_REQTYPE_PORT,
						USB_HUB_REQ_CLEAR_FEATURE, feature, port, NULL, 0);
}

int usb_hub_set_port_feature(usb_device_t* dev, int port, int feature)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_OUT | USB_REQTYPE_PORT,
						USB_HUB_REQ_SET_FEATURE, feature, port, NULL, 0);
}

int usb_hub_reset_port(usb_device_t* dev, int port, usb_port_status_t *port_status)
{
	int retry = 10;

	usb_hub_set_port_feature(dev, port, USB_PORT_FEATURE_RESET);
	while(--retry) {
		msleep(50);

		usb_hub_get_port_status(dev, port_status, port);
		if(!(port_status->wPortStatus&USB_PORT_STATUS_RESET) &&
			(port_status->wPortStatus&USB_PORT_STATUS_ENABLED))
			break;

		USB_INFO("PORT STATUS : 0x%08x, CHANGE : 0x%08x\n",
					port_status->wPortStatus, port_status->wPortChange);

		/* if device disconnected */
		if(!(port_status->wPortStatus&USB_PORT_STATUS_CONNECT)) {
			USB_DEBUG("Port[%d] disconnected\n", port);
			return -1;
		}
	}

	if(retry == 0) {
		USB_ERROR("Can't reset the port[%d]\n", port);
		return -1;
	}
	msleep(100);

	usb_hub_clear_port_feature(dev, port, USB_PORT_FEATURE_C_RESET);

	return 0;
}


usb_pipe_t* usb_create_pipe(usb_device_t* dev, int epaddr, int mps, u32 flag)
{
	usb_pipe_t* pipe;
	int idx = USB_PIPE_IDX(epaddr, flag);

	if(dev->pipes[idx] != NULL)
	{
		USB_ERROR("usb_create_pipe:already opend pipe !\n");
		return NULL;
	}

	pipe = (usb_pipe_t*)malloc(sizeof(usb_pipe_t));

	pipe->dev		= dev;
	pipe->num		= epaddr;
	pipe->mps		= mps;
	pipe->flag		= flag;
	pipe->toggle	= 0;

	dev->pipes[idx]	= pipe;

	return pipe;
}

usb_pipe_t* usb_open_pipe(usb_device_t* dev, usb_endpoint_desc_t* ep_desc)
{
	u32 pipe_flag = 0;
	int mps;
	int epaddr;

	pipe_flag |= (IS_USB_EP_IN(ep_desc->bEndpointAddress) ?
					USB_PIPE_DIR_IN : USB_PIPE_DIR_OUT);

    switch (ep_desc->bmAttributes & USB_EP_ATTR) {
		case USB_EP_ATTR_CONTROL:
		    pipe_flag |= USB_PIPE_TYPE_CONTROL;
		    break;
		case USB_EP_ATTR_ISOCHRONOUS:
		    pipe_flag |= USB_PIPE_TYPE_ISOCHRONOUS;
		    break;
		case USB_EP_ATTR_BULK:
		    pipe_flag |= USB_PIPE_TYPE_BULK;
		    break;
		case USB_EP_ATTR_INTERRUPT:
		    pipe_flag |= USB_PIPE_TYPE_INTERRUPT;
		    break;
	}

	mps = UTOHS(ep_desc->wMaxPacketSize);
	epaddr = (ep_desc->bEndpointAddress & 0x7F);

	return usb_create_pipe(dev, epaddr, mps, pipe_flag);
}

void usb_remove_pipe(usb_device_t* dev, usb_pipe_t* pipe)
{
	int idx;

	for(idx=0; idx<USB_MAX_PIPE; idx++) {
		if(dev->pipes[idx] == pipe) {
			dev->pipes[idx] = NULL;
			free(pipe);
			return;
		}
	}
}

static usb_device_t* usb_create_device(usb_usbd_t* usbd, int speed)
{
	usb_device_t* dev;
	u32 pipe_flag;
	int mps;

	switch(speed) {
		case USB_SPEED_SUPER:	mps = 512; break;
		case USB_SPEED_HIGH:
		case USB_SPEED_FULL:	mps = 64; break;
		case USB_SPEED_LOW:		mps = 8; break;
		default: return NULL;
	}

	dev = (usb_device_t*)calloc(sizeof(usb_device_t), 1);

	dev->usbd = usbd;
	dev->lang_id = -1;

	dev->dev_req = (usb_device_request_t*)dma_malloc(sizeof(usb_device_request_t));
	dev->speed = speed;

	pipe_flag = USB_PIPE_TYPE_CONTROL | USB_PIPE_DIR_IN | USB_PIPE_SPEED_FULL;
	usb_create_pipe(dev, 0, mps, pipe_flag);

	pipe_flag = USB_PIPE_TYPE_CONTROL | USB_PIPE_DIR_OUT | USB_PIPE_SPEED_FULL;
	usb_create_pipe(dev, 0, mps, pipe_flag);

	return dev;
}


int usb_get_address(usb_usbd_t* usbd)
{
	int idx;
	for(idx=0; idx<USB_MAX_DEVICE; idx++) {
		if(usbd->devices[idx] == NULL)
			break;
	}

	if(idx == USB_MAX_DEVICE) {
		USB_ERROR("Over max devices!\n");
		return -1;
	}

	return (idx+1);
}


static void usb_parse_config_descriptor(usb_device_t* dev, usb_config_desc_t* cfg_desc, int len)
{
	u8 *ptr, *endptr;
	u8 desc_type, desc_len;

	usb_dump_descriptor(dev, cfg_desc, len);

	ptr = (u8*)cfg_desc;
	endptr = ptr + len;

	dev->num_if_desc = 0;
	dev->num_ep_desc = 0;

	dev->cfg_desc = cfg_desc;
	while(ptr < endptr)	{
		desc_len = ptr[0];
		desc_type = ptr[1];
		switch (desc_type) {
			case USB_DESCRIPTOR_TYPE_INTERFACE:
				if(dev->num_if_desc < USB_MAX_IF_DESC) {
					dev->if_desc[dev->num_if_desc++] = (usb_interface_desc_t*)ptr;
				}
				break;
			case USB_DESCRIPTOR_TYPE_ENDPOINT:
				if(dev->num_ep_desc < USB_MAX_EP_DESC) {
					dev->ep_desc[dev->num_ep_desc++] = (usb_endpoint_desc_t*)ptr;
				}
				break;
		}
		ptr += desc_len;
	}
	USB_DEBUG("Interface Descriptor : %d\n", dev->num_if_desc);
	USB_DEBUG("EndPoint Descriptor : %d\n", dev->num_ep_desc);
}

static int usb_remove_device(usb_device_t* dev)
{
	usb_hcd_t *hcd = dev->usbd->hcd;

	/* I will implement this function some day...
	 * TODO: manage the parent/child list, ohci td/ed list, etc...
	 * But now, just free allocated memory
	 */

	int idx;

	if(hcd->func->device_deinit) {
		hcd->func->device_deinit(hcd, dev);
	}

	if(dev->cfg_desc) free(dev->cfg_desc);

	for(idx=0; idx<USB_MAX_PIPE; idx++) {
		if(dev->pipes[idx]) free(dev->pipes[idx]);
	}

	for(idx=0; idx<USB_MAX_DEVICE; idx++) {
		if(dev->usbd->devices[idx] == dev) {
			dev->usbd->devices[idx] = NULL;
			break;
		}
	}
	free(dev);
	return 0;
}

static int usb_attach_device(usb_device_t* newdev)
{
	u8 bDeviceClass;
	u16 idVendor, idProduct;
	int attached = 0;
	usb_device_descriptor_t* dev_desc = &newdev->dev_desc;
	const char *device_name = NULL;

	bDeviceClass = dev_desc->bDeviceClass;
	if(bDeviceClass == USB_CLASS_USE_INTERFACE) {
		if(newdev->if_desc[0] != NULL) bDeviceClass = newdev->if_desc[0]->bInterfaceClass;
	}
	idVendor = dev_desc->idVendor;
	idProduct = dev_desc->idProduct;

	USB_INFO("usb_attach_device. bDeviceClass:0x%x, idVendor:0x%x, idProduct:0x%x\n",
				bDeviceClass, idVendor, idProduct);

	/* USB HUB */
	if(bDeviceClass == USB_CLASS_HUB) {
		USB_INFO("USB HUB Attatched !\n");
		usb_hub_attatch(newdev);
		return 0;
	}

	printf("\tManufacturer : %s\n", usb_get_string(newdev, dev_desc->iManufacturer));
	printf("\tProduct      : %s\n", usb_get_string(newdev, dev_desc->iProduct));

// TODO: Make the probe function in each driver
	if(0){}
#if (USE_USB_SERIAL_CONSOLE == 1)
	else if(bDeviceClass == USB_CLASS_VENDOR_SPECIFIC &&
			( (idVendor == 0x067B && idProduct == 0x2303) ||	/* PL2303 USB-TO-SERIAL Device */
			  (idVendor == 0x0557 && idProduct == 0x2008))		/* ATEN PL2303 */
			) {
		if(usb_serial_attach(newdev) == 0) attached = 2;
		else {
			attached = 1;
			device_name = "PL2303";
		}
	}
#endif
	else
	{
		if(usb_inited >= USB_INIT_LEVEL_ALL)
		{
			if(0){}
#if (USE_USB_STORAGE == 1)
			else if(bDeviceClass == USB_CLASS_MASS_STORAGE) {
				if(usb_mass_attach(newdev) == 0) attached = 2;
				else {
					attached = 1;
					device_name = "MASS Storage";
				}
			}
#endif
#if (USE_USB_ETHER == 1)
			else if(!usb_ether_probe(bDeviceClass, idVendor, idProduct)) {
				if(usb_ether_attach(newdev) == 0) attached = 2;
				else {
					attached = 1;
					device_name = "USB-Ethernet";
				}
			}
#endif
		}
	}

	if(attached == 0) {
		printf("Not supported usb device - DeviceClass=0x%x, Vendor:0x%x\n", bDeviceClass, idVendor);
	} else if(attached == 1) {
		printf("Detected %s device but fail to register !!!\n", device_name);
	}

	return (attached == 2) ? 0 : -1;
}

static int usb_connect_device(usb_device_t* newdev)
{
	u8	usb_buf[64];

	usb_device_descriptor_t* dev_desc;
	usb_config_desc_t* cfg_desc;
	usb_usbd_t *usbd = newdev->usbd;
	usb_hcd_t *hcd = usbd->hcd;
	int addr, len;
	int rc;

	if(hcd->func->device_init) {
		if(hcd->func->device_init(hcd, newdev) < 0) {
			USB_ERROR("Device init fail\n");
			return -1;
		}
	}

	dev_desc = (usb_device_descriptor_t*)&newdev->dev_desc;
	if(hcd->rev != USB_REV_3_0) {
		if((rc = usb_get_device_descriptor(newdev, dev_desc, sizeof(usb_device_descriptor_t))) < 0) {
			USB_DEBUG("Can't get device descriptor\n");
			return -1;
		}
		usb_dump_descriptor(newdev, dev_desc, rc);

		newdev->pipes[0]->mps = dev_desc->bMaxPacketSize0;
		newdev->pipes[1]->mps = dev_desc->bMaxPacketSize0;
	}

	addr = usb_get_address(usbd);
	rc = usb_set_address(newdev, addr);
	if(rc < 0) {
		USB_DEBUG("Can't set the address\n");
		return -1;
	}

	len = sizeof(usb_device_descriptor_t);
	rc = usb_get_device_descriptor(newdev, dev_desc, len);
	if(rc < len) return -1;
	usb_dump_descriptor(newdev, dev_desc, rc);

	cfg_desc = (usb_config_desc_t*)usb_buf;
	rc = usb_get_config_descriptor(newdev, cfg_desc, 0,  sizeof(usb_config_desc_t));
	if(rc < 0) return -1;

	len = cfg_desc->wTotalLength;
	cfg_desc = (usb_config_desc_t*)malloc(len);
	rc = usb_get_config_descriptor(newdev, cfg_desc, 0, len);
	if(rc < 0) {
		free(cfg_desc);
		return -1;
	}

	/* Parse informations(interface, endpoint) in the configuration descriptor */
	usb_parse_config_descriptor(newdev, cfg_desc, rc);

	if(hcd->func->device_config) {
		if(hcd->func->device_config(hcd, newdev) < 0) {
			USB_DEBUG("Device Configuration fail\n");
			return -1;
		}
	}

	if(usb_set_config(newdev, cfg_desc->bConfigurationValue) < 0)
		return -1;

	return usb_attach_device(newdev);
}

static const char* usb_get_speed_string(int speed)
{
	const char *str_speed[] = {"unknown", "low", "full", "high", "super"};
	if(speed < USB_SPEED_LOW || speed > USB_SPEED_SUPER) speed = USB_SPEED_UNKNOWN;
	return str_speed[speed];
}

int usb_scan_ports(usb_device_t* hub)
{
	usb_port_status_t port_status;
	int port;
	usb_hub_info_t *hub_info;
	usb_device_t *newdev;
	u16 status, change;
	int speed = USB_SPEED_UNKNOWN;
	hub_info = (usb_hub_info_t*)hub->priv;

	USB_SCAN_INFO("usb_scan_ports !!!\n");

	//if(hcd->rev == USB_REV_3_0) msleep(3000);

	for(port=1; port<=hub_info->nports; port++) {

#ifdef USB_SCAN_HUB_ONCE
		if((hub_info->status[port-1]&USB_HUB_STATUS_CONNECTED))
			continue;
#endif
		if(usb_hub_get_port_status(hub, &port_status, port) < 0) {
			USB_ERROR("can't get the port status\n");
			continue;
		}
		status = port_status.wPortStatus;
		change = port_status.wPortChange;

		USB_SCAN_INFO("Port %d Status:0x%04x, Changed:0x%04x\n", port, status, change);
		if(change&USB_PORT_CHANGE_CONNECT) {
			USB_INFO("Usb Port[%d] Connection chagned !!!\n", port);

			usb_hub_clear_port_feature(hub, port, USB_PORT_FEATURE_C_CONNECTION);

			if(!(status&USB_PORT_STATUS_CONNECT)) {
				USB_INFO("Disconnected !!!\n");
				continue;
			}
			hub_info->status[port-1] |= USB_HUB_STATUS_CONNECTED;

//			msleep(200);	// imsi

			USB_INFO("hub %d port %d\n", hub->address, port);

			if(usb_hub_reset_port(hub, port, &port_status) < 0)
				continue;

			if(usb_hub_get_port_status(hub, &port_status, port) < 0) {
				USB_ERROR("can't get the port status\n");
				continue;
			}
			status = port_status.wPortStatus;
			change = port_status.wPortChange;
			USB_INFO("after reset port[%d]: Status:0x%04x, Changed:0x%04x\n", port, status, change);

			if(hub->speed == USB_SPEED_SUPER) {
				switch(status&USB_PORT_STATUS_3_SPEED) {
					case USB_PORT_STATUS_3_SPEED_FULL:	speed = USB_SPEED_FULL; break;
					case USB_PORT_STATUS_3_SPEED_LOW:	speed = USB_SPEED_LOW; break;
					case USB_PORT_STATUS_3_SPEED_HIGH:	speed = USB_SPEED_HIGH; break;
					case USB_PORT_STATUS_3_SPEED_SUPER:	speed = USB_SPEED_SUPER; break;
				}
			} else {
				speed = (status&USB_PORT_STATUS_HIGHSPEED) ? USB_SPEED_HIGH :
							(status&USB_PORT_STATUS_LOWSPEED) ? USB_SPEED_LOW : USB_SPEED_FULL;
			}

			if(speed == USB_SPEED_UNKNOWN) {
				printf("Unknown speed\n");
				continue;
			}

			printf("%s : New %s speed device connected\n",
					hub->usbd->name, usb_get_speed_string(speed));

//			msleep(200);	// imsi

			newdev			= usb_create_device(hub->usbd, speed);
			newdev->parent	= hub;
			newdev->port	= port;
			hub_info->devices[port-1] = newdev;

			if(usb_connect_device(newdev) < 0) {
				printf("Can't attach the device\n");
				usb_remove_device(newdev);
			}
		} else if(change&USB_PORT_CHANGE_OCURRENT) {
			printf("Port[%d] Over Current\n", port);
		}
	}

	return 0;
}


static int usb_hub_port_power(usb_device_t* hub)
{
	usb_hub_info_t *hub_info;
	usb_port_status_t port_status;
	int port;
	int max_poweron_delay = 100;	// it needs some delays even if already powered on

	hub_info = (usb_hub_info_t*)hub->priv;
	/* Enable port power if not yet enabled */
	for(port=1; port<=hub_info->nports; port++) {
		if(usb_hub_get_port_status(hub, &port_status, port) < 0) {
			USB_ERROR("can't get the port status\n");
			continue;
		}

		if(!(port_status.wPortStatus&USB_PORT_STATUS_POWER)) {
			USB_INFO("Port[%d] power disabled, Enabling Port Power\n", port);
			usb_hub_set_port_feature(hub, port, USB_PORT_FEATURE_POWER);
			max_poweron_delay = max(max_poweron_delay, hub_info->poweron_delay * 2);
		}
	}
	USB_DEBUG("hub_port_poweron delay. %d\n", max_poweron_delay);
	mdelay(max_poweron_delay);

	return 0;
}


static int usb_register_hub(usb_device_t *hub)
{
	usb_hub_port_power(hub);
	usb_scan_ports(hub);

#ifdef USB_SCAN_HUB
	int i;
	for(i=0; i<USB_MAX_HUBS; i++) {
		if(usb_hub[i] == NULL) {
			usb_hub[i] = hub;
			break;
		}
	}

	if(i == USB_MAX_HUBS) {
		USB_ERROR("Can't register usb hub\n");
		return -1;
	}
#endif
	return 0;
}

#if 0
static int usb_unregister_hub(usb_device_t *hub)
{
	int i;
	for(i=0; i<USB_MAX_HUBS; i++) {
		if(usb_hub[i] == hub) {
			usb_hub[i] = NULL;
			break;
		}
	}
	if(i == USB_MAX_HUBS) {
		USB_ERROR("Can't register usb hub\n");
		return -1;
	}
	return 0;
}
#endif

static int usb_hub_attatch(usb_device_t* hub)
{
	usb_hub_desc_t hub_desc;
	usb_hub_status_t hub_status;
	usb_hub_info_t* hub_info;
	usb_hcd_t *hcd = HCD_FROM_DEVICE(hub);

	usb_get_hub_descriptor(hub, &hub_desc, sizeof(usb_hub_desc_t));
	USB_INFO("%d ports detected\n", hub_desc.bNbrPorts);
	usb_dump_descriptor(hub, &hub_desc, sizeof(usb_hub_desc_t));

	usb_hub_get_hub_status(hub, &hub_status);
	USB_INFO("HUB Status : 0x%04x, 0x%04x\n", hub_status.wHubStatus, hub_status.wHubChange);

	hub_info = (usb_hub_info_t*)calloc(sizeof(usb_hub_info_t), 1);
	hub_info->nports = hub_desc.bNbrPorts;
	if(hub_info->nports > USB_MAX_HUB_PORT) hub_info->nports = USB_MAX_HUB_PORT;
	hub_info->poweron_delay = hub_desc.bPwrOn2PwrGood * 2;
	hub_info->tttt = USB_HUB_CHAR_GET_TTTT(hub_desc.wHubCharacteristics);
	hub->priv = hub_info;

	if(hcd->func->set_hub_device) {
		if(hcd->func->set_hub_device(hcd, hub) < 0)
			return -1;
	}
	usb_register_hub(hub);

	return 0;
}


int usb_roothub_init(usb_usbd_t* usbd)
{
	usb_device_t* rh_dev = NULL;
	usb_hub_info_t* hub_info;

	usb_config_desc_t config_desc;
	usb_config_desc_t* new_config_desc;
	int len;

	usb_hub_desc_t hub_desc;
	usb_hub_status_t hub_status;
	int speed;

	USB_DEBUG("\nusb_roothub_init.. start\n");

	switch(usbd->hcd->rev) {
		case USB_REV_1_1: speed = USB_SPEED_FULL; break;
		case USB_REV_2_0: speed = USB_SPEED_HIGH; break;
		case USB_REV_3_0: speed = USB_SPEED_SUPER; break;
		default: USB_ERROR("Not supported USB revision\n"); goto error;
	}
	rh_dev = usb_create_device(usbd, speed);

	usb_get_device_descriptor(rh_dev, &rh_dev->dev_desc, sizeof(usb_device_descriptor_t));

	if(usbd->devices[ROOTHUB_ADDR - 1] != NULL) {
		USB_ERROR("Root Hub already registered\n");
		goto error;
	}
	usb_set_address(rh_dev, ROOTHUB_ADDR);

	usb_get_config_descriptor(rh_dev, &config_desc, 0, sizeof(usb_config_desc_t));

	len = config_desc.wTotalLength;
	new_config_desc = (usb_config_desc_t*)malloc(len);
	usb_get_config_descriptor(rh_dev, new_config_desc, 0, len);

	rh_dev->cfg_desc = new_config_desc;

	if(usb_set_config(rh_dev, config_desc.bConfigurationValue) < 0)
		goto error;

	usb_get_hub_descriptor(rh_dev, &hub_desc, sizeof(usb_hub_desc_t));
	USB_INFO("%d ports detected\n", hub_desc.bNbrPorts);

	usb_hub_get_hub_status(rh_dev, &hub_status);
	USB_INFO("HUB Status : 0x%04x, 0x%04x\n", hub_status.wHubStatus, hub_status.wHubChange);

	hub_info = (usb_hub_info_t*)calloc(sizeof(usb_hub_info_t), 1);
	hub_info->nports = hub_desc.bNbrPorts;
	if(hub_info->nports > USB_MAX_HUB_PORT) hub_info->nports = USB_MAX_HUB_PORT;

	rh_dev->priv = hub_info;

	usbd->roothub = rh_dev;

	usb_register_hub(rh_dev);

	USB_DEBUG("usb_roothub_init... end\n");
	return 0;

error:
	usb_remove_device(rh_dev);
	return -1;
}



int usb_register_hcd(const char *name, usb_hcd_t* hcd)
{
	int i;
	usb_usbd_t* usbd = NULL;

	for(i=0; i<USB_MAX_CONTROLLERS; i++) {
		if(usb_driver[i].hcd == NULL) {
			usbd = &usb_driver[i];
			break;
		}
	}

	if(usbd == NULL) {
		USB_ERROR("Can't register usb hcd - %s\n", name);
		return -1;
	}

	if(hcd->func->start && hcd->func->start(hcd) < 0) {
		USB_ERROR("Can't start usb hcd - %s\n", name);
		return -1;
	}

	USB_INFO("usb hcd registered - %s\n", name);

	usbd->hcd = hcd;
	strcpy(usbd->name, name);

	usb_roothub_init(usbd);

	return 0;
}

void usb_poll(void)
{
	int i;
	usb_hcd_t *hcd;
	static int count;
	static int in_usb_poll = 0;

	if(!usb_inited) return;

	if(in_usb_poll) return;		/* To prevent the recursive call */
	count++;
	in_usb_poll = 1;
	for(i=0; i<USB_MAX_CONTROLLERS; i++) {
		if(usb_driver[i].hcd != NULL) {
			hcd = usb_driver[i].hcd;
			hcd->func->interrupt(hcd);
		}
	}

	in_usb_poll = 0;
}

static void usb_poll_timer(void* unused)
{
	usb_poll();
}

#ifdef USB_SCAN_HUB
static void usb_scan_timer(void *unused)
{
	int i;

	for(i=0; i<USB_MAX_HUBS; i++) {
		if(usb_hub[i] != NULL) {
			usb_scan_ports(usb_hub[i]);
		}
	}
}
#endif



int usb_init_level(int level)
{
	int old_level = usb_inited;
	if(level <= usb_inited) return 0;
	if(usb_inited == 0) arch_usb_start();
	usb_inited = level;

	printf("USB Initializing(%d)...\n", level);

#if USE_USB_XHCI
	if(old_level < XHCI_INIT_LEVEL && level >= XHCI_INIT_LEVEL)
		usb_xhci_init();
#endif
#if USE_USB_EHCI
	if(old_level < EHCI_INIT_LEVEL && level >= EHCI_INIT_LEVEL)
		usb_ehci_init();
#endif
#if USE_USB_OHCI
	if(old_level < OHCI_INIT_LEVEL && level >= OHCI_INIT_LEVEL)
		usb_ohci_init();
#endif

	/* start the usb poll timer */
	if(usb_timer_id == -1)
		usb_timer_id = add_timer(USB_POLL_TIME_INTERVAL, 0, usb_poll_timer, NULL);

#ifdef USB_SCAN_HUB
	if(usb_scan_timer_id == -1 && level >= USB_INIT_LEVEL_ALL)
		usb_scan_timer_id = add_timer(USB_SCAN_TIME_INTERVAL, 0, usb_scan_timer, NULL);
#endif

	return 0;
}

int usb_init(void)
{
#if USE_USB_BOOTING_TIME
	return usb_init_level(USB_INIT_LEVEL_ALL);
#else
#if USE_USB_SERIAL_CONSOLE
	return usb_init_level(USB_INIT_LEVEL_MIN);
#else
	return 0;
#endif
#endif
}

int usb_stop(void)
{
	int i;

	if(!usb_inited) return 0;

	if(usb_timer_id != -1) {
		del_timer(usb_timer_id);
		usb_timer_id = -1;
	}
#ifdef USB_SCAN_HUB
	if(usb_scan_timer_id != -1) {
		del_timer(usb_scan_timer_id);
		usb_scan_timer_id = -1;
	}
#endif

#if USE_USB_SERIAL_CONSOLE
	unresiter_usb_console();
#endif

	// Call this function before jumping to kernel
	// so we don't care about extra jobs like free mem..etc.
	for(i=0; i<USB_MAX_CONTROLLERS; i++)
	{
		if(usb_driver[i].hcd != NULL)
		{
			usb_hcd_t *hcd = usb_driver[i].hcd;
			hcd->func->stop(hcd);
			usb_driver[i].hcd = NULL;
		}
	}

	if(vbus_enable == 0)
		arch_usb_stop();

	usb_inited = 0;

	return 0;
}




#if (USE_USB_STORAGE == 1)
static int usb_mass_rw(struct usb_mass *usb_mass, int argc, char *argv[])
{
	int		write;
	ulong	addr;
	char	*endptr;
	u64		offset;
	u32		size;
	u32		start, elapsed, speed;
	int		rc;

	if (argc < 4)
		return -1;

	write = (!strcmp(argv[0], "write")) ? 1 : 0;

	addr = strtoul(argv[1], &endptr, 0);
	if(*endptr != '\0') return -1;

	offset = strtoull(argv[2], &endptr, 0);
	if(*endptr != '\0') return -1;

	size = strtoul(argv[3], &endptr, 0);
	if(*endptr != '\0') return -1;

	printf("usb %s: ", write ? "write" : "read");

	start = timer_msec();

	if(write) rc = usb_mass_write (usb_mass, offset, size, (void*)addr);
	else      rc = usb_mass_read  (usb_mass, offset, size, (void*)addr);

	elapsed = (u32)(timer_msec() - start);
	if(elapsed == 0) elapsed = 1;
	speed = (size/1024)*1000 / elapsed;

	printf(" %d bytes %s: %s. %ldms elapsed, %ldKbps/sec\n",
			size,  write ? "written" : "read", rc < 0 ? "ERROR" : "OK", elapsed, speed);

	return 0;
}

static int usb_mass_dump(struct usb_mass *usb_mass, int argc, char *argv[])
{
	char	*endptr;
	u64		offset;
	u32		size;
	uint8_t	*buf;

	if (argc < 3)
		return -1;

	offset = strtoull(argv[1], &endptr, 0);
	if(*endptr != '\0') return -1;

	size = strtoul(argv[2], &endptr, 0);
	if(*endptr != '\0') return -1;

	buf = (uint8_t*)DATA_BUF_BASE;
	if(usb_mass_read(usb_mass, offset, size, buf) < 0)
	{
		printf("read fail\n");
		return -1;
	}

	hex_dump(offset, buf, size, 1);
	return 0;
}

static int usb_mass_shell(int no)
{
	int 	argc;
	char	*argv[8];
	char	cmd[1024];
	int		len;
	struct usb_mass *usb_mass;

	usb_mass = usb_mass_open(no);
	if(usb_mass == NULL)
	{
		printf("Can't open usb:%d\n", no);
		return -1;
	}

	while(1)
	{
		printf("usb:%d> ", no);
		len = gets(cmd);
		puts("\n");
		if(len > 0)
		{
			argc = parse_cmd_args(cmd, argv, 8);
			if(argc > 0)
			{
				if(!strcmp("read", argv[0]) || !strcmp("write", argv[0]))
				{
					usb_mass_rw(usb_mass, argc, argv);
				}
				else if(!strcmp("dump", argv[0]))
				{
					usb_mass_dump(usb_mass, argc, argv);
				}
				else if(!strcmp("?", argv[0]))
				{
					printf("  dump offset size\n");
					printf("  read addr offset size\n");
					printf("  write addr offset size\n");
					printf("  exit\n");
				}
				else if(!strcmp("exit", argv[0]))
				{
					usb_mass_close(usb_mass);
					return 0;
				}
				else printf("Unknown command '%s'\n", argv[0]);
			}
		}
	}
	return -1;
}
#endif

static int cmd_usb(int argc, char* argv[])
{
	char *sub_cmd;

	if(argc < 2)
		goto usage;

	sub_cmd = argv[1];
	if(strcmp(sub_cmd, "init") == 0)
	{
		usb_init_level(USB_INIT_LEVEL_ALL);
	}
	else if(!strcmp(sub_cmd, "stop"))
	{
		usb_stop();
	}
	else if(!strcmp(sub_cmd, "vbus_enable"))
	{
		vbus_enable = 1;
	}
#if (USE_USB_STORAGE == 1)
	else if(!strcmp(sub_cmd, "mass"))
	{
		int		no = 0;
		char	*endptr;

		if(argc != 2 && argc != 3) goto usage;

		if(argc == 3) {
			no = strtol(argv[2], &endptr, 0);
			if(*endptr != '\0') goto usage;
		}

		usb_mass_shell(no);
	}
	else if(!strcmp(sub_cmd, "minfo"))
	{
		usb_mass_info();
	}
#endif
	else goto usage;


	return 0;

usage:
	command_error(argv[0]);
	return -1;
}

COMMAND(usb, cmd_usb, "usb test",
		"init - initialize usb driver\n"
#if (USE_USB_STORAGE == 1)
		"usb mass [num] - mass storage test\n"
		"usb minfo - display registerd mass storage information\n"
#endif
		"usb vbus_enable - vbus will not turned off\n"
		);
#endif

