/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#if (USE_USB_ETHER == 1)
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <malloc.h>
#include <usb.h>
#include <thread.h>
#include <ethernet.h>


/* It's not completed yet not working correctly, and just for testing */

//#define USE_USB_ETHER_INFO

#ifdef USE_USB_ETHER_INFO
#define USB_ETHER_INFO(fmt, args...)	usb_printf(fmt, ##args)
#else
#define USB_ETHER_INFO(fmt, args...)	do{}while(0)
#endif

#if 0
#define USB_ETHER_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define USB_ETHER_DEBUG(fmt, args...)	do{}while(0)
#endif

#if 1
#define USB_ETHER_ERROR(fmt, args...)	usb_printf("\x1b[31mUSB-ETHER:"fmt"\x1b[0m", ##args)
#else
#define USB_ETHER_ERROR(fmt, args...)	do{}while(0)
#endif



#define MAX_USB_ETHER_DEVICE	2

#define IN_MSG_BUF_SIZE			(2048 * 8)
#define OUT_MSG_BUF_SIZE		512
typedef struct
{
	u8			in[IN_MSG_BUF_SIZE];
	int			in_head, in_tail;

	u8			out[OUT_MSG_BUF_SIZE];
	int			out_pos;
} usb_ether_buffer_t;

typedef struct usb_ether usb_ether_t;

typedef struct usb_ether_if_func
{
	int	(*init)(usb_ether_t* usb_ether);
	int	(*open)(usb_ether_t* usb_ether);
	int	(*close)(usb_ether_t* usb_ether);
} usb_ether_if_func_t;

struct usb_ether
{
	usb_device_t*	dev;

	usb_pipe_t* 	in_pipe;
	int				in_mps;
	u8*				in_buf;

	usb_pipe_t* 	out_pipe;
	int 			out_mps;

	usb_ether_buffer_t*	buffer;

	int				input_size;

	usb_ether_if_func_t	*if_func;
	u8				mac[6];
};


static usb_ether_t* usb_ether_dev[MAX_USB_ETHER_DEVICE];


static int usb_ether_register_driver(struct usb_ether* usb_ether);


#define next_pos(i,max)		(((i) + (max) + 1) % (max))
static int usb_ether_rx_callback(usb_req_t* req)
{
	if(req->status == USB_REQ_STATUS_DONE)
	{
		int i;
		usb_ether_t *usb_ether = req->pipe->dev->priv;
		usb_ether_buffer_t* buffer = usb_ether->buffer;
		u8* input = (u8*)req->dma_buf;

		//USB_ETHER_INFO("USB RX[%d]\n", req->xfer_len);
#ifdef USE_USB_CACHED_BUFFER
		if(req->xfer_len > 0)
		{
			int asize = (req->xfer_len + D_CACHE_LINE_SIZE - 1) & ~(D_CACHE_LINE_SIZE-1);
			dcache_inv_range((unsigned long)req->dma_buf, asize);
		}
#endif

		for(i=0; i<req->xfer_len; i++)
		{
			if(next_pos(buffer->in_tail, IN_MSG_BUF_SIZE) == buffer->in_head)
			{
				USB_ETHER_ERROR("Buffer Overflow !!!. input size[%d]\n", req->xfer_len);
				// If Buffer is full !!!, Overwrite it
				buffer->in_head = next_pos(buffer->in_head, IN_MSG_BUF_SIZE);
			}
			buffer->in[buffer->in_tail] = input[i];
			buffer->in_tail = next_pos(buffer->in_tail, IN_MSG_BUF_SIZE);
		}
		usb_ether->input_size += req->xfer_len;
		usb_free_request(req);

		/* Restart !!! */
		usb_request(usb_ether->in_pipe, NULL, usb_ether->in_mps, usb_ether_rx_callback);
		return 0;
	}

	USB_ETHER_ERROR("usb_ether_rx_callback. error !!!\n");
	usb_free_request(req);

	return -1;
}


/* Realtek Functions */
#define RTEK_REG_ACCESS		0x05
#define RTEK_MAC_REG		0x0120
#define RTEK_CMD_REG		0x012E
#define RTEK_RXCFG_REG		0x0130
#define RTEK_RESET			0x10
#define RTEK_AUTOLOAD		0x01

static int usb_ether_rtl_get_reg(usb_device_t *dev, u16 reg, u8 *val, u16 len)
{
	return usb_device_request(dev, USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_VENDOR | USB_REQTYPE_REC_DEVICE,
	                        RTEK_REG_ACCESS, reg, 0, val, len );
}

static int usb_ether_rtl_set_reg( usb_device_t *dev, u16 reg, u16 val )
{
	return usb_device_request(dev, USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_VENDOR | USB_REQTYPE_REC_DEVICE,
	                        RTEK_REG_ACCESS, reg, 0, &val, 1 );
}

static int usb_ether_rtl_init(usb_ether_t* usb_ether)
{
	int i;
	uint8_t val;

	//Reset the adapter
	usb_ether_rtl_set_reg(usb_ether->dev, RTEK_CMD_REG, RTEK_RESET );
	for( i = 0; i < 10; ++i ) {
		usb_ether_rtl_get_reg(usb_ether->dev, RTEK_CMD_REG, &val, 1 );
		if( !(val & RTEK_RESET) )
			break;
		msleep(1);
	}

	//autoload the internal registers
	usb_ether_rtl_set_reg(usb_ether->dev, RTEK_CMD_REG, RTEK_AUTOLOAD );
	for( i = 0; i < 50; ++i ) {
		usb_ether_rtl_get_reg(usb_ether->dev, RTEK_CMD_REG, &val, 1 );
		if( !(val & RTEK_AUTOLOAD) )
			break;
		msleep(1);
	}

	//Read the adapter's MAC addr
	usb_ether_rtl_get_reg(usb_ether->dev, RTEK_MAC_REG, usb_ether->mac, 6);

	return 0;
}

static int usb_ether_rtl_open(usb_ether_t* usb_ether)
{
	//accept broadcast & own packets
	usb_ether_rtl_set_reg(usb_ether->dev, RTEK_RXCFG_REG, 0x0c );

	//Now enable adapter to receive and transmit packets
	usb_ether_rtl_set_reg(usb_ether->dev, RTEK_CMD_REG, 0x0c );

	return 0;
}

static int usb_ether_rtl_close(usb_ether_t* usb_ether)
{
	return 0;
}


static usb_ether_if_func_t if_func_rtl =
{
	.init = usb_ether_rtl_init,
	.open = usb_ether_rtl_open,
	.close = usb_ether_rtl_close,
};
/***** End of Realtek Functions ****/



static struct usb_ether_if_list
{
	u16 idVendor, idProduct;
	usb_ether_if_func_t *if_func;

} usb_ether_if_list[] =
{
	{0x0BDA, 0x8150, &if_func_rtl},
};

#define USB_ETHER_IF_COUNT	(sizeof(usb_ether_if_list)/sizeof(struct usb_ether_if_list))

int usb_ether_probe(u8 bDeviceClass, u16 idVendor, u16 idProduct)
{
	int i;
	if(bDeviceClass == USB_CLASS_COMMUNICATIONS ||
		bDeviceClass == USB_CLASS_VENDOR_SPECIFIC) {
		for(i=0; i<USB_ETHER_IF_COUNT; i++) {
			if(usb_ether_if_list[i].idVendor == idVendor &&
				usb_ether_if_list[i].idProduct == idProduct) {
				return 0;
			}
		}
	}
	return -1;
}

int usb_ether_attach(usb_device_t* dev)
{
	int i;
	u16 idVendor, idProduct;
	usb_endpoint_desc_t	*ep_desc;
	usb_ether_t *usb_ether = NULL;
	usb_ether_buffer_t *buffer = NULL;
	usb_ether_if_func_t *if_func = NULL;
	int idx = -1;

	for(i=0; i<MAX_USB_ETHER_DEVICE; i++) {
		if(usb_ether_dev[i] == NULL) {
			idx = i;
			break;
		}
	}

	if(idx == -1) {
		USB_ETHER_ERROR("Exceeded the maximum number of devices\n");
		return -1;
	}

	idVendor = dev->dev_desc.idVendor;
	idProduct = dev->dev_desc.idProduct;

	/* We have only one RTL8150 device */
	for(i=0; i<sizeof(usb_ether_if_list)/sizeof(struct usb_ether_if_list); i++) {
		if(usb_ether_if_list[i].idVendor == idVendor &&
			usb_ether_if_list[i].idProduct == idProduct) {
			if_func = usb_ether_if_list[i].if_func;
			break;
		}
	}

	if(if_func == NULL) {
		printf("Can't find matched ethernet interface \n");
		return -1;
	}

	usb_ether = (usb_ether_t*)calloc(sizeof(usb_ether_t), 1);
	usb_ether->if_func = if_func;

	USB_ETHER_DEBUG("usb_ether_attatch !!!\n");
	for(i=0; i<dev->num_ep_desc; i++) {
		ep_desc = dev->ep_desc[i];

		if(IS_USB_EP_BULK(ep_desc->bmAttributes)) {
			if(IS_USB_EP_IN(ep_desc->bEndpointAddress)) {
				if(usb_ether->in_pipe == NULL) {
					usb_ether->in_pipe = usb_open_pipe(dev, ep_desc);
					usb_ether->in_mps = UTOHS(ep_desc->wMaxPacketSize);
					usb_ether->in_buf = (u8*)malloc(usb_ether->in_mps);
				}
				USB_ETHER_DEBUG("INPUT EP\n");
		    } else {
				if(usb_ether->out_pipe == NULL) {
					usb_ether->out_pipe = usb_open_pipe(dev, ep_desc);
					usb_ether->out_mps = UTOHS(ep_desc->wMaxPacketSize);
				}
				USB_ETHER_DEBUG("OUTPUT EP\n");
		    }
		}
	#ifdef USE_USB_ETHER_INFO
		usb_dump_descriptor(dev, ep_desc, sizeof(usb_endpoint_desc_t));
	#endif
	}

	if(usb_ether->in_pipe == NULL || usb_ether->out_pipe == NULL) {
		USB_ETHER_ERROR("In or Out EP descriptor is missed !!!\n");
		goto error;
	}

	buffer = (usb_ether_buffer_t*)malloc(sizeof(usb_ether_buffer_t));
	buffer->in_head = buffer->in_tail = 0;
	buffer->out_pos = 0;
	usb_ether->buffer = buffer;
	usb_ether->dev = dev;

	dev->priv = usb_ether;

	if(if_func->init(usb_ether) < 0) goto error;

	usb_ether_dev[idx] = usb_ether;

	if(idx == 0) usb_ether_register_driver(usb_ether);

	printf("USB-to-Ethernet[%d] registered\n", idx);
	return 0;

error:
	if(usb_ether != NULL) free(usb_ether);
	if(buffer != NULL) free(buffer);

	return -1;
}

int usb_ether_open(struct usb_ether* usb_ether)
{
	usb_ether_if_func_t *if_func = usb_ether->if_func;

	if(if_func->open) {
		if_func->open(usb_ether);
	}

	/* Start USB Ethernet Rx !!! */
	usb_request(usb_ether->in_pipe, NULL, usb_ether->in_mps, usb_ether_rx_callback);

	return 0;
}

int usb_ether_tx_data(usb_ether_t* usb_ether, const void* data, int len)
{
	if(usb_ether == NULL) return -1;

	return usb_request_timeout(usb_ether->out_pipe, (void*)data, len, 100);
}

int	usb_ether_check_rx(struct usb_ether* usb_ether)
{
	usb_ether_buffer_t* buffer;

	if(usb_ether == NULL)
		return 0;

	buffer = usb_ether->buffer;
	if(buffer->in_head != buffer->in_tail)
		return 1;

	return 0;
}

int usb_ether_rx_data(struct usb_ether* usb_ether, u8* data, int len)
{
	usb_ether_buffer_t* buffer;
	int buf_size;
	int res = 0;

	if(usb_ether == NULL) return -1;

	buffer = usb_ether->buffer;
	if(buffer->in_head == buffer->in_tail)	/* empty buffer */
		return 0;

	buf_size = (buffer->in_tail + IN_MSG_BUF_SIZE - buffer->in_head) % IN_MSG_BUF_SIZE;
	if(len > buf_size) len = buf_size;

	res = len;
	if(buffer->in_head > buffer->in_tail) {	/* wrap around */
		int rsize = min(IN_MSG_BUF_SIZE - buffer->in_head, len);
		memcpy(data, &buffer->in[buffer->in_head], rsize);
		buffer->in_head += rsize;
		if(buffer->in_head == IN_MSG_BUF_SIZE) buffer->in_head = 0;

		if(rsize == len) return len;	// done;

		data += rsize;
		len -= rsize;
	}

	memcpy(data, &buffer->in[buffer->in_head], len);
	buffer->in_head += len;

	return res;
}


int	usb_ether_close(struct usb_ether* usb_ether)
{
	// TODO:
	return 0;
}



/***** Interface for Etherner Driver */
static struct usb_ether* usb_ether_drv;
static int usb_ether_drv_init(const uint8_t *mac_addr)
{
	return 0;
}

static void usb_ether_drv_start(void)
{
	if(usb_ether_drv == NULL) return;
	usb_ether_open(usb_ether_drv);
}

static int usb_ether_transmit(const void *data, size_t size)
{
	if(usb_ether_drv == NULL) return -1;
	return usb_ether_tx_data(usb_ether_drv, data, size);
}

static int usb_ether_receive(void *data, size_t size)
{
	if(usb_ether_drv == NULL) return -1;

	return usb_ether_rx_data(usb_ether_drv, data, size);
}

static uint8_t* usb_ether_getaddr(void)
{
	if(usb_ether_drv) return usb_ether_drv->mac;
	return NULL;
}

static eth_driver_t usb_ether_driver =
{
	.init		= usb_ether_drv_init,
	.start		= usb_ether_drv_start,
	.transmit	= usb_ether_transmit,
	.receive	= usb_ether_receive,
	.getaddr	= usb_ether_getaddr,
};

static int usb_ether_register_driver(struct usb_ether* usb_ether)
{
	if(usb_ether_drv == NULL) {
		if(register_eth_driver(&usb_ether_driver) == 0) {
			usb_ether_drv = usb_ether;
			return 0;
		}
	}
	return -1;
}
#endif
