/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#if (USE_USB_OHCI == 1)
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <util.h>
#include <malloc.h>
#include <usb.h>

#include "ohci.h"

//#define DUMP_OHCI_INFO

#if 0
#define OHCI_INFO(fmt, args...)		usb_printf(fmt, ##args)
#else
#define OHCI_INFO(fmt, args...)		do{}while(0)
#endif

#if 0
#define OHCI_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define OHCI_DEBUG(fmt, args...)	do{}while(0)
#endif

#if 0
#define OHCI_DESC_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define OHCI_DESC_DEBUG(fmt, args...)	do{}while(0)
#endif


#if 1
#define OHCI_ERROR(fmt, args...)	usb_printf("\x1b[31m"fmt"\x1b[0m", ##args)
#else
#define OHCI_ERROR(fmt, args...)	do{}while(0)
#endif


#define OHCI_RESET_DELAY	50	/* 50ms */

#define OHCI_MAX_ED		8
#define OHCI_MAX_TD		64

#define ED_BUFFER_SIZE		(sizeof(ohci_ed_t) * OHCI_MAX_ED)
#define TD_BUFFER_SIZE		(sizeof(ohci_td_t) * OHCI_MAX_TD)



typedef struct ohci
{
	ohci_reg_t*		reg;
	ohci_hcca_t*	hcca;			/* Host Controller Communications Area */

	ohci_ed_t*		ed[OHCI_MAX_ED];
	ohci_td_t*		td[OHCI_MAX_TD];
	u8*				dma_buffer;

	ohci_ed_t*		controlhead_ed;
	ohci_ed_t*		controltail_ed;

	ohci_ed_t*		bulkhead_ed;
	ohci_ed_t*		bulktail_ed;

	u32				hc_control;

	int				num_ports;
	int				roothub_addr;

} ohci_t;

#if 0
#define OHCI_REG_READ(ohci,r)		(ohci->reg->r)
#define OHCI_REG_WRITE(ohci,r, v)	(ohci->reg->r = v)
#else
#define OHCI_REG_READ(ohci,r)		USB_REG_READ((ulong)(ohci->reg) + r)
#define OHCI_REG_WRITE(ohci,r, v)	USB_REG_WRITE((ulong)(ohci->reg) + r, v)
#endif

#if (CONFIG_ARCH == ARCH_LG1311)
static unsigned long ohci_base_addr_a0[] = USB_OHCI_BASE_A0;
static unsigned long ohci_base_addr_b0[] = USB_OHCI_BASE_B0;
static unsigned long *ohci_base_addr;
#else
#define OHCI_NUM_DEVICE		(sizeof(ohci_base_addr)/sizeof(unsigned long))
static unsigned long ohci_base_addr[] = USB_OHCI_BASE;
#endif

//static unsigned long ohci_base_addr[] = {LG1152_USB0_OHCI1_BASE, LG1152_USB0_OHCI0_BASE};


static usb_device_descriptor_t ohci_rh_dev_desc =
{
    sizeof(usb_device_descriptor_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_DEVICE,			/* bDescriptorType */
    HTOUS(0x0110),			/* bcdUSB */
    USB_CLASS_HUB,			/* bDeviceClass */
    0,						/* bDeviceSubClass */
    0,						/* bDeviceProtocol */
    64,						/* bMaxPacketSize0 */
    HTOUS(0),				/* idVendor */
    HTOUS(0),				/* idProduct */
    HTOUS(0x0110),			/* bcdDevice */
    1,						/* iManufacturer */
    2,						/* iProduct */
    0,						/* iSerialNumber */
    1						/* bNumConfigurations */
};

static usb_config_desc_t ohci_rh_cfg_desc =
{
    sizeof(usb_config_desc_t),			/* bLength */
    USB_DESCRIPTOR_TYPE_CONFIGURATION,	/* bDescriptorType */
	HTOUS(sizeof(usb_config_desc_t) +
		sizeof(usb_interface_desc_t) +
		sizeof(usb_endpoint_desc_t)),	/* wTotalLength */
    1,						/* bNumInterfaces */
    1,						/* bConfigurationValue */
    0,						/* iConfiguration */
    USB_CONFIG_SELF_POWERED,		/* bmAttributes */
    0						/* MaxPower */
};

static usb_interface_desc_t ohci_rh_if_desc =
{
    sizeof(usb_interface_desc_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_INTERFACE,	/* bDescriptorType */
    0,						/* bInterfaceNumber */
    0,						/* bAlternateSetting */
    1,						/* bNumEndpoints */
    USB_CLASS_HUB,			/* bInterfaceClass */
    0,						/* bInterfaceSubClass */
    0,						/* bInterfaceProtocol */
    0						/* iInterface */
};

static usb_endpoint_desc_t ohci_rh_ep_desc =
{
    sizeof(usb_endpoint_desc_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_ENDPOINT,	/* bDescriptorType */
    (USB_EP_ADDR_DIR_IN | 1),	/* bEndpointAddress */
    USB_EP_ATTR_INTERRUPT,		/* bmAttributes */
    HTOUS(8),					/* wMaxPacketSize */
    255							/* bInterval */
};

static usb_hub_desc_t ohci_rh_hub_desc =
{
	sizeof(usb_hub_desc_t),		/* bDescLength */
	USB_DESCRIPTOR_TYPE_HUB,	/* bDescriptorType */
	0,		/* bNbrPorts */
	0,		/* wHubCharacteristics */
	0,		/* bPwrOn2PwrGood */
	0,		/* bHubContrCurrent */
	{0},	/* DeviceRemovable[1] */
	{0},	/* PortPwrCtrlMask[1] */
};

#if (CONFIG_ARCH == ARCH_LG1311)
static ohci_t *_ohci;
static usb_hcd_t *_usb_hcd;
#else
static ohci_t _ohci[OHCI_NUM_DEVICE];
static usb_hcd_t _usb_hcd[OHCI_NUM_DEVICE];
#endif


static ohci_ed_t* ohci_get_ed(ohci_t* ohci, usb_pipe_t* pipe);
static ohci_ed_t* get_ed_buffer(ohci_t* ohci, int idx);
static ohci_td_t* get_td_buffer(ohci_t* ohci, int idx);


#define GET_OHCI(d)		((ohci_t*)(d->usbd->hcd->bus))

static int ohci_start(usb_hcd_t *hcd)
{
	int i;
	u32 v;
	u32 hcFmInterval;
	u32 fm_interval;
	ohci_t *ohci = (ohci_t*)hcd->bus;

	OHCI_INFO("ohci_start\n");

	/* 5.1.1.4 Setup Host Controller */
	OHCI_REG_WRITE(ohci, HcControl, OHCI_HCFS_RESET);
	OHCI_REG_WRITE(ohci, HcCommandStatus, OHCI_CMDSTS_HCR); // reset host controller
	// The reset operation must be completed within 10us
	for(i=20; i>=0; i--)
	{
		// After reset completed then this bit is cleared
		if(!(OHCI_REG_READ(ohci, HcCommandStatus)&OHCI_CMDSTS_HCR))
			break;
		if(i == 0)
		{
			OHCI_ERROR("Reset timed out !\n");
			return -1;
		}
		udelay(1);
	}

	hcFmInterval = OHCI_REG_READ(ohci, HcFmInterval);
	OHCI_INFO("HcFmInterval:%08x\n", hcFmInterval);

	fm_interval = hcFmInterval & OHCI_FI_FI;
	OHCI_DEBUG("HcFmInterval : 0x%x\n", fm_interval);


	/* After reset, the controller is in SUSPEND state
	 * it must not stay in this state more than 2 ms
	 */
	OHCI_REG_WRITE(ohci, HcHCCA, (ulong)(ohci->hcca));
#if 0
	OHCI_REG_WRITE(ohci, HcControlHeadED, 0);
	OHCI_REG_WRITE(ohci, HcBulkHeadED, 0);
#else
	ohci->controltail_ed = ohci->ed[0] = get_ed_buffer(ohci, 0);	//&ohci->ed_list[0];
	ohci->controlhead_ed = ohci->controltail_ed;
	memset(ohci->controlhead_ed, 0, sizeof(ohci_ed_t));
	ohci->controlhead_ed->Control = OHCI_ED_SKIP;
	OHCI_REG_WRITE(ohci, HcControlHeadED, (ulong)ohci->controlhead_ed);

	ohci->bulktail_ed = ohci->ed[1] = get_ed_buffer(ohci, 1);	//&ohci->ed_list[1];
	ohci->bulkhead_ed = ohci->bulktail_ed;
	memset(ohci->bulkhead_ed, 0, sizeof(ohci_ed_t));
	ohci->bulkhead_ed->Control = OHCI_ED_SKIP;
	OHCI_REG_WRITE(ohci, HcBulkHeadED, (ulong)ohci->bulkhead_ed);
#endif

	// disable interrupts
	OHCI_REG_WRITE(ohci, HcInterruptDisable, OHCI_INT_ALL);

#if 0
	v = OHCI_INT_ALL;
	v &= ~OHCI_INT_MIE;
	OHCI_REG_WRITE(ohci, HcInterruptStatus,v );

	v = OHCI_INT_RHSC | OHCI_INT_UE | OHCI_INT_WDH | OHCI_INT_SO;
	OHCI_REG_WRITE(ohci, HcInterruptEnable, v);
#endif

#if 1
	v = OHCI_CONTROL_PLE |	OHCI_CONTROL_CLE | OHCI_CONTROL_BLE |
			OHCI_CBSR_41 | OHCI_HCFS_OPERATIONAL;
#else
	v = OHCI_CBSR_41 | OHCI_HCFS_OPERATIONAL;
#endif
	OHCI_REG_WRITE(ohci, HcControl, v);
	ohci->hc_control = v;


	/* Set HcPeriodicStart to a value that is 90% of the value
	 * in FrameInterval field of the HcFmInterval register.
	 */
	v = fm_interval * 9 / 10;
	OHCI_REG_WRITE(ohci, HcPeriodicStart, v);

	/* 5.4 FrameInterval Counter */
	v = fm_interval | ((fm_interval - 210) * 6 / 7 )<<16;
	v |= ((hcFmInterval&OHCI_FI_FIT) ? 0 : OHCI_FI_FIT);
	OHCI_REG_WRITE(ohci, HcFmInterval, v);


	v = OHCI_REG_READ(ohci, HcRhDescriptorA);
	OHCI_INFO("HcRhDescriptorA : %08x\n", v);		/* 0x02000001, kernel:0x7f000201 */

	/* Ŀ�� �ҽ��󿡼� ohci-dtvsoc.c���� ������ ���� �����Ǿ� �ִµ� ����� �� ��������??? ������
	 * ohci_writel(ohci, 0x7f000000 | RH_A_PSM | RH_A_OCPM, &ohci->regs->roothub.a);
	 * ohci_writel(ohci, 0x00060000, &ohci->regs->roothub.b);
	 */
#if 0
	v &= ~(OHCI_HRDA_POTPGT);
	v |= SET_OHCI_HRDA_POTPGT(0x7f);

	v &= ~(OHCI_HRDA_PSM | OHCI_HRDA_OCPM);
	v |= OHCI_HRDA_NPS;
	OHCI_REG_WRITE(ohci, HcRhDescriptorA, v);
	usb_printf("HcRhDescriptorA : %08x\n", v);
#endif

	/* Enable port power */
	OHCI_REG_WRITE(ohci, HcRhStatus, OHCI_HRS_LPSC);
	OHCI_REG_WRITE(ohci, HcRhDescriptorB, (v&OHCI_HRDA_NPS) ? 0 : OHCI_HRDB_PPCM);

	OHCI_INFO("PowerOnToPowerGoodTime : %dms\n", GET_OHCI_HRDA_POTPGT(v)*2);
	mdelay(GET_OHCI_HRDA_POTPGT(v)*2);

	v = OHCI_REG_READ(ohci, HcRhDescriptorA) & OHCI_HRDA_NDP;
	OHCI_INFO("Number Downstream Ports : %d\n", v);

	ohci->num_ports = v;

	ohci->roothub_addr = 0;

	return 0;
}

static void ohci_stop(usb_hcd_t *hcd)
{
	ohci_t *ohci = (ohci_t*)hcd->bus;

	OHCI_REG_WRITE(ohci, HcControl, OHCI_HCFS_RESET);
}

static int ohci_rh_transfer(usb_hcd_t *hcd, usb_req_t* req, usb_device_request_t* dev_req)
{
	u8 data[128];
	u16 wValue, wIndex;
	int len = 0;
	u8 *ptr;
	usb_pipe_t* pipe = req->pipe;
	usb_device_t* dev = pipe->dev;
	ohci_t* ohci = GET_OHCI(dev);

	void* buf = req->dma_buf;
	int size = req->size;

	wValue = UTOHS(dev_req->wValue);
	wIndex = UTOHS(dev_req->wIndex);

#define OP(r, rt)	((u16)r << 8 | rt)
	switch(OP(dev_req->bRequest, dev_req->bmRequestType))
	{
		case OP(USB_REQUEST_GET_STATUS,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):

			break;

		case OP(USB_HUB_REQ_GET_STATUS,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_CLASS | USB_REQTYPE_REC_DEVICE):
		{
			u32 rh_status = OHCI_REG_READ(ohci, HcRhStatus);
			usb_hub_status_t *hub_status = (usb_hub_status_t*)data;

			hub_status->wHubStatus = ((rh_status&(OHCI_HRS_LPS|OHCI_HRS_OCI))	>> 0) & 0xffff;
			hub_status->wHubChange = ((rh_status&(OHCI_HRS_LPSC|OHCI_HRS_OCIC))	>> 16) & 0xffff;

			ptr = data;
			len = sizeof(usb_hub_status_t);
			break;
		}

		case OP(USB_HUB_REQ_GET_STATUS,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_CLASS | USB_REQTYPE_REC_OTHER):
		{
			u32 rh_portstatus = OHCI_REG_READ(ohci, HcRhPortStatus + 4*(wIndex-1));
			usb_port_status_t *port_status = (usb_port_status_t*)data;

			//usb_printf("USB_REQUEST_GET_STATUS(USB_REQTYPE_TYPE_CLASS)\n");
			port_status->wPortStatus = (rh_portstatus >> 0) & 0xffff;
			port_status->wPortChange = (rh_portstatus >> 16) & 0xffff;

			ptr = data;
			len = sizeof(usb_port_status_t);
			break;
		}

		case OP(USB_HUB_REQ_CLEAR_FEATURE,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_CLASS | USB_REQTYPE_REC_OTHER):
		{
			u32 addr = HcRhPortStatus + 4*(wIndex-1);
			switch(wValue)
			{
				case USB_PORT_FEATURE_ENABLE: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_CPE); break;
				case USB_PORT_FEATURE_SUSPEND: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_CSS); break;
				case USB_PORT_FEATURE_POWER: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_CPP); break;

				case USB_PORT_FEATURE_C_CONNECTION: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_CSC); break;
				case USB_PORT_FEATURE_C_ENABLE: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_PESC); break;
				case USB_PORT_FEATURE_C_SUSPEND: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_PSSC); break;
				case USB_PORT_FEATURE_C_OVER_CURRENT: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_OCIC); break;
				case USB_PORT_FEATURE_C_RESET:  OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_PRSC); break;
			}
			break;
		}

		case OP(USB_HUB_REQ_SET_FEATURE,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_CLASS | USB_REQTYPE_REC_OTHER):
		{
			u32 addr = HcRhPortStatus + 4*(wIndex-1);
			switch(wValue)
			{
				case USB_PORT_FEATURE_ENABLE: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_SPE); break;
				case USB_PORT_FEATURE_SUSPEND: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_SPS); break;
				case USB_PORT_FEATURE_POWER: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_SPP); break;
				case USB_PORT_FEATURE_RESET: OHCI_REG_WRITE(ohci, addr, OHCI_HRPS_SPR); break;
			}
			break;
		}

		case OP(USB_REQUEST_GET_DESCRIPTOR,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			switch(wValue >> 8)
			{
				case USB_DESCRIPTOR_TYPE_DEVICE:
					ptr = (u8*)&ohci_rh_dev_desc;
					len = sizeof(ohci_rh_dev_desc);
					break;

				case USB_DESCRIPTOR_TYPE_CONFIGURATION:
					ptr = data;
					memcpy(ptr, &ohci_rh_cfg_desc, sizeof(usb_config_desc_t));
					len += sizeof(usb_config_desc_t);
					memcpy(ptr + len, &ohci_rh_if_desc, sizeof(usb_interface_desc_t));
					len += sizeof(usb_interface_desc_t);
					memcpy(ptr + len, &ohci_rh_ep_desc, sizeof(usb_endpoint_desc_t));
					len += sizeof(usb_endpoint_desc_t);
					break;
			}
			break;

		case OP(USB_REQUEST_GET_DESCRIPTOR,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_CLASS | USB_REQTYPE_REC_DEVICE):
		{
			usb_hub_desc_t *hub_desc = (usb_hub_desc_t*)data;
			u32 rh_a = OHCI_REG_READ(ohci, HcRhDescriptorA);
			u32 rh_b = OHCI_REG_READ(ohci, HcRhDescriptorB);
			u16 wHubCharacteristics = 0;

			OHCI_DEBUG("USB_REQUEST_GET_DESCRIPTOR(USB_REQTYPE_TYPE_CLASS). wValue=0x%x\n", wValue);

			memcpy(hub_desc, &ohci_rh_hub_desc, sizeof(ohci_rh_hub_desc));

			hub_desc->bNbrPorts = (rh_a & OHCI_HRDA_NDP);

			if(rh_a & OHCI_HRDA_PSM) wHubCharacteristics |= USB_HUB_CHAR_LPSM_IPS;

			if(rh_a & OHCI_HRDA_NOCP)		wHubCharacteristics |= USB_HUB_CHAR_OPM_NOP;
			else if(rh_a & OHCI_HRDA_OCPM)	wHubCharacteristics |= USB_HUB_CHAR_OPM_IPOP;

			put16(wHubCharacteristics, &hub_desc->wHubCharacteristics);
			hub_desc->bPwrOn2PwrGood = GET_OHCI_HRDA_POTPGT(rh_a);

			/* DeviceRemovable�� �������̾�� �ϳ� ���⼭�� �ܼ��� fix �� */
			hub_desc->DeviceRemovable[0] = (rh_b >> 0) & 0xff;
			hub_desc->PortPwrCtrlMask[0] = 0xff;

			ptr = data;
			len = sizeof(usb_hub_desc_t);
			break;
		}


		case OP(USB_REQUEST_GET_CONFIGURATION,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):

			break;

		case OP(USB_REQUEST_SET_ADDRESS,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			OHCI_DEBUG("USB_REQUEST_SET_ADDRESS. wValue=%d\n", wValue);
			ohci->roothub_addr = wValue;
			break;

		case OP(USB_REQUEST_SET_CONFIGURATION,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			OHCI_DEBUG("USB_REQUEST_SET_CONFIGURATION. wValue=%d\n", wValue);
			break;

	}

	if(len > 0)
	{
		len = min(len, size);
		memcpy(buf, ptr, len);
#ifdef USE_USB_CACHED_BUFFER
		dcache_clean_range((unsigned long)req->dma_buf, len);
#endif
	}

	req->xfer_len = len;
	req->status = USB_REQ_STATUS_DONE;

	return len;
}

static ohci_ed_t* get_ed_buffer(ohci_t* ohci, int idx)
{
	ohci_ed_t* ed = (ohci_ed_t*)(ohci->dma_buffer);
	ed += idx;
	memset(ed, 0, sizeof(ohci_ed_t));
	return ed;
}

static ohci_td_t* get_td_buffer(ohci_t* ohci, int idx)
{
	ohci_td_t* td = (ohci_td_t*)(ohci->dma_buffer + ED_BUFFER_SIZE);
	td += idx;
	memset(td, 0, sizeof(ohci_td_t));
	return td;
}

/*
 * Get the TD(Transfer Descriptor) from td list
 */
static ohci_td_t* ohci_get_td(ohci_t* ohci)
{
	ohci_td_t* td = NULL;
	int i;

	for(i=0; i<OHCI_MAX_TD; i++)
	{
		if(ohci->td[i] == NULL)
		{
			OHCI_DESC_DEBUG("ohci_get_td. index=%d\n", i);
			ohci->td[i] = get_td_buffer(ohci, i);	//&ohci->td_list[i];
			td = ohci->td[i];
			break;
		}
	}

	if(td == NULL)
	{
		OHCI_ERROR("ohci_get_td:no left TD\n");
		return NULL;
	}

	return td;
}

static int ohci_free_td(ohci_t* ohci, ohci_td_t* td)
{
	int i;

	for(i=0; i<OHCI_MAX_TD; i++)
	{
		if(ohci->td[i] == td)
		{
			OHCI_DESC_DEBUG("ohci_free_td. index=%d\n", i);
			ohci->td[i] = NULL;
			return 0;
		}
	}
	OHCI_ERROR("ohci_free_td:invalid TD(%08x)\n", td);
	return -1;
}

static ohci_ed_t* ohci_get_ed(ohci_t* ohci, usb_pipe_t* pipe)
{
	int i;
	ohci_ed_t* ed = NULL;
	int empty = -1;

	for(i=0; i<OHCI_MAX_ED; i++)
	{
		if(ohci->ed[i] != NULL)
		{
			u32 control = ohci->ed[i]->Control;
			if( (control != OHCI_ED_SKIP) &&
				GET_OHCI_ED_FADDR(control) == pipe->dev->address &&
				GET_OHCI_ED_EPNUM(control) == pipe->num)
			{
				OHCI_DEBUG("Alread exist ed !\n");
				ed = ohci->ed[i];
				break;
			}
		}
		else if(empty == -1)
		{
			empty = i;
		}
	}

	if(ed == NULL)
	{
		if(empty == -1)
		{
			OHCI_ERROR("ohci_get_ed:no left ED\n");
			return NULL;
		}

		ohci_td_t* td = ohci_get_td(ohci);
		if(td == NULL) return NULL;

		ed = ohci->ed[empty] = get_ed_buffer(ohci, empty);
		ed->TailP = HTOUL((ulong)td);
		ed->HeadP = ed->TailP;
		ed->NextED = 0;

		if(IS_USB_PIPE_CONTROL(pipe))
		{
			if(ohci->controltail_ed == NULL)
			{
				OHCI_ERROR("Not possible status : controltail_ed is null\n");
				OHCI_REG_WRITE(ohci, HcControlHeadED, (ulong)ed);
				ohci->hc_control |= OHCI_CONTROL_CLE;
				OHCI_REG_WRITE(ohci, HcControl, ohci->hc_control);
			}
			else
			{
				ohci->controltail_ed->NextED = HTOUL((ulong)ed);
				OHCI_DESC_DEBUG("Added to conroltail(%08x)\n", ohci->controltail_ed);
			}
			ohci->controltail_ed = ed;
		}
		else if(IS_USB_PIPE_BULK(pipe))
		{
			if(ohci->bulktail_ed == NULL)
			{
				OHCI_ERROR("Not possible status : bulktail_ed is null\n");
				OHCI_REG_WRITE(ohci, HcBulkHeadED, (ulong)ed);
				ohci->hc_control |= OHCI_CONTROL_BLE;
				OHCI_REG_WRITE(ohci, HcControl, ohci->hc_control);
			}
			else
			{
				ohci->bulktail_ed->NextED = HTOUL((ulong)ed);
				OHCI_DESC_DEBUG("Added to bulktail(%08x)\n", ohci->bulktail_ed);
			}
			ohci->bulktail_ed = ed;
		}
	}
	ed->Control = (pipe->dev->address << 0) |
				  (pipe->num << OHCI_ED_EPNUM_SHIFT) |
				  (IS_USB_PIPE_CONTROL(pipe) ? 0 :
					IS_USB_PIPE_OUT(pipe) ? OHCI_ED_DIR_OUT : OHCI_ED_DIR_IN) |
				  (pipe->mps << OHCI_ED_MPS_SHIFT) ;

	ed->pipe = pipe;

	OHCI_DESC_DEBUG("ohci_get_ed(%08x). address:%d, num:%d, flag:%x, mps:%d\n",
						ed, pipe->dev->address, pipe->num, pipe->flag, pipe->mps);
	return ed;
}

static int ohci_free_ed(ohci_t* ohci, ohci_ed_t* ed)
{
	int i;

	for(i=0; i<OHCI_MAX_ED; i++)
	{
		if(ohci->ed[i] == ed)
		{
			OHCI_DESC_DEBUG("ohci_free_ed. address:%d, num:%d, flag:%x, mps:%d\n",
					ed->pipe->dev->address, ed->pipe->num, ed->pipe->flag, ed->pipe->mps);

			ed->Control |= OHCI_ED_SKIP;

			if(IS_USB_PIPE_CONTROL(ed->pipe))
			{
				ohci_ed_t *head_ed = (ohci_ed_t*)(ulong)OHCI_REG_READ(ohci, HcControlHeadED);
				if(head_ed == ed)
				{
					if(ed->NextED == 0)	/* No one left in the control list */
					{
						OHCI_ERROR("Not possible status : control list empty\n");
						ohci->hc_control &= ~OHCI_CONTROL_CLE;
						OHCI_REG_WRITE(ohci, HcControl, ohci->hc_control);
						ohci->controltail_ed = NULL;
					}
					OHCI_REG_WRITE(ohci, HcControlHeadED, ed->NextED);
				}
				else
				{
					ohci_ed_t* pre_ed = head_ed;
					ohci_ed_t* next_ed = (ohci_ed_t*)(ulong)head_ed->NextED;

					/* We are not using the double linked list, so have to find the previous link
					 * and reconstruct the linked list */
					while(next_ed != NULL)
					{
						if(next_ed == ed)
						{
							pre_ed->NextED = ed->NextED;
							/* If the ED is the last link then we have to replace the controltail_ed. */
							if(ed == ohci->controltail_ed)
								ohci->controltail_ed = pre_ed;
							break;
						}
						pre_ed = next_ed;
						next_ed = (ohci_ed_t*)((ulong)next_ed->NextED);
					}
					if(next_ed == NULL) OHCI_ERROR("CONTROL : can't find valid ed\n");
				}
				ohci->ed[i] = NULL;
				return 0;
			}
			else if(IS_USB_PIPE_BULK(ed->pipe))
			{
				ohci_ed_t *head_ed = (ohci_ed_t*)(ulong)OHCI_REG_READ(ohci, HcBulkHeadED);
				if(head_ed == ed)
				{
					if(ed->NextED == 0) /* No one left in the control list */
					{
						OHCI_ERROR("Not possible status : bulk list empty\n");
						ohci->hc_control &= ~OHCI_CONTROL_BLE;
						OHCI_REG_WRITE(ohci, HcControl, ohci->hc_control);
						ohci->bulktail_ed = NULL;
					}
					OHCI_REG_WRITE(ohci, HcBulkHeadED, ed->NextED);
				}
				else
				{
					ohci_ed_t* pre_ed = head_ed;
					ohci_ed_t* next_ed = (ohci_ed_t*)(ulong)head_ed->NextED;

					/* We are not using the double linked list, so have to find the previous link
					 * and reconstruct the linked list */
					while(next_ed != NULL)
					{
						if(next_ed == ed)
						{
							pre_ed->NextED = ed->NextED;
							/* If the ED is the last link then we have to replace the builtail_ed. */
							if(ed == ohci->bulktail_ed)
								ohci->bulktail_ed = pre_ed;
							break;
						}
						pre_ed = next_ed;
						next_ed = (ohci_ed_t*)((ulong)next_ed->NextED);
					}

					if(next_ed == NULL) OHCI_ERROR("BULK : can't find valid ed. ed:%08x\n", ed);
				}
				ohci->ed[i] = NULL;
				return 0;


			}
			else
			{
				OHCI_ERROR("ohci_free_ed:Unsupported Type...\n");
			}
		}
	}
	OHCI_ERROR("ohci_free_ed:invalid ed(%08x)\n", ed);
	return -1;
}



static int ohci_add_td(ohci_t* ohci, ohci_ed_t* ed, u32 control, void* data, int size)
{
	ohci_td_t *td, *new_td;


	/*
	 * 5.2.8.2 Adding to a Queue
	 *
	 * Transfer Descriptor �߰� ���
	 * ED ������ �̹� �ϳ��� TD�� ������ �Ǿ� �����ϸ� �� TD�� ed->HeadP, ed->TailP�� �����Ǿ� �ִ�.
	 * ���ο� ED�� �ϳ� �����Ͽ� �߰� �ϴµ� ������ ed->TailP�� �����ϴ� ED�� ����ϰ�
	 * ���� ������ ED�� �ٽ� TailP�� ������ ������ ����Ѵ�.
	 */

	new_td = ohci_get_td(ohci);
	if(new_td == NULL)
		return -1;

	new_td->NextTD = 0;

	if(size == 0) data = NULL;

	td = (ohci_td_t*)GET_OHCI_TD_ADDR(ed->TailP);

	td->Control = control;
	td->CBP = HTOUL((ulong)data);
	if(data != NULL) td->BE = HTOUL((ulong)data + size - 1);
	else td->BE = 0;
	td->NextTD = HTOUL((ulong)new_td);

	OHCI_DESC_DEBUG("ohci_add_td. ed:%08x, td:%08x, control:%08x, CBP:%08x, Next:%08x, BE:%08x\n",
		ed, td, td->Control, td->CBP, td->NextTD, td->BE);

	td->num	= ed->td_cnt;
	td->ed	= ed;
	td->buf	= (ulong)data;

	ed->TailP = HTOUL((ulong)new_td);

	ed->td_cnt++;

	return 0;
}

#ifdef DUMP_OHCI_INFO
static void print_ohci_ed(ohci_ed_t* ed)
{
	ohci_td_t *td;

	while(ed != NULL)
	{
		usb_printf("ED(%8x). Control:%08x, TailP:%08x, HeadP:%08x, NextED:%08x\n",
				ed, ed->Control, ed->TailP, ed->HeadP, ed->NextED);
		usb_printf("\tFUNADDR:%d, EPNUM:%d, DIR:%d, SPEED:%d, FORMAT:%d, MPS:%d\n",
				(ed->Control&OHCI_ED_FADDR),
				(ed->Control&OHCI_ED_EPNUM) >> 7,
				(ed->Control&OHCI_ED_DIR) >> 11,
				(ed->Control&OHCI_ED_SPEED) >> 13,
				(ed->Control&OHCI_ED_FORMAT) >> 15,
				(ed->Control&OHCI_ED_MPS) >> 16);

		td = (ohci_td_t*)GET_OHCI_TD_ADDR(ed->HeadP);
		usb_printf("\tTD LIST : ");
		while(td)
		{
			usb_printf("TD(0x%08x) => ", (ulong)td);
			td = (ohci_td_t*)GET_OHCI_TD_ADDR(td->NextTD);
		}
		usb_printf("NULL\n");

		ed = (ohci_ed_t*)(ulong)ed->NextED;
	}
}

void print_ohci_info(usb_hcd_t *hcd)
{
	ohci_t* ohci = (ohci_t*)hcd->bus;
	ohci_ed_t* ed;

	usb_printf("\n\n================= OHCI INFORMATION =================\n");
	usb_printf("#### Control Endpoint List ####\n");
	ed = (ohci_ed_t*)(ulong)OHCI_REG_READ(ohci, HcControlHeadED);
	print_ohci_ed(ed);

	usb_printf("#### Bulk Endpoint List ####\n");
	ed = (ohci_ed_t*)(ulong)OHCI_REG_READ(ohci, HcBulkHeadED);
	print_ohci_ed(ed);

	usb_printf("===================================================\n");
}
#else
void print_ohci_info(usb_hcd_t *hcd){}
#endif


static int ohci_transfer(usb_hcd_t *hcd, usb_req_t* req, usb_device_request_t* dev_req)
{
	usb_pipe_t* pipe = req->pipe;
	usb_device_t* dev = pipe->dev;
	ohci_t* ohci = (ohci_t*)hcd->bus;

	ohci_ed_t* ed;
	u32 control;

	void* buf;
	int size;

	if(dev->address == ohci->roothub_addr)		// root hub
	{
		return ohci_rh_transfer(hcd, req, dev_req);
	}
	OHCI_DEBUG("##### ohci_transfer. #####\n");

	buf = req->dma_buf;
	size = req->size;

	ed = ohci_get_ed(ohci, pipe);
	if(!IS_USB_PIPE_CONTROL(pipe) && !IS_USB_PIPE_BULK(pipe))
	{
		OHCI_ERROR("Not supported type !!!\n");
		return -1;
	}
	OHCI_DEBUG("ed->Control:%08x\n", ed->Control);

	ed->td_cnt = 0;
	ed->td_processed = 0;
	ed->req = req;


	if(IS_USB_PIPE_CONTROL(pipe))
	{
		/* !Caution : DelayInterrupt ���� �������� ���� ��� �߰��� ���� Intrrupt�� �߻� �ϴ� ��찡 �߻� */
		control = SET_OHCI_TD_CC(OHCI_CC_NA) | OHCI_TD_DP_SETUP | OHCI_TD_T_DATA0 | SET_OHCI_TD_DI(6);
		ohci_add_td(ohci, ed, control, dev_req, sizeof(usb_device_request_t));

		if(size > 0)
		{
			control = SET_OHCI_TD_CC(OHCI_CC_NA) | OHCI_TD_R | SET_OHCI_TD_DI(6) | 	OHCI_TD_T_DATA1 |
					(IS_USB_PIPE_IN(pipe) ? OHCI_TD_DP_IN : OHCI_TD_DP_OUT);
			ohci_add_td(ohci, ed, control, buf, size);
		}

		control = SET_OHCI_TD_CC(OHCI_CC_NA) | OHCI_TD_T_DATA1 |
					(IS_USB_PIPE_IN(pipe) ? OHCI_TD_DP_OUT : OHCI_TD_DP_IN);
		ohci_add_td(ohci, ed, control, buf, 0);



		/* Start control list */
		OHCI_REG_WRITE(ohci, HcCommandStatus, OHCI_CMDSTS_CLF);
	}
	else if(IS_USB_PIPE_BULK(pipe))
	{
		u8* data = (u8*)buf;
		int rsize;

#if 0
		int toggle;
		if(pipe->toggle) toggle = 0;
		else
		{
			toggle = OHCI_TD_T_DATA0;
			pipe->toggle = 1;
			usb_printf("TOGGLE DATA !!!\n");
		}
#endif

		control = SET_OHCI_TD_CC(OHCI_CC_NA) | 	//toggle |
					(IS_USB_PIPE_IN(pipe) ? OHCI_TD_DP_IN : OHCI_TD_DP_OUT);

		if(IS_USB_PIPE_IN(pipe))
		{
			control |= OHCI_TD_R;
		}

		while(size > 0)
		{
			rsize = (size > 4096) ? 4096 : size;
			ohci_add_td(ohci, ed, control, data, rsize);

			size -= rsize;
			data += rsize;
		}

		OHCI_REG_WRITE(ohci, HcCommandStatus, OHCI_CMDSTS_BLF);
	}

	return 0;
}

/* Processing WriteBackDoneHead Interrupt */
static int ohci_intr_wbh(ohci_t* ohci)
{


	ohci_td_t* td;
	ohci_ed_t* ed;
	usb_req_t* req;
	usb_pipe_t* pipe;
	int cc;

	OHCI_DEBUG("WritebackDoneHead. hccaDoneHead:0x%08x\n", ohci->hcca->done_head);
	if(ohci->hcca->done_head == 0)
	{
		OHCI_ERROR("ohci_intr. done_head is null !!!\n");
		return -1;
	}

	td = (ohci_td_t*)(ulong)ohci->hcca->done_head;
	ohci->hcca->done_head = 0;

	while(td)
	{
		cc = GET_OHCI_TD_CC(td->Control);

		if(cc)
			OHCI_DEBUG("Control:%08x, CBP=%08x, NextTD=%08x, BE=%08x, Condition:%d\n",
						td->Control, td->CBP, td->NextTD, td->BE, cc);

		if(td->ed == NULL || td->ed->pipe == NULL || td->ed->req == NULL)
		{
			OHCI_ERROR("NULL Point. ed:%8x, pipe:%8x, req:%8x\n", td->ed,
						(td->ed == 0) ? 0 : td->ed->pipe, (td->ed == 0) ? 0 : td->ed->req);
			td = (ohci_td_t*)(ulong)td->NextTD;
			continue;
		}

		ed		= td->ed;
		pipe	= ed->pipe;
		req		= ed->req;

		ed->td_processed++;

		if((!IS_USB_PIPE_CONTROL(pipe) || td->num == 1) && td->BE != 0)
		{
			if(td->CBP == 0)
				req->xfer_len += (td->BE - td->buf + 1);
			else
				req->xfer_len += (td->CBP - td->buf);
		}

		ohci_free_td(ohci, td);
		td = (ohci_td_t*)(ulong)td->NextTD;

		if(ed->td_processed == ed->td_cnt)
		{
			if(GET_OHCI_TD_ADDR(ed->HeadP) != GET_OHCI_TD_ADDR(ed->TailP))
			{
				OHCI_ERROR("Invalid status. TD Cnt:%d, ED(%08x), HeadP:%08x, TailP:%08x\n",
					ed->td_cnt, ed, ed->HeadP, ed->TailP);
			}

			if(0)	//IS_USB_PIPE_CONTROL(pipe))
			{
				ohci_free_td(ohci, (ohci_td_t*)GET_OHCI_ED_ADDR(ed->HeadP));
				ohci_free_ed(ohci, ed);
			}
			else
			{
				ed->Control |= OHCI_ED_SKIP;
			}

			req->status = (cc == 4) ? USB_REQ_STATUS_STALL : USB_REQ_STATUS_DONE;
			if(req->callback)
			{
				req->callback(req);
			}

			OHCI_INFO("Transferred Length : %d\n", req->xfer_len);
			OHCI_DEBUG("ED(%08x). HeadP:%8x, TailP:%8x\n", ed, ed->HeadP, ed->TailP);
		}
	}

	return 0;
}

static int ohci_interrupt(usb_hcd_t *hcd)
{
	ohci_t* ohci = (ohci_t*)hcd->bus;
	u32 intr_stat;

	intr_stat = OHCI_REG_READ(ohci, HcInterruptStatus);
	intr_stat &= (OHCI_INT_RHSC | OHCI_INT_UE | OHCI_INT_WDH | OHCI_INT_SO);

	if(intr_stat == 0)
		return 0;

//	OHCI_DEBUG("StartFrame. frame:%d\n", ohci->hcca->frame_number);

	OHCI_DEBUG("ohci_intr : %08x\n", intr_stat);
	if(intr_stat & OHCI_INT_WDH)
	{
		ohci_intr_wbh(ohci);
	}

	if(intr_stat & OHCI_INT_SO)
	{
		OHCI_DEBUG("SchedulingOverrun\n");
	}

	if(intr_stat & OHCI_INT_UE)
	{
		OHCI_DEBUG("UnrecoverableError\n");
	}

	if(intr_stat & OHCI_INT_RHSC)
	{
		OHCI_DEBUG("RootHubStatusChange\n");
	}

	OHCI_REG_WRITE(ohci, HcInterruptStatus, intr_stat);

	return 0;
}


static usb_hcd_func_t hcd_func =
{
	.start		= ohci_start,
	.stop		= ohci_stop,
	.transfer	= ohci_transfer,
	.interrupt	= ohci_interrupt,
};

int usb_ohci_init(void)
{
	int i;
	char name[MAX_USBD_NAME_LENGTH + 1];
#if (CONFIG_ARCH == ARCH_LG1311)
	int OHCI_NUM_DEVICE;

	if(get_chip_rev() < CHIP_LG1311_B0)
	{//A0, A1
		OHCI_NUM_DEVICE = (sizeof(ohci_base_addr_a0)/sizeof(unsigned long));
		ohci_base_addr = ohci_base_addr_a0;
	}
	else
	{//B0
		OHCI_NUM_DEVICE = (sizeof(ohci_base_addr_b0)/sizeof(unsigned long));
		ohci_base_addr = ohci_base_addr_b0;
	}

	_ohci = (ohci_t *)calloc(1, sizeof(ohci_t) * OHCI_NUM_DEVICE);
	if(_ohci == NULL)
	{
		OHCI_ERROR("fail malloc\n");
		return -1;
	}

	_usb_hcd = (usb_hcd_t *)calloc(1, sizeof(usb_hcd_t) * OHCI_NUM_DEVICE);
	if(_usb_hcd == NULL)
	{
		OHCI_ERROR("fail malloc\n");
		return -1;
	}
#endif

	for(i=0; i<OHCI_NUM_DEVICE; i++)
	{
		_ohci[i].reg = (ohci_reg_t*)ohci_base_addr[i];

		/* HCCA Memory have to be aligned to 256bytes */
		_ohci[i].hcca = (ohci_hcca_t*)dmalloc_align(sizeof(ohci_hcca_t), 256);
		memset(_ohci[i].hcca, 0, sizeof(ohci_hcca_t));

		memset(_ohci[i].ed, 0, sizeof(_ohci[i].ed));
		memset(_ohci[i].td, 0, sizeof(_ohci[i].td));

		_ohci[i].dma_buffer = (u8*)dma_malloc(ED_BUFFER_SIZE + TD_BUFFER_SIZE);

		_usb_hcd[i].bus		= (void*)&_ohci[i];
		_usb_hcd[i].func	= &hcd_func;
		_usb_hcd[i].rev		= USB_REV_1_1;

		sprintf(name, "OHCI[%d]", i);
		usb_register_hcd(name, &_usb_hcd[i]);
	}

	return 0;
}
#endif
