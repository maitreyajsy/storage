/****************************************************************************************
 *   SIC R&D Lab., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011-2013 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#if (USE_USB_XHCI == 1)
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <util.h>
#include <malloc.h>
#include <usb.h>
#include <list.h>
#include <thread.h>

#include "xhci.h"


//#define DUMP_XHCI_INFO
//#define XHCI_DEBUG_CONTEXT

#if 0
#define XHCI_INFO(fmt, args...)		usb_printf(fmt, ##args)
#else
#define XHCI_INFO(fmt, args...)		do{}while(0)
#endif

#if 0
#define XHCI_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define XHCI_DEBUG(fmt, args...)	do{}while(0)
#endif

#if 0
#define XHCI_DESC_DEBUG(fmt, args...)	usb_printf(fmt, ##args)
#else
#define XHCI_DESC_DEBUG(fmt, args...)	do{}while(0)
#endif

#if 1
#define XHCI_ERROR(fmt, args...)	usb_printf("\x1b[31m"fmt"\x1b[0m", ##args)
#else
#define XHCI_ERROR(fmt, args...)	do{}while(0)
#endif


#define XHCI_MAX_DEVICES	255
#define XHCI_RESET_DELAY	50	/* 50ms */

#define XHCI_COMMAND_STATUS_RUN		0
#define XHCI_COMMAND_STATUS_DONE	1
#define XHCI_COMMAND_STATUS_ERROR	2

typedef struct xhci_command
{
	xhci_trb_t	*trb;
	int			status;
	u32			result;		/* TRB3 if succeed or TRB Completion Codes if failed */
} xhci_command_t;


#define XHCI_TRB_RING_TYPE_TRANSFER		1
#define XHCI_TRB_RING_TYPE_EVENT		2
#define XHCI_TRB_RING_TYPE_COMMAND		3


typedef struct xhci_trb_ring
{
	int				type;

	xhci_trb_t		*queue;
	int				queue_size;
	int				enq_idx;
	int				deq_idx;

	int				cycle_state;	/* Producer/Consumer Cycle State */
} xhci_trb_ring_t;


/* Process only a single transfer */
typedef struct xhci_xfer
{
	xhci_trb_ring_t	*ep_ring;

	xhci_trb_t		*first_trb;
	xhci_trb_t		*last_trb;

	usb_req_t		*req;
	LIST_ENTRY(xhci_xfer)   link;
} xhci_xfer_t;
typedef LIST_HEAD(xhci_xfer_head, xhci_xfer) xhci_xfer_head_t;

typedef struct xhci_device
{
	int					slot_id;

	xhci_input_ctx_t	in_ctx;
	xhci_device_ctx_t	dev_ctx;

	xhci_trb_ring_t		*ep_ring[32];

	xhci_xfer_head_t	xfer_head;

	int					address;	// assigned by xHC
} xhci_device_t;

typedef struct xhci_regs
{
	unsigned long		base_reg;		/* xHC Controller Base Register Address */

	xhci_cap_reg_t		*cap_reg;		/* Capability Registers */
	xhci_op_reg_t		*op_reg;		/* Operational Registers */
	xhci_rt_reg_t		*rt_reg;		/* Runtime Registers */
	xhci_db_reg_t		*db_reg;		/* Doorbell Registers */
} xhci_regs_t;

typedef struct xhci
{
	xhci_regs_t			regs;

	xhci_dcba_t			*dcbaa;			/* Device Context Base Address */
	xhci_sbba_t			*sba;			/* Scratchpad Buffer Base Address */

	xhci_erst_t			*erst;			/* Event Ring Segment Table */
	xhci_trb_ring_t		*event_ring;	/* Event Ring */
	xhci_trb_ring_t 	*command_ring;	/* Command Ring */

	xhci_command_t		command;

	xhci_device_t		*device[XHCI_MAX_DEVICES];


	u32					page_size;
	u32 				page_shift;

	int					num_sb;			/* Scratchpad Buffers */
	int					context_size;	/* 64 or 32 */
	int					num_slots;
	int					num_ports;
	int					roothub_addr;

} xhci_t;

union xhci_u64
{
	struct{ u32 lo, hi;};
	u64 val;
};

#define XHCI_REG_WRITE64(r, v)		\
	do{								\
		USB_REG_WRITE((r), v.lo);		\
		USB_REG_WRITE((r) + 4, v.hi);	\
	} while(0)

#define XHCI_REG_READ64(r, v)		\
	do{ 							\
		v.lo = USB_REG_READ((r));		\
		v.hi = USB_REG_READ((r) + 4);	\
	} while(0)

#define XHCI_CAP_REG_ADDR(xhci,r)		((ulong)(xhci->regs.cap_reg) + r)
#define XHCI_OP_REG_ADDR(xhci,r)		((ulong)(xhci->regs.op_reg) + r)


#define XHCI_CAP_REG_READ(xhci,r)		USB_REG_READ((ulong)(xhci->regs.cap_reg) + r)
#define XHCI_CAP_REG_WRITE(xhci,r,v)	USB_REG_WRITE((ulong)(xhci->regs.cap_reg) + r, v)

#define XHCI_OP_REG_READ(xhci,r)		USB_REG_READ((ulong)(xhci->regs.op_reg) + r)
#define XHCI_OP_REG_WRITE(xhci,r,v)		USB_REG_WRITE((ulong)(xhci->regs.op_reg) + r, v)
#define XHCI_OP_REG_WRITE64(xhci,r,v)	XHCI_REG_WRITE64((ulong)(xhci->regs.op_reg) + r, v)
#define XHCI_OP_REG_READ64(xhci,r,v)	XHCI_REG_READ64((ulong)(xhci->regs.op_reg) + r, v)

#define XHCI_RT_REG_READ(xhci,r)		USB_REG_READ((ulong)(xhci->regs.rt_reg) + r)
#define XHCI_RT_REG_WRITE(xhci,r,v)		USB_REG_WRITE((ulong)(xhci->regs.rt_reg) + r, v)
#define XHCI_RT_REG_WRITE64(xhci,r,v)	XHCI_REG_WRITE64((ulong)(xhci->regs.rt_reg) + r, v)
#define XHCI_RT_REG_READ64(xhci,r,v)	XHCI_REG_READ64((ulong)(xhci->regs.rt_reg) + r, v)

#define XHCI_DB_REG_READ(xhci,i)		USB_REG_READ((ulong)(xhci->regs.db_reg) + (i*4))
#define XHCI_DB_REG_WRITE(xhci,i,v)		USB_REG_WRITE((ulong)(xhci->regs.db_reg) + (i*4), v)

#if (CONFIG_ARCH == ARCH_LG1311)
static unsigned long xhci_base_addr_a0[] = USB_XHCI_BASE_A0;
static unsigned long xhci_base_addr_b0[] = USB_XHCI_BASE_B0;
static unsigned long *xhci_base_addr;
#else
#define XHCI_NUM_DEVICE		(sizeof(xhci_base_addr)/sizeof(unsigned long))
static unsigned long xhci_base_addr[] = USB_XHCI_BASE;
#endif


static usb_device_descriptor_t xhci_rh_dev_desc =
{
    sizeof(usb_device_descriptor_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_DEVICE,			/* bDescriptorType */
    HTOUS(0x0300),						/* bcdUSB */
    USB_CLASS_HUB,						/* bDeviceClass */
    0,									/* bDeviceSubClass */
    0,									/* bDeviceProtocol */
    9,									/* bMaxPacketSize0 */
    HTOUS(0),							/* idVendor */
    HTOUS(0),							/* idProduct */
    HTOUS(0x0110),						/* bcdDevice */
    1,									/* iManufacturer */
    2,									/* iProduct */
    0,									/* iSerialNumber */
    1									/* bNumConfigurations */
};

static usb_config_desc_t xhci_rh_cfg_desc =
{
    sizeof(usb_config_desc_t),			/* bLength */
    USB_DESCRIPTOR_TYPE_CONFIGURATION,	/* bDescriptorType */
	HTOUS(sizeof(usb_config_desc_t) +
		sizeof(usb_interface_desc_t) +
		sizeof(usb_endpoint_desc_t)),	/* wTotalLength */
    1,									/* bNumInterfaces */
    1,									/* bConfigurationValue */
    0,									/* iConfiguration */
    USB_CONFIG_SELF_POWERED,			/* bmAttributes */
    0									/* MaxPower */
};

static usb_interface_desc_t xhci_rh_if_desc =
{
    sizeof(usb_interface_desc_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_INTERFACE,	/* bDescriptorType */
    0,								/* bInterfaceNumber */
    0,								/* bAlternateSetting */
    1,								/* bNumEndpoints */
    USB_CLASS_HUB,					/* bInterfaceClass */
    0,								/* bInterfaceSubClass */
    0,								/* bInterfaceProtocol */
    0								/* iInterface */
};

static usb_endpoint_desc_t xhci_rh_ep_desc =
{
    sizeof(usb_endpoint_desc_t),	/* bLength */
    USB_DESCRIPTOR_TYPE_ENDPOINT,	/* bDescriptorType */
    (USB_EP_ADDR_DIR_IN | 1),		/* bEndpointAddress */
    USB_EP_ATTR_INTERRUPT,			/* bmAttributes */
    HTOUS(8),						/* wMaxPacketSize */
    255								/* bInterval */
};

static usb_hub_desc_t xhci_rh_hub_desc =
{
	sizeof(usb_hub_desc_t),		/* bDescLength */
	USB_DESCRIPTOR_TYPE_HUB,	/* bDescriptorType */
	0,							/* bNbrPorts */
	0,							/* wHubCharacteristics */
	10,							/* bPwrOn2PwrGood */
	0,							/* bHubContrCurrent */
	{0},						/* DeviceRemovable[1] */
	{0},						/* PortPwrCtrlMask[1] */
};

#if (CONFIG_ARCH == ARCH_LG1311)
static xhci_t *_xhci;
static usb_hcd_t *_usb_hcd;
#else
static xhci_t _xhci[XHCI_NUM_DEVICE];
static usb_hcd_t _usb_hcd[XHCI_NUM_DEVICE];
#endif

static int xhci_poll(xhci_t *xhci);

static int xhci_wait_status(xhci_t *xhci, u32 reg, u32 mask, u32 value, int timeout)
{
	timeout_id_t t;
	uint32_t v;

	set_timeout(&t, timeout);
	while(1)
	{
		v = XHCI_OP_REG_READ(xhci, reg);
		if((v&mask) == value) return 0;
		if(is_timeout(&t)) return -1;
		udelay(5);
	}
}

static xhci_trb_ring_t* xhci_alloc_trb_ring(int type)
{
	xhci_trb_ring_t *ring;
	int size, num_trbs;

	switch(type) {
		case XHCI_TRB_RING_TYPE_TRANSFER:	num_trbs = XHCI_MAX_TRANSFER_TRBS; break;
		case XHCI_TRB_RING_TYPE_EVENT:		num_trbs = XHCI_MAX_EVENT_TRBS; break;
		case XHCI_TRB_RING_TYPE_COMMAND:	num_trbs = XHCI_MAX_COMMAND_TRBS; break;
		default: return NULL;
	}

	ring = (xhci_trb_ring_t*)malloc(sizeof(xhci_trb_ring_t));

	ring->type = type;
	ring->queue_size = num_trbs;
	size = sizeof(xhci_trb_t) * num_trbs;
	ring->queue = (xhci_trb_t*)dmalloc_align(size, 64);
	memset(ring->queue, 0, size);

	ring->enq_idx = ring->deq_idx = 0;
	ring->cycle_state = 1;

	if(type != XHCI_TRB_RING_TYPE_EVENT) {
		/* Setup Link TRB */
		ring->queue[num_trbs - 1].trb0 = (ulong)ring->queue;
		ring->queue[num_trbs - 1].trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_LINK) | XHCI_TRB3_C;
	}

	return ring;
}

static void xhci_free_trb_ring(xhci_trb_ring_t *ring)
{
	dfree(ring->queue);
	free(ring);
}

static xhci_trb_t* xhci_enqueue_trb(xhci_trb_ring_t *ring, xhci_trb_t *in_trb)
{
	xhci_trb_t *trb;
	u32 trb3;


	trb = &ring->queue[ring->enq_idx];

	trb->trb0 = in_trb->trb0;
	trb->trb2 = in_trb->trb2;
	trb->trb3 = in_trb->trb3;

	ring->enq_idx++;
	if(ring->type == XHCI_TRB_RING_TYPE_EVENT) {
		if(ring->enq_idx == ring->queue_size) {
			ring->enq_idx = 0;
			ring->cycle_state ^= 1; 	/* Toggle Cycle State */
		}
	} else {
		if(ring->enq_idx == (ring->queue_size-1)) {
			xhci_trb_t *last_trb = &ring->queue[ring->enq_idx];

			trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_LINK) | XHCI_LINK_TRB3_TC;
			if(ring->cycle_state) trb3 |= XHCI_TRB3_C;
			if(in_trb->trb3&XHCI_TRB3_CH) trb3 |= XHCI_TRB3_CH;

			last_trb->trb3 = trb3;

			ring->enq_idx = 0;
			ring->cycle_state ^= 1; 	/* Toggle Cycle State */

			XHCI_DEBUG("Ring[%p] Toogle Cycle State.\n", ring);
			XHCI_DEBUG("Beginning Point : %p\n", last_trb->trb0_lo);
		}
	}

	return trb;
}

static xhci_trb_t* xhci_dequeue_trb(xhci_trb_ring_t *ring)
{
	xhci_trb_t *trb;
	int cycle_bit;

	/* This function is only needed for event ring in software */
	if(ring->type != XHCI_TRB_RING_TYPE_EVENT)
		return NULL;

	trb = &ring->queue[ring->deq_idx];
	cycle_bit = (trb->trb3&XHCI_TRB3_C) ? 1 : 0;
	if(ring->cycle_state != cycle_bit)
		return NULL;

	ring->deq_idx++;
	if(ring->deq_idx == ring->queue_size) {
		XHCI_DEBUG("^r^End of event trb\n");
		ring->deq_idx = 0;
		ring->cycle_state ^= 1;		/* Toggle Cycle bit */
	}

	return trb;
}

static xhci_trb_t* xhci_get_trb(xhci_trb_ring_t *ring)
{
	if(ring->type == XHCI_TRB_RING_TYPE_EVENT) return &ring->queue[ring->deq_idx];
	else return &ring->queue[ring->enq_idx];
}

#ifdef DUMP_XHCI_INFO
static void xhci_dump_regs(xhci_t *xhci)
{
	u32 v;

	XHCI_INFO("Capability Reg Base : 0x%08x\n", (u32)xhci->regs.cap_reg);

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCCAPBASE);
	XHCI_INFO("CAPLENGTH:%d\n", XHCI_CAPLENGTH(v));
	XHCI_INFO("HCIVERSION:%d.%d\n", XHCI_HCIVERSION_MAJOR(v), XHCI_HCIVERSION_MINOR(v));

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCSPARAMS1);
	XHCI_INFO("HCSPARAMS1 : 0x%08x\n", v);
	XHCI_INFO("  Number of Device Slots : %d\n", XHCI_HCS1_MAX_SLOTS(v));
	XHCI_INFO("  Number of Interrupters : %d\n", XHCI_HCS1_MAX_INTRS(v));
	XHCI_INFO("  Number of Ports : %d\n", XHCI_HCS1_MAX_PORTS(v));

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCSPARAMS2);
	XHCI_INFO("HCSPARAMS2 : 0x%08x\n", v);
	XHCI_INFO("  Isochronous Scheduling Threshold : %d\n", XHCI_HCS2_IST(v));
	XHCI_INFO("  Event Ring Segment Table Max : %d(%d)\n", XHCI_HCS2_ERST_MAX(v), 0x1 << XHCI_HCS2_ERST_MAX(v));
	XHCI_INFO("  Scratchpad Restore : %d\n", XHCI_HCS2_SPR(v));
	XHCI_INFO("  Max Scratchpad Buffers : %d\n", XHCI_HCS2_MSB(v));

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCSPARAMS3);
	XHCI_INFO("HCSPARAMS3 : 0x%08x\n", v);
	XHCI_INFO("  U1 Device Exit Latency : %d\n", XHCI_HCS3_U1_DEL(v));
	XHCI_INFO("  U2 Device Exit Latency : %d\n", XHCI_HCS3_U2_DEL(v));

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCCPARAMS);
	XHCI_INFO("HCCPARAMS : 0x%08x\n", v);
	XHCI_INFO("  64-bit Addressing Capability : %d\n", XHCI_HCC_AC64(v));
	XHCI_INFO("  BW Negotiation Capability : %d\n", XHCI_HCC_BNC(v));
	XHCI_INFO("  Context Size : %d(%d byte)\n", XHCI_HCC_CSZ(v), XHCI_HCC_CSZ(v) ? 64 : 32 );
	XHCI_INFO("  Port Power Control : %d\n", XHCI_HCC_PPC(v));
	XHCI_INFO("  xHCI Extended Capabilities Pointer : 0x%x\n", XHCI_HCC_XECP(v));

	if(XHCI_HCC_XECP(v) != 0) {
		u32 *ptr;
		u32 val, next, count = 0;
		XHCI_INFO("Extended Capabilities\n");
		ptr = (u32*)xhci->regs.base_reg + XHCI_HCC_XECP(v);
		while(1) {
			val = USB_REG_READ(ptr);
			next = XHCI_EXT_NEXT_POINTER(val);
			if(XHCI_EXT_CAP_ID(val) == XHCI_EXT_CAP_ID_SUPPORTED_PROTOCOL) {
				XHCI_INFO("  Port Information[%d]\n", count); count++;
				XHCI_INFO("    Revision : %d.%d\n", XHCI_EXT_SPC_MAJOR(val), XHCI_EXT_SPC_MINOR(val));
				val = USB_REG_READ(ptr + 1);
				XHCI_INFO("    Name String : %08x\n", val);
				val = USB_REG_READ(ptr + 2);
				XHCI_INFO("    Port Offset : %d, Port Count : %d, Protocol Defined : 0x%03x, PSIC:%d\n",
					XHCI_EXT_SPC_PORT_OFFSET(val), XHCI_EXT_SPC_PORT_COUNT(val),
					XHCI_EXT_SPC_PROTO_DEFINED(val), XHCI_EXT_SPC_PSIC(val));
			}
			if(next == 0) break;
			ptr += next;
		}
	}

	v = XHCI_CAP_REG_READ(xhci, XHCI_DBOFF);
	XHCI_INFO("Doorbell Array Offset : 0x%x\n", v);

	v = XHCI_CAP_REG_READ(xhci, XHCI_RTSOFF);
	XHCI_INFO("Runtime Register Space Offset : 0x%x\n", v);

}
#else
static void xhci_dump_regs(xhci_t *xhci){}
#endif

/* The xHC shall halt within 16 ms. after software clears the Run/Stop bit */
#define XHCI_HALT_TIME		(16 + 10)

static int xhci_start(usb_hcd_t *hcd)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;
	int i;
	uint32_t v, size;
	union xhci_u64 v64;


	xhci->regs.cap_reg	= (xhci_cap_reg_t*)((unsigned long)xhci->regs.base_reg + 0x00);

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCCAPBASE);
	xhci->regs.op_reg	= (xhci_op_reg_t*)((unsigned long)xhci->regs.cap_reg + XHCI_CAPLENGTH(v));

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCSPARAMS1);
	xhci->num_ports = XHCI_HCS1_MAX_PORTS(v);
	xhci->num_slots = XHCI_HCS1_MAX_SLOTS(v);

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCSPARAMS2);
	xhci->num_sb	= XHCI_HCS2_MSB(v);

	v = XHCI_CAP_REG_READ(xhci, XHCI_HCCPARAMS);
	xhci->context_size	= (XHCI_HCC_CSZ(v) ? 64 : 32);

	v = XHCI_CAP_REG_READ(xhci, XHCI_RTSOFF);
	xhci->regs.rt_reg = (xhci_rt_reg_t*)((unsigned long)xhci->regs.cap_reg + XHCI_RTSOFF_GET(v));

	v = XHCI_CAP_REG_READ(xhci, XHCI_DBOFF);
	xhci->regs.db_reg = (xhci_db_reg_t*)((unsigned long)xhci->regs.cap_reg + XHCI_DBOFF_GET(v));

	XHCI_INFO("Operation Reg Base : 0x%08x\n", (u32)xhci->regs.op_reg);
	XHCI_INFO("Runtime   Reg Base : 0x%08x\n", (u32)xhci->regs.rt_reg);
	XHCI_INFO("Doorbell  Reg Base : 0x%08x\n", (u32)xhci->regs.db_reg);

	xhci_dump_regs(xhci);

	/* 4.2 Host Controller Initialization */

	/* Software should not set HCRESET bit to a one when the HCHalted bit in the USBSTS register
	 * is a zero */
	XHCI_OP_REG_WRITE(xhci, XHCI_USBCMD, 0);
	if(xhci_wait_status(xhci, XHCI_USBSTS, XHCI_USBSTS_HCH, XHCI_USBSTS_HCH, XHCI_HALT_TIME) < 0) {
		XHCI_ERROR("Not Halted\n");
		return -1;
	}

	/* After HCRESET, all of the operational registers will be at their default values */
	XHCI_OP_REG_WRITE(xhci, XHCI_USBCMD, XHCI_USBCMD_HCRST);
	if(xhci_wait_status(xhci, XHCI_USBCMD, XHCI_USBCMD_HCRST, 0, 1000) < 0)	{
		XHCI_ERROR("Reset timeout\n");
		return -1;
	}
	v = XHCI_OP_REG_READ(xhci, XHCI_USBCMD);
	XHCI_INFO("USBCMD default value : 0x%08x\n", v);

	if(xhci_wait_status(xhci, XHCI_USBSTS, XHCI_USBSTS_CNR, 0, 100) < 0) {
		XHCI_ERROR("Contoller Not Ready\n");
		return -1;
	}

	v = XHCI_OP_REG_READ(xhci, XHCI_PAGESIZE);
	for(i=0; i<16; i++)	{
		if(v & (0x1 << i)) break;
	}
	xhci->page_shift = i + 12;
	xhci->page_size = 0x1 << xhci->page_shift;
	XHCI_INFO("Page Size:%d, Shift:%d\n", xhci->page_size, xhci->page_shift);

	/* Program the Max Device Slots Enabled field in the CONFIG register */
	XHCI_OP_REG_WRITE(xhci, XHCI_CONFIG, xhci->num_slots);

	/* Allocate the DCBAAP Memory */
	size = sizeof(xhci_dcba_t) * xhci->num_slots;
	xhci->dcbaa = dmalloc_align(size, 2048);
	memset(xhci->dcbaa, 0, size);
	XHCI_DEBUG("DCBAAP : %p, size:%d\n", xhci->dcbaa, size);

	/* Allocate Scratchpad Buffer Array */
	if(xhci->num_sb) {
	#if 0
		size = sizeof(xhci_sbba_t) * xhci->num_sb;
		xhci->sba = dmalloc_align(size, 64);
		memset(xhci->sba, 0, size);
		xhci->dcbaa[0].dcba = (u32)xhci->sba;
	#endif
		// TODO: if Scratchpad buffer is needed then allocate memory in here
	}

	/* Program the DCBAAP register */
	v64.val = (ulong)xhci->dcbaa;
	XHCI_OP_REG_WRITE64(xhci, XHCI_DCBAAP, v64);

	/* Allocate the Command Ring */
	xhci->command_ring = xhci_alloc_trb_ring(XHCI_TRB_RING_TYPE_COMMAND);
	XHCI_DEBUG("Command Ring : 0x%08x\n", xhci->command_ring->queue);


	v64.val = (ulong)xhci->command_ring->queue | XHCI_CRCR_RCS;
	XHCI_OP_REG_WRITE64(xhci, XHCI_CRCR, v64);	/* Reading this register always returns '0' except CRR bit */
	XHCI_DEBUG("CRCR : 0x%llx\n", v64.val);


	/* Set Event Ring Segment Table */
	xhci->event_ring = xhci_alloc_trb_ring(XHCI_TRB_RING_TYPE_EVENT);

	size = (sizeof(xhci_erst_t) * XHCI_NUM_ERST);
	xhci->erst = (xhci_erst_t*)dmalloc_align(size, 64);
	memset(xhci->erst, 0, size);

	xhci->erst[0].addr = (ulong)xhci->event_ring->queue;
	xhci->erst[0].size = XHCI_MAX_EVENT_TRBS;


	XHCI_RT_REG_WRITE(xhci, XHCI_ERSTSZ(0), XHCI_NUM_ERST);
	v64.val = (ulong)xhci->erst;
	XHCI_RT_REG_WRITE64(xhci, XHCI_ERSTBA(0), v64);

	v64.val = (ulong)xhci->event_ring->queue;
	XHCI_RT_REG_WRITE64(xhci, XHCI_ERDP(0), v64);

	XHCI_DEBUG("Event Ring Segement Table : 0x%08x\n", xhci->erst);
	XHCI_DEBUG("Event Ring[0] : 0x%08x\n", xhci->event_ring->queue);


	/* Set Interrupter Registers */
	XHCI_RT_REG_WRITE(xhci, XHCI_IMAN(0), XHCI_IMAN_IE);

	/* Disable device notifications */
	XHCI_OP_REG_WRITE(xhci, XHCI_DNCTRL, 0);


	/* Start Controller */
	v = XHCI_OP_REG_READ(xhci, XHCI_USBCMD);
	v |= (XHCI_USBCMD_RUN | XHCI_USBCMD_INTE | XHCI_USBCMD_HSEE);
	XHCI_OP_REG_WRITE(xhci, XHCI_USBCMD, v);
	if(xhci_wait_status(xhci, XHCI_USBSTS, XHCI_USBSTS_HCH, 0, XHCI_HALT_TIME) < 0) {
		XHCI_ERROR("Can't start the controller\n");
		return -1;
	}
	XHCI_INFO("Start Controller. 0x%08x\n", XHCI_OP_REG_READ(xhci, XHCI_USBCMD));

	return 0;
}

static void xhci_stop(usb_hcd_t *hcd)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;

	XHCI_OP_REG_WRITE(xhci, XHCI_USBCMD, 0);
	if(xhci_wait_status(xhci, XHCI_USBSTS, XHCI_USBSTS_HCH, XHCI_USBSTS_HCH, XHCI_HALT_TIME) < 0) {
		XHCI_ERROR("Not Halted\n");
	}

	XHCI_OP_REG_WRITE(xhci, XHCI_USBCMD, XHCI_USBCMD_HCRST);
	if(xhci_wait_status(xhci, XHCI_USBCMD, XHCI_USBCMD_HCRST, 0, 1000) < 0)	{
		XHCI_ERROR("Reset timeout\n");
	}
	XHCI_INFO("XHCI(%x) STOP\n", xhci->regs.base_reg);
}

static int xhci_rh_transfer(usb_hcd_t *hcd, usb_req_t* req, usb_device_request_t* dev_req)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;
	usb_hub_status_t *hub_status;
	usb_port_status_t *port_status;
	usb_hub_desc_t *hub_desc;
	u32 status, portsc;
	u8 data[128];
	u16 wValue, wIndex;
	int len = 0;
	u8 *ptr = data;

	wValue = dev_req->wValue;
	wIndex = dev_req->wIndex;

#define OP(r, rt)	((u16)(r) << 8 | (rt))
	switch(OP(dev_req->bRequest, dev_req->bmRequestType)) {
		case OP(USB_HUB_REQ_GET_STATUS,	USB_REQTYPE_DIR_IN | USB_REQTYPE_HUB):
			hub_status = (usb_hub_status_t*)data;

			hub_status->wHubStatus = USB_HUB_STATUS_LPS;
			hub_status->wHubChange = 0;

			len = sizeof(usb_hub_status_t);
			break;
		case OP(USB_HUB_REQ_GET_STATUS, USB_REQTYPE_DIR_IN | USB_REQTYPE_PORT):
			if(wIndex < 1 || wIndex > xhci->num_ports) goto invalid;
			port_status = (usb_port_status_t*)data;
			status = XHCI_OP_REG_READ(xhci, XHCI_PORTSC(wIndex));

			port_status->wPortStatus = 0;
			port_status->wPortChange = 0;

			//XHCI_DEBUG("port[%d] get status : 0x%x\n", wIndex, status);

			if((status&XHCI_PORTSC_CCS)) {
				port_status->wPortStatus |= USB_PORT_STATUS_CONNECT;
				switch(XHCI_PORTSC_PS(status)) {
					case XHCI_SPEED_FULL: port_status->wPortStatus	|= USB_PORT_STATUS_3_SPEED_FULL; break;
					case XHCI_SPEED_LOW: port_status->wPortStatus	|= USB_PORT_STATUS_3_SPEED_LOW; break;
					case XHCI_SPEED_HIGH: port_status->wPortStatus	|= USB_PORT_STATUS_3_SPEED_HIGH; break;
					case XHCI_SPEED_SUPER: port_status->wPortStatus	|= USB_PORT_STATUS_3_SPEED_SUPER; break;
				}
			}
			if((status&XHCI_PORTSC_PED))	port_status->wPortStatus |= USB_PORT_STATUS_ENABLED;
			switch(XHCI_PORTSC_PLS(status)) {
				case XHCI_PORTSC_PLS_U3:	port_status->wPortStatus |= USB_PORT_STATUS_SUSPEND;
			}
			if((status&XHCI_PORTSC_PR))		port_status->wPortStatus |= USB_PORT_STATUS_RESET;
			if((status&XHCI_PORTSC_PP)) 	port_status->wPortStatus |= USB_PORT_STATUS_POWER;

			if((status&XHCI_PORTSC_CSC))	port_status->wPortChange |= USB_PORT_CHANGE_CONNECT;
			if((status&XHCI_PORTSC_PEC))	port_status->wPortChange |= USB_PORT_CHANGE_ENABLED;
			if((status&XHCI_PORTSC_OCC))	port_status->wPortChange |= USB_PORT_CHANGE_OCURRENT;
			if((status&XHCI_PORTSC_PRC))	port_status->wPortChange |= USB_PORT_CHANGE_RESET;

			len = sizeof(usb_port_status_t);
			break;
		case OP(USB_HUB_REQ_CLEAR_FEATURE, USB_REQTYPE_DIR_OUT | USB_REQTYPE_PORT):
			if(wIndex < 1 || wIndex > xhci->num_ports) goto invalid;

			portsc = XHCI_PORTSC(wIndex);
			status = XHCI_OP_REG_READ(xhci, portsc);
			XHCI_DEBUG("port[%d] clear feature[%d]. status=0x%x\n", wIndex, wValue, status);
			status &= XHCI_PORTSC_CLEAR;
			switch(wValue) {
				case USB_PORT_FEATURE_ENABLE:	status |= XHCI_PORTSC_PED; break;
				case USB_PORT_FEATURE_SUSPEND:	status |= XHCI_PORTSC_PLC; break;
				case USB_PORT_FEATURE_C_CONNECTION:	status |= XHCI_PORTSC_CSC; break;
				case USB_PORT_FEATURE_C_ENABLE:	status |= XHCI_PORTSC_PEC; break;
				case USB_PORT_FEATURE_C_OVER_CURRENT:	status |= XHCI_PORTSC_OCC; break;
				case USB_PORT_FEATURE_C_RESET: goto done;
				default: goto invalid;
			}
			XHCI_OP_REG_WRITE(xhci, portsc, status);

			status = XHCI_OP_REG_READ(xhci, portsc);
			XHCI_DEBUG("after port clear feaure. status : 0x%x\n", status);
			break;
		case OP(USB_HUB_REQ_SET_FEATURE, USB_REQTYPE_DIR_OUT | USB_REQTYPE_PORT):
			if(wIndex < 1 || wIndex > xhci->num_ports) goto invalid;

			portsc = XHCI_PORTSC(wIndex);
			status = XHCI_OP_REG_READ(xhci, portsc);

			XHCI_DEBUG("USB_HUB_REQ_SET_FEATURE(USB_REQTYPE_PORT). status=0x%08x\n", status);
			status &= XHCI_PORTSC_CLEAR;

			switch(wValue) {
				case USB_PORT_FEATURE_ENABLE:
					XHCI_OP_REG_WRITE(xhci, portsc, status | XHCI_PORTSC_PED); break;
				case USB_PORT_FEATURE_POWER:
					XHCI_OP_REG_WRITE(xhci, portsc, status | XHCI_PORTSC_PP); break;
				case USB_PORT_FEATURE_RESET:
					XHCI_OP_REG_WRITE(xhci, portsc, status | XHCI_PORTSC_PR);
					status = XHCI_OP_REG_READ(xhci, portsc);
					XHCI_DEBUG("  After RESET. status:0x%08x\n", status);
					break;
				default: goto invalid;
			}
			break;
		case OP(USB_REQUEST_GET_DESCRIPTOR,
				USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			switch(wValue >> 8) {
				case USB_DESCRIPTOR_TYPE_DEVICE:
					ptr = (u8*)&xhci_rh_dev_desc;
					len = sizeof(xhci_rh_dev_desc);
					break;

				case USB_DESCRIPTOR_TYPE_CONFIGURATION:
					memcpy(ptr, &xhci_rh_cfg_desc, sizeof(usb_config_desc_t));
					len += sizeof(usb_config_desc_t);
					memcpy(ptr + len, &xhci_rh_if_desc, sizeof(usb_interface_desc_t));
					len += sizeof(usb_interface_desc_t);
					memcpy(ptr + len, &xhci_rh_ep_desc, sizeof(usb_endpoint_desc_t));
					len += sizeof(usb_endpoint_desc_t);
					break;
			}
			break;
		case OP(USB_REQUEST_GET_DESCRIPTOR, USB_REQTYPE_DIR_IN | USB_REQTYPE_HUB):
			hub_desc = (usb_hub_desc_t*)data;

			XHCI_DEBUG("USB_REQUEST_GET_DESCRIPTOR(USB_REQTYPE_TYPE_CLASS). wValue=0x%x\n", wValue);

			memcpy(hub_desc, &xhci_rh_hub_desc, sizeof(xhci_rh_hub_desc));
			hub_desc->bNbrPorts = xhci->num_ports;

			len = sizeof(usb_hub_desc_t);
			break;
		case OP(USB_REQUEST_SET_ADDRESS,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			XHCI_DEBUG("USB_REQUEST_SET_ADDRESS. wValue=%d\n", wValue);
			xhci->roothub_addr = wValue;
			break;
		case OP(USB_REQUEST_SET_CONFIGURATION,
				USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_DEVICE):
			XHCI_DEBUG("USB_REQUEST_SET_CONFIGURATION. wValue=%d\n", wValue);
			break;

		default:
			goto undefined;

	}

done:
	if(len > 0) {
		len = min(len, req->size);
		memcpy(req->dma_buf, ptr, len);
	#ifdef USE_USB_CACHED_BUFFER
		dcache_clean_range((unsigned long)req->dma_buf, len);
	#endif
	}

	req->xfer_len = len;
	req->status = USB_REQ_STATUS_DONE;

	return len;

undefined:
	XHCI_ERROR("Not implemented request[0x%04x]\n", OP(dev_req->bRequest, dev_req->bmRequestType));
	return -1;

invalid:
	XHCI_ERROR("Invalid param : request[0x%04x], wValue:%d, wIndex:%d, wLength:%d \n",
			OP(dev_req->bRequest, dev_req->bmRequestType),
			dev_req->wValue, dev_req->wIndex, dev_req->wLength);
	return -1;
}



static xhci_xfer_t* xhci_add_xfer(xhci_device_t *xhci_device, xhci_trb_ring_t *ring, usb_req_t* req)
{
	xhci_xfer_t *xfer;

	xfer			= (xhci_xfer_t*)calloc(1, sizeof(xhci_xfer_t));
	xfer->ep_ring	= ring;
	xfer->req		= req;

	list_insert_tail(&xhci_device->xfer_head, xfer, link);

	return xfer;
}

static void xhci_remove_xfer(xhci_device_t *xhci_device, xhci_xfer_t *xfer)
{
	list_remove(&xhci_device->xfer_head, xfer, link);
	free(xfer);
}

static int xhci_proc_xfer(xhci_t *xhci, xhci_trb_t* event_trb)
{
	int slot_id, ep_idx;
	u32 trb2, trb3;
	xhci_device_t *xhci_device;
	xhci_ep_ctx_t *ep_ctx;
	xhci_trb_ring_t	*ep_ring;

	int len, completion;
	u32 xfer_size;
	xhci_xfer_t *xfer, *_xfer;
	usb_req_t	*req;


	trb2 = event_trb->trb2;
	trb3 = event_trb->trb3;

	slot_id = XHCI_TRB3_SLOT_ID(trb3);
	if(xhci->device[slot_id] == NULL) {
		XHCI_DEBUG("Not allocated slot\n");
		return -1;
	}
	xhci_device = xhci->device[slot_id];

	ep_idx = XHCI_TRB3_EP_ID(trb3) - 1;
	if(ep_idx < 0 || ep_idx > 31) {
		XHCI_DEBUG("Invalid EP ID\n");
		return -1;
	}
	ep_ctx = xhci_device->dev_ctx.ep[ep_idx];
	ep_ring = xhci_device->ep_ring[ep_idx];

	XHCI_DEBUG("EP_IDX[%d], STATUS:%d\n", ep_idx, XHCI_EP_CTX0_EP_STATE(ep_ctx->ep_ctx0));

	completion = XHCI_TRB2_COMPLETION_CODE(trb2);
	len = XHCI_TRB2_TRANSFER_LEN(trb2);
	XHCI_DEBUG("Completion CODE[%d], Transfer Length:%d\n", completion, len);

	XHCI_DEBUG("TRB Pointer : %p\n", event_trb->trb0_lo);

	list_foreach_safe(&xhci_device->xfer_head, link, xfer, _xfer) {
		if(xfer->ep_ring == ep_ring) {
			// Not completed....
			if(event_trb->trb0_lo != (ulong)xfer->last_trb) {
				XHCI_DEBUG("Not completed...\n");
				continue;
			}

			req = xfer->req;
			xfer_size = req->size - len;

			req->xfer_len = xfer_size;
			req->status = USB_REQ_STATUS_DONE;

			xhci_remove_xfer(xhci_device, xfer);
			if(req->callback) req->callback(req);
		}
	}

	return 0;
}

static int xhci_poll(xhci_t *xhci)
{
	u32 trb2, trb3;
	int trb_type;
	xhci_trb_t *event_trb;
	union xhci_u64 v64;
	xhci_trb_ring_t *event_ring;

	event_ring = xhci->event_ring;
	while(1) {
		event_trb = xhci_dequeue_trb(event_ring);
		if(event_trb == NULL) break;

		trb2 = event_trb->trb2;
		trb3 = event_trb->trb3;

		trb_type = XHCI_TRB3_TYPE(trb3);
		switch(trb_type) {
			case XHCI_TRB_TYPE_TRANSFER:
				XHCI_DEBUG("TRANSFER EVENT\n");
				xhci_proc_xfer(xhci, event_trb);
				break;
			case XHCI_TRB_TYPE_CMD_COMPLETION:
				XHCI_DEBUG("COMMAND COMPLETION EVENT\n");
				if(xhci->command.trb == (xhci_trb_t*)(ulong)event_trb->trb0_lo) {
					if(XHCI_TRB2_COMPLETION_CODE(trb2) != XHCI_TRB_CODE_SUCCESS) {
						xhci->command.result = XHCI_TRB2_COMPLETION_CODE(trb2);
						xhci->command.status = XHCI_COMMAND_STATUS_ERROR;
					} else {
						xhci->command.result = trb3;
						xhci->command.status = XHCI_COMMAND_STATUS_DONE;
					}
				}
				break;
			case XHCI_TRB_TYPE_PORT_STATUS_CHANGE:
				XHCI_DEBUG("PORT STATUS CHANGE EVENT. PORT_ID:%d\n", XHCI_TRB0_PORT_ID(event_trb->trb0_lo));
				break;

			default:
				XHCI_DEBUG("Unknown TRB[%d]\n", trb_type);
				break;
		}
	}

	v64.val = (ulong)xhci_get_trb(event_ring) | XHCI_ERDP_SET_DESI(0) | XHCI_ERDP_EHB;
	XHCI_RT_REG_WRITE64(xhci, XHCI_ERDP(0), v64);

	return 0;
}


static int xhci_command(xhci_t *xhci, xhci_trb_t *trb, int timeout)
{
	xhci_trb_ring_t *cmd_ring;
	timeout_id_t tid;

	cmd_ring = xhci->command_ring;
	if(cmd_ring->cycle_state) trb->trb3 |= XHCI_TRB3_C;

	xhci->command.trb = xhci_enqueue_trb(cmd_ring, trb);
	xhci->command.status = XHCI_COMMAND_STATUS_RUN;

	XHCI_DEBUG("xhci_command. idx=%d\n", cmd_ring->enq_idx);
	XHCI_DEBUG("TRB0:0x%llx, TRB2:0x%08x, TRB3:0x%08x\n", trb->trb0, trb->trb2, trb->trb3);

	XHCI_DB_REG_WRITE(xhci, XHCI_DB_HOST_CONTROLLER, XHCI_DB_TARGET_COMMAND);

	set_timeout(&tid, timeout);
	while(!is_timeout(&tid)) {
		xhci_poll(xhci);
		if(xhci->command.status != XHCI_COMMAND_STATUS_RUN) {
			XHCI_DEBUG("Command Done. STATUS:%d, RESULT:0x%08x\n",
				xhci->command.status, xhci->command.result);
			return 0;
		}
		usleep(100);
	}

	return -1;
}

static int xhci_get_usb_speed(usb_device_t *dev)
{
	switch(dev->speed) {
		case USB_SPEED_LOW:		return XHCI_SPEED_LOW;
		case USB_SPEED_FULL:	return XHCI_SPEED_FULL;
		case USB_SPEED_HIGH:	return XHCI_SPEED_HIGH;
		case USB_SPEED_SUPER:	return XHCI_SPEED_SUPER;
	}
	return 0;
}

#ifdef XHCI_DEBUG_CONTEXT
static void xhci_print_input_ctx(xhci_input_ctx_t *in_ctx)
{
	int i;

	XHCI_DEBUG("#### Input Context @%p ####\n", in_ctx->ptr);

	XHCI_DEBUG("Input Control Context @%p\n", in_ctx->ctrl);
	XHCI_DEBUG("  drop_ctx_flags : 0x%08x \n", in_ctx->ctrl->drop_ctx_flags);
	XHCI_DEBUG("  add_ctx_flags : 0x%08x \n", in_ctx->ctrl->add_ctx_flags);

	XHCI_DEBUG("Slot Context @%p\n", in_ctx->slot);
	XHCI_DEBUG("  ctx0:0x%08x\n", in_ctx->slot->slot_ctx0);
	XHCI_DEBUG("  ctx1:0x%08x\n", in_ctx->slot->slot_ctx1);
	XHCI_DEBUG("  ctx2:0x%08x\n", in_ctx->slot->slot_ctx2);
	XHCI_DEBUG("  ctx3:0x%08x\n", in_ctx->slot->slot_ctx3);

	for(i=0; i<4; i++) {	// only display 4 EPs
		XHCI_DEBUG("EP[%d] Context @%p\n", i, in_ctx->ep[i]);
		XHCI_DEBUG("  ctx0: 0x%08x \n", in_ctx->ep[i]->ep_ctx0);
		XHCI_DEBUG("    ep state : %d\n", XHCI_EP_CTX0_EP_STATE(in_ctx->ep[i]->ep_ctx0));
		XHCI_DEBUG("  ctx1: 0x%08x \n", in_ctx->ep[i]->ep_ctx1);
		XHCI_DEBUG("  ctx2: 0x%08llx \n", in_ctx->ep[i]->ep_ctx2);
		XHCI_DEBUG("  ctx4: 0x%08x \n", in_ctx->ep[i]->ep_ctx4);
	}

}

static void xhci_print_device_ctx(xhci_device_ctx_t *dev_ctx)
{
	int i;

	XHCI_DEBUG("#### Device Context @%p ####\n", dev_ctx->ptr);

	XHCI_DEBUG("Slot Context @%p\n", dev_ctx->slot);
	XHCI_DEBUG("  ctx0:0x%08x\n", dev_ctx->slot->slot_ctx0);

	XHCI_DEBUG("  ctx1:0x%08x\n", dev_ctx->slot->slot_ctx1);
	XHCI_DEBUG("  ctx2:0x%08x\n", dev_ctx->slot->slot_ctx2);
	XHCI_DEBUG("  ctx3:0x%08x\n", dev_ctx->slot->slot_ctx3);
	XHCI_DEBUG("    Device Address : %d\n", XHCI_SLOT_CTX3_DEV_ADDRESS(dev_ctx->slot->slot_ctx3));
	XHCI_DEBUG("    Slot State : %d\n", XHCI_SLOT_CTX3_SLOT_STATE(dev_ctx->slot->slot_ctx3));

	for(i=0; i<4; i++) {	// only display 4 EPs
		XHCI_DEBUG("EP[%d] Context @%p\n", i, dev_ctx->ep[i]);
		XHCI_DEBUG("  ctx0: 0x%08x \n", dev_ctx->ep[i]->ep_ctx0);
		XHCI_DEBUG("    ep state : %d\n", XHCI_EP_CTX0_EP_STATE(dev_ctx->ep[i]->ep_ctx0));
		XHCI_DEBUG("  ctx1: 0x%08x \n", dev_ctx->ep[i]->ep_ctx1);
		XHCI_DEBUG("  ctx2: 0x%08llx \n", dev_ctx->ep[i]->ep_ctx2);
		XHCI_DEBUG("  ctx4: 0x%08x \n", dev_ctx->ep[i]->ep_ctx4);
	}
}
#else
static void xhci_print_input_ctx(xhci_input_ctx_t *in_ctx){}
static void xhci_print_device_ctx(xhci_device_ctx_t *dev_ctx){}
#endif

static int xhci_get_roothub_port(usb_device_t *dev)
{
	usb_device_t *root_dev;
	for(root_dev=dev; root_dev->parent && root_dev->parent->parent; root_dev=root_dev->parent);
	return root_dev->port;
}

static int xhci_slot_init(xhci_t *xhci, usb_device_t *dev, int slot_id)
{
	xhci_device_t *xhci_device;
	xhci_input_ctx_t *in_ctx;
	xhci_device_ctx_t *dev_ctx;
	xhci_ep_ctx_t *ep0_ctx;
	int i, size;
	u32 v;

	XHCI_DEBUG("Slot[%d] Initialization\n", slot_id);

	if(xhci->device[slot_id] != NULL) {
		XHCI_ERROR("Already allocated slot !!!\n");
		return -1;
	}

	xhci_device = (xhci_device_t*)malloc(sizeof(xhci_device_t));
	memset(xhci_device, 0, sizeof(xhci_device_t));

	/* 4.3.3 Device Slot Initialization */
	/* 1) Allocate an Input Context data structure and initialize all fields to '0' */
	in_ctx = &xhci_device->in_ctx;

	size = xhci->context_size * 33;		/* Input Control Context + Slot Context + EP Context(31) */
	in_ctx->ptr = dmalloc_align(size, 2048);
	memset(in_ctx->ptr, 0, size);

	in_ctx->ctrl = (xhci_input_ctrl_ctx_t*)(in_ctx->ptr + 0);
	in_ctx->slot = (xhci_slot_ctx_t*)(in_ctx->ptr + (xhci->context_size * 1));
	for(i=0; i<31; i++) {
		in_ctx->ep[i] = (xhci_ep_ctx_t*)(in_ctx->ptr + (xhci->context_size * (2+i)));
	}

	/* 2) Initialize Input Control Context by setting the A0 and A1 flags to '1' .
	 * A0 : Slot Context, A1 : EP0 Context
	 */
	in_ctx->ctrl->add_ctx_flags = (0x01 << 1) | (0x01 << 0);
	in_ctx->ctrl->drop_ctx_flags = 0;

	/* 3) Initialize Slot Context */
	v = XHCI_SLOT_CTX0_SET_ENTRIES(1);
	v |= XHCI_SLOT_CTX0_SET_SPEED(xhci_get_usb_speed(dev));
	in_ctx->slot->slot_ctx0 = v;
	in_ctx->slot->slot_ctx1 = XHCI_SLOT_CTX1_SET_ROOT_HUB_PORT(xhci_get_roothub_port(dev));

	/* If the device is a Low/Full-speed and connected through a High-speed hub */
	if(dev->parent && dev->parent->speed == USB_SPEED_HIGH &&
		(dev->speed == USB_SPEED_FULL || dev->speed == USB_SPEED_LOW))
	{
		xhci_device_t *xhci_hub_device = dev->parent->hw_priv;
		v = XHCI_SLOT_CTX2_SET_TT_HUB_SLOT(xhci_hub_device->slot_id);
		v |= XHCI_SLOT_CTX2_SET_TT_PORT_NUM(dev->port);
		in_ctx->slot->slot_ctx2 = v;
	}

	/* 4) Allocate and initialize the Transfer Ring for EP0 */
	xhci_device->ep_ring[0] = xhci_alloc_trb_ring(XHCI_TRB_RING_TYPE_TRANSFER);

	/* 5) initialize the EP0 Context */
	ep0_ctx = in_ctx->ep[0];

	v  = XHCI_EP_CTX1_EP_TYPE_CONTROL;
	v |= XHCI_EP_CTX1_SET_MPS(dev->pipes[0]->mps);
	v |= XHCI_EP_CTX1_SET_MBS(0);
	v |= XHCI_EP_CTX1_SET_CERR(3);
	ep0_ctx->ep_ctx1 = v;
	ep0_ctx->ep_ctx2_lo = (ulong)xhci_device->ep_ring[0]->queue | XHCI_EP_CTX2_DCS;


	/* 6) Allocate the output Device Context data structure and initialize it to '0' */
	dev_ctx = &xhci_device->dev_ctx;
	size = xhci->context_size * 32;		/* Slot Context + EP Context(31) */
	dev_ctx->ptr = dmalloc_align(size, 2048);
	memset(dev_ctx->ptr, 0, size);

	dev_ctx->slot = (xhci_slot_ctx_t*)(dev_ctx->ptr + 0);
	for(i=0; i<31; i++) {
		dev_ctx->ep[i] = (xhci_ep_ctx_t*)(dev_ctx->ptr + (xhci->context_size * (1+i)));
	}

	/* 7) Load the appropriate entry in the DCBAA with a pointer to the Device Context */
	xhci->dcbaa[slot_id].dcba = (ulong)dev_ctx->ptr;

	xhci_device->slot_id = slot_id;
	xhci->device[slot_id] = xhci_device;

	dev->hw_priv = xhci_device;

	list_init_head(&xhci_device->xfer_head);

	return 0;
}

static int xhci_device_init(usb_hcd_t *hcd, usb_device_t *dev)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;

	xhci_trb_t trb;
	int slot_id;

	XHCI_DEBUG("\n### xhci_device_init\n");

	/* 4.3.2 Device Slot Assignment */
	memset(&trb, 0, sizeof(xhci_trb_t));
	trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_ENABLE_SLOT);

	if(xhci_command(xhci, &trb, 1000) < 0)
		return -1;

	if(xhci->command.status == XHCI_COMMAND_STATUS_ERROR) {
		XHCI_DEBUG("Completion Code[%d]\n", xhci->command.result);
		return -1;
	}
	XHCI_DEBUG("VF ID[%d]\n", XHCI_TRB3_VF_ID(xhci->command.result));
	XHCI_DEBUG("Slot ID[%d]\n", XHCI_TRB3_SLOT_ID(xhci->command.result));

	slot_id = XHCI_TRB3_SLOT_ID(xhci->command.result);

	return xhci_slot_init(xhci, dev, slot_id);
}

static int xhci_device_deinit(usb_hcd_t *hcd, usb_device_t *dev)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;

	xhci_device_t *xhci_device;
	xhci_trb_t trb;
	int i;

	XHCI_DEBUG("\n### xhci_device_deinit\n");

	xhci_device = dev->hw_priv;
	if(xhci_device == NULL) return -1;

	/* Disable Slot */
	memset(&trb, 0, sizeof(xhci_trb_t));
	trb.trb3 = XHCI_TRB3_SET_SLOT_ID(xhci_device->slot_id) |
				XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_DISABLE_SLOT);

	if(xhci_command(xhci, &trb, 1000) < 0)
		return -1;

	if(xhci->command.status == XHCI_COMMAND_STATUS_ERROR) {
		XHCI_ERROR("Completion Code[%d]\n", xhci->command.result);
		return -1;
	}

	/* Free allocated memory */
	xhci->dcbaa[xhci_device->slot_id].dcba = 0;

	for(i=0; i<32; i++) {
		if(xhci_device->ep_ring[i]) {
			xhci_free_trb_ring(xhci_device->ep_ring[i]);
			xhci_device->ep_ring[i] = NULL;
		}
	}

	if(xhci_device->dev_ctx.ptr) dfree(xhci_device->dev_ctx.ptr);
	if(xhci_device->in_ctx.ptr) dfree(xhci_device->in_ctx.ptr);

	xhci->device[xhci_device->slot_id] = NULL;

	free(xhci_device);

	dev->hw_priv = NULL;

	return 0;
}

static int xhci_set_address(usb_hcd_t *hcd, usb_device_t *dev, int addr)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;
	xhci_trb_t trb;
	int slot_id;
	xhci_device_t *xhci_device;
	xhci_input_ctx_t *in_ctx;
	xhci_device_ctx_t *dev_ctx;

	/* 4.3.4 Address Assigment
	 * 4.6.5 Address Device
	 */
	xhci_device = dev->hw_priv;
	if(xhci_device == NULL) return -1;

	XHCI_DEBUG("\n### xhci_set_address. slot_id=%d, addr=%d\n", xhci_device->slot_id, addr);


	slot_id = xhci_device->slot_id;
	in_ctx = &xhci_device->in_ctx;
	dev_ctx = &xhci_device->dev_ctx;

	xhci_print_input_ctx(in_ctx);

	memset(&trb, 0, sizeof(xhci_trb_t));
	trb.trb0_lo = (ulong)in_ctx->ptr;
	trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_ADDR_DEV) | XHCI_TRB3_SET_SLOT_ID(slot_id);

	if(xhci_command(xhci, &trb, 1000) < 0)
		return -1;

	if(xhci->command.status == XHCI_COMMAND_STATUS_ERROR) {
		XHCI_DEBUG("Completion Code[%d]\n", xhci->command.result);
		return -1;
	}

	xhci_print_device_ctx(dev_ctx);

	XHCI_DEBUG("Assigned address by xHC : %d\n", XHCI_SLOT_CTX3_DEV_ADDRESS(dev_ctx->slot->slot_ctx3));
	xhci_device->address = XHCI_SLOT_CTX3_DEV_ADDRESS(dev_ctx->slot->slot_ctx3) + 1;

	if(XHCI_SLOT_CTX3_SLOT_STATE(dev_ctx->slot->slot_ctx3) != XHCI_SLOT_STATE_ADDRESSED) {
		XHCI_DEBUG("Slot State is invalid !!!\n");
		return -1;
	}

	return 0;
}

static int xhci_device_config(usb_hcd_t *hcd, usb_device_t *dev)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;
	xhci_device_t *xhci_device;
	xhci_input_ctx_t *in_ctx;
	xhci_device_ctx_t *dev_ctx;
	xhci_input_ctrl_ctx_t *ctrl_ctx;
	xhci_slot_ctx_t *slot_ctx;
	xhci_ep_ctx_t *ep_ctx;
	usb_endpoint_desc_t *ep_desc;
	xhci_trb_t trb;
	int dci, max_dci;
	int num_ep;
	u32 v, add_ctx_flags;
	int i, idx;

	XHCI_DEBUG("\n### xhci_device_config ###\n");

	/* 4.3.5 Device Configuration */
	/* 4.6.6 Configure Endpoint */

	/* The state of both the USB Device and xHC Device Slot must be synchronized */
	xhci_device = dev->hw_priv;
	if(xhci_device == NULL) return -1;

	in_ctx = &xhci_device->in_ctx;
	dev_ctx = &xhci_device->dev_ctx;

	ctrl_ctx = in_ctx->ctrl;
	slot_ctx = in_ctx->slot;

	num_ep = dev->num_ep_desc;

	/* 4.5.1 Device Context Index
	 * DCI = ((Endpoint Number*2) + Direction(0:OUT,1:IN)
	 */
	max_dci = 1;
	add_ctx_flags = 0;
	for(i=0; i<num_ep; i++) {
		int addr_num, is_dir_input;

		ep_desc = dev->ep_desc[i];

		if((ep_desc->bmAttributes&USB_EP_ATTR) != USB_EP_ATTR_BULK) {
			XHCI_DEBUG("Skip endpoint type[%d]\n", (ep_desc->bmAttributes&USB_EP_ATTR));
			/* if we configure periodic endpoint like isoc,intrrupt than have to manage bandwidth */
			continue;
		}

		addr_num = USB_EP_ADDR_NUM(ep_desc->bEndpointAddress);
		is_dir_input = IS_USB_EP_IN(ep_desc->bEndpointAddress);

		if(addr_num == 0) { XHCI_DEBUG("Control EP ???\n"); continue; }
		dci = addr_num * 2 + (is_dir_input ? 1 : 0);
		add_ctx_flags |= (1 << dci);
		if(dci > max_dci) max_dci = dci;	/* Search the last valid EP Context */

		idx = dci - 1;		/* DCI 0 is Slot Context */

		/* Allocate and initialize the Transfer Ring for EPx */
		if(xhci_device->ep_ring[idx] != NULL) {
			XHCI_ERROR("Already allocated EP[%d]\n", idx);
			continue;
		}
		xhci_device->ep_ring[idx] = xhci_alloc_trb_ring(XHCI_TRB_RING_TYPE_TRANSFER);

		/* Initialize the EP Context */
		ep_ctx = in_ctx->ep[idx];

		v = is_dir_input ? XHCI_EP_CTX1_EP_TYPE_IN : XHCI_EP_CTX1_EP_TYPE_OUT;
		switch((ep_desc->bmAttributes&USB_EP_ATTR)) {
			case USB_EP_ATTR_ISOCHRONOUS:	v |= XHCI_EP_CTX1_EP_TYPE_ISOCH; break;
			case USB_EP_ATTR_BULK:			v |= XHCI_EP_CTX1_EP_TYPE_BULK; break;
			case USB_EP_ATTR_INTERRUPT:		v |= XHCI_EP_CTX1_EP_TYPE_INTR; break;
		}
		v |= XHCI_EP_CTX1_SET_MPS(ep_desc->wMaxPacketSize);
		v |= XHCI_EP_CTX1_SET_MBS(0);
		v |= XHCI_EP_CTX1_SET_CERR(3);
		ep_ctx->ep_ctx1 = v;
		ep_ctx->ep_ctx2_lo = (ulong)xhci_device->ep_ring[idx]->queue | XHCI_EP_CTX2_DCS;
	}
	ctrl_ctx->add_ctx_flags = add_ctx_flags;


	/* Update Context Entries.
	 * This field identifies the index of the last valid EP Context within the Device Context */
	v = slot_ctx->slot_ctx0;
	v &= ~XHCI_SLOT_CTX0_ENTRIES_MASK;
	v |= XHCI_SLOT_CTX0_SET_ENTRIES(max_dci);
	slot_ctx->slot_ctx0 = v;

	/* 6.2.2 Slot Context */
	/* All fields of the Slot Context shall be initialized to the appropriate value
	 * by software before issuing a command */
	slot_ctx->slot_ctx3 = dev_ctx->slot->slot_ctx3;		/* Update Slot State & Address */

	in_ctx->ep[0]->ep_ctx0 = dev_ctx->ep[0]->ep_ctx0;


	/* 6.4.3.5 Configure Endpoint Command TRB */
	memset(&trb, 0, sizeof(xhci_trb_t));
	trb.trb0_lo = (ulong)in_ctx->ptr;
	trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_CFG_EP) | XHCI_TRB3_SET_SLOT_ID(xhci_device->slot_id);

	if(xhci_command(xhci, &trb, 1000) < 0)
		return -1;

	if(xhci->command.status == XHCI_COMMAND_STATUS_ERROR) {
		XHCI_DEBUG("Completion Code[%d]\n", xhci->command.result);
		return -1;
	}
	XHCI_DEBUG("Configure Endpoint Success !!!\n");

#if 0	/* Do not check slot state because if we do not set any enpoint than the state is not changed to configured */
	if(XHCI_SLOT_CTX3_SLOT_STATE(dev_ctx->slot->slot_ctx3) != XHCI_SLOT_STATE_CONFIGURED) {
		XHCI_DEBUG("Slot State[%d] is invalid !!!\n", XHCI_SLOT_CTX3_SLOT_STATE(dev_ctx->slot->slot_ctx3));
		return -1;
	}
#endif

	xhci_print_input_ctx(in_ctx);
	xhci_print_device_ctx(&xhci_device->dev_ctx);

	return 0;
}

static int xhci_set_hub_device(usb_hcd_t *hcd, usb_device_t *dev)
{
	xhci_t *xhci;
	xhci_device_t *xhci_device;
	xhci_input_ctx_t *in_ctx;
	xhci_input_ctrl_ctx_t *ctrl_ctx;
	xhci_slot_ctx_t *slot_ctx;
	usb_hub_info_t* hub_info;
	xhci_trb_t trb;

	if(!dev->parent)
		return 0;

	XHCI_DEBUG("\n### xhci_set_hub_device ###\n");

	hub_info = dev->priv;

	xhci = (xhci_t*)hcd->bus;
	xhci_device = dev->hw_priv;
	if(xhci_device == NULL)
		return -1;

	in_ctx = &xhci_device->in_ctx;
	ctrl_ctx = in_ctx->ctrl;
	slot_ctx = in_ctx->slot;

	ctrl_ctx->add_ctx_flags = (0x1 << 0);	// DCI of the Slot Context
	slot_ctx->slot_ctx0 |= XHCI_SLOT_CTX0_HUB;
	slot_ctx->slot_ctx1 |= XHCI_SLOT_CTX1_SET_NUM_OF_PORTS(hub_info->nports);

	if(dev->speed == USB_SPEED_HIGH)
	{
		XHCI_DEBUG("TT Think Time : %d\n", hub_info->tttt);
		slot_ctx->slot_ctx2 |= XHCI_SLOT_CTX2_SET_TT_THINK_TIME(hub_info->tttt);
	}

	/* 6.4.3.5 Configure Endpoint Command TRB */
	memset(&trb, 0, sizeof(xhci_trb_t));
	trb.trb0_lo = (ulong)in_ctx->ptr;
	trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_CFG_EP) | XHCI_TRB3_SET_SLOT_ID(xhci_device->slot_id);

	if(xhci_command(xhci, &trb, 1000) < 0)
		return -1;

	if(xhci->command.status == XHCI_COMMAND_STATUS_ERROR) {
		XHCI_DEBUG("Completion Code[%d]\n", xhci->command.result);
		return -1;
	}
	XHCI_DEBUG("Configure Endpoint Success !!!\n");

	xhci_print_input_ctx(&xhci_device->in_ctx);
	xhci_print_device_ctx(&xhci_device->dev_ctx);

	return 0;
}

static int xhci_control_transfer(xhci_t *xhci, xhci_device_t *xhci_device,
									usb_req_t* req, usb_device_request_t* dev_req)
{
	usb_pipe_t		*pipe = req->pipe;
	xhci_trb_ring_t *ep_ring = xhci_device->ep_ring[0];
	xhci_xfer_t 	*xfer;
	xhci_trb_t trb;
	u32 first_trb3;
	u8		*buf;
	int 	size;

	xfer	= xhci_add_xfer(xhci_device, ep_ring, req);

	buf		= req->dma_buf;
	size	= req->size;


	XHCI_DEBUG("CONTROL: req:%p, devreq:%p, buf:%p, size:%d\n", req, dev_req, buf, size);

xhci_print_input_ctx(&xhci_device->in_ctx);
xhci_print_device_ctx(&xhci_device->dev_ctx);

	/* 4.11.2.2 Setup Stage, Data Stage, and Status Stage TRBs */

	/* 6.4.1.2.1 Setup Stage */
	trb.trb0_lo = XHCI_SETUP_TRB0_SET_REQUEST_TYPE(dev_req->bmRequestType) |
					XHCI_SETUP_TRB0_SET_REQUEST(dev_req->bRequest) |
					XHCI_SETUP_TRB0_SET_VALUE(dev_req->wValue);
	trb.trb0_hi = XHCI_SETUP_TRB1_SET_INDEX(dev_req->wIndex) |
					XHCI_SETUP_TRB1_SET_LENGTH(dev_req->wLength);
	trb.trb2 = XHCI_TRB2_SET_TRANSFER_LEN(8);	/* Always 8 */
	trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_SETUP) | XHCI_TRB3_IDT;

	if(size > 0) {
		trb.trb3 |= (IS_USB_PIPE_IN(pipe) ? XHCI_SETUP_TRB3_SET_TRT(XHCI_SETUP_TRT_IN_DATA) :
									XHCI_SETUP_TRB3_SET_TRT(XHCI_SETUP_TRT_OUT_DATA));
	}
	/* Cycle bit is used to mark the Enqueue point of a Transfer ring.
	 * If the software change the cycle bit then xHC will dequeue TRBs and process it.
	 * So we have to change the first trb's cycle bit after making all TRBs */
	first_trb3 = trb.trb3;
	if(ep_ring->cycle_state) first_trb3 |= XHCI_TRB3_C;
	else trb.trb3 |= XHCI_TRB3_C;

	xfer->first_trb = xhci_enqueue_trb(ep_ring, &trb);


	/* 6.4.1.2.2 Data Stage */
	if(size > 0) {
		XHCI_DEBUG("Data Stage. size:%d, mps:%d\n", size, pipe->mps);
		trb.trb0 = (ulong)buf;
		trb.trb2 = XHCI_TRB2_SET_TRANSFER_LEN(size) | XHCI_TRB2_SET_TD_SIZE(0);

		trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_DATA);
		if(IS_USB_PIPE_IN(pipe)) {
			trb.trb3 |= (XHCI_TRB3_DIR_IN | XHCI_TRB3_ISP);
		}
		if(ep_ring->cycle_state) trb.trb3 |= XHCI_TRB3_C;
		xhci_enqueue_trb(ep_ring, &trb);
	}

	/* 6.4.1.2.3 Status Stage */
	trb.trb0 = 0;
	trb.trb2 = 0;
	trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_STATUS) | XHCI_TRB3_IOC;
	if(size == 0 || IS_USB_PIPE_OUT(pipe))
		trb.trb3 |= XHCI_TRB3_DIR_IN;
	if(ep_ring->cycle_state) trb.trb3 |= XHCI_TRB3_C;

	xfer->last_trb = xhci_enqueue_trb(ep_ring, &trb);

	/* Change the cycble bit in first trb */
	xfer->first_trb->trb3 = first_trb3;

	XHCI_DB_REG_WRITE(xhci, xhci_device->slot_id, XHCI_DB_SET_TARGET(1));

	return 0;

}

static int xhci_bulk_transfer(xhci_t *xhci, xhci_device_t *xhci_device, usb_req_t* req)
{
	usb_pipe_t *pipe;

	xhci_trb_ring_t *ep_ring;
	xhci_trb_t *enq_trb;
	xhci_xfer_t *xfer;
	xhci_trb_t trb;

	u8 *buf;
	int size;

	u32 first_trb3;
	int num_of_trbs;
	int tx_buf_size, not_spanned_size;
	int packet_count, packet_remained;
	int n;	/* index of a Transfer TRB in a TD */
	int ep_idx;
	int xferred_size;

//xhci_print_input_ctx(&xhci_device->in_ctx);
//xhci_print_device_ctx(&xhci_device->dev_ctx);

	pipe	= req->pipe;
	buf		= req->dma_buf;
	size	= req->size;

	XHCI_INFO("Bulk Transfer %s [%dbytes@%p]\n", IS_USB_PIPE_IN(pipe) ? "IN" : "OUT", size, buf);

	ep_idx = pipe->num * 2 + (IS_USB_PIPE_IN(pipe) ? 1 : 0) - 1;
	ep_ring = xhci_device->ep_ring[ep_idx];
	if(ep_ring == NULL) {
		XHCI_ERROR("Not configured EP[%d]\n", ep_idx);
		return -1;
	}
	XHCI_DEBUG("pipe->num:%d, ep_idx:%d\n", pipe->num, ep_idx);

	xfer	= xhci_add_xfer(xhci_device, ep_ring, req);

	/* Data Buffers shall not span 64KB boundaries */
	/* Calcualte the number of TRBs */
	not_spanned_size = XHCI_TRB_MAX_TX_BUF_SIZE - ((ulong)buf&(XHCI_TRB_BOUNDARY-1));
	if(not_spanned_size > size) not_spanned_size = size;

	tx_buf_size = not_spanned_size;
	num_of_trbs = 1;
	while(tx_buf_size < size) {
		num_of_trbs++;
		tx_buf_size += XHCI_TRB_MAX_TX_BUF_SIZE;
	}

#if 0
	if(num_of_trbs > 1) {
		XHCI_ERROR("Num of TRBs : %d\n", num_of_trbs);
	}
#endif

	/* 4.11.2.4 TD Size */
	/* TD Size�� ���� TRB��� ���� TRB�� Max Packet Size�� ��Ŷ�� ó���ǰ� ����
	 * ���� ��Ŷ �� */
	packet_count = ROUNDUP(size, pipe->mps);

	XHCI_DEBUG("Bulk Xfer. Size=%d, NUM TRBs=%d, Packet Count=%d\n", size, num_of_trbs, packet_count);

	first_trb3 = 0;		/* To remove warnings */

	tx_buf_size = not_spanned_size;
	xferred_size = 0;
	for(n=1; n<=num_of_trbs; n++) {

		if(tx_buf_size == 0) {
			XHCI_DEBUG("Check code !!!. n=%d, packet_count=%d\n", n, packet_count);
		}
		trb.trb0 = (ulong)buf;

		if(n == num_of_trbs) packet_remained = 0;
		else {
			packet_remained = packet_count - (xferred_size/pipe->mps) - 1;
			if(packet_remained > 31) packet_remained = 31;
		}
		XHCI_DEBUG("TD size : %d\n", packet_remained);

		trb.trb2 = XHCI_TRB2_SET_TRANSFER_LEN(tx_buf_size) |
					XHCI_TRB2_SET_TD_SIZE(packet_remained);

		trb.trb3 = XHCI_TRB3_SET_TYPE(XHCI_TRB_TYPE_NORMAL);
		if(IS_USB_PIPE_IN(pipe)) {
			trb.trb3 |= (XHCI_TRB3_DIR_IN | XHCI_TRB3_ISP);
		}

		if(n == num_of_trbs) trb.trb3 |= XHCI_TRB3_IOC;
		else trb.trb3 |= XHCI_TRB3_CH;

		/* Cycle bit is used to mark the Enqueue point of a Transfer ring.
		 * If the software change the cycle bit then xHC will dequeue TRBs and process it.
		 * So we have to change the first trb's cycle bit after making all TRBs */
		if(n == 1) {
			first_trb3 = trb.trb3;
			if(ep_ring->cycle_state) first_trb3 |= XHCI_TRB3_C;
			else trb.trb3 |= XHCI_TRB3_C;
		} else {
			if(ep_ring->cycle_state) trb.trb3 |= XHCI_TRB3_C;
		}

		enq_trb = xhci_enqueue_trb(ep_ring, &trb);
		if(n == 1) xfer->first_trb = enq_trb;
		if(n == num_of_trbs) xfer->last_trb = enq_trb;

		buf += tx_buf_size;
		size -= tx_buf_size;

		xferred_size += tx_buf_size;

		tx_buf_size = (size > XHCI_TRB_MAX_TX_BUF_SIZE) ? XHCI_TRB_MAX_TX_BUF_SIZE : size;

	}

	/* Change the cycble bit in first trb */
	xfer->first_trb->trb3 = first_trb3;

	XHCI_DEBUG("First TRB:%p, Last TRB:%p\n", xfer->first_trb, xfer->last_trb);

	XHCI_DB_REG_WRITE(xhci, xhci_device->slot_id, XHCI_DB_SET_TARGET(ep_idx+1));	/* 0 : Reserved */

	return 0;
}

static int xhci_transfer(usb_hcd_t *hcd, usb_req_t* req, usb_device_request_t* dev_req)
{
	usb_pipe_t		*pipe	= req->pipe;
	usb_device_t	*dev	= pipe->dev;
	xhci_t			*xhci	= (xhci_t*)hcd->bus;
	xhci_device_t	*xhci_device;

	if(dev->address == xhci->roothub_addr) {		// root hub
		return xhci_rh_transfer(hcd, req, dev_req);
	}
	XHCI_DEBUG("\n##### xhci_transfer. #####\n");

	xhci_device = dev->hw_priv;
	if(xhci_device == NULL) return -1;

	if(IS_USB_PIPE_CONTROL(pipe)) {
		return xhci_control_transfer(xhci, xhci_device, req, dev_req);
	} else if(IS_USB_PIPE_BULK(pipe)) {
		return xhci_bulk_transfer(xhci, xhci_device, req);
	}

	return -1;
}

static int xhci_cancel_transfer(usb_hcd_t *hcd, usb_req_t *req)
{
	usb_device_t *dev = req->pipe->dev;
	xhci_device_t *xhci_device;
	xhci_xfer_t *xfer;

	xhci_device = dev->hw_priv;
	if(xhci_device == NULL) return -1;

	list_foreach(&xhci_device->xfer_head, link, xfer) {
		if(xfer->req == req) {
			xhci_remove_xfer(xhci_device, xfer);
			return 0;
		}
	}

	return -1;
}

static int xhci_interrupt(usb_hcd_t *hcd)
{
	xhci_t *xhci = (xhci_t*)hcd->bus;
	u32 status;

	status = XHCI_OP_REG_READ(xhci, XHCI_USBSTS);
	if(!status) return 0;
	XHCI_OP_REG_WRITE(xhci, XHCI_USBSTS, status);

	XHCI_DEBUG("xhci_interrupt. status:0x%08x\n", status);

	if(status&XHCI_USBSTS_EINT) {
		u32 iman = XHCI_RT_REG_READ(xhci, XHCI_IMAN(0));
		XHCI_RT_REG_WRITE(xhci, XHCI_IMAN(0), iman);	/* reset interrupt */

		xhci_poll(xhci);
	} else if(status&XHCI_USBSTS_PCD) {
		XHCI_DEBUG("xhci_interrupt. Port Change Detected !!!\n");
	}

	return 0;
}


static usb_hcd_func_t hcd_func =
{
	.start			= xhci_start,
	.stop			= xhci_stop,
	.transfer		= xhci_transfer,
	.cancel_transfer= xhci_cancel_transfer,
	.interrupt		= xhci_interrupt,

	.device_init	= xhci_device_init,
	.device_deinit	= xhci_device_deinit,
	.set_address	= xhci_set_address,
	.device_config	= xhci_device_config,

	.set_hub_device	= xhci_set_hub_device,
};

int usb_xhci_init(void)
{
	int i;
	char name[MAX_USBD_NAME_LENGTH + 1];
#if (CONFIG_ARCH == ARCH_LG1311)
	int XHCI_NUM_DEVICE;

	if(get_chip_rev() < CHIP_LG1311_B0)
	{
		XHCI_NUM_DEVICE = (sizeof(xhci_base_addr_a0)/sizeof(unsigned long));
		xhci_base_addr = xhci_base_addr_a0;
	}
	else
	{
		XHCI_NUM_DEVICE = (sizeof(xhci_base_addr_b0)/sizeof(unsigned long));
		xhci_base_addr = xhci_base_addr_b0;
	}

	_xhci = (xhci_t *)calloc(1, sizeof(xhci_t) * XHCI_NUM_DEVICE);
	_usb_hcd = (usb_hcd_t *)calloc(1, sizeof(usb_hcd_t) * XHCI_NUM_DEVICE);
	if(_xhci == NULL || _usb_hcd == NULL)
	{
		XHCI_ERROR("fail malloc\n");
		return -1;
	}
#endif

	for(i=0; i<XHCI_NUM_DEVICE; i++) {
		_xhci[i].regs.base_reg	= xhci_base_addr[i];

		_usb_hcd[i].bus		= (void*)&_xhci[i];
		_usb_hcd[i].func	= &hcd_func;
		_usb_hcd[i].rev		= USB_REV_3_0;

		sprintf(name, "XHCI[%d]", i);
		usb_register_hcd(name, &_usb_hcd[i]);
	}

	return 0;
}
#endif
