/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifndef _EHCI_H_
#define _EHCI_H_

/* 2.2 Host Controller Capability Registers */
#if 1
typedef u32 ehci_cap_reg_t;
#else
typedef struct ehci_cap_reg ehci_cap_reg_t;
struct ehci_cap_reg
{
	volatile u8 const	CAPLENGTH;			/* Capability Register Length */
	volatile u8			Reserved;
	volatile u16		HCIVERSION;			/* Interface Version Number */
	volatile u32		HCSPARAMS;			/* Structural Parameters */
	volatile u32		HCCPARAMS;			/* Capability Parameters */
	volatile u8			HCSP_PORTROUTE[8];	/* Companion Port Route Description. optional */
} __attribute__((packed));
#endif

#define HCCAPBASE		0x00
#define CAPLENGTH(v)		(((v) >>  0) & 0xFF)	/* Capability Register Length */
#define HCIVERSION(v)		(((v) >> 16) & 0xFFFF)	/* Interface Version Number */
#define HCIVERSION_MAJOR(v)	(((v) >> 24) & 0xFF)	/* Interface Version Number Major */
#define HCIVERSION_MINOR(v)	(((v) >> 16) & 0xFF)	/* Interface Version Number Minor */

#define HCSPARAMS		0x04			/* Structural Parameters */
#define HCS_P_INDICATOR(v)	(((v) >> 16) & 0x1)
#define HCS_N_CC(v)			(((v) >> 12) & 0xF)
#define HCS_N_PCC(v)		(((v) >>  8) & 0xF)
#define HCS_PPC(v)			(((v) >>  4) & 0x1)
#define HCS_N_PORTS(v)		(((v) >>  0) & 0xF)

#define HCCPARAMS		0x08			/* Capability Parameters */
#define HCC_64BIT_ADDR(v)	(((v) >>  0) & 0x1)

#define HCSP_PORTROUTE	0x0C			/* Companion Port Route Description. optional */



/* 2.3 Host Controller Operational Registers */
#if 1
typedef u32 ehci_op_reg_t;
#else
typedef struct ehci_op_reg ehci_op_reg_t;
struct ehci_op_reg
{
	volatile u32		USBCMD;				/* USB Command */
	volatile u32		USBSTS;				/* USB Status */
	volatile u32		USBINTR;			/* USB Interrupt Enable */
	volatile u32		FRINDEX;			/* USB Frame Index */
	volatile u32		CTRLDSSEGMENT;		/* 4G Segment Selector */
	volatile u32		PERIODICLISTBASE;	/* Frame List Base Address */
	volatile u32		ASYNCLISTADDR;		/* Next Asynchronous List Address */
	volatile u32		Reserved[9];
	volatile u32		CONFIGFLAG;			/* Configured Flag Register */
	volatile u32		PORTSC[15];			/* Port Status/Control */
} __attribute__((packed));
#endif

#define EHCI_USBCMD				0x00	/* USB Command */

#define EHCI_USBCMD_ITC_MASK	(0xFF << 16)	/* Interrupt Threshold Control */
#define EHCI_USBCMD_ITC_8		(0x08 << 16)	/* 8 micro-frames (1ms) */
#define EHCI_USBCMD_IAAD		(0x01 << 6)		/* Interrupt on Async Advance Doorbell */
#define EHCI_USBCMD_ASE			(0x01 << 5)		/* Asynchronous Schedule Enable */
#define EHCI_USBCMD_PSE			(0x01 << 4)		/* Periodic Schedule Enable */
#define EHCI_USBCMD_FLS_MASK	(0x03 << 2)		/* Frame List Size */
#define EHCI_USBCMD_HCRESET		(0x01 << 1)
#define EHCI_USBCMD_RUN			(0x01 << 0)


#define EHCI_USBSTS				0x04	/* USB Status */
#define EHCI_USBSTS_ASS			(0x01 << 15)	/* Asynchronous Schedule Status */
#define EHCI_USBSTS_HCH			(0x01 << 12)	/* HCHalted */

#define EHCI_USBSTS_IAA			(0x01 << 5)		/* Interrupt on Async Advance */
#define EHCI_USBSTS_HSE			(0x01 << 4)		/* Host System Error */
#define EHCI_USBSTS_FLR			(0x01 << 3)		/* Frame List Rollover */
#define EHCI_USBSTS_PCD			(0x01 << 2)		/* Port Change Detect */
#define EHCI_USBSTS_ERR			(0x01 << 1)		/* USB Error Interrupt(USBERRINT) */
#define EHCI_USBSTS_INT			(0x01 << 0)		/* USB Interrupt */
#define EHCI_USBSTS_INTR_MASK	(0x3F)

#define EHCI_USBINTR			0x08	/* USB Interrupt Enable */
#define EHCI_FRINDEX			0x0C	/* USB Frame Index */
#define EHCI_CTRLDSSEGMENT		0x10	/* 4G Segment Selector */
#define EHCI_PERIODICLISTBASE	0x14	/* Frame List Base Address */
#define EHCI_ASYNCLISTADDR		0x18	/* Next Asynchronous List Address */

#define EHCI_CONFIGFLAG			0x40	/* Configured Flag Register */
#define EHCI_CONFIGFLAG_CF		(0x01 << 0)


#define EHCI_PORTSC(n)			(0x44 + (n)*4)	/* Port Status/Control */

#define EHCI_PORTSC_PO			(0x01 << 13)	/* Port Owner */
#define EHCI_PORTSC_PP			(0x01 << 12)	/* Port Power */
#define EHCI_PORTSC_LS_MASK		(0x03 << 10)	/* Line Status */
#define EHCI_PORTSC_LS_LOW		(0x01 << 10)	/* Low-speed device */
#define EHCI_PORTSC_PR			(0x01 << 8)		/* Port Reset */
#define EHCI_PORTSC_S			(0x01 << 7)		/* Suspend */
#define EHCI_PORTSC_OCC			(0x01 << 5)		/* Over-current Change */
#define EHCI_PORTSC_OCA			(0x01 << 4)		/* Over-current Active */
#define EHCI_PORTSC_PEDC		(0x01 << 3)		/* Port Enable/Disable Change */
#define EHCI_PORTSC_PED			(0x01 << 2)		/* Port Enabled/Disabled */
#define EHCI_PORTSC_CSC			(0x01 << 1)		/* Connect Status Change */
#define EHCI_PORTSC_CCS			(0x01 << 0)		/* Current Connect Status. 1 : present */

#define EHCI_PORTSC_CLEAR	(EHCI_PORTSC_OCC | EHCI_PORTSC_PEDC | EHCI_PORTSC_CSC)

/* 3.5 Queue Element Transfer Descriptor(qTD) */
#define EHCI_QTD_BUFFER_CNT		5
typedef struct ehci_qtd	ehci_qtd_t;
struct ehci_qtd
{
	volatile u32	next_qtd;
	volatile u32	alt_next_qtd;
	volatile u32	qtd_token;			/* Total Bytes to Transfer, ioc, C_Page, Cerr, ... */
	volatile u32	buffer[EHCI_QTD_BUFFER_CNT];
	/* we do not support 64-bit addressing */
	volatile u32	buffer_hi[EHCI_QTD_BUFFER_CNT];

	/* Software informations */
	LIST_ENTRY(ehci_qtd)   link;
};// __attribute__((packed));

typedef LIST_HEAD(ehci_qtd_head, ehci_qtd) ehci_qtd_head_t;


#define EHCI_QTD(v)				((v) & 0xFFFFFFE0)
#define EHCI_QTD_TERMINATE		0x01


/* qTD Token */
#define EHCI_QTD_TOKEN_DT(v)		(((v) & 0x01) << 31)	/* Data Toggle */
#define EHCI_QTD_TOKEN_GET_DT(s)	(((s) >> 31) & 0x01)
#define EHCI_QTD_TOKEN_TBT(v)		(((v) & 0x7FFF) << 16)	/* Total Bytes to Transfer */
#define EHCI_QTD_TOKEN_GET_TBT(s)	(((s) >> 16) & 0x7FFF)
#define EHCI_QTD_TOKEN_IOC(v)		(((v) & 0x01) << 15)	/* Interrupt On Complete(IOC) */
#define EHCI_QTD_TOKEN_CP(v)		(((v) & 0x07) << 12)	/* Current Page(C_Page) */
#define EHCI_QTD_TOKEN_EC(v)		(((v) & 0x03) << 10)	/* Error Counter(CERR) */
#define EHCI_QTD_TOKEN_PIDC(v)		(((v) & 0x03) << 8)		/* PID Code */
#define EHCI_QTD_TOKEN_PID_OUT			EHCI_QTD_TOKEN_PIDC(0x0)
#define EHCI_QTD_TOKEN_PID_IN			EHCI_QTD_TOKEN_PIDC(0x1)
#define EHCI_QTD_TOKEN_PID_SETUP		EHCI_QTD_TOKEN_PIDC(0x2)

#define EHCI_QTD_TOKEN_STATUS(v)	(((v) & 0xFF) << 0)
#define EHCI_QTD_STATUS_ACTIVE			(1 << 7)
#define EHCI_QTD_STATUS_HALTED			(1 << 6)
#define EHCI_QTD_STATUS_BUFFER_ERROR	(1 << 5)
#define EHCI_QTD_STATUS_BABBLE_DETECTED	(1 << 4)	/* Babble Detected */
#define EHCI_QTD_STATUS_XACT_ERROR		(1 << 3)	/* Transaction Error */
#define EHCI_QTD_STATUS_MISSED_MF		(1 << 2)	/* Missed Micro-Frame */
#define EHCI_QTD_STATUS_SPLIT_X_STATE	(1 << 1)	/* Split Transaction State (SplieXState) */
#define EHCI_QTD_STATUS_PING_STATE		(1 << 0)	/* Ping State (P)/ERR */


#define EHCI_QTD_ALIGMENT			32
#define EHCI_QTD_BUFFER_ALIGMENT	4096



/* 3.6 Queue Head */
typedef struct ehci_qh	ehci_qh_t;
struct ehci_qh
{
	volatile u32	hlink;		/* Queue Head Horizontal Link Pointer */
	volatile u32	ep1;		/* Endpoint Characteristics */
	volatile u32	ep2;		/* Endpoint Capabilities */
	volatile u32	cur_qtd;
	ehci_qtd_t		overlay;

	/* Software informations */
	LIST_ENTRY(ehci_qh) link;
	ehci_qtd_head_t		qtd_head;
} __attribute__((packed));
typedef LIST_HEAD(ehci_qh_head, ehci_qh) ehci_qh_head_t;


#define EHCI_QHLP(v)			((v) & 0xFFFFFFE0)
#define EHCI_QHLP_TYPE(v)		(((v) & 0x03) << 1)
#define EHCI_QHLP_TYPE_iTD		EHCI_QHLP_TYPE(0x00)	/* isochronous transfer descriptor */
#define EHCI_QHLP_TYPE_QH		EHCI_QHLP_TYPE(0x01)	/* queue head */
#define EHCI_QHLP_TYPE_siTD		EHCI_QHLP_TYPE(0x02)	/* split transaction isochronous transfer descriptor */
#define EHCI_QHLP_TYPE_FSTN		EHCI_QHLP_TYPE(0x03)	/* Frame Span Traversal Node */

#define EHCI_QHLP_TERMINATE		0x01

/* Endpoint Characteristics */
#define EHCI_EP1_RL(v)			(((v) & 0x0F) << 28)	/* Nak Count Reload(RL) */
#define EHCI_EP1_C(v)			(((v) & 0x01) << 27)	/* Control Endpoint Flag(C) */
#define EHCI_EP1_MPL(v)			(((v) & 0x7FF)<< 16)	/* Maximum Packet Length */
#define EHCI_EP1_H(v)			(((v) & 0x01) << 15)	/* Head of Reclamation List Flag(H) */
#define EHCI_EP1_DTC(v)			(((v) & 0x01) << 14)	/* Data Toggle Control(DTC) */
#define EHCI_EP1_EPS(v)			(((v) & 0x03) << 12)	/* Endpoint Speed(EPS) */
#define EHCI_EP1_EPS_FULL		EHCI_EP1_EPS(0)			/* Full-Speed(12Mbs) */
#define EHCI_EP1_EPS_LOW		EHCI_EP1_EPS(1)			/* Low-Speed(1.5Mbs) */
#define EHCI_EP1_EPS_HIGH		EHCI_EP1_EPS(2)			/* High-Speed(480Mb/s) */
#define EHCI_EP1_ENDPT(v)		(((v) & 0x0F) << 8)		/* Endpoint Number(Endpt) */
#define EHCI_EP1_DEVADDR(v)		(((v) & 0x7F) << 0)		/* Device Address */

/* Endpoint Capabilities */
#define EHCI_EP2_MULT(v)		(((v) & 0x03) << 30)	/* High-Bandwidth Pipe Multiplier(Mult) */
#define EHCI_EP2_PN(v)			(((v) & 0x7F) << 23)	/* Port Number */
#define EHCI_EP2_HA(v)			(((v) & 0x7F) << 16)	/* Hub Addr */
#define EHCI_EP2_SCM(v)			(((v) & 0xFF) <<  8)	/* Split Completion Mask(uFrame C-Mask) */
#define ECHI_EP2_ISM(v)			(((v) & 0xFF) <<  0)	/* Interrupt Schedule Mask(uFrame S-mask) */



#define EHCI_QH_ALIGMENT			32


#endif
