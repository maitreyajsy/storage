/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#if (USE_USB_STORAGE == 1)
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>
#include <thread.h>

#include <timer.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <malloc.h>
#include <usb.h>
#include <serial.h>

/*
 * Currently only the SCSI SUBCLASS and BBB transport protocol is implemented,
 * and  it's tested only with the memory stick
 */

//#define DUMP_DESCRIPTOR

#if 0
#define USB_MASS_INFO(fmt, args...)		usb_printf("USB-MASS:"fmt, ##args)
#else
#define USB_MASS_INFO(fmt, args...)		do{}while(0)
#endif

#if 0
#define USB_MASS_DEBUG(fmt, args...)	usb_printf("USB-MASS:"fmt, ##args)
#else
#define USB_MASS_DEBUG(fmt, args...)	do{}while(0)
#endif

#if 1
#define USB_MASS_ERROR(fmt, args...)	usb_printf("\x1b[31mUSB-MASS:"fmt"\x1b[0m", ##args)
#else
#define USB_MASS_ERROR(fmt, args...)	do{}while(0)
#endif



/*
 * http://www.usb.org/developers/devclass_docs/Mass_Storage_Specification_Overview_v1.4_2-19-2010.pdf
 */

#define USB_MASS_SUBCLASS_RBC		0x01
#define USB_MASS_SUBCLASS_ATAPI		0x02
#define USB_MASS_SUBCLASS_UFI		0x04
#define USB_MASS_SUBCLASS_SCSI		0x06
#define USB_MASS_SUBCLASS_LSDFS		0x07
#define USB_MASS_SUBCLASS_IEEE1667	0x08

#define USB_MASS_PROT_CBI			0x00	/* Control/Bulk/Interrupt Transport */
#define USB_MASS_PROT_BBB			0x50	/* Bulk-Only Transport */
#define USB_MASS_PROT_UAS			0x62


/*
 * http://www.usb.org/developers/devclass_docs/usbmassbulk_10.pdf
 */
typedef struct usb_mass_cbw usb_mass_cbw_t;
struct usb_mass_cbw
{
	u32		dCBWSignature;
	u32		dCBWTag;
	u32		dCBWDataTransferLength;
	u8		bmCBWFlags;
	u8		bCBWLUN;
	u8		bCBWCBLength;
	u8		CBWCB[16];
} __attribute__ ((packed));
#define CBW_SIGNATURE		0x43425355
#define CBW_FLAG_DATA_OUT	0x00
#define CBW_FLAG_DATA_IN	0x80

typedef struct usb_mass_csw usb_mass_csw_t;
struct usb_mass_csw
{
	u32		dCSWSignature;
	u32		dCSWTag;
	u32		dCSWDataResidue;
	u8		bCSWStatus;
} __attribute__ ((packed));

#define CSW_SIGNATURE			0x53425355
#define CSW_STATUS_PASSED		0x00
#define CSW_STATUS_FAILED		0x01
#define CSW_STATUS_PHASE_ERROR	0x02



#define USB_REQ_TYPE_RESET			0xFF	/*Bulk-Only Mass Stroage Reset */
#define USB_REQ_TYPE_GET_MAX_LUN	0xFE	/* Get Max LUN */



/*
 * http://en.wikipedia.org/wiki/SCSI_command
 * http://www.seagate.com/staticfiles/support/disc/manuals/Interface%20manuals/100293068c.pdf
 */
/*
 * 0x00 ~ 0x1F : 6
 * 0x20 ~ 0x5F : 10
 * 0x80 ~ 0x8F : 16
 * 0xA0 ~ 0xBf : 12
 */
#define SCSI_CMD_TEST_UNIT_READY	0x00
#define SCSI_CMD_REQUEST_SENSE		0x03
#define SCSI_CMD_INQUIRY			0x12
#define SCSI_CMD_READ_CAPACITY_10	0x25
#define SCSI_CMD_READ_10			0x28


/*************************************************/

#define USB_MASS_DIR_IN				0
#define USB_MASS_DIR_OUT			1

#define USB_MASS_MAX_CMD_LEN		16

#define MAX_USB_MASS_DEVICE			2

typedef struct
{
	uint8_t 	cmd[USB_MASS_MAX_CMD_LEN];
	uint8_t 	cmdlen;
	uint8_t 	dir;
} usb_mass_xfer_t;


typedef struct usb_mass
{
	usb_device_t		*dev;

	usb_pipe_t			*in_pipe;
	int					in_mps;
	usb_pipe_t			*out_pipe;
	int					out_mps;

	uint32_t			cbw_tag;

	usb_mass_xfer_t		xfer;
	usb_mass_cbw_t		cbw;
	usb_mass_csw_t		csw;

	uint32_t			last_lba;
	uint32_t			blk_size;
	uint64_t			size;
	char				vendor[8+1];
	char				product[16+1];
	char				prod_rev[4+1];	// Product revision level
	uint8_t				*buf;
} usb_mass_t;

static usb_mass_t* usb_mass_dev[MAX_USB_MASS_DEVICE];



static int usb_mass_stall_recovery(usb_mass_t *usb_mass, usb_pipe_t *pipe)
{
	int rc;

	rc = usb_device_request(usb_mass->dev,
					USB_REQTYPE_DIR_OUT | USB_REQTYPE_TYPE_STANDARD | USB_REQTYPE_REC_ENDPOINT,
					USB_REQUEST_CLEAR_FEATURE,
					0, pipe->num, NULL, 0);

	USB_MASS_INFO("STALL RECOVERY : %d\n", rc);

	return rc;
}


/*
 * Command/Data/Status Flow
 * Command Transport(CBW) ==> Data Out / Data In ==> Status Transport(CSW)
 */

static int usb_mass_command(usb_mass_t *usb_mass, uint8_t *data, int datalen)
{
	int rc;
	usb_mass_xfer_t *xfer = &usb_mass->xfer;
	usb_mass_cbw_t *cbw = &usb_mass->cbw;
	usb_mass_csw_t *csw = &usb_mass->csw;
	usb_pipe_t *pipe;
	int timeout;

	cbw->dCBWSignature	= CBW_SIGNATURE;
	cbw->dCBWTag		= usb_mass->cbw_tag++;
	cbw->dCBWDataTransferLength = datalen;
	cbw->bmCBWFlags		= (xfer->dir == USB_MASS_DIR_IN) ? CBW_FLAG_DATA_IN : CBW_FLAG_DATA_OUT;
	cbw->bCBWLUN		= 0;
	cbw->bCBWCBLength	= xfer->cmdlen;
	memcpy(cbw->CBWCB, xfer->cmd, xfer->cmdlen);
	if(xfer->cmdlen < 16) memset(cbw->CBWCB + xfer->cmdlen, 0, 16 - xfer->cmdlen);

	/* Command Transport(CBW) */
	USB_MASS_INFO("CBW\n");
	if((rc = usb_request_timeout(usb_mass->out_pipe, (uint8_t*)cbw, sizeof(usb_mass_cbw_t), 300)) < 0) {
		USB_MASS_ERROR("CBW : rc=%d\n", rc);
		return -1;
	}

	if(datalen > 0) {
		/* Data Out or Data In */
		USB_MASS_INFO("Data In/Out\n");
		pipe = (xfer->dir == USB_MASS_DIR_IN) ? usb_mass->in_pipe : usb_mass->out_pipe;
//		timeout = datalen/300 + 500;//100;	/* we assume the speed of xfer is 300KB/s */
		timeout = datalen/300 + 3000;
		if((rc = usb_request_timeout(pipe, data, datalen, timeout)) < 0) {
			USB_MASS_ERROR("Data In/Out : rc=%d\n", rc);
			if(rc == USB_ERR_STALL) {
				rc = usb_mass_stall_recovery(usb_mass, pipe);
			}
			if(rc < 0) return -1;
		}

		if(rc != datalen) USB_MASS_ERROR("datalen:%d, received:%d\n", datalen, rc);
	}

	/* Status Transport(CSW) */
	USB_MASS_INFO("CSW\n");
	if((rc = usb_request_timeout(usb_mass->in_pipe, csw, sizeof(usb_mass_csw_t), 300)) < 0) {
		USB_MASS_ERROR("CSW : rc=%d\n", rc);
		return -1;
	}


	if(csw->dCSWSignature != CSW_SIGNATURE) {
		USB_MASS_ERROR("Invalid signature !!!\n");
		return -1;
	} else if(csw->dCSWTag != (usb_mass->cbw_tag - 1)) {
		USB_MASS_ERROR("Invalid Tag !!!\n");
		return -1;
	} else if(csw->bCSWStatus != 0) {
		USB_MASS_INFO("CSW Signature:0x%08x, Tag:0x%08x, DataResidue:0x%08x, Status:%d\n",
						csw->dCSWSignature, csw->dCSWTag, csw->dCSWDataResidue, csw->bCSWStatus);
		return -1;
	}

	return 0;
}

static void usb_mass_request_sense(usb_mass_t *usb_mass)
{
	uint8_t data[18];
	usb_mass_xfer_t *xfer = &usb_mass->xfer;

	USB_MASS_INFO("usb_mass_request_sense\n");

	xfer->cmdlen = 6;
	memset(xfer->cmd, 0, xfer->cmdlen);
	xfer->cmd[0] = SCSI_CMD_REQUEST_SENSE;
	xfer->cmd[4] = 18;
	xfer->dir = USB_MASS_DIR_IN;

	usb_mass_command(usb_mass, (uint8_t*)data, 18);

//	hex_dump(0, data, 18, 1);
}

static int usb_mass_inquiry(usb_mass_t *usb_mass)
{
	uint8_t data[36];
	usb_mass_xfer_t *xfer = &usb_mass->xfer;
	int retry = 5;

	USB_MASS_INFO("usb_mass_request_sense\n");

	while(--retry) {
		xfer->cmdlen = 6;
		memset(xfer->cmd, 0, xfer->cmdlen);
		xfer->cmd[0] = SCSI_CMD_INQUIRY;
		xfer->cmd[4] = 36;
		xfer->dir = USB_MASS_DIR_IN;

		if(usb_mass_command(usb_mass, (uint8_t*)data, 36) == 0)
		{
			memcpy(usb_mass->vendor, &data[8], 8);
			memcpy(usb_mass->product, &data[16], 16);
			memcpy(usb_mass->prod_rev, &data[32], 4);
			usb_mass->vendor[8] = 0;
			usb_mass->product[16] = 0;
			usb_mass->prod_rev[4] = 0;
			return 0;
		}
	}
	USB_MASS_ERROR("fail in inquiry\n");
	return -1;
}

static int usb_mass_unit_ready(usb_mass_t *usb_mass)
{
	usb_mass_xfer_t *xfer = &usb_mass->xfer;
	int retry = 5;

	USB_MASS_INFO("usb_mass_unit_ready\n");

	while(--retry) {
		xfer->cmdlen = 6;
		memset(xfer->cmd, 0, xfer->cmdlen);
		xfer->cmd[0] = SCSI_CMD_TEST_UNIT_READY;
		xfer->dir = USB_MASS_DIR_IN;

		if(usb_mass_command(usb_mass, NULL, 0) == 0)
			return 0;

		USB_MASS_INFO("waiting for storage ready...\n");
		msleep(100);
	}
	USB_MASS_ERROR("fail in unit ready\n");
	return -1;
}

static int usb_mass_get_capacity(usb_mass_t *usb_mass)
{
	uint8_t data[8];	/* 0: Returned LBA, 1:Block length in bytes */
	usb_mass_xfer_t *xfer = &usb_mass->xfer;

	USB_MASS_INFO("usb_mass_get_capacity\n");

	xfer->cmdlen = 10;
	memset(xfer->cmd, 0, xfer->cmdlen);
	xfer->cmd[0] = SCSI_CMD_READ_CAPACITY_10;
	xfer->dir = USB_MASS_DIR_IN;

	if(usb_mass_command(usb_mass, (uint8_t*)data, 8) < 0)
		return -1;

	usb_mass->last_lba = GET32_BE_FROM_ARRAY(&data[0]);
	usb_mass->blk_size = GET32_BE_FROM_ARRAY(&data[4]);

	USB_MASS_INFO("last_lba:0x%08x, blk_size:0x%08x\n",
				usb_mass->last_lba, usb_mass->blk_size);
	return 0;
}

static int usb_mass_read_block(usb_mass_t *usb_mass, uint32_t lba, uint16_t blkcnt, uint8_t *buf)
{
	int rc;
	usb_mass_xfer_t *xfer = &usb_mass->xfer;

	USB_MASS_INFO("usb_mass_read_block. lba:%d, blkcnt:%d\n", lba, blkcnt);

	if(lba > usb_mass->last_lba) return -1;

	xfer->cmdlen = 10;
	memset(xfer->cmd, 0, xfer->cmdlen);
	xfer->cmd[0] = SCSI_CMD_READ_10;
	SET32_BE_TO_ARRAY(lba, &xfer->cmd[2]);
	SET16_BE_TO_ARRAY(blkcnt, &xfer->cmd[7]);
	xfer->dir = USB_MASS_DIR_IN;

	rc = usb_mass_command(usb_mass, buf, usb_mass->blk_size * blkcnt);

	return rc;
}

static uint8_t usb_mass_get_max_lun(usb_mass_t *usb_mass)
{
	uint8_t lun;
	int rc;

	rc = usb_device_request(usb_mass->dev,
					USB_REQTYPE_DIR_IN | USB_REQTYPE_TYPE_CLASS | USB_REQTYPE_REC_INTERFACE,
					USB_REQ_TYPE_GET_MAX_LUN, 0, 0, &lun, 1);
	if(rc < 0) {
		USB_MASS_INFO("Can't get the max lun\n");
		return 0;
	}
	return lun;
}

int usb_mass_attach(usb_device_t* dev)
{
	int i;
	usb_interface_desc_t* if_desc;
	usb_endpoint_desc_t	*ep_desc;
	usb_mass_t *usb_mass = NULL;
	uint8_t max_lun;
	int idx = -1;

	for(i=0; i<MAX_USB_MASS_DEVICE; i++) {
		if(usb_mass_dev[i] == NULL) {
			idx = i;
			break;
		}
	}

	if(idx == -1) {
		USB_MASS_ERROR("Exceeded the maximum number of devices\n");
		return -1;
	}

	if_desc = dev->if_desc[0];
	if(if_desc == NULL) {
		printf("Can't get interface descriptor !!!\n");
		return -1;
	}

	if(if_desc->bInterfaceSubClass != USB_MASS_SUBCLASS_SCSI ||
		if_desc->bInterfaceProtocol != USB_MASS_PROT_BBB) {
		printf("Not supported interface\n");
		printf("InterfaceSubClass:0x%02x, InterfaceProtocol:0x%02x\n",
			if_desc->bInterfaceSubClass, if_desc->bInterfaceProtocol);
		return -1;
	}

	usb_mass = (usb_mass_t*)calloc(sizeof(usb_mass_t), 1);
	for(i=0; i<dev->num_ep_desc; i++) {
		/* Normally, there's one input endpoint and output endpoint in BBB protocol */
		ep_desc = dev->ep_desc[i];
		if(IS_USB_EP_BULK(ep_desc->bmAttributes)) {
			if(IS_USB_EP_IN(ep_desc->bEndpointAddress)) {
				if(usb_mass->in_pipe == NULL) {
					usb_mass->in_pipe	= usb_open_pipe(dev, ep_desc);
					usb_mass->in_mps	= ep_desc->wMaxPacketSize;
					USB_MASS_INFO("IN MaxPacketSize : %d\n", usb_mass->in_mps);
				} else {
					USB_MASS_INFO("more than one in ep\n");
				}
			} else {
				if(usb_mass->out_pipe == NULL) {
					usb_mass->out_pipe = usb_open_pipe(dev, ep_desc);
					usb_mass->out_mps	= ep_desc->wMaxPacketSize;
					USB_MASS_INFO("OUT MaxPacketSize : %d\n", usb_mass->out_mps);
				} else {
					USB_MASS_INFO("more than one out ep\n");
				}
			}
		} else {
			USB_MASS_INFO("Not bulk EP\n");
		}
	}

	if(usb_mass->in_pipe == NULL || usb_mass->out_pipe == NULL) {
		USB_MASS_ERROR("In or Out EP descriptor is missed !!!\n");
		goto error;
	}
	usb_mass->dev = dev;
	dev->priv = usb_mass;

//	msleep(500); // some devices are needed long delay...

	max_lun = usb_mass_get_max_lun(usb_mass);
	if(max_lun > 0) printf("Max LUN=%d, but supported only 1 LUN\n", max_lun);

	if(usb_mass_inquiry(usb_mass) < 0)
		goto error;

	if(usb_mass_unit_ready(usb_mass) < 0)		/* Some devices are needed this command */
		goto error;

	usb_mass_request_sense(usb_mass);
	if(usb_mass_get_capacity(usb_mass) < 0) {
		printf("Can't get the capacity info\n");
		goto error;
	}

	usb_mass->buf = malloc(usb_mass->blk_size);
	usb_mass_dev[idx] = usb_mass;

	usb_mass->size = (uint64_t)(usb_mass->last_lba + 1) * usb_mass->blk_size;
	printf("USB Mass Storage[%d] registered : ", idx);
	printf("%s %s %s, %dMB\n", usb_mass->vendor, usb_mass->product, usb_mass->prod_rev, (uint32_t)(usb_mass->size/1024/1024));

	return 0;
error:
	if(usb_mass != NULL) free(usb_mass);

	return -1;
}


/*****************************************************************/

/* It depends on the hc driver */
#define MAX_USB_MASS_XFER_BLK_SUPER	8000		/* 4000 KB */
#define MAX_USB_MASS_XFER_BLK_HIGH	4000
#define MAX_USB_MASS_XFER_BLK_FULL	100
int usb_mass_read(struct usb_mass* usb_mass, loff_t offset, size_t len, void* buf)
{
	uint32_t lba, pos;
	int rsize, remained;
	int blk_cnt, max_blk_cnt;

	if(usb_mass == NULL) return -1;

	lba = offset/usb_mass->blk_size;
	pos = offset%usb_mass->blk_size;
	remained = len;

	max_blk_cnt = (usb_mass->dev->speed == USB_SPEED_SUPER) ? MAX_USB_MASS_XFER_BLK_SUPER :
					((usb_mass->dev->speed == USB_SPEED_HIGH) ? MAX_USB_MASS_XFER_BLK_HIGH :
						MAX_USB_MASS_XFER_BLK_FULL);

	while(remained > 0) {
		if(pos || remained < usb_mass->blk_size) {
			blk_cnt = 1;
			rsize = min(usb_mass->blk_size - pos, remained);
			if(usb_mass_read_block(usb_mass, lba, blk_cnt, usb_mass->buf) < 0)
				return -1;

			memcpy(buf, usb_mass->buf + pos, rsize);
			pos = 0;
		} else {
			blk_cnt = remained/usb_mass->blk_size;
			if(blk_cnt > max_blk_cnt) blk_cnt = max_blk_cnt;
			rsize = blk_cnt * usb_mass->blk_size;
			if(usb_mass_read_block(usb_mass, lba, blk_cnt, buf) < 0)
				return -1;
		}
		remained -= rsize;
		buf = (uint8_t*)buf + rsize;
		lba += blk_cnt;
	}

	return (len - remained);
}

int usb_mass_write(struct usb_mass* usb_mass, loff_t offset, size_t len, const void* buf)
{
	if(usb_mass == NULL) return -1;

	return -1;
}

struct usb_mass* usb_mass_open(int no)
{
	if(no < 0 || no >= MAX_USB_MASS_DEVICE || usb_mass_dev[no] == NULL) {
		printf("Unregisterd device[%d]\n", no);
		return NULL;
	}
	return usb_mass_dev[no];
}

int usb_mass_close(struct usb_mass* usb_mass)
{
	return 0;
}

void usb_mass_info(void)
{
	int i;
	struct usb_mass* usb_mass;
	int found = 0;

	for(i=0; i<MAX_USB_MASS_DEVICE; i++) {
		if(usb_mass_dev[i] != NULL) {
			usb_mass = usb_mass_dev[i];
			printf("Mass Storage Num : %d\n", i);
			printf("  %s %s %s, %dMB\n", usb_mass->vendor, usb_mass->product, usb_mass->prod_rev, (uint32_t)(usb_mass->size/1024/1024));
			found = 1;
		}
	}

	if(!found) printf("No mass storage device\n");
}
#endif
