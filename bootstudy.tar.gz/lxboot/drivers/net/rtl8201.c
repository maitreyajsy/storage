/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if USE_RTL8201
#include <stdio.h>
#include <string.h>
#include <gpio.h>
#include <util.h>
#include <timer.h>

#include "mii.h"
#include "phy.h"

#if 0
#define debug(fmt, args...)		printf(fmt, ##args)
#else
#define debug(fmt, args...)		do{}while(0)
#endif


#define RTL8201_PHY_ID_OUI_MSB		0x001C
#define RTL8201_PHY_ID_OUI_LSB		0x0032
#define RTL8201_PHY_ID_OUI			((RTL8201_PHY_ID_OUI_MSB << 6) | RTL8201_PHY_ID_OUI_LSB)

#define RTL8201_PSR		0x1F		/* Register 31. Page Select Register */
#define RTL8201_RMSR	0x10		/* Page 7 Register 16 RMII Mode Setting Register */


typedef struct
{
	phy_dev_t	phy_dev;
} rtl8201_dev_t;

static rtl8201_dev_t _rtl8201;
static rtl8201_dev_t *rtl8201 = &_rtl8201;

static int rtl8201_init(void)
{
	debug("rtl8201_init\n");

	gpio_set_top(GPIO_PHY_RESET);		// set to gpio
	gpio_set_direction(GPIO_PHY_RESET, GPIO_DIR_OUTPUT);

	gpio_set_value(GPIO_PHY_RESET, GPIO_LOW);
	mdelay(20);		/* at least 10ms */
	gpio_set_value(GPIO_PHY_RESET, GPIO_HIGH);
	mdelay(200);	/* at least 150ms */

	memset(rtl8201, 0, sizeof(rtl8201_dev_t));

	return 0;
}

static int rtl8201_phy_read(phy_dev_t *dev, int reg, u16 *val)
{
	return dev->bus->read(dev->phy_addr, reg, val);
}

static int rtl8201_phy_write(phy_dev_t *dev, int reg, u16 val)
{
	return dev->bus->write(dev->phy_addr, reg, val);
}


#if 0
#define check_phy_reg(addr, value)	\
	do {							\
		u16 _v_;					\
		do {						\
			rtl8201_phy_read(dev, addr, &_v_);	\
		} while(_v_ != value);		\
	} while(0)

static void change_phy_tx_timing(phy_dev_t *dev, u32 value)
{
	rtl8201_phy_write (dev, RTL8201_PSR , 0x7);	// select page 7
	check_phy_reg(RTL8201_RMSR, 0xFFA);
	rtl8201_phy_write(dev, RTL8201_RMSR, value);			// change tx timing
	check_phy_reg(RTL8201_RMSR, value);
	rtl8201_phy_write (dev, RTL8201_PSR , 0x0);			// select page 0
}
#endif

static phy_dev_t* rtl8201_connect(mii_bus_t *bus, int addr)
{
	u16 phy_id[2];
	u32 oui, model, rev;
	u16 status;
	phy_dev_t *dev = &rtl8201->phy_dev;

	debug("rtl8201_connect\n");

	dev->bus = bus;
	if(addr == -1) {
		int i;
		u16 val;
		for(i=1; i<32; i++) {
			dev->phy_addr = i;
			rtl8201_phy_read(dev, MII_PHYID_H, &val);
			if(val == RTL8201_PHY_ID_OUI_MSB) break;
		}
		if(i == 32) {
			printf("Can't find phy addr\n");
			return NULL;
		}
	} else {
		dev->phy_addr = addr;
	}
	debug("PHY ADDR : %d\n", dev->phy_addr);

	rtl8201_phy_read(dev, MII_PHYID_H, &phy_id[0]);
	rtl8201_phy_read(dev, MII_PHYID_L, &phy_id[1]);
	oui = ((u32)phy_id[0] << MII_PH_OUI_H_C_SHIFT |
			((phy_id[1]&MII_PL_OUI_L_MASK) >> MII_PL_OUI_L_SHIFT));
	model = (phy_id[1]&MII_PL_MODEL_MASK) >> MII_PL_MODEL_SHIFT;
	rev = (phy_id[1]&MII_PL_REV_MASK);
	debug("OUI:0x%08x, MODEL:%d, REV:%d\n", oui, model, rev);

	if(oui != RTL8201_PHY_ID_OUI) {
		printf("Not matached OUI !!!\n");
	}

	/*
	 * Adjust RMII mode
	 */
	rtl8201_phy_write(dev, RTL8201_PSR , 0x7);	// select page 7
	rtl8201_phy_write(dev, RTL8201_RMSR, 0x77A);
	rtl8201_phy_write(dev, RTL8201_PSR , 0x0);	// select page 0

	/* Get supported features */
	dev->supported = 0;
	rtl8201_phy_read(dev, MII_STATUS, &status);
	if(status & MII_STATUS_ANA)		dev->supported |= PHY_SUPPORT_AUTONEGO;
	if(status & MII_STATUS_100XFD)	dev->supported |= PHY_SUPPORT_100FD;
	if(status & MII_STATUS_100XHD)	dev->supported |= PHY_SUPPORT_100HD;
	if(status & MII_STATUS_10FD)	dev->supported |= PHY_SUPPORT_10FD;
	if(status & MII_STATUS_10HD)	dev->supported |= PHY_SUPPORT_10HD;

	dev->priv = rtl8201;

	return dev;
}

static int rtl8201_start(phy_dev_t *dev, u32 support)
{
	u16 ana;
	u16 val;
	timeout_id_t tid;

	//autonegotiate advertisement registers
	rtl8201_phy_read(dev, MII_ANA, &ana);

	if(!(support&PHY_SUPPORT_AUTONEGO)) {
		printf("Only support auto-negotiation\n");
		support |= PHY_SUPPORT_AUTONEGO;
	}

	debug("Auto-Negotiation Advertisement : 0x%x\n", ana);
	support &= dev->supported;
	ana &= ~(MII_ANA_TAF_MASK);

	if(support & PHY_SUPPORT_100FD) {
		debug("100BASE_TX_FD-advertised\n");
		ana |= (MII_TAF_100TXFD << MII_ANA_TAF_SHIFT);
	}

	if(support & PHY_SUPPORT_100HD) {
		debug("100BASE_TX_HD-advertised\n");
		ana |= (MII_TAF_100TXHD << MII_ANA_TAF_SHIFT);
	}

	if(support & PHY_SUPPORT_10FD) {
		debug ("10BASE_TX_FD-advertised\n");
		ana |= (MII_TAF_10TFD << MII_ANA_TAF_SHIFT);
	}

	if(support & PHY_SUPPORT_10HD) {
		debug ("10BASE_TX_HD-advertised\n");
		ana |= (MII_TAF_10THD << MII_ANA_TAF_SHIFT);
	}
	rtl8201_phy_write(dev, MII_ANA, ana);

	debug("Starting auto-negotiation...\n");

	//enable & restart  autonegotiate
	rtl8201_phy_read(dev, MII_CTRL, &val);
	val |= (MII_CTRL_ANE | MII_CTRL_RAN);
	rtl8201_phy_write(dev, MII_CTRL, val);

	/* Wait for link to be up */
#if 0
	rtl8201_phy_read(dev, MII_STATUS, &status);
	if(status&MII_STATUS_LS) {
		printf("Link is up !!!\n");
	}
	printf("STATUS : 0x%04x\n", status);
#endif

	set_timeout(&tid, PHY_AUTO_NEGO_TIMEOUT);
	while(1) {
		rtl8201_phy_read(dev, MII_STATUS, &val);
		if(val&MII_STATUS_ANC) break;

		if(is_timeout(&tid)) {
			printf("auto-negotiation timeout...\n");
			return -1;
		}
		if(get_ctrl_c()) return -1;
	}

	dev->link = 1;

	rtl8201_phy_read(dev, MII_ANLPA, &val);
	ana &= val;
	debug(" Auto-Neg Link Partner Ability : 0x%x, 0x%x\n", val, ana);

	val = (ana >> MII_ANA_TAF_SHIFT);

	if(val & (MII_TAF_100TXFD | MII_TAF_100TXHD)) dev->speed = PHY_SPEED_100;
	else dev->speed = PHY_SPEED_10;

	if(val & (MII_TAF_100TXFD | MII_TAF_10TFD)) dev->duplex = PHY_DUPLEX_FULL;
	else dev->duplex = PHY_DUPLEX_HALF;

	return 0;
}

static phy_driver_t rtl8201_driver =
{
	.init		= rtl8201_init,
	.connect	= rtl8201_connect,
	.start		= rtl8201_start,
};

phy_driver_t* get_phy_driver(void)
{
	return &rtl8201_driver;
}
#endif
