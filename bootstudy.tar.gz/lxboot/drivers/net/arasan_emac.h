/*
 * Driver for L8 On-Chip MAC device
 * file : l8_mac.h
 *
 * author : SC Jung
 * date : 15.SEP.2009
 */


/* functin prototype */

#ifndef _ARASAN_EMAC_
#define _ARASAN_EMAC_


//defines
#define LINK_SPEED_1000MBPS  				1000
#define LINK_HD					1
#define LINK_FD					2


//Descriptor buffer structure
struct _stEmacDescBuffer {
	//	pst_sk_buff pstSkb;
	UINT64 u64DMAAddress;
	PVOID pvBuffVirtAddress;
	ULONG ulTimeStamp;
	UINT16 u16DMALength;
	UINT16 u16NextToWatch;
};

typedef struct _stEmacDescBuffer  stEmacDescBuffer, *pstEmacDescBuffer;



//Receive Descriptor structur
struct _stEmacRxDesc {
	UINT32 FramePacketLength:14;
	UINT32 ApplicationStatus:15;
	UINT32 LastDescriptor:1;
	UINT32 FirstDescriptor:1;
	UINT32 OWN:1;

	UINT32 BufferSize1:12;
	UINT32 BufferSize2:12;
	UINT32 Reserved1:1;
	UINT32 SecondAddressChained:1;
	UINT32 EndRing:1;
	UINT32 Reserved2:5;

	UINT32 BufferAddr1;
	UINT32 BufferAddr2;
};

typedef struct _stEmacRxDesc  stEmacRxDesc, *pstEmacRxDesc;

//Transmit Descriptor
struct _stEmacTxDesc {
	UINT32 FramePacketStatus:31;
	UINT32 OWN:1;

	UINT32 BufferSize1:12;
	UINT32 BufferSize2:12;
	UINT32 ForceEOPError:1;
	UINT32 SecondAddressChained:1;
	UINT32 EndRing:1;
	UINT32 DisablePadding:1;
	UINT32 AddCRCDisable:1;
	UINT32 FirstSegment:1;
	UINT32 LastSegment:1;
	UINT32 InterruptOnCompletion:1;

	UINT32 BufferAddr1;
	UINT32 BufferAddr2;
};

typedef struct _stEmacTxDesc  stEmacTxDesc, *pstEmacTxDesc;







//The following table lists the Names and Addresses (offset) for all Registers in the EMAC-AHB Core

// BUS address
#define	MAC_MMIO_START		EMAC_BASE	//0xFA000000
//#define	MAC_MMIO_START		0x40002000
#define	MAC_MMIO_LEN		0x1E8

#define	MAC_IRQ_NUM		IRQ_FEMAC


//DMA register set
#define DMA_CONFIGURATION								0x0000
#define DMA_CONTROL									0x0004
#define DMA_STATUS_IRQ									0x0008
#define DMA_INTERRUPT_ENABLE							0x000C

#define DMA_TRANSMIT_AUTO_POLL_COUNTER				0x0010
#define DMA_TRANSMIT_POLL_DEMAND						0x0014
#define DMA_RECEIVE_POLL_DEMAND						0x0018

#define DMA_TRANSMIT_BASE_ADDRESS					0x001C
#define DMA_RECEIVE_BASE_ADDRESS						0x0020
#define DMA_MISSED_FRAME_COUNTER						0x0024
#define DMA_STOP_FLUSH_COUNTER						0x0028

#define DMA_CURRENT_TRANSMIT_DESCRIPTOR_POINTER	0x0030
#define DMA_CURRENT_TRANSMIT_BUFFER_POINTER		0x0034
#define DMA_CURRENT_RECEIVE_DESCRIPTOR_POINTER		0x0038
#define DMA_CURRENT_RECEIVE_BUFFER_POINTER			0x003C

//MAC Register set
#define MAC_GLOBAL_CONTROL							0x0100
#define MAC_TRANSMIT_CONTROL							0x0104
#define MAC_RECEIVE_CONTROL							0x0108
#define MAC_MAXIMUM_FRAME_SIZE						0x010C
#define MAC_TRANSMIT_JABBER_SIZE						0x0110
#define MAC_RECEIVE_JABBER_SIZE						0x0114
#define MAC_ADDRESS_CONTROL							0x0118
#define MAC_ADDRESS1_HIGH								0x0120
#define MAC_ADDRESS1_MED								0x0124
#define MAC_ADDRESS1_LOW								0x0128
#define MAC_ADDRESS2_HIGH								0x012C
#define MAC_ADDRESS2_MED								0x0130
#define MAC_ADDRESS2_LOW								0x0134
#define MAC_ADDRESS3_HIGH								0x0138
#define MAC_ADDRESS3_MED								0x013C
#define MAC_ADDRESS3_LOW								0x0140
#define MAC_ADDRESS4_HIGH								0x0144
#define MAC_ADDRESS4_MED								0x0148
#define MAC_ADDRESS4_LOW								0x014C
#define MAC_MULTICAST_HASH_TABLE1					0x0150
#define MAC_MULTICAST_HASH_TABLE2					0x0154
#define MAC_MULTICAST_HASH_TABLE3					0x0158
#define MAC_MULTICAST_HASH_TABLE4					0x015C
#define MAC_FC_CONTROL									0x0160
#define MAC_FC_PAUSE_FRAME_GENERATE					0x0164
#define MAC_FC_SOURCE_ADDRESS_HIGH					0x0168
#define MAC_FC_SOURCE_ADDRESS_MED					0x016C
#define MAC_FC_SOURCE_ADDRESS_LOW					0x0170
#define MAC_FC_DESTINATION_ADDRESS_HIGH				0x0174
#define MAC_FC_DESTINATION_ADDRESS_MED				0x0178
#define MAC_FC_DESTINATION_ADDRESS_LOW				0x017C
#define MAC_FC_PAUSE_TIME_VALUE						0x0180
#define MAC_MDIO_CONTROL								0x01A0
#define MAC_MDIO_DATA									0x01A4
#define MAC_RX_STATCTR_CONTROL						0x01A8
#define MAC_RX_STATCTR_DATA_HIGH						0x01AC
#define MAC_RX_STATCTR_DATA_LOW						0x01B0
#define MAC_TX_STATCTR_CONTROL						0x01B4
#define MAC_TX_STATCTR_DATA_HIGH						0x01B8
#define MAC_TX_STATCTR_DATA_LOW						0x01BC
#define MAC_TRANSMIT_FIFO_ALMOST_FULL				0x01C0
#define MAC_TRANSMIT_PACKET_START_THRESHOLD		0x01C4
#define MAC_RECEIVE_PACKET_START_THRESHOLD			0x01C8
#define MAC_STATUS_IRQ									0x01E0
#define MAC_INTERRUPT_ENABLE							0x01E4

//Receive Descriptors
#define MAC_RECEIVE_DESCRIPTOR0						0xFFFF
#define MAC_RECEIVE_DESCRIPTOR1						0xFFFF
#define MAC_RECEIVE_DESCRIPTOR2						0xFFFF
#define MAC_RECEIVE_DESCRIPTOR3						0xFFFF

//Transmit Descriptors
#define MAC_TRANSMIT_DESCRIPTOR0						0xFFFF
#define MAC_TRANSMIT_DESCRIPTOR1						0xFFFF
#define MAC_TRANSMIT_DESCRIPTOR2						0xFFFF
#define MAC_TRANSMIT_DESCRIPTOR3						0xFFFF


//DMA_CONFIGURATION (0x0000) register bit info
#define MREGBIT_SOFTWARE_RESET 							0x00000001 //0-DMA controller in normal operation mode, 1-DMA controller reset to default state,clearing all internal state information
#define MREGBIT_BURST_LENGTH 								0x000000FE //0000001 -  1 Word, 0000010 -  2 Words, 0000100 -  4 Words, 0001000 -  8 Words, 0010000 -  16 Words, 0100000 -  32 Words, 1000000 -  64 Words
#define MREGBIT_DESCRIPTOR_SKIP_LENGTH 					0x00001F00 //This field specifies the number of 32-bit words to skip between two unchained Descriptors.
#define MREGBIT_DESRIPTOR_BYTE_ORDERING 				0x00002000 //For Receive and Transmit DMA operate in Big-Endian mode for Descriptors.
#define MREGBIT_BIG_LITLE_ENDIAN 							0x00004000 //0-Big Endian, 1-Little endian.
#define MREGBIT_TX_RX_ARBITRATION 						0x00008000 //0-Receive DMA has priority over Transmit DMA.
#define MREGBIT_WAIT_FOR_DONE 							0x00010000 //0-Transmit DMA does not wait for the done, 1-Transmit DMA waits for the done.

//DMA_CONTROL (0x0004) register bit info
#define MREGBIT_START_STOP_TRANSMIT_DMA				0x00000001 //0-Transmit DMA in stopped state, 1-Transmit DMA in running state.
#define MREGBIT_START_STOP_RECEIVE_DMA					0x00000002 //0-Receive DMA in stopped state, 1-Receive DMA in running state.

//DMA_STATUS_IRQ (0x0008) register bit info
#define MREGBIT_TRANSMIT_TRANSFER_DONE_IRQ 				0x00000001 //Frame transmission completed.
#define MREGBIT_TRANSMIT_DES_UNAVAILABLE_IRQ				0x00000002 //Next descriptor on the transmit list is owned by the host and cannot be acquired by the EMAC-AHB Core.
#define MREGBIT_TRANSMIT_DMA_STOPPED_IRQ					0x00000004 //Transmit DMA enters stopped state.
#define MREGBIT_RECEIVE_TRANSFER_DONE_IRQ				0x00000010 //completion of frame reception.
#define MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ				0x00000020 //Next descriptor in the receive list is owned by the host and cannot be acquired by the EMAC-AHB Core.
#define MREGBIT_RECEIVE_DMA_STOPPED_IRQ					0x00000040 //Receive DMA enters in stopped state.
#define MREGBIT_RECEIVE_MISSED_FRAME_IRQ					0x00000080 //Frame is dropped.
#define MREGBIT_TRANSMIT_DMA_STATE						0x00070000 //000-STOPPED, 001-FETCH_DESCRIPTOR, 010-FETCH_DATABUFFER, 011-WAIT_FOR_END_OF_TRANSMISSION, 100- CLOSE_DESCRIPTOR, 101- SUSPENDED, 110-Reserved and 111- Reserved
#define MREGBIT_RECEIVE_DMA_STATE							0x00380000 //000-STOPPED, 001-FETCH_DESCRIPTOR, 010-WAIT_FOR_END_OF_RECEIVE, 011-WAIT_FOR_RXFRAME, 100-SUSPENDED, 101-CLOSE_DESCRIPTOR, 110-FLUSH_BUFFER, 111-PUT_BUFFER.

//DMA_INTERRUPT_ENABLE ( 0x000C) register bit info
#define MREGBIT_TRANSMIT_TRANSFER_DONE_INTR_ENABLE 		0x00000001 //Transmit Transfer Done IRQ is used in generation of Interrupt onto the AHB Bus.
#define MREGBIT_TRANSMIT_DES_UNAVAILABLE_INTR_ENABLE	0x00000002 //Transmit Descriptor Unavailable IRQ is used in generation of Interrupt onto the AHB Bus.
#define MREGBIT_TRANSMIT_DMA_STOPPED_INTR_ENABLE		0x00000003 //Transmit DMA Stopped IRQ is used in generation of Interrupt onto the AHB Bus.
#define MREGBIT_RECEIVE_TRANSFER_DONE_INTR_ENABLE		0x00000010 //Receive Transfer Done IRQ is used in generation of Interrupt onto the AHB Bus.
#define MREGBIT_RECEIVE_DES_UNAVAILABLE_INTR_ENABLE		0x00000020 //Receive Descriptor Unavailable IRQ is used in generation of Interrupt onto the AHB Bus.
#define MREGBIT_RECEIVE_DMA_STOPPED_INTR_ENABLE			0x00000040 //Receive DMA Stopped IRQ is used in generation of Interrupt onto the AHB Bus.
#define MREGBIT_RECEIVE_MISSED_FRAME_INTR_ENABLE		0x00000080 //Receive Missed Frame IRQ is used in generation of Interrupt onto the AHB Bus.
#define MREGBIT_MAC_INTR_ENABLE						0x00000080 //Receive Missed Frame IRQ is used in generation of Interrupt onto the AHB Bus.

//DMA_TRANSMIT_AUTO_POLL_COUNTER ( 0x0010) register bit info
#define MREGBIT_TRANSMIT_AUTO_POLL 						0x0000FFFF //This value determines the number of AHB Clocks to wait in the Suspended State before the Transmit DMA goes and re-fetches the Descriptor.

//TRANSMIT_POLL_DEMAND ( 0x0014) register bit info
#define MREGBIT_TRANSMIT_POLL_DEMAND					0xFFFFFFFF //This is a Write Only register.

//DMA_RECEIVE_POLL_DEMAND( 0x0018) register bit info
#define MREGBIT_RECEIVE_POLL_DEMAND						0xFFFFFFFF //This is a Write Only register.

//DMA_TRANSMIT_BASE_ADDRESS (0x001C) register bit info
#define MREGBIT_TRANSMIT_BASE_ADDRESS					0xFFFFFFFF //The value contains the Start of the Transmit Descriptor list in the Host Memory Space.

//DMA_RECEIVE_BASE_ADDRESS (0x0020) register bit info
#define MREGBIT_RECEIVE_BASE_ADDRESS					0xFFFFFFFF //The value contains the Start of the Receive Descriptor list in the Host Memory Space.

//DMA_MISSED_FRAME_COUNTER(0x0024) register bit info
#define MREGBIT_MISSED_FRAME_COUNTER_OVERFLOW_IRQ	0x80000000 //Missed Frame Counter rolls-over.
#define MREGBIT_MISSED_FRAME_COUNTER					0x7FFFFFFF //The Missed Frame Counter presents the number of frames that were missed because of the Receive Descriptor Unavailability.

//DMA_STOP_FLUSH_COUNTER(0x0024) register bit info
#define MREGBIT_STOP_COUNTER_OVERFLOW_IRQ				0x80000000 //This bit is set when the Stop Flulsh Counter rolls-over. Setting this bit doesn't cause an interrupt to be generated.
#define MREGBIT_STOP_COUNTER								0x7FFFFFFF //This counter represents total number of frames that flushed since the counter was last read.

//DMA_CURRENT_TRANSMIT_DESCRIPTOR_POINTER(0x0030) register bit info
#define MREGBIT_CURRENT_TRANSMIT_DESCRIPTION_POINTER				0xFFFFFFFF //This field contains the current descriptor pointer the Transmit DMA is using.

//DMA_CURRENT_TRANSMIT_BUFFER_POINTER(0x0034) register bit info
#define MREGBIT_CURRENT_TRANSMIT_BUFFER_POINTER					0xFFFFFFFF //This field contains the current buffer pointer the Transmit DMA is using.

//DMA_CURRENT_RECEIVE_DESCRIPTOR_POINTER(0x0038) register bit info
#define MREGBIT_CURRENT_RECEIVE_DESCRIPTOR_POINTER				0xFFFFFFFF //This field contains the current descriptor pointer the Receive DMA is using.

//DMA_CURRENT_RECEIVE_BUFFER_POINTER(0x003C) register bit info
#define MREGBIT_CURRENT_RECEIVE_BUFFER_POINTER					0xFFFFFFFF //This field contains the current buffer pointer the Receive DMA is using.




//MAC_GLOBAL_CONTROL (0x0100) register bit info
#define MREGBIT_SPEED										0x00000003 //00-10Mbps, 01-100Mbps, 10-1000Mbps, 11-Reserved
#define MREGBIT_DUPLEX_MODE								0x00000004 //0-half, 1-full
#define MREGBIT_HALF_DUPLEX_MODE							0x00000000 //0-half, 1-full
#define MREGBIT_FULL_DUPLEX_MODE							0x00000004 //0-half, 1-full
#define MREGBIT_RESET_RX_STAT_COUNTERS					0x00000008 //
#define MREGBIT_RESET_TX_STAT_COUNTERS					0x00000010

//MAC_TRANSMIT_CONTROL (0x0104) register bit info
#define MREGBIT_TRANSMIT_ENABLE							0x00000001
#define MREGBIT_INVERT_FCS									0x00000002
#define MREGBIT_DISABLE_FCS_INSERT						0x00000004
#define MREGBIT_TRANSMIT_AUTO_RETRY						0x00000008
#define MREGBIT_IFG_LEN										0x00000030 //00: 96 Bit Times of IFG, 01: 64 Bit Times of IFG, 10: 128 Bit Times of IFG, 11: 256 Bit Times of IFG
#define MREGBIT_PREAMBLE_LENGTH							0x000000C0 //00: 7 Bytes of Preamble, 01: Reserved, 10: 3 Bytes of Preamble, 11: 5 Bytes of Preamble

//MAC_RECEIVE_CONTROL (0x0108) register bit info
#define MREGBIT_RECEIVE_ENABLE								0x00000001
#define MREGBIT_DISABLE_FCS_CHECK							0x00000002
#define MREGBIT_STRIP_FCS									0x00000004
#define MREGBIT_STORE_FORWARD								0x00000008
#define MREGBIT_STATUS_FIRST								0x00000010
#define MREGBIT_PASS_BAD_FRAMES							0x00000020
#define MREGBIT_ACOOUNT_VLAN								0x00000040


//MAC_MAXIMUM_FRAME_SIZE (0x010C) register bit info
#define MREGBIT_MAX_FRAME_SIZE							0x00003FFF

//MAC_TRANSMIT_JABBER_SIZE (0x0110) register bit info
#define MREGBIT_TRANSMIT_JABBER_SIZE						0x0000FFFF


//MAC_RECEIVE_JABBER_SIZE (0x0114) register bit info
#define MREGBIT_RECEIVE_JABBER_SIZE						0x0000FFFF

//MAC_ADDRESS_CONTROL	 (0x0118) register bit info
#define MREGBIT_MAC_ADDRESS1_ENABLE						0x00000001
#define MREGBIT_MAC_ADDRESS2_ENABLE						0x00000002
#define MREGBIT_MAC_ADDRESS3_ENABLE						0x00000004
#define MREGBIT_MAC_ADDRESS4_ENABLE						0x00000008
#define MREGBIT_INVERSE_MAC_ADDRESS1_ENABLE				0x00000010
#define MREGBIT_INVERSE_MAC_ADDRESS2_ENABLE				0x00000020
#define MREGBIT_INVERSE_MAC_ADDRESS3_ENABLE				0x00000040
#define MREGBIT_INVERSE_MAC_ADDRESS4_ENABLE				0x00000080
#define MREGBIT_PROMISCUOUS_MODE							0x00000100


//MAC_ADDRESS1_HIGH (0x0120) register bit info
#define MREGBIT_MAC_ADDRESS1_01_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_02_BYTE					0x0000FF00
//MAC_ADDRESS1_MED (0x0124) register bit info
#define MREGBIT_MAC_ADDRESS1_03_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_04_BYTE					0x0000FF00
//MAC_ADDRESS1_LOW (0x0128) register bit info
#define MREGBIT_MAC_ADDRESS1_05_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_06_BYTE					0x0000FF00

//MAC_ADDRESS2_HIGH (0x0120) register bit info
#define MREGBIT_MAC_ADDRESS1_01_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_02_BYTE					0x0000FF00
//MAC_ADDRESS2_MED (0x0124) register bit info
#define MREGBIT_MAC_ADDRESS1_03_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_04_BYTE					0x0000FF00
//MAC_ADDRESS2_LOW (0x0128) register bit info
#define MREGBIT_MAC_ADDRESS1_05_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_06_BYTE					0x0000FF00

//MAC_ADDRESS3_HIGH (0x0120) register bit info
#define MREGBIT_MAC_ADDRESS1_01_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_02_BYTE					0x0000FF00
//MAC_ADDRESS3_MED (0x0124) register bit info
#define MREGBIT_MAC_ADDRESS1_03_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_04_BYTE					0x0000FF00
//MAC_ADDRESS3_LOW (0x0128) register bit info
#define MREGBIT_MAC_ADDRESS1_05_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_06_BYTE					0x0000FF00

//MAC_ADDRESS4_HIGH (0x0120) register bit info
#define MREGBIT_MAC_ADDRESS1_01_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_02_BYTE					0x0000FF00
//MAC_ADDRESS4_MED (0x0124) register bit info
#define MREGBIT_MAC_ADDRESS1_03_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_04_BYTE					0x0000FF00
//MAC_ADDRESS4_LOW (0x0128) register bit info
#define MREGBIT_MAC_ADDRESS1_05_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS1_06_BYTE					0x0000FF00


//MAC_HASH_TABLE1 (0x0150) register bit info
#define MREGBIT_HASH_TABLE_BITS							0x000000FF
//MAC_HASH_TABLE2 (0x0150) register bit info
#define MREGBIT_HASH_TABLE_BITS							0x000000FF
//MAC_HASH_TABLE3 (0x0150) register bit info
#define MREGBIT_HASH_TABLE_BITS							0x000000FF
//MAC_HASH_TABLE4 (0x0150) register bit info
#define MREGBIT_HASH_TABLE_BITS							0x000000FF

//MAC_FC_CONTROL (0x0160) register bit info
#define MREGBIT_FC_DECODE_ENABLE							0x00000001
#define MREGBIT_FC_GENERATION_ENABLE						0x00000002
#define MREGBIT_AUTO_FC_GENERATION_ENABLE				0x00000004
#define MREGBIT_MULTICAST_MODE							0x00000008
#define MREGBIT_BLOCK_PAUSE_FRAMES						0x00000010


//MAC_FC_PAUSE_FRAME_GENERATE (0x0164) register bit info
#define MREGBIT_GENERATE_PAUSE_FRAME					0x00000001


//MAC_FC_SOURCE_ADDRESS_HIGH (0x0168) register bit info
#define MREGBIT_MAC_ADDRESS_01_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS_02_BYTE					0x0000FF00
//MAC_FC_SOURCE_ADDRESS_MED (0x016C) register bit info
#define MREGBIT_MAC_ADDRESS_03_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS_04_BYTE					0x0000FF00
//MAC_FC_SOURCE_ADDRESS_LOW (0x0170) register bit info
#define MREGBIT_MAC_ADDRESS_05_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS_06_BYTE					0x0000FF00

//MAC_FC_DESTINATION_ADDRESS_HIGH (0x0174) register bit info
#define MREGBIT_MAC_ADDRESS_01_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS_02_BYTE					0x0000FF00
//MAC_FC_DESTINATION_ADDRESS_MED (0x0178) register bit info
#define MREGBIT_MAC_ADDRESS_03_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS_04_BYTE					0x0000FF00
//MAC_FC_DESTINATION_ADDRESS_LOW (0x017C) register bit info
#define MREGBIT_MAC_ADDRESS_05_BYTE					0x000000FF
#define MREGBIT_MAC_ADDRESS_06_BYTE					0x0000FF00


//MAC_FC_PAUSE_TIME_VALUE (0x0180) register bit info
#define MREGBIT_MAC_FC_PAUSE_TIME						0x0000FFFF

//MAC_MDIO_CONTROL (0x01A0) register bit info
#define MREGBIT_PHY_ADDRESS								0x0000001F
#define MREGBIT_REGISTER_ADDRESS							0x000003E0
#define MREGBIT_MDIO_READ_WRITE							0x00000400
#define MREGBIT_START_MDIO_TRANS							0x00008000

//MAC_MDIO_DATA (0x01A4) register bit info
#define MREGBIT_MDIO_DATA									0x000000FF

//MAC_RX_STATCTR_CONTROL (0x01A8) register bit info
#define MREGBIT_RX_COUNTER_NUMBER						0x0000001F
#define MREGBIT_START_RX_COUNTER_READ					0x00008000


//MAC_RX_STATCTR_DATA_HIGH (0x01AC) register bit info
#define MREGBIT_RX_STATCTR_DATA_HIGH					0x000000FF
//MAC_RX_STATCTR_DATA_LOW (0x01B0) register bit info
#define MREGBIT_RX_STATCTR_DATA_LOW						0x000000FF


//MAC_TX_STATCTR_CONTROL (0x01B4) register bit info
#define MREGBIT_TX_COUNTER_NUMBER						0x0000001F
#define MREGBIT_START_TX_COUNTER_READ					0x00008000


//MAC_TX_STATCTR_DATA_HIGH (0x01B8) register bit info
#define MREGBIT_TX_STATCTR_DATA_HIGH					0x000000FF
//MAC_TX_STATCTR_DATA_LOW (0x01BC) register bit info
#define MREGBIT_TX_STATCTR_DATA_LOW						0x000000FF


//MAC_TRANSMIT_FIFO_ALMOST_FULL (0x01C0) register bit info
#define MREGBIT_TX_FIFO_AF								0x00003FFF

//MAC_TRANSMIT_PACKET_START_THRESHOLD (0x01C4) register bit info
#define MREGBIT_TX_PACKET_START_THRESHOLD				0x00003FFF

//MAC_RECEIVE_PACKET_START_THRESHOLD (0x01C8) register bit info
#define MREGBIT_RX_PACKET_START_THRESHOLD				0x00003FFF

//MAC_STATUS_IRQ  (0x01E0) register bit info
#define MREGBIT_MAC_UNDERRUN_IRQ							(0x01)
#define MREGBIT_MAC_JABBER_IRQ								(0x0x<<1)


//MAC_INTERRUPT_ENABLE (0x01E4) register bit info
#define MREGBIT_MAC_UNDERRUN_INTERRUPT_ENABLE			(0x01)
#define MREGBIT_JABBER_INTERRUPT_ENABLE					(0x0x<<1)


//Receive Descriptors
//MAC_RECEIVE_DESCRIPTOR0 () register bit info
#define MREGBIT_FRAME_LENGTH								0x00003FFF
#define MREGBIT_APPLICATION_STATUS						0x1FFF0000
#define MREGBIT_LAST_DESCRIPTOR							0x20000000
#define MREGBIT_FIRST_DESCRIPTOR							0x40000000
#define MREGBIT_OWN_BIT									0x80000000

//MAC_RECEIVE_DESCRIPTOR1 () register bit info
#define MREGBIT_BUFFER1_SIZE								0x00000FFF
#define MREGBIT_BUFFER2_SIZE								0x00FFF000
#define MREGBIT_SECOND_ADDRESS_CHAINED					0x02000000
#define MREGBIT_END_OF_RING								0x04000000

//MAC_RECEIVE_DESCRIPTOR2 () register bit info
#define MREGBIT_BUFFER_ADDRESS1							0xFFFFFFFF


//MAC_RECEIVE_DESCRIPTOR3 () register bit info
#define MREGBIT_BUFFER_ADDRESS1							0xFFFFFFFF


//Transmit Descriptors
//TD_TRANSMIT_DESCRIPTOR0 () register bit info
#define MREGBIT_TX_PACKET_STATUS							0x7FFFFFFF
#define MREGBIT_OWN_BIT									0x80000000

//TD_TRANSMIT_DESCRIPTOR1 () register bit info
#define MREGBIT_BUFFER1_SIZE								0x00000FFF
#define MREGBIT_BUFFER2_SIZE								0x00FFF000
#define MREGBIT_FORCE_EOP_ERROR							0x01000000
#define MREGBIT_SECOND_ADDRESS_CHAINED					0x02000000
#define MREGBIT_END_OF_RING								0x04000000
#define MREGBIT_DISABLE_PADDING							0x08000000
#define MREGBIT_ADD_CRC_DISABLE							0x10000000
#define MREGBIT_FIRST_SEGMENT							0x20000000
#define MREGBIT_LAST_SEGMENT								0x40000000
#define MREGBIT_INTERRUPT_ON_COMPLETION					0x80000000


//TD_TRANSMIT_DESCRIPTOR2 () register bit info
#define MREGBIT_BUFFER_ADDRESS1							0xFFFFFFFF


//TD_TRANSMIT_DESCRIPTOR3 () register bit info
#define MREGBIT_BUFFER_ADDRESS1							0xFFFFFFFF


/*	PHY 8700 Chip register set	*/
#ifdef CONFIG_MACH_DTVSOC_EVALUATION
#define PHY_BASE_ADDRESS 	0x3
#else
#define PHY_BASE_ADDRESS        0x1f
#endif

#define PHY_BMCR 			0x00 //RW Basic Mode Control Register
#define PHY_BMSR 			0x01 //RO Basic Mode Status Register
#define PHY_PHYIDR1 		0x02 //RO PHY Identifier Register #1
#define PHY_PHYIDR2 		0x03 //RO PHY Identifier Register #2
#define PHY_ANAR 			0x04 //RW Auto-Negotiation Advertisement Register
#define PHY_ANLPAR 			0x05 //RW Auto-Negotiation Link Partner Ability Register
#define PHY_ANER 			0x06 //RW Auto-Negotiation Expansion Register
#define PHY_ANNPTR 			0x07 //RW Auto-Negotiation Next Page TX
#define PHY_ANNPRR 			0x08 //RW Auto-Negotiation Next Page RX
#define PHY_1KTCR 			0x09 //RW 1000BASE-T Control Register
#define PHY_1KSTSR 			0x0A //RO 1000BASE-T Status Register
//0x0B-0x0E 11-14 RO Reserved Reserved
#define PHY_1KSCR 			0x0F //RO 1000BASE-T Extended Status Register
#define PHY_STRAP_REG 		0x10 //RO Strap Options Register
#define PHY_LINK_AN 		0x11 //RO Link and Auto-Negotiation Status Register	AA
#define PHY_AUX_CTRL 		0x12 //RW Auxiliary Control Register
#define PHY_LED_CTRL 		0x13 //RW LED Control Register
#define PHY_INT_STATUS 		0x14 //RO Interrupt Status Register
#define PHY_INT_MASK 		0x15 //RW Interrupt Mask Register			AA
#define PHY_EXP_MEM_CTL 	0x16 //RO Expanded Memory Access Control
#define PHY_INT_CLEAR 		0x17 //RW Interrupt Clear Register			AA
#define PHY_BIST_CNT 		0x18 //RW BIST Counter Register
#define PHY_BIST_CFG1 		0x19 //RW BIST Configuration Register #1
#define PHY_BIST_CFG2_BIST 	0x1A //RW Configuration Register #2
//0x1B-0x1C 27-28 RO Reserved Reserved
#define PHY_EXP_MEM_DATA 	0x1D //RW Expanded Memory Data
#define PHY_EXP_MEM_ADDR 	0x1E //RW Expanded Memory Address
#define PHY_PHY_SUP 		0x1F //RW PHY Support Register

//PHY register bit information BMCR
//PHY_BMCR bit info
#define PREGBIT_RESET 			(0x01<<15)//default 0, RW, SC
#define PREGBIT_LOOPBACK 		(0x01<<14)//default 0, RW
#define PREGBIT_SPEED0 		(0x01<<13)//default STRAP[0], RW
#define PREGBIT_BMCR_AN_EN 			(0x01<<12)//default STRAP[1], RW
#define PREGBIT_POWER_DOWN 	(0x01<<11) //default 0, RW
#define PREGBIT_ISOLATE 		(0x01<<10) //default 0, RW
#define PREGBIT_RESTART_AN 	(0x01<<9) //default 0, RW, SC
#define PREGBIT_DUPLEX 		(0x01<<8) //default STRAP[1],
#define PREGBIT_COLLISION_TEST (0x01<<7) //default 0, RW
#define PREGBIT_SPEED1 		(0x01<<6) //STRAP[0],


//PHY_BMSR bit info
#define PREGBIT_BMSR_100BASE_T4 (0x01<<15)//-0, P
#define PREGBIT_BMSR_100BASE_X_FD (0x01<<14) //default 1, P
#define PREGBIT_BMSR_100BASE_X_HD (0x01<<13) //default 1, P
#define PREGBIT_BMSR_10BASE_T_FD (0x01<<12) //default 1, P
#define PREGBIT_BMSR_10BASE_T_HD (0x01<<11) //default 1, P
#define PREGBIT_BMSR_100BASE_T2_FD (0x01<<10) //default 0, P
#define PREGBIT_BMSR_100BASE_T2_HD (0x01<<9) //default 0, P
#define PREGBIT_BMSR_1000BASE_T_EXTENDED_STATUS (0x01<<8) //default 1, P
#define PREGBIT_PREAMBLE_SUPPRESSION (0x01<<6) //default 1, P
#define PREGBIT_AUTO_NEGOTIATION_COMPLETE (0x01<<5) //default 0, RO
#define PREGBIT_REMOTE_FAULT (0x01<<4) //default 0, RO, LH
#define PREGBIT_AUTO_NEGOTIATION_ABILITY (0x01<<3) //default 1, P
#define PREGBIT_LINK_STATUS (0x01<<2) //default 0, RO, LL
#define PREGBIT_JABBER_DETECT (0x01<<1) //default 0, RO, LH
#define PREGBIT_EXTENDED_CAPABILITY (0x01<<0) //default 1, P


//PHY_PHYIDR2 bit info
#define PREGBIT_OUI (0x3f<<10) //default  <01_0111>, P
#define PREGBIT_VNDR_MDL (0x1f<<4) //default  <00_0111>, P
#define PREGBIT_MDL_REV (0x0f) //default  <1010>, P


//PHY_ANAR bit info
#define PREGBIT_ANAR_NP (0x01<<15) //default  0, RW
#define PREGBIT_ANAR_RF (0x01<<13) //default  0, RW
#define PREGBIT_ANAR_ASY_PAUSE (0x01<<11) //default  0, RW
#define PREGBIT_ANAR_PAUSE (0x01<<10) //default  0, RW
#define PREGBIT_ANAR_100BASE_T4 (0x01<<9) //default  0, RO
#define PREGBIT_ANAR_100BASE_TX_FD (0x01<<8) //default  STRAP[1], RW
#define PREGBIT_ANAR_100BASE_TX_HD (0x01<<7) //default  STRAP[1], RW
#define PREGBIT_ANAR_10BASE_T_FD (0x01<<6) //default  STRAP[1], RW
#define PREGBIT_ANAR_10BASE_T_HD (0x01<<5) //default  STRAP[1], RW
#define PREGBIT_ANAR_PSB (0x01<<1f) //default  <0_0001>, P

//PHY_ANLPAR bit info
#define PREGBIT_ANLPAR_NP (0x01<<15) //default  0, RO
#define PREGBIT_ANLPAR_ACK (0x01<<14) //default  0, RO
#define PREGBIT_ANLPAR_RF (0x01<<13) //default  0, RO
#define PREGBIT_ANLPAR_ASY_PAUSE (0x01<<11) //default  0, RO
#define PREGBIT_ANLPAR_PAUSE (0x01<<10) //default  0, RO
#define PREGBIT_ANLPAR_100BASET4 (0x01<<9) //default  0, RO
#define PREGBIT_ANLPAR_100BASE_TX_FD (0x01<<8) //default  0, RO
#define PREGBIT_ANLPAR_100BASE_TX_HD (0x01<<7) //default  0, RO
#define PREGBIT_ANLPAR_10BASE_T_FD (0x01<<6) //default  0, RO
#define PREGBIT_ANLPAR_10BASE_T_HD (0x01<<5) //default  0, RO
#define PREGBIT_ANLPAR_PSB (0x1f) //default  5'B<0_0000>, RO


//PHY_ANER bit info
#define PREGBIT_PDF (0x01<<4) //default 0, RO, LH
#define PREGBIT_LP_NP_ABLE (0x01<<3) //default 0, RO
#define PREGBIT_NP_ABLE (0x01<<2) //default 1, RO
#define PREGBIT_PAGE_RX (0x01<<1) //default 0, RO, LH
#define PREGBIT_LP_AN_ABLE (0x01<<0) //default 0, RO

//PHY_ANNPTR bit info
#define PREGBIT_ANNPTR_NP (0x01<<15) //default  1, RW
#define PREGBIT_ANNPTR_ACK (0x01<<14) //default  0, RO
#define PREGBIT_ANNPTR_MP (0x01<<13) //default  1, RW
#define PREGBIT_ANNPTR_ACK2 (0x01<<12) //default  0, RW
#define PREGBIT_ANNPTR_TOG_TX (0x01<<11) //default  0, RO
#define PREGBIT_ANNPTR_CODE (0x7ff) //default  RW Bit Bit Name Default


//PHY_ANNPRR bit info
#define PREGBIT_ANNPRR_NP (0x01<<15) //default 0, RO
#define PREGBIT_ANNPRR_ACK (0x01<<14) //default 0, RO
#define PREGBIT_ANNPRR_MP (0x01<<13) //default 0, RO
#define PREGBIT_ANNPRR_ACK2 (0x01<<12) //default 0, RO
#define PREGBIT_ANNPRR_TOG_RX (0x01<<11) //default 0, RO
#define PREGBIT_ANNPRR_CODE (0x7ff) //default  RO Bit Bit Name Default


//PHY_1KTCR  bit info
#define PREGBIT_1KTCR_TEST_MODE (0x07<<13) //default 0, RW
#define PREGBIT_1KTCR_MS_MANUAL_CFG_EN (0x01<<12) //default 0, RW
#define PREGBIT_1KTCR_MS_CONFIG_VALUE (0x01<<11) //default 0, RW
#define PREGBIT_1KTCR_REPEATER_ DTE (0x01<<10) //default STRAP[0], RW
#define PREGBIT_1KTCR_1000BASE_T_FD (0x01<<9) //default STRAP[1], RW
#define PREGBIT_1KTCR_1000BASE_T_HD (0x01<<8) //default STRAP[1], RW


//PHY_1KSTSR  bit info
#define PREGBIT_1KSTSR_MS_MANUAL_CFG_FAULT (0x01<<15) //default 0, RO, LH, SC
#define PREGBIT_1KSTSR_MS_CONFIG_RESOLUTION (0x01<<14) //default 0, RO
#define PREGBIT_1KSTSR_LOCAL_RECEIVER_STATUS (0x01<<13) //default 0, RO
#define PREGBIT_1KSTSR_REMOTE_RECEIVER_STATUS (0x01<<12) //default 0, RO
#define PREGBIT_1KSTSR_LP_1000BASE_T_FD (0x01<<11) //default 0, RO
#define PREGBIT_1KSTSR_LP_1000BASE_T_HD (0x01<<10) //default 0, RO
#define PREGBIT_1KSTSR_IDLE_ERROR_COUNT (0xff) //default 0, RO, SC

//PHY_1KSCR  bit info
#define PREGBIT_1KSCR_1000BASE_X_FD (0x01<<15) //default 0, P
#define PREGBIT_1KSCR_1000BASE_X_HD (0x01<<14) //default 0, P
#define PREGBIT_1KSCR_1000BASE_T_FD (0x01<<13) //default 1, P
#define PREGBIT_1KSCR_1000BASE_T_HD (0x01<<12) //default 1, P

//PHY_STRAP_REG  bit info
#define PREGBIT_STRAP_REG_AN_EN (0x01<<15) //default STRAP[1], RO
#define PREGBIT_DUPLEX_MODE (0x01<<14) //default STRAP[1], RO
#define PREGBIT_STRAP_REG_SPEED (0x03<<12) //default STRAP[00], RO
#define PREGBIT_NC_MODE_EN (0x01<<10) //default STRAP[0], RO
#define PREGBIT_MAC_CLOCK_EN (0x01<<7) //default STRAP[1], RO
#define PREGBIT_MDIX_EN (0x01<<6) //default STRAP[1], RO
#define PREGBIT_MULTI_EN (0x01<<5) //default STRAP[0], RO
#define PREGBIT_PHYADDR (0x01f) //default STRAP[0_0001], RO

//PHY_LINK_AN  bit info
#define PREGBIT_TP_POLARITY (0x0f<<12) //default 0, RO
#define PREGBIT_POWER_DOWN_STATUS (0x01<<11) //default 0, RO
#define PREGBIT_MDIX_STATUS (0x01<<10) //default 0, RO
#define PREGBIT_FIFO_ERROR (0x01<<9) //default 0, RO
#define PREGBIT_SHALLOW_LOOPBACK_STATUS (0x01<<7) //default 0, RO
#define PREGBIT_DEEP_LOOPBACK_STATUS (0x01<<6) //default 0, RO
#define PREGBIT_NON_COMPLIANT_MODE_STATUS (0x01<<5) //default 0, RO
#define PREGBIT_LINK_AN_SPEED (0x03<<3) //default STATUS STRAP[00],
#define PREGBIT_LINK_STATUS (0x01<<2) //default 0, RO
#define PREGBIT_DUPLEX_STATUS (0x01<<1) //default 0, RO
#define PREGBIT_MASTER_SLAVE_CONFIG_STATUS (0x01<<0) //default 0, RO

//PHY_AUX_CTRL  bit info
#define PREGBIT_AUTO_MDIX_EN (0x01<<15) //default STRAP[1], RW
#define PREGBIT_MANUAL_MDIX_VALUE (0x01<<14) //default STRAP[0], RW
#define PREGBIT_RGMII_EN (0x03<<12) //default STRAP[0]
#define PREGBIT_NON_COMPLIANT_MODE (0x01<<9) //default STRAP[0], RW
#define PREGBIT_RGMII_INBAND_STATUS_EN (0x01<<8) //default 0, RW
#define PREGBIT_TX_TCLK_EN (0x01<<7) //default 0, RW
#define PREGBIT_TX_TRIGGER_SYN_EN (0x01<<6) //default 0, RW
#define PREGBIT_SHALLOW_DEEP_LOOPBACK_EN (0x01<<5) //default 0, RW
#define PREGBIT_X_MAC (0x01<<4) //default 0, RW
#define PREGBIT_JABBER_DISABLE (0x01<<0) //default 0, RW

//PHY_LED_CTRL  bit info
#define PREGBIT_ACTIVITY_LED (0x03<<14) //default 0, RW
#define PREGBIT_LINK10_LED (0x03<<12) //default 0, RW
#define PREGBIT_LINK100_LED (0x03<<10) //default 0, RW
#define PREGBIT_LINK1000_LED (0x03<<8) //default 0, RW
#define PREGBIT_DUPLEX_LED (0x03<<6) //default 0, RW
#define PREGBIT_REDUCED_LED_EN (0x01<<5) //default 0, RW


//PHY_INT_STATUS  bit info
#define PREGBIT_SPD_CNG_INT (0x01<<15) //default 0, RO
#define PREGBIT_LNK_CNG_INT (0x01<<14) //default 0, RO
#define PREGBIT_DPLX_CNG_INT (0x01<<13) //default 0, RO
#define PREGBIT_MDIX_CNG_INT (0x01<<12) //default 0, RO
#define PREGBIT_POL_CNG_INT (0x01<<11) //default 0, RO
#define PREGBIT_PRL_DET_FLT_INT (0x01<<10) //default 0, RO
#define PREGBIT_MAS_SLA_ERR_INT (0x01<<9) //default 0, RO
#define PREGBIT_NO_HCD_INT (0x01<<8) //default 0, RO
#define PREGBIT_NO_LNK_INT (0x01<<7) //default 0, RO
#define PREGBIT_JABBER_CNG_INT (0x01<<6) //default 0, RO
#define PREGBIT_NXT_PG_RCVD_INT (0x01<<5) //default 0, RO
#define PREGBIT_AN_CMPL_INT (0x01<<4) //default 0, RO
#define PREGBIT_REM_FLT_CNG_INT (0x01<<3) //default 0, RO



//PHY_INT_MASK  bit info
#define PREGBIT_SPD_CNG_INT_MSK (0x01<<15) //default 0, RW
#define PREGBIT_LNK_CNG_INT_MSK (0x01<<14) //default 0, RW
#define PREGBIT_DPLX_CNG_INT_MSK (0x01<<13) //default 0, RW
#define PREGBIT_MDIX_CNG_INT_MSK (0x01<<12) //default 0, RW
#define PREGBIT_POL_CNG_INT_MSK (0x01<<11) //default 0, RW
#define PREGBIT_PRL_DET_FLT_INT_MSK (0x01<<10) //default 0, RW
#define PREGBIT_MAS_SLA_ERR_INT_MSK (0x01<<9) //default 0, RW
#define PREGBIT_NO_HCD_INT_MSK (0x01<<8) //default 0, RW
#define PREGBIT_NO_LNK_INT_MSK (0x01<<7) //default 0, RW
#define PREGBIT_JABBER_CNG_INT_MSK (0x01<<6) //default 0, RW
#define PREGBIT_NXT_PG_RCVD_INT_MSK (0x01<<5) //default 0, RW
#define PREGBIT_AN_CMPL_INT_MSK (0x01<<4) //default 0, RW
#define PREGBIT_REM_FLT_CNG_INT_MSK (0x01<<3) //default 0, RW


//PHY_EXP_MEM_CTL bit info
#define PREGBIT_GLOBAL_RESET (0x01<<15) //default 0, RW, SC
#define PREGBIT_BROADCAST_EN (0x01<<7) //default 0, RW
#define PREGBIT_ADDRESS_CONTROL (0x03<<0) //default RW


//PHY_INT_CLEAR bit info
#define PREGBIT_SPD_CNG_INT_CLR (0x01<<15) //default 0, RW, SC
#define PREGBIT_LNK_CNG_INT_CLR (0x01<<14) //default 0, RW, SC
#define PREGBIT_DPLX_CNG_INT_CLR (0x01<<13) //default 0, RW, SC
#define PREGBIT_MDIX_CNG_INT_CLR (0x01<<12) //default 0, RW, SC
#define PREGBIT_POL_CNG_INT_CLR (0x01<<11) //default 0, RW, SC
#define PREGBIT_PRL_DET_FLT_INT_CLR (0x01<<10) //default 0, RW, SC
#define PREGBIT_MAS_SLA_ERR_INT_CLR (0x01<<9) //default 0, RW, SC
#define PREGBIT_NO_HCD_INT_CLR (0x01<<8) //default 0, RW, SC
#define PREGBIT_NO_LNK_INT_CLR (0x01<<7) //default 0, RW, SC
#define PREGBIT_JABBER_CNG_INT_CLR (0x01<<6) //default 0, RW, SC
#define PREGBIT_NXT_PG_RCVD_INT_CLR (0x01<<5) //default 0, RW, SC
#define PREGBIT_AN_CMPL_INT_CLR (0x01<<4) //default 0, RW, SC
#define PREGBIT_REM_FLT_CNG_INT_CLR (0x01<<3) //default 0, RW, SC

//PHY_BIST_CNT bit info
#define PREGBIT_BIST_COUNTER (0xffff) //default 0, RO

//PHY_BIST_CFG1 bit info
#define PREGBIT_BIST_CNT_TYPE (0x01<<15) //default  0, RW
#define PREGBIT_BIST_CNT_CLR (0x01<<14) //default 0, RW, SC
#define PREGBIT_TX_BIST_PAK_LEN (0x01<<13) //default 0, RW
#define PREGBIT_TX_BIST_IFG (0x01<<12) //default 0, RW
#define PREGBIT_TX_BIST_EN (0x01<<11) //default 0, RW, SC
#define PREGBIT_TX_BIST_PAK_TYPE (0x01<<10) //default 0, RW
#define PREGBIT_TX_BIST_PAK (0xff) //default 0, RW

//PHY_BIST_CFG2 bit info
#define PREGBIT_RX_BIST_EN (0x01<<15) //default 0, RW
#define PREGBIT_BIST_CNT_SEL (0x01<<14) //default 0, RW
#define PREGBIT_TX_BIST_PAK_CNT (0x07<<11) //default 0, RW
#define PREGBIT_LINK_ACT_SEL (0x01<<0) //default 0, RW


//PHY_EXP_MEM_DATA bit info
#define PREGBIT_MEMORY_DATA (0xffff) //default 0, RW


//PHY_EXP_MEM_ADDR bit info
#define PREGBIT_MEMORY_ADDRESS (0xffff) //default 0, RW


//PHY_PHY_SUP bit info
#define PREGBIT_PHY_ADDRESS (0x1f) //default STRAP[0_0001],

#endif

