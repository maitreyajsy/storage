/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifndef __ETHERNET_PHY_H__
#define __ETHERNET_PHY_H__


#define PHY_AUTO_NEGO_TIMEOUT	(5000)		/* 5 seconds */

#define PHY_SPEED_10		0
#define PHY_SPEED_100		1
#define PHY_SPEED_1000		2

#define PHY_DUPLEX_HALF		0
#define PHY_DUPLEX_FULL		1

#define PHY_SUPPORT_10HD		(1 << 0)	/*10Base Half-Duplex */
#define PHY_SUPPORT_10FD		(1 << 1)	/*10Base Full-Duplex */
#define PHY_SUPPORT_100HD		(1 << 2)	/*100Base Half-Duplex */
#define PHY_SUPPORT_100FD		(1 << 3)	/*100Base Full-Duplex */
#define PHY_SUPPORT_1000HD		(1 << 4)	/*1000Base Half-Duplex */
#define PHY_SUPPORT_1000FD		(1 << 5)	/*1000Base Full-Duplex */

#define PHY_SUPPORT_AUTONEGO	(1 << 10)	/*Auto-Negotiation */


typedef struct
{
	int (*read)(u8 addr, int reg, u16 *val);
	int (*write)(u8 addr, int reg, u16 val);
} mii_bus_t;

typedef struct
{
	int			phy_addr;
	mii_bus_t	*bus;

	int			link;
	int			speed;
	int			duplex;

	u32			supported;

	void		*priv;
} phy_dev_t;

typedef struct
{
	int			(*init)(void);
	phy_dev_t*	(*connect)(mii_bus_t *bus, int addr);
	int			(*start)(phy_dev_t *dev, u32 support);
} phy_driver_t;



int register_phy_driver(phy_driver_t *phy_driver);
phy_driver_t* get_phy_driver(void);


int phy_init(void);
phy_dev_t* phy_connect(mii_bus_t *bus, int addr);
int phy_start(phy_dev_t *dev, u32 support);

#endif
