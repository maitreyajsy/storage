
#if USE_DTVSOC_EMAC
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <timer.h>
#include <gpio.h>
#include <ethernet.h>
#include <arasan_emac.h>

#define PHY_RTL8201F_REV_NUMBER 0xc816
#define PHY_RTL8201E_REV_NUMBER 0xc815

#define PHY_RTL8201F_ETHERNET_ADDR_SEARCH
#ifdef PHY_RTL8201F_ETHERNET_ADDR_SEARCH
unsigned int gPhyAddressSearch = PHY_BASE_ADDRESS;
unsigned int gPhyRevNumber;
#endif

#define	SET_EMAC_REG(addr , val)	*(volatile unsigned int *)(MAC_MMIO_START + addr) = val
#define	GET_EMAC_REG(addr)			*(volatile unsigned int *)(MAC_MMIO_START + addr)

#if 1
#define DEBUG_PRINT(FMT, VAL...)
#else
#define DEBUG_PRINT(FMT, VAL...)        printf("%s:%d: "FMT,__FUNCTION__,__LINE__,##VAL)
#endif
#define INFO_PRINT(FMT, VAL...)        printf("%s:%d: "FMT,__FUNCTION__,__LINE__,##VAL)


#define EMAC_AUTO_NEG	1

#define AUTONEG 1
#define	SPEED 1
#define DUPLEX 1

#define	TX_MAX_LENGTH	2048
#define	TX_BUF_CNT		1

#define	RX_MAX_LENGTH	2048
//#define RX_BUF_CNT		4
#define RX_BUF_CNT		32


#define	TXBUF_TOTAL_SIZE	((sizeof(stEmacTxDesc) + TX_MAX_LENGTH) * TX_BUF_CNT)
#define	RXBUF_TOTAL_SIZE	((sizeof(stEmacRxDesc) + RX_MAX_LENGTH) * RX_BUF_CNT)


static stEmacTxDesc *tx_buf[TX_BUF_CNT];
static stEmacRxDesc *rx_buf[RX_BUF_CNT];

static ulong tx_buf_base;
static ulong rx_buf_base;

static uint32_t rxIdx = 0;
static uint32_t txIdx = 0;

static uint8_t mac_addr[6];		//ethernet mac address

static int phy_read(UINT8 u8PhyRegAddr, UINT32 *pu32Value)
{
	//Dbg_Debug("Enter...\n");

	unsigned int u32Cmd;
	unsigned int u32ValueTemp;

	u32Cmd= MREGBIT_START_MDIO_TRANS | MREGBIT_MDIO_READ_WRITE |u8PhyRegAddr << 5 | gPhyAddressSearch;

	//	Dbg_Debug("u32Cmd 0x%x\n", u32Cmd);

	SET_EMAC_REG(MAC_MDIO_CONTROL, u32Cmd);

	u32ValueTemp= GET_EMAC_REG( MAC_MDIO_CONTROL);
	u32ValueTemp = u32ValueTemp >> 15 & 0x01;

	while(u32ValueTemp!=0)
	{
		u32ValueTemp=GET_EMAC_REG( MAC_MDIO_CONTROL);
		u32ValueTemp = u32ValueTemp >> 15 & 0x01;
	}

	*pu32Value=GET_EMAC_REG(MAC_MDIO_DATA);

	return 0;
}



static int phy_write(UINT8 u8PhyRegAddr, UINT32 pu32Value)
{
	UINT32 u32Cmd;
	UINT32 u32ValueTemp;

	SET_EMAC_REG(MAC_MDIO_DATA, pu32Value);

	u32Cmd= MREGBIT_START_MDIO_TRANS | u8PhyRegAddr << 5 | gPhyAddressSearch;

	SET_EMAC_REG(MAC_MDIO_CONTROL, u32Cmd);

	u32ValueTemp=GET_EMAC_REG(MAC_MDIO_CONTROL);
	u32ValueTemp = u32ValueTemp >> 15 & 0x01;

	while(u32ValueTemp!=0)
	{
		u32ValueTemp=GET_EMAC_REG(MAC_MDIO_CONTROL);
		u32ValueTemp = u32ValueTemp >> 15 & 0x01;
	}

	return 0;
}

#ifdef  PHY_RTL8201F_ETHERNET_ADDR_SEARCH
/*	temporary function
 *	only for B0 board hw workaround
 */
static void search_phyaddr(void)
{
	int i;
	unsigned int u32Value = 0;

	for(i=0;i<4;i++)        // search 4 address 00,01,10,11
	{
		gPhyAddressSearch = i;
		phy_read (PHY_PHYIDR1 , &u32Value);     // read 2nd register
		if(u32Value == 0x001c)
		{
			break;
		}
	}

	// phy version check
	phy_read (PHY_PHYIDR2 , &u32Value);

	// only for PHY RTL8201
	if(u32Value == PHY_RTL8201F_REV_NUMBER)
	{
		u32Value = 0x0310;
		phy_write (PHY_BIST_CNT , u32Value); 	// link down power save off

		u32Value = 7;							// goto page7 region register
		phy_write (PHY_PHY_SUP , u32Value); 	// set page7 region
		u32Value = 0x0001;
		phy_write (PHY_BIST_CNT , u32Value); 	// 24th register setting in page7 region
		u32Value = 0;							// goto page0 region register
		phy_write (PHY_PHY_SUP , u32Value); 	// set page0 region again

		gPhyRevNumber = PHY_RTL8201F_REV_NUMBER;                // for another PHY setting
	}
	else
		gPhyRevNumber = PHY_RTL8201E_REV_NUMBER;                // for another PHY setting

}
#endif


static void phy_reset(void)
{
	gpio_set_top(GPIO_PHY_RESET);		// set to gpio
	gpio_set_direction(GPIO_PHY_RESET, GPIO_DIR_OUTPUT);

	gpio_set_value(GPIO_PHY_RESET, GPIO_LOW);
	mdelay(30);
	gpio_set_value(GPIO_PHY_RESET, GPIO_HIGH);
	mdelay(300);
}


static void emac_reset(void)
{
	phy_reset();

	//disable all the interrupts
	SET_EMAC_REG(MAC_INTERRUPT_ENABLE, 0x0000);
	SET_EMAC_REG(DMA_INTERRUPT_ENABLE, 0x0000);

	//disable transmit and receive units
	SET_EMAC_REG(MAC_RECEIVE_CONTROL, 0x0000);
	SET_EMAC_REG(MAC_TRANSMIT_CONTROL, 0x0000);

	//stop the DMA
	SET_EMAC_REG(DMA_CONTROL, 0x0000);

	//reset PHY
	//phy_write( PHY_BMCR, PREGBIT_RESET);
	//udelay (5000);

	//reset mac, statistic counters
	SET_EMAC_REG(MAC_GLOBAL_CONTROL, 0x0018);
	mdelay(5);

	SET_EMAC_REG(MAC_GLOBAL_CONTROL, 0x0000);

}

static void hw_init(void)
{

	UINT32 u32ValueTemp = 0, u32Value = 0;

	//check the link status from the underlying hardware from its registers
	UINT8 u8LinkSpeed = 0;
	UINT16 u16PktStartThs = 0;

	//PHY init process
	//	Emac_Phy_Read (pstHWData, PHY_PHYIDR2, &pstHWData->u32PhyId);

#ifdef	PHY_RTL8201F_ETHERNET_ADDR_SEARCH

	if(gPhyRevNumber == PHY_RTL8201E_REV_NUMBER)    // only RMII setting at REV RTL8201E
	{
		phy_read(PHY_BIST_CFG1 , &u32Value);
		u32Value |= ((1<<14)  | (1<<10));		// RMII mode : 10 , RMII clock out : 11
		u32Value &= ~(1<<11);
		phy_write(PHY_BIST_CFG1 , u32Value);
	}

	// if phy is RTL8201E, that value not be set.
#else
	phy_read(PHY_BIST_CFG1 , &u32Value);
	u32Value |= ((1<<14)  | (1<<10));		// RMII mode : 10 , RMII clock out : 11
	u32Value &= ~(1<<11);
	phy_write(PHY_BIST_CFG1 , u32Value);
#endif


	//autonegotiate advertisement registers
	phy_read( PHY_BMSR, &u32Value);
	phy_read( PHY_ANAR, &u32ValueTemp);

#if (AUTONEG == 1)
	DEBUG_PRINT ("Autonegotiate mode...\n");

	if (u32Value & PREGBIT_BMSR_100BASE_X_FD)
	{
		u32ValueTemp |= PREGBIT_ANAR_100BASE_TX_FD;
		DEBUG_PRINT("100BASE_TX_FD-advertised\n");
	}

	if (u32Value & PREGBIT_BMSR_100BASE_X_HD)
	{

		u32ValueTemp |= PREGBIT_ANAR_100BASE_TX_HD;
		DEBUG_PRINT("100BASE_TX_HD-advertised\n");
	}

	if (u32Value & PREGBIT_BMSR_10BASE_T_FD)
	{
		u32ValueTemp |= PREGBIT_ANAR_10BASE_T_FD;
		DEBUG_PRINT ("10BASE_TX_FD-advertised\n");
	}


	if (u32Value & PREGBIT_BMSR_10BASE_T_HD)
	{
		u32ValueTemp |= PREGBIT_ANAR_10BASE_T_HD;
		DEBUG_PRINT ("10BASE_TX_HD-advertised\n");
	}
#else
	DEBUG_PRINT ("Force mode...\n");

	u32ValueTemp &= ~PREGBIT_ANAR_100BASE_TX_FD;
	u32ValueTemp &= ~PREGBIT_ANAR_100BASE_TX_HD;
	u32ValueTemp &= ~PREGBIT_ANAR_10BASE_T_FD;
	u32ValueTemp &= ~PREGBIT_ANAR_10BASE_T_HD;


	if (u32Value & PREGBIT_BMSR_100BASE_X_FD)
	{
		if (1 == SPEED && 1 == DUPLEX)
		{
			u32ValueTemp |= PREGBIT_ANAR_100BASE_TX_FD;
			DEBUG_PRINT("100BASE_TX_FD-advertised\n");
		}
	}

	if (u32Value & PREGBIT_BMSR_100BASE_X_HD)
	{
		if (1 == SPEED && 0 == DUPLEX)
		{
			u32ValueTemp |= PREGBIT_ANAR_100BASE_TX_HD;
			DEBUG_PRINT("100BASE_TX_HD-advertised\n");
		}
	}


	if (u32Value & PREGBIT_BMSR_10BASE_T_FD)
	{
		if (0 == SPEED && 1 == DUPLEX)
		{
			u32ValueTemp |= PREGBIT_ANAR_10BASE_T_FD;
			DEBUG_PRINT("10BASE_TX_FD-advertised\n");
		}
	}


	if (u32Value & PREGBIT_BMSR_10BASE_T_HD)
	{
		if (0 == SPEED && 0 == DUPLEX)
		{
			u32ValueTemp |= PREGBIT_ANAR_10BASE_T_HD;
			DEBUG_PRINT("10BASE_TX_HD-advertised\n");
		}
	}
#endif


	phy_write(PHY_ANAR, u32ValueTemp);

	phy_read( PHY_ANAR, &u32ValueTemp);

	DEBUG_PRINT("PHY_ANAR: 0x%x\n", u32ValueTemp);


	//enable autonegotiate
	phy_read( PHY_BMCR, &u32ValueTemp);
	u32ValueTemp |= (PREGBIT_BMCR_AN_EN);
	phy_write( PHY_BMCR, u32ValueTemp);

	//restart auto negotiate
	phy_read( PHY_BMCR, &u32ValueTemp);
	u32ValueTemp |= PREGBIT_RESTART_AN;
	phy_write( PHY_BMCR, u32ValueTemp);

	//enable phy interrupts
	phy_write( 30, 0xfff8);

	phy_read( PHY_BMSR, &u32Value);


	while (!(u32Value & PREGBIT_AUTO_NEGOTIATION_COMPLETE))
	{
		mdelay(1);
		phy_read( PHY_BMSR, &u32Value);
	}

	phy_read( PHY_BMCR, &u32Value);

	u32ValueTemp = 0;

	if (u32Value & (1<<8))
	{
		u32ValueTemp |= MREGBIT_DUPLEX_MODE;
	}

	//	phy_read( 0x0, &u32Value);

	//	u32Value = (u32Value & (0x3 << 2)) >>2;

	if(u32Value & (1<<13) )  u32Value = 0x2;
	else u32Value = 0x1;

	if (u32Value == 0x01)
	{
		u8LinkSpeed = 0x00;
		u16PktStartThs = 64;
	}
	else if (u32Value == 0x02)
	{
		u8LinkSpeed = 0x01;
		u16PktStartThs = 128;
	}
	else if (u32Value == 0x03)
	{
		u8LinkSpeed = 0x02;
		u16PktStartThs = 1024;
	}
	else if (u32Value == 0x04)
	{
		u8LinkSpeed = 0x03;
		u16PktStartThs = 64;
	}

	u32ValueTemp |= u8LinkSpeed;

	DEBUG_PRINT ("MAC_GLOBAL_CONTROL = 0x%x\n", u32ValueTemp);
	SET_EMAC_REG( MAC_GLOBAL_CONTROL, u32ValueTemp);



	//MAC Init
	//disable transmit and receive units
	SET_EMAC_REG(MAC_RECEIVE_CONTROL, 0x0000);
	SET_EMAC_REG(MAC_TRANSMIT_CONTROL, 0x0000);

	//enable mac address filtering
	SET_EMAC_REG(MAC_ADDRESS_CONTROL, 0x0001);	//enable address 1 filtering


	//zero initiaize the multicast hash table
	SET_EMAC_REG(MAC_MULTICAST_HASH_TABLE1, 0x0000);
	SET_EMAC_REG(MAC_MULTICAST_HASH_TABLE2, 0x0000);
	SET_EMAC_REG(MAC_MULTICAST_HASH_TABLE3, 0x0000);
	SET_EMAC_REG(MAC_MULTICAST_HASH_TABLE4, 0x0000);

	SET_EMAC_REG(MAC_TRANSMIT_FIFO_ALMOST_FULL, 0x1f8);
	SET_EMAC_REG(MAC_TRANSMIT_FIFO_ALMOST_FULL, 0x1f8);
	SET_EMAC_REG(MAC_TRANSMIT_FIFO_ALMOST_FULL, 0x1f8);

	u16PktStartThs = 0x5ee;

	SET_EMAC_REG(MAC_TRANSMIT_PACKET_START_THRESHOLD,u16PktStartThs);
	SET_EMAC_REG(MAC_TRANSMIT_PACKET_START_THRESHOLD,u16PktStartThs);
	SET_EMAC_REG(MAC_TRANSMIT_PACKET_START_THRESHOLD,u16PktStartThs);

	SET_EMAC_REG(MAC_RECEIVE_PACKET_START_THRESHOLD, 0xc);
	SET_EMAC_REG(MAC_RECEIVE_PACKET_START_THRESHOLD, 0xc);
	SET_EMAC_REG(MAC_RECEIVE_PACKET_START_THRESHOLD, 0xc);


	//reset dma
	SET_EMAC_REG(DMA_CONTROL, 0x0000);

	SET_EMAC_REG(DMA_CONFIGURATION, 0x01);

	mdelay(10);

	SET_EMAC_REG(DMA_CONFIGURATION, 0x00);

	mdelay(10);

	//  u32ValueTemp = (0x1 << 17) | (0x01 << 3) ; //0x20008 Four burst mode	SC
	u32ValueTemp = (0x1 << 17) | (0x01 << 5) ; //0x20008 16 burst mode
	SET_EMAC_REG(DMA_CONFIGURATION, u32ValueTemp);


	u32ValueTemp = GET_EMAC_REG(MAC_GLOBAL_CONTROL);

	printf("Ethernet interface Up %d Mbps %s\n",  ((u32ValueTemp&MREGBIT_SPEED)==1 ? 100:10) ,
			(((u32ValueTemp&MREGBIT_DUPLEX_MODE)>>2) == 1 ? "Full Duplex" : "Half Duplex"));
}


static void emac_configure_tx(void)
{
	UINT32 u32ValueTemp=0;

	DEBUG_PRINT("Enter...\n");

	//set the transmit base address
	SET_EMAC_REG(DMA_TRANSMIT_BASE_ADDRESS , tx_buf_base);
	mdelay(10);

	//Tx Inter Packet Gap value and enable the transmit
	u32ValueTemp=GET_EMAC_REG(MAC_TRANSMIT_CONTROL);
	u32ValueTemp &= (~MREGBIT_IFG_LEN);
	u32ValueTemp |= MREGBIT_TRANSMIT_ENABLE;
	u32ValueTemp |= MREGBIT_TRANSMIT_AUTO_RETRY;
	SET_EMAC_REG(MAC_TRANSMIT_CONTROL, u32ValueTemp);

	SET_EMAC_REG(DMA_TRANSMIT_AUTO_POLL_COUNTER, 0x00);


	//start tx dma
	u32ValueTemp = GET_EMAC_REG( DMA_CONTROL);
	u32ValueTemp |= MREGBIT_START_STOP_TRANSMIT_DMA;
	SET_EMAC_REG( DMA_CONTROL, u32ValueTemp);

	return;
}

static void emac_configure_rx(void)
{
	UINT32 u32ValueTemp=0;

	DEBUG_PRINT("Enter...\n");

	//set the receive base address
	SET_EMAC_REG(DMA_RECEIVE_BASE_ADDRESS , rx_buf_base);

	mdelay(10);

	//TBD -set the Tx Interrupt Delay

	//enable the receive
	u32ValueTemp=GET_EMAC_REG(MAC_RECEIVE_CONTROL);
	u32ValueTemp |= MREGBIT_RECEIVE_ENABLE;
	u32ValueTemp |= MREGBIT_STORE_FORWARD;
	SET_EMAC_REG(MAC_RECEIVE_CONTROL, u32ValueTemp);
	SET_EMAC_REG(MAC_RECEIVE_CONTROL, u32ValueTemp);


	//start rx dma
	u32ValueTemp = GET_EMAC_REG(DMA_CONTROL);
	u32ValueTemp |= MREGBIT_START_STOP_RECEIVE_DMA;
	//u32ValueTemp = 0x02;
	SET_EMAC_REG(DMA_CONTROL, u32ValueTemp);

	return;


}

#if (CONFIG_ARCH == ARCH_LG1154 || CONFIG_ARCH == ARCH_LG1311)
#define check_phy_reg(addr, value)	\
	do {							\
		u32 _v_;					\
		do {						\
			phy_read(addr, &_v_);	\
		} while(_v_ != value);		\
	} while(0)

static void change_phy_tx_timing(u32 value)
{
	phy_write (PHY_PHY_SUP , 0x7);	// select page 7
	check_phy_reg(0x10, 0xFFA);
	phy_write(0x10, value);			// change tx timing
	check_phy_reg(0x10, value);
	phy_write (PHY_PHY_SUP , 0x1);	// select page 0
}
#endif

static int emac_init (const uint8_t* mac)
{
	int			i;

	printf("Initializing ethernet device...\n");

	/* verify chip id */
	memcpy(mac_addr, mac, 6);

#ifdef  PHY_RTL8201F_ETHERNET_ADDR_SEARCH
	search_phyaddr();
#endif

	emac_reset();

#if (CONFIG_ARCH == ARCH_LG1154)
	if(get_chip_rev() < CHIP_LG1154_B0)
		change_phy_tx_timing(0x4FA);
	else
		change_phy_tx_timing(0x77A);
#elif (CONFIG_ARCH == ARCH_LG1311)
	change_phy_tx_timing(0x77A);
#endif

	/* set the ethernet address */
	SET_EMAC_REG (MAC_ADDRESS_CONTROL , 0x01);	// only MAC address1 enable
	SET_EMAC_REG (MAC_ADDRESS1_HIGH,mac_addr[0] | (mac_addr[1] << 8));
	SET_EMAC_REG (MAC_ADDRESS1_MED,	mac_addr[2] | (mac_addr[3] << 8));
	SET_EMAC_REG (MAC_ADDRESS1_LOW,	mac_addr[4] | (mac_addr[5] << 8));

	/* system initial */
	/* auto-neogotiation */
	hw_init();

	/* allocate buffer memory */
	if(tx_buf_base) dma_free((void*)tx_buf_base);
	tx_buf_base = (ulong)dma_malloc(TXBUF_TOTAL_SIZE);

	if(rx_buf_base) dma_free((void*)rx_buf_base);
	rx_buf_base = (ulong)dma_malloc(RXBUF_TOTAL_SIZE);


	/* DMA setting*/
	for(i=0 ; i < RX_BUF_CNT ; i++)
	{
		int next = (i == (RX_BUF_CNT - 1)) ? 0 : (i+1);

		rx_buf[i] = (stEmacRxDesc *)(rx_buf_base + i*sizeof(stEmacRxDesc));
		memset((stEmacRxDesc *)rx_buf[i] , 0, sizeof(stEmacRxDesc));

		rx_buf[i]->BufferAddr1 = rx_buf_base + RX_BUF_CNT*sizeof(stEmacRxDesc) + i*RX_MAX_LENGTH;
		rx_buf[i]->OWN = 1;

		// BufferAddr2 means next descriptor pointer in chaining mode
		rx_buf[i]->BufferAddr2 = rx_buf_base + next*sizeof(stEmacRxDesc);

		rx_buf[i]->SecondAddressChained = 1;
		rx_buf[i]->BufferSize1 = RX_MAX_LENGTH;
	}
	rx_buf[RX_BUF_CNT-1]->EndRing = 1;

	for(i=0 ; i<TX_BUF_CNT ; i++)
	{
		tx_buf[i] = (stEmacTxDesc *)(tx_buf_base + i*sizeof(stEmacTxDesc));
		memset(tx_buf[i] , 0, sizeof(stEmacTxDesc));

		tx_buf[i]->BufferAddr1 = tx_buf_base + TX_BUF_CNT*sizeof(stEmacTxDesc) + i*TX_MAX_LENGTH;
		tx_buf[i]->OWN=1;

	}
	tx_buf[TX_BUF_CNT-1]->EndRing = 1;


	/* Tx and Rx configuration */
	emac_configure_tx();
	emac_configure_rx();

	SET_EMAC_REG(DMA_INTERRUPT_ENABLE , 0xD5);

	return 0;
}

/* Get a data block via Ethernet */
static int emac_rx (void* packet, size_t len)
{
	int rxlen = 0;
	u32 status;

	status = GET_EMAC_REG(DMA_STATUS_IRQ);

	if((status&MREGBIT_RECEIVE_TRANSFER_DONE_IRQ))	// == 0)
	{
		//	DEBUG_PRINT("no packets\n");
//		return -1;
		SET_EMAC_REG(DMA_STATUS_IRQ , MREGBIT_RECEIVE_TRANSFER_DONE_IRQ);
	}

#if 1
	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
	{
		SET_EMAC_REG( DMA_STATUS_IRQ , MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ);
		//DEBUG_PRINT("buffer overflow\n");
		WARN("#### buffer overflow ####\n");
//		return -1;
	}
#endif

//	SET_EMAC_REG(DMA_STATUS_IRQ , MREGBIT_RECEIVE_TRANSFER_DONE_IRQ);


	DEBUG_PRINT("Entered\n");

	if(rx_buf[rxIdx]->OWN == 0)
	{
		rxlen = rx_buf[rxIdx]->FramePacketLength;

		rxlen -= 4;

//		printf("rx len=%d\n", rxlen);

		if(rxlen < 0)		// packet length error
		{
			WARN("packet error\n");
			rxlen = -1;
		}
		else
		{
			if(rxlen > len)
			{
				WARN("RX LEN OVERFLOW !!!. rxlen=%d\n", rxlen);
				rxlen = len;
			}

			memcpy(packet, (const void*)(rx_buf[rxIdx]->BufferAddr1), rxlen);
		}

		rx_buf[rxIdx]->OWN = 1;
		rxIdx = (rxIdx + 1) >= RX_BUF_CNT ? 0 : rxIdx + 1;

	}

	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
	{
	//DEBUG_PRINT("total length %d \n",trxlen);
		SET_EMAC_REG(DMA_RECEIVE_POLL_DEMAND, 0xFF);
	}

	return rxlen;
}

/* Send a data block via Ethernet. */
static int emac_tx(const void *packet, size_t length)
{
	int i;

	DEBUG_PRINT("entered. length : %d\n", length);

	//DEBUG_PRINT("tx_buf[txIdx] : %p, txIdx : %d , addr : %x \n", tx_buf[txIdx] , txIdx , tx_buf[txIdx]->BufferAddr1);

	if(length <= 0)
	{
		DEBUG_PRINT("bad packet size: %d\n", length);
		goto out;
	}

	if( (GET_EMAC_REG(DMA_STATUS_IRQ)&MREGBIT_TRANSMIT_DES_UNAVAILABLE_IRQ) != 0 )
	{
		SET_EMAC_REG(DMA_STATUS_IRQ,MREGBIT_TRANSMIT_DES_UNAVAILABLE_IRQ);
		tx_buf[txIdx]->OWN = 1;

	}

	for(i=0 ; (GET_EMAC_REG(DMA_STATUS_IRQ)&MREGBIT_TRANSMIT_DMA_STATE) != 0x50000 ; i++ )
	{
		if(i > 1000000)
		{
			printf("tx DMA not ready %x\n", GET_EMAC_REG(DMA_STATUS_IRQ)&MREGBIT_TRANSMIT_DMA_STATE );
			goto out;
		}
	}


	if(length < TX_MAX_LENGTH)
	{
		memcpy((UINT8 *)(tx_buf[txIdx]->BufferAddr1) , (UINT8 *)packet , length);
		tx_buf[txIdx]->BufferSize1 = length;
		tx_buf[txIdx]->FirstSegment = 1;
		tx_buf[txIdx]->LastSegment = 1;
		tx_buf[txIdx]->InterruptOnCompletion=1;

		tx_buf[txIdx]->OWN = 1;

		SET_EMAC_REG(DMA_TRANSMIT_POLL_DEMAND, 0xFF);
	}
	else
	{
		printf("TX packet size overflow\n");
	}



out:

	return 0;
}


static void emac_start(void)
{
	// clean previous data
	u32 status = GET_EMAC_REG(DMA_STATUS_IRQ);

	if((status&MREGBIT_RECEIVE_TRANSFER_DONE_IRQ))
		SET_EMAC_REG(DMA_STATUS_IRQ , MREGBIT_RECEIVE_TRANSFER_DONE_IRQ);

	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
		SET_EMAC_REG( DMA_STATUS_IRQ , MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ);

	while(1)
	{
		if(rx_buf[rxIdx]->OWN == 0)
		{
			rx_buf[rxIdx]->OWN = 1;
			rxIdx = (rxIdx + 1) >= RX_BUF_CNT ? 0 : rxIdx + 1;
		}
		else
		{
			break;
		}
	}

	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
		SET_EMAC_REG(DMA_RECEIVE_POLL_DEMAND, 0xFF);
}


static uint8_t*	emac_getaddr(void)
{
	return mac_addr;
}


static eth_driver_t emac_driver =
{
	.init		= emac_init,
	.transmit	= emac_tx,
	.receive	= emac_rx,
	.start		= emac_start,
	.getaddr	= emac_getaddr,
};

eth_driver_t* get_eth_driver(void)
{
	return &emac_driver;
}
#endif
