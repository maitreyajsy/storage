/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if USE_RTL8211
#include <stdio.h>
#include <string.h>
#include <gpio.h>
#include <util.h>
#include <timer.h>

#include "mii.h"
#include "phy.h"

#if 0
#define debug(fmt, args...)		printf(fmt, ##args)
#else
#define debug(fmt, args...)		do{}while(0)
#endif


#define RTL8211_PHY_ID_OUI_MSB		0x001C
#define RTL8211_PHY_ID_OUI_LSB		0x0032
#define RTL8211_PHY_ID_OUI			((RTL8211_PHY_ID_OUI_MSB << 6) | RTL8211_PHY_ID_OUI_LSB)

#define RTL8211_PHYSR	0x11		/* PHY Specific Status Register */

#define RTL8211_PSR		0x1F		/* Register 31. Page Select Register */



typedef struct
{
	phy_dev_t	phy_dev;
} rtl8211_dev_t;

static rtl8211_dev_t _rtl8211;
static rtl8211_dev_t *rtl8211 = &_rtl8211;

static int rtl8211_init(void)
{
	debug("rtl8211_init\n");

	gpio_set_top(GPIO_GEM_PHY_RESET);		// set to gpio
	gpio_set_direction(GPIO_GEM_PHY_RESET, GPIO_DIR_OUTPUT);

	gpio_set_value(GPIO_GEM_PHY_RESET, GPIO_LOW);
	mdelay(20);	/* at least 10ms */
	gpio_set_value(GPIO_GEM_PHY_RESET, GPIO_HIGH);
	mdelay(50);	/* wait for a further 30ms */

	memset(rtl8211, 0, sizeof(rtl8211_dev_t));

	return 0;
}

static int rtl8211_phy_read(phy_dev_t *dev, int reg, u16 *val)
{
	return dev->bus->read(dev->phy_addr, reg, val);
}

static int rtl8211_phy_write(phy_dev_t *dev, int reg, u16 val)
{
	return dev->bus->write(dev->phy_addr, reg, val);
}

static phy_dev_t* rtl8211_connect(mii_bus_t *bus, int addr)
{
	u16 phy_id[2];
	u32 oui, model, rev;
	u16 status;
	phy_dev_t *dev = &rtl8211->phy_dev;
	debug("rtl8211_connect\n");

	dev->bus = bus;
	if(addr == -1) {
		int i;
		u16 val;
		for(i=1; i<32; i++) {
			dev->phy_addr = i;
			rtl8211_phy_read(dev, MII_PHYID_H, &val);
			if(val == RTL8211_PHY_ID_OUI_MSB) break;
		}
		if(i == 32) {
			printf("Can't find phy addr\n");
			return NULL;
		}
	} else {
		dev->phy_addr = addr;
	}
	debug("PHY ADDR : %d\n", dev->phy_addr);

	rtl8211_phy_read(dev, MII_PHYID_H, &phy_id[0]);
	rtl8211_phy_read(dev, MII_PHYID_L, &phy_id[1]);
	oui = ((u32)phy_id[0] << MII_PH_OUI_H_C_SHIFT |
			((phy_id[1]&MII_PL_OUI_L_MASK) >> MII_PL_OUI_L_SHIFT));
	model = (phy_id[1]&MII_PL_MODEL_MASK) >> MII_PL_MODEL_SHIFT;
	rev = (phy_id[1]&MII_PL_REV_MASK);
	debug("OUI:0x%08x, MODEL:%d, REV:%d\n", oui, model, rev);

	if(oui != RTL8211_PHY_ID_OUI) {
		printf("Not matached OUI !!!\n");
	}

	/* Get supported features */
	dev->supported = 0;
	rtl8211_phy_read(dev, MII_STATUS, &status);
	if(status & MII_STATUS_ANA)		dev->supported |= PHY_SUPPORT_AUTONEGO;
	if(status & MII_STATUS_100XFD)	dev->supported |= PHY_SUPPORT_100FD;
	if(status & MII_STATUS_100XHD)	dev->supported |= PHY_SUPPORT_100HD;
	if(status & MII_STATUS_10FD)	dev->supported |= PHY_SUPPORT_10FD;
	if(status & MII_STATUS_10HD)	dev->supported |= PHY_SUPPORT_10HD;
	if(status & MII_STATUS_EXT_STAT) {
		rtl8211_phy_read(dev, MII_EXT_STATUS, &status);
		if(status & MII_ESTAT_1000TFD)	dev->supported |= PHY_SUPPORT_1000FD;
		if(status & MII_ESTAT_1000THD)	dev->supported |= PHY_SUPPORT_1000HD;
	}

	dev->priv = rtl8211;

	return dev;
}

static int rtl8211_start(phy_dev_t *dev, u32 support)
{
	u16 status, ana;
	u16 val;
	timeout_id_t tid;

	//autonegotiate advertisement registers
	rtl8211_phy_read(dev, MII_ANA, &ana);

	if(!(support&PHY_SUPPORT_AUTONEGO)) {
		printf("Only support auto-negotiation\n");
		support |= PHY_SUPPORT_AUTONEGO;
	}

	debug("Auto-Negotiation Advertisement : 0x%x\n", ana);
	support &= dev->supported;
	ana &= ~(MII_ANA_TAF_MASK);

	if(support & PHY_SUPPORT_100FD) {
		debug("100BASE_TX_FD-advertised\n");
		ana |= (MII_TAF_100TXFD << MII_ANA_TAF_SHIFT);
	}

	if(support & PHY_SUPPORT_100HD) {
		debug("100BASE_TX_HD-advertised\n");
		ana |= (MII_TAF_100TXHD << MII_ANA_TAF_SHIFT);
	}

	if(support & PHY_SUPPORT_10FD) {
		debug ("10BASE_TX_FD-advertised\n");
		ana |= (MII_TAF_10TFD << MII_ANA_TAF_SHIFT);
	}

	if(support & PHY_SUPPORT_10HD) {
		debug ("10BASE_TX_HD-advertised\n");
		ana |= (MII_TAF_10THD << MII_ANA_TAF_SHIFT);
	}
	rtl8211_phy_write(dev, MII_ANA, ana);

	if(dev->supported & (PHY_SUPPORT_1000FD | PHY_SUPPORT_1000HD)) {
		rtl8211_phy_read(dev, MII_MS_CTRL, &val);
		val &= ~(MII_MSC_1000T_FD | MII_MSC_1000T_HD);

		if(support & PHY_SUPPORT_1000FD) {
			debug("1000BASE_TX_FD-advertised\n");
			val |= MII_MSC_1000T_FD;
		}

		if(support & PHY_SUPPORT_1000HD) {
			debug("1000BASE_TX_HD-advertised\n");
			val |= MII_MSC_1000T_HD;
		}
		rtl8211_phy_write(dev, MII_MS_CTRL, val);
	}

	debug("Starting auto-negotiation...\n");

	//enable & restart  autonegotiate
	rtl8211_phy_read(dev, MII_CTRL, &val);
	val |= (MII_CTRL_ANE | MII_CTRL_RAN);
	rtl8211_phy_write(dev, MII_CTRL, val);

	/* Wait for link to be up */
#if 0
	rtl8211_phy_read(dev, MII_STATUS, &status);
	if(status&MII_STATUS_LS) {
		printf("Link is up !!!\n");
	}
	printf("STATUS : 0x%04x\n", status);
#endif

	set_timeout(&tid, PHY_AUTO_NEGO_TIMEOUT);
	while(1) {
		rtl8211_phy_read(dev, MII_STATUS, &status);
		if(status&MII_STATUS_ANC) break;

		if(is_timeout(&tid)) {
			printf("auto-negotiation timeout...\n");
			return -1;
		}
		if(get_ctrl_c()) return -1;
	}

	dev->link = 1;
	dev->speed = PHY_SPEED_100;
	if(dev->supported & (PHY_SUPPORT_1000FD | PHY_SUPPORT_1000HD)) {
		rtl8211_phy_read(dev, MII_MS_STATUS, &val);
		if(val & (MII_MSS_LP1000T_FD|MII_MSS_LP1000T_HD)) {
			dev->speed = PHY_SPEED_1000;
			if(val&MII_MSS_LP1000T_FD) dev->duplex = PHY_DUPLEX_FULL;
			else dev->duplex = PHY_DUPLEX_HALF;
		}
	}

	if(dev->speed != PHY_SPEED_1000) {
		rtl8211_phy_read(dev, MII_ANLPA, &val);
		ana &= val;
		debug(" Auto-Neg Link Partner Ability : 0x%x, 0x%x\n", val, ana);

		val = (ana >> MII_ANA_TAF_SHIFT);

		if(val & (MII_TAF_100TXFD | MII_TAF_100TXHD)) dev->speed = PHY_SPEED_100;
		else dev->speed = PHY_SPEED_10;

		if(val & (MII_TAF_100TXFD | MII_TAF_10TFD)) dev->duplex = PHY_DUPLEX_FULL;
		else dev->duplex = PHY_DUPLEX_HALF;
	}

	debug("Link up %dMbps %s-Duplex\n",
		dev->speed == PHY_SPEED_1000 ? 1000 :
		dev->speed == PHY_SPEED_100 ? 100 : 10,
		dev->duplex == PHY_DUPLEX_FULL ? "Full" : "Half");

	debug("RTL8211 Specific Register\n");
	rtl8211_phy_read(dev, RTL8211_PHYSR, &val);
	debug("SPEED : %dMbps\n", ((val >> 14) & 0x03) == 0x2 ? 1000 :
								((val >> 14) & 0x03) == 0x1 ? 100 :
									((val >> 14) & 0x03) == 0x0 ? 10 : 0);
	debug("Duplex : %s Duplex\n", (val&(0x1<<13)) ? "Full" : "Half");
	debug("Link : %s\n", (val&(0x1<<10)) ? "OK" : "Not OK");
	debug("MID %s\n", (val&(0x1<<6)) ? "Crossover" : "");

	return 0;
}

static phy_driver_t rtl8211_driver =
{
	.init		= rtl8211_init,
	.connect	= rtl8211_connect,
	.start		= rtl8211_start,
};

phy_driver_t* get_phy_driver(void)
{
	return &rtl8211_driver;
}
#endif
