/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if USE_LG115X_GEM
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <timer.h>
#include <gpio.h>
#include <ethernet.h>

#include "phy.h"
#include "gem-lg115x.h"

#if 0
#define debug(fmt, args...)		printf(fmt, ##args)
#else
#define debug(fmt, args...)		do{}while(0)
#endif

#if 1
#define error(fmt, args...)		printf(fmt, ##args)
#else
#define error(fmt, args...)		do{}while(0)
#endif


#define gem_reg_write(reg, val)		REG_WRITE(GEM_BASE + reg, val)
#define gem_reg_read(reg)			REG_READ(GEM_BASE + reg)


#define GEM_MAX_PKT_SIZE	1536
#define GEM_RX_BUF_CNT		(64 * 2)
#define GEM_TX_BUF_CNT		(4 * 2)

typedef struct
{
	u32	addr;
	u32	status;
} gem_buf_desc_t;

typedef struct
{
	int cnt;
	int idx;
	uint8_t	*base;
	gem_buf_desc_t	*buf_desc;
} gem_buf_t;

typedef struct
{
	uint8_t		mac[6];
	gem_buf_t	*tx_buf;
	gem_buf_t	*rx_buf;

	int			speed;
	int			duplex;

	phy_dev_t	*phy_dev;
} gem_t;


static gem_t _gem;
static gem_t *gem = &_gem;


static int gem_mdio_wait(void)
{
	int timeout = 1000000;
	u32 value;

	/* Wait for completion */
	while(--timeout) {
		value = gem_reg_read(GEM_NWSR_OFFSET);
		if(value&GEM_NWSR_MDIOIDLE_MASK) break;
	}

	if(!timeout) {
		printf("mdio wait timeout\n");
		return -1;
	}
	return 0;
}

static int gem_phy_read(u8 addr, int reg, u16 *val)
{
	u32 value;

	value = GEM_PHYMNTNC_OP_MASK | GEM_PHYMNTNC_OP_R_MASK |
			(addr << GEM_PHYMNTNC_PHYAD_SHIFT_MASK) |
			(reg << GEM_PHYMNTNC_PHREG_SHIFT_MASK);

	gem_reg_write(GEM_PHYMNTNC_OFFSET, value);

	if(gem_mdio_wait() < 0) return -1;

	value = gem_reg_read(GEM_PHYMNTNC_OFFSET);
	*val = (value&0xffff);
	return 0;
}

static int gem_phy_write(u8 addr, int reg, u16 val)
{
	u32 value;

	value = GEM_PHYMNTNC_OP_MASK | GEM_PHYMNTNC_OP_W_MASK |
			(addr << GEM_PHYMNTNC_PHYAD_SHIFT_MASK) |
			(reg << GEM_PHYMNTNC_PHREG_SHIFT_MASK) |
			val;

	gem_reg_write(GEM_PHYMNTNC_OFFSET, value);

	if(gem_mdio_wait() < 0) return -1;

	return 0;
}

static mii_bus_t gem_mii_bus =
{
	.read	= gem_phy_read,
	.write	= gem_phy_write,
};

static void gem_reset_hw(void)
{
	u32 v;

	debug("gem_reset_hw\n");

	v = gem_reg_read(GEM_MODID_OFFSET);
	debug("GEM ID : 0x%08x\n", v);

	/* Diable transmit and receive circuits */
	gem_reg_write(GEM_NWCTRL_OFFSET, 0);
	gem_reg_write(GEM_NWCTRL_OFFSET, GEM_NWCTRL_STATCLR_MASK);

	/* Clear TX and RX status */
	gem_reg_write(GEM_TXSR_OFFSET, ~0U);
	gem_reg_write(GEM_RXSR_OFFSET, ~0U);

	/* Disable all interrupts */
	gem_reg_write(GEM_IDR_OFFSET, ~0U);

	/* Diable multicast mode */
	gem_reg_write(GEM_HASHL_OFFSET, 0x0);
	gem_reg_write(GEM_HASHH_OFFSET, 0x0);
}

static void gem_setup_mac(const uint8_t *mac)
{
	u32 val[2];

	memcpy(gem->mac, mac, 6);
	val[0] = mac[0] | (mac[1] << 8) | (mac[2] << 16) | (mac[3] << 24);
	val[1] = mac[4] | (mac[5] << 8);

	debug("gem_setup_mac. 0x%08x, 0x%04x\n", val[0], val[1]);

	gem_reg_write(GEM_LADDR1L_OFFSET, val[0]);
	gem_reg_write(GEM_LADDR1H_OFFSET, val[1]);
}

static void gem_init_txbuf(gem_buf_t *buf)
{
	int i;

	buf->idx = 0;
	for(i=0; i<buf->cnt; i++) {
		buf->buf_desc[i].addr = (ulong)(buf->base + i*GEM_MAX_PKT_SIZE);
		buf->buf_desc[i].status = GEM_TXBUF_USED_MASK;
	}
	buf->buf_desc[i-1].status |= GEM_TXBUF_WRAP_MASK;
}

static void gem_init_rxbuf(gem_buf_t *buf)
{
	int i;

	for(i=0; i<buf->cnt; i++) {
		buf->buf_desc[i].addr = (ulong)(buf->base + i*GEM_MAX_PKT_SIZE);
		buf->buf_desc[i].status = 0;
	}
	buf->buf_desc[i-1].addr |= GEM_RXBUF_WRAP_MASK;
}

static gem_buf_t* gem_alloc_buf(int cnt)
{
	gem_buf_t *buf;

	buf = (gem_buf_t*)malloc(sizeof(gem_buf_t));
	buf->cnt		= cnt;
	buf->idx		= 0;
	buf->base		= (uint8_t*)dma_malloc(GEM_MAX_PKT_SIZE * cnt);
	buf->buf_desc	= (gem_buf_desc_t*)dma_malloc(sizeof(gem_buf_desc_t) * cnt);

	return buf;
}

static void gem_free_buf(gem_buf_t *buf)
{
	if(buf->base) dma_free(buf->base);
	if(buf->buf_desc) dma_free(buf->buf_desc);
	free(buf);
}

static void gem_init_hw(void)
{
	u32 val;

	/* Network Configuratoin */
	gem->speed = PHY_SPEED_100;
	gem->duplex = PHY_DUPLEX_FULL;

	val = gem_reg_read(GEM_NWCFG_OFFSET);
	/* BUSWIDTH & CLKDIV : use default value */
	val &= (GEM_NWCFG_BUSWIDTH_MASK | GEM_NWCFG_MDCCLKDIV_MASK);
	val |= (0
			| GEM_NWCFG_100_MASK
			| GEM_NWCFG_FDEN_MASK
			| GEM_NWCFG_FCSREM_MASK
			| GEM_NWCFG_PAUSEEN_MASK
			| GEM_NWCFG_PAUSECOPYDI_MASK
			| GEM_NWCFG_RXCHKSUMEN_MASK
			//| GEM_NWCFG_BCASTDI_MASK
			);
	debug("NWCFG : 0x%08x\n", val);
	gem_reg_write(GEM_NWCFG_OFFSET, val);

	/* Init buffers */
	gem_init_rxbuf(gem->rx_buf);
	gem_init_txbuf(gem->tx_buf);

	debug("Rx DMA Buffer Descriptor : %p\n", gem->rx_buf->buf_desc);
	debug("Tx DMA Buffer Descriptor : %p\n", gem->tx_buf->buf_desc);

	gem_reg_write(GEM_RXQBASE_OFFSET, (ulong)gem->rx_buf->buf_desc);
	gem_reg_write(GEM_TXQBASE_OFFSET, (ulong)gem->tx_buf->buf_desc);

	/* DMA Configuration */
	val = (0
			| GEM_DMACR_STALLRX_MASK
			| GEM_DMACR_PKTDSCRD_MASK
			| GEM_DMACR_BLENGTH_INCR16
			| GEM_DMACR_RXSIZE_MASK
			| GEM_DMACR_TXSIZE_MASK
			| GEM_DMACR_TCPCKSUM_MASK
			| ((GEM_MAX_PKT_SIZE / 64) << GEM_DMACR_RXBUF_SHIFT)
			);
	gem_reg_write(GEM_DMACR_OFFSET, val);

	/* Enable MDIO port */
	val = GEM_NWCTRL_MDEN_MASK | GEM_NWCTRL_RXEN_MASK | GEM_NWCTRL_TXEN_MASK;
	gem_reg_write(GEM_NWCTRL_OFFSET, val);
	dmb();
}

static void gem_update_link(void)
{
	u32 val;

	if(gem->speed != gem->phy_dev->speed ||
		gem->duplex != gem->phy_dev->duplex) {
		val = gem_reg_read(GEM_NWCFG_OFFSET);

		if(gem->phy_dev->speed == PHY_SPEED_1000)
			val |= GEM_NWCFG_1000_MASK;
		else
			val &= ~GEM_NWCFG_1000_MASK;

		if(gem->phy_dev->speed == PHY_SPEED_100)
			val |= GEM_NWCFG_100_MASK;
		else
			val &= ~GEM_NWCFG_100_MASK;

		if(gem->phy_dev->duplex == PHY_DUPLEX_FULL)
			val |= GEM_NWCFG_FDEN_MASK;
		else
			val &= ~GEM_NWCFG_FDEN_MASK;

		gem_reg_write(GEM_NWCFG_OFFSET, val);

		gem->speed = gem->phy_dev->speed;
		gem->duplex = gem->phy_dev->duplex;
	}

	printf("Ethernet interface Up %d Mbps %s\n",
			(gem->speed == PHY_SPEED_1000) ? 1000:
			(gem->speed == PHY_SPEED_100) ? 100 : 10,
			(gem->duplex == PHY_DUPLEX_FULL) ? "Full Duplex" : "Half Duplex");

}

static int gem_init (const uint8_t* mac)
{
	u32 support;

	printf("Initializing ethernet device...\n");

	memset(gem, 0, sizeof(gem_t));

	if(phy_init() < 0) {
		printf("Can't init phy\n");
		return -1;
	}

	/* Allocate buffers */
	gem->tx_buf = gem_alloc_buf(GEM_TX_BUF_CNT);
	gem->rx_buf = gem_alloc_buf(GEM_RX_BUF_CNT);

	gem_reset_hw();
	gem_setup_mac(mac);
	gem_init_hw();

	gem->phy_dev = phy_connect(&gem_mii_bus, -1);
	if(gem->phy_dev == NULL) {
		printf("Can't connect phy device\n");
		goto fail;
	}

	support = PHY_SUPPORT_AUTONEGO |
				PHY_SUPPORT_10HD | PHY_SUPPORT_10FD |
				PHY_SUPPORT_100HD | PHY_SUPPORT_100FD;
				//PHY_SUPPORT_1000HD | PHY_SUPPORT_1000FD;
	if(phy_start(gem->phy_dev, support) < 0)
	{
		printf("^r^Link is down !!!\n");
		printf("^r^Check Lan cable or Network !!!\n");
		goto fail;
	}

	if(!gem->phy_dev->link) {
		printf("Link is down !!!\n");
		goto fail;
	}
	gem_update_link();

	return 0;
fail:
	if(gem->tx_buf) gem_free_buf(gem->tx_buf);
	if(gem->rx_buf) gem_free_buf(gem->rx_buf);
	return -1;
}


static int gem_rx(void* packet, size_t maxlen)
{
	gem_buf_t *buf = gem->rx_buf;
	gem_buf_desc_t *desc = &buf->buf_desc[buf->idx];
	u32 len;
	u32 val;

	val = gem_reg_read(GEM_RXSR_OFFSET);
	if(val&(GEM_RXSR_RXOVR_MASK|GEM_RXSR_BUFFNA_MASK)) {
		error("RX ERROR(0x%04x) : ", val);
		if(val&GEM_RXSR_BUFFNA_MASK)	error("Buffer not available ");
		if(val&GEM_RXSR_RXOVR_MASK)		error("Receive overrun ");
		error("\n");
	}
	if(val) gem_reg_write(GEM_RXSR_OFFSET, val);

	if(!(desc->addr & GEM_RXBUF_NEW_MASK)) {
		return 0;
	}
	debug("gem_rx... addr:%p, status:0x%08x, rxsr:0x%08x\n", desc->addr, desc->status, val);

#if 0
	if(desc->status&GEM_RXBUF_SOF_MASK)
		debug("SOF\n");
	if(desc->status&GEM_RXBUF_EOF_MASK)
		debug("EOF\n");
#endif

	if(!(desc->status&GEM_RXBUF_EOF_MASK))
		error("It's not EOF\n");

	len = desc->status & GEM_RXBUF_LEN_MASK;
	if(len) {
		if(len > maxlen) printf("Overmax. len:%d, maxlen:%d\n", len, maxlen);
		else {
			debug("RX:%dBytes\n", len);
			memcpy(packet, (const void*)((ulong)desc->addr&GEM_RXBUF_ADD_MASK), len);
			dmb();
		}
	}

	desc->status = 0x00000000;
	desc->addr &= ~GEM_RXBUF_NEW_MASK;
	dmb();

	buf->idx = (buf->idx+1)%buf->cnt;
	dmb();


	return len;
}

static int gem_tx(const void *packet, size_t len)
{
	gem_buf_t *buf = gem->tx_buf;
	gem_buf_desc_t *desc = &buf->buf_desc[buf->idx];
	u32 val;

	debug("gem_tx. packet:%p, len:%d, status:0x%08x\n", packet, len, desc->status);
	if(!(desc->status&GEM_TXBUF_USED_MASK)) {
		printf("Hardware is using TXBUF !!!\n");
		return -1;
	}

	memcpy((void*)((ulong)desc->addr), packet, len);
	dmb();
	val = (len&GEM_TXBUF_LEN_MASK) | GEM_TXBUF_LAST_MASK;
	if(buf->idx == (buf->cnt-1)) val |= GEM_TXBUF_WRAP_MASK;
	desc->status = val;
	dmb();

	val = gem_reg_read(GEM_NWCTRL_OFFSET);
	val |= GEM_NWCTRL_STARTTX_MASK;
	gem_reg_write(GEM_NWCTRL_OFFSET, val);

	val = gem_reg_read(GEM_TXSR_OFFSET);
	if(val & (GEM_TXSR_HRESPNOK_MASK | GEM_TXSR_URUN_MASK | GEM_TXSR_BUFEXH_MASK))
		printf("Something has gone wrong. val : 0x%08x\n", val);
	gem_reg_write(GEM_TXSR_OFFSET, val);

	buf->idx = (buf->idx+1)%buf->cnt;
	dmb();

	return 0;
}

static void gem_start(void)
{
	gem_buf_t *buf = gem->rx_buf;
	gem_buf_desc_t *desc;
	int start_idx;
	u32 val;
	u32 nwctrl;

	/* disable rx and flush the next packet */
	nwctrl = gem_reg_read(GEM_NWCTRL_OFFSET);
	nwctrl &= ~GEM_NWCTRL_RXEN_MASK;
	gem_reg_write(GEM_NWCTRL_OFFSET, nwctrl);
	nwctrl |= GEM_NWCTRL_FLUSH_DPRAM_MASK;
	gem_reg_write(GEM_NWCTRL_OFFSET, nwctrl);

	/* clear status register */
	val = gem_reg_read(GEM_RXSR_OFFSET);
	if(val) gem_reg_write(GEM_RXSR_OFFSET, val);

	/* clean all rx buffer */
	start_idx = buf->idx;
	while(1)
	{
		desc = &buf->buf_desc[buf->idx];
		if(!(desc->addr & GEM_RXBUF_NEW_MASK)) break;

		desc->status = 0x00000000;
		desc->addr &= ~GEM_RXBUF_NEW_MASK;
		buf->idx = (buf->idx+1)%buf->cnt;

		if(start_idx == buf->idx) break;
	}
	dmb();

	/* enable rx */
	nwctrl |= GEM_NWCTRL_RXEN_MASK;
	gem_reg_write(GEM_NWCTRL_OFFSET, nwctrl);
}

static int gem_setaddr(const u8 *mac_addr)
{
	gem_setup_mac(mac_addr);
	return 0;
}

static eth_driver_t gem_driver =
{
	.init		= gem_init,
	.transmit	= gem_tx,
	.receive	= gem_rx,
	.start		= gem_start,
	.setaddr	= gem_setaddr,
};

eth_driver_t* get_eth_driver(void)
{
	return &gem_driver;
}
#endif
