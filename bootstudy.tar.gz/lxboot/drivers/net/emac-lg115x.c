
#if USE_LG115X_EMAC
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <timer.h>
#include <gpio.h>
#include <ethernet.h>

#include "phy.h"
#include "emac-lg115x.h"

#if 1
#define debug(fmt, args...)		do{}while(0)
#else
#define debug(fmt, args...)		printf("%s:%d: "fmt,__FUNCTION__,__LINE__,##args)
#endif

#define	TX_MAX_LENGTH	2048
#define	TX_BUF_CNT		1

#define	RX_MAX_LENGTH	2048
//#define RX_BUF_CNT		4
#define RX_BUF_CNT		32


#define	TXBUF_TOTAL_SIZE	((sizeof(stEmacTxDesc) + TX_MAX_LENGTH) * TX_BUF_CNT)
#define	RXBUF_TOTAL_SIZE	((sizeof(stEmacRxDesc) + RX_MAX_LENGTH) * RX_BUF_CNT)

#define	write_emac_reg(addr, val)	*(volatile unsigned int *)(MAC_MMIO_START + addr) = val
#define	read_emac_reg(addr)			*(volatile unsigned int *)(MAC_MMIO_START + addr)

static stEmacTxDesc *tx_buf[TX_BUF_CNT];
static stEmacRxDesc *rx_buf[RX_BUF_CNT];

static ulong tx_buf_base;
static ulong rx_buf_base;

static uint32_t rxIdx = 0;
static uint32_t txIdx = 0;

static uint8_t mac_addr[6];		//ethernet mac address

static phy_dev_t *emac_phy_dev;

static int emac_phy_read(u8 addr, int reg, u16 *val)
{
	u32 control, value;
	control = MREGBIT_START_MDIO_TRANS | MREGBIT_MDIO_READ_WRITE |
			((reg&0x1f) << 5) | (addr&0x1f);
	write_emac_reg(MAC_MDIO_CONTROL, control);

	while(read_emac_reg(MAC_MDIO_CONTROL) & 0x8000);

	value = read_emac_reg(MAC_MDIO_DATA);
	*val = (value&0xffff);
	return 0;
}

static int emac_phy_write(u8 addr, int reg, u16 val)
{
	u32 control;

	write_emac_reg(MAC_MDIO_DATA, val);

	control = MREGBIT_START_MDIO_TRANS |
			((reg&0x1f) << 5) | (addr&0x1f);
	write_emac_reg(MAC_MDIO_CONTROL, control);

	while(read_emac_reg(MAC_MDIO_CONTROL) & 0x8000);
	return 0;
}

static mii_bus_t emac_mii_bus =
{
	.read = emac_phy_read,
	.write = emac_phy_write,
};

static void emac_reset(void)
{
	//disable all the interrupts
	write_emac_reg(MAC_INTERRUPT_ENABLE, 0x0000);
	write_emac_reg(DMA_INTERRUPT_ENABLE, 0x0000);

	//disable transmit and receive units
	write_emac_reg(MAC_RECEIVE_CONTROL, 0x0000);
	write_emac_reg(MAC_TRANSMIT_CONTROL, 0x0000);

	//stop the DMA
	write_emac_reg(DMA_CONTROL, 0x0000);

	//reset mac, statistic counters
	write_emac_reg(MAC_GLOBAL_CONTROL, 0x0018);
	mdelay(5);

	write_emac_reg(MAC_GLOBAL_CONTROL, 0x0000);

}

static void hw_init(void)
{
	u32 val;

	val = 0;
	if(emac_phy_dev->duplex == PHY_DUPLEX_FULL) val |= MREGBIT_FULL_DUPLEX_MODE;
	else val |= MREGBIT_HALF_DUPLEX_MODE;

	if(emac_phy_dev->speed == PHY_SPEED_100) val |= 0x01;
	else val |= 0x00;

	write_emac_reg( MAC_GLOBAL_CONTROL, val);

	//MAC Init
	//disable transmit and receive units
	write_emac_reg(MAC_RECEIVE_CONTROL, 0x0000);
	write_emac_reg(MAC_TRANSMIT_CONTROL, 0x0000);

	//enable mac address filtering
	write_emac_reg(MAC_ADDRESS_CONTROL, 0x0001);	//enable address 1 filtering


	//zero initiaize the multicast hash table
	write_emac_reg(MAC_MULTICAST_HASH_TABLE1, 0x0000);
	write_emac_reg(MAC_MULTICAST_HASH_TABLE2, 0x0000);
	write_emac_reg(MAC_MULTICAST_HASH_TABLE3, 0x0000);
	write_emac_reg(MAC_MULTICAST_HASH_TABLE4, 0x0000);

	write_emac_reg(MAC_TRANSMIT_FIFO_ALMOST_FULL, 0x1f8);
	write_emac_reg(MAC_TRANSMIT_FIFO_ALMOST_FULL, 0x1f8);
	write_emac_reg(MAC_TRANSMIT_FIFO_ALMOST_FULL, 0x1f8);

	val = 0x5ee;
	write_emac_reg(MAC_TRANSMIT_PACKET_START_THRESHOLD, val);
	write_emac_reg(MAC_TRANSMIT_PACKET_START_THRESHOLD, val);
	write_emac_reg(MAC_TRANSMIT_PACKET_START_THRESHOLD, val);

	write_emac_reg(MAC_RECEIVE_PACKET_START_THRESHOLD, 0xc);
	write_emac_reg(MAC_RECEIVE_PACKET_START_THRESHOLD, 0xc);
	write_emac_reg(MAC_RECEIVE_PACKET_START_THRESHOLD, 0xc);

	//reset dma
	write_emac_reg(DMA_CONTROL, 0x0000);

	write_emac_reg(DMA_CONFIGURATION, 0x01);

	mdelay(10);

	write_emac_reg(DMA_CONFIGURATION, 0x00);

	mdelay(10);

	//  val = (0x1 << 17) | (0x01 << 3) ; //0x20008 Four burst mode	SC
	val = (0x1 << 17) | (0x01 << 5) ; //0x20008 16 burst mode
	write_emac_reg(DMA_CONFIGURATION, val);

	printf("Ethernet interface Up %d Mbps %s\n",
			(emac_phy_dev->speed == PHY_SPEED_100) ? 100 : 10,
			(emac_phy_dev->duplex == PHY_DUPLEX_FULL) ? "Full Duplex" : "Half Duplex");

}


static void emac_configure_tx(void)
{
	UINT32 u32ValueTemp=0;

	//set the transmit base address
	write_emac_reg(DMA_TRANSMIT_BASE_ADDRESS , tx_buf_base);
	mdelay(10);

	//Tx Inter Packet Gap value and enable the transmit
	u32ValueTemp=read_emac_reg(MAC_TRANSMIT_CONTROL);
	u32ValueTemp &= (~MREGBIT_IFG_LEN);
	u32ValueTemp |= MREGBIT_TRANSMIT_ENABLE;
	u32ValueTemp |= MREGBIT_TRANSMIT_AUTO_RETRY;
	write_emac_reg(MAC_TRANSMIT_CONTROL, u32ValueTemp);

	write_emac_reg(DMA_TRANSMIT_AUTO_POLL_COUNTER, 0x00);


	//start tx dma
	u32ValueTemp = read_emac_reg( DMA_CONTROL);
	u32ValueTemp |= MREGBIT_START_STOP_TRANSMIT_DMA;
	write_emac_reg( DMA_CONTROL, u32ValueTemp);

	return;
}

static void emac_configure_rx(void)
{
	UINT32 u32ValueTemp=0;

	//set the receive base address
	write_emac_reg(DMA_RECEIVE_BASE_ADDRESS , rx_buf_base);

	mdelay(10);

	//TBD -set the Tx Interrupt Delay

	//enable the receive
	u32ValueTemp=read_emac_reg(MAC_RECEIVE_CONTROL);
	u32ValueTemp |= MREGBIT_RECEIVE_ENABLE;
	u32ValueTemp |= MREGBIT_STORE_FORWARD;
	write_emac_reg(MAC_RECEIVE_CONTROL, u32ValueTemp);
	write_emac_reg(MAC_RECEIVE_CONTROL, u32ValueTemp);


	//start rx dma
	u32ValueTemp = read_emac_reg(DMA_CONTROL);
	u32ValueTemp |= MREGBIT_START_STOP_RECEIVE_DMA;
	//u32ValueTemp = 0x02;
	write_emac_reg(DMA_CONTROL, u32ValueTemp);

	return;


}


static int emac_init (const uint8_t* mac)
{
	int i;
	u32 support;

	printf("Initializing ethernet device...\n");

	/* verify chip id */
	memcpy(mac_addr, mac, 6);

	phy_init();

	emac_phy_dev = phy_connect(&emac_mii_bus, -1);
	if(emac_phy_dev == NULL) {
		printf("Can't connect phy device\n");
		return -1;
	}

	emac_reset();

	/* set the ethernet address */
	write_emac_reg (MAC_ADDRESS_CONTROL , 0x01);	// only MAC address1 enable
	write_emac_reg (MAC_ADDRESS1_HIGH,	mac_addr[0] | (mac_addr[1] << 8));
	write_emac_reg (MAC_ADDRESS1_MED,	mac_addr[2] | (mac_addr[3] << 8));
	write_emac_reg (MAC_ADDRESS1_LOW,	mac_addr[4] | (mac_addr[5] << 8));

	support = PHY_SUPPORT_AUTONEGO |
				PHY_SUPPORT_10HD | PHY_SUPPORT_10FD |
				PHY_SUPPORT_100HD | PHY_SUPPORT_100FD;
	if(phy_start(emac_phy_dev, support) < 0)
	{
		printf("^r^Link is down !!!\n");
		printf("^r^Check Lan cable or Network !!!\n");
		return -1;
	}

	if(!emac_phy_dev->link) {
		printf("Link is down !!!\n");
		return -1;
	}

	/* system initial */
	hw_init();

	/* allocate buffer memory */
	if(tx_buf_base) dma_free((void*)tx_buf_base);
	tx_buf_base = (ulong)dma_malloc(TXBUF_TOTAL_SIZE);

	if(rx_buf_base) dma_free((void*)rx_buf_base);
	rx_buf_base = (ulong)dma_malloc(RXBUF_TOTAL_SIZE);


	/* DMA setting*/
	for(i=0 ; i < RX_BUF_CNT ; i++)
	{
		int next = (i == (RX_BUF_CNT - 1)) ? 0 : (i+1);

		rx_buf[i] = (stEmacRxDesc *)(rx_buf_base + i*sizeof(stEmacRxDesc));
		memset((stEmacRxDesc *)rx_buf[i] , 0, sizeof(stEmacRxDesc));

		rx_buf[i]->BufferAddr1 = rx_buf_base + RX_BUF_CNT*sizeof(stEmacRxDesc) + i*RX_MAX_LENGTH;
		rx_buf[i]->OWN = 1;

		// BufferAddr2 means next descriptor pointer in chaining mode
		rx_buf[i]->BufferAddr2 = rx_buf_base + next*sizeof(stEmacRxDesc);

		rx_buf[i]->SecondAddressChained = 1;
		rx_buf[i]->BufferSize1 = RX_MAX_LENGTH;
	}
	rx_buf[RX_BUF_CNT-1]->EndRing = 1;

	for(i=0 ; i<TX_BUF_CNT ; i++)
	{
		tx_buf[i] = (stEmacTxDesc *)(tx_buf_base + i*sizeof(stEmacTxDesc));
		memset(tx_buf[i] , 0, sizeof(stEmacTxDesc));

		tx_buf[i]->BufferAddr1 = tx_buf_base + TX_BUF_CNT*sizeof(stEmacTxDesc) + i*TX_MAX_LENGTH;
		tx_buf[i]->OWN=1;

	}
	tx_buf[TX_BUF_CNT-1]->EndRing = 1;


	/* Tx and Rx configuration */
	emac_configure_tx();
	emac_configure_rx();

	write_emac_reg(DMA_INTERRUPT_ENABLE , 0xD5);

	return 0;
}

/* Get a data block via Ethernet */
static int emac_rx (void* packet, size_t len)
{
	int rxlen = 0;
	u32 status;

	status = read_emac_reg(DMA_STATUS_IRQ);

	if((status&MREGBIT_RECEIVE_TRANSFER_DONE_IRQ))	// == 0)
	{
		//	debug("no packets\n");
//		return -1;
		write_emac_reg(DMA_STATUS_IRQ , MREGBIT_RECEIVE_TRANSFER_DONE_IRQ);
	}

#if 1
	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
	{
		write_emac_reg( DMA_STATUS_IRQ , MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ);
		//debug("buffer overflow\n");
		WARN("#### buffer overflow ####\n");
//		return -1;
	}
#endif

//	write_emac_reg(DMA_STATUS_IRQ , MREGBIT_RECEIVE_TRANSFER_DONE_IRQ);
	if(rx_buf[rxIdx]->OWN == 0)
	{
		rxlen = rx_buf[rxIdx]->FramePacketLength;

		rxlen -= 4;

//		printf("rx len=%d\n", rxlen);

		if(rxlen < 0)		// packet length error
		{
			WARN("packet error\n");
			rxlen = -1;
		}
		else
		{
			if(rxlen > len)
			{
				WARN("RX LEN OVERFLOW !!!. rxlen=%d\n", rxlen);
				rxlen = len;
			}

			memcpy(packet, (const void*)(rx_buf[rxIdx]->BufferAddr1), rxlen);
		}

		rx_buf[rxIdx]->OWN = 1;
		rxIdx = (rxIdx + 1) >= RX_BUF_CNT ? 0 : rxIdx + 1;

	}

	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
	{
	//debug("total length %d \n",trxlen);
		write_emac_reg(DMA_RECEIVE_POLL_DEMAND, 0xFF);
	}

	return rxlen;
}

/* Send a data block via Ethernet. */
static int emac_tx(const void *packet, size_t length)
{
	int i;

	if(length <= 0)
	{
		debug("bad packet size: %d\n", length);
		goto out;
	}

	if( (read_emac_reg(DMA_STATUS_IRQ)&MREGBIT_TRANSMIT_DES_UNAVAILABLE_IRQ) != 0 )
	{
		write_emac_reg(DMA_STATUS_IRQ,MREGBIT_TRANSMIT_DES_UNAVAILABLE_IRQ);
		tx_buf[txIdx]->OWN = 1;

	}

	for(i=0 ; (read_emac_reg(DMA_STATUS_IRQ)&MREGBIT_TRANSMIT_DMA_STATE) != 0x50000 ; i++ )
	{
		if(i > 1000000)
		{
			printf("tx DMA not ready %x\n", read_emac_reg(DMA_STATUS_IRQ)&MREGBIT_TRANSMIT_DMA_STATE );
			goto out;
		}
	}


	if(length < TX_MAX_LENGTH)
	{
		memcpy((UINT8 *)(tx_buf[txIdx]->BufferAddr1) , (UINT8 *)packet , length);
		tx_buf[txIdx]->BufferSize1 = length;
		tx_buf[txIdx]->FirstSegment = 1;
		tx_buf[txIdx]->LastSegment = 1;
		tx_buf[txIdx]->InterruptOnCompletion=1;

		tx_buf[txIdx]->OWN = 1;

		write_emac_reg(DMA_TRANSMIT_POLL_DEMAND, 0xFF);
	}
	else
	{
		printf("TX packet size overflow\n");
	}



out:

	return 0;
}


static void emac_start(void)
{
	// clean previous data
	u32 status = read_emac_reg(DMA_STATUS_IRQ);

	if((status&MREGBIT_RECEIVE_TRANSFER_DONE_IRQ))
		write_emac_reg(DMA_STATUS_IRQ , MREGBIT_RECEIVE_TRANSFER_DONE_IRQ);

	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
		write_emac_reg( DMA_STATUS_IRQ , MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ);

	while(1)
	{
		if(rx_buf[rxIdx]->OWN == 0)
		{
			rx_buf[rxIdx]->OWN = 1;
			rxIdx = (rxIdx + 1) >= RX_BUF_CNT ? 0 : rxIdx + 1;
		}
		else
		{
			break;
		}
	}

	if(status&MREGBIT_RECEIVE_DES_UNAVAILABLE_IRQ)
		write_emac_reg(DMA_RECEIVE_POLL_DEMAND, 0xFF);
}

static int emac_setaddr(const u8 *mac)
{
	memcpy(mac_addr, mac, 6);
	write_emac_reg (MAC_ADDRESS1_HIGH,	mac_addr[0] | (mac_addr[1] << 8));
	write_emac_reg (MAC_ADDRESS1_MED,	mac_addr[2] | (mac_addr[3] << 8));
	write_emac_reg (MAC_ADDRESS1_LOW,	mac_addr[4] | (mac_addr[5] << 8));
	return 0;
}


static eth_driver_t emac_driver =
{
	.init		= emac_init,
	.transmit	= emac_tx,
	.receive	= emac_rx,
	.start		= emac_start,
	.setaddr	= emac_setaddr,
};

eth_driver_t* get_eth_driver(void)
{
	return &emac_driver;
}
#endif
