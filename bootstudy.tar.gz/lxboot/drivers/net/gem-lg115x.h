/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifndef __GEM_LG115X_H__
#define __GEM_LG115X_H__

#define GEM_NWCTRL_OFFSET		0x00000000 /* Network Control reg */
#define GEM_NWCTRL_FLUSH_DPRAM_MASK		0x00040000
#define GEM_NWCTRL_RXTSTAMP_MASK		0x00008000 /* RX Timestamp in CRC */
#define GEM_NWCTRL_ZEROPAUSETX_MASK		0x00001000 /* Transmit zero quantum pause frame */
#define GEM_NWCTRL_PAUSETX_MASK			0x00000800 /* Transmit pause frame */
#define GEM_NWCTRL_HALTTX_MASK			0x00000400 /* Halt transmission after current frame */
#define GEM_NWCTRL_STARTTX_MASK			0x00000200 /* Start tx (tx_go) */
#define GEM_NWCTRL_STATWEN_MASK			0x00000080 /* Enable writing to stat counters */
#define GEM_NWCTRL_STATINC_MASK			0x00000040 /* Increment statistic registers */
#define GEM_NWCTRL_STATCLR_MASK			0x00000020 /* Clear statistic registers */
#define GEM_NWCTRL_MDEN_MASK			0x00000010 /* Enable MDIO port */
#define GEM_NWCTRL_TXEN_MASK			0x00000008 /* Enable transmit */
#define GEM_NWCTRL_RXEN_MASK			0x00000004 /* Enable receive */
#define GEM_NWCTRL_LOOPEN_MASK			0x00000002 /* local loopback */

#define GEM_NWCFG_OFFSET		0x00000004 /* Network Config reg */
#define GEM_NWCFG_BADPREAMBEN_MASK		0x20000000 /* disable rejection of non-standard preamble */
#define GEM_NWCFG_IPDSTRETCH_MASK		0x10000000 /* enable transmit IPG */
#define GEM_NWCFG_FCSIGNORE_MASK		0x04000000 /* disable rejection of FCS error */
#define GEM_NWCFG_HDRXEN_MASK			0x02000000 /* RX half duplex */
#define GEM_NWCFG_RXCHKSUMEN_MASK		0x01000000 /* enable RX checksum offload */
#define GEM_NWCFG_PAUSECOPYDI_MASK		0x00800000 /* Do not copy pause Frames to memory */
#define GEM_NWCFG_BUSWIDTH_MASK			0x00600000 /* Data bus width */
#define GEM_NWCFG_BUSWIDTH_SHIFT		21
#define GEM_NWCFG_BUSWIDTH_32			(0 << GEM_NWCFG_BUSWIDTH_SHIFT)
#define GEM_NWCFG_BUSWIDTH_64			(1 << GEM_NWCFG_BUSWIDTH_SHIFT)
#define GEM_NWCFG_BUSWIDTH_128			(2 << GEM_NWCFG_BUSWIDTH_SHIFT)
#define GEM_NWCFG_MDC_SHIFT_MASK		18 /* shift bits for MDC */
#define GEM_NWCFG_MDCCLKDIV_MASK		0x001C0000 /* MDC Mask PCLK divisor */
#define GEM_NWCFG_MDCCLKDIV_8				(0 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_MDCCLKDIV_16				(1 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_MDCCLKDIV_32				(2 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_MDCCLKDIV_48				(3 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_MDCCLKDIV_64				(4 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_MDCCLKDIV_96				(5 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_MDCCLKDIV_128				(6 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_MDCCLKDIV_224				(7 << GEM_NWCFG_MDC_SHIFT_MASK)
#define GEM_NWCFG_FCSREM_MASK			0x00020000 /* Discard FCS from received frames */
#define GEM_NWCFG_LENGTHERRDSCRD_MASK	0x00010000	/* RX length error discard */
#define GEM_NWCFG_RXOFFS_MASK			0x0000C000 /* RX buffer offset */
#define GEM_NWCFG_PAUSEEN_MASK			0x00002000 /* Enable pause TX */
#define GEM_NWCFG_RETRYTESTEN_MASK		0x00001000 /* Retry test */
#define GEM_NWCFG_1000_MASK				0x00000400 /* Gigbit mode */
#define GEM_NWCFG_EXTADDRMATCHEN_MASK	0x00000200	/* External address match enable */
#define GEM_NWCFG_UCASTHASHEN_MASK		0x00000080 /* Receive unicast hash frames */
#define GEM_NWCFG_MCASTHASHEN_MASK		0x00000040 /* Receive multicast hash frames */
#define GEM_NWCFG_BCASTDI_MASK			0x00000020 /* Do not receive broadcast frames */
#define GEM_NWCFG_COPYALLEN_MASK		0x00000010 /* Copy all frames */
#define GEM_NWCFG_NVLANDISC_MASK		0x00000004 /* Receive only VLAN frames */
#define GEM_NWCFG_FDEN_MASK				0x00000002 /* Full duplex */
#define GEM_NWCFG_100_MASK				0x00000001 /* 10 or 100 Mbs */

#define GEM_NWSR_OFFSET			0x00000008 /* Network Status reg */
#define GEM_NWSR_MDIOIDLE_MASK			0x00000004 /* PHY management idle */
#define GEM_NWSR_MDIO_MASK				0x00000002 /* Status of mdio_in */


#define GEM_USERIO_OFFSET		0x0000000C /* User IO reg */

#define GEM_DMACR_OFFSET		0x00000010 /* DMA Configuration reg */
#define GEM_DMACR_STALLRX_MASK			0x08000000 /* Stall the RX DMA descriptor */
#define GEM_DMACR_PKTDSCRD_MASK			0x01000000 /* Resource not available discard */
#define GEM_DMACR_RXBUF_MASK			0x00FF0000 /* Mask bit for RX buffer size */
#define GEM_DMACR_RXBUF_SHIFT			16 /* Shift bit for RX buffer size */
#define GEM_DMACR_TCPCKSUM_MASK			0x00000800 /* enable/disable TX checksum offload */
#define GEM_DMACR_TXSIZE_MASK			0x00000400 /* TX buffer memory size */
#define GEM_DMACR_RXSIZE_MASK			0x00000300 /* RX buffer memory size */
#define GEM_DMACR_ENDIAN_MASK			0x00000080 /* Endian configuration */
#define GEM_DMACR_BLENGTH_MASK			0x0000001F /* Buffer burst length */
#define GEM_DMACR_BLENGTH_INCR16		0x00000010 /* Buffer burst length */
#define GEM_DMACR_BLENGTH_INCR8			0x00000008 /* Buffer burst length */
#define GEM_DMACR_BLENGTH_INCR4			0x00000004 /* Buffer burst length */
#define GEM_DMACR_BLENGTH_SINGLE		0x00000002 /* Buffer burst length */

#define GEM_TXSR_OFFSET			0x00000014 /* TX Status reg */
#define GEM_RXQBASE_OFFSET		0x00000018 /* RX Q Base address reg */
#define GEM_TXQBASE_OFFSET		0x0000001C /* TX Q Base address reg */

#define GEM_RXSR_OFFSET			0x00000020 /* RX Status reg */
#define GEM_RXSR_HRESPNOK_MASK			0x00000008 /* Receive hresp not OK */
#define GEM_RXSR_RXOVR_MASK				0x00000004 /* Receive overrun */
#define GEM_RXSR_FRAMERX_MASK			0x00000002 /* Frame received OK */
#define GEM_RXSR_BUFFNA_MASK			0x00000001 /* RX buffer used bit set */

#define GEM_ISR_OFFSET			0x00000024 /* Interrupt Status reg */
#define GEM_IER_OFFSET			0x00000028 /* Interrupt Enable reg */
#define GEM_IDR_OFFSET			0x0000002C /* Interrupt Disable reg */
#define GEM_IMR_OFFSET			0x00000030 /* Interrupt Mask reg */

#define GEM_PHYMNTNC_OFFSET		0x00000034 /* Phy Maintaince reg */
#define GEM_PHYMNTNC_OP_MASK			0x40020000 /* operation mask bits */
#define GEM_PHYMNTNC_OP_R_MASK			0x20000000 /* read operation */
#define GEM_PHYMNTNC_OP_W_MASK			0x10000000 /* write operation */
#define GEM_PHYMNTNC_ADDR_MASK			0x0F800000 /* Address bits */
#define GEM_PHYMNTNC_REG_MASK			0x007C0000 /* register bits */
#define GEM_PHYMNTNC_DATA_MASK			0x0000FFFF /* data bits */
#define GEM_PHYMNTNC_PHYAD_SHIFT_MASK	23 /* Shift bits for PHYAD */
#define GEM_PHYMNTNC_PHREG_SHIFT_MASK	18 /* Shift bits for PHREG */

#define GEM_RXPAUSE_OFFSET		0x00000038 /* RX Pause Time reg */
#define GEM_TXPAUSE_OFFSET		0x0000003C /* TX Pause Time reg */
#define GEM_HASHL_OFFSET		0x00000080 /* Hash Low address reg */
#define GEM_HASHH_OFFSET		0x00000084 /* Hash High address reg */
#define GEM_LADDR1L_OFFSET		0x00000088 /* Specific1 addr low */
#define GEM_LADDR1H_OFFSET		0x0000008C /* Specific1 addr high */
#define GEM_LADDR2L_OFFSET		0x00000090 /* Specific2 addr low */
#define GEM_LADDR2H_OFFSET		0x00000094 /* Specific2 addr high */
#define GEM_LADDR3L_OFFSET		0x00000098 /* Specific3 addr low */
#define GEM_LADDR3H_OFFSET		0x0000009C /* Specific3 addr high */
#define GEM_LADDR4L_OFFSET		0x000000A0 /* Specific4 addr low */
#define GEM_LADDR4H_OFFSET		0x000000A4 /* Specific4 addr high */
#define GEM_MATCH1_OFFSET		0x000000A8 /* Type ID1 Match reg */
#define GEM_MATCH2_OFFSET		0x000000AC /* Type ID2 Match reg */
#define GEM_MATCH3_OFFSET		0x000000B0 /* Type ID3 Match reg */
#define GEM_MATCH4_OFFSET		0x000000B4 /* Type ID4 Match reg */
#define GEM_WOL_OFFSET			0x000000B8 /* Wake on LAN reg */
#define GEM_STRETCH_OFFSET		0x000000BC /* IPG Stretch reg */
#define GEM_SVLAN_OFFSET		0x000000C0 /* Stacked VLAN reg */
#define GEM_MODID_OFFSET		0x000000FC /* Module ID reg */


#define GEM_RXBUF_EOF_MASK		0x00008000 /* End of frame. */
#define GEM_RXBUF_SOF_MASK		0x00004000 /* Start of frame. */
#define GEM_RXBUF_LEN_MASK		0x00003FFF /* Mask for length field */

#define GEM_RXBUF_WRAP_MASK		0x00000002 /* Wrap bit, last BD */
#define GEM_RXBUF_NEW_MASK		0x00000001 /* Used bit.. */
#define GEM_RXBUF_ADD_MASK		0xFFFFFFFC /* Mask for address */

#define GEM_TXBUF_USED_MASK		0x80000000
#define GEM_TXBUF_WRAP_MASK		0x40000000
#define GEM_TXBUF_LAST_MASK		0x00008000 /* Last buffer */
#define GEM_TXBUF_LEN_MASK		0x00003FFF /* Mask for length field */

#define GEM_TXSR_HRESPNOK_MASK	0x00000100 /* Transmit hresp not OK */
#define GEM_TXSR_URUN_MASK		0x00000040 /* Transmit underrun */
#define GEM_TXSR_BUFEXH_MASK	0x00000010 /* Transmit buffs exhausted mid frame */


#endif
