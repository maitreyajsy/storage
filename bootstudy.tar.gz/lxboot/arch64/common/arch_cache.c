/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <string.h>
#include <command.h>

#ifdef USE_DATA_CACHE
void dcache_flush_all(void)
{
	flush_dcache();
}

void dcache_clean_all(void)
{
	clean_dcache();
}

void dcache_inv_all(void)
{
	inv_dcache();
}

void dcache_flush_range(unsigned long start, unsigned long size)
{
	unsigned long nstart = start;
	unsigned long end = start + size;

	nstart &= ~(D_CACHE_LINE_SIZE-1);

	while(nstart < end)
	{
		/* D / U line Clean & invalidate by VA to POC */
		asm volatile("dc 	civac, %0" : : "r" (nstart) : "memory");
		nstart += D_CACHE_LINE_SIZE;
	}
	dsb();
}

void dcache_clean_range(unsigned long start, unsigned long size)
{
	unsigned long nstart = start;
	unsigned long end = start + size;

	nstart &= ~(D_CACHE_LINE_SIZE-1);

	while(nstart < end)
	{
		/* D / U line Clean by VA to POC */
		asm volatile("dc 	cvac, %0" : : "r" (nstart) : "memory");
		nstart += D_CACHE_LINE_SIZE;
	}
	dsb();
}

void dcache_inv_range(unsigned long start, unsigned long size)
{
	unsigned long nstart = start;
	unsigned long end = start + size;

	if( nstart & (D_CACHE_LINE_SIZE-1))
	{
		nstart &= ~(D_CACHE_LINE_SIZE-1);
		/* D / U line Clean by VA to POC */
		asm volatile("dc 	cvac, %0" : : "r" (nstart) : "memory");
	}

	if( end & (D_CACHE_LINE_SIZE-1))
	{
		end &= ~(D_CACHE_LINE_SIZE-1);
		/* D / U line Clean & invalidate by VA to POC */
		asm volatile("dc 	civac, %0" : : "r" (end) : "memory");
	}

	while(nstart < end)
	{
		/* D / U line invalidate by VA to POC */
		asm volatile("dc 	ivac, %0" : : "r" (nstart) : "memory");
		nstart += D_CACHE_LINE_SIZE;
	}
	dsb();
}
#else
void dcache_flush_all(void);
void dcache_clean_all(void);
void dcache_inv_all(void);
void dcache_flush_range(unsigned long start, unsigned long size){}
void dcache_clean_range(unsigned long start, unsigned long size){}
void dcache_inv_range(unsigned long start, unsigned long size){}
#endif

void cache_flush(void)
{
	inv_icache();
	flush_dcache();
}

#if !defined(FIRST_BOOT)
static int cmd_cacheinfo(int argc, char* argv[])
{
	uint32_t value;

	uint32_t 	cache_lvl;
	uint32_t	CTypeX;

	printf("----------------------------------------------------------------\n");
	printf("-------------------------CTR_EL0 INFO---------------------------\n");
	/*
	* Read Cache Type Register(CTR_EL0)
	**/
	asm volatile ("mrs	%0, ctr_el0" : "=r" (value) :: "memory");
	//printf("ctr_el0[%08x]\n", value);

	/*
	* L1 instruction cache indexing and tagging policy.
	**/
	switch((value>>14)&0x03)
	{
		case 0x1:
			printf("ASID-tagged Virtual Index, Virtual Tag (AIVIVT) \n");
			break;

		case 0x2:
			printf("Virtual Index, Physical Tag (VIPT) \n");
			break;

		case 0x3:
			printf("Physical Index, Physical Tag (PIPT) \n");
			break;

		default:
			printf("Unknown L1 I-cache idx and tagging policy \n");
	}


	/*
	* Log2 of the number of words in the smallest cache line of all the
	* instruction caches that are controlled by the processor.
	**/
	printf("IminLine: %d words\n", 0x1<<(value&0xF));


	/*
	* Log2 of the number of words in the smallest cache line of all the
	* data caches that are controlled by the processor.
	**/
	printf("DminLine: %d words\n", 0x1<<((value>>16)&0xF));


	/*
	* Exclusives Reservation Granule. Log2 of the number of words of
	* the maximum size of the reservation granule that has been implemented
	* for the Load-Exclusive and Store-Exclusive instructions.
	**/
	printf("Exclusives Reservation Granule: %d words\n", 0x1<<((value>>20)&0xF));


	/*
	* Cache Writeback Granule. Log2 of the number of words of the maximum size of memory
	* that can be overwritten as a result of the eviction of a cache entry that has had a memory
	* location in it modified.
	* A value of 0b0000 indicates that the CTR does not provide Cache Writeback Granule
    * information and either:
    * . the architectural maximum of 512 words (2Kbytes) must be assumed
    * . the Cache Writeback Granule can be determined from maximum cache line size encoded in the Cache Size ID Registers.
    * Values greater than 0b1001 are reserved.
	**/
	if(((value>>24)&0xF) != 0x0)
	{
		printf("Cache Writeback Granule.: %d words\n", 0x1<<((value>>24)&0xF));
	}
	printf("-------------------------CLIDR_EL1 INFO-------------------------\n\n");

	/*
	* Read Cache Level ID Register(CLIDR_EL1)
	**/
	asm volatile ("mrs	%0, clidr_el1" : "=r" (value):: "memory");
	printf("clidr_el1[%08x]\n", value);

	for(cache_lvl=0;cache_lvl<7;cache_lvl++)
	{
		CTypeX = (value >> (cache_lvl*3))&0x7;

		if(CTypeX!=0x0)
		{
			printf("cache level [%d]",cache_lvl+1);

			switch(CTypeX)
			{
				case 0x1:
					printf("\t Instruction cache only\n");
					break;

				case 0x2:
					printf("\t Data cache only\n");
					break;

				case 0x3:
					printf("\t Separate Instruction and Data caches\n");
					break;

				case 0x4:
					printf("\t Unified cache\n");
					break;

				default:
					printf("\t There is no cache!!\n");
			}

		}
	}

	printf("Level of Unification Inner Shareable[%d]\n", (value >> 21) & 0x07);
	printf("Level of Coherency[%d]\n", (value >> 24) & 0x07);
	printf("Level of Unification Uniprocessor[%d]\n", (value >> 27) & 0x07);
	printf("------------------------CCSIDR_EL1 INFO-------------------------\n\n");

	/*
	* Set L1 Instruction Cache Size Selection.
	* Get L1 Instruction Cache Size.
	**/
	asm volatile("msr csselr_el1, %0" :: "r" (1): "memory");		// Cache Size Selection
	asm volatile("mrs %0, ccsidr_el1" : "=r" (value):: "memory");	// Cache Size ID
	printf("L1 ICache Size Info:\n");
	printf("\t# of words in ICache line: %d words\n", 0x1<<((value&0x7) + 2));
	printf("\tAssociaivity of ICache: %d\n", ((value>>3)&0x3FF) + 1);
	printf("\t# of sets in ICache: %d\n", ((value>>13)&0x7FFF) + 1);
	printf("\tSupport Write-Allocation[%d]\n", (value>>28)&0x01);
	printf("\tSupport Read-Allocation[%d]\n", (value>>29)&0x01);
	printf("\tSupport Write-Back[%d]\n", (value>>30)&0x01);
	printf("\tSupport Write-Through[%d]\n", (value>>31)&0x01);


	/*
	* Set L1 Data Cache Size Selection.
	* Get L1 Data Cache  Size.
	**/
	asm volatile("msr csselr_el1, %0" :: "r" (0): "memory");		// Cache Size Selection
	asm volatile("mrs %0, ccsidr_el1" : "=r" (value):: "memory");	// Cache Size ID
	printf("\nL1 DCache Size Info:\n");
	printf("\t# of words in DCache line: %d words\n", 0x1<<((value&0x7) + 2));
	printf("\tAssociaivity of DCache: %d\n", ((value>>3)&0x3FF) + 1);
	printf("\t# of sets in DCache: %d\n", ((value>>13)&0x7FFF) + 1);
	printf("\tSupport Write-Allocation[%d]\n", (value>>28)&0x01);
	printf("\tSupport Read-Allocation[%d]\n", (value>>29)&0x01);
	printf("\tSupport Write-Back[%d]\n", (value>>30)&0x01);
	printf("\tSupport Write-Through[%d]\n", (value>>31)&0x01);

	/*
	* Set L2 Unified Cache Size Selection.
	* Get L2 Unified Cache  Size.
	**/
	asm volatile("msr csselr_el1, %0" :: "r" (2): "memory");		// Cache Size Selection
	asm volatile("mrs %0, ccsidr_el1" : "=r" (value):: "memory");	// Cache Size ID
	printf("\nL2 UCache Size Info:\n");
	printf("\t# of words in UCache line: %d words\n", 0x1<<((value&0x7) + 2));
	printf("\tAssociaivity of UCache: %d\n", ((value>>3)&0x3FF) + 1);
	printf("\t# of sets in UCache: %d\n", ((value>>13)&0x7FFF) + 1);
	printf("\tSupport Write-Allocation[%d]\n", (value>>28)&0x01);
	printf("\tSupport Read-Allocation[%d]\n", (value>>29)&0x01);
	printf("\tSupport Write-Back[%d]\n", (value>>30)&0x01);
	printf("\tSupport Write-Through[%d]\n", (value>>31)&0x01);
	
	return 0;
}
COMMAND(cacheinfo, cmd_cacheinfo, "display cache info", NULL);

#endif
