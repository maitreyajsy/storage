#include <string.h>
#include <arch/cpu.h>
#include <mmu.h>
#include <command.h>

#if USE_SMP
#if !USE_DATA_CACHE
#error "Have to enable USE_DATA_CACHE to use SMP"
#endif
#endif

#if USE_DATA_CACHE

#ifndef MMU_L1_TABLE_BASE
#error "Have to define MMU_L1_TABLE_BASE"
#endif

#ifndef MMU_L2_TABLE_BASE
#error "Have to define MMU_L2_TABLE_BASE"
#endif

#ifndef MMU_L3_TABLE_BASE
#error "Have to define MMU_L3_TABLE_BASE"
#endif

#ifndef MEM_MMU_TABLE
#error "Have to define MEM_MMU_TABLE"
#endif

//#define DBG
#include <debug.h>

static int mmu_table_inited = 0;
static mem_map_t map_table[] = MEM_MMU_TABLE;

#if 0
static void mmu_tt_align_check(void)
{
	uint32_t i;
#if (MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB)
	uint32_t shift = 1 << TT_PAGE_SHIFT;
#elif(MMU_GRANULE == USE_GRANULE_4KB_BLOCK_2MB)
	uint32_t shift = 1 << TT_BLOCK_SHIFT;
#elif (MMU_GRANULE == USE_GRANULE_64KB_PAGE_64KB)
	uint32_t shift = 1 << TT_PAGE_SHIFT;
#endif

	for(i = 0; i < ARRAY_SIZE(map_table); i++)
	{
		if((map_table[i].virt % shift) ||
			(map_table[i].size % shift) ||
			(map_table[i].phys % shift))
		{
			printf("index %d, shift %x\n", i, shift);
			printf("%x, %x, %x, %x, %x, %x\n", map_table[i].virt
											 , map_table[i].size
											 , map_table[i].phys
											 , map_table[i].virt % shift
											 , map_table[i].size % shift
											 , map_table[i].phys % shift);
			ERROR("unaligned mmu table, check mmu table\n");
		}

	}

	printf("%s done\n", __func__);
}
#else
static void mmu_tt_align_check(void) {}
#endif

/*
 * print information macro & prameters for setup mmu
 */
static void mmu_tt_info(void)
{
	mmu_tt_align_check();

#if (MMU_GRANULE == USE_GRANULE_64KB_PAGE_64KB)
	DEBUG("============== info mmu setup ==============\n");
	DEBUG("granule : %dKB\n", TCR_EL_TG0 ? 64 : 4);
	DEBUG("use 64KB page\n");
	DEBUG("input address size :%d, memsize %dGB\n", TT_MAX_INPUT_ADD_SIZE
											, ((ulong)1<<TT_MAX_INPUT_ADD_SIZE)/GB);
	DEBUG("tcr_el03.T0SZ %d\n", TCR_EL_T0SZ);
	DEBUG("ttrb0_el3 base address low boundary bit %d\n", TT_BASE_ADD_LOW_BIT);
	DEBUG("level 3 base address low boundary bit %d\n", TT_L3_ADD_LOW_BIT);
	DEBUG("--------------------------------------------\n");
	DEBUG("level 2 table entry number %d\n", TT_L2_ENTRY_NUMBER);
	DEBUG("level 2 table base address align 0x%x\n", TT_L2_BASE_ADD_ALIGN);
	DEBUG("level 3 table base address align 0x%x\n", TT_L3_BASE_ADD_ALIGN);
	DEBUG("--------------------------------------------\n");
	DEBUG("page des shift %d\n", TT_PAGE_SHIFT);
	DEBUG("--------------------------------------------\n");
	DEBUG("level 2 table size %d\n", MMU_L2_TABLE_SIZE);
	DEBUG("level 3 table size %d\n", MMU_L3_TABLE_SIZE);
	DEBUG("--------------------------------------------\n");

#elif ((MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB) || (MMU_GRANULE == USE_GRANULE_4KB_BLOCK_2MB))
	DEBUG("============== info mmu setup ==============\n");
	DEBUG("granule : %dKB\n", TCR_EL_TG0 ? 64 : 4);
#if (MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB)
	DEBUG("use 4KB page\n");
#else
	DEBUG("use 2MB block\n");
#endif
	DEBUG("input address size :%d, memsize %dGB\n", TT_MAX_INPUT_ADD_SIZE
											, ((ulong)1<<TT_MAX_INPUT_ADD_SIZE)/GB);
	DEBUG("tcr_el03.T0SZ %d\n", TCR_EL_T0SZ);
	DEBUG("ttrb0_el3 base address low boundary bit %d\n", TT_BASE_ADD_LOW_BIT);
	DEBUG("level 2 base address low boundary bit %d\n", TT_L2_ADD_LOW_BIT);
	DEBUG("level 3 base address low boundary bit %d\n", TT_L3_ADD_LOW_BIT);
	DEBUG("--------------------------------------------\n");
	DEBUG("level 1 table entry number %d\n", TT_L1_ENTRY_NUMBER);
	DEBUG("level 2 table entry number %d\n", TT_L2_ENTRY_NUMBER);
	DEBUG("level 1 table base address align 0x%x\n", TT_L1_BASE_ADD_ALIGN);
	DEBUG("level 2 table base address align 0x%x\n", TT_L2_BASE_ADD_ALIGN);
	DEBUG("level 3 table base address align 0x%x\n", TT_L3_BASE_ADD_ALIGN);
	DEBUG("--------------------------------------------\n");
	DEBUG("block des shift %d\n", TT_BLOCK_SHIFT);
	DEBUG("page des shift %d\n", TT_PAGE_SHIFT);
	DEBUG("--------------------------------------------\n");
	DEBUG("level 1 table size %d\n", MMU_L1_TABLE_SIZE);
	DEBUG("level 2 table size %d\n", MMU_L2_TABLE_SIZE);
	DEBUG("level 3 table size %d\n", MMU_L3_TABLE_SIZE);
	DEBUG("--------------------------------------------\n");
#else
#error "do define MMU_GRANULE"
#endif
}

#if (MMU_GRANULE == USE_GRANULE_64KB_PAGE_64KB)
/*
 * initialize mmu translation table
 *
 * ex> T0SZ : 31(memory 8GB)
 * |-----------------------|
 * | MMU Level2 Table(128B)|
 * |-----------------------| MMU_L2_TABLE_BASE
 * | MMU Level3 Table(1M)  |
 * |-----------------------| MMU_L3_TABLE_BASE
 * |	            	   |
 */
static int mmu_set_table(void)
{
	uint32_t 	i,j;
	ulong 	*l2_table = (ulong *)(MMU_L2_TABLE_BASE & ~TT_L2_BASE_ADD_ALIGN);
	ulong 	*l3_table = (ulong *)(MMU_L3_TABLE_BASE & ~TT_L3_BASE_ADD_ALIGN);

	if(mmu_table_inited) 
		return 0;

	mmu_tt_info();

	if(l2_table != (ulong *)MMU_L2_TABLE_BASE)
	{
		ERROR("error address align MMU_L2_TABLE_BASE\n");
		return -1;
	}
	
	if(l3_table != (ulong *)MMU_L3_TABLE_BASE)
	{
		ERROR("error address align MMU_L3_TABLE_BASE\n");
		return -1;
	}

	DEBUG("info mmu table base address l2:%016x, l3:%016x\n", l2_table, l3_table);

	memset(l2_table, 0, MMU_L2_TABLE_SIZE);
	memset(l3_table, 0, MMU_L3_TABLE_SIZE);

	/* Level 0,1,2 Table descriptor
	 *
	 * [0] 		: 1(valid), 0(invalid)
	 * [1]		: 1(table), 0(block)
	 * [47:16] 	: next level table address
	 * [59] 	: PXNTable , used el01
	 * [60] 	: UXNTable(el01) or XNTable(el23)
	 * [62:61] 	: APTable 00(No effect on permissions in subsequent levels of lookup)
	 * [63] 	: NSTable 0(the defined table address is in the secure physical address space)
	 */

	/* setup mmu level2 traslation table */
	for(i = 0; i < TT_L2_ENTRY_NUMBER; i++)
	{
		l2_table[i] = MMU_L3_TABLE_BASE + (i << TT_PAGE_SHIFT) + TT_TYPE_TABLE + TT_VALID;

		DEBUG("l2table[%d] : %016x\n", i, l2_table[i]);
	}

	/* Level 3 Page descriptor
	 *
	 * ---- lower attributes ---
	 * [1:0] 	: 11(page descriptor) , other invalid
	 * [4:2] 	: AttrIndx, index attr of mair_elx
	 * [5] 		: NS, Non-secure bit
	 * [7:6] 	: AP, Data Access permissions bits
	 * [9:8] 	: SH, 00(non-share), 01(invalid), 10(outer share), 11(inner share)
	 * [10] 	: AF, the access flag (?)
	 * [11] 	: nG, not global bit, 0(the region is available for all process)
	 * -------------------------
	 * [47:16] 	: output address
	 * ---- upper attributes ---
	 * [52] 	: Contiguous, the translation table entry is one of contiguous set or entries.
	 * [53] 	: PXN, used el01
	 * [54] 	: UXN(el01) or XN(el23)
	 * -------------------------
	 */

	/* access permisstions for instruction excution, EL2 and EL3
	 *
	 * XN 	| 	AP[2] 	| 	SCTLR_EL3.WXN 	| 	access
	 *------|-----------|-------------------|-----------------
	 * 0 	| 	0 		| 	0 				| 	excutable
	 * 1 	| 	x 		| 	x 				| 	Not excutable
	 */

	/* Data access permissions
	 * AP[2]
	 * 0 : read/write
	 * 1 : read-only
	 */

	for(i = 0; i < ARRAY_SIZE(map_table); i++)
	{
		ulong index, size, output;

		index 	= map_table[i].virt >> TT_PAGE_SHIFT;
		size 	= map_table[i].size >> TT_PAGE_SHIFT;
		output = map_table[i].phys >> TT_PAGE_SHIFT;

		DEBUG("map_table[%d], : index %d, size %d, output %d\n", i, index, size, output);

		for(j = 0; j < size; j++, index++, output++)
		{
			l3_table[index] = (output << TT_PAGE_SHIFT) + TT_TYPE_PAGE;

			switch(map_table[i].flag & MMU_ATTR_MASK)
			{
#if USE_SMP
			case MMU_ATTR_DATA_CACHE:
					l3_table[index] |= TT_S_NORMAL_CACHE;
					break;
				case MMU_ATTR_DATA_UNCACHE:
					l3_table[index] |= TT_S_NORMAL_UNCACHE;
					break;
				case MMU_ATTR_DEVICE:
					l3_table[index] |= TT_S_DEVICE;
					break;
#else
				case MMU_ATTR_DATA_CACHE:
					l3_table[index] |= TT_NORMAL_CACHE;
					break;
				case MMU_ATTR_DATA_UNCACHE:
					l3_table[index] |= TT_NORMAL_UNCACHE;
					break;
				case MMU_ATTR_DEVICE:
					l3_table[index] |= TT_DEVICE;
					break;
#endif
			}
		}
	}

	mmu_table_inited = 1;

	return 0;
}

#elif ((MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB) || (MMU_GRANULE == USE_GRANULE_4KB_BLOCK_2MB))
/*
 * initialize mmu translation table
 *
 * ex> T0SZ : 31(memory 8GB)
 * |-----------------------|
 * | MMU Level1 Table(64B)|
 * |-----------------------| MMU_L1_TABLE_BASE
 * | MMU Level2 Table(32KB)|
 * |-----------------------| MMU_L2_TABLE_BASE
 * | MMU Level3 Table(16M) |
 * |-----------------------| MMU_L3_TABLE_BASE
 * |	            	   |
 */
static int mmu_set_table(void)
{
	uint32_t 	i,j;
	ulong 	*l1_table = (ulong *)(MMU_L1_TABLE_BASE & ~TT_L1_BASE_ADD_ALIGN);
	ulong 	*l2_table = (ulong *)(MMU_L2_TABLE_BASE & ~TT_L2_BASE_ADD_ALIGN);
#if (MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB)
	ulong 	*l3_table = (ulong *)(MMU_L3_TABLE_BASE & ~TT_L3_BASE_ADD_ALIGN);
#endif

	if(mmu_table_inited) 
		return 0;

	mmu_tt_info();

	if(l1_table != (ulong *)MMU_L1_TABLE_BASE)
	{
		ERROR("error address align MMU_L1_TABLE_BASE\n");
		return -1;
	}

	if(l2_table != (ulong *)MMU_L2_TABLE_BASE)
	{
		ERROR("error address align MMU_L2_TABLE_BASE\n");
		return -1;
	}
	
#if (MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB)
	if(l3_table != (ulong *)MMU_L3_TABLE_BASE)
	{
		ERROR("error address align MMU_L3_TABLE_BASE\n");
		return -1;
	}
#endif

	DEBUG("info mmu table base address l1:%016x, l2:%016x\n"
								,l1_table, l2_table);

	memset(l1_table, 0, MMU_L1_TABLE_SIZE);
	memset(l2_table, 0, MMU_L2_TABLE_SIZE);
#if (MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB)
	memset(l3_table, 0, MMU_L3_TABLE_SIZE);
#endif

	/* Level 0,1,2 Table descriptor
	 *
	 * [0] 		: 1(valid), 0(invalid)
	 * [1]		: 1(table), 0(block)
	 * [47:12] 	: next level table address
	 * [59] 	: PXNTable , used el01
	 * [60] 	: UXNTable(el01) or XNTable(el23)
	 * [62:61] 	: APTable 00(No effect on permissions in subsequent levels of lookup)
	 * [63] 	: NSTable 0(the defined table address is in the secure physical address space)
	 */
	/* setup mmu level1 traslation table */
	for(i = 0; i < TT_L1_ENTRY_NUMBER; i++)
	{
		l1_table[i] = MMU_L2_TABLE_BASE + (i << TT_PAGE_SHIFT) + TT_TYPE_TABLE + TT_VALID;

		DEBUG("l1table[%d] : %016x\n", i, l1_table[i]);
	}

#if (MMU_GRANULE == USE_GRANULE_4KB_BLOCK_2MB)

	/* Level 2 Block descriptor
	 *
	 * ---- lower attributes ---
	 * [0] 		: 1(valid), 0(invalid)
	 * [1]		: 1(table), 0(block)
	 * [4:2] 	: AttrIndx, index attr of mair_elx
	 * [5] 		: NS, Non-secure bit
	 * [7:6] 	: AP, Data Access permissions bits
	 * [9:8] 	: SH, 00(non-share), 01(invalid), 10(outer share), 11(inner share)
	 * [10] 	: AF, the access flag (?)
	 * [11] 	: nG, not global bit, 0(the region is available for all process)
	 * -------------------------
	 * [47:21] 	: output address
	 * ---- upper attributes ---
	 * [52] 	: Contiguous, the translation table entry is one of contiguous set or entries.
	 * [53] 	: PXN, used el01
	 * [54] 	: UXN(el01) or XN(el23)
	 * -------------------------
	 */


	for(i = 0; i < ARRAY_SIZE(map_table); i++)
	{
		ulong index, size, output;

		index 	= map_table[i].virt >> TT_BLOCK_SHIFT;
		size 	= map_table[i].size >> TT_BLOCK_SHIFT;
		output = map_table[i].phys >> TT_BLOCK_SHIFT;

		DEBUG("map_table[%d], : index %d, size %d, output %d\n", i, index, size, output);

		for(j = 0; j < size; j++, index++, output++)
		{
			l2_table[index] = (output << TT_BLOCK_SHIFT) + TT_TYPE_BLOCK + TT_VALID;

			switch(map_table[i].flag & MMU_ATTR_MASK)
			{
#if USE_SMP
			case MMU_ATTR_DATA_CACHE:
					l2_table[index] |= TT_S_NORMAL_CACHE;
					break;
				case MMU_ATTR_DATA_UNCACHE:
					l2_table[index] |= TT_S_NORMAL_UNCACHE;
					break;
				case MMU_ATTR_DEVICE:
					l2_table[index] |= TT_S_DEVICE;
					break;
#else
				case MMU_ATTR_DATA_CACHE:
					l2_table[index] |= TT_NORMAL_CACHE;
					break;
				case MMU_ATTR_DATA_UNCACHE:
					l2_table[index] |= TT_NORMAL_UNCACHE;
					break;
				case MMU_ATTR_DEVICE:
					l2_table[index] |= TT_DEVICE;
					break;
#endif
			}
		}
	}


#elif (MMU_GRANULE == USE_GRANULE_4KB_PAGE_4KB)
	/* setup mmu level2 traslation table */
	for(i = 0; i < TT_L2_ENTRY_NUMBER * TT_L1_ENTRY_NUMBER; i++)
	{
		l2_table[i] = MMU_L3_TABLE_BASE + (i << TT_PAGE_SHIFT) + TT_TYPE_TABLE + TT_VALID;

		DEBUG("l2table[%d] : %016x\n", i, l2_table[i]);
	}

	/* Level 3 Page descriptor
	 *
	 * ---- lower attributes ---
	 * [1:0] 	: 11(page descriptor) , other invalid
	 * [4:2] 	: AttrIndx, index attr of mair_elx
	 * [5] 		: NS, Non-secure bit
	 * [7:6] 	: AP, Data Access permissions bits
	 * [9:8] 	: SH, 00(non-share), 01(invalid), 10(outer share), 11(inner share)
	 * [10] 	: AF, the access flag (?)
	 * [11] 	: nG, not global bit, 0(the region is available for all process)
	 * -------------------------
	 * [47:12] 	: output address
	 * ---- upper attributes ---
	 * [52] 	: Contiguous, the translation table entry is one of contiguous set or entries.
	 * [53] 	: PXN, used el01
	 * [54] 	: UXN(el01) or XN(el23)
	 * -------------------------
	 */

	/* access permisstions for instruction excution, EL2 and EL3
	 *
	 * XN 	| 	AP[2] 	| 	SCTLR_EL3.WXN 	| 	access
	 *------|-----------|-------------------|-----------------
	 * 0 	| 	0 		| 	0 				| 	excutable
	 * 1 	| 	x 		| 	x 				| 	Not excutable
	 */

	/* Data access permissions
	 * AP[2]
	 * 0 : read/write
	 * 1 : read-only
	 */

	for(i = 0; i < ARRAY_SIZE(map_table); i++)
	{
		ulong index, size, output;

		index 	= map_table[i].virt >> TT_PAGE_SHIFT;
		size 	= map_table[i].size >> TT_PAGE_SHIFT;
		output = map_table[i].phys >> TT_PAGE_SHIFT;

		DEBUG("map_table[%d], : index %d, size %d, output %d\n", i, index, size, output);

		for(j = 0; j < size; j++, index++, output++)
		{
			l3_table[index] = (output << TT_PAGE_SHIFT) + TT_TYPE_PAGE;

			switch(map_table[i].flag & MMU_ATTR_MASK)
			{
#if USE_SMP
				case MMU_ATTR_DATA_CACHE:
					l3_table[index] |= TT_S_NORMAL_CACHE;
					break;
				case MMU_ATTR_DATA_UNCACHE:
					l3_table[index] |= TT_S_NORMAL_UNCACHE;
					break;
				case MMU_ATTR_DEVICE:
					l3_table[index] |= TT_S_DEVICE;
					break;
#else
				case MMU_ATTR_DATA_CACHE:
					l3_table[index] |= TT_NORMAL_CACHE;
					break;
				case MMU_ATTR_DATA_UNCACHE:
					l3_table[index] |= TT_NORMAL_UNCACHE;
					break;
				case MMU_ATTR_DEVICE:
					l3_table[index] |= TT_DEVICE;
					break;
#endif
			}
		}
	}
#endif

	mmu_table_inited = 1;

	return 0;
}
#else
#error "do define MMU_GRANULE"
#endif

//#define CHECK_MMU_INIT
#ifdef CHECK_MMU_INIT
#include "timer.h"
#endif
/*
 * initialize mmu to use mmu & cache
 * setup tlb, mmu table & enable mmu, I/D cache
 */
void mmu_init(void)
{
	uint32_t 	sctlr_value;
	ulong 	mair_attr = 0;
	ulong 	tcr = 0;
	ulong 	tcr_ps = 0;

#ifdef CHECK_MMU_INIT
	u32 tick;
	tick = timer_tick();
#endif

	/* set mmu table */
	if(mmu_set_table() != 0)
		return;
	dmb();

	/* mair_el3 */
	mair_attr = MAIR_DEVICE_NGNRNE | (MAIR_DEVICE_NGNRE << 8) 
				| (MAIR_NORMAL_NONCACHED << 16) | (MAIR_NORMAL_CACHED << 24);
	asm volatile ("msr mair_el3, %0" :: "r" (mair_attr) : "memory");

	/* tcr_el3 */
	//to read PARange
	asm volatile ("mrs	%0, id_aa64mmfr0_el1" : "=r" (tcr_ps):: "memory");
	tcr_ps &= 0x07;
	tcr = TCR_EL_T0SZ + TCR_EL_IRGN0 + TCR_EL_ORGN0 + TCR_EL_SH0
			+ TCR_EL_TG0 + TCR_EL_PS(tcr_ps) + TCR_EL_TBI;
	asm volatile ("msr tcr_el3, %0" :: "r" (tcr) : "memory");

	/* setup ttbr0_el3 */
	asm volatile ("msr ttbr0_el3, %0" :: "r" (MMU_TTBR0_BASE) : "memory");
	
	inv_tlb();
	inv_icache();
	inv_dcache();

	sctlr_value = read_sctlr_el3();
	sctlr_value |= SCTLR_EL_M; 		//mmu enable
	sctlr_value &= ~(SCTLR_EL_A); 	//diable alignment check(exception> exclusive, acquire, release)
	sctlr_value |= SCTLR_EL_C; 		//D cache enable
	sctlr_value |= SCTLR_EL_SA; 	//stack alignment check enable
	sctlr_value |= SCTLR_EL_I; 		//I cache enable
	write_sctlr_el3(sctlr_value);

#ifdef CHECK_MMU_INIT
	early_printf("mmu init %dus elapsed\n", timer_elapsed(tick));
#endif
}

void mmu_disable(void)
{
	uint32_t 	sctlr_value;

	//disable & inv I cache
	disable_icache();
	inv_icache();

	//disable & flush D cache
	disable_dcache();
	flush_dcache();

	sctlr_value = read_sctlr_el3();
	sctlr_value &= ~(SCTLR_EL_M); 	//turn off mmu
	sctlr_value |= SCTLR_EL_A; 		//enable alignment check(exception> exclusive, acquire, release)
	write_sctlr_el3(sctlr_value);
}
#endif//#if USE_DATA_CACHE

uint8_t mmu_status(void)
{
	uint32_t 	sctlr_value;
	sctlr_value = read_sctlr_el3();

	if(sctlr_value & SCTLR_EL_M)
		return TRUE;
	else
		return FALSE;
}


#if !defined(FIRST_BOOT)
static int mmfinfo_cmd(int argc, char* argv[])
{
	ulong value;

	asm volatile ("mrs	%0, id_aa64mmfr0_el1" : "=r" (value):: "memory");
	printf("memory model feature info idaa64mmfr0_el1[%016x]\n", value);

	return 0;
}
COMMAND(mmfinfo, mmfinfo_cmd, "display memory model feature info", NULL);
#endif
