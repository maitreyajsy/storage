#include <types.h>
#include <stdio.h>
#include <string.h>
#include <arch/irqs.h>
#include <arch/timers.h>
#include <system.h>
#include <interrupt.h>
#include <timer.h>
#include <thread.h>
#include <command.h>

#ifdef FIRST_BOOT
#define TIMER_INFO(fmt, args...)	do{}while(0)
#else
#define TIMER_INFO(fmt, args...)	printf(fmt, ##args)
#endif

#define USE_64BIT_TIMER		1


static timer_t *timer[2] = {TIMER(0), TIMER(1)};
#if USE_64BIT_TIMER
static timer64_t *timer64[2] = {TIMER64(0), TIMER64(1)};
#else
static u32 last_tick;
#endif

static u32 initial_tick, initial_clock;
static int timer_tick_inited = 0;
static u32 loop_clk_base;
static u32 clk_rate;

#if USE_64BIT_TIMER
uint64_t timer_ltick(void)
{
	volatile u32 low;
	volatile u32 high[2];

	do {
		high[0] = timer64[0]->value_hi;
		low = timer64[0]->value_lo;
		high[1] = timer64[0]->value_hi;
	} while(high[0] != high[1]);

	return ((u64)(0xFFFFFFFF - high[0]) << 32) | (0xFFFFFFFF - low);
}

static u64 timer_clock(void)
{
	/* Synchronize 64bit timer with the 32bit timer by adding initial_tick */
	u64 ticks = timer_ltick() + initial_tick;
	return (ticks/clk_rate);
}
#else
#if USE_TIMER_IRQ
static volatile uint32_t mticks;

static spin_lock_t	timer_spin_lock = INIT_SPIN_LOCK;

#define timer_lock(flags) \
	do{ flags = interrupt_save(); spin_lock(&timer_spin_lock); }while(0)

#define timer_unlock(flags) \
	do{ spin_unlock(&timer_spin_lock); interrupt_restore(flags); }while(0)



static u64 base_clock	= 0;
static u64 base_tick;
static u64 timer_clock(void)
{
	u64 clock;
	u32 flags, tick;

	timer_lock(flags);
	tick = timer_tick();
	clock = base_clock + timer_ticks2usec((uint32_t)(tick - last_tick));
	timer_unlock(flags);

	return clock;
}

static void timer_irq_handler(void *unused)
{
	u32 tick;
	u32 diff_tick;

	spin_lock(&timer_spin_lock);
	mticks += (1000/TIMER_FREQ);

	tick = timer_tick();
	diff_tick = (uint32_t)(tick - last_tick);
	base_clock += timer_ticks2usec(diff_tick);
	base_tick += diff_tick;
	last_tick = tick;

	spin_unlock(&timer_spin_lock);

	timer[0]->intclr = 0x01;		// clear interrupt flag
}

uint64_t timer_ltick(void)
{
	u64 tick64;
	u32 flags, tick;

	timer_lock(flags);
	tick = timer_tick();
	tick64 = base_tick + (uint32_t)(tick - last_tick);
	timer_unlock(flags);

	return tick64;
}
#else
#define timer_lock(flags)	do{(void)flags;}while(0)
#define timer_unlock(flags)	do{(void)flags;}while(0)


static u32 wcount, wremainder;
static u64 wusec;
static u64 timer_clock(void)
{
	u32 tick;

	tick = timer_tick();
	if(tick < last_tick)	/* wrap around */
	{
		u64 wtick;
		wcount++;
		wtick = (u64)wcount << 32;
		wusec = wtick / clk_rate;
		wremainder = wtick % clk_rate;
	}
	last_tick = tick;

	return (wusec +	(tick + wremainder) / clk_rate);
}

uint64_t timer_ltick(void)
{
	return timer_tick();
}
#endif	// #if USE_TIMER_IRQ
#endif	// #if USE_64BIT_TIMER

#define TIMER1_SET_VALUE		(TIMER_CTRL_FREERUN  | TIMER_CTRL_32BIT | TIMER_CTRL_ENABLE)
void early_timer_init(void)
{
	loop_clk_base = get_clk(CLK_DEV_CPU);
	clk_rate = get_clk(CLK_DEV_TIMER)/1000000;

	timer_tick_inited = 1;

#if USE_64BIT_TIMER
#define TIMER64_0_LOAD			(0xFFFFFFFFFFFFFFFFLL)
	timer64[0]->control = TIMER_CTRL_DISABLE;
	timer64[0]->load_hi = ((TIMER64_0_LOAD >> 32) & 0xFFFFFFFF);
	timer64[0]->load_lo = ((TIMER64_0_LOAD >>  0) & 0xFFFFFFFF);
	timer64[0]->control = (TIMER_CTRL_FREERUN  | TIMER_CTRL_32BIT | TIMER_CTRL_ENABLE);
#endif

	/* we will keep the time if the timer already started with same configuration */
	if(timer[1]->control != TIMER1_SET_VALUE)
	{
		// enable timer1 to get high resoultion time
		timer[1]->control = TIMER_CTRL_DISABLE;
		timer[1]->load	= TIMER1_RELOAD;
		timer[1]->control = TIMER1_SET_VALUE;
	}
	else
	{
		initial_tick	= timer_tick();
		initial_clock	= timer_ticks2usec(initial_tick);
#if USE_TIMER_IRQ && !USE_64BIT_TIMER
		last_tick		= initial_tick;
		base_clock		= initial_clock;
#endif
	}

}

u32 timer_initial_clock(void)
{
	return initial_clock;
}

void timer_init(void)
{
#if USE_TIMER_IRQ && !USE_64BIT_TIMER
	mticks = 0;

	// enable timer 0 to increse ms tick
	timer[0]->control	= TIMER_CTRL_DISABLE;
	timer[0]->load 	= TIMER0_RELOAD;
	timer[0]->control = TIMER_CTRL_PERIODIC | TIMER_CTRL_32BIT |
					  TIMER_CTRL_IE | TIMER_CTRL_ENABLE | TIMER0_PRESCALER;

	interrupt_request(IRQ_TIMER0_1, timer_irq_handler, NULL);
	interrupt_active(IRQ_TIMER0_1);
#endif

	TIMER_INFO("Timer Inited\n");

#if !defined(FIRST_BOOT)
	printf("Initial Time : %d.%03dms\n", initial_clock/1000, initial_clock%1000);
	printf("Elapsed Time : ROM[%d.%03dms], 1ST BOOT[%d.%03dms]\n",
		 get_bootrom_elapsed_time()/1000, get_bootrom_elapsed_time()%1000,
		 get_1stboot_elapsed_time()/1000, get_1stboot_elapsed_time()%1000);
#endif

}

void timer_finalize(void)
{
#if USE_TIMER_IRQ && !USE_64BIT_TIMER
	/* kernel bug
	 * sp804 타이머가 irq가 발생가능한 상태로 설정되어 커널로 점프할경우 
	 * sp804 irq handler에서 죽는다. 
	 * irq 등록과 상관없이 sp804 timer 인터럽트 발생 가능 설정에 영향을 받음.
	 */
	timer[0]->control	= TIMER_CTRL_DISABLE;
	timer[0]->intclr = 0x01; // clear interrupt flag
	interrupt_free(IRQ_TIMER0_1);
#endif

	local_timer_finalize();
}


uint64_t timer_usec(void)
{
	return timer_clock();
}

uint32_t timer_msec(void)
{
	u32 msec;
	msec = timer_clock()/1000;
	return msec;
}

uint32_t timer_sec(void)
{
	return timer_msec() / 1000;
}

void mdelay(uint32_t msec)
{
	uint32_t end_msec;
	volatile uint32_t cur_msec;

	if(!timer_tick_inited)
	{
		loop_mdelay(msec);
		return;
	}

	cur_msec = timer_msec();
	end_msec = cur_msec + msec;

	while( 1 )
	{
		cur_msec = timer_msec();
		if( cur_msec >= end_msec ) break;
		loop_udelay(100);	// 100 usec
	}
}

void udelay(uint32_t usec)
{
	volatile uint32_t tmo, ticks;

	if(!timer_tick_inited)
	{
		loop_udelay(usec);
		return;
	}

	ticks = clk_rate * usec;
	tmo = timer[1]->value;

	while((uint32_t)(tmo - timer[1]->value) < ticks);
}

uint32_t timer_tick(void)
{
	if(!timer_tick_inited) return 0;

	return (uint32_t)(TIMER1_RELOAD - timer[1]->value);
}

uint32_t timer_ticks2usec(uint32_t ticks)
{
	return (uint32_t)(ticks/clk_rate);
}

uint64_t timer_lticks2usec(uint64_t lticks)
{
	return (lticks/clk_rate);
}

/* in usec unit */
uint32_t timer_elapsed(uint32_t ticks)
{
	return timer_ticks2usec((uint32_t)(timer_tick() - ticks));
}

void loop_udelay(uint32_t usec)
{
	cpu_loop(loop_clk_base / 1000000 * usec);
}

void loop_mdelay(uint32_t msec)
{
	uint32_t sec = msec/1000;
	uint32_t ms = msec%1000;

	while(sec != 0)
	{
		cpu_loop(loop_clk_base);
		--sec;
	}
	if(ms) cpu_loop(loop_clk_base / 1000 * ms);
}


#if 0 /* generic timer test */

#ifndef COUNTER_MODULE_BASE
#error "CONTER_MODULE_BASE not defined in <arch/arch_config.h>"
#endif

#ifndef SYSTEM_COUNTER_CLK
#error "SYSTEM_COUNTER_CLK not defined in <arch/arch_config.h>"
#endif


#define LOCAL_TIMER_INTERVAL		1000 	/* ms unit */

#define LOCAL_TIMER_LOAD			(LOCAL_TIMER_INTERVAL*(SYSTEM_COUNTER_CLK/1000) - 1)

#define LOCAL_TIMER_ENABLE() 		do{ \
										write_timer_cntp_ctl(1); \
									}while(0)

#define LOCAL_TIMER_DISABLE() 		do{ \
										write_timer_cntp_ctl(0); \
									}while(0)

#define LOCAL_TIMER_FRQ(x) 			do{ \
										write_timer_cntfrq(x); \
									}while(0)

#define LOCAL_TIMER_TIMESET(x) 		do{ \
										write_timer_cntp_tval(x); \
									}while(0)

#define SYSTEM_COUNTER_ENABLE() 	do{ \
										sys_counter->cntcr.bit.en = 1; \
									}while(0)

#define SYSTEM_COUNTER_DISABLE() 	do{ \
										sys_counter->cntcr.bit.en = 0; \
									}while(0)

#define SYSTEM_COUNTER_INIT() 		do{\
										sys_counter->cntfid[0] = SYSTEM_COUNTER_CLK; \
									}while(0)

static system_counter_t *sys_counter = (system_counter_t *)COUNTER_MODULE_BASE;

void generic_timer_irq_handler(void *args)
{
	static int i = 0;

	LOCAL_TIMER_TIMESET(LOCAL_TIMER_LOAD);
	printf("%s entered %d!\n", __func__, i++);
}

static void generic_timer_init(void)
{
	printf("======== generic timer init ==========\n");

	SYSTEM_COUNTER_INIT();
	
	LOCAL_TIMER_DISABLE();
	LOCAL_TIMER_FRQ(SYSTEM_COUNTER_CLK);
	LOCAL_TIMER_TIMESET(LOCAL_TIMER_LOAD);

	interrupt_request(IRQ_LOCALTIMER, generic_timer_irq_handler, (void*)((u64)get_cpu_id()));
	interrupt_active(IRQ_LOCALTIMER);

	LOCAL_TIMER_ENABLE();
	SYSTEM_COUNTER_ENABLE();
}

static int generic_timer_cmd(int argc, char **argv)
{
	generic_timer_init();

	return 0;
}

COMMAND(gtimer, generic_timer_cmd, "test", NULL);
#endif


#if USE_MULTI_THREAD

#ifndef COUNTER_MODULE_BASE
#error "CONTER_MODULE_BASE not defined in <arch/arch_config.h>"
#endif

#ifndef SYSTEM_COUNTER_CLK
#error "SYSTEM_COUNTER_CLK not defined in <arch/arch_config.h>"
#endif

#ifdef THREAD_PREEMPTIVE
/* THREAD_PREEMPTIVE 모드인 경우 scheduler용 timer가 필요하지 않다.
 * 즉 timeout 용으로만 사용하면 되는데 이 경우에는 timeout시점에만
 * 인터럽트가 발생하도록 한다. */
#define SINGLE_LOCAL_TIMER
#endif

#define local_timer_lock(flags) \
	do{ flags = interrupt_save(); }while(0)

#define local_timer_unlock(flags) \
	do{ interrupt_restore(flags); }while(0)


#define LOCAL_TIMER_INTERVAL		1 	/* ms unit */
#define LOCAL_TIMER_LOAD			(LOCAL_TIMER_INTERVAL*(SYSTEM_COUNTER_CLK/1000) - 1)

#define LOCAL_TIMER_ENABLE() 		do{ \
										write_timer_cntp_ctl(1); \
									}while(0)

#define LOCAL_TIMER_DISABLE() 		do{ \
										write_timer_cntp_ctl(0); \
									}while(0)

#define LOCAL_TIMER_FRQ(x) 			do{ \
										write_timer_cntfrq(x); \
									}while(0)

#define LOCAL_TIMER_TIMESET(x) 		do{ \
										write_timer_cntp_tval(x); \
									}while(0)

#define SYSTEM_COUNTER_ENABLE() 	do{ \
										sys_counter->cntcr.bit.en = 1; \
									}while(0)

#define SYSTEM_COUNTER_DISABLE() 	do{ \
										sys_counter->cntcr.bit.en = 0; \
									}while(0)

#define SYSTEM_COUNTER_INIT() 		do{\
										sys_counter->cntfid[0] = SYSTEM_COUNTER_CLK; \
									}while(0)

/*
 *                    LOAD_value + 1
 * Timer Interval = -------------------
 *                  SYSTEM_COUNTER_CLK
 *
 *   LOAD_value = Interval * CLK - 1;
 *
 */

/* Local Timer(PrivateTimer) */
typedef struct local_timer_event
{
	int started;
	u32 timeout;
	u64 expired;
	u32 mode;
	void (*handler)(void*);
	void *arg;
} local_timer_event_t;

typedef void (*timer_handler_t)(void);

static system_counter_t *sys_counter = (system_counter_t *)COUNTER_MODULE_BASE;
static u32 reload_time = 0;

#ifdef SINGLE_LOCAL_TIMER
static local_timer_event_t local_timer_event[CPU_NUM];
#else
static local_timer_event_t local_timer_event[CPU_NUM][LOCAL_TIMER_EVENT_NUM];
#endif

static inline local_timer_event_t* get_local_timer_event(u32 eid)
{
#ifdef SINGLE_LOCAL_TIMER
	return &local_timer_event[get_cpu_id()];
#else
	local_timer_event_t* e = NULL;
	if(eid < LOCAL_TIMER_EVENT_NUM)
		e = (local_timer_event_t*)&local_timer_event[get_cpu_id()][eid];
	return e;
#endif
}

static void local_timer_irq_handler(void *args)
{
	ulong cpu_id = (ulong)args;

#ifdef SINGLE_LOCAL_TIMER
	local_timer_event_t* event = &local_timer_event[cpu_id];

	if(event->mode == LOCAL_TIMER_MODE_ONESHOT)
		LOCAL_TIMER_DISABLE();
	else//auto reload
		LOCAL_TIMER_TIMESET(reload_time);

	if(event->started)
	{
		if(event->mode == LOCAL_TIMER_MODE_ONESHOT)
			event->started = 0;
		else	// REPEAT 모드인 경우 이미 REPEAT 모드로 timer가 시작이 되었다.
			event->expired = timer_usec() + event->timeout;

		event->handler(event->arg);
	}
	else
	{
		printf("^r^local_timer_irq_handler[%d] not started..\n", cpu_id);
	}
#else
	int i;
	volatile u64 usec;
	local_timer_event_t* event = local_timer_event[cpu_id];

	LOCAL_TIMER_TIMESET(reload_time);

	for(i=0; i<LOCAL_TIMER_EVENT_NUM; i++)
	{
		if(event[i].started)
		{
			usec = timer_usec();
			if(event[i].expired < usec)
			{
				if(event[i].mode == LOCAL_TIMER_MODE_ONESHOT)
					event[i].started = 0;
				else
					event[i].expired = usec + event[i].timeout;

				/* handler에서 재 등록이 가능함으로 위의 순서가 중요함 */
				event[i].handler(event[i].arg);
			}
		}
	}
#endif


}

void local_timer_init(void)
{
	SYSTEM_COUNTER_INIT();

	LOCAL_TIMER_DISABLE();
	LOCAL_TIMER_FRQ(SYSTEM_COUNTER_CLK);

#if !defined(SINGLE_LOCAL_TIMER)
	reload_time = LOCAL_TIMER_LOAD;
	LOCAL_TIMER_TIMESET(reload_time);
	LOCAL_TIMER_ENABLE();
#endif

	interrupt_request(IRQ_LOCALTIMER, local_timer_irq_handler, (void*)((u64)get_cpu_id()));
	interrupt_active(IRQ_LOCALTIMER);

	SYSTEM_COUNTER_ENABLE();
}

void local_timer_register(int eid, void (*handler)(void*), void* arg)
{
	local_timer_event_t* e = get_local_timer_event(eid);
	if(e == NULL) return;

	e->started = 0;
	e->handler = handler;
	e->arg = arg;
}

void local_timer_start(int eid, u32 timeout, u32 mode)
{
	u32 flags;
	local_timer_event_t* e = get_local_timer_event(eid);
	if(e == NULL) return;

	local_timer_lock(flags);

	e->timeout = timeout;
	e->mode = mode;
	e->expired = timer_usec() + timeout;
	e->started = 1;

#ifdef SINGLE_LOCAL_TIMER
	if(timeout == 0)
	{
		timeout = 1;
		printf("^r^local_timer_start. timeout is 0\n");
	}

	reload_time = (timeout * (SYSTEM_COUNTER_CLK/1000/1000) - 1);	// timeout : usec unit
	LOCAL_TIMER_TIMESET(reload_time);
	LOCAL_TIMER_ENABLE();

#endif

	local_timer_unlock(flags);
}

void local_timer_stop(int eid)
{
	u32 flags;
	local_timer_event_t* e = get_local_timer_event(eid);
	if(e == NULL) return;

	local_timer_lock(flags);
	e->started = 0;
#ifdef SINGLE_LOCAL_TIMER
	LOCAL_TIMER_DISABLE();
#endif

	local_timer_unlock(flags);
}
#else/* USE_MULTI_THREAD == 1 */

#define SYSTEM_COUNTER_ENABLE() 	do{ \
										sys_counter->cntcr.bit.en = 1; \
									}while(0)

#define SYSTEM_COUNTER_DISABLE() 	do{ \
										sys_counter->cntcr.bit.en = 0; \
									}while(0)

#define SYSTEM_COUNTER_INIT() 		do{\
										sys_counter->cntfid[0] = SYSTEM_COUNTER_CLK; \
									}while(0)

static system_counter_t *sys_counter = (system_counter_t *)COUNTER_MODULE_BASE;

void system_counter_start(void)
{
	SYSTEM_COUNTER_INIT();
	SYSTEM_COUNTER_ENABLE();
}
#endif

void local_timer_finalize(void)
{
#if USE_MULTI_THREAD
	LOCAL_TIMER_DISABLE();
	interrupt_free(IRQ_LOCALTIMER);
#endif
}



#ifndef FIRST_BOOT
static int timer_cmd(int argc, char **argv)
{
	u64 usec = timer_usec();
	printf("Current Time : %d.%06d Sec\n", (u32)(usec/1000000), (u32)(usec%1000000));

	if(argc >= 2)
	{
		if(!strcmp(argv[1], "initial"))
		{
			printf("Initial Time : %dus\n", initial_clock);
		}
		else if(!strcmp(argv[1], "tick"))
		{
			u32 tick = timer_tick();

			printf("Tick:0x%x(%dus)\n", tick, timer_ticks2usec(tick));
		}
		else if(!strcmp(argv[1], "loop"))
		{
			u32 stick, elapsed;

			stick = timer_tick();
			loop_mdelay(1);
			elapsed = timer_elapsed(stick);
			printf("Loop 1ms = %uus\n", elapsed);

			stick = timer_tick();
			loop_mdelay(300);
			elapsed = timer_elapsed(stick);
			printf("Loop 300ms = %ums\n", elapsed/1000);

			stick = timer_tick();
			loop_mdelay(3000);
			elapsed = timer_elapsed(stick);
			printf("Loop 3s = %ums\n", elapsed/1000);
		}
	}

	return 0;
}
COMMAND(time, timer_cmd, "Time", "[initial|tick|loop]");
#if 0
static int timer_test_cmd(int argc, char **argv)
{
	uint64_t ticks = timer_tick();
	uint64_t t64_usec = timer_usec();
	uint64_t sc_tick = SYSTEM_COUNTER_READ();
	uint64_t sc_diff;
	uint64_t t64_diff;
	uint64_t cnt = 0;
	while(1)
	{

		if(timer_elapsed(ticks) > 1000*1000)
		{
			ticks = timer_tick();

			t64_diff = timer_usec() - t64_usec;
			t64_usec = timer_usec();

			sc_diff = SYSTEM_COUNTER_READ() - sc_tick;
			sc_tick = SYSTEM_COUNTER_READ();

			printf("%llds 64: %lld, sc: %lld\n", cnt++, t64_diff, sc_diff);
		}
	}

	return 0;

}
COMMAND(timer_test, timer_test_cmd, "Timer test", "");
#endif
#endif

