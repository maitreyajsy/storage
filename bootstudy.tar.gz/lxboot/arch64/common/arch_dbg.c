#include <string.h>
#include <serial.h>
#include <thread.h>
#include <command.h>

#define excep_print(fmt, args...) 	serial_printf(CONSOLE_UART_PORT, fmt, ##args)

typedef struct
{
	ulong vector_num;
	ulong regs[31];
}excep_regs_t;

struct esr_field
{
	uint32_t	 iss:25;
	uint32_t	 il :1;
	uint32_t	 ec :6;
};

typedef union
{
	uint32_t 			all;
	struct esr_field 	bit;
}esr_t;

struct spsr_field
{
	uint32_t	 m 	:4;
	uint32_t 	 m4 :1;
	uint32_t	 	:1;
	uint32_t	 f 	:1;
	uint32_t	 i 	:1;
	uint32_t	 a 	:1;
	uint32_t	 d 	:1;
	uint32_t	 	:10;
	uint32_t	 il :1;
	uint32_t	 ss :1;
	uint32_t	 	:6;
	uint32_t	 v 	:1;
	uint32_t	 c 	:1;
	uint32_t	 z 	:1;
	uint32_t	 n 	:1;
};

typedef union
{
	uint32_t 			all;
	struct spsr_field 	bit;
}spsr_t;

struct esr_iss_dabort_field
{
	uint32_t 	dfsc 	:6;
	uint32_t 	wnr 	:1;
	uint32_t 	s1ptw 	:1;
	uint32_t 	cm 		:1;
	uint32_t 	ea 		:1;
	uint32_t 	 		:4;
	uint32_t 	ar 		:1;
	uint32_t 	sf 		:1;
	uint32_t 	srt 	:5;
	uint32_t 	sse 	:1;
	uint32_t 	sas 	:2;
	uint32_t 	isv 	:1;
	uint32_t 		    :7;
};

typedef union
{
	uint32_t 			all;
	struct esr_iss_dabort_field bit;
}esr_iss_dabort_t;


static const char *esr_ec_str[0x3D] =
{
	/*0x00*/ "Unknown or uncategorized",
	/*0x01*/ "WFE/WFItraps",
	/*0x02*/ "???", 
	/*0x03*/ "AArch32 CP15 MCR/MRCtraps",
	/*0x04*/ "AArch32 CP15 MCRR/MRRCtraps",
	/*0x05*/ "AArch32 CP14 MCR/MRCtraps",
	/*0x06*/ "AArch32 CP14 LDC/STCtraps",
	/*0x07*/ "Advanced SIMD or FP traps",
	/*0x08*/ "AArch32 MVFR* and FPSID traps",
	/*0x09*/ "???",
	/*0x0A*/ "???",
	/*0x0B*/ "???",
	/*0x0C*/ "AArch32 CP14 MCRR/MRRCtraps",
	/*0x0D*/ "???",
	/*0x0E*/ "Illegal instruction set state",
	/*0x0F*/ "???",
	/*0x10*/ "???",
	/*0x11*/ "AArch32 SVC",
	/*0x12*/ "AArch32 HVC that is not disabled",
	/*0x13*/ "AArch32 SMC that is not disabled",
	/*0x14*/ "???",
	/*0x15*/ "AArch64 SVC",
	/*0x16*/ "AArch64 HVC that is not disabled",
	/*0x17*/ "AArch64 SMC that is not disabled",
	/*0x18*/ "AArch64 MSR, MRSand system instruction traps",
	/*0x19*/ "???",
	/*0x1A*/ "???",
	/*0x1B*/ "???",
	/*0x1C*/ "???",
	/*0x1D*/ "???",
	/*0x1E*/ "???",
	/*0x1F*/ "???",
	/*0x20*/ "Instruction abort from below",
	/*0x21*/ "Instruction abort from current EL",
	/*0x22*/ "PC alignment",
	/*0x23*/ "???",
	/*0x24*/ "Data Abort from below",
	/*0x25*/ "Data Abort from current EL",
	/*0x26*/ "Stack pointer alignment",
	/*0x27*/ "???",
	/*0x28*/ "AArch32 FP exception",
	/*0x29*/ "???",
	/*0x2A*/ "???",
	/*0x2B*/ "???",
	/*0x2C*/ "AArch64 FP exception",
	/*0x2D*/ "???",
	/*0x2E*/ "???",
	/*0x2F*/ "SError interrupt",
	/*0x30*/ "Breakpoint from below",
	/*0x31*/ "Breakpoint from current EL",
	/*0x32*/ "Software step form below",
	/*0x33*/ "Software step from current EL",
	/*0x34*/ "Watchpoint from below",
	/*0x35*/ "Watchpoint from current EL",
	/*0x36*/ "???",
	/*0x37*/ "???",
	/*0x38*/ "AArch32 BKPTinstruction",
	/*0x39*/ "???",
	/*0x3A*/ "AArch32 Vector Catch debug event",
	/*0x3B*/ "???",
	/*0x3C*/ "AArch64 BRKinstruction",
};

static const char *data_fault_code_str[0x12] = 
{
	/*0x00*/ "Address size fault, zeroth(base) level",
	/*0x01*/ "Address size fault, first level",
	/*0x02*/ "Address size fault, second level",
	/*0x03*/ "Address size fault, third level",
	/*0x04*/ "Translation fault, zeroth level",
	/*0x05*/ "Translation fault, first level",
	/*0x06*/ "Translation fault, second level",
	/*0x07*/ "Translation fault, third level",
	/*0x08*/ "???",
	/*0x09*/ "Access flag fault, first level",
	/*0x0A*/ "Access flag fault, second level",
	/*0x0B*/ "Access flag fault, third level",
	/*0x0C*/ "???",
	/*0x0D*/ "Permission fault,first level",
	/*0x0E*/ "Permission fault,second level",
	/*0x0F*/ "Permission fault, third level",
	/*0x10*/ "Synchronous external abort",
	/*0x11*/ "Asynchronous external abort",
};

static const char *spsr_mode_str[0x10] =
{
	/*0x0*/ "EL0t",
	/*0x1*/ "???",
	/*0x2*/ "???",
	/*0x3*/ "???",
	/*0x4*/ "EL1t",
	/*0x5*/ "EL1h",
	/*0x6*/ "???",
	/*0x7*/ "???",
	/*0x8*/ "EL2t",
	/*0x9*/ "EL2h",
	/*0xA*/ "???",
	/*0xB*/ "???",
	/*0xC*/ "EL3t",
	/*0xD*/ "EL3h",
	/*0xE*/ "???",
	/*0xF*/ "???",
};


static const char *arm_reg_str[31] =
{
	"x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8", "x9",
	"x10", "x11", "x12", "x13", "x14", "x15", "x16", "x17", "x18", "x19",
	"x20", "x21", "x22", "x23", "x24", "x25", "x26", "x27", "x28", "x29",
	"lr/x30"
};

static const char *excep_vector_str[0x10] = 
{
	/*0x00*/"Synchronous - Current Exception level with SP_EL0",
	/*0x01*/"IRQ - Current Exception level with SP_EL0",
	/*0x02*/"FIQ - Current Exception level with SP_EL0",
	/*0x03*/"SError - Current Exception level with SP_EL0",

	/*0x04*/"Synchronous - Current Exception level with SP_ELx",
	/*0x05*/"IRQ - Current Exception level with SP_ELx",
	/*0x06*/"FIQ - Current Exception level with SP_ELx",
	/*0x07*/"SError - Current Exception level with SP_ELx",

	/*0x08*/"Synchronous - Lower Exception Level, lower:AArch64",
	/*0x09*/"IRQ - Lower Exception Level, lower:AArch64",
	/*0x0A*/"FIQ - Lower Exception Level, lower:AArch64",
	/*0x0B*/"SError - Lower Exception Level, lower:AArch64",

	/*0x0C*/"Synchronous - Lower Exception Level, lower:AArch32",
	/*0x0D*/"IRQ - Lower Exception Level, lower:AArch32",
	/*0x0E*/"FIQ - Lower Exception Level, lower:AArch32",
	/*0x0F*/"SError - Lower Exception Level, lower:AArch32",
};

/* TODO: extention... */
static spin_lock_t	show_exceptions_lock = INIT_SPIN_LOCK;

void show_exceptions(void *p)
{
	int i;
	ulong 	elr;
	esr_t 	esr;
	spsr_t 	spsr;
	excep_regs_t *excep_regs = (excep_regs_t *)p;

	spin_lock(&show_exceptions_lock);

	asm volatile("mrs %0, elr_el3"  : "=r" (elr)  :: "memory");
	asm volatile("mrs %0, esr_el3"  : "=r" (esr.all)  :: "memory");
	asm volatile("mrs %0, spsr_el3" : "=r" (spsr.all) :: "memory");

	excep_print("CPU[%d], exception vector : ", get_current_cpu());

	if(excep_regs->vector_num > 0x0F)
		excep_print("invalid vector, ??? vector_num : %d\n", excep_regs->vector_num);
	else
		excep_print("%s\n", excep_vector_str[excep_regs->vector_num]);

	if(excep_regs->vector_num == 0x04 ||
			excep_regs->vector_num == 0x07)

	{
		excep_print("======== exception detail ======\n");

		excep_print("%s (0x%x)\n", esr_ec_str[esr.bit.ec], esr.bit.ec);

		if(esr.bit.ec == 0x24 || esr.bit.ec == 0x25)//data abort
		{
			esr_iss_dabort_t esr_iss;
			
			esr_iss.all = esr.bit.iss;

			if(esr_iss.bit.sf)
				excep_print("instruction laod/store 64bit wide\n");
			else
				excep_print("instruction laod/store 32bit wide\n");

			if(esr_iss.bit.ar)
				excep_print("did acquire/release\n");
			else
				excep_print("did not acquire/release\n");

			if(esr_iss.bit.cm)
				excep_print("data fault came from a Cache Maintenance inst\n");

			if(esr_iss.bit.wnr)
				excep_print("abort by a write operation\n");
			else
				excep_print("abort by a read operation\n");

			if(esr_iss.bit.dfsc < 0x12)
				excep_print("%s\n", data_fault_code_str[esr_iss.bit.dfsc]);
			else if(esr_iss.bit.dfsc == 0x21)
				excep_print("Alignment fault\n");
			else if(esr_iss.bit.dfsc == 0x30)
				excep_print("TLB conflict abort\n");
			else if(esr_iss.bit.dfsc == 0x3D)
				excep_print("Section Domain Fault, used only for faults reported in the PAR_EL1\n");
			else if(esr_iss.bit.dfsc == 0x3E)
				excep_print("Page Domain Fault, used only for faults reported in the PAR_EL1\n");
			else
				excep_print("reference ARMv8 Architecture Manual!!\n");
		}
	}
	
	excep_print("======== system register =======\n");
	
	excep_print("elr_el3 	0x%016x\n", elr);
	excep_print("esr_el3 	0x%08x", esr.all);
	excep_print("(EC 0x%x, IL %d, ISS 0x%08x)\n", esr.bit.ec, esr.bit.il, esr.bit.iss);
	excep_print("spsr_el3 	0x%08x", spsr.all);
	excep_print("(N %d, Z %d, C %d, V %d, SS %d, IL %d, D %d, A %d, I %d, F %d, M4 %d, M %s)\n",
			spsr.bit.n, spsr.bit.z, spsr.bit.c, spsr.bit.v, spsr.bit.ss, spsr.bit.il,
			spsr.bit.d, spsr.bit.a, spsr.bit.i, spsr.bit.f, spsr.bit.m4, spsr_mode_str[spsr.bit.m]);
			

	excep_print("========= register map =========\n");
	for(i = 0; i < 31; i++)
	{
		excep_print("%-6s 0x%016x    ", arm_reg_str[i], excep_regs->regs[i]);
		if(!((i+1)%3))
			excep_print("\n");

	}
	excep_print("\n\n");

	spin_unlock(&show_exceptions_lock);


	while(1);

}


#if !defined(FIRST_BOOT)
static int cpuinfo_cmd(int argc, char* argv[])
{
	ulong value;

	asm volatile ("mrs %0, midr_el1" : "=r" (value) :: "memory");

	if(((value >> 24) & 0xff) == 0x41)
		printf("ARM Limited.\n");
	else
		printf("unknown Implementer\n");

	printf("Variant : r%dp%d.\n", (value >> 20) & 0xf, (value >> 0) & 0xf);

	if(((value >> 4) & 0xfff) == 0xd07)
		printf("Cortex-A57 MPcore processor.\n");
	else if(((value >> 4) & 0xfff) == 0xd03)
		printf("Cortex-A53 MPcore processor.\n");
	else
		printf("unknown core\n");

	asm volatile ("mrs %0, revidr_el1" : "=r" (value) :: "memory");

	printf("Revision ID : 0x%x.\n", value);

	return 0;
}
COMMAND(cpuinfo, cpuinfo_cmd, "display information for the processor", NULL);
#endif

