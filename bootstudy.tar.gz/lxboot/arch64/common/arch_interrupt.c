#include <types.h>
#include <arch/irqs.h>
#include <arch/gic.h>
#include <stdio.h>
#include <serial.h>
#include <timer.h>
#include <thread.h>
#include <command.h>

typedef struct
{
	int irq;
	void (*func)(void*);
	void* param;
	u32		count;
} irq_func_t;

#if USE_IRQ
static cpu_interrupt_interface_t *cii	= (cpu_interrupt_interface_t*)GIC_CPU_BASE;
static interrupt_distributor_t *id 		= (interrupt_distributor_t *)GIC_DIST_BASE;

static irq_func_t irq_local_funcs[CPU_NUM][IRQ_GIC_START];
static irq_func_t irq_shared_funcs[NR_IRQS - IRQ_GIC_START];
#endif

int interrupt_enabled(void)
{
	uint32_t daif;
	asm volatile("mrs %0, daif" : "=r" (daif) :: "memory");
	return (daif&DAIF_I) ? 0 : 1;
}

inline __attribute__((always_inline)) void interrupt_enable(void)
{
	/* clear I mask */
	asm volatile("msr daifclr, #2" ::: "memory");
}

inline __attribute__((always_inline)) void interrupt_disable(void)
{
	/* set I mask */
	asm volatile("msr daifset, #2" ::: "memory");
}

inline __attribute__((always_inline)) void serror_enable(void)
{
	/* clear A mask */
	asm volatile("msr daifclr, #4" ::: "memory");
}

inline __attribute__((always_inline)) void serror_disable(void)
{
	/* set A mask */
	asm volatile("msr daifset, #4" ::: "memory");
}

#if USE_IRQ
inline __attribute__((always_inline)) uint32_t interrupt_save(void)
{
	uint32_t daif;
	/* save daif & set I mask */
	asm volatile("mrs %0, daif" : "=r" (daif) :: "memory");
	interrupt_disable();

	return daif;
}

inline __attribute__((always_inline)) void interrupt_restore(uint32_t daif)
{
	/* restore daif */
	asm volatile("msr daif, %0" :: "r" (daif) : "memory");
}

/*
 *************************************************************** 
 * gic400 function 
 ***************************************************************
 */

#if !defined(FIRST_BOOT)
static int gicinfo_cmd(int argc, char* argv[])
{
	uint32_t i;

	i = id->ic_type_reg;
		
	printf("\n=========== gic information ===========\n");
	printf("interrupt controller type register : 0x%08x\n", i);
	
	if((i >> 10) & 0x01)
	{
		printf("-security extensions implemented\n");

		printf("--maximum number of lockable SPIs : %d (0 ~~ %d)\n", ((i>>11) & 0x1f) + 1, ((i>>11) & 0x1f));
	}
	else
		printf("-security extensions not implemented\n");

	printf("-the number of implemented CPU interfaces : %d\n", ((i>>5) & 0x07) + 1);

	printf("-maximum number of interrupts : %d (0 ~~ %d)\n", 32 * ((i & 0x1f) + 1), 32 * ((i & 0x1f) + 1) - 1);

	printf("-distributor Implementer identification register 0x%08x\n", id->dist_ident_reg);

	printf("-cpu interface identification register 0x%08x\n", cii->cpu_ident_reg);

	printf("PERIPHERAL ID : ");
	for(i=0; i<GIC_PERIPHERAL_ID; i++)
		printf("0x%02x ", id->peripheral_id0[i]);
	for(i=0; i<GIC_PERIPHERAL_ID; i++)
		printf("0x%02x ", id->peripheral_id1[i]);
	printf("\n");

	printf("COMPONENT ID : ");
	for(i=0; i<GIC_COMPONENT_ID; i++)
		printf("0x%02x ", id->component_id[i]);
	printf("\n");

	printf("ARM-defined DevID : %s\n", id->peripheral_id0[1] == 0xb4 ? "GICv2" : "GICv1");

	printf("ArchRev field : %s\n", id->peripheral_id0[2] == 0x2b ? "GICv2" : "GICv1");

	return 0;
}
COMMAND(gicinfo, gicinfo_cmd, "display gic info", NULL);
#endif

/* 
 * Enables the forwarding of pending interrupts 
 * from the Distributor to the CPU interfaces
 * bit 0 : Enable Grp0
 * bit 1 : Enable Grp1
 * ex> control = 0x03, enable Grp0 & Grp1
 */

void enable_gic(void)
{
	id->control = 0x00000001;
}

void disable_gic(void)
{
	id->control = 0x00000000;
}

void interrupt_active( uint32_t irq )
{
	uint32_t index;

	index = irq / 32;
	irq %= 32;
	irq = 1 << irq;

	id->enable_set[index] = irq;
}

void interrupt_deactive( uint32_t irq )
{
	uint32_t index;

	index = irq / 32;
	irq %= 32;
	irq = 1 << irq;

	id->enable_clear[index] = irq;
}

#define get_irq_func(n)	((n < IRQ_GIC_START) ? \
		&irq_local_funcs[get_current_cpu()][n] : \
		&irq_shared_funcs[n - IRQ_GIC_START])

int interrupt_handler( void )
{
	int ret = 0;
	irq_func_t *irq_func;

	uint32_t ack;
	int cpu_id, int_id;

#if USE_MULTI_THREAD
	thread_t* current = get_current_thread();
	current->in_interrupt = 1;
#endif

	do
	{
		ack = cii->interrupt_ack;
		cpu_id = (ack&IAR_CPUID_MASK) >> IAR_CPUID_SHIFT;
		int_id = (ack&INTERRUPT_MASK);

		if(int_id == SPURIOUS_INTERRUPT)
			break;

		irq_func = get_irq_func(int_id);

		if(irq_func->func)
		{
			irq_func->func(irq_func->param);
			irq_func->count++;
		}
		//else serial_printf("unregistered irq[%d]\n", irq);

		/* Clear the interrupt */
		cii->end_of_interrupt = ack;
	} while(TRUE);

#if USE_MULTI_THREAD
	current->in_interrupt = 0;
	ret = get_need_schedule();
#endif

	return ret;
}

int interrupt_request(uint32_t irq, void (*func )(void*), void *param)
{
	irq_func_t *irq_func = get_irq_func(irq);
	irq_func->func = func;
	irq_func->param = param;

//	printf("Request IRQ[%d]\n", irq);
	return 0;
}

void interrupt_free( uint32_t irq )
{
	irq_func_t *irq_func = get_irq_func(irq);
	interrupt_deactive(irq);
	irq_func->func = NULL;
}

void interrupt_local_init(void)
{
	int i;

#if 0
	/* Enable the CPU Interface */
	cii->control = 0x00000001;
#else
	/* Initialize cpu interrupt interface ! */

	/* Clear up the bits of the distributor which are actually CPU-specific */
	id->pending_clear[0] = 0xFFFFFFFF;
	for (i = 0; i < 8; i++)
	{
		id->priority[i] = 0x00000000;
}
	id->configuration[0] = 0xAAAAAAAA;
	id->configuration[1] = 0xAAAAAAAA;

	/* Disable the CPU Interface */
	cii->control = 0x00000000;

	/* Allow interrupts with higher priority (i.e. lower number) than 0xF */
	cii->priority_mask = 0x000000F0;

	/* All priority bits are compared for pre-emption */
	cii->binary_point = 0x00000003;

	/* Clear any pending interrupts */
	do
	{
		uint32_t irq = cii->interrupt_ack;

		if ((irq & INTERRUPT_MASK) == SPURIOUS_INTERRUPT)
		{
			break;
		}

		cii->end_of_interrupt = irq;
	} while (TRUE);

	/* Enable the CPU Interface */
	cii->control = 0x00000001;
#endif
}

void interrupt_init( void )
{
	int i;

	/* Initialize the IRQ handler */
#if 0
	for(i=0; i<NR_IRQS; i++)
	{

	}
#endif


	/* Disable the whole controller */
	disable_gic();

	/* Disable all interrupts */
	for (i = 0; i < NO_OF_INTERRUPTS_IMPLEMENTED / 32; i++)
	{
		id->enable_clear[i] = 0xFFFFFFFF;
	}

	/* Clear all interrupts */
	for (i = 1; i < NO_OF_INTERRUPTS_IMPLEMENTED / 32; i++)
	{
		id->pending_clear[i] = 0xFFFFFFFF;
	}

	/* Reset interrupt priorities */
	for (i = 8; i < NO_OF_INTERRUPTS_IMPLEMENTED / 4; i++)
	{
		id->priority[i] = 0x80808080;
	}

	/* Reset interrupt targets */
	for (i = 0; i < NO_OF_INTERRUPTS_IMPLEMENTED / 4; i++)
	{
		id->target[i] = 0x01010101;		/* Each bit refers to CPU1, so we are using CPU1 not CPU0 ? */
	}

	/* Set interrupt configuration (level high sensitive, 1-N) */
	for (i = 2; i < NO_OF_INTERRUPTS_IMPLEMENTED / 16; i++)
	{
		id->configuration[i] = 0x55555555;
	}

	/* Set interrupt group 
	 * 0: Group 0
	 * 1: Group 1
	 */
	for (i = 0; i < NO_OF_INTERRUPTS_IMPLEMENTED / 32; i++)
	{
		id->int_group[i] = 0x00000000;
	}

	/* Finally, enable the interrupt controller */
	enable_gic();


	interrupt_local_init();

//	interrupt_enable();
}

/* Send an IPI to the requesting CPU */
void ipi_send(u32 ipi)
{
	ipi &= IPI_MASK;
	id->software_interrupt = (SELF << IPI_TARGET_FILTER_SHIFT) | ipi;
	dmb();
}

/* Send an IPI to all but the requesting CPU */
void ipi_broadcast(u32 ipi)
{
	ipi &= IPI_MASK;
	id->software_interrupt = (ALL_BUT_SELF << IPI_TARGET_FILTER_SHIFT) | ipi;
	dmb();
}

void ipi_send_target(u32 ipi, u32 target)
{
	ipi &= IPI_MASK;
	target &= 0xFF;

	id->software_interrupt = (USE_TARGET_LIST << IPI_TARGET_FILTER_SHIFT) |
							 (target << IPI_TARGET_SHIFT) |
							 ipi;
	dmb();
}
#else
void interrupt_init( void ){}
void interrupt_local_init(void){}
#endif	// #ifdef USE_IRQ
//EOF
