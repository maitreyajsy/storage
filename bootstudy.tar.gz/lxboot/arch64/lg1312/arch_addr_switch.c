/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/


#if (defined(CONFIG_SHADOW_ROM) && defined(CONFIG_ADDR_SWITCH_SHADOW))
	#if defined(SHADOW_ROM)
		#include <iboot_param.h>
		#define INCLUDE_ADDR_SWITCH_CODES 		1
		#define early_printf 	printf
	#else
		#if USE_2ND_ADDR_SWITCH /* 2nd boot, enable addr_switch */
			#include <stdio.h>
			#include <gpio.h>
			#include <iboot_param.h>
			#define INCLUDE_ADDR_SWITCH_CODES 		1
		#else
			#define INCLUDE_ADDR_SWITCH_CODES 		0
		#endif
	#endif
#else
	#if (defined(CONFIG_BOOT_SINGLE) || defined(FIRST_BOOT)) && \
			((defined(CONFIG_ADDR_SWITCH) || USE_ADDR_SWITCH))
		#include <stdio.h>
		#include <gpio.h>
		#define INCLUDE_ADDR_SWITCH_CODES 		1
	#else
		#define INCLUDE_ADDR_SWITCH_CODES 		0
	#endif
#endif

#if USE_2ND_ADDR_SWITCH && !defined(SHADOW_ROM)
	#define REG_WRITE_IBOOT_SAVE(addr, val) \
					do {\
						REG_WRITE(addr, val); \
						write_iboot_addr_switch_value((uint32_t)((ulong)addr),val);\
					}while(0)
#else
	#define REG_WRITE_IBOOT_SAVE(addr, val) 	REG_WRITE(addr,val)
#endif



#if 0
	/* It will generate address switch CMM for T32. Define USE_EARLY_PRINTF before you use it  */
#define REG_WRITE_ADDRSW(addr, val)	\
		do { \
			early_printf("D.S ASD:0x%08X %%LONG 0x%08X\n", (ulong)addr, (u32)val); \
			REG_WRITE_IBOOT_SAVE(addr, val);	\
		} while(0)
#else
#define REG_WRITE_ADDRSW(addr, val)		REG_WRITE_IBOOT_SAVE(addr, val)
#endif

#define		DDR_SIZE_GPIO		GPIO_MODEL_OPT14
#define		DDR_SIZE_1_5GB		0
#define		DDR_SIZE_2_0GB		1

#define		DDR_SWITCH_MAP_AX	0
#define		DDR_SWITCH_MAP_BX	1

//#define 	USE_BW_BALANCER
//#define 	USE_MPRO_STALL
#define 	USE_MEM_PROTECT
	
//address switch, qos reg cmn base address
#define		QOS_CMN_CPU			0xFD300000
#define		QOS_CMN_LBUS		0xC8820000
#define		QOS_CMN_GBUS		0xC8100000



//memory protect, qos reg btop base address
#define		QOS_CTOP_CPU		0xC8231000
#define		QOS_CTOP_PERI		0xC8232000
#define		QOS_BTOP_GFX_M0		0xC8821000
#define		QOS_BTOP_GFX_M1		0xC8821200
#define		QOS_BTOP_AUD		0xC8821400
#define		QOS_BTOP_ICOD		0xC8821600
#define		QOS_BTOP_TE_M0		0xC8821800
#define		QOS_BTOP_VDEC0_M0	0xC8821A00
#define		QOS_BTOP_VDEC0_M1	0xC8821C00
#define		QOS_BTOP_VDEC1_M0	0xC8821E00
#define		QOS_BTOP_VDEC1_M1	0xC8822000
#define		QOS_BTOP_VDEC2_M0	0xC8822200
#define		QOS_BTOP_VDEC2_M1	0xC8822400
#define		QOS_BTOP_CCO		0xC8822600
#define		QOS_BTOP_FME		0xC8822800
#define		QOS_BTOP_FMC_M0		0xC8822A00
#define		QOS_BTOP_FMC_M1		0xC8822C00
#define		QOS_BTOP_VENC		0xC8822E00
#define		QOS_BTOP_TCON		0xC8823000
#define		QOS_BTOP_CPU_M0		0xC8823200
#define		QOS_BTOP_CPU_M1		0xC8823400
#define		QOS_BTOP_GPU		0xC8101200
#define		QOS_BTOP_GBB		0xC8101400
#define		QOS_BTOP_CVD		0xC8101600
#define		QOS_BTOP_VDM		0xC8101800
#define		QOS_BTOP_SMX0		0xC8101A00
#define		QOS_BTOP_SMX1		0xC8101C00
#define		QOS_BTOP_SUB		0xC8101E00
#define		QOS_BTOP_ND0		0xC8102000
#define		QOS_BTOP_GSC		0xC8102200
#define		QOS_BTOP_VCP		0xC8102400
#define		QOS_BTOP_MCU		0xC8102600

/*
 * macro bandwidth balancer 
 */

/* memory interleaving mode */
#define BWB_MODE_DIS 		0x0 	//diable
#define BWB_MODE_M0_M1 		0x4 	// m0 <-> m1 interleaving

/* memory interleaving unit */
#define BWB_UNIT_8K 		0x0
#define BWB_UNIT_4K 		0x1
#define BWB_UNIT_2K 		0x2
#define BWB_UNIT_1K 		0x3
#define BWB_UNIT_512B		0x4
#define BWB_UNIT_256B 		0x5
#define BWB_UNIT_128B		0x6
#define BWB_UNIT_64B		0x7

/* balacer offset mode */
#define BWB_OFFSET_DIS 		0x0 	//disable offset
#define BWB_OFFSET_M0 		0x4 	//offset for M0 area
#define BWB_OFFSET_M1 		0x5 	//offset for M1 area

#define MAX_ADDR_SWITCH 	16
#define MAX_ADDR_SWITCH_IDX (MAX_ADDR_SWITCH -1)

#define MAX_BWB 			16
#define MAX_BWB_IDX 		(MAX_BWB -1)

#define MAX_MPRO			3
#define MAX_MPRO_IDX		(MAX_MPRO -1)

struct addr_switch
{
	uint16_t  	asw_start;
	uint16_t 	asw_end;
	uint16_t 	asw_offset;
};

struct bw_balancer
{
	uint16_t 	bwb_start;
	uint16_t 	bwb_end;
	uint16_t 	bwb_mode;
	uint16_t 	bwb_unit;
	uint16_t 	bwb_offset;
	uint16_t 	bwb_offset_mode;
};

#ifdef USE_MEM_PROTECT
struct mem_protect
{
	uint32_t 	mpro_start;
	uint32_t 	mpro_end;
};
#endif
	

const ulong asw_base[] = 
{
	QOS_CMN_CPU		+ 0x20,
	QOS_CMN_LBUS	+ 0x80,
	QOS_CMN_GBUS	+ 0x80,
};

const ulong bwb_base[] =
{
	QOS_CMN_CPU		+ 0x1C4,
	QOS_CMN_LBUS	+ 0x100,
	QOS_CMN_GBUS	+ 0x100,
};

#ifdef USE_MEM_PROTECT
const ulong mpro_base[] =
{
	//QOS_CTOP_CPU		+ 0x20,	//cpu access all
	//QOS_CTOP_PERI		+ 0x20,	//cpu access all
	//QOS_BTOP_GFX_M0		+ 0x20,
	//QOS_BTOP_GFX_M1		+ 0x20,
	QOS_BTOP_AUD		+ 0x20,
	QOS_BTOP_ICOD		+ 0x20,
	QOS_BTOP_TE_M0		+ 0x20,
	QOS_BTOP_VDEC0_M0	+ 0x20,
	QOS_BTOP_VDEC0_M1	+ 0x20,
	QOS_BTOP_VDEC1_M0	+ 0x20,
	QOS_BTOP_VDEC1_M1	+ 0x20,
	QOS_BTOP_VDEC2_M0	+ 0x20,
	QOS_BTOP_VDEC2_M1	+ 0x20,
	QOS_BTOP_CCO		+ 0x20,
	QOS_BTOP_FME		+ 0x20,
	QOS_BTOP_FMC_M0		+ 0x20,
	QOS_BTOP_FMC_M1		+ 0x20,
	QOS_BTOP_VENC		+ 0x20,
	QOS_BTOP_TCON		+ 0x20,
	//QOS_BTOP_CPU_M0		+ 0x20,	//cpu -> QOS_CTOP_CPU
	//QOS_BTOP_CPU_M1		+ 0x20, //cpu -> QOS_CTOP_CPU
	//QOS_BTOP_GPU		+ 0x20,
	QOS_BTOP_GBB		+ 0x20,
	//QOS_BTOP_CVD		+ 0x20,
	QOS_BTOP_VDM		+ 0x20,
	QOS_BTOP_SMX0		+ 0x20,
	QOS_BTOP_SMX1		+ 0x20,
	QOS_BTOP_SUB		+ 0x20,
	QOS_BTOP_ND0		+ 0x20,
	QOS_BTOP_GSC		+ 0x20,
	QOS_BTOP_VCP		+ 0x20,
	QOS_BTOP_MCU		+ 0x20,
};
#endif


/////////////////////////////////////////////////////////////////////////
///////////////// M16 Ax DDR SIZE 2GB ///////////////////////////////////
const struct addr_switch Ax_asw_2g[] =
{
#if 0// 1st map
	{ 0x000, 0x0C7, 0x000}, //0x0000_0000 ~ 0X0C7F_FFFF => 0X0000_0000 ~ 0X0C7F_FFFF : 200MB
	{ 0X0C8, 0X3E7, 0X738}, //0X0C80_0000 ~ 0X3E7F_FFFF => 0X8000_0000 ~ 0XB1FF_FFFF : 800MB
	{ 0X3E8, 0X4C7, 0X738}, //0x3E80_0000 ~ 0x4C7F_FFFF => 0xB200_0000 ~ 0xBFFF_FFFF : 224MB
	{ 0x4C8, 0x7FF, 0x000}, //0x4C80_0000 ~ 0x7FFF_FFFF => 0x4C80_0000 ~ 0x7FFF_FFFF : 824MB
#endif

#if 0// 2nd map
	/* kernel 2 size : 794MB
	 * disp driver : 230MB
	 * not modify addr switch 
	 * 20150703
	 */

	{ 0x000, 0x135, 0x000}, //0x0000_0000 ~ 0x135F_FFFF => 0x0000_0000 ~ 0x135F_FFFF : 310MB
	{ 0x136, 0x45F, 0x6CA}, //0x1360_0000 ~ 0x45FF_FFFF => 0x8000_0000 ~ 0xB29F_FFFF : 810MB
	{ 0x460, 0x535, 0x6CA}, //0x4600_0000 ~ 0x535F_FFFF => 0xB2A0_0000 ~ 0xBFFF_FFFF : 214MB
	{ 0x536, 0x7FF, 0x000}, //0x5360_0000 ~ 0x7FFF_FFFF => 0x5360_0000 ~ 0x7FFF_FFFF : 714MB
#endif

#if 0// 3rd map
	{ 0x000, 0x15E, 0x000}, //0x0000_0000 ~ 0x15EF_FFFF => 0x0000_0000 ~ 0x15EF_FFFF :  351MB
	{ 0x15F, 0x55E, 0x6A1}, //0x15F0_0000 ~ 0x55EF_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x55F, 0x7FF, 0x000}, //0x55F0_0000 ~ 0x7FFF_FFFF => 0x55F0_0000 ~ 0x7FFF_FFFF :  673MB
#endif

#if 0// 4th map & 5th map
	{ 0x000, 0x176, 0x000}, //0x0000_0000 ~ 0x176F_FFFF => 0x0000_0000 ~ 0x176F_FFFF :  375MB
	{ 0x177, 0x576, 0x689}, //0x1770_0000 ~ 0x576F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x577, 0x7FF, 0x000}, //0x5770_0000 ~ 0x7FFF_FFFF => 0x5770_0000 ~ 0x7FFF_FFFF :  649MB
#endif

#if 0// 6th map
	{ 0x000, 0x190, 0x000}, //0x0000_0000 ~ 0x190F_FFFF => 0x0000_0000 ~ 0x190F_FFFF :  401MB
	{ 0x191, 0x590, 0x66F}, //0x1910_0000 ~ 0x590F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x591, 0x7FF, 0x000}, //0x5910_0000 ~ 0x7FFF_FFFF => 0x5910_0000 ~ 0x7FFF_FFFF :  623MB
#endif

#if 1// 7th map
	{ 0x000, 0x1A2, 0x000}, //0x0000_0000 ~ 0x1A2F_FFFF => 0x0000_0000 ~ 0x1A2F_FFFF :  419MB
	{ 0x1A3, 0x5A2, 0x65D}, //0x1A30_0000 ~ 0x5A2F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x5A3, 0x7FF, 0x000}, //0x5A30_0000 ~ 0x7FFF_FFFF => 0x5A30_0000 ~ 0x7FFF_FFFF :  605MB
#endif
};


const struct bw_balancer Ax_bwb_2g[] =
{
#if 0// 1st map
	//m0 phy 0x0000_0000 ~ 0x0C7F_FFFF & m1 phy 0x8000 0000 ~ 0x8C7F_FFFF
	{ 0x000, 0x0C7, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 2nd map
	//m0 0x0000_0000 ~ 0x135F_FFFF & m1 0x8000_0000 ~ 0x935F_FFFF
	{ 0x000, 0x135, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 3rd map
	//m0 0x0000_0000 ~ 0x15EF_FFFF & m1 0x8000_0000 ~ 0x95EF_FFFF
	{ 0x000, 0x15E, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 4th map & 5th map
	//m0 0x0000_0000 ~ 0x176F_FFFF & m1 0x8000_0000 ~ 0x976F_FFFF
	{ 0x000, 0x176, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 6th map
	//m0 0x0000_0000 ~ 0x190F_FFFF & m1 0x8000_0000 ~ 0x990F_FFFF
	{ 0x000, 0x190, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 1// 7th map
	//m0 0x0000_0000 ~ 0x1A2F_FFFF & m1 0x8000_0000 ~ 0x9A2F_FFFF
	{ 0x000, 0x1A2, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif
};

/* per 4Kbyte */
const struct mem_protect Ax_mpro_2g[] = 
{
#if 0// 1st map
	{ 0x80000, 0xB1FFF}, //0x8000 0000 ~ 0xB1FF FFFF
	{ 0x00000, 0x4C7FF}, //0x0000 0000 ~ 0x4C7F FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 2nd map
	{ 0x00000, 0x535FF}, //0x0000_0000 ~ 0x535F_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 3rd map
	{ 0x00000, 0x55EFF}, //0x0000_0000 ~ 0x55EF_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 4th map
	{ 0x00000, 0x576FF}, //0x0000_0000 ~ 0x576F_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 5th map
	{ 0x00000, 0x576FF}, //0x0000_0000 ~ 0x576F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 6th map
	{ 0x00000, 0x590FF}, //0x0000_0000 ~ 0x590F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 1// 7th map
	{ 0x00000, 0x5A2FF}, //0x0000_0000 ~ 0x5A2F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif
};

static const int Ax_asw_2g_cnt = ARRAY_SIZE(Ax_asw_2g);
static const int Ax_bwb_2g_cnt = ARRAY_SIZE(Ax_bwb_2g);
static const int Ax_mpro_2g_cnt = ARRAY_SIZE(Ax_mpro_2g);

//////////////////////////////////////////////////////////////////////////
///////////////// M16 Ax DDR SIZE 1.5GB //////////////////////////////////
const struct addr_switch Ax_asw_15g[] =
{
#if 0 //2nd map
	/* kernel 2 size : 282MB
	 * disp driver : 230MB
	 * not modify addr switch
	 * 20150703
	 */
	{ 0x000, 0x153, 0x000}, //0x0000_0000 ~ 0x153F_FFFF => 0x0000_0000 ~ 0x153F_FFFF : 340MB
	{ 0x154, 0x27D, 0x6AC}, //0x1540_0000 ~ 0x27DF_FFFF => 0x8000_0000 ~ 0x929F_FFFF : 298MB
	{ 0x27E, 0x353, 0x6AC}, //0x27E0_0000 ~ 0x353F_FFFF => 0x92A0_0000 ~ 0x9FFF_FFFF : 214MB
	{ 0x354, 0x3FF, 0x200}, //0x3540_0000 ~ 0x3FFF_FFFF => 0x5540_0000 ~ 0x5FFF_FFFF : 172MB
#endif

#if 0 //3rd map
	{ 0x000, 0x17C, 0x000}, //0x0000_0000 ~ 0x17CF_FFFF => 0x0000_0000 ~ 0x17CF_FFFF : 381MB
	{ 0x17D, 0x37C, 0x683}, //0x17D0_0000 ~ 0x37CF_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x37D, 0x3FF, 0x200}, //0x37D0_0000 ~ 0x3FFF_FFFF => 0x57D0_0000 ~ 0x5FFF_FFFF : 131MB
#endif

#if 0 //4th map & 5th map
	{ 0x000, 0x1C5, 0x000}, //0x0000_0000 ~ 0x1C5F_FFFF => 0x0000_0000 ~ 0x1C5F_FFFF : 454MB
	{ 0x1C6, 0x3C5, 0x63A}, //0x1C60_0000 ~ 0x3C5F_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x3C6, 0x3FF, 0x200}, //0x3C60_0000 ~ 0x3FFF_FFFF => 0x5C60_0000 ~ 0x5FFF_FFFF :  58MB
#endif

#if 0 //6th map
	{ 0x000, 0x1D7, 0x000}, //0x0000_0000 ~ 0x1D7F_FFFF => 0x0000_0000 ~ 0x1D7F_FFFF : 472MB
	{ 0x1D8, 0x3D7, 0x628}, //0x1D80_0000 ~ 0x3D7F_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x3D8, 0x4FF, 0x200}, //0x3D80_0000 ~ 0x4FFF_FFFF => 0x5D80_0000 ~ 0x6FFF_FFFF : 296MB
#endif

#if 1 //7th map
	{ 0x000, 0x1E9, 0x000}, //0x0000_0000 ~ 0x1E9F_FFFF => 0x0000_0000 ~ 0x1E9F_FFFF : 490MB
	{ 0x1EA, 0x3E9, 0x616}, //0x1EA0_0000 ~ 0x3E9F_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x3EA, 0x4FF, 0x200}, //0x3EA0_0000 ~ 0x4FFF_FFFF => 0x5EA0_0000 ~ 0x6FFF_FFFF : 278MB
#endif
};


const struct bw_balancer Ax_bwb_15g[] =
{
#if 0 //2nd map
	//m0 phy 0x0000_0000 ~ 0x0FFF_FFFF & m1 phy 0x8000 0000 ~ 0x8FFF_FFFF
	{ 0x000, 0x0FF, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //3rd map
	//m0 phy 0x0000_0000 ~ 0x0FFF_FFFF & m1 phy 0x8000 0000 ~ 0x8FFF_FFFF
	{ 0x000, 0x0FF, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //4th map
	//m0 phy 0x0000_0000 ~ 0x119F_FFFF & m1 phy 0x8000 0000 ~ 0x919F_FFFF
	{ 0x000, 0x119, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //5th map
	//m0 phy 0x0000_0000 ~ 0x0F1F_FFFF & m1 phy 0x8000 0000 ~ 0x8F1F_FFFF
	{ 0x000, 0x0F1, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //6th may
	//m0 phy 0x0000_0000 ~ 0x0F1F_FFFF & m1 phy 0x8000 0000 ~ 0x8F1F_FFFF
	{ 0x000, 0x0F1, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 1 //7th may
	//m0 phy 0x0000_0000 ~ 0x0F1F_FFFF & m1 phy 0x8000 0000 ~ 0x8F1F_FFFF
	{ 0x000, 0x0F1, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

};

/* per 4Kbyte */
const struct mem_protect Ax_mpro_15g[] = 
{
#if 0 //2nd map
	{ 0x00000, 0x553FF}, //0x0000 0000 ~ 0x553F FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //3rd map
	{ 0x00000, 0x57CFF}, //0x0000_0000 ~ 0x57CF_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //4th map
	{ 0x00000, 0x5C5FF}, //0x0000_0000 ~ 0x5C5F_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //5th map
	{ 0x00000, 0x5C5FF}, //0x0000_0000 ~ 0x5C5F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //6th map
	{ 0x00000, 0x5D7FF}, //0x0000_0000 ~ 0x5D7F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 1 //7th map
	{ 0x00000, 0x5E9FF}, //0x0000_0000 ~ 0x5E9F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif
};

static const int Ax_asw_15g_cnt = ARRAY_SIZE(Ax_asw_15g);
static const int Ax_bwb_15g_cnt = ARRAY_SIZE(Ax_bwb_15g);
static const int Ax_mpro_15g_cnt = ARRAY_SIZE(Ax_mpro_15g);


/////////////////////////////////////////////////////////////////////////
///////////////// M16 Bx DDR SIZE 2GB ///////////////////////////////////
const struct addr_switch Bx_asw_2g[] =
{
#if 0// 1st map
	{ 0x000, 0x0C7, 0x000}, //0x0000_0000 ~ 0X0C7F_FFFF => 0X0000_0000 ~ 0X0C7F_FFFF : 200MB
	{ 0X0C8, 0X3E7, 0X738}, //0X0C80_0000 ~ 0X3E7F_FFFF => 0X8000_0000 ~ 0XB1FF_FFFF : 800MB
	{ 0X3E8, 0X4C7, 0X738}, //0x3E80_0000 ~ 0x4C7F_FFFF => 0xB200_0000 ~ 0xBFFF_FFFF : 224MB
	{ 0x4C8, 0x7FF, 0x000}, //0x4C80_0000 ~ 0x7FFF_FFFF => 0x4C80_0000 ~ 0x7FFF_FFFF : 824MB
#endif

#if 0// 2nd map
	/* kernel 2 size : 794MB
	 * disp driver : 230MB
	 * not modify addr switch 
	 * 20150703
	 */

	{ 0x000, 0x135, 0x000}, //0x0000_0000 ~ 0x135F_FFFF => 0x0000_0000 ~ 0x135F_FFFF : 310MB
	{ 0x136, 0x45F, 0x6CA}, //0x1360_0000 ~ 0x45FF_FFFF => 0x8000_0000 ~ 0xB29F_FFFF : 810MB
	{ 0x460, 0x535, 0x6CA}, //0x4600_0000 ~ 0x535F_FFFF => 0xB2A0_0000 ~ 0xBFFF_FFFF : 214MB
	{ 0x536, 0x7FF, 0x000}, //0x5360_0000 ~ 0x7FFF_FFFF => 0x5360_0000 ~ 0x7FFF_FFFF : 714MB
#endif

#if 0// 3rd map
	{ 0x000, 0x15E, 0x000}, //0x0000_0000 ~ 0x15EF_FFFF => 0x0000_0000 ~ 0x15EF_FFFF :  351MB
	{ 0x15F, 0x55E, 0x6A1}, //0x15F0_0000 ~ 0x55EF_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x55F, 0x7FF, 0x000}, //0x55F0_0000 ~ 0x7FFF_FFFF => 0x55F0_0000 ~ 0x7FFF_FFFF :  673MB
#endif

#if 0// 4th map & 5th map
	{ 0x000, 0x176, 0x000}, //0x0000_0000 ~ 0x176F_FFFF => 0x0000_0000 ~ 0x176F_FFFF :  375MB
	{ 0x177, 0x576, 0x689}, //0x1770_0000 ~ 0x576F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x577, 0x7FF, 0x000}, //0x5770_0000 ~ 0x7FFF_FFFF => 0x5770_0000 ~ 0x7FFF_FFFF :  649MB
#endif

#if 0// 6th map
	{ 0x000, 0x190, 0x000}, //0x0000_0000 ~ 0x190F_FFFF => 0x0000_0000 ~ 0x190F_FFFF :  401MB
	{ 0x191, 0x590, 0x66F}, //0x1910_0000 ~ 0x590F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x591, 0x7FF, 0x000}, //0x5910_0000 ~ 0x7FFF_FFFF => 0x5910_0000 ~ 0x7FFF_FFFF :  623MB
#endif

#if 0// 7th map
	{ 0x000, 0x1A2, 0x000}, //0x0000_0000 ~ 0x1A2F_FFFF => 0x0000_0000 ~ 0x1A2F_FFFF :  419MB
	{ 0x1A3, 0x5A2, 0x65D}, //0x1A30_0000 ~ 0x5A2F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x5A3, 0x7FF, 0x000}, //0x5A30_0000 ~ 0x7FFF_FFFF => 0x5A30_0000 ~ 0x7FFF_FFFF :  605MB
#endif

#if 0// 8th map
	{ 0x000, 0x182, 0x000}, //0x0000_0000 ~ 0x182F_FFFF => 0x0000_0000 ~ 0x182F_FFFF :  387MB
	{ 0x183, 0x582, 0x67D}, //0x1830_0000 ~ 0x582F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x583, 0x7FF, 0x000}, //0x5830_0000 ~ 0x7FFF_FFFF => 0x5830_0000 ~ 0x7FFF_FFFF :  637MB
#endif

#if 1// 9th map
	{ 0x000, 0x172, 0x000}, //0x0000_0000 ~ 0x172F_FFFF => 0x0000_0000 ~ 0x172F_FFFF :  371MB
	{ 0x173, 0x572, 0x68D}, //0x1730_0000 ~ 0x572F_FFFF => 0x8000_0000 ~ 0xBFFF_FFFF : 1024MB
	{ 0x573, 0x7FF, 0x000}, //0x5730_0000 ~ 0x7FFF_FFFF => 0x5730_0000 ~ 0x7FFF_FFFF :  653MB
#endif
};


const struct bw_balancer Bx_bwb_2g[] =
{
#if 0// 1st map
	//m0 phy 0x0000_0000 ~ 0x0C7F_FFFF & m1 phy 0x8000 0000 ~ 0x8C7F_FFFF
	{ 0x000, 0x0C7, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 2nd map
	//m0 0x0000_0000 ~ 0x135F_FFFF & m1 0x8000_0000 ~ 0x935F_FFFF
	{ 0x000, 0x135, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 3rd map
	//m0 0x0000_0000 ~ 0x15EF_FFFF & m1 0x8000_0000 ~ 0x95EF_FFFF
	{ 0x000, 0x15E, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 4th map & 5th map
	//m0 0x0000_0000 ~ 0x176F_FFFF & m1 0x8000_0000 ~ 0x976F_FFFF
	{ 0x000, 0x176, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 6th map
	//m0 0x0000_0000 ~ 0x190F_FFFF & m1 0x8000_0000 ~ 0x990F_FFFF
	{ 0x000, 0x190, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 7th map
	//m0 0x0000_0000 ~ 0x1A2F_FFFF & m1 0x8000_0000 ~ 0x9A2F_FFFF
	{ 0x000, 0x1A2, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0// 8th map
	//m0 0x0000_0000 ~ 0x182F_FFFF & m1 0x8000_0000 ~ 0x982F_FFFF
	{ 0x000, 0x182, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 1// 9th map
	//m0 0x0000_0000 ~ 0x172F_FFFF & m1 0x8000_0000 ~ 0x972F_FFFF
	{ 0x000, 0x172, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif
};

/* per 4Kbyte */
const struct mem_protect Bx_mpro_2g[] = 
{
#if 0// 1st map
	{ 0x80000, 0xB1FFF}, //0x8000 0000 ~ 0xB1FF FFFF
	{ 0x00000, 0x4C7FF}, //0x0000 0000 ~ 0x4C7F FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 2nd map
	{ 0x00000, 0x535FF}, //0x0000_0000 ~ 0x535F_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 3rd map
	{ 0x00000, 0x55EFF}, //0x0000_0000 ~ 0x55EF_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 4th map
	{ 0x00000, 0x576FF}, //0x0000_0000 ~ 0x576F_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 5th map
	{ 0x00000, 0x576FF}, //0x0000_0000 ~ 0x576F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 6th map
	{ 0x00000, 0x590FF}, //0x0000_0000 ~ 0x590F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 7th map
	{ 0x00000, 0x5A2FF}, //0x0000_0000 ~ 0x5A2F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0// 8th map
	{ 0x00000, 0x582FF}, //0x0000_0000 ~ 0x582F_FFFF
	{ 0x80000, 0xB17FF}, //0x8000_0000 ~ 0xB17F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 1// 9th map
	{ 0x00000, 0x572FF}, //0x0000_0000 ~ 0x572F_FFFF
	{ 0x80000, 0xB17FF}, //0x8000_0000 ~ 0xB17F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif
};

static const int Bx_asw_2g_cnt = ARRAY_SIZE(Bx_asw_2g);
static const int Bx_bwb_2g_cnt = ARRAY_SIZE(Bx_bwb_2g);
static const int Bx_mpro_2g_cnt = ARRAY_SIZE(Bx_mpro_2g);

//////////////////////////////////////////////////////////////////////////
///////////////// M16 Bx DDR SIZE 1.5GB //////////////////////////////////
const struct addr_switch Bx_asw_15g[] =
{
#if 0 //2nd map
	/* kernel 2 size : 282MB
	 * disp driver : 230MB
	 * not modify addr switch
	 * 20150703
	 */
	{ 0x000, 0x153, 0x000}, //0x0000_0000 ~ 0x153F_FFFF => 0x0000_0000 ~ 0x153F_FFFF : 340MB
	{ 0x154, 0x27D, 0x6AC}, //0x1540_0000 ~ 0x27DF_FFFF => 0x8000_0000 ~ 0x929F_FFFF : 298MB
	{ 0x27E, 0x353, 0x6AC}, //0x27E0_0000 ~ 0x353F_FFFF => 0x92A0_0000 ~ 0x9FFF_FFFF : 214MB
	{ 0x354, 0x3FF, 0x200}, //0x3540_0000 ~ 0x3FFF_FFFF => 0x5540_0000 ~ 0x5FFF_FFFF : 172MB
#endif

#if 0 //3rd map
	{ 0x000, 0x17C, 0x000}, //0x0000_0000 ~ 0x17CF_FFFF => 0x0000_0000 ~ 0x17CF_FFFF : 381MB
	{ 0x17D, 0x37C, 0x683}, //0x17D0_0000 ~ 0x37CF_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x37D, 0x3FF, 0x200}, //0x37D0_0000 ~ 0x3FFF_FFFF => 0x57D0_0000 ~ 0x5FFF_FFFF : 131MB
#endif

#if 0 //4th map & 5th map
	{ 0x000, 0x1C5, 0x000}, //0x0000_0000 ~ 0x1C5F_FFFF => 0x0000_0000 ~ 0x1C5F_FFFF : 454MB
	{ 0x1C6, 0x3C5, 0x63A}, //0x1C60_0000 ~ 0x3C5F_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x3C6, 0x3FF, 0x200}, //0x3C60_0000 ~ 0x3FFF_FFFF => 0x5C60_0000 ~ 0x5FFF_FFFF :  58MB
#endif

#if 0 //6th map
	{ 0x000, 0x1D7, 0x000}, //0x0000_0000 ~ 0x1D7F_FFFF => 0x0000_0000 ~ 0x1D7F_FFFF : 472MB
	{ 0x1D8, 0x3D7, 0x628}, //0x1D80_0000 ~ 0x3D7F_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x3D8, 0x4FF, 0x200}, //0x3D80_0000 ~ 0x4FFF_FFFF => 0x5D80_0000 ~ 0x6FFF_FFFF : 296MB
#endif

#if 0 //7th map
	{ 0x000, 0x1E9, 0x000}, //0x0000_0000 ~ 0x1E9F_FFFF => 0x0000_0000 ~ 0x1E9F_FFFF : 490MB
	{ 0x1EA, 0x3E9, 0x616}, //0x1EA0_0000 ~ 0x3E9F_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x3EA, 0x4FF, 0x200}, //0x3EA0_0000 ~ 0x4FFF_FFFF => 0x5EA0_0000 ~ 0x6FFF_FFFF : 278MB
#endif

#if 1 //8th map
	{ 0x000, 0x1EB, 0x000}, //0x0000_0000 ~ 0x1EBF_FFFF => 0x0000_0000 ~ 0x1EBF_FFFF : 492MB
	{ 0x1EC, 0x3EB, 0x614}, //0x1EC0_0000 ~ 0x3EBF_FFFF => 0x8000_0000 ~ 0x9FFF_FFFF : 512MB
	{ 0x3EC, 0x4FF, 0x200}, //0x3EC0_0000 ~ 0x4FFF_FFFF => 0x5EC0_0000 ~ 0x6FFF_FFFF : 276MB
#endif
};


const struct bw_balancer Bx_bwb_15g[] =
{
#if 0 //2nd map
	//m0 phy 0x0000_0000 ~ 0x0FFF_FFFF & m1 phy 0x8000 0000 ~ 0x8FFF_FFFF
	{ 0x000, 0x0FF, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //3rd map
	//m0 phy 0x0000_0000 ~ 0x0FFF_FFFF & m1 phy 0x8000 0000 ~ 0x8FFF_FFFF
	{ 0x000, 0x0FF, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //4th map
	//m0 phy 0x0000_0000 ~ 0x119F_FFFF & m1 phy 0x8000 0000 ~ 0x919F_FFFF
	{ 0x000, 0x119, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //5th map
	//m0 phy 0x0000_0000 ~ 0x0F1F_FFFF & m1 phy 0x8000 0000 ~ 0x8F1F_FFFF
	{ 0x000, 0x0F1, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //6th may
	//m0 phy 0x0000_0000 ~ 0x0F1F_FFFF & m1 phy 0x8000 0000 ~ 0x8F1F_FFFF
	{ 0x000, 0x0F1, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 0 //7th may
	//m0 phy 0x0000_0000 ~ 0x0F1F_FFFF & m1 phy 0x8000 0000 ~ 0x8F1F_FFFF
	{ 0x000, 0x0F1, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif

#if 1 //8th may
	//m0 phy 0x0000_0000 ~ 0x0FBF_FFFF & m1 phy 0x8000 0000 ~ 0x8FBF_FFFF
	{ 0x000, 0x0FB, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},
#endif
};

/* per 4Kbyte */
const struct mem_protect Bx_mpro_15g[] = 
{
#if 0 //2nd map
	{ 0x00000, 0x553FF}, //0x0000 0000 ~ 0x553F FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //3rd map
	{ 0x00000, 0x57CFF}, //0x0000_0000 ~ 0x57CF_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //4th map
	{ 0x00000, 0x5C5FF}, //0x0000_0000 ~ 0x5C5F_FFFF
	{ 0x80000, 0xB19FF}, //0x8000_0000 ~ 0xB19F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //5th map
	{ 0x00000, 0x5C5FF}, //0x0000_0000 ~ 0x5C5F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //6th map
	{ 0x00000, 0x5D7FF}, //0x0000_0000 ~ 0x5D7F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 0 //7th map
	{ 0x00000, 0x5E9FF}, //0x0000_0000 ~ 0x5E9F_FFFF
	{ 0x80000, 0xAF1FF}, //0x8000_0000 ~ 0xAF1F_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif

#if 1 //8th map
	{ 0x00000, 0x5EBFF}, //0x0000_0000 ~ 0x5EBF_FFFF
	{ 0x80000, 0xAFBFF}, //0x8000_0000 ~ 0xAFBF_FFFF
	{ 0xC0000, 0xFFFFF}, //0xC000 0000 ~ 0xFFFF FFFF
#endif
};

static const int Bx_asw_15g_cnt = ARRAY_SIZE(Bx_asw_15g);
static const int Bx_bwb_15g_cnt = ARRAY_SIZE(Bx_bwb_15g);
static const int Bx_mpro_15g_cnt = ARRAY_SIZE(Bx_mpro_15g);


//////////////////////////////////////////////////////////////////////////////
//////////////// M16 Ax/Bx addr switch table /////////////////////////////////

struct addr_set_table
{
	const struct addr_switch	*asw;
	const struct bw_balancer	*bwb;
	const struct mem_protect	*mpro;

	const int *asw_cnt;
	const int *bwb_cnt;
	const int *mpro_cnt;
};

static const struct addr_set_table table[2][2] = 
{
	{//Ax
		{//Ax - 1.5GB 
			Ax_asw_15g,
			Ax_bwb_15g,
			Ax_mpro_15g,

			&Ax_asw_15g_cnt,
			&Ax_bwb_15g_cnt,
			&Ax_mpro_15g_cnt,
		},

		{//Ax - 2.0GB
			Ax_asw_2g,
			Ax_bwb_2g,
			Ax_mpro_2g,

			&Ax_asw_2g_cnt,
			&Ax_bwb_2g_cnt,
			&Ax_mpro_2g_cnt,
		}
	},

	{//Bx
		{//Bx - 1.5GB 
			Bx_asw_15g,
			Bx_bwb_15g,
			Bx_mpro_15g,

			&Bx_asw_15g_cnt,
			&Bx_bwb_15g_cnt,
			&Bx_mpro_15g_cnt,
		},

		{//Bx - 2.0GB
			Bx_asw_2g,
			Bx_bwb_2g,
			Bx_mpro_2g,

			&Bx_asw_2g_cnt,
			&Bx_bwb_2g_cnt,
			&Bx_mpro_2g_cnt,
		}
	},

};

///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////



#if INCLUDE_ADDR_SWITCH_CODES
static int get_ddr_size_type(void)
{
	gpio_set_direction(DDR_SIZE_GPIO, GPIO_DIR_INPUT);

	if(gpio_get_value(DDR_SIZE_GPIO) == GPIO_LOW)
		return DDR_SIZE_2_0GB;
	else
		return DDR_SIZE_1_5GB;
}

static void *get_addr_table(void)
{
	int ddr_type;
	int chip;

	ddr_type = get_ddr_size_type();

	if(get_chip_rev() < LX_CHIP_REV(M16, B0))
		chip = DDR_SWITCH_MAP_AX;
	else
		chip = DDR_SWITCH_MAP_BX;

	early_printf("[%s][DDR:%s]\n", chip == DDR_SWITCH_MAP_AX ? "Ax": "Bx"
								,ddr_type == DDR_SIZE_1_5GB ? "1.5GB" : "2.0GB");

	return (void*)&(table[chip][ddr_type]);
}

void set_addr_switch(void)
{
	int i,j;
	u32 ctr0;
	u32 ctr1;
	volatile u32 *ctrl_reg;

	struct addr_switch	*p_asw;
	struct bw_balancer	*p_bwb;
	struct mem_protect	*p_mpro;

	struct addr_set_table *p_table;

	int asw_cnt;
	int bwb_cnt;
	int mpro_cnt;

#if USE_2ND_ADDR_SWITCH && !defined(SHADOW_ROM)
	init_iboot_addr_switch();
	//early_printf("init_iboot_addr_switch()\n");
#endif

	//early_printf("do set_addr_switch()\n");

	////////////////////////////////////////////////////////////
	// select addr_switch table
	p_table = (struct addr_set_table *)get_addr_table();

	p_asw = (struct addr_switch *)p_table->asw;
	p_bwb = (struct bw_balancer *)p_table->bwb;
	p_mpro =(struct mem_protect *)p_table->mpro;

	asw_cnt = *(p_table->asw_cnt);
	bwb_cnt = *(p_table->bwb_cnt);
	mpro_cnt = *(p_table->mpro_cnt);

	if(unlikely(asw_cnt > MAX_ADDR_SWITCH))
		early_printf("ERROR. over asw slot \n");
	if(unlikely(bwb_cnt > MAX_BWB))
		early_printf("ERROR. over bwb slot \n");
	if(unlikely(mpro_cnt > MAX_MPRO))
		early_printf("ERROR. over mpro slot \n");
	
	//////////////////////////////////////////////////////

	for(j = 0; j < ARRAY_SIZE(asw_base); j++)
	{
		ctrl_reg = (volatile u32 *)asw_base[j];

		for(i = 0; i < asw_cnt; i++)
		{
			ctr0 = (p_asw[i].asw_start & 0xfff) << 16;
			ctr0 |= (p_asw[i].asw_end & 0xfff);

			ctr1 = (p_asw[i].asw_offset & 0xfff);
			ctr1 |= 1 << 28;// addr_switch enable

			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			//early_printf("D.S ASD:0x%08X %%LONG 0x%08X", ctrl_reg, ctr0);
			//early_printf("\t;0x%03x ~ 0x%03x -> 0x%03x\n" 
			//		, asw[i].asw_start, asw[i].asw_end 
			//		, ((asw[i].asw_start + asw[i].asw_offset)&0xfff));
			ctrl_reg++;

			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			//early_printf("D.S ASD:0x%08X %%LONG 0x%08X\n", ctrl_reg, ctr1);
			ctrl_reg++;

		}
		//early_printf("\n\n");
	}

#ifdef USE_BW_BALANCER

	for(j = 0; j < ARRAY_SIZE(bwb_base); j++)
	{
		ctrl_reg = (volatile u32 *)bwb_base[j];

		for(i = 0; i < bwb_cnt; i++)
		{
			if(j == 0)//CPU BWB REG
			{
				//[30:28] 3 : uint
				//[26:16] 11 : start
				//[14:12] 3 : mode
				//[10:0]  11 : end

				//[30:28] 3 : offset_mode
				//[11:0]  12 : offset
				ctr0 =  (p_bwb[i].bwb_start & 0x7ff) << 16;
				ctr0 |= (p_bwb[i].bwb_end & 0x7ff) << 0;
				ctr0 |= (p_bwb[i].bwb_mode & 0x7) << 12;
				ctr0 |= (p_bwb[i].bwb_unit & 0x7) << 28;

				ctr1 =  (p_bwb[i].bwb_offset & 0xfff) << 0;
				ctr1 |= (p_bwb[i].bwb_offset_mode & 0x7) << 28;
			}
			else//L,G BUS BWB REG
			{
				//[30:28] 3 : mode
				//[26:24] 3 : unit
				//[22:12] 11 : start
				//[10:0]  11 : end

				//[30:28] 3 : offset_mode
				//[11:0]  12 : offset
				ctr0 =  (p_bwb[i].bwb_start & 0x7ff) << 12;
				ctr0 |= (p_bwb[i].bwb_end & 0x7ff) << 0;
				ctr0 |= (p_bwb[i].bwb_mode & 0x7) << 28;
				ctr0 |= (p_bwb[i].bwb_unit & 0x7) << 24;

				ctr1 =  (p_bwb[i].bwb_offset & 0xfff) << 0;
				ctr1 |= (p_bwb[i].bwb_offset_mode & 0x7) << 28;
			}
			
			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			ctrl_reg++;
			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			ctrl_reg++;
		}

	}
#endif

#ifdef USE_MEM_PROTECT

	for(j = 0; j < ARRAY_SIZE(mpro_base); j++)
	{
		ctrl_reg = (volatile u32 *)mpro_base[j];

		for(i = 0; i < mpro_cnt; i++)
		{
			ctr0 = p_mpro[i].mpro_start & 0xfffff;
			ctr0 |= (1<<28); //enable
#ifdef 	USE_MPRO_STALL
			ctr0 |= (1<<24);
#endif
			ctr1 = p_mpro[i].mpro_end & 0xfffff;

			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			ctrl_reg++;
			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			ctrl_reg++;
		}
	}
#endif

}
#else

#ifndef TODO
#define DO_PRAGMA(x) _Pragma (#x)
#define TODO(x) DO_PRAGMA(message ("TODO - " #x))
#endif

TODO (dummy_addr_switch)
void set_addr_switch(void){}
#endif//#if INCLUDE_ADDR_SWITCH_CODES


#if (!defined(SHADOW_ROM)) && (!defined(FIRST_BOOT))
#include <stdio.h>
#include <string.h>
#include <command.h>
#include <env.h>
static int addr_switch_menu(int argc, char **argv)
{
#ifdef USE_MEM_PROTECT
	int i,j;
	u32 ctr0;
	u32 ctr1;
	volatile u32 *ctrl_reg;
	ulong s0_start, s0_end;
	ulong s1_start, s1_end;
	ulong s2_start, s2_end;
	struct mem_protect mpro[3] = {
		{0, 0},
		{0, 0},
		{0, 0},};

	if(argc < 7)
	{
		command_usuage(argv[0]);
		return -1;
	}

    s0_start = strtoul(argv[1], NULL,0);
    s0_end = strtoul(argv[2], NULL,0);
    s1_start = strtoul(argv[3], NULL,0);
    s1_end = strtoul(argv[4], NULL,0);
    s2_start = strtoul(argv[5], NULL,0);
    s2_end = strtoul(argv[6], NULL,0);

	mpro[0].mpro_start 	= s0_start >> 12;
	mpro[0].mpro_end 	= s0_end >> 12;
	mpro[1].mpro_start 	= s1_start >> 12;
	mpro[1].mpro_end 	= s1_end >> 12;
	mpro[2].mpro_start 	= s2_start >> 12;
	mpro[2].mpro_end 	= s2_end >> 12;

	printf( "set "
			"mpro0: 0x%x~0x%x\n"
			"mpro1: 0x%x~0x%x\n"
			"mpro2: 0x%x~0x%x\n(unit : 4k)\n"
												 , mpro[0].mpro_start
												 , mpro[0].mpro_end
												 , mpro[1].mpro_start
												 , mpro[1].mpro_end
												 , mpro[2].mpro_start
												 , mpro[2].mpro_end);

	for(j = 0; j < ARRAY_SIZE(mpro_base); j++)
	{
		ctrl_reg = (volatile u32 *)mpro_base[j];

		for(i = 0; i < 3; i++)
		{
			ctr0 = mpro[i].mpro_start & 0xfffff;
			ctr0 |= (1<<28); //enable
#ifdef 	USE_MPRO_STALL
			ctr0 |= (1<<24);
#endif
			ctr1 = mpro[i].mpro_end & 0xfffff;

			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			ctrl_reg++;
			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			ctrl_reg++;
		}
	}

#else
	printf("not support this command!\n");
#endif

	return 0;
}
COMMAND(adswitch, addr_switch_menu, "setup addr switch range"
			, "slot0_start_add slot0_end_add slot1_start_add slot1_end_add"
												" slot2_start_add slot2_end_add\n"
			"ex> adswitch 0x0 0x6DFFFFFF 0x80000000 0x9FFFFFFF 0x0 0x0");
#endif
