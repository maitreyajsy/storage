#include <types.h>
#include <string.h>
#include <arch/cpu.h>
#include <arch/ctop_regs.h>
#include <command.h>
#include <gpio.h>

//#define DBG
#include <debug.h>

#define GPIO_MAX_NUM			144 	//GPIO0 ~ GPIO143, total 144
#define GPIO_SHARED_PIN_START	32 		//GPIO32

#define GPIO_BASE(p)			((ulong)(LG1312_GPIO0_BASE + (((p)/8) * 0x10000)))

#define READ_GPIO_DIR(p)		IO_READ(GPIO_BASE(p) + 0x400)
#define WRITE_GPIO_DIR(p,v)		IO_WRITE(GPIO_BASE(p) + 0x400, v)

#define READ_GPIO_DATA(p)		IO_READ(GPIO_BASE(p) + 0x3FC)
#define WRITE_GPIO_DATA(p,m,v)	IO_WRITE(GPIO_BASE(p) + m, v)


#if defined(CONFIG_BOARD_TYPE_FPGA)
int gpio_set_top(uint32_t port){ return 0;}
#else
int gpio_set_top(uint32_t port)
{
	return gpio_set_pin_mux(port, 1);
}
#endif


#define SET_CTOP_GPIO_MUX(x, y, op) do{\
					value = CTOP_CTRL_READ(x, y); \
					bit = op; \
					mask = 1 << bit; \
					value = enable ? (value | mask) : (value & (~mask)); \
					CTOP_CTRL_WRITE(x, y, value); \
					}while(0)

TODO(implement gpio mux)
int gpio_set_pin_mux(u32 port, int enable)
{
	uint32_t value = 0;
	uint32_t mask = 0;
	uint32_t bit = 0;

	if(port < GPIO_SHARED_PIN_START)
	{
		DEBUG("port %03d, static gpio\n", port);
		return 0;
	}
	else if(port <= 39)//32 ~ 39
	{
		/*	bit	: 31......24
			io	: 39......32 */
		SET_CTOP_GPIO_MUX(DPE, ctop_r25, 24+(port-32));
	}
	else if(port <= 43)//40 ~ 43 : none
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 47)//44 ~ 47
	{
		/* 	bit	: 31..28
			io 	: 47..44 */
		value = CTOP_CTRL_READ(DEMOD, ctop_r03);
		bit = 28 + (port - 44);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(DEMOD, ctop_r03, value);

		//SET_CTOP_GPIO_MUX(DEMOD, ctop_r03, 28+(port-44));
	}
	else if(port <= 53)//48 ~ 53
	{
		// 18....13
		// 53....48
		value = CTOP_CTRL_READ(DEMOD, ctop_r03);
		bit = 13 + (port - 48);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(DEMOD, ctop_r03, value);

		//SET_CTOP_GPIO_MUX(DEMOD, ctop_r03, 13+(port-48));
	}
	else if(port <= 55)//54, 55 none
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 63)//56 ~ 63
	{
		//31......24
		//63......56
		value = CTOP_CTRL_READ(FMC, ctop_r05);
		bit = 24 + (port - 56);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(FMC, ctop_r05, value);

		//SET_CTOP_GPIO_MUX(FMC, ctop_r05, 24+(port-56));
	}
	else if(port <= 67)//64 ~ 67 none
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 71)//68 ~ 71
	{
		//23..20
		//71..68
		value = CTOP_CTRL_READ(FMC, ctop_r05);
		bit = 20 + (port - 68);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(FMC, ctop_r05, value);

		//SET_CTOP_GPIO_MUX(FMC, ctop_r05, 20+(port-68));
	}
	else if(port <= 79)//72 ~ 79
	{
		value = CTOP_CTRL_READ(DPE, ctop_r25);
		switch(port)
		{
			case 72:
			case 73:
				bit = 15 + (port - 72);
				break;
			case 74:
				bit = 7 + (port - 74);
				break;
			case 75:
				bit = 11 + (port - 75);
				break;
			case 76:
			case 77:
				bit = 17 + (port - 76);
				break;
			case 78:
				bit = 8 + (port - 78);
				break;
			case 79:
				bit = 12 + (port - 79);
				break;
		}
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(DPE, ctop_r25, value);
	}
	else if(port <= 87)//80 ~ 87
	{
		if(port == 80)
		{
			value = CTOP_CTRL_READ(FMC, ctop_r05);
			bit = 12 + (port - 80);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(FMC, ctop_r05, value);

			//SET_CTOP_GPIO_MUX(FMC, ctop_r05, 12+(port-80));
		}
		else if(port <= 84)//81 ~ 84
		{
			value = CTOP_CTRL_READ(FMC, ctop_r11);
			bit = 12 + (84 - port);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(FMC, ctop_r11, value);

			//SET_CTOP_GPIO_MUX(FMC, ctop_r11, 12+(84-port));
		}
		else//85 ~ 87
		{
			value = CTOP_CTRL_READ(FMC, ctop_r05);
			bit = 13 + (port - 85);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(FMC, ctop_r05, value);

			//SET_CTOP_GPIO_MUX(FMC, ctop_r05, 13+(port-85));
		}
	}
	else if(port <= 93)//88 ~ 93
	{
		if(port <= 89)//88, 89
		{
			value = CTOP_CTRL_READ(AUD, ctop_r07);
			bit = 30 + (port - 88);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(AUD, ctop_r07, value);

			//SET_CTOP_GPIO_MUX(AUD, ctop_r07, 30+(port-88));
		}
		else//90 ~ 93
		{
			value = CTOP_CTRL_READ(TE, ctop_r06);
			bit = 22 + (93 - port);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(TE, ctop_r06, value);

			//SET_CTOP_GPIO_MUX(TE, ctop_r06, 22+(93-port));
		}
	}
	else if(port <= 95)//94, 95
	{
		//used gpio
	}
	else if(port <= 103)//96 ~ 103
	{
		value = CTOP_CTRL_READ(DEMOD, ctop_r03);
		bit = 20 + (port - 96);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(DEMOD, ctop_r03, value);

		//SET_CTOP_GPIO_MUX(DEMOD, ctop_r03, 20+(port-96));
	}
	else if(port <= 104)//104
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 110)//105 ~ 110
	{
		value = CTOP_CTRL_READ(DPE, ctop_r25);
		bit = 0 + (port - 105);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(DPE, ctop_r25, value);

		//SET_CTOP_GPIO_MUX(DPE, ctop_r25, 0+(port-105));
	}
	else if(port <= 111)
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 119)//112 ~ 119
	{
		value = CTOP_CTRL_READ(AUD, ctop_r07);
		bit = 22 + (port - 112);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(AUD, ctop_r07, value);

		//SET_CTOP_GPIO_MUX(AUD, ctop_r07, 22+(port-112));
	}
	else if(port <= 127)//120 ~ 127
	{
		value = CTOP_CTRL_READ(AUD, ctop_r07);
		bit = 14 + (port - 120);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(AUD, ctop_r07, value);

		//SET_CTOP_GPIO_MUX(AUD, ctop_r07, 14+(port-120));
	}
	else if(port <= 135)//128 ~ 135
	{
		value = CTOP_CTRL_READ(AUD, ctop_r07);
		bit = 6 + (port - 128);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(AUD, ctop_r07, value);

		//SET_CTOP_GPIO_MUX(AUD, ctop_r07, 6+(port-128));
	}
	else if(port <= 143)//136 ~ 143
	{
		value = CTOP_CTRL_READ(DPE, ctop_r25);
		switch(port)
		{
			case 136:
				bit = 9 + (port - 136);
				break;
			case 137:
				bit = 13 + (port - 137);
				break;
			case 138:
				bit = 10 + (port - 138);
				break;
			case 139:
				bit = 14 + (port - 139);
				break;
			case 140:
				bit = 19 + (port - 140);
				break;
			case 141:
			case 142:
			case 143:
				bit = 21 + (port - 141);
				break;
		}
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(DPE, ctop_r25, value);
	}
	else
	{
		DEBUG("not exist pin\n");
		return -1;
	}

	DEBUG("port %03d, bit %02d, mask %08x\n", port, bit, mask);

	return 0;
}

#define GET_CTOP_GPIO_MUX(x, y, op) do{\
					value = CTOP_CTRL_READ(x, y); \
					bit = op; \
					mask = 1 << bit; \
					}while(0)

int gpio_get_pin_mux(u32 port)
{
	uint32_t value = 0;
	uint32_t mask = 0;
	uint32_t bit = 0;

	if(port < GPIO_SHARED_PIN_START)
	{
		DEBUG("port %03d, static gpio\n", port);
		return 1;
	}
	else if(port <= 39)//32 ~ 39
	{
		/*	bit	: 31......24
			io	: 39......32 */
		GET_CTOP_GPIO_MUX(DPE, ctop_r25, 24+(port-32));
	}
	else if(port <= 43)//40 ~ 43 : none
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 47)//44 ~ 47
	{
		/* 	bit	: 31..28
			io 	: 47..44 */
		GET_CTOP_GPIO_MUX(DEMOD, ctop_r03, 28+(port-44));
	}
	else if(port <= 53)//48 ~ 53
	{
		// 18....13
		// 53....48
		GET_CTOP_GPIO_MUX(DEMOD, ctop_r03, 13+(port-48));
	}
	else if(port <= 55)//54, 55 none
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 63)//56 ~ 63
	{
		//31......24
		//63......56
		GET_CTOP_GPIO_MUX(FMC, ctop_r05, 24+(port-56));
	}
	else if(port <= 67)//64 ~ 67 none
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 71)//68 ~ 71
	{
		//23..20
		//71..68
		GET_CTOP_GPIO_MUX(FMC, ctop_r05, 20+(port-68));
	}
	else if(port <= 79)//72 ~ 79
	{
		value = CTOP_CTRL_READ(DPE, ctop_r25);
		switch(port)
		{
			case 72:
			case 73:
				bit = 15 + (port - 72);
				break;
			case 74:
				bit = 7 + (port - 74);
				break;
			case 75:
				bit = 11 + (port - 75);
				break;
			case 76:
			case 77:
				bit = 17 + (port - 76);
				break;
			case 78:
				bit = 8 + (port - 78);
				break;
			case 79:
				bit = 12 + (port - 79);
				break;
		}
		mask = 1 << bit;
	}
	else if(port <= 87)//80 ~ 87
	{
		if(port == 80)
		{
			GET_CTOP_GPIO_MUX(FMC, ctop_r05, 12+(port-80));
		}
		else if(port <= 84)//81 ~ 84
		{
			GET_CTOP_GPIO_MUX(FMC, ctop_r11, 12+(84-port));
		}
		else//85 ~ 87
		{
			GET_CTOP_GPIO_MUX(FMC, ctop_r05, 13+(port-85));
		}
	}
	else if(port <= 93)//88 ~ 93
	{
		if(port <= 89)//88, 89
		{
			GET_CTOP_GPIO_MUX(AUD, ctop_r07, 30+(port-88));
		}
		else//90 ~ 93
		{
			GET_CTOP_GPIO_MUX(TE, ctop_r06, 22+(93-port));
		}
	}
	else if(port <= 95)//94, 95
	{
		//used gpio
	}
	else if(port <= 103)//96 ~ 103
	{
		GET_CTOP_GPIO_MUX(DEMOD, ctop_r03, 20+(port-96));
	}
	else if(port <= 104)//104
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 110)//105 ~ 110
	{
		GET_CTOP_GPIO_MUX(DPE, ctop_r25, 0+(port-105));
	}
	else if(port <= 111)
	{
		ERROR("none gpio %d\n", port);
		return -1;
	}
	else if(port <= 119)//112 ~ 119
	{
		GET_CTOP_GPIO_MUX(AUD, ctop_r07, 22+(port-112));
	}
	else if(port <= 127)//120 ~ 127
	{
		GET_CTOP_GPIO_MUX(AUD, ctop_r07, 14+(port-120));
	}
	else if(port <= 135)//128 ~ 135
	{
		GET_CTOP_GPIO_MUX(AUD, ctop_r07, 6+(port-128));
	}
	else if(port <= 143)//136 ~ 143
	{
		value = CTOP_CTRL_READ(DPE, ctop_r25);
		switch(port)
		{
			case 136:
				bit = 9 + (port - 136);
				break;
			case 137:
				bit = 13 + (port - 137);
				break;
			case 138:
				bit = 10 + (port - 138);
				break;
			case 139:
				bit = 14 + (port - 139);
				break;
			case 140:
				bit = 19 + (port - 140);
				break;
			case 141:
			case 142:
			case 143:
				bit = 21 + (port - 141);
				break;
		}
		mask = 1 << bit;
	}
	else
	{
		DEBUG("not exist pin\n");
		return -1;
	}

	DEBUG("port %03d, bit %02d, mask %08x\n", port, bit, mask);

	return (value & mask) ? 1 : 0;
}

int gpio_set_direction(uint32_t port, int dir)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		value = (dir == GPIO_DIR_OUTPUT) ? (value | mask) : (value & ~mask);
		WRITE_GPIO_DIR(port, value);

		return 0;
	}
	return -1;
}

int gpio_get_direction(uint32_t port)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		return (value & mask) ? GPIO_DIR_OUTPUT : GPIO_DIR_INPUT;
	}
	return -1;
}

int gpio_set_value(uint32_t port, int value)
{
	uint32_t mask;

	if(port < GPIO_MAX_NUM)
	{
		mask = 1 << (2 + (port%8));
		value = (value == GPIO_HIGH) ? 0xFF : 0;
		WRITE_GPIO_DATA(port, mask, value);
		return 0;
	}
	return -1;
}

int gpio_get_value(uint32_t port)
{
	uint32_t value;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DATA(port);
		value = (value >> (port%8)) & 0x01;

		return (value == 1) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}

TODO(m16 ace gpio)
/* ---------- m16a gpio ----------- */
static int gpio_ex_dir[2] = {-1, -1};

static void gpio_ex_init(void)
{
	static int inited = 0;

	if(inited) return;
	inited = 1;

	/* Set Interrupt Sense to get the value */
	ace_reg_write(0x28, 0x12, 0xFF);
	ace_reg_write(0x28, 0x13, 0xFF);

	/*
	(3) GPIO_IEV 가 1일면 input level인 '1' 인 경우 High, '0'이면 Low
	(4) GPIO_IEV 가 0일면 input level인 '0' 인 경우 High, '1'이면 Low
	*/
	ace_reg_write(0x28, 0x16, 0xFF);
	ace_reg_write(0x28, 0x17, 0xFF);
}

int gpio_ex_set_direction(uint32_t port, int dir)
{
	gpio_ex_init();
	if(port < 16)
	{
		int block = port/8;
		uint8_t addr, mask, value;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x10 : 0x11;

		if(gpio_ex_dir[block] == -1)
		{
			ace_reg_read(0x28, addr, &value);
			gpio_ex_dir[block] = value;
		}

		value = (dir == GPIO_DIR_INPUT) ? gpio_ex_dir[block] & (~mask) : gpio_ex_dir[block] | mask;

		if(gpio_ex_dir[block] != value)
		{
			ace_reg_write(0x28, addr, value);
			gpio_ex_dir[block] = value;
		}
		return 0;
	}
	return -1;
}

int gpio_ex_get_direction(uint32_t port)
{
	gpio_ex_init();
	if(port < 16)
	{
		int block = port/8;
		uint8_t addr, value, mask;

		mask = 1 << (port % 8);
		if(gpio_ex_dir[block] == -1)
		{
			addr = (port < 8) ? 0x10 : 0x11;
			ace_reg_read(0x28, addr, &value);
			gpio_ex_dir[block] = value;
		}

		DEBUG("DIR:0x%02x\n", gpio_ex_dir[block]);
		return (gpio_ex_dir[block] & mask) ? GPIO_DIR_OUTPUT : GPIO_DIR_INPUT;
	}
	return -1;
}

int gpio_ex_set_value(uint32_t port, int value)
{
	gpio_ex_init();
	if(port < 16)
	{
		uint8_t data, mask;
		uint8_t addr;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x00 : 0x01;

		ace_reg_read(0x28, addr, &data);
		data = (value == GPIO_LOW) ? data & (~mask) : data | mask;
		DEBUG("DATA:0x%02x\n", data);
		ace_reg_write(0x28, addr, data);
		return 0;
	}
	return -1;
}

int gpio_ex_get_value(uint32_t port)
{
	gpio_ex_init();
	if(port < 16)
	{
		uint8_t data, mask;
		uint8_t addr;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x1e : 0x1f;

		ace_reg_read(0x28, addr, &data);
		DEBUG("DATA:0x%02x\n", data);
		return (data & mask) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}

/* For Performance Improvement */
int gpio_ex_get_static_value(uint32_t port)
{
	static int value[2] = {-1, -1};

	gpio_ex_init();
	if(port < 16)
	{
		uint8_t mask = 1 << (port % 8);
		int block = port/8;

		if(value[block] == -1)
		{
			uint8_t data, addr;
			addr = (port < 8) ? 0x1e : 0x1f;
			ace_reg_read(0x28, addr, &data);
			value[block] = data;
		}

		return (value[block] & mask) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}



#if !defined(FIRST_BOOT)
/*********************************
 * GPIO TEST CODE START
 *********************************/
static void print_gpio_pin_mux(int value)
{
	printf("Direction : %s\n", (value == GPIO_DIR_INPUT) ? "INPUT" :
						(value == GPIO_DIR_OUTPUT) ? "OUTPUT" : "XXX");
}

static void print_gpio_direction(int value)
{
	printf("Direction : %s\n", (value == GPIO_DIR_INPUT) ? "INPUT" :
						(value == GPIO_DIR_OUTPUT) ? "OUTPUT" : "XXX");
}

static void print_gpio_value(int value)
{
	printf("Data : %s\n", (value == GPIO_LOW) ? "LOW" :
						(value == GPIO_HIGH) ? "HIGH" : "XXX");
}

static int input_gpio_pin_mux(void)
{
	int c;

	while(1)
	{
		printf("Input pin mux - normal(0), gpio(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? 0 : 1;
}

static int input_gpio_direction(void)
{
	int c;

	while(1)
	{
		printf("Input direction - input(0), output(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? GPIO_DIR_INPUT : GPIO_DIR_OUTPUT;
}

static int input_gpio_value(void)
{
	int c;

	while(1)
	{
		printf("Input value - Low(0), High(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? GPIO_LOW : GPIO_HIGH;
}

static int gpio_cmd(int argc, char **argv)
{
	char name[32];
	int len, port;
	char c;

	do{
		printf("###### GPIO Test #######\n");
		printf("========================\n");
		printf(" 1. SetPinMux\n");
		printf(" 2. GetPinMux\n");
		printf(" 3. SetDirection\n");
		printf(" 4. GetDirection\n");
		printf(" 5. SetValue\n");
		printf(" 6. GetValue\n");
		printf("========================\n");
		printf(" A. ExSetDirection\n");
		printf(" S. ExGetDirection\n");
		printf(" D. ExSetValue\n");
		printf(" F. ExGetValue\n");
		printf("========================\n");
		printf(" X. Exit\n");
		while(1)
		{
			printf("Select : ");
			c = getchar();
			if(isalnum(c))
				break;
			printf("\n");
		}

		printf("%c\n", isprint((int)c) ? c : ' ');

		if(toupper(c) == 'X')
			break;

		while(1)
		{
			printf("Input pin number : ");
			len = gets(name);
			printf("\n");
			if(len > 0) break;
		}
		port = strtoul(name, NULL, 10);

		switch(toupper(c))
		{
			case '1': gpio_set_pin_mux(port, input_gpio_pin_mux()); break;
			case '2': print_gpio_pin_mux(gpio_get_pin_mux(port)); break;
			case '3': gpio_set_direction(port, input_gpio_direction()); break;
			case '4': print_gpio_direction(gpio_get_direction(port)); break;
			case '5': gpio_set_value(port, input_gpio_value()); break;
			case '6': print_gpio_value(gpio_get_value(port)); break;

			case 'A': gpio_ex_set_direction(port, input_gpio_direction()); break;
			case 'S': print_gpio_direction(gpio_ex_get_direction(port)); break;
			case 'D': gpio_ex_set_value(port, input_gpio_value()); break;
			case 'F': print_gpio_value(gpio_ex_get_value(port)); break;

			default: printf("unknown \n");
		}
	}while(1);
	return 0;
}

COMMAND(gpio, gpio_cmd, "GPIO Test", NULL);
#endif	/* if !defined(FIRST_BOOT) */
