/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
/*----------------------------------------------------------------------------------------
  Control Constants
  ----------------------------------------------------------------------------------------*/
#define	USE_GFX_SWL						/* use SW renderer */
#undef  USE_GFX_FILL_DELAYED			/* GFX fillrect is delayed to blit function */
#undef   USE_GFX_TEST_PATTERN
#define GFXOSD_PRINT(fmt,args...)		// printf(fmt,##args)

/*----------------------------------------------------------------------------------------
  File Inclusions
  ----------------------------------------------------------------------------------------*/
#if USE_BOOT_LOGO
#include <types.h>
#include <stdio.h>
#include <string.h>
#include <command.h>
#include <partinfo.h>
#include <storage.h>
#include <util.h>
#include <timer.h>
#include <image.h>
#include <logo.h>
#include <decompress.h>
#include <malloc.h>
#include <thread.h>
#include <display.h>

#include <debug.h>

#include <arch/ovi_config_m16a0.h>

/*----------------------------------------------------------------------------------------
  Constant Definitions
  ----------------------------------------------------------------------------------------*/
#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3
#define REG_SET_A0_START				0x000000A0
#define REG_SET_B0_START				0x000000B0
#define REG_SET_B1_START				0x000000B1
#define REG_SET_CHECK_END				0x00000000

#define	OSD_MAX_NUM						8

//ifndef OSD_HEADER_BASE
//#define OSD_HEADER_BASE		0x70000000
//#endif
#define	OSD_PLTE_BUFFER			(OSD_HEADER_BASE + 0x20)
#define	OSD_FRAME_BUFFER		(OSD_HEADER_BASE + 0x2000)

#define	OSD_ADDR_BASE			0xc8024100
#define OSD_CTRL_BASE(layer)	((UINT32)(OSD_ADDR_BASE + 0x200 + (0x80*(layer))))

/*----------------------------------------------------------------------------------------
  Macro Definitions
  ----------------------------------------------------------------------------------------*/
#define set_reg(base,offset,val)	REG_WRITE((ulong)(base+offset),val)
#define get_reg(base,offset) 		REG_READ((ulong)(base+offset))

#define DCO_IN_CLK(npc,nsc)			((UINT32)24*((4*(npc))+(nsc))/12)
#define DCO_FCW(npc,nsc)			((UINT32)27*(1<<23)/(DCO_IN_CLK(npc,nsc)))

/*----------------------------------------------------------------------------------------
  Type Definitions
  ----------------------------------------------------------------------------------------*/
typedef struct
{
	UINT32                      	// OSD[0:3]_HDR0
		osd_hdr_ypos           :12, //  0:11
							   : 4,						// 12:15 reserved
							   osd_hdr_xpos           :11, // 16:26
							   : 4, 						// 27:30 reserved
							   osd_hdr_color_key_en   : 1; //    31

	UINT32                     		// OSD[0:3]_HDR1
		osd_hdr_h_mem         :12, 	//  0:11
							  : 4, 						// 12:15 reserved
							  osd_hdr_w_mem         :12;	// 16:27

	UINT32                     		// OSD[0:3]_HDR2
		osd_hdr_h_out         :12,	//  0:11
							  : 4,						// 12:15 reserved
							  osd_hdr_w_out         :12,	// 16:27
							  : 3,						// 28:30 reserved
							  osd_hdr_pixel_order   : 1; //    31

	UINT32							// OSD[0:3]_HDR3
		osd_hdr_wpl			  :16,	//  0:15
							  osd_hdr_global_alpha  : 8,	// 16:23
							  osd_hdr_format        : 4,	// 24:27
							  osd_hdr_depth         : 3,	// 28:30
							  osd_hdr_global_alpha_en: 1; //    31

	UINT32                     		// OSD[0:3]_HDR4
		osd_hdr_color_key      ;    // 31: 0

	UINT32							// OSD[0:3]_HDR5
		osd_hdr_ptr_plte		;	// 31: 0

	UINT32							// OSD[0:3]_HDR6
		osd_hdr_ptr_bmp			;    // 31: 0
}
OSD_HDR_T;

/*----------------------------------------------------------------------------------------
  External Function Prototype Declarations
  ----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
  External Variables
  ----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
  global Variables
  ----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
  Static Function Prototypes Declarations
  ----------------------------------------------------------------------------------------*/
static void DISP_Init(struct disp_info* info);
static void _Reg_Param_Set(const OVI_REG_T *param, u32 cnt, u32 addrOffset, BOOL bM16B0);

#ifdef USE_GFX_TEST_PATTERN
static void OSD_SimplePattern(void);
#endif
static void OSD_Init(osd_separate_t osd_t, const char* func, const int line );
static void OSD_RdFLHdr ( int fb_dev_id, OSD_HDR_T* pHdr );
static void OSD_WrFLHdr ( int fb_dev_id, OSD_HDR_T* pHdr );

static void GFX_Clear( UINT32 width, UINT32 height, UINT32 color, BOOL bSync );
static void GFX_Fill ( UINT32 x, UINT32 y, UINT32 width, UINT32 height, UINT32 color, BOOL bSync );

/*----------------------------------------------------------------------------------------
  Static Variables
  ----------------------------------------------------------------------------------------*/
static unsigned int g_osd_disp_width  = 1920;
static unsigned int g_osd_disp_height = 1080;
static unsigned int g_osd_img_width	  = 1920;
static unsigned int g_osd_img_height  = 1080;
static unsigned int g_osd_back_color  = 0xff000000;

/*========================================================================================
  Implementation Group ( VIDEO & FRC )
  ========================================================================================*/
static void DISP_Init(struct disp_info* info)
{
	UINT32 regVal;

	printf("DISP_Init-chip[%d], Infotype-frc_type[%d]/osd_img_width[%d]/osd_img_height[%d]/osd_disp_width[%d]/osd_disp_height[%d]/\n",
			get_chip_rev(), info->frc_type, info->osd_img_width, info->osd_img_height, info->osd_disp_width, info->osd_disp_height);
	printf("panel_type[%d]/panel_cell[%d]/panel_inch[%d]/panel_tool[%d]/panel_maker[%d]/panel_backlight[%d]/panel_led_bar_type[%d]/panel_gamut_type[%d]\
		/output_type[%d]/mirror[%d]/lvds_bit[%d]\n",
			info->panel_type,info->panel_cell,info->panel_inch,info->panel_tool,info->panel_maker,info->panel_backlight,info->panel_led_bar_type,info->panel_gamut_type,
			info->output_type,info->mirror,info->lvds_bit);

	g_osd_img_width	 = info->osd_img_width;
	g_osd_img_height = info->osd_img_height;

	g_osd_disp_width = info->osd_disp_width;
	g_osd_disp_height= info->osd_disp_height;

	// DCO (FCW) setting
	regVal = REG_READ(0xc8c73438);
	if ((regVal >> 24) & 0x1)
	{
		REG_WRITE(0xc800b090, 0x0011745d);
	}
	else
	{
		regVal = REG_READ(0xc8c7341c);
		if (((regVal>>23)&0x3f) || ((regVal>>19)&0xf))
		{
			REG_WRITE(0xc800b090, DCO_FCW((regVal>>23)&0x3f, (regVal>>19)&0xf));
		}
		else
		{
			printf("\nFCW Error!\n");
			return;
		}
	}

	if (info->frc_type == FRC_TYPE_EXTERNAL)
	{
		_Reg_Param_Set(disp_4k60_2k60_sep_vx1, ARRAY_SIZE(disp_4k60_2k60_sep_vx1), 0, info->isM16B0);
	}
	else
	{
		switch(info->output_type)
		{
			case DISP_60HZ_UHD_EPI:
				// Set DISP PLL SS (1%)
				REG_WRITE(0xC830941C, 0x0AA24120);
				REG_WRITE(0xC8309418, 0x5821364C);
				REG_WRITE(0xC8309418, 0x58213648);

				if (info->panel_cell == PANEL_CELL_RGBW)
				{
					switch(info->panel_inch)
					{
						case PANEL_INCH_43:
							if (info->panel_backlight == PANEL_BACKLIGHT_EDGE_LED)
							{
								_Reg_Param_Set(disp_4k60_epi_43_12lane_edge_rgbw, ARRAY_SIZE(disp_4k60_epi_43_12lane_edge_rgbw), 0, info->isM16B0);
							}
							else
							{
								_Reg_Param_Set(disp_4k60_epi_43_12lane_dl_rgbw, ARRAY_SIZE(disp_4k60_epi_43_12lane_dl_rgbw), 0, info->isM16B0);
							}
							break;
						case PANEL_INCH_49:
							_Reg_Param_Set(disp_4k60_epi_49_12lane_rgbw, ARRAY_SIZE(disp_4k60_epi_49_12lane_rgbw), 0, info->isM16B0);

							if ((info->panel_gamut_type == PANEL_GAMUT_WCG_PAC)
								&& (get_chip_rev() >= LX_CHIP_REV(M16 ,B0)))
							{
								REG_WRITE(0xC8010310, 0x00AAFF55);
								REG_WRITE(0xC8010314, 0x00AAFF55);
							}
							break;
						case PANEL_INCH_55:
						default :
							_Reg_Param_Set(disp_4k60_epi_55_12lane_rgbw, ARRAY_SIZE(disp_4k60_epi_55_12lane_rgbw), 0, info->isM16B0);

							if ((info->panel_gamut_type == PANEL_GAMUT_WCG_PAC)
								&& (get_chip_rev() >= LX_CHIP_REV(M16 ,B0)))
							{
								REG_WRITE(0xC8010310, 0x00AAFF55);
								REG_WRITE(0xC8010314, 0x00AAFF55);

								REG_WRITE(0xc801a014, 0x00000010);
								REG_WRITE(0xc801a018, 0x00000000);
								REG_WRITE(0xc801a01c, 0x00000010);
								REG_WRITE(0xc801a020, 0x00000000);
								REG_WRITE(0xc801a024, 0x00000010);
								REG_WRITE(0xc801a028, 0x00000000);
								REG_WRITE(0xc801a02c, 0x00000010);
								REG_WRITE(0xc801a030, 0x00000000);
								REG_WRITE(0xc801a034, 0x00000010);
								REG_WRITE(0xc801a038, 0x00000000);
								REG_WRITE(0xc801a03c, 0x00000010);
								REG_WRITE(0xc801a040, 0x00000000);
								REG_WRITE(0xc801a044, 0x00000010);
								REG_WRITE(0xc801a048, 0x00000000);
								REG_WRITE(0xc801a04c, 0x00000010);
								REG_WRITE(0xc801a050, 0x00000000);
							}
							break;
					}
				}
				else
				{
					_Reg_Param_Set(disp_4k60_epi_12lane_rgb, ARRAY_SIZE(disp_4k60_epi_12lane_rgb), 0, info->isM16B0);
				}
				break;
			case DISP_60HZ_UHD_VX1:
			default :
				_Reg_Param_Set(disp_4k60_blend_vx1, ARRAY_SIZE(disp_4k60_blend_vx1), 0, info->isM16B0);
		}

		// Local Dimming settings
		regVal = REG_READ(0xC830942C);
		if (info->led_control == LED_CONTROL_ENABLE)
		{
			REG_WRITE(0xC830942C, (regVal | (1<<10)));
		}
		else
		{
			REG_WRITE(0xC830942C, (regVal & ~(1<<10)));
		}

		if (info->panel_led_bar_type == PANEL_LED_BAR_V8)
		{
			_Reg_Param_Set(led_spi_v8, ARRAY_SIZE(led_spi_v8), 0, info->isM16B0);
		}
		else
		{
			switch(info->panel_backlight)
			{
				case PANEL_BACKLIGHT_EDGE_LED:
					switch(info->panel_led_bar_type)
					{
						case PANEL_LED_BAR_12:
							_Reg_Param_Set(led_spi_edge12, ARRAY_SIZE(led_spi_edge12), 0, info->isM16B0);
							break;
						case PANEL_LED_BAR_16:
							_Reg_Param_Set(led_spi_edge16, ARRAY_SIZE(led_spi_edge16), 0, info->isM16B0);
							break;
						case PANEL_LED_BAR_6:
						default :
							_Reg_Param_Set(led_spi_edge6, ARRAY_SIZE(led_spi_edge6), 0, info->isM16B0);
					}
					break;
				default :
					break;
			}
		}
	}

	if (info->frc_type == FRC_TYPE_EXTERNAL)
	{
		/* check again if disp_size is 2K if UHD Separated OSD model used */
		if( g_osd_disp_width != 1920 ) { GFXOSD_PRINT("UHD Separated OSD: change disp_width  %d -> 1920\n", g_osd_disp_width); g_osd_disp_width = 1920; }
		if( g_osd_disp_height!= 1080 ) { GFXOSD_PRINT("UHD Separated OSD: change disp_height %d -> 1080\n", g_osd_disp_height); g_osd_disp_height= 1080; }
	}
	else
	{
		/* check again if disp_size is 4K if UHD Blended OSD model used */
		if( g_osd_disp_width != 3840 ) { GFXOSD_PRINT("UHD Blended OSD: change disp_width  %d -> 3840\n", g_osd_disp_width); g_osd_disp_width = 3840; }
		if( g_osd_disp_height!= 2160 ) { GFXOSD_PRINT("UHD Blended OSD: change disp_height %d -> 2160\n", g_osd_disp_height); g_osd_disp_height= 2160; }
	}

	//GFX_Fill(0, 0, g_osd_img_width, g_osd_img_height, 0xff000000, TRUE );
	OSD_Init(info->frc_type == FRC_TYPE_EXTERNAL ? SOC_OUT_SEP_OSD : SOC_IN_SEP_OSD,__FUNCTION__,__LINE__);

#ifdef USE_GFX_TEST_PATTERN
	OSD_SimplePattern();
#endif
}

static void _Reg_Param_Set(const OVI_REG_T *param, u32 cnt, u32 addrOffset, BOOL bM16B0)
{
	BOOL ignore = FALSE;

	while(cnt--)
	{
		switch(param->addr & REG_PARAM_OP_GROUP_MASK)
		{
			case REG_PARAM_OP_GROUP_WAIT:	// wait
				if (!ignore)
				{
					udelay(param->value);
				}
				DEBUG("delay(_%dms);\n", param->value/1000);
				break;

			case REG_PARAM_OP_GROUP_CHECK:	// check
				if (bM16B0)	// B0
				{
					if ((param->value != REG_SET_CHECK_END)
						&& (param->value != REG_SET_B0_START))
					{
						ignore = TRUE;
					}
					else
					{
						ignore = FALSE;
					}
				}
				else if (get_chip_rev() >= LX_CHIP_REV(M16 ,B0)) // B1
				{
					if ((param->value != REG_SET_CHECK_END)
						&& (param->value != REG_SET_B1_START))
					{
						ignore = TRUE;
					}
					else
					{
						ignore = FALSE;
					}
				}
				else
				{
					if ((param->value != REG_SET_CHECK_END)
						&& (param->value != REG_SET_A0_START))
					{
						ignore = TRUE;
					}
					else
					{
						ignore = FALSE;
					}
				}
				DEBUG("ignore : %d\n", ignore);
				break;

			case REG_PARAM_OP_GROUP_RESERVED:
				DEBUG("REG_PARAM_OP_GROUP_RESERVED\n");
				break;

			default:	// REG_PARAM_OP_GROUP_WRITE
				if (!ignore)
				{
					REG_WRITE((ulong)(param->addr + addrOffset), param->value);
				}
				DEBUG("REG_WRITE( 0x%08x, 0x%08x);\n", (param->addr + addrOffset), param->value);
				break;
		}
		//DEBUG("0x%08x 0x%08x\n", param->addr, param->value);
		param++;
	}
}

/*========================================================================================
  Implementation Group ( OSD & GFX )
  ========================================================================================*/
#ifdef USE_GFX_TEST_PATTERN
static void OSD_SimplePattern(void)
{
	int		i;
    UINT32  colbar_list[8] = {  0xffffffff, /* white */
                                0xffffff00, /* yellow */
                                0xff00ffff, /* cyan */
                                0xff00ff00, /* green */
                                0xffff00ff, /* violet */
                                0xffff0000, /* red */
                                0xff0000ff, /* blue */
                                0xff000000};/* black */

	UINT32	colbar_sz = g_osd_img_width/8;

	for (i=0;i<8;i++)
	{
		GFX_Fill( i*colbar_sz, 0, colbar_sz, g_osd_img_height, colbar_list[i], FALSE);
	}

	#if USE_DATA_CACHE
	dcache_clean_range((unsigned long)OSD_FRAME_BUFFER, g_osd_img_width*g_osd_img_height*4);
	#endif
}
#endif

/** initialize OSD hardware with default configuration
 *
 *
 */
static void OSD_Init(osd_separate_t osd_t, const char* func, const int line)
{
	int			i;
	OSD_HDR_T	osd_hdr[2];

	UINT32		in_xsize  = g_osd_img_width;
	UINT32		in_ysize  = g_osd_img_height;
	UINT32		out_xsize = g_osd_disp_width;
	UINT32		out_ysize = g_osd_disp_height;

	UINT32 		depth = 0x6, format = 0xe, divide = 1, swap_ctrl = 0x444;

	UINT32		disp_reg_val = (g_osd_disp_width<<16) | (g_osd_disp_height);

	set_reg(OSD_ADDR_BASE, 0x50, disp_reg_val );	// OSD0.COMMON_DISP_SIZE
	set_reg(OSD_ADDR_BASE, 0x54, disp_reg_val );	// OSD1.COMMON_DISP_SIZE
	set_reg(OSD_ADDR_BASE, 0x58, disp_reg_val );	// OSD2.COMMON_DISP_SIZE
	set_reg(OSD_ADDR_BASE, 0x5c, disp_reg_val );	// OSD3.COMMON_DISP_SIZE
	set_reg(OSD_ADDR_BASE, 0x60, disp_reg_val );	// OSD4.COMMON_DISP_SIZE
	set_reg(OSD_ADDR_BASE, 0x64, disp_reg_val );	// OSD5.COMMON_DISP_SIZE
	set_reg(OSD_ADDR_BASE, 0x68, disp_reg_val );	// OSD6.COMMON_DISP_SIZE
	set_reg(OSD_ADDR_BASE, 0x6c, disp_reg_val );	// OSD7.COMMON_DISP_SIZE

	GFXOSD_PRINT("OSD PATH (%s) INIT %dx%d -> %dx%d @0x%x from %s:%d\n",
				(SOC_OUT_SEP_OSD == osd_t)? "S.OSD":"B.OSD",
				g_osd_img_width, g_osd_img_height,
				g_osd_disp_width, g_osd_disp_height,
				OSD_FRAME_BUFFER, func, line );

	if(osd_t == SOC_OUT_SEP_OSD)
	{
		set_reg(OSD_ADDR_BASE, 0x80, disp_reg_val );										// SOSD_MIXER.COMMON_DISP_SIZE

		for (i=0;i<OSD_MAX_NUM; i++)
		{
			set_reg(OSD_CTRL_BASE(i), 0x18, (g_osd_disp_width<<16) | 0x0101 );				// OSD0.PATH osd_ctrl_eo2s = 1, osd_ctrl_bosd_pos=0, osd_ctrl_direc = 1
			set_reg(OSD_CTRL_BASE(i), 0x40, 0x00000010 );									// OSD0.SYNC0 osd0_sync_hdouble_en = 1
			set_reg(OSD_CTRL_BASE(i), 0x44, (g_osd_disp_width<<16) | g_osd_disp_height);	// OSD0.SYNC1 disp_width, disp_height
		}
	}
	else
	{
		set_reg(OSD_ADDR_BASE, 0x180, disp_reg_val );										// BOSD_MIXER.COMMON_DISP_SIZE

		for (i=0;i<OSD_MAX_NUM;i++)
		{
			set_reg(OSD_CTRL_BASE(i), 0x18, ((g_osd_disp_width/2)<<16) | 0x0000 );			// OSD0.PATH disp_width/2, osd_ctrl_eo2s = 0, osd_ctrl_bosd_pos=0, osd_ctrl_direc = 0
			set_reg(OSD_CTRL_BASE(i), 0x40, 0x00000000 );									// OSD0.SYNC0 osd0_sync_hdouble_en = 0
			set_reg(OSD_CTRL_BASE(i), 0x44, ((g_osd_disp_width/2)<<16) | g_osd_disp_height);// OSD0.SYNC1 disp_width/2, disp_height
		}
	}

	/* initialize memory address for all OSD layer. prevent MEM_PROTECT error */
	for (i=0; i<OSD_MAX_NUM; i++ )
	{
		set_reg( OSD_CTRL_BASE(i), 0x04, OSD_HEADER_BASE );
		set_reg( OSD_CTRL_BASE(i), 0x34, OSD_PLTE_BUFFER );
		set_reg( OSD_CTRL_BASE(i), 0x38, OSD_FRAME_BUFFER );
	}

	/* setup OSD to read the OSD header from register NOT DDR */
	for (i=0; i<OSD_MAX_NUM; i++ )
	{
		set_reg( OSD_CTRL_BASE(i), 0x00, 0x00080010);	// OSDx.CTRL_MAIN osd_manual_dir=2 osd_hdr_src_sel = 1
	}

	/* FHD mode - use single POSDs to show LOGO */
	OSD_RdFLHdr (0, &osd_hdr[0]);

	osd_hdr[0].osd_hdr_xpos		= 0;
	osd_hdr[0].osd_hdr_ypos		= 0;
	osd_hdr[0].osd_hdr_w_mem	= in_xsize;
	osd_hdr[0].osd_hdr_h_mem	= in_ysize;
	osd_hdr[0].osd_hdr_w_out	= out_xsize;
	osd_hdr[0].osd_hdr_h_out	= out_ysize;

	osd_hdr[0].osd_hdr_wpl		= in_xsize>>divide;
	osd_hdr[0].osd_hdr_format	= format;
	osd_hdr[0].osd_hdr_depth	= depth;
	osd_hdr[0].osd_hdr_ptr_plte	= OSD_PLTE_BUFFER;
	osd_hdr[0].osd_hdr_ptr_bmp	= OSD_FRAME_BUFFER;

	OSD_WrFLHdr (0, &osd_hdr[0] );						// write OSD hdr
	set_reg( OSD_CTRL_BASE(0), 0x08, swap_ctrl );		// OSD0_CTRL_SWAP

	set_reg(0xc8024000, 0x20, 0x00000008);				// CCO CTRL_DPATH - OSD0/1 AFBC off
	set_reg(0xc8024000, 0x38, 0x00000000);				// CCO CTRL_AUTO_INIT_AFBC_01 off

	if(osd_t == SOC_OUT_SEP_OSD)
	{
		set_reg(0xc8024000, 0x8, 0x77777777 );			// CCO CTRL_AUTO_INIT (S.OSD)
	}
	else
	{
		set_reg(0xc8024000, 0x8, 0x55555555 );			// CCO CTRL_AUTO_INIT (B.OSD)
	}

	set_reg(0xc8024000, 0x0, 0x00FF0000 );
}

/** read OSD header
 *
 */
static void OSD_RdFLHdr ( int fb_dev_id, OSD_HDR_T* pHdr )
{
	UINT32	data[7];

	if (fb_dev_id==0)
	{
		data[0] = get_reg( OSD_CTRL_BASE(0), 0x20); /* OSDx_CTRL_HDR0 */
		data[1] = get_reg( OSD_CTRL_BASE(0), 0x24); /* OSDx_CTRL_HDR1 */
		data[2] = get_reg( OSD_CTRL_BASE(0), 0x28); /* OSDx_CTRL_HDR2 */
		data[3] = get_reg( OSD_CTRL_BASE(0), 0x2c); /* OSDx_CTRL_HDR3 */
		data[4] = get_reg( OSD_CTRL_BASE(0), 0x30); /* OSDx_CTRL_HDR4 */
		data[5] = get_reg( OSD_CTRL_BASE(0), 0x34); /* OSDx_CTRL_HDR5 */
		data[6] = get_reg( OSD_CTRL_BASE(0), 0x38); /* OSDx_CTRL_HDR6 */
	}
	else /* fb_dev_id==1 */
	{
		data[0] = get_reg( OSD_CTRL_BASE(1), 0x20); /* OSDx_CTRL_HDR0 */
		data[1] = get_reg( OSD_CTRL_BASE(1), 0x24); /* OSDx_CTRL_HDR1 */
		data[2] = get_reg( OSD_CTRL_BASE(1), 0x28); /* OSDx_CTRL_HDR2 */
		data[3] = get_reg( OSD_CTRL_BASE(1), 0x2c); /* OSDx_CTRL_HDR3 */
		data[4] = get_reg( OSD_CTRL_BASE(1), 0x30); /* OSDx_CTRL_HDR4 */
		data[5] = get_reg( OSD_CTRL_BASE(1), 0x34); /* OSDx_CTRL_HDR5 */
		data[6] = get_reg( OSD_CTRL_BASE(1), 0x38); /* OSDx_CTRL_HDR6 */
	}

	memcpy( pHdr, data, sizeof(OSD_HDR_T));
}

/** wrie OSD header
 *
 */
static void OSD_WrFLHdr ( int fb_dev_id, OSD_HDR_T* pHdr )
{
	UINT32	data[7];
	memcpy( data, pHdr, sizeof(OSD_HDR_T));

	GFXOSD_PRINT("%s, fb(%d)\n", __FUNCTION__, fb_dev_id);

	if (fb_dev_id==0)
	{
		set_reg( OSD_CTRL_BASE(0), 0x20, data[0]);		/* OSDx_CTRL_HDR0 */
		set_reg( OSD_CTRL_BASE(0), 0x24, data[1]);		/* OSDx_CTRL_HDR1 */
		set_reg( OSD_CTRL_BASE(0), 0x28, data[2]);		/* OSDx_CTRL_HDR2 */
		set_reg( OSD_CTRL_BASE(0), 0x2c, data[3]);		/* OSDx_CTRL_HDR3 */
		set_reg( OSD_CTRL_BASE(0), 0x30, data[4]);		/* OSDx_CTRL_HDR4 */
		set_reg( OSD_CTRL_BASE(0), 0x34, data[5]);		/* OSDx_CTRL_HDR5 */
		set_reg( OSD_CTRL_BASE(0), 0x38, data[6]);		/* OSDx_CTRL_HDR6 */
	}
	else /* fb_dev_id==1 */
	{
		set_reg( OSD_CTRL_BASE(1), 0x20, data[0]);		/* OSDx_CTRL_HDR0 */
		set_reg( OSD_CTRL_BASE(1), 0x24, data[1]);		/* OSDx_CTRL_HDR1 */
		set_reg( OSD_CTRL_BASE(1), 0x28, data[2]);		/* OSDx_CTRL_HDR2 */
		set_reg( OSD_CTRL_BASE(1), 0x2c, data[3]);		/* OSDx_CTRL_HDR3 */
		set_reg( OSD_CTRL_BASE(1), 0x30, data[4]);		/* OSDx_CTRL_HDR4 */
		set_reg( OSD_CTRL_BASE(1), 0x34, data[5]);		/* OSDx_CTRL_HDR5 */
		set_reg( OSD_CTRL_BASE(1), 0x38, data[6]);		/* OSDx_CTRL_HDR6 */
	}
}

/** enable OSD0 layer
 *
 */
static void OSD_Enable(void)
{
	UINT32	val;

	val = get_reg(OSD_CTRL_BASE(0), 0x0 );	/* read OSD0_CTRL_MAIN */
	val |= 0x1;								/* set bit[0] */
	set_reg(OSD_CTRL_BASE(0), 0x0, val );	/* write OSD0_CTRL_MAIN */

	val = get_reg(OSD_CTRL_BASE(0), 0x40 );
	val |= 0x1;								/* set bit[0] */
	set_reg(OSD_CTRL_BASE(0), 0x40, val );	/* write OSD0_CTRL_MAIN */

	GFXOSD_PRINT("fb(%d) POSD ON\n", 0 );

	if ( g_osd_img_width > 2048 )
	{
		val = get_reg(OSD_CTRL_BASE(1), 0x0 );	/* read OSD0_CTRL_MAIN */
		val |= 0x1;								/* set bit[0] */
		set_reg(OSD_CTRL_BASE(0), 0x0, val );	/* write OSD0_CTRL_MAIN */

		val = get_reg(OSD_CTRL_BASE(1), 0x40 );
		val |= 0x1;								/* set bit[0] */
		set_reg(OSD_CTRL_BASE(0), 0x40, val );	/* write OSD0_CTRL_MAIN */

		GFXOSD_PRINT("fb(%d) POS1 ON\n", 0 );
	}
}

static void GFX_init (void)
{
	/* M16 GFX clk = 528 MHz. moved to shadow_rom */
	// set_reg(0xC898C08C, 0x0, 0x66260000 );
}

static void GFX_Fill ( UINT32 x, UINT32 y, UINT32 width, UINT32 height, UINT32 color, BOOL bSync)
{
	GFXOSD_PRINT("%s: %d,%d,%d,%d, 0x%08x\n", __FUNCTION__, x, y, width, height, color );

#ifdef USE_GFX_SWL
	int		i,j;
	UINT32* fbmem = (UINT32*)OSD_FRAME_BUFFER + y * g_osd_img_width + x;
	UINT32* fbmem_base = fbmem;
	UINT32* fbmem_ptr  = fbmem;

	GFXOSD_PRINT("osd 0x%x, fbmem = %p\n", (UINT32)OSD_FRAME_BUFFER, fbmem );

	/* prepare the first line */
	for (i=width; i>0; i--) *fbmem_ptr++ = color;

	/* copy the first line to rest lines */
	for (j= height-1; j>0; j--)
	{
		fbmem_base += g_osd_img_width;
		memcpy( fbmem_base, fbmem, sizeof(UINT32)*width );
	}
	#if USE_DATA_CACHE
	if (bSync)
	{
		dcache_clean_range((unsigned long)fbmem, g_osd_img_width*height*4);
	}
	#endif
#else
	/* not supported */
#endif
}

/** clear all screen with constant color
 *	color should have the type of ARGB8888
 *
 */
static void GFX_Clear( UINT32 width, UINT32 height, UINT32 color, BOOL bSync )
{
	GFXOSD_PRINT("%s: %d,%d 0x%08x\n", __FUNCTION__, width, height, color );

	GFX_Fill( 0, 0, width, height, color, bSync );
}

/** blit
 *
 *	@param in_xsize [IN] width of input buffer
 *	@param in_ysize [IN] height of input buffer
 *	@param xoffset  [IN] horizontal offset in destination frame
 *	@param yoffset  [IN] vertical offset in destination frame
 *	@param format 	[IN] GFX pixel format
 *	@param out_xsize[IN] used to calcuate output frame stride
 *	@param addr		[IN] physical address for input frame
 *
 */
static void GFX_Blit(unsigned long addr, UINT32 img_w, UINT32 img_h, UINT32 out_x, UINT32 out_y, BOOL bSync )
{
	GFXOSD_PRINT("%s: %d,%d %d,%d 0x%08x\n", __FUNCTION__, img_w, img_h, out_x, out_y );

#ifdef USE_GFX_SWL
	int		i;
	UINT32* fbmem = (UINT32*)OSD_FRAME_BUFFER + g_osd_img_width * out_y + out_x;
	UINT32* imgmem= (UINT32*)addr;

	UINT32*	imgmem_ptr = imgmem;
	UINT32* fbmem_ptr  = fbmem;

	for (i=0; i<img_h; i++)
	{
		memcpy( fbmem_ptr, imgmem_ptr, sizeof(UINT32) * img_w );

		imgmem_ptr += img_w;
		fbmem_ptr  += g_osd_img_width;
	}
	#if USE_DATA_CACHE
	if (bSync)
	{
		dcache_clean_range((unsigned long)fbmem, g_osd_img_width * img_h);
	}
	#endif
#else

#endif
}

/*========================================================================================
  Implementation Group ( main ctrl )
  ========================================================================================*/
void display_default_info(struct disp_info* info)
{
	info->frc_type		= FRC_TYPE_NO_FRC;
	info->colordepth	= 10;	// not used

	info->panel_type	= PANEL_TYPE_V16;
	info->panel_cell	= PANEL_CELL_RGB;
	info->panel_inch	= PANEL_INCH_55;
	info->panel_tool	= PANEL_TOOL_UF95;
	info->panel_maker	= PANEL_MAKER_LGD;
	info->panel_backlight= PANEL_BACKLIGHT_EDGE_LED;
	info->panel_led_bar_type	= PANEL_LED_BAR_6;
	info->panel_gamut_type	= PANEL_GAMUT_WCG;
	info->output_type	= DISP_60HZ_UHD_VX1;
	info->lvds_type		= LVDS_VESA;
	info->lvds_bit		= LVDS_10BIT;
	info->mirror		= 0;

	info->osd_img_width =1920;	/* FHD resolution */
	info->osd_img_height=1080;	/* FHD resolution */

	info->osd_disp_width =3840;	/* UHD resolution */
	info->osd_disp_height=2160;	/* UHD resolution */

	info->led_control	= LED_CONTROL_ENABLE;
	info->isM16B0		= FALSE;
}

void display_init(struct disp_info* info)
{
	GFX_init	( );
	DISP_Init	( info );
	OSD_Enable	( );
}

int osd_blit(int x, int y, int w, int h, const void *pixmap, color_fmt_t format)
{
	if(format != COLOR_FMT_RGB8888)
	{
		printf("Not implemented color format\n");
		return -1;
	}
	if(x == -1) x = (g_osd_img_width - w) >> 1;
	if(y == -1) y = (g_osd_img_height- h) >> 1;

	if((x+w) > g_osd_img_width || (y+h) > g_osd_img_height)
	{
		printf("Over max range\n");
		return -1;
	}

	/* disable cache clean when GFX SWL is used */
#ifndef USE_GFX_SWL
#if USE_DATA_CACHE
	dcache_clean_range((unsigned long)pixmap, w*h*4);
#endif
#endif

	GFXOSD_PRINT("%s: xywh = %d,%d,%d,%d\n", __FUNCTION__,x,y,w,h);

#ifdef USE_GFX_FILL_DELAYED
	GFX_Clear(g_osd_img_width, g_osd_img_height, g_osd_back_color, FALSE);
#endif
	GFX_Blit((unsigned long)pixmap, w, h, x, y, FALSE);

	/* cache clean the whole OSD area to improve the performance */
#if USE_DATA_CACHE
	dcache_clean_range(OSD_FRAME_BUFFER, g_osd_img_width * g_osd_img_height * 4 );
#endif

	return 0;
}

void osd_fill(int x, int y, int w, int h, uint32_t color)
{
	g_osd_back_color = 0xff000000|color;
#ifdef USE_GFX_FILL_DELAYED
	/* do nothing */
#else
	/* FIXME: make full-sized fill for test */
	if ( w>=1920 && h>=1080 )
	{
		w = g_osd_img_width;
		h = g_osd_img_height;
	}

	GFX_Clear(w, h, 0xff000000|color, TRUE); /* make color to be opaque !! */
#endif
}

void osd_sync(void)
{

}

#endif

