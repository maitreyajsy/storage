static reg_param_t lm_exit_cmm[] = {
};
