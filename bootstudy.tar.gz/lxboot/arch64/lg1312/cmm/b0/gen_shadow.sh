rm -rf *.lst *.h

cat ../common/bus_150708_port_chn_balancing_N_FPGA.cmm > ../common/bus.cmm

#B0 chip (sk, ss)
../../../../tools/convert_cmm ./sk/M16_A0_TOP.cmm		top_sk_bx.h
../../../../tools/convert_cmm ./sk/M16_M0_1056.cmm		lm_sk_bx.h
../../../../tools/convert_cmm ./sk/M16_M1_1056.cmm		gm_sk_bx.h
../../../../tools/convert_cmm ../common/bus.cmm			bus_sk_bx.h

../../../../tools/convert_cmm ./sk/instant/M16_M0_self_refresh_exit1.cmm	lm_exit_sk_bx.h
../../../../tools/convert_cmm ./sk/instant/M16_M1_self_refresh_exit1.cmm	gm_exit_sk_bx.h
../../../../tools/convert_cmm ./sk/instant/M16_M0_self_refresh_exit2.cmm	lm_exit_post_sk_bx.h
../../../../tools/convert_cmm ./sk/instant/M16_M1_self_refresh_exit2.cmm	gm_exit_post_sk_bx.h

#B0 chip (micron)
../../../../tools/convert_cmm ./micron/M16_A0_TOP.cmm		top_mr_bx.h
../../../../tools/convert_cmm ./micron/M16_M0_1056.cmm		lm_mr_bx.h
../../../../tools/convert_cmm ./micron/M16_M1_1056.cmm		gm_mr_bx.h
../../../../tools/convert_cmm ../common/bus.cmm				bus_mr_bx.h

../../../../tools/convert_cmm ./micron/instant/M16_M0_self_refresh_exit1.cmm	lm_exit_mr_bx.h
../../../../tools/convert_cmm ./micron/instant/M16_M1_self_refresh_exit1.cmm	gm_exit_mr_bx.h
../../../../tools/convert_cmm ./micron/instant/M16_M0_self_refresh_exit2.cmm	lm_exit_post_mr_bx.h
../../../../tools/convert_cmm ./micron/instant/M16_M1_self_refresh_exit2.cmm	gm_exit_post_mr_bx.h


cp ./*.h ../../header/shadow/soc_setup_header/


rm -rf *.lst *.h
