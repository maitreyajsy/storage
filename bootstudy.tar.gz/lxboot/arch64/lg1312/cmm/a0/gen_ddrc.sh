
rm -rf *.lst *.h

../../../../tools/convert_cmm ./1056/M16_A0_TOP.cmm top.lst
../../../../tools/convert_cmm ./1056/M16_M0_1056.cmm m0.lst
../../../../tools/convert_cmm ./1056/M16_M1_1056.cmm m1.lst
../../../../tools/convert_cmm ../common/bus_150626_port_chn_NoP0.cmm bus.lst



cat top.lst > ddrc.lst
cat m0.lst >> ddrc.lst
cat m1.lst >> ddrc.lst
cat bus.lst >> ddrc.lst

cp ./ddrc.lst ../../header/system/

rm -rf *.lst *.h
