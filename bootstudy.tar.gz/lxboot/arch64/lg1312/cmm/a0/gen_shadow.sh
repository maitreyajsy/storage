rm -rf *.lst *.h

cat ../common/bus_150708_port_chn_balancing_N_FPGA.cmm > ../common/bus.cmm

#936MHz
../../../../tools/convert_cmm ./936/M16_A0_TOP.cmm		top.h
../../../../tools/convert_cmm ./936/M16_M0_1056.cmm		lm.h
../../../../tools/convert_cmm ./936/M16_M1_1056.cmm		gm.h
../../../../tools/convert_cmm ../common/bus.cmm			bus.h

../../../../tools/convert_cmm dummy.cmm		lm_exit.h
../../../../tools/convert_cmm dummy.cmm		gm_exit.h
../../../../tools/convert_cmm dummy.cmm		lm_exit_post.h
../../../../tools/convert_cmm dummy.cmm		gm_exit_post.h

#1056MHz
../../../../tools/convert_cmm ./1056/M16_A0_TOP.cmm		top_1056.h
../../../../tools/convert_cmm ./1056/M16_M0_1056.cmm	lm_1056.h
../../../../tools/convert_cmm ./1056/M16_M1_1056.cmm	gm_1056.h
../../../../tools/convert_cmm ../common/bus.cmm			bus_1056.h

../../../../tools/convert_cmm ./1056/instant/M16_M0_self_refresh_exit1.cmm	lm_exit_1056.h
../../../../tools/convert_cmm ./1056/instant/M16_M1_self_refresh_exit1.cmm	gm_exit_1056.h
../../../../tools/convert_cmm ./1056/instant/M16_M0_self_refresh_exit2.cmm	lm_exit_post_1056.h
../../../../tools/convert_cmm ./1056/instant/M16_M1_self_refresh_exit2.cmm	gm_exit_post_1056.h

#../../../../tools/convert_cmm ./1056/instant/M16_M0_self_refresh_entry.cmm ?
#../../../../tools/convert_cmm ./1056/instant/M16_M1_self_refresh_entry.cmm	?

cp ./*.h ../../header/shadow/soc_setup_header/


rm -rf *.lst *.h
