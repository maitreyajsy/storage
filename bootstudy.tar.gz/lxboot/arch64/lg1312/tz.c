/*
 * System IC Lab, LG ELECTRONICS INC., SEOUL, KOREA
 * COPYRIGHT(c) 2014 by LG Electronics Inc.
 *
 * All rights reserved. No part of this work covered by this copyright hereon
 * may be reproduced, stored in a retrieval system, in any form
 * or by any means, electronic, mechanical, photocopying, recording
 * or otherwise, without the prior written  permission of LG Electronics.
 */

#include <stdio.h>
#include <string.h>
#include <debug.h>
#include <storage.h>
#include <arch/tz.h>

/* move tz image (emmc -> ddr) */
#define TZ_DMA_MEM_BASE		(0x7f600000)

#define TZFW_HDR_SZ			0x20 /*32 bytes*/
#define TZFW_HDR_OFFSET		0x20 /*32bytes vector table advance header*/

/*
 * X_X_X_X 
 * X[3:0] Boot loader use wfi or wfe before TrustZone
 * X[7:4] TrustZone use wfi or wfe before Linux Kernel
 * X[11:8] Linux Kernel use PSCI or Spin Table
 * X[15:12] Linux Kernel use AArch32 or AArch64
 */
#define A32_X_X_X 		(0x1000)
#define A64_X_X_X 		(0x2000)
#define X_PSCI_X_X 		(0x0100)
#define X_SPIN_X_X 		(0x0200)
#define X_X_WFI_X 		(0x0010)
#define X_X_WFE_X 		(0x0020)
#define X_X_X_WFI		(0x0001)
#define X_X_X_WFE		(0x0002)

			      /* 32 or 64    Linux Kernel tz          lx */
#define USE_A32_PSCI_WFE_WFE	(A32_X_X_X | X_PSCI_X_X | X_X_WFE_X | X_X_X_WFE)
#define USE_A32_PSCI_WFE_WFI	(A32_X_X_X | X_PSCI_X_X | X_X_WFE_X | X_X_X_WFI)
#define USE_A32_PSCI_WFI_WFE	(A32_X_X_X | X_PSCI_X_X | X_X_WFI_X | X_X_X_WFE)
#define USE_A32_PSCI_WFI_WFI	(A32_X_X_X | X_PSCI_X_X | X_X_WFI_X | X_X_X_WFI)
#define USE_A32_SPIN_WFE_WFE	(A32_X_X_X | X_SPIN_X_X | X_X_WFE_X | X_X_X_WFE)
#define USE_A32_SPIN_WFE_WFI	(A32_X_X_X | X_SPIN_X_X | X_X_WFE_X | X_X_X_WFI)
#define USE_A32_SPIN_WFI_WFE	(A32_X_X_X | X_SPIN_X_X | X_X_WFI_X | X_X_X_WFE)
#define USE_A32_SPIN_WFI_WFI	(A32_X_X_X | X_SPIN_X_X | X_X_WFI_X | X_X_X_WFI)

#define USE_A64_PSCI_WFE_WFE	(A64_X_X_X | X_PSCI_X_X | X_X_WFE_X | X_X_X_WFE)
#define USE_A64_PSCI_WFE_WFI	(A64_X_X_X | X_PSCI_X_X | X_X_WFE_X | X_X_X_WFI)
#define USE_A64_PSCI_WFI_WFE	(A64_X_X_X | X_PSCI_X_X | X_X_WFI_X | X_X_X_WFE)
#define USE_A64_PSCI_WFI_WFI	(A64_X_X_X | X_PSCI_X_X | X_X_WFI_X | X_X_X_WFI)
#define USE_A64_SPIN_WFE_WFE	(A64_X_X_X | X_SPIN_X_X | X_X_WFE_X | X_X_X_WFE)
#define USE_A64_SPIN_WFE_WFI	(A64_X_X_X | X_SPIN_X_X | X_X_WFE_X | X_X_X_WFI)
#define USE_A64_SPIN_WFI_WFE	(A64_X_X_X | X_SPIN_X_X | X_X_WFI_X | X_X_X_WFE)
#define USE_A64_SPIN_WFI_WFI	(A64_X_X_X | X_SPIN_X_X | X_X_WFI_X | X_X_X_WFI)


typedef struct {
	u32 magic;
	u32 load;
	u32 size_0;
	u32 size_1;
	u32 p_ver;
} tzfw_hdr_t;


static inline int tzfw_get_magic(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return (h->magic);
}

static inline int tzfw_check_magic(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return ((h->magic)==0x545A4657); /*TZFW*/
}


static inline uint32_t tzfw_get_load(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return (h->load);
}

static inline uint32_t tzfw_get_size(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return (h->size_0+h->size_1);
}

static inline ulong tzfw_get_version(void* hdr)
{
	tzfw_hdr_t* h = (tzfw_hdr_t*)hdr;
	return (h->p_ver);
}

static ulong tz_version;

#if USE_TZ_PARTITION
/*load tz from emmc partition*/
static unsigned long _loadtz_from_storage(void)
{
	unsigned long load_addr = 0;
	uint8_t* buf = (uint8_t *)TZ_DMA_MEM_BASE;
	void* hdr;
	uint32_t img_size;
	uint64_t offset;
	uint32_t filesize;
	storage_partition_t partition;

	/*get tzfw partition*/
	if(storage_get_partition("tzfw", &partition) < 0 || partition.filesize == 0)
	{
		ERROR("[tz] Invalid tzfw partition\n");
		return 0;
	}
	offset = partition.offset;
	filesize = partition.filesize; /*header(16B) + program_size*/

	printf("[tz] partition offset[0x%llx], filesz[0x%x]\n", offset, filesize);


	/*read tzfw header*/
	if (storage_read(offset+TZFW_HDR_OFFSET, TZFW_HDR_SZ, buf) < 0)
	{
		ERROR("[tz] Can't read tzfw image\n");
		return 0;
	}

	/*check magic, loading addr, binary size*/
	hdr = (void*)buf;
	if(tzfw_check_magic(hdr))
	{
		load_addr = tzfw_get_load(hdr);
		img_size = tzfw_get_size(hdr);
		tz_version = tzfw_get_version(hdr);
		printf("[tz] addr[0x%x], size[0x%x] from emmc\n", 
			load_addr, img_size);
	}
	else
	{
		ERROR("[tz] fault tzfw magic\n");
		return 0;
	}

	/*read tzfw binary*/
	if (storage_read(offset, img_size, (void*)buf) < 0)
	{
		ERROR("[tz] Can't read tzfw image\n");
		return 0;
	}
	else
	{
		/*load tzfw binary to execution address*/
		memcpy((char *)load_addr, (char*)buf, img_size);
		printf("success\n");
	}

	return load_addr;

}
#endif


#if USE_TZ_INCBIN
extern unsigned long tz_bin_start;
extern unsigned long tz_bin_end;

/*load tz from .data section in 2st lxboot*/
static unsigned long _loadtz_from_section(void)
{
	unsigned long load_addr = 0;
	unsigned long bin_start;
	void* hdr ;
	uint32_t img_size;


	hdr = (void*)((uint8_t*)(&tz_bin_start)+TZFW_HDR_OFFSET);

	if(tzfw_check_magic(hdr))
	{
		load_addr = (unsigned long)tzfw_get_load(hdr);
		img_size = tzfw_get_size(hdr);
		tz_version = tzfw_get_version(hdr);
		bin_start = (unsigned long)(&tz_bin_start);

		printf("[tz] addr[0x%lx], size[0x%x] from .data section\n", 
			load_addr, img_size);

		memcpy((void*)load_addr,(void*)bin_start, img_size);
	}
	else
	{
		ERROR("fault tzfw magic\n");
		return 0;
	}

	return load_addr;
}
#endif


unsigned long loadtz(void)
{
	unsigned long load_addr=0;

#if USE_TZ_PARTITION
	/*load tzfw from emmc firstly.*/
	load_addr = _loadtz_from_storage();
	printf ("[tz] load from storage : 0x%08x \n", load_addr);
#endif

#if USE_TZ_INCBIN
	/*load tzfw from .data section.*/
	if(load_addr == 0)
	{
		load_addr = _loadtz_from_section();
		printf ("[tz] load from section : 0x%08x \n", load_addr);
	}

#endif

	return load_addr;
}

tz_param_t tz_args;

void tz_boot(unsigned long load_addr)
{
	/*secondary cpus enable method and release addr*/
	ulong method=0;
	ulong rel_addr=0;

	if(tz_args.aarch == KERNEL_AARCH32)
	{
		if(tz_args.psci)
			method = USE_A32_PSCI_WFI_WFI;
		else
			method = USE_A32_SPIN_WFI_WFI;
		
		rel_addr = LG1312_SYS_FLAGSSET;
	}
	else if(tz_args.aarch == KERNEL_AARCH64)
	{
		if(tz_args.psci)
			method = USE_A64_PSCI_WFI_WFI;
		else
			method = USE_A64_SPIN_WFE_WFI;
		
		rel_addr = KERNEL_CPUS_SPIN_CODE_REG;
	}
	else
	{
		printf("[tz] Unknown Kernel Arch[%u]\n", tz_args.aarch);
		method = USE_A32_SPIN_WFI_WFI;
		rel_addr = LG1312_SYS_FLAGSSET;
	}

	if(tz_version != 0x7ff00000)
			printf("[tz] tz version%s\n", tz_version );
	
	printf("[tz] goto tz, pc[0x%x], psci[%u]\n", load_addr, tz_args.psci );

	/*
	 * x0 : tz start, load address
	 * x1 : returned lxboot el2 entry address
	 * x2 : secondary cpus release addr
	 * x3 : secondary cpus enable method
	 */
	__tzboot(load_addr, __el2, rel_addr, method);

	return;
}

