/*************************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 **************************************************************************************************/


#ifndef __ARCH_CPU_H__
#define __ARCH_CPU_H__

#include <arm/registers.h>
#include <arm/cpu.h>
//#include <arch/cpu_ext.h>

#ifndef __ASSEMBLY__

// arch_soc.c
void soc_init(void);
void set_su_top(void);

// arch_addr_switch.c
void set_addr_switch(void);

// in cacheops.S
void flush_dcache(void);
void clean_dcache(void);
void inv_dcache(void);
void inv_icache(void);
void inv_tlb(void);

void enable_dcache(void);
void disable_dcache(void);
void enable_icache(void);
void disable_icache(void);

/* to compatible */
#define dcache_disable() 	disable_dcache()

// in arch_dbg.c
void show_exceptions(void *p);

// in arch_cpu.c
int ace_reg_read(uint8_t slave, uint8_t addr, uint8_t *data);
int ace_reg_write(uint8_t slave, uint8_t addr, uint8_t data);

// in arch_ctop.c
void ctop_detect_clk(void);
uint32_t ctop_get_cpu_clk(void);
uint32_t ctop_get_pclk(void);
uint32_t ctop_get_lm_clk(void);
uint32_t ctop_get_gm_clk(void);
uint32_t ctop_get_m1_pll_ss(void);
uint32_t ctop_get_m2_pll_ss(void);

// arch_usb.c
void arch_usb_init(void);
void arch_usb_start(void);
void arch_usb_stop(void);
// in start.S
void cpu_loop(uint32_t count);

#endif

#endif /* __ARCH_CPU_H__ */
