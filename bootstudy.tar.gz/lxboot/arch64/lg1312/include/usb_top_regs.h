#ifndef _USB_TOP_REGS_H_
#define _USB_TOP_REGS_H_

#include <types.h>

/*----------------------------------------------------------------------------------------
    Control Constants
----------------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
  USB_CTRL0 Memory Map
------------------------------------------------------------------------------*/
#define USB3_HOST_CTRL0         (LG1312_USB_CTRL0_BASE + 0x10000)
#define USB3_HOST_CTRL1         (LG1312_USB_CTRL0_BASE + 0x20000)
#define USB3_PHY_CTRL0          (LG1312_USB_CTRL0_BASE + 0x30000)
#define USB3_PHY_CTRL1          (LG1312_USB_CTRL0_BASE + 0x40000)
#define USB2_HOST_CTRL0         (LG1312_USB_CTRL0_BASE + 0x50000)
#define USB2_HOST_CTRL1         (LG1312_USB_CTRL0_BASE + 0x60000)
#define USB2_PHY_CTRL0          (LG1312_USB_CTRL0_BASE + 0x70000)
/*-----------------------------------------------------------------------------
 BT/WiFi Port(HSUSB1) Memory Map
------------------------------------------------------------------------------*/
/* Note: BT/WiFi PHY Registers are CTOP_R31 and CTOP_R32 and it contains only
 * USB2_PHY_PARAM0 and USB2_PHY_PARAM1.
 * BT/WiFi Has no USB2_PHY_RESET and USB2_PHY_PARAM2 so we need to redefine for
 * BT/WiFi Port reset.
 */
#define USB2_BT_PHY_CTRL1			(0xC830A47C) // CTOP_R31
#define USB2_BT_PHY_CTRL1_B0		(0xC830A478)

/*----------------------------------------------------------------------------------------
    File Inclusions
----------------------------------------------------------------------------------------*/


#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
  0x0000 usb2_host_reset(RW) : USB2_HOST_CTRL (Default : 0x0000_0000)
  [31:3]  Reserved                      0x0
  [2     ]  usb2_host_bus_reset    0x0  USB2.0 Host Controller Bus Reset Control
  [1     ]  usb2_host_core_reset  0x0   USB2.0 Host Controller Core Reset Control
  [0     ]  usb2_host_utmi_reset  0x0   USB2.0 Host Controller UTMI Reset Control
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  usb2_host_utmi_reset    :1,    // [0] default:0(USB2.0 Host Controller UTMI Reset Control)
  usb2_host_core_reset    :1,    // [1] default:0(USB2.0 Host Controller Core Reset Control)
  usb2_host_bus_reset     :1,    // [2] default:0(USB2.0 Host Controller Bus Reset Control)
  reserved_0              :29;   // [3:31] reserved
} USB2_HOST_RESET;

/*-----------------------------------------------------------------------------
  0x0004 usb2_host_param0(RW) : USB2_HOST_CTRL (Default : 0x0410_4F00)
  [31:30] Reserved                                  0x0
  [29    ]  app_start_clk_i                         0x0   " This is an asynchronous primary input to the host core.
                                                            When theOHCI clocks are suspended, the system has to
                                                            assert this signal to start theclocks (12 and 48 MHz).
                                                            This should be deasserted after the clocks arestarted
                                                            and before the host is suspended a"
  [28     ] ohci_susp_lgcy_i                        0x0     This is a static strap signal
  [27     ] ss_simulation_mode_i                    0x0     "When set to 1��b1, this bit sets the PHY in a non-driving
                                                             mode so the EHCI can detect device connection.
                                                             This signal is used only for simulation."
  [26:21] ss_fladj_val_host_i                       0x20     Frame Length Adjustment Register
  [20:15] ss_fladj_val_i                            0x20     Frame Length Adjustment Register per Port
  [14     ] ss_word_if_i                            0x0     "Selects the data width of the UTMI/UTMI+ PHY interface.
                                                                      b1:16 -bit interface,  b0: 8-bit interface"
  [13     ] ss_utmi_backward_enb_i                  0x0     UTMI Backward Enable
  [12     ] ss_resume_utmi_pls_dis_i                0x0     Resume Disable
  [11     ] ss_autoppd_on_overcur_en_i              0x0     Auto Port Power Disable on Overcurrent
  [10     ] ss_ena_incr16_i                         0x0     AHB Burst Type INCR16 Enable
  [9       ] ss_ena_incr8_i                         0x0     AHB Burst Type INCR8 Enable
  [8       ] ss_ena_incr4_i                         0x0     AHB Burst Type INCR4 Enable
  [7       ] ss_ena_incrx_align_i                   0x0     Burst Alignment Enable
  [6       ] app_prt_ovrcur_i                       0x0     Port Overcurrent Indication From Application
  [5       ] endian_ahbsl                           0x0     Control Bus Endian
  [4       ] endian_ahbms_ehci                      0x0     Control Bus Endian
  [3       ] endian_ahbms_ohci                      0x0     Control Bus Endian
  [2       ] endian_ahbms_ehci_bufacc               0x0      Control Bus Endian
  [1       ] endian_ahbms_ohci_bufacc               0x0      Control Bus Endian
  [0       ] ss_hubsetup_min_i                      0x0      Hub setup time control signal
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  ss_hubsetup_min_i               :1, // [0] default:0
  endian_ahbms_ohci_bufacc        :1, // [1] default:0
  endian_ahbms_ehci_bufacc        :1, // [2] default:0
  endian_ahbms_ohci               :1, // [3] default:0
  endian_ahbms_ehci               :1, // [4] default:0
  endian_ahbsl                    :1, // [5] default:0
  app_prt_ovrcur_i                :1, // [6] default:0
  ss_ena_incrx_align_i            :1, // [7] default:0
  ss_ena_incr4_i                  :1, // [8] default:0
  ss_ena_incr8_i                  :1, // [9] default:0
  ss_ena_incr16_i                 :1, // [10] default:0
  ss_autoppd_on_overcur_en_i      :1, // [11] default:0
  ss_resume_utmi_pls_dis_i        :1, // [12] default:0
  ss_utmi_backward_enb_i          :1, // [13] default:0
  ss_word_if_i                    :1, // [14] default:0
  ss_fladj_val_i                  :6, // [15:20] default:0x20
  ss_fladj_val_host_i             :6, // [21:26] default:0x20
  ss_simulation_mode_i            :1, // [27] default:0
  ohci_susp_lgcy_i                :1, // [28] default:0
  app_start_clk_i                 :1, // [29] default:0
  reserved_0                      :2; // [30:31] reserved
}USB2_HOST_PARAM_0;

/*-----------------------------------------------------------------------------
  0x0008 usb2_host_param1(RO) : USB2_HOST_CTRL (Default : 0x0000_0000)
    [31     ] ehci_bufacc_o               0x0   EHCI Buffer Access
    [30     ] ehci_pme_status_o           0x0   PME Status
    [29:26  ] ehci_lpsmc_state_o          0x0   "This signal indicates the state of the LPSMC module.
                                                 It is usedonly for debugging."
    [25:20  ] ehci_usbsts_o               0x0   USB Status
    [19     ] ehci_xfer_prdc_o            0x0    "Indicates that the current transfer of the EHCI master on the
                                                  AHB bus belongs to periodic descriptor/data."
    [18     ] ohci_0_globalsuspend_o      0x0   Host Controller is in Global Suspend State
    [17     ] ohci_0_drwe_o               0x0   Device Remote Wake-Up Enable
    [16     ] ohci_0_rwe_o                0x0   Remote Wake Up Enable
    [15     ] ohci_0_rmtwkp_o             0x0   Remote Wakeup Status
    [14     ] ohci_0_smi_o_n              0x0   HCI Bus System Management Interrupt
    [13     ] ohci_0_sof_o_n              0x0   Host Controller��s New Frame
    [12     ] ohci_0_bufacc_o             0x0   Host Controller Buffer Access Indicator
    [11     ] ehci_prt_pwr_o              0x0   Port Power
    [10:0   ] ehci_xfer_cnt_o             0x0   Transfer Count
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  ehci_xfer_cnt_o             :11,// [0:10] default:0
  echi_prt_pwr_o              :1, // [11] default:0
  ochi_0_bufacc_o             :1, // [12] default:0
  ohci_0_sof_o_n              :1, // [13] default:0
  ohci_0_smi_o_n              :1, // [14] default:0
  ohci_0_rmtwkp_o             :1, // [15] default:0
  ohci_0_rwe_o                :1, // [16] default:0
  ohci_0_drwe_o               :1, // [17] default:0
  ohci_0_globalsuspend_o      :1, // [18] default:0
  ehci_xfer_prdc_o            :1, // [19] default:0
  ehci_usbsts_o               :6, // [20:25] default:0
  ehci_lpsmc_state_o          :4, // [26:29] default:0
  ehci_pme_status_o           :1, // [30] default:0
  ehci_bufacc_o               :1; // [31] default:0
}USB2_HOST_PARAM_1;

/*-----------------------------------------------------------------------------
  0x000C usb2_host_param2(RO) : USB2_HOST_CTRL (Default : 0x0000_0000)
   [31:2] Reserved                           0x0
   [1     ] ehci_power_state_ack_o  0x0 Power State ACK
   [0     ] ohci_0_ccs_o                    0x0 Current Connect Status of Each Port
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  ohci_0_ccs_o            :1,  // [0] default:0
  ehci_power_stat_ack_o   :1,  // [1] default:0
  reserved_0              :30; // [2:31] reserved
}USB2_HOST_PARAM_2;

/*-----------------------------------------------------------------------------
  0x0010 usb2_host_param3(RO) : USB2_HOST_CTRL (Default : 0x0000_0000)
  [31:0 ] tc_from_hsusb0_mon  0x0 Debug.
------------------------------------------------------------------------------*/
typedef struct {
  UINT32  tc_from_hsusb0_mon;  // [0:31]  default:0
}USB2_HOST_PARAM_3;

/*-----------------------------------------------------------------------------
  0x0000 USB2 Phy Reset Control(RW) : USB2_PHY_CTRL (Default : 0x0000_0000)
  [31:1]  Reserved            0x0
    [0    ] usb2_phy_reset  0x0 USB2.0 PHY Reset Control
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  usb2_phy_reset                      :1, // [0] default:0(USB2.0 PHY Reset Control)
  reserved_0                          :31;// [1:31] reserved
}USB2_PHY_RESET;

/*-----------------------------------------------------------------------------
  0x0004 USB2_PHY_PARAM_0(RW) : USB2_PHY_CTRL (Default : 0x48CC_0734)
    [31     ] port_reset            0x0    Per-Port Reset
    [30:29] phy_refclksel           0x20  "This signal selects the reference clock source for the PLL block.
                                           b'11: Reserved
                                           b'10: The PLL uses CLKCORE as reference.
                                           b'01: The XO block uses an external, 2.5-V clock supplied on the XO pin.
                                           b'00: The XO block uses the clock from a crystal."
    [28     ] phy_commononn         0x0    Common Block Power-Down Control
    [27:25] phy_compdistune         0x4    Disconnect Threshold Adjustment
    [24:22] phy_sqrxtune            0x3    Squelch Threshold Adjustment
    [21:18] phy_txfslstune          0x3    FS/LS Source Impedance Adjustment
    [17:16] phy_txpreempamptune     0x0    HS Transmitter Pre-Emphasis Current Control
    [15     ] phy_txpreemppulsetune 0x0    HS Transmitter Pre-Emphasis Duration Control
    [14:13] phy_txrisetune          0x0    "HS Transmitter Rise/Fall Time AdjustmentFunction:
                                            This bus adjusts the rise/fall times of the high-speed waveform.
                                            b'11: 40%
                                            b'10: 20%
                                            b'01: Design default
                                            b'00: + 10%"
    [12:9 ] phy_txvreftune          0x3    "This bus adjusts the high-speed DC level voltage.
                                            b'1111: + 24%
                                            b'1110: + 22%
                                            b'1101: + 20%
                                            b'1100: + 18%
                                            b'1011: + 16%
                                            b'1010: + 14%
                                            b'1001: + 12%
                                            b'1000: + 10%
                                            b'0111: + 8%
                                            b'0110: + 6%
                                            b'0101: + 4%
                                            b'0100: + 2%
                                            b'0011: Design default
                                            b'0010: 2%
                                            b'0000:
    [8:7   ]  phy_txhsxvtune        0x2    "This bus adjusts the voltage at which the DP0 and DM0 signals
                                            cross while transmitting in HS mode.
                                            b'11: Default setting
                                            b'10: + 15 mV
                                            b'01:  15 mV
                                            b'00: Reserved
                                            Voltage Range: 0 V~DVDD"
    [6:5   ]  phy_txrestune         0x1    USB Source Impedance Adjustment
    [4:2   ]  phy_fsel              0x5    "Selects the USB 2.0 picoPHY reference clock frequency.
                                            b'111: 50 MHz
                                            b'110: Reserved
                                            b'101: 24 MHz
                                            b'100: 20 MHz
                                            b'011: 19.2 MHz
                                            b'010: 12 MHz
                                            b'001: 10 MHz
                                            b'000: 9.6 MHz"
    [0:1   ]  Reserved              0x0
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  reserved_0              :2, // [0:1] reserved
  phy_fsel                :3, // [2:4] default:0x5
  phy_txrestune           :2, // [5:6] default:0x1
  phy_txhsxvtune          :2, // [7:8] default:0x2
  phy_txvreftune          :4, // [9:12] default:0x3
  phy_txrisetune          :2, // [13:14] default:0
  phy_txpreemppulsetune   :1, // [15] default:0
  phy_txpreempamptune     :2, // [16:17] default:0x3
  phy_txfslstune          :4, // [18:21] default: 0x3
  phy_sqrxtune            :3, // [22:24] default:0x3
  phy_compdistune         :3, // [25:27] default:0x4
  phy_commononn           :1, // [28] default:0
  phy_refclksel           :2, // [29:30] default:0x20
  port_reset              :1; // [31] default:0
}USB2_PHY_PARAM_0;

typedef struct {
  UINT32
  reserved_0              :1, // [0] reserved
  phy_bt_por              :1, // [1] bt port power on reset
  phy_fsel                :3, // [2:4] default:0x5
  phy_txrestune           :2, // [5:6] default:0x1
  phy_txhsxvtune          :2, // [7:8] default:0x2
  phy_txvreftune          :4, // [9:12] default:0x3
  phy_txrisetune          :2, // [13:14] default:0
  phy_txpreemppulsetune   :1, // [15] default:0
  phy_txpreempamptune     :2, // [16:17] default:0x3
  phy_txfslstune          :4, // [18:21] default: 0x3
  phy_sqrxtune            :3, // [22:24] default:0x3
  phy_compdistune         :3, // [25:27] default:0x4
  phy_commononn           :1, // [28] default:0
  phy_refclksel           :2, // [29:30] default:0x20
  port_reset              :1; // [31] default:0
}USB2_BT_PHY_PARAM_0;
/*-----------------------------------------------------------------------------
  0x0008 USB2_PHY_PARAM_1(RW) : USB2_PHY_CTRL (Default : 0x0000_0000)
    [31   ]   phy_atereset        0x0   Reset Input from Automatic Test Equipment
    [30:29]   Reserved            0x0
    [28   ]   phy_testdataoutsel  0x0   Test Data Out Select
    [27:24]   phy_testaddr        0x0   Test Interface Register Address
    [23:16]   phy_testdatain      0x0   Test Data Write Bus
    [15:11]   Reserved            0x0
    [10   ]   phy_testclk         0x0   Test Clock
    [9    ]   phy_siddq           0x0   IDDQ Test Enable
    [8    ]   loopbackenb         0x0   Loopback Test Enable
    [7:6  ]   phy_vatestenb       0x0   Analog Test Pin Select
    [5    ]   phy_otgdisable      0x0   OTG Block Disable
    [4    ]   phy_bypassdpdata    0x0   Data for DP0 Transmitter Digital Bypass
    [3    ]   phy_bypassdmdata    0x0   Data for DM0 Transmitter Digital Bypass
    [2    ]   phy_bypassdpen      0x0   DP0 Transmitter Digital Bypass Enable
    [1    ]   phy_bypassdmen      0x0   DM0 Transmitter Digital Bypass Enable
    [0    ]   phy_bypasssel       0x0   Transmitter Digital Bypass Select
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  phy_bypasssel        :1, // [0] default:0
  phy_bypassdmen       :1, // [1] default:0
  phy_bypassdpen       :1, // [2] default:0
  phy_bypassdmdata     :1, // [3] default:0
  phy_bypassdpdata     :1, // [4] default:0
  phy_otgdisable       :1, // [5] default:0
  phy_vatestenb        :2, // [6:7] default:0
  loopbackenb          :1, // [8] default:0
  phy_siddq            :1, // [9] default:0
  phy_testclk          :1, // [10] default:0
  reserved_0           :5, // [11:15] reserved
  phy_testdatain       :8, // [16:23] default:0
  phy_testaddr         :4, // [24:27] default:0
  phy_testdataoutsel   :1, // [28] default:0
  reserved_1           :2, // [29:30] reserved
  phy_atereset         :1; // [31] default:0
}USB2_PHY_PARAM_1;

/*-----------------------------------------------------------------------------
  0x000c USB2_PHY_PARAM_2(RO) : USB2_PHY_CTRL (Default : 0x0000_0000)
    [31:4]  Reserved          0x0
    [3:0 ]  phy_testdataout   0x0 Test Data Read Bus

------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  phy_testdataout             :4, // [0:3] default:0
  reserved_0                  :28;// [4:31] reserved
}USB2_PHY_PARAM_2;

/*-----------------------------------------------------------------------------
  0x0000 USB3_HOST_RESET(RO) : USB3_HOST_CTRL (Default : 0x0000_0000)
  [31:20] Reserved  0x0
  [1    ] usb3_host_bus_reset   0x0 USB3.0 HOST Bus Reset Control
  [0    ] usb3_host_core_reset  0x0 USB3.0 HOST Core Reset Control
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  usb3_host_core_reset    :1, // [0] default:0(USB3.0 HOST Core Reset Control)
  usb3_host_bus_reset     :1, // [1] default:0(USB3.0 HOST Core Reset Control)
  reserved_0              :30;// [2:31] reserved
}USB3_HOST_RESET;

/*-----------------------------------------------------------------------------
  0x0004 USB3_HOST_PARAM_0(RW) : USB3_HOST_CTRL (Default : 0x0000_40E0)
  [31:17] Reserved                           0x0
  [16   ] bigendian_gs                       0x0  Slave Big Endian Select
  [15   ] host_msi_enable                    0x0  "This enables the pulse type interrupt signal (one bus clock cycle)on
                                                   interrupt port instead of level-sensitive interrupt. When interfacing to PCIe,
												   this allows you to easily map ��interrupt�� to MSI in the PCIe controller."
  [14   ] host_port_power_control_present    0x1
  [13   ] host_u2_port_disable               0x0  USB2.0 Port Disable control
  [12   ] host_u3_port_disable               0x0  USB3.0 Port Disable control0
  [11   ] hub_oc_inv                         0x0  inverse Over-current input signal
  [10:9 ] hub_port_perm_attach               0x0  "Indicates if the device attached to a downstream port is
                                                   permanently attached or not."
  [8    ] hub_vbus_inv                       0x0  inverse DCDC control output signal
  [7    ] xhc_bme                            0x1  "This signal is used to disable the bus masteringcapability of the xHC.
                                                   In a PCI system, it comes from the BusMaster Enable (BME) bit of
                                                   the Device Control Register in the PCIConfiguration register space."
  [6    ] xhci_revision                      0x1  "This signal is used to select the xHCI revision that thehost controller
                                                   complies with.
												   1'b0: The host controller complies with the xHCI revision 0.96
                                                   1.b1: The host controller complies with the xHCI revision 1.0"
  [5:0  ] fladj_30mhz_reg                    0x20 HS Jitter Adjustment
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  fladj_30mhz_reg                   :6, // [0:5] default:0x20
  xhci_revision                     :1, // [6] default:0x1
  xhc_bme                           :1, // [7] default:0x1
  hub_vbus_inv                      :1, // [8] default:0
  hub_port_perm_attach              :2, // [9:10] default:0
  hub_oc_inv                        :1, // [11] default:0
  host_u3_port_disable              :1, // [12] default:0
  host_u2_port_disable              :1, // [13] default:0
  host_post_power_control_present   :1, // [14] default:0x1
  host_msi_enable                   :1, // [15] default:0
  bigendian_gs                      :1, // [16] default:0
  reserved_0                        :15; // [17:31] reserved
}USB3_HOST_PARAM_0;

/*-----------------------------------------------------------------------------
  0x0008 USB3_HOST_PARAM_1(RO) : USB3_HOST_CTRL (Default : 0x0000_0000)
  [31:0]  debug_info  0x0 This signal is used for debug purpose
------------------------------------------------------------------------------*/
typedef struct {
  UINT32  debug_info; // [0:31] default:0
}USB3_HOST_PARAM_1;

/*-----------------------------------------------------------------------------
  0x000C USB3_HOST_PARAM_2(RO) : USB3_HOST_CTRL (Default : 0x0000_0000)
  [31:0]  debug_info  0x0 This signal is used for debug purpose
------------------------------------------------------------------------------*/
typedef struct {
  UINT32 debug_info; // [0:31] default:0
}USB3_HOST_PARAM_2;

/*-----------------------------------------------------------------------------
  0x0010 USB3_HOST_PARAM_3(RO) : USB3_HOST_CTRL (Default : 0x0000_0000)
  [31:0]  logic_trace  0x0 This signal is used for debug purpose
------------------------------------------------------------------------------*/
typedef struct {
  UINT32 logic_trace; // [0:31] default:0
}USB3_HOST_PARAM_3;

/*-----------------------------------------------------------------------------
  0x0014 USB3_HOST_PARAM_4(RO) : USB3_HOST_CTRL (Default : 0x0000_0000)
  [31:0]  logic_trace  0x0 This signal is used for debug purpose
------------------------------------------------------------------------------*/
typedef struct {
  UINT32 logic_trace; // [0:31] default:0
}USB3_HOST_PARAM_4;

/*-----------------------------------------------------------------------------
  0x0018 USB3_HOST_PARAM_5(RO) : USB3_HOST_CTRL (Default : 0x0000_0000)
  [31:12] Reserved          0x0
  [11:0 ] host_current_belt 0x0 Current BELT Value
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  host_current_belt     :12, // [0:11] default:0
  reserved_0            :20; // [12:31] reserved
}USB3_HOST_PARAM_5;

/*-----------------------------------------------------------------------------
  0x001C USB3_HOST_PARAM_6(RW) : USB3_HOST_CTRL (Default : 0x0000_0000)
  [31:8] Reserved  0x0 
  [7:4 ] aruser    0x0 AXI Bus ArUser Signal
  [3:0 ] awuser    0x0 AXI Bus AxUser Signal
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
  awuser        :4, // [0:3] default:0
  aruwer        :4, // [4:7] default:0
  reserved_0   :24; // [8:31] reserved
}USB3_HOST_PARAM_6;

/*-----------------------------------------------------------------------------
  0x0000 USB3_PHY_RESET(RO) : USB3_PHY_CTRL (Default : 0x0000_0000)
  [31  ]  usb3phy_ref_clk_sel   0x0 USB3 PHY Reference Clock Sel
                                    b'0: xtal ,
                                    b'1: internal Clock from PLL
  [30:1]  Reserved              0x0
  [0   ]  usb3_phy_reset        0x0 USB3.0 PHY Reset Control
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    usb3_phy_reset          :1, // [0] default:0(USB3.0 Phy reset control)
    reserved_0              :30,// [1:30] reserved
    usb3_phy_ref_clk_sel    :1; // [31] default:0(0:xtar, 1:internel clock from PLL)
}USB3_PHY_RESET;

/*-----------------------------------------------------------------------------
  0x0004 USB3_PHY_PARAM_0(RW) : USB3_PHY_CTRL (Default : 0x0000_03A8)
  [31     ]  phy_atereset            0x0     Reset Input from Automatic Test Equipment
  [30     ]  phy_loopbkenb           0x0     Loopback Test Enable
  [29     ]  phy_test_powerdown_hsp  0x0     HS Function Circuits Power-Down Control
  [28     ]  phy_test_powerdown_ssp  0x0     SS Function Circuits Power-Down Control
  [27:26  ]  phy_vatestenb           0x0     Analog Test Pin Select
  [25     ]  phy_otgdisable          0x0     OTG Block Disable
  [24     ]  phy_adpchrg             0x0     VBUS Input ADP Charge Enable
  [23     ]  phy_adpdischrg          0x0     VBUS Input ADP Discharge Enable
  [22     ]  phy_adpprbenb           0x0     ADP Probe Indicator
  [21     ]  phy_bypassdpdata        0x0     Data for DP<#> Transmitter Digital Bypass
  [20     ]  phy_bypassdmdata        0x0     Data for DM<#> Transmitter Digital Bypass
  [19     ]  phy_bypassdpen          0x0     DP<#> Transmitter Digital Bypass Enable
  [18     ]  phy_bypassdmen          0x0     DM<#> Transmitter Digital Bypass Enable
  [17     ]  phy_bypasssel           0x0     Transmitter Digital Bypass Select
  [16:12  ]  Reserved                0x0
  [11     ]  phy_lane0_ext_pclk_req  0x0     External PIPE Clock Enable Request
  [10     ]  phy_lane0_tx2rx_loopbk  0x0     Loopback
  [9      ]  phy_commononn           0x1     Block Power-Down Control
  [8      ]  phy_retenablen          0x1     Lowered Digital Supply Indicator
  [7:2    ]  phy_fsel                0x2A    Frequency Select
  [1      ]  phy_mpll_refssc_clk_en  0x0     Spread Reference Clock Output
  [0      ]  Reserved                0x0
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    reserved_0                   :1, // [0] reserved
    phy_mpll_refssc_clk_en       :1, // [1] default:0
    phy_fsel                     :6, // [2:7] default:0x2A
    phy_retenablen               :1, // [8] default:0x1
    phy_commononn                :1, // [9] default:0x1
    phy_lane0_tx2rx_loopbk       :1, // [10] default:0
    phy_lane0_ext_pclk_req       :1, // [11] default:0
    reserved_1                   :5, // [12:16] reserved
    phy_bypasssel                :1, // [17] default:0
    phy_bypassdmen               :1, // [18] default:0
    phy_bypassdpen               :1, // [19] default:0
    phy_bypassdmdata             :1, // [20] default:0
    phy_bypassdpdata             :1, // [21] default:0
    phy_adpprbenb                :1, // [22] default:0
    phy_adpdischrg               :1, // [23] default:0
    phy_adpchrg                  :1, // [24] default:0
    phy_otgdisable               :1, // [25] default:0
    phy_vatestenb                :2, // [26:27] default:0
    phy_test_powerdown_ssp       :1, // [28] default:0
    phy_test_powerdown_hsp       :1, // [29] default:0
    phy_loopbkenb                :1, // [30] default:0
    phy_atereset                 :1; // [31] default:0
}USB3_PHY_PARAM_0;

/*-----------------------------------------------------------------------------
  0x0008 USB3_PHY_PARAM_1(RW) : USB3_PHY_CTRL (Default : 0xD0A1_0923)
[31:25]  phy_mpll_multiplier   0x68     MPLL Frequency Multiplier Control
[24   ]  phy_ref_clkdiv2       0x0      Input Reference Clock Divider Control
[23   ]  phy_ref_ssp_en        0x1      Reference Clock Enable for SS function
[22   ]  phy_ref_use_pad       0x0      Select Reference Clock Connected to ref_pad_clk_{p,m}
[21   ]  phy_ssc_en            0x1      Spread Spectrum Enable
[20:18]  phy_ssc_range         0x0      Spread Spectrum Clock Range
[17:9 ]  phy_ssc_ref_clk_sel   0x84     Spread Spectrum Reference Clock Shifting
[8:6  ]  phy_compdistune       0x4      Disconnect Threshold Adjustment
[5:3  ]  phy_otgtune           0x4      VBUS Valid Threshold Adjustment
[2:0  ]  phy_sqrxtune          0x3      Squelch Threshold Adjustment
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    phy_sqrxtune                        :3, // [0:2] default:0x3
    phy_otgtune                         :3, // [3:5] default:0x4
    phy_compdistune                     :3, // [6:8] default:0x4
    phy_ssc_ref_clk_sel                 :9, // [9:17]  default:0x84
    phy_ssc_range                       :3, // [18:20]  default:0x0
    phy_ssc_en                          :1, // [21] default:0x1
    phy_ref_use_pad                     :1, // [22] default:0x0
    phy_ref_ssp_en                      :1, // [23]  default:0x1
    phy_ref_clkdiv2                     :1, // [24] default:0x0
    phy_mpll_multiplier                 :7; // [25:31]  default:0x68
}USB3_PHY_PARAM_1;

/*-----------------------------------------------------------------------------
  0x000C USB3_PHY_PARAM_2(RW) : USB3_PHY_CTRL (Default : 0x3C29_A550)
  [31:28]  phy_txfslstune           0x3     FS/LS Source Impedance Adjustment
  [27:26]  phy_txhsxvtune           0x3     Transmitter High-Speed Crossover Adjustment
  [25:24]  phy_txpreempamptune      0x0     HS Transmitter Pre-Emphasis Current Control
  [23   ]  phy_txpreemppulsetune    0x0     HS Transmitter Pre-Emphasis Duration Control
  [22:21]  phy_txrestune            0x1     USB Source Impedance Adjustment
  [20:19]  phy_txrisetune           0x1     HS Transmitter Rise/Fall Time Adjustment
  [18:15]  phy_txvreftune           0x3     HS DC Voltage Level Adjustment
  [14:10]  phy_los_level            0x9     Loss-of-Signal Detector Sensitivity Level Control
  [9:4  ]  phy_pcs_tx_deemph_3p5db  0x15    Tx De-Emphasis at 3.5 dB
  [3    ]  Reserved                 0x0
  [2:0  ]  phy_tx_vboost_lvl        0x0     Tx Voltage Boost Level
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    phy_tx_vboost_lvl                    :3,// [0:2] default:0x0
    reserved_0                           :1,// [3] reserved
    phy_pcs_tx_deemph_3p5db              :6,// [4:9]  default:  0x15
    phy_los_level                        :5,// [10:14]   default:  0x9
    phy_txvreftune                       :4,// [15:18]  default:  0x3
    phy_txrisetune                       :2,// [19:20]  default:  0x1
    phy_txrestune                        :2,// [21:22]  default:  0x1
    phy_txpreemppulsetune                :1,// [23] default:  0x0
    phy_txpreempamptune                  :2,// [24:25]  default:  0x0
    phy_txhsxvtune                       :2,// [26:27] default:  0x3
    phy_txfslstune                       :4;// [28:31] default:0x3
}USB3_PHY_PARAM_2;

/*-----------------------------------------------------------------------------
  0x0010 USB3_PHY_PARAM_3(RW) : USB3_PHY_CTRL (Default : 0x0020_BC00)
  [31:22]  Reserved                 0x0
  [21:16]  phy_pcs_tx_deemph_6db    0x20   Tx De-Emphasis at 6 dB
  [15:9 ]  phy_pcs_tx_swing_full    0x5D   Tx Amplitude (Full Swing Mode)
  [8:4  ]  phy_lane0_tx_term_offset 0x0    Transmitter Termination Offset
  [3:1  ]  phy_los_bias             0x0    Loss-of-Signal Detector Threshold Level Control
  [0    ]  phy_rtune_req            0x0    Resistor Tune Request
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    phy_rtune_req               :1, // [0] default: 0x0
    phy_los_bias                :3, // [3:1] default: 0x0
    phy_lane0_tx_term_offset    :5, // [8:4] default: 0x0
    phy_pcs_tx_swing_full       :7, // [15:9] default: 0x5D
    phy_pcs_tx_deemph_6db       :6, // [21:16] default: 0x20
    reserved_0                  :10;// [31:22] reserved
}USB3_PHY_PARAM_3;

/*-----------------------------------------------------------------------------
  0x0014 USB3_PHY_PARAM_4(RW) : USB3_PHY_CTRL (Default : 0x0000_0000)
  [31:20]  Reserved
  [19    ]  phy_cr_cap_addr      0x0   CR Capture Address
  [18    ]  phy_cr_cap_data      0x0   CR Capture Data
  [17    ]  phy_cr_read          0x0   CR Read
  [16    ]  phy_cr_write         0x0   CR Write
  [15:0  ]  phy_cr_data_in       0x0   CR Address and Write Data Input Bus
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    phy_cr_data_in      :16, // [15:0] default:0x0
    phy_cr_write        :1,  // [16] default:0x0
    phy_cr_read         :1,  // [17] default:0x0
    phy_cr_cap_data     :1,  // [18] default:0x0
    phy_cr_cap_addr     :1,  // [19] default:0x0
    reserved_0          :12; // [31:20] reserved
}USB3_PHY_PARAM_4;

/*-----------------------------------------------------------------------------
  0x0018 USB3_PHY_PARAM_5(RO) : USB3_PHY_CTRL (Default : 0x0000_0000)
  [31   ]  phy_rtune_ack      0x0   Resistor Tune Acknowledge
  [30:17]  Reserved           0x0
  [16   ]  phy_cr_ack         0x0   CR Acknowledgement
  [15:0 ]  phy_cr_data_out    0x0   CR Data Output Bus
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    phy_cr_data_out  :16,// [15:0] default :0x0
    phy_cr_ack       :1, //[16] default :0x00
    reserved_0       :14,// [30:17] reserved
    phy_rtune_ack    :1; // [31] default : 0x0
}USB3_PHY_PARAM_5;

/*-----------------------------------------------------------------------------
  0x001C USB3_PHY_PARAM_6(RW) : USB3_PHY_CTRL (Default : 0x0000_0000)
  [31:10] Reserved  0x0
  [9:0  ] phy_pcs_rx_los_mask_val 0x0 "Sets the number of reference clock cycles to mask theincoming LFPS.
          For normal operation, set to a targeted maskinterval of 10 ��s
          (value = 10 ��s / Tref_clk).
          If the ref_clkdiv2signal is used,
          the value = 10 ��s / (2 * Tref_clk)."
------------------------------------------------------------------------------*/
typedef struct {
  UINT32
    phy_pcs_rx_los_mask_val :10, // [0:9] default:0x0
    Reserved_0              :22; // [10:31] reserved
}USB3_PHY_PARAM_6;

typedef struct {
  USB2_HOST_RESET           usb2_host_reset;  // 0x0000
  USB2_HOST_PARAM_0         usb2_host_param0; // 0x0004
  USB2_HOST_PARAM_1         usb2_host_param1; // 0x0008
  USB2_HOST_PARAM_2         usb2_host_param2; // 0x000C
  USB2_HOST_PARAM_3         usb2_host_param3; // 0x0010
}USB2_HOST_CTRL;

typedef struct {
  USB2_PHY_RESET            usb2_phy_reset;   //0x0000
  USB2_PHY_PARAM_0          usb2_phy_param0;  //0x0004
  USB2_PHY_PARAM_1          usb2_phy_param1;  //0x0008
  USB2_PHY_PARAM_2          usb2_phy_param2;  //0x000C
}USB2_PHY_CTRL;

typedef struct {
  USB2_BT_PHY_PARAM_0          usb2_phy_param0;  //0x0000
  USB2_PHY_PARAM_1          usb2_phy_param1;  //0x0004
}USB2_BT_PHY_CTRL;

typedef struct {
  USB3_HOST_RESET           usb3_host_reset;  // 0x0000
  USB3_HOST_PARAM_0         usb3_host_param0; // 0x0004
  USB3_HOST_PARAM_1         usb3_host_param1; // 0x0008
  USB3_HOST_PARAM_2         usb3_host_param2; // 0x000C
  USB3_HOST_PARAM_3         usb3_host_param3; // 0x0010
  USB3_HOST_PARAM_4         usb3_host_param4; // 0x0014
  USB3_HOST_PARAM_5         usb3_host_param5; // 0x0018
  USB3_HOST_PARAM_6         usb3_host_param6; // 0x001C
}USB3_HOST_CTRL;

typedef struct {
  USB3_PHY_RESET            usb3_phy_reset;   // 0x0000
  USB3_PHY_PARAM_0          usb3_phy_param0;  // 0x0004
  USB3_PHY_PARAM_1          usb3_phy_param1;  // 0x0008
  USB3_PHY_PARAM_2          usb3_phy_param2;  // 0x000C
  USB3_PHY_PARAM_3          usb3_phy_param3;  // 0x0010
  USB3_PHY_PARAM_4          usb3_phy_param4;  // 0x0014
  USB3_PHY_PARAM_5          usb3_phy_param5;  // 0x0018
  USB3_PHY_PARAM_6          usb3_phy_param6;  // 0x001C
}USB3_PHY_CTRL;


typedef struct {
  USB2_PHY_CTRL *pPhy;
  USB2_HOST_CTRL *pHost;
}USB2_CTRL_REG_T;

typedef struct {
  USB2_BT_PHY_CTRL *pPhy;
  USB2_HOST_CTRL *pHost;
}USB2_BT_CTRL_REG_T;


typedef struct {
  USB3_PHY_CTRL *pPhy;
  USB3_HOST_CTRL *pHost;
}USB3_CTRL_REG_T;

#ifdef __cplusplus
}
#endif

#endif  /* _USB_TOP_REGS_H_*/

