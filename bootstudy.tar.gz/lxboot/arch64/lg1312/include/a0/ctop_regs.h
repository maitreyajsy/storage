#ifndef __CTOP_CTRL_REG_M16A0_H__
#define __CTOP_CTRL_REG_M16A0_H__

/*----------------------------------------------------------------------------------------
    Control Constants
----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
    File Inclusions
----------------------------------------------------------------------------------------*/


#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
	0xc8c70000 crg_vdec000 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	vd_mcu_clk_gate_en              : 1,	//     0
	vd_msvc_clk_gate_en             : 1,	//     1
	vd_g2_clk_gate_en               : 1,	//     2
	vd_g2a_clk_gate_en              : 1,	//     3
	vd_axi_clk_gate_en              : 1,	//     4
	vd_mem_clk_gate_en              : 1,	//     5
	te_clk_gate_en                  : 1,	//     6
	soc_clk_gate_en                 : 1,	//     7
	soc_528_clk_gate_en             : 1,	//     8
	                                : 9,	//  9:17 reserved
	vd_mem_clk_sel                  : 1,	//    18
	sysclk_sel                      : 6,	// 19:24
	soc_clk_sel                     : 1,	//    25
	soc_528_clk_sel                 : 1;	//    26
} VDEC0_SYN_CRG_VDEC000_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c70004 crg_vdec001 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_mcu                       : 1,	//     0
	swrst_vd                        : 1,	//     1
	swrst_g2                        : 1,	//     2
	swrst_g2a                       : 1,	//     3
	swrst_vda                       : 1,	//     4
	swrst_mem                       : 1,	//     5
	swrst_te                        : 1,	//     6
	swrst_sys                       : 6,	//  7:12
	swrst_soc                       : 1,	//    13
	swrst_soc_528                   : 1;	//    14
} VDEC0_SYN_CRG_VDEC001_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c71000 crg_vdec100 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	vd_clk_gate_en                  : 1,	//     0
	hevc_clk_gate_en                : 1,	//     1
	g1_clk_gate_en                  : 1,	//     2
	ed_clk_gate_en                  : 1,	//     3
	soc_clk_gate_en                 : 1,	//     4
	soc_528_clk_gate_en             : 1,	//     5
	                                :10,	//  6:15 reserved
	vd_clk_sel                      : 1,	//    16
	soc_clk_sel                     : 1,	//    17
	soc_528_clk_sel                 : 1;	//    18
} VDEC1_SYN_CRG_VDEC100_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c71004 crg_vdec101 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_vd                        : 1,	//     0
	swrst_ed                        : 1,	//     1
	swrst_hevc                      : 1,	//     2
	swrst_g1                        : 1,	//     3
	swrst_soc                       : 1,	//     4
	swrst_soc_528                   : 1,	//     5
	swrst_hevc_spr                  : 1,	//     6
	                                : 9,	//  7:15 reserved
	swrst_vdec1_vdec2_adapter       : 1;	//    16
} VDEC1_SYN_CRG_VDEC101_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c72000 crg_vdec200 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	vd_clk_gate_en                  : 1,	//     0
	hevc_clk_gate_en                : 1,	//     1
	g1_clk_gate_en                  : 1,	//     2
	ed_clk_gate_en                  : 1,	//     3
	soc_clk_gate_en                 : 1,	//     4
	                                :11,	//  5:15 reserved
	vd_clk_sel                      : 1,	//    16
	soc_clk_sel                     : 1;	//    17
} VDEC2_SYN_CRG_VDEC200_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c72004 crg_vdec201 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_vd                        : 1,	//     0
	swrst_ed                        : 1,	//     1
	swrst_hevc                      : 1,	//     2
	swrst_g1                        : 1,	//     3
	swrst_soc                       : 1,	//     4
	swrst_hevc_spr                  : 1,	//     5
	                                :10,	//  6:15 reserved
	swrst_vdec2_vdec1_adapter       : 1;	//    16
} VDEC2_SYN_CRG_VDEC201_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c20000 crg_lbus00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	axi_396clk_gate_en              : 1,	//     0
	axi_528clk_gate_en              : 1,	//     1
	soc_clk_gate_en                 : 1,	//     2
	                                :13,	//  3:15 reserved
	axi_528clk_sel                  : 1,	//    16
	soc_clk_sel                     : 1;	//    17
} LBUS_SYN_CRG_LBUS00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c20004 crg_lbus01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_axi_396                   : 1,	//     0
	swrst_axi_528                   : 1,	//     1
	swrst_soc                       : 1;	//     2
} LBUS_SYN_CRG_LBUS01_M16A0;

/*-----------------------------------------------------------------------------
	0xc830b000 crg_gbus00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	axi_clk_gate_en                 : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	                                :14,	//  2:15 reserved
	soc_clk_sel                     : 1;	//    16
} GBUS_SYN_CRG_GBUS00_M16A0;

/*-----------------------------------------------------------------------------
	0xc830b004 crg_gbus01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_axi                       : 1,	//     0
	swrst_soc                       : 1;	//     1
} GBUS_SYN_CRG_GBUS01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8306000 crg_vsd00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	det_clk_gate_en                 : 1,	//     2
	disp_h3d_le_clk_gate_en         : 1,	//     3
	disp_stb_clk_gate_en            : 1,	//     4
	                                :11,	//  5:15 reserved
	det_sel                         : 2,	// 16:17
	soc_clk_sel                     : 1,	//    18
	disp_stb_clk_sel                : 2;	// 19:20
} VSD_SYN_CRG_VSD00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8306004 crg_vsd01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1,	//     1
	swrst_soc                       : 1,	//     2
	swrst_disp_h3d_le               : 1,	//     3
	swrst_det                       : 1,	//     4
	swrst_disp_le                   : 1,	//     5
	swrst_disp_ro                   : 1,	//     6
	swrst_disp_stb                  : 1,	//     7
	                                : 8,	//  8:15 reserved
	vsd_shp_detour_en               : 1,	//    16
	vsd_h3d_detour_en               : 1,	//    17
	vsd_h3d_detour_swap             : 1;	//    18
} VSD_SYN_CRG_VSD01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8306008 crg_vsd02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_gsc_vsd_sc0_cc            : 1,	//     0
	swrst_gsc_vsd_sc0_yy            : 1,	//     1
	swrst_gsc_vsd_sc1_cc            : 1,	//     2
	swrst_gsc_vsd_sc1_yy            : 1,	//     3
	swrst_sr_vsd_y                  : 1;	//     4
} VSD_SYN_CRG_VSD02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8304000 crg_nd000 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1;	//     0
} ND0_SYN_CRG_ND000_M16A0;

/*-----------------------------------------------------------------------------
	0xc8304004 crg_nd001 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1;	//     1
} ND0_SYN_CRG_ND001_M16A0;

/*-----------------------------------------------------------------------------
	0xc8304008 crg_nd002 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_imx_nd0_cc                : 1,	//     0
	swrst_imx_nd0_yy                : 1;	//     1
} ND0_SYN_CRG_ND002_M16A0;

/*-----------------------------------------------------------------------------
	0xc8303000 crg_imx00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	vdo0_clk_gate_en                : 1,	//     1
	vdo1_clk_gate_en                : 1,	//     2
	soc_clk_gate_en                 : 1,	//     3
	                                :12,	//  4:15 reserved
	cve27_inv_sel                   : 1,	//    16
	soc_clk_sel                     : 1;	//    17
} IMX_SYN_CRG_IMX00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8303004 crg_imx01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1,	//     1
	swrst_vdo0                      : 1,	//     2
	swrst_vdo1                      : 1,	//     3
	swrst_cve27                     : 1,	//     4
	swrst_soc                       : 1;	//     5
} IMX_SYN_CRG_IMX01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8303008 crg_imx02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_cvi_imx0                  : 1,	//     0
	swrst_gsc_imx_msf_data          : 1,	//     1
	swrst_cco_imx_gcf_data          : 1;	//     2
} IMX_SYN_CRG_IMX02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8301000 crg_gsc00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	                                :14,	//  2:15 reserved
	soc_clk_sel                     : 1;	//    16
} GSC_SYN_CRG_GSC00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8301004 crg_gsc01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1,	//     1
	swrst_soc                       : 1;	//     2
} GSC_SYN_CRG_GSC01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8301008 crg_gsc02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_nd0_gsc_c                 : 1,	//     0
	swrst_nd0_gsc_y                 : 1;	//     1
} GSC_SYN_CRG_GSC02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8302000 crg_cvi00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	cvi0_clk_gate_en                : 1,	//     1
	cvi1_clk_gate_en                : 1,	//     2
	cvi2_clk_gate_en                : 1,	//     3
	cvi3_clk_gate_en                : 1,	//     4
	soc_clk_gate_en                 : 1,	//     5
	                                : 2,	//  6: 7 reserved
	soc_clk_sel                     : 1,	//     8
	hdmi0_clk_sel                   : 1,	//     9
	hdmi1_clk_sel                   : 1,	//    10
	hdmi2_clk_sel                   : 1,	//    11
	cvi0_clk_sel                    : 3,	// 12:14
	cvi1_clk_sel                    : 3,	// 15:17
	cvi2_clk_sel                    : 3,	// 18:20
	cvi3_clk_sel                    : 3,	// 21:23
	phy1_ppll_inv_sel               : 1,	//    24
	phy2_ppll_inv_sel               : 1,	//    25
	phy3_ppll_inv_sel               : 1,	//    26
	ch3pix_inv_sel                  : 1,	//    27
	cvd54_inv_sel                   : 1;	//    28
} CVI_SYN_CRG_CVI00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8302004 crg_cvi01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1,	//     1
	swrst_soc                       : 1,	//     2
	swrst_hdmi0                     : 1,	//     3
	swrst_hdmi0_link                : 1,	//     4
	swrst_hdmi1                     : 1,	//     5
	swrst_hdmi1_link                : 1,	//     6
	swrst_hdmi2                     : 1,	//     7
	swrst_hdmi2_link                : 1,	//     8
	swrst_ch3pix                    : 1,	//     9
	swrst_cvd54                     : 1,	//    10
	swrst_cvd27                     : 1,	//    11
	swrst_cvd_vbi                   : 1,	//    12
	swrst_cvd_mif                   : 1,	//    13
	swrst_cvi0                      : 1,	//    14
	swrst_cvi1                      : 1,	//    15
	swrst_cvi2                      : 1,	//    16
	swrst_cvi3                      : 1;	//    17
} CVI_SYN_CRG_CVI01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8302008 crg_cvi02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_sub_cvi_cve_cvbs          : 1;	//     0
} CVI_SYN_CRG_CVI02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8307000 crg_cco00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	det_clk_gate_en                 : 1,	//     2
	sosd_clk_gate_en                : 1,	//     3
	disp_stb_clk_gate_en            : 1,	//     4
	                                :11,	//  5:15 reserved
	soc_clk_sel                     : 1,	//    16
	det_sel                         : 2,	// 17:18
	sosd_sel                        : 2,	// 19:20
	disp_stb_clk_sel                : 2;	// 21:22
} CCO_SYN_CRG_CCO00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8307004 crg_cco01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1,	//     1
	swrst_soc                       : 1,	//     2
	swrst_det                       : 1,	//     3
	swrst_disp_le                   : 1,	//     4
	swrst_disp_ro                   : 1,	//     5
	swrst_sosd                      : 1,	//     6
	swrst_disp_stb                  : 1,	//     7
	                                : 8,	//  8:15 reserved
	cpu_cco_detour_en               : 1;	//    16
} CCO_SYN_CRG_CCO01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8305000 crg_sre00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	sre_clk_gate_en                 : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	soc_297_clk_gate_en             : 1,	//     2
	disp_stb_clk_gate_en            : 1,	//     3
	soc_osd_clk_gate_en             : 1,	//     4
	                                :11,	//  5:15 reserved
	soc_clk_sel                     : 1,	//    16
	soc_297_clk_sel                 : 2,	// 17:18
	                                : 1,	//    19 reserved
	disp_stb_clk_sel                : 2,	// 20:21
	soc_osd_clk_sel                 : 2;	// 22:23
} SRE_SYN_CRG_SRE00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8305004 crg_sre01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_sre                       : 1,	//     0
	swrst_shs                       : 1,	//     1
	swrst_soc                       : 1,	//     2
	swrst_soc_297                   : 1,	//     3
	swrst_disp_stb                  : 1,	//     4
	swrst_soc_osd                   : 1,	//     5
	                                :13,	//  6:18 reserved
	isolate_shs                     : 1,	//    19
	isolate_sre                     : 1;	//    20
} SRE_SYN_CRG_SRE01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8305008 crg_sre02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_vsd_sre                   : 1;	//     0
} SRE_SYN_CRG_SRE02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8300000 crg_mcu00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	                                :14,	//  2:15 reserved
	soc_clk_sel                     : 1;	//    16
} MCU_SYN_CRG_MCU00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8300004 crg_mcu01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_cpuapb                    : 1,	//     0
	swrst_mcu                       : 1,	//     1
	swrst_soc                       : 1;	//     2
} MCU_SYN_CRG_MCU01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309000 crg_fmc00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	soc_297_clk_gate_en             : 1,	//     2
	disp_stb_clk_gate_en            : 1,	//     3
	soc_osd_clk_gate_en             : 1,	//     4
	                                :11,	//  5:15 reserved
	soc_clk_sel                     : 1,	//    16
	soc_297_clk_sel                 : 2,	// 17:18
	disp_stb_clk_sel                : 2,	// 19:20
	soc_osd_clk_sel                 : 2;	// 21:22
} FMC_SYN_CRG_FMC00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309004 crg_fmc01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1,	//     1
	swrst_soc                       : 1,	//     2
	swrst_soc_297                   : 1,	//     3
	swrst_disp_stb                  : 1,	//     4
	swrst_soc_osd                   : 1,	//     5
	swrst_de_spr                    : 1;	//     6
} FMC_SYN_CRG_FMC01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309008 crg_fmc02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_fme_fmc_data              : 1;	//     0
} FMC_SYN_CRG_FMC02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8308000 crg_fme00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	core_clk_gate_en                : 1,	//     0
	soc_clk_gate_en                 : 1,	//     1
	                                :14,	//  2:15 reserved
	soc_clk_sel                     : 1;	//    16
} FME_SYN_CRG_FME00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8308004 crg_fme01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_de                        : 1,	//     0
	swrst_axi                       : 1,	//     1
	swrst_soc                       : 1,	//     2
	swrst_de_spr                    : 1;	//     3
} FME_SYN_CRG_FME01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c30000 crg_m000 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_sw_phy                      : 1,	//     0
	reg_sw_m                        : 1,	//     1
	reg_sw_reg_if                   : 1,	//     2
	ref_sw_apb                      : 1,	//     3
	reg_sw_bus                      : 1;	//     4
} M0_SYN_CRG_M000_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c40000 crg_m100 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_sw_phy                      : 1,	//     0
	reg_sw_m                        : 1,	//     1
	reg_sw_reg_if                   : 1,	//     2
	ref_sw_apb                      : 1,	//     3
	reg_sw_bus                      : 1;	//     4
} M1_SYN_CRG_M100_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c10000 crg_gfx00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	gfx_aclk_gate_en                : 1,	//     0
	gfx_cclk_gate_en                : 1,	//     1
	soc_clk_gate_en                 : 1,	//     2
	soc_528_clk_gate_en             : 1,	//     3
	                                :12,	//  4:15 reserved
	gfx_cclk_sel                    : 1,	//    16
	soc_clk_sel                     : 1,	//    17
	soc_528_clk_sel                 : 1;	//    18
} GFX_SYN_CRG_GFX00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c10004 crg_gfx01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_gfxa                      : 1,	//     0
	swrst_gfxc                      : 1,	//     1
	swrst_soc                       : 1,	//     2
	swrst_soc_528                   : 1;	//     3
} GFX_SYN_CRG_GFX01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73000 crg_venc00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	ve_clk_gate_en                  : 1,	//     0
	                                :15,	//  1:15 reserved
	ve_clk_sel                      : 1;	//    16
} VENC_SYN_CRG_VENC00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73004 crg_venc01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_ve                        : 1;	//     0
} VENC_SYN_CRG_VENC01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50400 crg_aud00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	aud_aclk_gate_en                : 1,	//     0
	aud_teclk_gate_en               : 1,	//     1
	soc_clk_gate_en                 : 1,	//     2
	                                :13,	//  3:15 reserved
	soc_clk_sel                     : 1;	//    16
} AUD_SYN_CRG_AUD00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50404 crg_aud01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_soc                       : 1;	//     0
} AUD_SYN_CRG_AUD01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50408 crg_aud02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 2,	//  0: 1 reserved
	swrst_gstcs                     : 1;	//     2
} AUD_SYN_CRG_AUD02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60800 crg_te00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	te_clk_gate_en                  : 1,	//     0
	ch0_sclk_gate_en                : 1,	//     1
	ch1_sclk_gate_en                : 1,	//     2
	ch2_sclk_gate_en                : 1,	//     3
	ch3_sclk_gate_en                : 1,	//     4
	stpo_clk_gate_en                : 1,	//     5
	te_ciout_clk_gate_en            : 1,	//     6
	icod_clk_gate_en                : 1,	//     7
	                                : 4,	//  8:11 reserved
	ch0_sclk_sel                    : 1,	//    12
	ch1_sclk_sel                    : 1,	//    13
	ch2_sclk_sel                    : 1,	//    14
	ch3_sclk_sel                    : 1,	//    15
	stpo_clk_sel                    : 3,	// 16:18
	te_ciout_clk_sel                : 3,	// 19:21
	tpi0_clk_inv_sel                : 1,	//    22
	tpi1_clk_inv_sel                : 1,	//    23
	tpi2_clk_inv_sel                : 1,	//    24
	tpi3_clk_inv_sel                : 1,	//    25
	                                : 1,	//    26 reserved
	stpi0_clk_inv_sel               : 1,	//    27
	stpi1_clk_inv_sel               : 1;	//    28
} TE_SYN_CRG_TE00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60804 crg_te01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_axi                       : 1,	//     0
	swrst_ch0_s                     : 1,	//     1
	swrst_ch1_s                     : 1,	//     2
	swrst_ch2_s                     : 1,	//     3
	swrst_ch3_s                     : 1,	//     4
	swrst_f_s                       : 1,	//     5
	swrst_temcu                     : 1,	//     6
	swrst_te                        : 1,	//     7
	swrst_stop                      : 1,	//     8
	swrst_ciout                     : 1,	//     9
	swrst_icod_jpeg                 : 1,	//    10
	                                : 5,	// 11:15 reserved
	swrst_gstc_adapter              : 1,	//    16
	swrst_te_vdec_0_adapter         : 1,	//    17
	swrst_te_vdec_1_adapter         : 1,	//    18
	swrst_te_aud_0_adapter          : 1,	//    19
	swrst_te_aud_1_adapter          : 1;	//    20
} TE_SYN_CRG_TE01_M16A0;

/*-----------------------------------------------------------------------------
	0xc830d000 crg_hdmi00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	phy0_tmdsrx_inv_sel             : 1,	//     0
	phy1_tmdsrx_inv_sel             : 1,	//     1
	phy2_tmdsrx_inv_sel             : 1,	//     2
	phy0_pixfifo_inv_sel            : 1,	//     3
	phy1_pixfifo_inv_sel            : 1,	//     4
	phy2_pixfifo_inv_sel            : 1,	//     5
	phy_i2c_clk_sel                 : 1,	//     6
	hdmirx_comm_spab_clk_sel        : 1,	//     7
	swrst_bus                       : 1;	//     8
} HDMI_SYN_CRG_HDMI00_M16A0;

/*-----------------------------------------------------------------------------
	0xc830d004 crg_hdmi01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_hdmirx_prt0_main          : 1,	//     0
	swrst_hdmirx_prt0_sapb          : 1,	//     1
	swrst_hdmirx_prt0_iapb          : 1,	//     2
	swrst_hdmirx_prt0_iapb_top      : 1,	//     3
	swrst_hdmirx_prt0_iapb_hdmi     : 1,	//     4
	swrst_hdmirx_prt0_iapb_crc      : 1,	//     5
	swrst_hdmirx_prt0_esm           : 1,	//     6
	swrst_hdmirx_prt0_edid          : 1,	//     7
	swrst_hdmirx_prt1_main          : 1,	//     8
	swrst_hdmirx_prt1_sapb          : 1,	//     9
	swrst_hdmirx_prt1_iapb          : 1,	//    10
	swrst_hdmirx_prt1_iapb_top      : 1,	//    11
	swrst_hdmirx_prt1_iapb_hdmi     : 1,	//    12
	swrst_hdmirx_prt1_iapb_crc      : 1,	//    13
	swrst_hdmirx_prt1_esm           : 1,	//    14
	swrst_hdmirx_prt1_edid          : 1,	//    15
	swrst_hdmirx_prt2_main          : 1,	//    16
	swrst_hdmirx_prt2_sapb          : 1,	//    17
	swrst_hdmirx_prt2_iapb          : 1,	//    18
	swrst_hdmirx_prt2_iapb_top      : 1,	//    19
	swrst_hdmirx_prt2_iapb_hdmi     : 1,	//    20
	swrst_hdmirx_prt2_iapb_crc      : 1,	//    21
	swrst_hdmirx_prt2_esm           : 1,	//    22
	swrst_hdmirx_prt2_edid          : 1,	//    23
	                                : 5,	// 24:28 reserved
	dbg_sel2                        : 1,	//    29
	dbg_sel1                        : 1,	//    30
	dbg_sel0                        : 1;	//    31
} HDMI_SYN_CRG_HDMI01_M16A0;

/*-----------------------------------------------------------------------------
	0xc830d008 crg_hdmi02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_hdmirx_prt2_mhlrx_sapb    : 1,	//     0
	swrst_hdmirx_prt2_mhlrx_link    : 1,	//     1
	swrst_hdmirx_prt2_mhlrx_hdcp    : 1,	//     2
	swrst_hdmirx_prt2_mhlrx_edid    : 1,	//     3
	swrst_hdmirx_prt2_mhlrx_tmds    : 1,	//     4
	swrst_hdmirx_prt2_mhlrx_pix     : 1,	//     5
	swrst_hdmirx_prt2_mhlrx_aud     : 1,	//     6
	swrst_hdmirx_prt2_mhlrx_vfifo_w : 1,	//     7
	swrst_hdmirx_prt2_mhlrx_afifo_w : 1,	//     8
	swrst_hdmirx_prt2_mhlrx_vfifo_r : 1,	//     9
	swrst_hdmirx_prt2_mhlrx_afifo_r : 1,	//    10
	                                : 5,	// 11:15 reserved
	swrst_hdmirx_prt0_phy_pixfifo   : 1,	//    16
	swrst_hdmirx_prt1_phy_pixfifo   : 1,	//    17
	swrst_hdmirx_prt2_phy_pixfifo   : 1,	//    18
	                                : 1,	//    19 reserved
	swrst_acr0                      : 1,	//    20
	swrst_acr1                      : 1,	//    21
	swrst_acr2                      : 1;	//    22
} HDMI_SYN_CRG_HDMI02_M16A0;

/*-----------------------------------------------------------------------------
	0xc830d00c ctop_hdmi03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	hdmi_arcache_1                  : 1,	//     0
	hdmi_awcache_1                  : 1,	//     1
	                                : 2,	//  2: 3 reserved
	hdmi0_bus_gating_r              : 1,	//     4
	hdmi0_bus_gating_w              : 1,	//     5
	                                : 2,	//  6: 7 reserved
	hdmi1_bus_gating_r              : 1,	//     8
	hdmi1_bus_gating_w              : 1,	//     9
	                                : 2,	// 10:11 reserved
	hdmi2_bus_gating_r              : 1,	//    12
	hdmi2_bus_gating_w              : 1;	//    13
} HDMI_SYN_CTOP_HDMI03_M16A0;

/*-----------------------------------------------------------------------------
	0xc830d010 ctop_hdmi04 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	hdmi0_flush_en                  : 1,	//     0
	hdmi1_flush_en                  : 1,	//     1
	hdmi2_flush_en                  : 1,	//     2
	                                : 1,	//     3 reserved
	uart_sel                        : 2;	//  4: 5
} HDMI_SYN_CTOP_HDMI04_M16A0;

/*-----------------------------------------------------------------------------
	0xc830d014 ctop_hdmi05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	hdmi0_flush_done                : 1,	//     0
	hdmi1_flush_done                : 1,	//     1
	hdmi2_flush_done                : 1,	//     2
	                                : 1,	//     3 reserved
	hdmi0_rd_cmd_vio                : 1,	//     4
	hdmi0_wr_cmd_vio                : 1,	//     5
	hdmi0_wr_data_vio               : 1,	//     6
	                                : 1,	//     7 reserved
	hdmi1_rd_cmd_vio                : 1,	//     8
	hdmi1_wr_cmd_vio                : 1,	//     9
	hdmi1_wr_data_vio               : 1,	//    10
	                                : 1,	//    11 reserved
	hdmi2_rd_cmd_vio                : 1,	//    12
	hdmi2_wr_cmd_vio                : 1,	//    13
	hdmi2_wr_data_vio               : 1;	//    14
} HDMI_SYN_CTOP_HDMI05_M16A0;

/*-----------------------------------------------------------------------------
	0xc8205000 crg_gpu ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_gpu_core                  : 1,	//     0
	                                : 3,	//  1: 3 reserved
	swrst_gpu_xtal                  : 1,	//     4
	                                : 3,	//  5: 7 reserved
	gpu_clk_sel                     : 1;	//     8
} GPU_SYN_CRG_GPU_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a000 crg_dpe00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	led_pxl_clk_gate_en             : 1,	//     0
	tcon_axi_clk_gate_en            : 1,	//     1
	tcon_pix2_clk_gate_en           : 1,	//     2
	tcon_pix_clk_gate_en            : 1,	//     3
	tcon_osd_clk_gate_en            : 1,	//     4
	tcon_comp_clk_gate_en           : 1,	//     5
	tcon_hcic_clk_gate_en           : 1,	//     6
	dpe_pxl_clk_gate_en             : 1,	//     7
	                                : 8,	//  8:15 reserved
	led_pxl_clk_sel                 : 2,	// 16:17
	tcon_pix2_clk_sel               : 2,	// 18:19
	tcon_pix_clk_sel                : 3,	// 20:22
	tcon_osd_clk_sel                : 2,	// 23:24
	tcon_comp_clk_sel               : 2,	// 25:26
	tcon_hcic_clk_sel               : 1,	//    27
	led_apb_clk_sel                 : 1,	//    28
	dpe_pxl_clk_sel                 : 2;	// 29:30
} DPE_SYN_CRG_DPE00_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a004 crg_dpe01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_led_pxl                   : 1,	//     0
	swrst_tcon_axi                  : 1,	//     1
	swrst_tcon_pix2                 : 1,	//     2
	swrst_tcon_pix                  : 1,	//     3
	swrst_tcon_osd                  : 1,	//     4
	swrst_tcon_comp                 : 1,	//     5
	swrst_tcon_hcic                 : 1,	//     6
	swrst_dpe_pxl                   : 1,	//     7
	swrst_d2s_in                    : 1,	//     8
	swrst_d2s_out                   : 1,	//     9
	                                : 6,	// 10:15 reserved
	vid_3x1_sel                     : 2,	// 16:17
	                                :11,	// 18:28 reserved
	tcon_flush_en                   : 1;	//    29
} DPE_SYN_CRG_DPE01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230000 crg_cpuperi00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	bus1_clk_gate_en                : 1,	//     0
	bus2_clk_gate_en                : 1,	//     1
	ahb6_clk_gate_en                : 1,	//     2
	ahb8_clk_gate_en                : 1,	//     3
	ahb9_clk_gate_en                : 1,	//     4
	cssysclk_gate_en                : 1,	//     5
	tsclk_gate_en                   : 1,	//     6
	cpu_bus_clk_gate_en             : 1,	//     7
	tz_apb_clk_gate_en              : 1;	//     8
} PERI_SYN_CRG_CPUPERI00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230004 crg_cpuperi01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	bus1_sel                        : 1,	//     0
	bus2_sel                        : 1,	//     1
	ahb0_sel                        : 1,	//     2
	ahb6_sel                        : 1,	//     3
	ahb8_sel                        : 1,	//     4
	ahb9_sel                        : 1,	//     5
	cssys_sel                       : 1,	//     6
	ts_sel                          : 1,	//     7
	cpu_bus_sel                     : 1,	//     8
	tz_apb_clk_sel                  : 1,	//     9
	rmii_clkoff_sel                 : 1,	//    10
	rx_clkoff_sel                   : 1,	//    11
	txclk_sel                       : 1,	//    12
	rxclk_sel                       : 1;	//    13
} PERI_SYN_CRG_CPUPERI01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230008 crg_cpuperi02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_bus_0                     : 1,	//     0
	swrst_bus_1                     : 1,	//     1
	swrst_bus_2                     : 1,	//     2
	swrst_bus_3                     : 1,	//     3
	swrst_bus_4                     : 1,	//     4
	swrst_bus_5                     : 1,	//     5
	swrst_bus_6                     : 1,	//     6
	swrst_bus_7                     : 1,	//     7
	swrst_bus_8                     : 1,	//     8
	swrst_bus_9                     : 1,	//     9
	swrst_bus_10                    : 1;	//    10
} PERI_SYN_CRG_CPUPERI02_M16A0;

/*-----------------------------------------------------------------------------
	0xc823000c crg_cpuperi03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_ahb_0                     : 1,	//     0
	swrst_ahb_1                     : 1,	//     1
	swrst_ahb_2                     : 1,	//     2
	swrst_ahb_3                     : 1,	//     3
	swrst_ahb_4                     : 1,	//     4
	swrst_ahb_5                     : 1,	//     5
	swrst_ahb_6                     : 1,	//     6
	swrst_ahb_7                     : 1,	//     7
	swrst_ahb_8                     : 1,	//     8
	swrst_ahb_9                     : 1,	//     9
	swrst_ahb_10                    : 1,	//    10
	swrst_ahb_11                    : 1;	//    11
} PERI_SYN_CRG_CPUPERI03_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230010 crg_cpuperi04 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_apb0_0                    : 1,	//     0
	swrst_apb0_1                    : 1,	//     1
	swrst_apb0_2                    : 1,	//     2
	swrst_apb0_3                    : 1,	//     3
	swrst_apb0_4                    : 1,	//     4
	swrst_apb0_5                    : 1,	//     5
	swrst_apb0_6                    : 1,	//     6
	swrst_apb0_7                    : 1,	//     7
	swrst_apb0_8                    : 1,	//     8
	swrst_apb0_9                    : 1,	//     9
	swrst_apb0_10                   : 1;	//    10
} PERI_SYN_CRG_CPUPERI04_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230014 crg_cpuperi05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_apb1_0                    : 1,	//     0
	swrst_apb1_1                    : 1,	//     1
	swrst_apb1_2                    : 1,	//     2
	swrst_apb1_3                    : 1,	//     3
	swrst_apb1_4                    : 1,	//     4
	swrst_apb1_5                    : 1,	//     5
	swrst_apb1_6                    : 1,	//     6
	swrst_apb1_7                    : 1,	//     7
	swrst_apb1_8                    : 1,	//     8
	swrst_apb1_9                    : 1,	//     9
	swrst_apb1_10                   : 1,	//    10
	swrst_apb1_11                   : 1,	//    11
	swrst_apb1_12                   : 1,	//    12
	swrst_apb1_13                   : 1,	//    13
	swrst_apb1_14                   : 1,	//    14
	swrst_apb1_15                   : 1,	//    15
	swrst_apb1_16                   : 1,	//    16
	swrst_apb1_17                   : 1,	//    17
	swrst_apb1_18                   : 1,	//    18
	swrst_apb1_19                   : 1,	//    19
	swrst_apb1_20                   : 1,	//    20
	swrst_apb1_21                   : 1;	//    21
} PERI_SYN_CRG_CPUPERI05_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230018 crg_cpuperi06 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_cssys                     : 1,	//     0
	swrst_ts                        : 1,	//     1
	swrst_cnt                       : 1,	//     2
	swrst_tz_apb                    : 1,	//     3
	swrst_cpu_bus                   : 1,	//     4
	swrst_gem_tx                    : 1,	//     5
	swrst_gem_rgmii_tx              : 1,	//     6
	swrst_gem_rx                    : 1,	//     7
	swrst_gem_rgmii_rx              : 1,	//     8
	swrst_gem_rmii_ref              : 1;	//     9
} PERI_SYN_CRG_CPUPERI06_M16A0;

/*-----------------------------------------------------------------------------
	0xc823001c crg_cpuperi07 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	emmc_flush_en                   : 1,	//     0
	usb_flush_en                    : 1,	//     1
	                                : 2,	//  2: 3 reserved
	adapter_pchkerr                 : 1,	//     4
	apb1_pchkerr                    : 1,	//     5
	apb1_pchkerr_sel                : 1;	//     6
} PERI_SYN_CRG_CPUPERI07_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230020 snapietro_crg0 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_cpu0_reset                  : 1,	//     0
	reg_cpu1_reset                  : 1,	//     1
	reg_cpu2_reset                  : 1,	//     2
	reg_cpu3_reset                  : 1,	//     3
	reg_core0_reset                 : 1,	//     4
	reg_core1_reset                 : 1,	//     5
	reg_core2_reset                 : 1,	//     6
	reg_core3_reset                 : 1,	//     7
	reg_dbg_preset                  : 1,	//     8
	reg_l2_reset                    : 1,	//     9
	reg_a_reset                     : 1,	//    10
	reg_at_reset                    : 1,	//    11
	reg_cnt_reset                   : 1,	//    12
	reg_clk_reset                   : 1,	//    13
	                                : 2,	// 14:15 reserved
	cpu_clk_sel                     : 1;	//    16
} PERI_SYN_SNAPIETRO_CRG0_M16A0;

/*-----------------------------------------------------------------------------
	0xc8230024 snapietro_crg1 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	pclkdbg_sel                     : 1,	//     0
	                                : 3,	//  1: 3 reserved
	cntclk_sel                      : 1,	//     4
	                                : 3,	//  5: 7 reserved
	atclk_sel                       : 1,	//     8
	                                : 7,	//  9:15 reserved
	cg_pclkdbg                      : 1,	//    16
	                                : 3,	// 17:19 reserved
	cg_cntclk                       : 1,	//    20
	                                : 3,	// 21:23 reserved
	cg_atclk                        : 1;	//    24
} PERI_SYN_SNAPIETRO_CRG1_M16A0;

/*-----------------------------------------------------------------------------
	0xc1cf0038 crg_emmc ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	emmc_clk_gate_en                : 1,	//     0
	nand_clk_gate_en                : 1,	//     1
	                                : 2,	//  2: 3 reserved
	emmc_core_clk_sel               : 1,	//     4
	                                : 3,	//  5: 7 reserved
	swrst_emmc_core                 : 1,	//     8
	swrst_emmc_pdb                  : 1,	//     9
	swrst_nand_core                 : 1;	//    10
} EMMC_SYN_CRG_EMMC_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309400 ctop_r00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 3,	//  0: 2 reserved
	reg_epi_eo_pd                   : 1,	//     3
	                                : 3,	//  4: 6 reserved
	reg_epi_gclk_pd                 : 1,	//     7
	                                : 3,	//  8:10 reserved
	reg_epi_mclk_pd                 : 1,	//    11
	                                : 3,	// 12:14 reserved
	reg_epi_vst_pd                  : 1,	//    15
	                                : 1,	//    16 reserved
	reg_ext_intr0_pu                : 1,	//    17
	                                : 3,	// 18:20 reserved
	reg_ext_intr1_pu                : 1,	//    21
	                                : 3,	// 22:24 reserved
	reg_ext_intr2_pu                : 1,	//    25
	                                : 3,	// 26:28 reserved
	reg_ext_intr3_pu                : 1;	//    29
} CTOP_FMC_CTOP_R00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309404 ctop_r01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 2,	//  0: 1 reserved
	reg_pcmi3lrck_pd                : 1,	//     2
	                                : 3,	//  3: 5 reserved
	reg_pcmi3sck_pd                 : 1,	//     6
	                                : 4,	//  7:10 reserved
	reg_pwm_in_pu                   : 1,	//    11
	                                : 3,	// 12:14 reserved
	reg_pwm2_pu                     : 1,	//    15
	                                : 3,	// 16:18 reserved
	reg_pwm1_pu                     : 1,	//    19
	                                : 3,	// 20:22 reserved
	reg_pwm0_pu                     : 1,	//    23
	                                : 3,	// 24:26 reserved
	reg_l_vsout_ld_pd               : 1,	//    27
	                                : 3,	// 28:30 reserved
	reg_epi_soe_pd                  : 1;	//    31
} CTOP_FMC_CTOP_R01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309408 ctop_r02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 3,	//  0: 2 reserved
	reg_gpio17_pd                   : 1,	//     3
	                                : 3,	//  4: 6 reserved
	reg_gpio16_pd                   : 1,	//     7
	                                : 3,	//  8:10 reserved
	reg_dim1_sclk_pd                : 1,	//    11
	                                : 3,	// 12:14 reserved
	reg_dim1_mosi_pd                : 1,	//    15
	                                : 3,	// 16:18 reserved
	reg_dim0_sclk_pd                : 1,	//    19
	                                : 3,	// 20:22 reserved
	reg_dim0_mosi_pd                : 1,	//    23
	                                : 3,	// 24:26 reserved
	reg_frc_lrsync_pu               : 1,	//    27
	                                : 2,	// 28:29 reserved
	reg_pcmi3lrch_pd                : 1;	//    30
} CTOP_FMC_CTOP_R02_M16A0;

/*-----------------------------------------------------------------------------
	0xc830940c ctop_r03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 8,	//  0: 7 reserved
	reserved                        : 1,	//     8
	reserved_1                      : 1,	//     9
	reserved_2                      : 1,	//    10
	reg_gpio23_pd                   : 1,	//    11
	reserved_3                      : 1,	//    12
	reserved_4                      : 1,	//    13
	reserved_5                      : 1,	//    14
	reg_gpio22_pd                   : 1,	//    15
	reserved_6                      : 1,	//    16
	reserved_7                      : 1,	//    17
	reserved_8                      : 1,	//    18
	reg_gpio21_pd                   : 1,	//    19
	reserved_9                      : 1,	//    20
	reserved_10                     : 1,	//    21
	reg_gpio20_pd                   : 1,	//    22
	reserved_11                     : 1,	//    23
	reserved_12                     : 1,	//    24
	reserved_13                     : 1,	//    25
	reg_gpio19_pd                   : 1,	//    26
	reserved_14                     : 1,	//    27
	reserved_15                     : 1,	//    28
	reserved_16                     : 1,	//    29
	reserved_17                     : 1,	//    30
	reg_gpio18_pd                   : 1;	//    31
} CTOP_FMC_CTOP_R03_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309410 ctop_r04 ''
------------------------------------------------------------------------------*/
/*	no field */

/*-----------------------------------------------------------------------------
	0xc8309414 ctop_r05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :12,	//  0:11 reserved
	gp10_0_mux_en                   : 1,	//    12
	gp10_5_mux_en                   : 1,	//    13
	gp10_6_mux_en                   : 1,	//    14
	gp10_7_mux_en                   : 1,	//    15
	                                : 4,	// 16:19 reserved
	gp8_4_mux_en                    : 1,	//    20
	gp8_5_mux_en                    : 1,	//    21
	gp8_6_mux_en                    : 1,	//    22
	gp8_7_mux_en                    : 1,	//    23
	gp7_0_mux_en                    : 1,	//    24
	gp7_1_mux_en                    : 1,	//    25
	gp7_2_mux_en                    : 1,	//    26
	gp7_3_mux_en                    : 1,	//    27
	gp7_4_mux_en                    : 1,	//    28
	gp7_5_mux_en                    : 1,	//    29
	gp7_6_mux_en                    : 1,	//    30
	gp7_7_mux_en                    : 1;	//    31
} CTOP_FMC_CTOP_R05_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309418 ctop_r06 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	displl_fine_div                 : 1,	//     1
	displl_dss                      : 1,	//     2
	displl_accuracy                 : 2,	//  3: 4
	displl_updn_max                 : 7,	//  5:11
	displl_mod_freq                 : 9,	// 12:20
	displl_m                        : 6,	// 21:26
	reserved                        : 1,	//    27
	displl_cih                      : 4;	// 28:31
} CTOP_FMC_CTOP_R06_M16A0;

/*-----------------------------------------------------------------------------
	0xc830941c ctop_r07 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	displl_ofs_mode                 : 1,	//     4
	displl_fout3_od                 : 3,	//  5: 7
	displl_fout2_od                 : 3,	//  8:10
	displl_fout_od                  : 2,	// 11:12
	displl_pre_fout3_div            : 3,	// 13:15
	displl_pre_fout2_div            : 3,	// 16:18
	displl_nsc                      : 4,	// 19:22
	displl_npc                      : 6,	// 23:28
	displl_fine_control             : 3;	// 29:31
} CTOP_FMC_CTOP_R07_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309420 ctop_r08 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :22,	//  0:21 reserved
	displl_wakeup_bypass            : 1,	//    22
	displl_ddr_mode                 : 1,	//    23
	displl_offset                   : 8;	// 24:31
} CTOP_FMC_CTOP_R08_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309424 ctop_r09 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	pqepll_fine_div                 : 1,	//     1
	pqepll_dss                      : 1,	//     2
	pqepll_accuracy                 : 2,	//  3: 4
	pqepll_updn_max                 : 7,	//  5:11
	pqepll_mod_freq                 : 9,	// 12:20
	pqepll_m                        : 6,	// 21:26
	reserved                        : 1,	//    27
	pqepll_cih                      : 4;	// 28:31
} CTOP_FMC_CTOP_R09_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309428 ctop_r10 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	pqepll_ofs_mode                 : 1,	//     4
	pqepll_fout3_od                 : 3,	//  5: 7
	pqepll_fout2_od                 : 3,	//  8:10
	pqepll_fout_od                  : 2,	// 11:12
	pqepll_pre_fout3_div            : 3,	// 13:15
	pqepll_pre_fout2_div            : 3,	// 16:18
	pqepll_nsc                      : 4,	// 19:22
	pqepll_npc                      : 6,	// 23:28
	pqepll_fine_control             : 3;	// 29:31
} CTOP_FMC_CTOP_R10_M16A0;

/*-----------------------------------------------------------------------------
	0xc830942c ctop_r11 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 9,	//  0: 8 reserved
	jtag1_disable_mid_normal        : 1,	//     9
	jtag0_disable_normal            : 1,	//    10
	aud_multi_ch_en                 : 1,	//    11
	gp10_4_mux_en                   : 1,	//    12
	gp10_3_mux_en                   : 1,	//    13
	gp10_2_mux_en                   : 1,	//    14
	gp10_1_mux_en                   : 1,	//    15
	                                : 6,	// 16:21 reserved
	pqepll_wakeup_bypass            : 1,	//    22
	pqepll_ddr_mode                 : 1,	//    23
	pqepll_offset                   : 8;	// 24:31
} CTOP_FMC_CTOP_R11_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309430 ctop_r12 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_FMC_CTOP_R12_M16A0;

/*-----------------------------------------------------------------------------
	0xc8309434 ctop_r13 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 8,	//  0: 7 reserved
	reserved                        : 1,	//     8
	reserved_1                      : 1,	//     9
	reserved_2                      : 1,	//    10
	reg_daclrch_pu                  : 1,	//    11
	reserved_3                      : 1,	//    12
	reserved_4                      : 1,	//    13
	reserved_5                      : 1,	//    14
	reg_dacclfch_pu                 : 1,	//    15
	reserved_6                      : 1,	//    16
	reserved_7                      : 1,	//    17
	reserved_8                      : 1,	//    18
	reg_dacslrch_pu                 : 1,	//    19
	reserved_9                      : 1,	//    20
	reserved_10                     : 1,	//    21
	reserved_11                     : 1,	//    22
	reg_dacsck_pu                   : 1,	//    23
	reserved_12                     : 1,	//    24
	reserved_13                     : 1,	//    25
	reserved_14                     : 1,	//    26
	reg_daclrck_pu                  : 1,	//    27
	reserved_15                     : 1,	//    28
	reserved_16                     : 1,	//    29
	reserved_17                     : 1,	//    30
	reg_audclk_out_pd               : 1;	//    31
} CTOP_FMC_CTOP_R13_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73400 ctop_r00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	m1pll_fine_div                  : 1,	//     1
	m1pll_dss                       : 1,	//     2
	m1pll_accuracy                  : 2,	//  3: 4
	m1pll_updn_max                  : 7,	//  5:11
	m1pll_mod_freq                  : 9,	// 12:20
	m1pll_m                         : 6,	// 21:26
	reserved                        : 1,	//    27
	m1pll_cih                       : 4;	// 28:31
} CTOP_VENC_CTOP_R00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73404 ctop_r01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	m1pll_ofs_mode                  : 1,	//     4
	m1pll_fout3_od                  : 3,	//  5: 7
	m1pll_fout2_od                  : 3,	//  8:10
	m1pll_fout_od                   : 2,	// 11:12
	m1pll_pre_fout3_div             : 3,	// 13:15
	m1pll_pre_fout2_div             : 3,	// 16:18
	m1pll_nsc                       : 4,	// 19:22
	m1pll_npc                       : 6,	// 23:28
	m1pll_fine_control              : 3;	// 29:31
} CTOP_VENC_CTOP_R01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73408 ctop_r02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :22,	//  0:21 reserved
	m1pll_wakeup_bypass             : 1,	//    22
	m1pll_ddr_mode                  : 1,	//    23
	m1pll_offset                    : 8;	// 24:31
} CTOP_VENC_CTOP_R02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c7340c ctop_r03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	m2pll_fine_div                  : 1,	//     1
	m2pll_dss                       : 1,	//     2
	m2pll_accuracy                  : 2,	//  3: 4
	m2pll_updn_max                  : 7,	//  5:11
	m2pll_mod_freq                  : 9,	// 12:20
	m2pll_m                         : 6,	// 21:26
	reserved                        : 1,	//    27
	m2pll_cih                       : 4;	// 28:31
} CTOP_VENC_CTOP_R03_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73410 ctop_r04 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	m2pll_ofs_mode                  : 1,	//     4
	m2pll_fout3_od                  : 3,	//  5: 7
	m2pll_fout2_od                  : 3,	//  8:10
	m2pll_fout_od                   : 2,	// 11:12
	m2pll_pre_fout3_div             : 3,	// 13:15
	m2pll_pre_fout2_div             : 3,	// 16:18
	m2pll_nsc                       : 4,	// 19:22
	m2pll_npc                       : 6,	// 23:28
	m2pll_fine_control              : 3;	// 29:31
} CTOP_VENC_CTOP_R04_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73414 ctop_r05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :22,	//  0:21 reserved
	m2pll_wakeup_bypass             : 1,	//    22
	m2pll_ddr_mode                  : 1,	//    23
	m2pll_offset                    : 8;	// 24:31
} CTOP_VENC_CTOP_R05_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73418 ctop_r06 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	gpupll_fine_div                 : 1,	//     1
	gpupll_dss                      : 1,	//     2
	gpupll_accuracy                 : 2,	//  3: 4
	gpupll_updn_max                 : 7,	//  5:11
	gpupll_mod_freq                 : 9,	// 12:20
	gpupll_m                        : 6,	// 21:26
	reserved                        : 1,	//    27
	gpupll_cih                      : 4;	// 28:31
} CTOP_VENC_CTOP_R06_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c7341c ctop_r07 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	gpupll_ofs_mode                 : 1,	//     4
	gpupll_fout3_od                 : 3,	//  5: 7
	gpupll_fout2_od                 : 3,	//  8:10
	gpupll_fout_od                  : 2,	// 11:12
	gpupll_pre_fout3_div            : 3,	// 13:15
	gpupll_pre_fout2_div            : 3,	// 16:18
	gpupll_nsc                      : 4,	// 19:22
	gpupll_npc                      : 6,	// 23:28
	gpupll_fine_control             : 3;	// 29:31
} CTOP_VENC_CTOP_R07_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73420 ctop_r08 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :22,	//  0:21 reserved
	gpupll_wakeup_bypass            : 1,	//    22
	gpupll_ddr_mode                 : 1,	//    23
	gpupll_offset                   : 8;	// 24:31
} CTOP_VENC_CTOP_R08_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73424 ctop_r09 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :25,	//  0:24 reserved
	te_dco_g_ctrl                   : 3,	// 25:27
	te_dco_lpf_ctrl                 : 2,	// 28:29
	reserved                        : 1,	//    30
	te_dco_rom_test_ctrl            : 1;	//    31
} CTOP_VENC_CTOP_R09_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73428 ctop_r10 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :25,	//  0:24 reserved
	pqe_dco_g_ctrl                  : 3,	// 25:27
	pqe_dco_lpf_ctrl                : 2,	// 28:29
	reserved                        : 1,	//    30
	pqe_dco_rom_test_ctrl           : 1;	//    31
} CTOP_VENC_CTOP_R10_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c7342c ctop_r11 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_VENC_CTOP_R11_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73430 ctop_r12 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_VENC_CTOP_R12_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73434 ctop_r13 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :28,	//  0:27 reserved
	txclkdrv2_icon_normal           : 3,	// 28:30
	txclkdrv2_pdb_normal            : 1;	//    31
} CTOP_VENC_CTOP_R13_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73438 ctop_r14 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :17,	//  0:16 reserved
	ck_mux_pll_sel_lbus             : 1,	//    17
	reserved                        : 1,	//    18
	ck_mux_pll_sel_m1               : 1,	//    19
	ck_mux_pll_sel_m0               : 1,	//    20
	ck_mux_pll_sel_g2               : 1,	//    21
	ck_mux_pll_sel_usb              : 1,	//    22
	reserved_1                      : 1,	//    23
	ck_mux_pll_sel_dco              : 1,	//    24
	ck_mux_pll_sel_gpu              : 1,	//    25
	ck_mux_pll_sel_core             : 1,	//    26
	reserved_2                      : 1,	//    27
	reserved_3                      : 1,	//    28
	reserved_4                      : 1,	//    29
	reserved_5                      : 1,	//    30
	reserved_6                      : 1;	//    31
} CTOP_VENC_CTOP_R14_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c7343c ctop_r15 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	swrst_demod                     : 1,	//     4
	swrst_hdmi                      : 1,	//     5
	swrst_venc                      : 1,	//     6
	swrst_vdec2                     : 1,	//     7
	swrst_vdec1                     : 1,	//     8
	swrst_vdec0                     : 1,	//     9
	swrst_usb                       : 1,	//    10
	swrst_te                        : 1,	//    11
	swrst_pqe_vsd                   : 1,	//    12
	swrst_pqe_sre                   : 1,	//    13
	swrst_pqe_nd0                   : 1,	//    14
	swrst_pqe_mcu                   : 1,	//    15
	swrst_pqe_imx                   : 1,	//    16
	swrst_pqe_gsc                   : 1,	//    17
	swrst_pqe_fme                   : 1,	//    18
	swrst_pqe_fmc                   : 1,	//    19
	swrst_pqe_cvi                   : 1,	//    20
	swrst_pqe_cco                   : 1,	//    21
	swrst_m1                        : 1,	//    22
	swrst_m0                        : 1,	//    23
	swrst_gpu                       : 1,	//    24
	swrst_gfx                       : 1,	//    25
	swrst_lbus                      : 1,	//    26
	swrst_gbus                      : 1,	//    27
	swrst_emmc                      : 1,	//    28
	swrst_dpe                       : 1,	//    29
	swrst_cpuperi                   : 1,	//    30
	swrst_aud                       : 1;	//    31
} CTOP_VENC_CTOP_R15_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73440 ctop_r16 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	swrst_demod_d100                : 1,	//     4
	swrst_hdmi_d100                 : 1,	//     5
	swrst_venc_d100                 : 1,	//     6
	swrst_vdec2_d100                : 1,	//     7
	swrst_vdec1_d100                : 1,	//     8
	swrst_vdec0_d100                : 1,	//     9
	swrst_usb_d100                  : 1,	//    10
	swrst_te_d100                   : 1,	//    11
	swrst_pqe_vsd_d100              : 1,	//    12
	swrst_pqe_sre_d100              : 1,	//    13
	swrst_pqe_nd0_d100              : 1,	//    14
	swrst_pqe_mcu_d100              : 1,	//    15
	swrst_pqe_imx_d100              : 1,	//    16
	swrst_pqe_gsc_d100              : 1,	//    17
	swrst_pqe_fme_d100              : 1,	//    18
	swrst_pqe_fmc_d100              : 1,	//    19
	swrst_pqe_cvi_d100              : 1,	//    20
	swrst_pqe_cco_d100              : 1,	//    21
	swrst_m1_d100                   : 1,	//    22
	swrst_m0_d100                   : 1,	//    23
	swrst_gpu_d100                  : 1,	//    24
	swrst_gfx_d100                  : 1,	//    25
	swrst_lbus_d100                 : 1,	//    26
	swrst_gbus_d100                 : 1,	//    27
	swrst_emmc_d100                 : 1,	//    28
	swrst_dpe_d100                  : 1,	//    29
	swrst_cpuperi_d100              : 1,	//    30
	swrst_aud_d100                  : 1;	//    31
} CTOP_VENC_CTOP_R16_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73444 ctop_r17 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 5,	//  0: 4 reserved
	swrst_disp_pqe_vsd_d100         : 1,	//     5
	swrst_disp_pqe_sre_d100         : 1,	//     6
	swrst_disp_pqe_nd0_d100         : 1,	//     7
	swrst_disp_pqe_mcu_d100         : 1,	//     8
	swrst_disp_pqe_imx_d100         : 1,	//     9
	swrst_disp_pqe_gsc_d100         : 1,	//    10
	swrst_disp_pqe_fme_d100         : 1,	//    11
	swrst_disp_pqe_fmc_d100         : 1,	//    12
	swrst_disp_pqe_cvi_d100         : 1,	//    13
	swrst_disp_pqe_cco_d100         : 1,	//    14
	swrst_disp_dpe_d100             : 1,	//    15
	                                : 5,	// 16:20 reserved
	swrst_disp_pqe_vsd              : 1,	//    21
	swrst_disp_pqe_sre              : 1,	//    22
	swrst_disp_pqe_nd0              : 1,	//    23
	swrst_disp_pqe_mcu              : 1,	//    24
	swrst_disp_pqe_imx              : 1,	//    25
	swrst_disp_pqe_gsc              : 1,	//    26
	swrst_disp_pqe_fme              : 1,	//    27
	swrst_disp_pqe_fmc              : 1,	//    28
	swrst_disp_pqe_cvi              : 1,	//    29
	swrst_disp_pqe_cco              : 1,	//    30
	swrst_disp_dpe                  : 1;	//    31
} CTOP_VENC_CTOP_R17_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c73448 ctop_r18 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	sc_ext_sel                      : 3,	//  0: 2
	dco_ext_sel                     : 1,	//     3
	                                :26,	//  4:29 reserved
	f24_sel                         : 1,	//    30
	f27_18_sel                      : 1;	//    31
} CTOP_VENC_CTOP_R18_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c7344c ctop_r19 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :22,	//  0:21 reserved
	swrst_f396                      : 1,	//    22
	f396_sync_clk_gate_en           : 1,	//    23
	f396_sync_clk_sel               : 1,	//    24
	pqepll_pdb_ctrl                 : 1,	//    25
	displl_pdb_ctrl                 : 1,	//    26
	gpupll_pdb_ctrl                 : 1,	//    27
	corepll_pdb_ctrl                : 1,	//    28
	ddrpll_pdb_ctrl                 : 1,	//    29
	sdec_dco_pdb_ctrl               : 1,	//    30
	de_dco_pdb_ctrl                 : 1;	//    31
} CTOP_VENC_CTOP_R19_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50800 ctop_r00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_eb_data4_ds                 : 1,	//     0
	reg_eb_data4_pu                 : 1,	//     1
	reg_eb_data4_pd                 : 1,	//     2
	reserved                        : 1,	//     3
	reg_eb_data3_ds                 : 1,	//     4
	reg_eb_data3_pu                 : 1,	//     5
	reg_eb_data3_pd                 : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_eb_data2_ds                 : 1,	//     8
	reg_eb_data2_pu                 : 1,	//     9
	reg_eb_data2_pd                 : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_eb_data1_ds                 : 1,	//    12
	reg_eb_data1_pu                 : 1,	//    13
	reg_eb_data1_pd                 : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_eb_data0_ds                 : 1,	//    16
	reg_eb_data0_pu                 : 1,	//    17
	reg_eb_data0_pd                 : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_eb_oe_n_ds                  : 1,	//    20
	reg_eb_oe_n_pu                  : 1,	//    21
	reg_eb_oe_n_pd                  : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_eb_we_n_ds                  : 1,	//    24
	reg_eb_we_n_pu                  : 1,	//    25
	reg_eb_we_n_pd                  : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_eb_wait_ds                  : 1,	//    28
	reg_eb_wait_pu                  : 1,	//    29
	reg_eb_wait_pd                  : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_AUD_CTOP_R00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50804 ctop_r01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_eb_addr13_ds                : 1,	//     0
	reg_eb_addr13_pu                : 1,	//     1
	reg_eb_addr13_pd                : 1,	//     2
	reserved                        : 1,	//     3
	reg_eb_addr9_ds                 : 1,	//     4
	reg_eb_addr9_pu                 : 1,	//     5
	reg_eb_addr9_pd                 : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_eb_addr10_ds                : 1,	//     8
	reg_eb_addr10_pu                : 1,	//     9
	reg_eb_addr10_pd                : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_eb_addr11_ds                : 1,	//    12
	reg_eb_addr11_pu                : 1,	//    13
	reg_eb_addr11_pd                : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_eb_addr12_ds                : 1,	//    16
	reg_eb_addr12_pu                : 1,	//    17
	reg_eb_addr12_pd                : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_eb_data7_ds                 : 1,	//    20
	reg_eb_data7_pu                 : 1,	//    21
	reg_eb_data7_pd                 : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_eb_data5_ds                 : 1,	//    24
	reg_eb_data5_pu                 : 1,	//    25
	reg_eb_data5_pd                 : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_eb_data6_ds                 : 1,	//    28
	reg_eb_data6_pu                 : 1,	//    29
	reg_eb_data6_pd                 : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_AUD_CTOP_R01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50808 ctop_r02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_eb_addr4_ds                 : 1,	//     0
	reg_eb_addr4_pu                 : 1,	//     1
	reg_eb_addr4_pd                 : 1,	//     2
	reserved                        : 1,	//     3
	reg_eb_addr3_ds                 : 1,	//     4
	reg_eb_addr3_pu                 : 1,	//     5
	reg_eb_addr3_pd                 : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_eb_addr5_ds                 : 1,	//     8
	reg_eb_addr5_pu                 : 1,	//     9
	reg_eb_addr5_pd                 : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_eb_addr6_ds                 : 1,	//    12
	reg_eb_addr6_pu                 : 1,	//    13
	reg_eb_addr6_pd                 : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_eb_addr8_ds                 : 1,	//    16
	reg_eb_addr8_pu                 : 1,	//    17
	reg_eb_addr8_pd                 : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_eb_addr7_ds                 : 1,	//    20
	reg_eb_addr7_pu                 : 1,	//    21
	reg_eb_addr7_pd                 : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_eb_addr15_ds                : 1,	//    24
	reg_eb_addr15_pu                : 1,	//    25
	reg_eb_addr15_pd                : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_eb_addr14_ds                : 1,	//    28
	reg_eb_addr14_pu                : 1,	//    29
	reg_eb_addr14_pd                : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_AUD_CTOP_R02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c5080c ctop_r03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_cam_ireq_n_ds               : 1,	//     0
	reg_cam_ireq_n_pu               : 1,	//     1
	reg_cam_ireq_n_pd               : 1,	//     2
	reserved                        : 1,	//     3
	reg_cam_ce1_n_ds                : 1,	//     4
	reg_cam_ce1_n_pu                : 1,	//     5
	reg_cam_ce1_n_pd                : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_cam_ce2_n_ds                : 1,	//     8
	reg_cam_ce2_n_pu                : 1,	//     9
	reg_cam_ce2_n_pd                : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_cam_reset_ds                : 1,	//    12
	reg_cam_reset_pu                : 1,	//    13
	reg_cam_reset_pd                : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_cam_vccen_n_ds              : 1,	//    16
	reg_cam_vccen_n_pu              : 1,	//    17
	reg_cam_vccen_n_pd              : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_eb_addr1_ds                 : 1,	//    20
	reg_eb_addr1_pu                 : 1,	//    21
	reg_eb_addr1_pd                 : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_eb_addr2_ds                 : 1,	//    24
	reg_eb_addr2_pu                 : 1,	//    25
	reg_eb_addr2_pd                 : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_eb_addr0_ds                 : 1,	//    28
	reg_eb_addr0_pu                 : 1,	//    29
	reg_eb_addr0_pd                 : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_AUD_CTOP_R03_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50810 ctop_r04 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	reg_sd_clk_ds                   : 1,	//     4
	reg_sd_clk_pu                   : 1,	//     5
	reg_sd_clk_pd                   : 1,	//     6
	reserved                        : 1,	//     7
	reg_sd_cd_n_ds                  : 1,	//     8
	reg_sd_cd_n_pu                  : 1,	//     9
	reg_sd_cd_n_pd                  : 1,	//    10
	reserved_1                      : 1,	//    11
	reg_cam_reg_n_ds                : 1,	//    12
	reg_cam_reg_n_pu                : 1,	//    13
	reg_cam_reg_n_pd                : 1,	//    14
	reserved_2                      : 1,	//    15
	reg_cam_inpack_n_ds             : 1,	//    16
	reg_cam_inpack_n_pu             : 1,	//    17
	reg_cam_inpack_n_pd             : 1,	//    18
	reserved_3                      : 1,	//    19
	reg_cam_cd1_n_ds                : 1,	//    20
	reg_cam_cd1_n_pu                : 1,	//    21
	reg_cam_cd1_n_pd                : 1,	//    22
	reserved_4                      : 1,	//    23
	reg_cam_cd2_n_ds                : 1,	//    24
	reg_cam_cd2_n_pu                : 1,	//    25
	reg_cam_cd2_n_pd                : 1,	//    26
	reserved_5                      : 1,	//    27
	reg_cam_wait_n_ds               : 1,	//    28
	reg_cam_wait_n_pu               : 1,	//    29
	reg_cam_wait_n_pd               : 1,	//    30
	reserved_6                      : 1;	//    31
} CTOP_AUD_CTOP_R04_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50814 ctop_r05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_sd_reserved2_ds             : 1,	//     0
	reg_sd_reserved2_pu             : 1,	//     1
	reg_sd_reserved2_pd             : 1,	//     2
	reserved                        : 1,	//     3
	reg_sd_reserved1_ds             : 1,	//     4
	reg_sd_reserved1_pu             : 1,	//     5
	reg_sd_reserved1_pd             : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_sd_reserved0_ds             : 1,	//     8
	reg_sd_reserved0_pu             : 1,	//     9
	reg_sd_reserved0_pd             : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_sd_data0_ds                 : 1,	//    12
	reg_sd_data0_pu                 : 1,	//    13
	reg_sd_data0_pd                 : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_sd_data1_ds                 : 1,	//    16
	reg_sd_data1_pu                 : 1,	//    17
	reg_sd_data1_pd                 : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_sd_data2_ds                 : 1,	//    20
	reg_sd_data2_pu                 : 1,	//    21
	reg_sd_data2_pd                 : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_sd_data3_ds                 : 1,	//    24
	reg_sd_data3_pu                 : 1,	//    25
	reg_sd_data3_pd                 : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_sd_cmd_ds                   : 1,	//    28
	reg_sd_cmd_pu                   : 1,	//    29
	reg_sd_cmd_pd                   : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_AUD_CTOP_R05_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50818 ctop_r06 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :20,	//  0:19 reserved
	reg_sd_wp_n_ds                  : 1,	//    20
	reg_sd_wp_n_pu                  : 1,	//    21
	reg_sd_wp_n_pd                  : 1,	//    22
	reserved                        : 1,	//    23
	reg_sd_reserved4_ds             : 1,	//    24
	reg_sd_reserved4_pu             : 1,	//    25
	reg_sd_reserved4_pd             : 1,	//    26
	reserved_1                      : 1,	//    27
	reg_sd_reserved3_ds             : 1,	//    28
	reg_sd_reserved3_pu             : 1,	//    29
	reg_sd_reserved3_pd             : 1,	//    30
	reserved_2                      : 1;	//    31
} CTOP_AUD_CTOP_R06_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c5081c ctop_r07 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 6,	//  0: 5 reserved
	gp16_0_mux_en                   : 1,	//     6
	gp16_1_mux_en                   : 1,	//     7
	gp16_2_mux_en                   : 1,	//     8
	gp16_3_mux_en                   : 1,	//     9
	gp16_4_mux_en                   : 1,	//    10
	gp16_5_mux_en                   : 1,	//    11
	gp16_6_mux_en                   : 1,	//    12
	gp16_7_mux_en                   : 1,	//    13
	gp15_0_mux_en                   : 1,	//    14
	gp15_1_mux_en                   : 1,	//    15
	gp15_2_mux_en                   : 1,	//    16
	gp15_3_mux_en                   : 1,	//    17
	gp15_4_mux_en                   : 1,	//    18
	gp15_5_mux_en                   : 1,	//    19
	gp15_6_mux_en                   : 1,	//    20
	gp15_7_mux_en                   : 1,	//    21
	gp14_0_mux_en                   : 1,	//    22
	gp14_1_mux_en                   : 1,	//    23
	gp14_2_mux_en                   : 1,	//    24
	gp14_3_mux_en                   : 1,	//    25
	gp14_4_mux_en                   : 1,	//    26
	gp14_5_mux_en                   : 1,	//    27
	gp14_6_mux_en                   : 1,	//    28
	gp14_7_mux_en                   : 1,	//    29
	gp11_0_mux_en                   : 1,	//    30
	gp11_1_mux_en                   : 1;	//    31
} CTOP_AUD_CTOP_R07_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50820 ctop_r08 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	cpupll_fine_div                 : 1,	//     1
	cpupll_dss                      : 1,	//     2
	cpupll_accuracy                 : 2,	//  3: 4
	cpupll_updn_max                 : 7,	//  5:11
	cpupll_mod_freq                 : 9,	// 12:20
	cpupll_m                        : 6,	// 21:26
	cpupll_pdb_ctrl                 : 1,	//    27
	cpupll_cih                      : 4;	// 28:31
} CTOP_AUD_CTOP_R08_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50824 ctop_r09 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	cpupll_ofs_mode                 : 1,	//     4
	cpupll_fout3_od                 : 3,	//  5: 7
	cpupll_fout2_od                 : 3,	//  8:10
	cpupll_fout_od                  : 2,	// 11:12
	cpupll_pre_fout3_div            : 3,	// 13:15
	cpupll_pre_fout2_div            : 3,	// 16:18
	cpupll_nsc                      : 4,	// 19:22
	cpupll_npc                      : 6,	// 23:28
	cpupll_fine_control             : 3;	// 29:31
} CTOP_AUD_CTOP_R09_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50828 ctop_r10 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :22,	//  0:21 reserved
	cpupll_wakeup_bypass            : 1,	//    22
	cpupll_ddr_mode                 : 1,	//    23
	cpupll_offset                   : 8;	// 24:31
} CTOP_AUD_CTOP_R10_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c5082c ctop_r11 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :24,	//  0:23 reserved
	txclkdrv1_icon_normal           : 3,	// 24:26
	txclkdrv1_pdb_normal            : 1,	//    27
	txclkdrv0_icon_normal           : 3,	// 28:30
	txclkdrv0_pdb_normal            : 1;	//    31
} CTOP_AUD_CTOP_R11_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50830 ctop_r12 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :28,	//  0:27 reserved
	rxclkdrv1_smv_normal            : 1,	//    28
	rxclkdrv1_outsel_normal         : 2,	// 29:30
	rxclkdrv1_pdb_normal            : 1;	//    31
} CTOP_AUD_CTOP_R12_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50834 ctop_r13 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 7,	//  0: 6 reserved
	jtag_sel_te1                    : 1,	//     7
	jtag1_sel                       : 3,	//  8:10
	jtag_sel_vdec                   : 1,	//    11
	jtag_sel_aud                    : 1,	//    12
	jtag_sel_pmcu                   : 1,	//    13
	jtag_sel_te0                    : 1,	//    14
	                                : 1,	//    15 reserved
	jtag0_sel                       : 3,	// 16:18
	                                :12,	// 19:30 reserved
	jtag_hdmi_dbg                   : 1;	//    31
} CTOP_AUD_CTOP_R13_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50838 ctop_r14 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	ef_pd_normal                    : 1;	//    31
} CTOP_AUD_CTOP_R14_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c5083c ctop_r15 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_AUD_CTOP_R15_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c50840 ctop_r16 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_te_internal               : 1,	//     0
	swrst_auda_internal             : 1;	//     1
} CTOP_AUD_CTOP_R16_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c00 ctop_r00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_TE_CTOP_R00_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c04 ctop_r01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_hub_vbus_ctrl0_ds           : 1,	//     0
	reg_hub_vbus_ctrl0_pu           : 1,	//     1
	reg_hub_vbus_ctrl0_pd           : 1;	//     2
} CTOP_TE_CTOP_R01_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c08 ctop_r02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_tpio_data0_ds               : 1,	//     0
	reg_tpio_data0_pu               : 1,	//     1
	reg_tpio_data0_pd               : 1,	//     2
	reserved                        : 1,	//     3
	reg_tpio_data1_ds               : 1,	//     4
	reg_tpio_data1_pu               : 1,	//     5
	reg_tpio_data1_pd               : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_tpio_sop_ds                 : 1,	//     8
	reg_tpio_sop_pu                 : 1,	//     9
	reg_tpio_sop_pd                 : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_tpio_clk_ds                 : 1,	//    12
	reg_tpio_clk_pu                 : 1,	//    13
	reg_tpio_clk_pd                 : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_tpio_err_ds                 : 1,	//    16
	reg_tpio_err_pu                 : 1,	//    17
	reg_tpio_err_pd                 : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_tpio_val_ds                 : 1,	//    20
	reg_tpio_val_pu                 : 1,	//    21
	reg_tpio_val_pd                 : 1,	//    22
	reserved_5                      : 1,	//    23
	                                : 4,	// 24:27 reserved
	reg_hub_port_over0_ds           : 1,	//    28
	reg_hub_port_over0_pu           : 1,	//    29
	reg_hub_port_over0_pd           : 1,	//    30
	reserved_6                      : 1;	//    31
} CTOP_TE_CTOP_R02_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c0c ctop_r03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_tpi_data1_ds                : 1,	//     0
	reg_tpi_data1_pu                : 1,	//     1
	reg_tpi_data1_pd                : 1,	//     2
	reserved                        : 1,	//     3
	reg_tpi_data0_ds                : 1,	//     4
	reg_tpi_data0_pu                : 1,	//     5
	reg_tpi_data0_pd                : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_tpio_data7_ds               : 1,	//     8
	reg_tpio_data7_pu               : 1,	//     9
	reg_tpio_data7_pd               : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_tpio_data6_ds               : 1,	//    12
	reg_tpio_data6_pu               : 1,	//    13
	reg_tpio_data6_pd               : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_tpio_data5_ds               : 1,	//    16
	reg_tpio_data5_pu               : 1,	//    17
	reg_tpio_data5_pd               : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_tpio_data4_ds               : 1,	//    20
	reg_tpio_data4_pu               : 1,	//    21
	reg_tpio_data4_pd               : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_tpio_data3_ds               : 1,	//    24
	reg_tpio_data3_pu               : 1,	//    25
	reg_tpio_data3_pd               : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_tpio_data2_ds               : 1,	//    28
	reg_tpio_data2_pu               : 1,	//    29
	reg_tpio_data2_pd               : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_TE_CTOP_R03_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c10 ctop_r04 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_tpi_err_ds                  : 1,	//     0
	reg_tpi_err_pu                  : 1,	//     1
	reg_tpi_err_pd                  : 1,	//     2
	reserved                        : 1,	//     3
	reg_tpi_sop_ds                  : 1,	//     4
	reg_tpi_sop_pu                  : 1,	//     5
	reg_tpi_sop_pd                  : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_tpi_data7_ds                : 1,	//     8
	reg_tpi_data7_pu                : 1,	//     9
	reg_tpi_data7_pd                : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_tpi_data5_ds                : 1,	//    12
	reg_tpi_data5_pu                : 1,	//    13
	reg_tpi_data5_pd                : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_tpi_data6_ds                : 1,	//    16
	reg_tpi_data6_pu                : 1,	//    17
	reg_tpi_data6_pd                : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_tpi_data4_ds                : 1,	//    20
	reg_tpi_data4_pu                : 1,	//    21
	reg_tpi_data4_pd                : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_tpi_data3_ds                : 1,	//    24
	reg_tpi_data3_pu                : 1,	//    25
	reg_tpi_data3_pd                : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_tpi_data2_ds                : 1,	//    28
	reg_tpi_data2_pu                : 1,	//    29
	reg_tpi_data2_pd                : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_TE_CTOP_R04_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c14 ctop_r05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_eb_be_n0_ds                 : 1,	//     0
	reg_eb_be_n0_pu                 : 1,	//     1
	reg_eb_be_n0_pd                 : 1,	//     2
	reserved                        : 1,	//     3
	reg_eb_be_n1_ds                 : 1,	//     4
	reg_eb_be_n1_pu                 : 1,	//     5
	reg_eb_be_n1_pd                 : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_eb_cs3_ds                   : 1,	//     8
	reg_eb_cs3_pu                   : 1,	//     9
	reg_eb_cs3_pd                   : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_eb_cs2_ds                   : 1,	//    12
	reg_eb_cs2_pu                   : 1,	//    13
	reg_eb_cs2_pd                   : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_eb_cs1_ds                   : 1,	//    16
	reg_eb_cs1_pu                   : 1,	//    17
	reg_eb_cs1_pd                   : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_eb_cs0_ds                   : 1,	//    20
	reg_eb_cs0_pu                   : 1,	//    21
	reg_eb_cs0_pd                   : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_tpi_clk_ds                  : 1,	//    24
	reg_tpi_clk_pu                  : 1,	//    25
	reg_tpi_clk_pd                  : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_tpi_val_ds                  : 1,	//    28
	reg_tpi_val_pu                  : 1,	//    29
	reg_tpi_val_pd                  : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_TE_CTOP_R05_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c18 ctop_r06 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :20,	//  0:19 reserved
	reserved                        : 1,	//    20
	reserved_1                      : 1,	//    21
	gp11_5_mux_en                   : 1,	//    22
	gp11_4_mux_en                   : 1,	//    23
	gp11_3_mux_en                   : 1,	//    24
	gp11_2_mux_en                   : 1;	//    25
} CTOP_TE_CTOP_R06_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c1c ctop_r07 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :13,	//  0:12 reserved
	tpo_sel_ctrl1                   : 1,	//    13
	                                : 7,	// 14:20 reserved
	sc_clk_sel                      : 1,	//    21
	                                : 1,	//    22 reserved
	ir_enable                       : 1,	//    23
	                                : 4,	// 24:27 reserved
	vccen_n_pol                     : 1,	//    28
	tpio_sel_ctrl                   : 1,	//    29
	tpo_sel_ctrl0                   : 1,	//    30
	reserved                        : 1;	//    31
} CTOP_TE_CTOP_R07_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c20 ctop_r08 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	emmc_cd_n_wp_sel                : 1;	//     0
} CTOP_TE_CTOP_R08_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c24 ctop_r09 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_TE_CTOP_R09_M16A0;

/*-----------------------------------------------------------------------------
	0xc8c60c28 ctop_r10 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_TE_CTOP_R10_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e000 ctop_r00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 1,	//     0
	reserved_1                      : 1,	//     1
	reserved_2                      : 1,	//     2
	reg_stpi0_data4_pu              : 1,	//     3
	reserved_3                      : 1,	//     4
	reserved_4                      : 1,	//     5
	reserved_5                      : 1,	//     6
	reg_stpi0_data5_pu              : 1,	//     7
	reserved_6                      : 1,	//     8
	reserved_7                      : 1,	//     9
	reserved_8                      : 1,	//    10
	reg_stpi0_data6_pu              : 1,	//    11
	reserved_9                      : 1,	//    12
	reserved_10                     : 1,	//    13
	reserved_11                     : 1,	//    14
	reg_stpi0_data7_pu              : 1,	//    15
	reserved_12                     : 1,	//    16
	reserved_13                     : 1,	//    17
	reserved_14                     : 1,	//    18
	reg_stpi0_err_pu                : 1,	//    19
	reserved_15                     : 1,	//    20
	reserved_16                     : 1,	//    21
	reserved_17                     : 1,	//    22
	reg_stpi0_val_pu                : 1,	//    23
	reserved_18                     : 1,	//    24
	reserved_19                     : 1,	//    25
	reserved_20                     : 1,	//    26
	reg_stpi0_sop_pu                : 1,	//    27
	reserved_21                     : 1,	//    28
	reserved_22                     : 1,	//    29
	reserved_23                     : 1,	//    30
	reg_stpi0_clk_pu                : 1;	//    31
} CTOP_DEMOD_CTOP_R00_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e004 ctop_r01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 1,	//     0
	reserved_1                      : 1,	//     1
	reserved_2                      : 1,	//     2
	reg_tp_dvb_err_pu               : 1,	//     3
	reserved_3                      : 1,	//     4
	reserved_4                      : 1,	//     5
	reserved_5                      : 1,	//     6
	reg_tp_dvb_val_pu               : 1,	//     7
	reserved_6                      : 1,	//     8
	reserved_7                      : 1,	//     9
	reserved_8                      : 1,	//    10
	reg_tp_dvb_sop_pu               : 1,	//    11
	reserved_9                      : 1,	//    12
	reserved_10                     : 1,	//    13
	reserved_11                     : 1,	//    14
	reg_tp_dvb_clk_pu               : 1,	//    15
	reserved_12                     : 1,	//    16
	reserved_13                     : 1,	//    17
	reserved_14                     : 1,	//    18
	reg_stpi0_data0_pu              : 1,	//    19
	reserved_15                     : 1,	//    20
	reserved_16                     : 1,	//    21
	reserved_17                     : 1,	//    22
	reg_stpi0_data1_pu              : 1,	//    23
	reserved_18                     : 1,	//    24
	reserved_19                     : 1,	//    25
	reserved_20                     : 1,	//    26
	reg_stpi0_data2_pu              : 1,	//    27
	reserved_21                     : 1,	//    28
	reserved_22                     : 1,	//    29
	reserved_23                     : 1,	//    30
	reg_stpi0_data3_pu              : 1;	//    31
} CTOP_DEMOD_CTOP_R01_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e008 ctop_r02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 1,	//     0
	reserved_1                      : 1,	//     1
	reserved_2                      : 1,	//     2
	reg_tp_dvb_data0_pu             : 1,	//     3
	reserved_3                      : 1,	//     4
	reserved_4                      : 1,	//     5
	reserved_5                      : 1,	//     6
	reg_tp_dvb_data1_pu             : 1,	//     7
	reserved_6                      : 1,	//     8
	reserved_7                      : 1,	//     9
	reserved_8                      : 1,	//    10
	reg_tp_dvb_data2_pu             : 1,	//    11
	reserved_9                      : 1,	//    12
	reserved_10                     : 1,	//    13
	reserved_11                     : 1,	//    14
	reg_tp_dvb_data3_pu             : 1,	//    15
	reserved_12                     : 1,	//    16
	reserved_13                     : 1,	//    17
	reserved_14                     : 1,	//    18
	reg_tp_dvb_data4_pu             : 1,	//    19
	reserved_15                     : 1,	//    20
	reserved_16                     : 1,	//    21
	reserved_17                     : 1,	//    22
	reg_tp_dvb_data5_pu             : 1,	//    23
	reserved_18                     : 1,	//    24
	reserved_19                     : 1,	//    25
	reserved_20                     : 1,	//    26
	reg_tp_dvb_data6_pu             : 1,	//    27
	reserved_21                     : 1,	//    28
	reserved_22                     : 1,	//    29
	reserved_23                     : 1,	//    30
	reg_tp_dvb_data7_pu             : 1;	//    31
} CTOP_DEMOD_CTOP_R02_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e00c ctop_r03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :11,	//  0:10 reserved
	jtag_hdmi_dbg_demod             : 1,	//    11
	stpi0_out_ctrl                  : 1,	//    12
	gp6_0_mux_en                    : 1,	//    13
	gp6_1_mux_en                    : 1,	//    14
	gp6_2_mux_en                    : 1,	//    15
	gp6_3_mux_en                    : 1,	//    16
	gp6_4_mux_en                    : 1,	//    17
	gp6_5_mux_en                    : 1,	//    18
	resreved                        : 1,	//    19
	gp12_0_mux_en                   : 1,	//    20
	gp12_1_mux_en                   : 1,	//    21
	gp12_2_mux_en                   : 1,	//    22
	gp12_3_mux_en                   : 1,	//    23
	gp12_4_mux_en                   : 1,	//    24
	gp12_5_mux_en                   : 1,	//    25
	gp12_6_mux_en                   : 1,	//    26
	gp12_7_mux_en                   : 1,	//    27
	gp5_4_mux_en                    : 1,	//    28
	gp5_5_mux_en                    : 1,	//    29
	gp5_6_mux_en                    : 1,	//    30
	gp5_7_mux_en                    : 1;	//    31
} CTOP_DEMOD_CTOP_R03_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e010 ctop_r04 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :17,	//  0:16 reserved
	reserved                        : 1,	//    17
	reg_ifagc_pu                    : 1,	//    18
	reserved_1                      : 1,	//    19
	reserved_2                      : 1,	//    20
	hdmi3_en_demod                  : 1,	//    21
	hdmi2_en_demod                  : 1,	//    22
	hdmi1_en_demod                  : 1,	//    23
	ddc_write_en_demod              : 1,	//    24
	hdmi_i2c_en_demod               : 1,	//    25
	phy_arc_mux                     : 1,	//    26
	reserved_3                      : 1,	//    27
	rxclkdrv0_smv_normal            : 1,	//    28
	rxclkdrv0_outsel_normal         : 2,	// 29:30
	rxclkdrv0_pdb_normal            : 1;	//    31
} CTOP_DEMOD_CTOP_R04_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e014 ctop_r05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 8,	//  0: 7 reserved
	reg_hdmi2_2_5v_in_ds            : 1,	//     8
	reg_hdmi2_2_5v_in_pu            : 1,	//     9
	reg_hdmi2_2_5v_in_pd            : 1,	//    10
	reserved                        : 1,	//    11
	reg_hdmi2_1_5v_in_ds            : 1,	//    12
	reg_hdmi2_1_5v_in_pu            : 1,	//    13
	reg_hdmi2_1_5v_in_pd            : 1,	//    14
	reserved_1                      : 1,	//    15
	reg_hdmi2_0_5v_in_ds            : 1,	//    16
	reg_hdmi2_0_5v_in_pu            : 1,	//    17
	reg_hdmi2_0_5v_in_pd            : 1,	//    18
	reserved_2                      : 1;	//    19
} CTOP_DEMOD_CTOP_R05_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e018 ctop_r06 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_hdmi2_2_cd_sense_ds         : 1,	//     0
	reg_hdmi2_2_cd_sense_pu         : 1,	//     1
	reg_hdmi2_2_cd_sense_pd         : 1,	//     2
	reserved                        : 1,	//     3
	reg_hdmi2_2_sda_ds              : 1,	//     4
	reg_hdmi2_2_sda_pu              : 1,	//     5
	reg_hdmi2_2_sda_pd              : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_hdmi2_2_scl_ds              : 1,	//     8
	reg_hdmi2_2_scl_pu              : 1,	//     9
	reg_hdmi2_2_scl_pd              : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_hdmi2_1_sda_ds              : 1,	//    12
	reg_hdmi2_1_sda_pu              : 1,	//    13
	reg_hdmi2_1_sda_pd              : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_hdmi2_1_scl_ds              : 1,	//    16
	reg_hdmi2_1_scl_pu              : 1,	//    17
	reg_hdmi2_1_scl_pd              : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_hdmi2_0_sda_ds              : 1,	//    20
	reg_hdmi2_0_sda_pu              : 1,	//    21
	reg_hdmi2_0_sda_pd              : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_hdmi2_0_scl_ds              : 1,	//    24
	reg_hdmi2_0_scl_pu              : 1,	//    25
	reg_hdmi2_0_scl_pd              : 1,	//    26
	reserved_6                      : 1;	//    27
} CTOP_DEMOD_CTOP_R06_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e01c ctop_r07 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_DEMOD_CTOP_R07_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e020 ctop_r08 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_DEMOD_CTOP_R08_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e024 ctop_r09 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_DEMOD_CTOP_R09_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e028 ctop_r10 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto1_add_value             ;   	// 31: 0
} CTOP_DEMOD_CTOP_R10_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e02c ctop_r11 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto1_err_value             :12,	//  0:11
	                                : 4,	// 12:15 reserved
	sync_update_adto1               : 1,	//    16
	                                : 7,	// 17:23 reserved
	swrst_adto1                     : 1;	//    24
} CTOP_DEMOD_CTOP_R11_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e030 ctop_r12 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto2_add_value             ;   	// 31: 0
} CTOP_DEMOD_CTOP_R12_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e034 ctop_r13 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto2_err_value             :12,	//  0:11
	                                : 4,	// 12:15 reserved
	sync_update_adto2               : 1,	//    16
	                                : 7,	// 17:23 reserved
	swrst_adto2                     : 1;	//    24
} CTOP_DEMOD_CTOP_R13_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e038 ctop_r14 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto3_add_value             ;   	// 31: 0
} CTOP_DEMOD_CTOP_R14_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e03c ctop_r15 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto3_err_value             :12,	//  0:11
	                                : 4,	// 12:15 reserved
	sync_update_adto3               : 1,	//    16
	                                : 7,	// 17:23 reserved
	swrst_adto3                     : 1;	//    24
} CTOP_DEMOD_CTOP_R15_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e040 ctop_r16 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto4_add_value             ;   	// 31: 0
} CTOP_DEMOD_CTOP_R16_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e044 ctop_r17 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto4_err_value             :12,	//  0:11
	                                : 4,	// 12:15 reserved
	sync_update_adto4               : 1,	//    16
	                                : 7,	// 17:23 reserved
	swrst_adto4                     : 1;	//    24
} CTOP_DEMOD_CTOP_R17_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e048 ctop_r18 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_adto_sel                    : 2,	//  0: 1
	                                : 2,	//  2: 3 reserved
	sel_hdmi_mclk                   : 2,	//  4: 5
	                                : 2,	//  6: 7 reserved
	swrst_audclk_out                : 1,	//     8
	swrst_aud_fs20clk               : 1,	//     9
	swrst_aud_fs21clk               : 1,	//    10
	swrst_aud_fs23clk               : 1,	//    11
	swrst_aud_fs24clk               : 1,	//    12
	swrst_aud_fs25clk               : 1,	//    13
	swrst_audclk_out_sub            : 1,	//    14
	swrst_audclk_out2               : 1,	//    15
	swrst_audclk_out_sub2           : 1;	//    16
} CTOP_DEMOD_CTOP_R18_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e04c ctop_r19 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	aclk_mux1_src                   : 3,	//  0: 2
	aclk_mux1_div                   : 2,	//  3: 4
	                                : 3,	//  5: 7 reserved
	aclk_mux3_src                   : 3,	//  8:10
	aclk_mux3_div                   : 2,	// 11:12
	                                : 3,	// 13:15 reserved
	aclk_mux4_src                   : 3,	// 16:18
	aclk_mux4_div                   : 2,	// 19:20
	                                : 3,	// 21:23 reserved
	aclk_mux5_src                   : 3,	// 24:26
	aclk_mux5_div                   : 2;	// 27:28
} CTOP_DEMOD_CTOP_R19_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e050 ctop_r20 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	aclk_mux6_src                   : 3,	//  0: 2
	aclk_mux6_div                   : 2,	//  3: 4
	                                : 3,	//  5: 7 reserved
	aclk_mux7_src                   : 3,	//  8:10
	aclk_mux7_div                   : 2,	// 11:12
	                                : 3,	// 13:15 reserved
	aclk_mux8_src                   : 3,	// 16:18
	aclk_mux8_div                   : 2;	// 19:20
} CTOP_DEMOD_CTOP_R20_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e054 ctop_r21 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	aclk_mux11_src                  : 3,	//  0: 2
	aclk_mux11_div                  : 2,	//  3: 4
	                                : 3,	//  5: 7 reserved
	aclk_mux12_src                  : 3,	//  8:10
	aclk_mux12_div                  : 2,	// 11:12
	                                : 3,	// 13:15 reserved
	audclk_out_sub_mux_sel          : 1,	//    16
	audclk_out_mux_sel              : 1,	//    17
	sel_inv_aclk_mux11              : 1,	//    18
	sel_inv_aclk_mux12              : 1,	//    19
	                                : 4,	// 20:23 reserved
	sel_inv_aud_fsclk               : 8;	// 24:31
} CTOP_DEMOD_CTOP_R21_M16A0;

/*-----------------------------------------------------------------------------
	0xc830e058 ctop_r22 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	swrst_axi                       : 1,	//     0
	                                : 1,	//     1 reserved
	cg_axi_clk_en                   : 1,	//     2
	                                : 1,	//     3 reserved
	aclk_mux13_src                  : 3,	//  4: 6
	aclk_mux13_div                  : 2,	//  7: 8
	                                : 3,	//  9:11 reserved
	swrst_aud_fs22clk               : 1,	//    12
	                                : 3,	// 13:15 reserved
	sel_inv_aud_fs20clk             : 1;	//    16
} CTOP_DEMOD_CTOP_R22_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a400 ctop_r00 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	hdmi3_en                        : 1,	//     0
	hdmi2_en                        : 1,	//     1
	hdmi1_en                        : 1,	//     2
	ddc_write_en                    : 1,	//     3
	                                : 4,	//  4: 7 reserved
	rx_sel_uart1                    : 1,	//     8
	rx_sel_uart0                    : 1,	//     9
	rx_sel_hdmi                     : 2,	// 10:11
	rx_sel_mcu                      : 2,	// 12:13
	rx_sel_te                       : 2,	// 14:15
	rx_sel_vdec0                    : 2,	// 16:17
	rx_sel_tz                       : 2,	// 18:19
	                                : 1,	//    20 reserved
	uart2_sel                       : 3,	// 21:23
	                                : 1,	//    24 reserved
	uart1_sel                       : 3,	// 25:27
	                                : 1,	//    28 reserved
	uart0_sel                       : 3;	// 29:31
} CTOP_DPE_CTOP_R00_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a404 ctop_r01 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_DPE_CTOP_R01_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a408 ctop_r02 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_DPE_CTOP_R02_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a40c ctop_r03 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	c4_lvds_mode                    : 1,	//     1
	c4_epi_mode                     : 1,	//     2
	c4_sel_plllock                  : 1,	//     3
	c4_sel_fin                      : 2,	//  4: 5
	c4_sc_ctl                       : 2,	//  6: 7
	c4_epi_sel_mode                 : 1,	//     8
	c4_sel_bw                       : 1,	//     9
	c4_sw_rext                      : 1,	//    10
	c4_cih                          : 3,	// 11:13
	c4_pll_ic                       : 2,	// 14:15
	                                : 1,	//    16 reserved
	c4_sel_prediv                   : 1,	//    17
	c4_sel_lpf                      : 1,	//    18
	c4_lock_ctl                     : 2,	// 19:20
	c4_pdb                          : 1,	//    21
	c4_sel_lock                     : 1,	//    22
	c4_rf                           : 1,	//    23
	c4_term_en                      : 1,	//    24
	c4_adj_term                     : 4,	// 25:28
	c4_sel_mode                     : 2,	// 29:30
	c4_sw_pud                       : 1;	//    31
} CTOP_DPE_CTOP_R03_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a410 ctop_r04 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	c4_link0_en                     : 1,	//     0
	c4_link1_en                     : 1,	//     1
	c4_link2_en                     : 1,	//     2
	c4_link3_en                     : 1,	//     3
	c4_link4_en                     : 1,	//     4
	c4_link5_en                     : 1,	//     5
	c4_link6_en                     : 1,	//     6
	c4_link7_en                     : 1,	//     7
	c4_link8_en                     : 1,	//     8
	c4_link9_en                     : 1,	//     9
	c4_link10_en                    : 1,	//    10
	c4_link11_en                    : 1,	//    11
	reserved                        : 1,	//    12
	reserved_1                      : 1,	//    13
	reserved_2                      : 1,	//    14
	reserved_3                      : 1,	//    15
	reserved_4                      : 1,	//    16
	c4_scr_rst3                     : 1,	//    17
	c4_scr_rst2                     : 1,	//    18
	c4_scr_rst1                     : 1,	//    19
	reserved_5                      : 1,	//    20
	c4_scr_off3                     : 1,	//    21
	c4_scr_off2                     : 1,	//    22
	c4_scr_off1                     : 1,	//    23
	reserved_6                      : 1,	//    24
	c4_enc_rst3                     : 1,	//    25
	c4_enc_rst2                     : 1,	//    26
	c4_enc_rst1                     : 1,	//    27
	reserved_7                      : 1,	//    28
	c4_enc_off3                     : 1,	//    29
	c4_enc_off2                     : 1,	//    30
	c4_enc_off1                     : 1;	//    31
} CTOP_DPE_CTOP_R04_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a414 ctop_r05 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	c4_flip_en_ch0                  : 1,	//     0
	c4_flip_en_ch1                  : 1,	//     1
	c4_flip_en_ch2                  : 1,	//     2
	c4_flip_en_ch3                  : 1,	//     3
	c4_flip_en_ch4                  : 1,	//     4
	c4_flip_en_ch5                  : 1,	//     5
	c4_flip_en_ch6                  : 1,	//     6
	c4_flip_en_ch7                  : 1,	//     7
	c4_flip_en_ch8                  : 1,	//     8
	c4_flip_en_ch9                  : 1,	//     9
	c4_flip_en_ch10                 : 1,	//    10
	c4_flip_en_ch11                 : 1,	//    11
	reserved                        : 1,	//    12
	reserved_1                      : 1,	//    13
	reserved_2                      : 1,	//    14
	reserved_3                      : 1,	//    15
	c4_pdb_ch0                      : 1,	//    16
	c4_pdb_ch1                      : 1,	//    17
	c4_pdb_ch2                      : 1,	//    18
	c4_pdb_ch3                      : 1,	//    19
	c4_pdb_ch4                      : 1,	//    20
	c4_pdb_ch5                      : 1,	//    21
	c4_pdb_ch6                      : 1,	//    22
	c4_pdb_ch7                      : 1,	//    23
	c4_pdb_ch8                      : 1,	//    24
	c4_pdb_ch9                      : 1,	//    25
	c4_pdb_ch10                     : 1,	//    26
	c4_pdb_ch11                     : 1,	//    27
	reserved_4                      : 1,	//    28
	reserved_5                      : 1,	//    29
	reserved_6                      : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_DPE_CTOP_R05_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a418 ctop_r06 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	c4_pemp_ch0                     : 2,	//  0: 1
	c4_pemp_ch1                     : 2,	//  2: 3
	c4_pemp_ch2                     : 2,	//  4: 5
	c4_pemp_ch3                     : 2,	//  6: 7
	c4_pemp_ch4                     : 2,	//  8: 9
	c4_pemp_ch5                     : 2,	// 10:11
	c4_pemp_ch6                     : 2,	// 12:13
	c4_pemp_ch7                     : 2,	// 14:15
	c4_pemp_ch8                     : 2,	// 16:17
	c4_pemp_ch9                     : 2,	// 18:19
	c4_pemp_ch10                    : 2,	// 20:21
	c4_pemp_ch11                    : 2,	// 22:23
	reserved                        : 2,	// 24:25
	reserved_1                      : 2,	// 26:27
	reserved_2                      : 2,	// 28:29
	reserved_3                      : 2;	// 30:31
} CTOP_DPE_CTOP_R06_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a41c ctop_r07 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 2,	//  0: 1 reserved
	c4_test_mode3                   : 2,	//  2: 3
	c4_test_mode2                   : 2,	//  4: 5
	c4_test_mode1                   : 2,	//  6: 7
	c4_itune8                       : 3,	//  8:10
	c4_itune9                       : 3,	// 11:13
	c4_itune10                      : 3,	// 14:16
	c4_itune11                      : 3,	// 17:19
	reserved                        : 3,	// 20:22
	reserved_1                      : 3,	// 23:25
	reserved_2                      : 3,	// 26:28
	reserved_3                      : 3;	// 29:31
} CTOP_DPE_CTOP_R07_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a420 ctop_r08 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 8,	//  0: 7 reserved
	c4_itune0                       : 3,	//  8:10
	c4_itune1                       : 3,	// 11:13
	c4_itune2                       : 3,	// 14:16
	c4_itune3                       : 3,	// 17:19
	c4_itune4                       : 3,	// 20:22
	c4_itune5                       : 3,	// 23:25
	c4_itune6                       : 3,	// 26:28
	c4_itune7                       : 3;	// 29:31
} CTOP_DPE_CTOP_R08_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a424 ctop_r09 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 2,	//  0: 1
	c4_txlock_fixen3                : 2,	//  2: 3
	c4_txlock_fixen2                : 2,	//  4: 5
	c4_txlock_fixen1                : 2,	//  6: 7
	reserved_1                      : 6,	//  8:13
	c4_count_rxlock3                : 6,	// 14:19
	c4_count_rxlock2                : 6,	// 20:25
	c4_count_rxlock1                : 6;	// 26:31
} CTOP_DPE_CTOP_R09_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a428 ctop_r10 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 4,	//  0: 3
	c4_read_tp_sel3                 : 4,	//  4: 7
	c4_read_tp_sel2                 : 4,	//  8:11
	c4_read_tp_sel1                 : 4,	// 12:15
	                                : 8,	// 16:23 reserved
	reserved_1                      : 2,	// 24:25
	c4_read_lane_sel3               : 2,	// 26:27
	c4_read_lane_sel2               : 2,	// 28:29
	c4_read_lane_sel1               : 2;	// 30:31
} CTOP_DPE_CTOP_R10_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a42c ctop_r11 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	c4_sel_clkpix2                  : 3,	//  0: 2
	c4_sel_clkpix1                  : 3,	//  3: 5
	c4_count_txlock2                :13,	//  6:18
	c4_count_txlock1                :13;	// 19:31
} CTOP_DPE_CTOP_R11_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a430 ctop_r12 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 3,	//  0: 2
	c4_sel_clkpix3                  : 3,	//  3: 5
	reserved_1                      :13,	//  6:18
	c4_count_txlock3                :13;	// 19:31
} CTOP_DPE_CTOP_R12_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a434 ctop_r13 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        :10,	//  0: 9
	                                : 6,	// 10:15 reserved
	reserved_1                      : 1,	//    16
	c4_clk_pix1x_rf3                : 1,	//    17
	c4_clk_pix1x_rf2                : 1,	//    18
	c4_clk_pix1x_rf1                : 1,	//    19
	reserved_2                      : 2,	// 20:21
	c4_read_address_offset3         : 2,	// 22:23
	c4_read_address_offset2         : 2,	// 24:25
	c4_read_address_offset1         : 2,	// 26:27
	reserved_3                      : 1,	//    28
	c4_rstn_vtxlink3                : 1,	//    29
	c4_rstn_vtxlink2                : 1,	//    30
	c4_rstn_vtxlink1                : 1;	//    31
} CTOP_DPE_CTOP_R13_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a438 ctop_r14 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	c4_test_di3                     :10,	//  0: 9
	c4_test_di2                     :10,	// 10:19
	c4_test_di1                     :10,	// 20:29
	c4_bytemode                     : 2;	// 30:31
} CTOP_DPE_CTOP_R14_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a43c ctop_r15 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 8,	//  0: 7 reserved
	reserved                        : 1,	//     8
	reserved_1                      : 1,	//     9
	reserved_2                      : 1,	//    10
	reg_uart1_cts_pu                : 1,	//    11
	reserved_3                      : 1,	//    12
	reserved_4                      : 1,	//    13
	reserved_5                      : 1,	//    14
	reg_uart1_rts_pu                : 1,	//    15
	reserved_6                      : 1,	//    16
	reserved_7                      : 1,	//    17
	reserved_8                      : 1,	//    18
	reg_uart1_txd_pu                : 1,	//    19
	reserved_9                      : 1,	//    20
	reg_uart1_rxd_pu                : 1,	//    21
	reserved_10                     : 1,	//    22
	reserved_11                     : 1,	//    23
	reserved_12                     : 1,	//    24
	reserved_13                     : 1,	//    25
	reserved_14                     : 1,	//    26
	reg_gpio26_pd                   : 1,	//    27
	reserved_15                     : 1,	//    28
	reserved_16                     : 1,	//    29
	reserved_17                     : 1,	//    30
	reg_iec958out_pu                : 1;	//    31
} CTOP_DPE_CTOP_R15_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a440 ctop_r16 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_scl2_ds                     : 1,	//     0
	reg_scl2_pu                     : 1,	//     1
	reg_scl2_pd                     : 1,	//     2
	reserved                        : 1,	//     3
	reg_sda2_ds                     : 1,	//     4
	reg_sda2_pu                     : 1,	//     5
	reg_sda2_pd                     : 1,	//     6
	reserved_1                      : 1,	//     7
	reg_scl1_ds                     : 1,	//     8
	reg_scl1_pu                     : 1,	//     9
	reg_scl1_pd                     : 1,	//    10
	reserved_2                      : 1,	//    11
	reg_sda1_ds                     : 1,	//    12
	reg_sda1_pu                     : 1,	//    13
	reg_sda1_pd                     : 1,	//    14
	reserved_3                      : 1,	//    15
	reg_scl0_ds                     : 1,	//    16
	reg_scl0_pu                     : 1,	//    17
	reg_scl0_pd                     : 1,	//    18
	reserved_4                      : 1,	//    19
	reg_sda0_ds                     : 1,	//    20
	reg_sda0_pu                     : 1,	//    21
	reg_sda0_pd                     : 1,	//    22
	reserved_5                      : 1,	//    23
	reg_scl4_ds                     : 1,	//    24
	reg_scl4_pu                     : 1,	//    25
	reg_scl4_pd                     : 1,	//    26
	reserved_6                      : 1,	//    27
	reg_sda4_ds                     : 1,	//    28
	reg_sda4_pu                     : 1,	//    29
	reg_sda4_pd                     : 1,	//    30
	reserved_7                      : 1;	//    31
} CTOP_DPE_CTOP_R16_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a444 ctop_r17 ''
------------------------------------------------------------------------------*/
/*	no field */

/*-----------------------------------------------------------------------------
	0xc830a448 ctop_r18 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	reserved                        : 1,	//     4
	reserved_1                      : 1,	//     5
	reserved_2                      : 1,	//     6
	reg_gpio24_pd                   : 1,	//     7
	reserved_3                      : 1,	//     8
	reserved_4                      : 1,	//     9
	reg_gpio25_pd                   : 1,	//    10
	reserved_5                      : 1,	//    11
	reserved_6                      : 1,	//    12
	reserved_7                      : 1,	//    13
	reserved_8                      : 1,	//    14
	reg_gpio27_pd                   : 1,	//    15
	reserved_9                      : 1,	//    16
	reserved_10                     : 1,	//    17
	reserved_11                     : 1,	//    18
	reg_gpio28_pd                   : 1,	//    19
	reserved_12                     : 1,	//    20
	reserved_13                     : 1,	//    21
	reserved_14                     : 1,	//    22
	reg_gpio29_pd                   : 1,	//    23
	reserved_15                     : 1,	//    24
	reserved_16                     : 1,	//    25
	reserved_17                     : 1,	//    26
	reg_gpio30_pd                   : 1,	//    27
	reserved_18                     : 1,	//    28
	reserved_19                     : 1,	//    29
	reserved_20                     : 1,	//    30
	reg_gpio31_pd                   : 1;	//    31
} CTOP_DPE_CTOP_R18_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a44c ctop_r19 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_DPE_CTOP_R19_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a450 ctop_r20 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 1,	//     0
	reserved_1                      : 1,	//     1
	reserved_2                      : 1,	//     2
	reg_gpio7_pd                    : 1,	//     3
	reserved_3                      : 1,	//     4
	reserved_4                      : 1,	//     5
	reserved_5                      : 1,	//     6
	reg_gpio6_pd                    : 1,	//     7
	reserved_6                      : 1,	//     8
	reserved_7                      : 1,	//     9
	reserved_8                      : 1,	//    10
	reg_gpio5_pd                    : 1,	//    11
	reserved_9                      : 1,	//    12
	reserved_10                     : 1,	//    13
	reserved_11                     : 1,	//    14
	reg_gpio4_pd                    : 1,	//    15
	reserved_12                     : 1,	//    16
	reserved_13                     : 1,	//    17
	reserved_14                     : 1,	//    18
	reg_gpio3_pd                    : 1,	//    19
	reserved_15                     : 1,	//    20
	reserved_16                     : 1,	//    21
	reserved_17                     : 1,	//    22
	reg_gpio2_pd                    : 1,	//    23
	reserved_18                     : 1,	//    24
	reserved_19                     : 1,	//    25
	reserved_20                     : 1,	//    26
	reg_gpio1_pd                    : 1,	//    27
	reserved_21                     : 1,	//    28
	reserved_22                     : 1,	//    29
	reserved_23                     : 1,	//    30
	reg_gpio0_pd                    : 1;	//    31
} CTOP_DPE_CTOP_R20_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a454 ctop_r21 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 1,	//     0
	reserved_1                      : 1,	//     1
	reserved_2                      : 1,	//     2
	reg_gpio15_pd                   : 1,	//     3
	reserved_3                      : 1,	//     4
	reserved_4                      : 1,	//     5
	reserved_5                      : 1,	//     6
	reg_gpio14_pd                   : 1,	//     7
	reg_gpio13_ds                   : 1,	//     8
	reg_gpio13_pu                   : 1,	//     9
	reg_gpio13_pd                   : 1,	//    10
	reserved_6                      : 1,	//    11
	reserved_7                      : 1,	//    12
	reserved_8                      : 1,	//    13
	reserved_9                      : 1,	//    14
	reg_gpio12_pd                   : 1,	//    15
	reserved_10                     : 1,	//    16
	reserved_11                     : 1,	//    17
	reserved_12                     : 1,	//    18
	reg_gpio11_pd                   : 1,	//    19
	reg_gpio10_ds                   : 1,	//    20
	reg_gpio10_pu                   : 1,	//    21
	reg_gpio10_pd                   : 1,	//    22
	reserved_13                     : 1,	//    23
	reserved_14                     : 1,	//    24
	reserved_15                     : 1,	//    25
	reserved_16                     : 1,	//    26
	reg_gpio9_pd                    : 1,	//    27
	reserved_17                     : 1,	//    28
	reserved_18                     : 1,	//    29
	reserved_19                     : 1,	//    30
	reg_gpio8_pd                    : 1;	//    31
} CTOP_DPE_CTOP_R21_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a458 ctop_r22 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 1,	//     0
	reserved_1                      : 1,	//     1
	reserved_2                      : 1,	//     2
	reg_spi_cs1_pu                  : 1,	//     3
	reserved_3                      : 1,	//     4
	reserved_4                      : 1,	//     5
	reserved_5                      : 1,	//     6
	reg_spi_di1_pu                  : 1,	//     7
	reg_scl5_ds                     : 1,	//     8
	reg_scl5_pu                     : 1,	//     9
	reg_scl5_pd                     : 1,	//    10
	reserved_6                      : 1,	//    11
	reg_sda5_ds                     : 1,	//    12
	reg_sda5_pu                     : 1,	//    13
	reg_sda5_pd                     : 1,	//    14
	reserved_7                      : 1,	//    15
	reg_scl3_ds                     : 1,	//    16
	reg_scl3_pu                     : 1,	//    17
	reg_scl3_pd                     : 1,	//    18
	reserved_8                      : 1,	//    19
	reg_sda3_ds                     : 1,	//    20
	reg_sda3_pu                     : 1,	//    21
	reg_sda3_pd                     : 1,	//    22
	reserved_9                      : 1,	//    23
	reserved_10                     : 1,	//    24
	reserved_11                     : 1,	//    25
	reserved_12                     : 1,	//    26
	reg_uart0_txd_pu                : 1,	//    27
	reserved_13                     : 1,	//    28
	reg_uart0_rxd_pu                : 1,	//    29
	reserved_14                     : 1,	//    30
	reserved_15                     : 1;	//    31
} CTOP_DPE_CTOP_R22_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a45c ctop_r23 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        : 1,	//     0
	reserved_1                      : 1,	//     1
	reserved_2                      : 1,	//     2
	reg_stpi1_val_pu                : 1,	//     3
	                                : 4,	//  4: 7 reserved
	reserved_3                      : 1,	//     8
	reserved_4                      : 1,	//     9
	reserved_5                      : 1,	//    10
	reg_spi_cs0_pu                  : 1,	//    11
	reserved_6                      : 1,	//    12
	reserved_7                      : 1,	//    13
	reserved_8                      : 1,	//    14
	reg_spi_do0_pu                  : 1,	//    15
	reserved_9                      : 1,	//    16
	reserved_10                     : 1,	//    17
	reserved_11                     : 1,	//    18
	reg_spi_sclk1_pu                : 1,	//    19
	reserved_12                     : 1,	//    20
	reserved_13                     : 1,	//    21
	reserved_14                     : 1,	//    22
	reg_spi_do1_pu                  : 1,	//    23
	reserved_15                     : 1,	//    24
	reserved_16                     : 1,	//    25
	reserved_17                     : 1,	//    26
	reg_spi_di0_pu                  : 1,	//    27
	reserved_18                     : 1,	//    28
	reserved_19                     : 1,	//    29
	reserved_20                     : 1,	//    30
	reg_spi_sclk0_pu                : 1;	//    31
} CTOP_DPE_CTOP_R23_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a460 ctop_r24 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :16,	//  0:15 reserved
	reserved                        : 1,	//    16
	reserved_1                      : 1,	//    17
	reserved_2                      : 1,	//    18
	reg_stpi1_data_pu               : 1,	//    19
	reserved_3                      : 1,	//    20
	reserved_4                      : 1,	//    21
	reserved_5                      : 1,	//    22
	reg_stpi1_err_pu                : 1,	//    23
	reserved_6                      : 1,	//    24
	reserved_7                      : 1,	//    25
	reserved_8                      : 1,	//    26
	reg_stpi1_sop_pu                : 1,	//    27
	reserved_9                      : 1,	//    28
	reserved_10                     : 1,	//    29
	reserved_11                     : 1,	//    30
	reg_stpi1_clk_pu                : 1;	//    31
} CTOP_DPE_CTOP_R24_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a464 ctop_r25 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	gp13_1_mux_en                   : 1,	//     0
	gp13_2_mux_en                   : 1,	//     1
	gp13_3_mux_en                   : 1,	//     2
	gp13_4_mux_en                   : 1,	//     3
	gp13_5_mux_en                   : 1,	//     4
	gp13_6_mux_en                   : 1,	//     5
	                                : 1,	//     6 reserved
	gp9_2_mux_en                    : 1,	//     7
	gp9_6_mux_en                    : 1,	//     8
	gp17_0_mux_en                   : 1,	//     9
	gp17_2_mux_en                   : 1,	//    10
	gp9_3_mux_en                    : 1,	//    11
	gp9_7_mux_en                    : 1,	//    12
	gp17_1_mux_en                   : 1,	//    13
	gp17_3_mux_en                   : 1,	//    14
	gp9_0_mux_en                    : 1,	//    15
	gp9_1_mux_en                    : 1,	//    16
	gp9_4_mux_en                    : 1,	//    17
	gp9_5_mux_en                    : 1,	//    18
	gp17_4_mux_en                   : 1,	//    19
	                                : 1,	//    20 reserved
	gp17_5_mux_en                   : 1,	//    21
	gp17_6_mux_en                   : 1,	//    22
	gp17_7_mux_en                   : 1,	//    23
	gp4_0_mux_en                    : 1,	//    24
	gp4_1_mux_en                    : 1,	//    25
	gp4_2_mux_en                    : 1,	//    26
	gp4_3_mux_en                    : 1,	//    27
	gp4_4_mux_en                    : 1,	//    28
	gp4_5_mux_en                    : 1,	//    29
	gp4_6_mux_en                    : 1,	//    30
	gp4_7_mux_en                    : 1;	//    31
} CTOP_DPE_CTOP_R25_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a468 ctop_r26 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reg_rgmii_rx_clk_ds             : 1,	//     0
	reg_rgmii_rx_clk_pu             : 1,	//     1
	reserved                        : 1,	//     2
	reg_rgmii_rx_clk_pd             : 1,	//     3
	reg_rgmii_rxd2_ds               : 1,	//     4
	reg_rgmii_rxd2_pu               : 1,	//     5
	reserved_1                      : 1,	//     6
	reg_rgmii_rxd2_pd               : 1,	//     7
	reg_rgmii_rxd1_ds               : 1,	//     8
	reg_rgmii_rxd1_pu               : 1,	//     9
	reserved_2                      : 1,	//    10
	reg_rgmii_rxd1_pd               : 1,	//    11
	reg_rgmii_rxd0_ds               : 1,	//    12
	reg_rgmii_rxd0_pu               : 1,	//    13
	reserved_3                      : 1,	//    14
	reg_rgmii_rxd0_pd               : 1,	//    15
	reg_rgmii_rxctl_ds              : 1,	//    16
	reg_rgmii_rxctl_pu              : 1,	//    17
	reserved_4                      : 1,	//    18
	reg_rgmii_rxctl_pd              : 1,	//    19
	reg_rgmii_txctl_ds              : 1,	//    20
	reg_rgmii_txctl_pu              : 1,	//    21
	reserved_5                      : 1,	//    22
	reg_rgmii_txctl_pd              : 1,	//    23
	reg_rgmii_mdio_ds               : 1,	//    24
	reg_rgmii_mdio_pu               : 1,	//    25
	reserved_6                      : 1,	//    26
	reg_rgmii_mdio_pd               : 1,	//    27
	reg_rgmii_mdc_ds                : 1,	//    28
	reg_rgmii_mdc_pu                : 1,	//    29
	reserved_7                      : 1,	//    30
	reg_rgmii_mdc_pd                : 1;	//    31
} CTOP_DPE_CTOP_R26_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a46c ctop_r27 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 4,	//  0: 3 reserved
	reg_rgmii_ref_clk_ds            : 1,	//     4
	reg_rgmii_ref_clk_pu            : 1,	//     5
	reserved                        : 1,	//     6
	reg_rgmii_ref_clk_pd            : 1,	//     7
	reg_rgmii_tx_clk_ds             : 1,	//     8
	reg_rgmii_tx_clk_pu             : 1,	//     9
	reserved_1                      : 1,	//    10
	reg_rgmii_tx_clk_pd             : 1,	//    11
	reg_rgmii_txd3_ds               : 1,	//    12
	reg_rgmii_txd3_pu               : 1,	//    13
	reserved_2                      : 1,	//    14
	reg_rgmii_txd3_pd               : 1,	//    15
	reg_rgmii_txd2_ds               : 1,	//    16
	reg_rgmii_txd2_pu               : 1,	//    17
	reserved_3                      : 1,	//    18
	reg_rgmii_txd2_pd               : 1,	//    19
	reg_rgmii_txd1_ds               : 1,	//    20
	reg_rgmii_txd1_pu               : 1,	//    21
	reserved_4                      : 1,	//    22
	reg_rgmii_txd1_pd               : 1,	//    23
	reg_rgmii_txd0_ds               : 1,	//    24
	reg_rgmii_txd0_pu               : 1,	//    25
	reserved_5                      : 1,	//    26
	reg_rgmii_txd0_pd               : 1,	//    27
	reg_rgmii_rxd3_ds               : 1,	//    28
	reg_rgmii_rxd3_pu               : 1,	//    29
	reserved_6                      : 1,	//    30
	reg_rgmii_rxd3_pd               : 1;	//    31
} CTOP_DPE_CTOP_R27_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a470 ctop_r28 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 9,	//  0: 8 reserved
	mon_sr_en                       : 1,	//     9
	mon_c4tx_en                     : 1,	//    10
	mon_aud_en                      : 1,	//    11
	mon_tcon_en                     : 1,	//    12
	mon_hdmirx_en                   : 1,	//    13
	mon_cpu_en                      : 1,	//    14
	mon_te_en                       : 1,	//    15
	mon_led_en                      : 1,	//    16
	mon_imx_en                      : 1,	//    17
	mon_aad_en                      : 1,	//    18
	mon_vdec0_en                    : 1,	//    19
	mon_fme_en                      : 1,	//    20
	mon_vsd_en                      : 1,	//    21
	mon_cvi_en                      : 1,	//    22
	mon_vdec1_en                    : 1,	//    23
	mon_dmcu_en                     : 1,	//    24
	mon_cco_en                      : 1,	//    25
	mon_fmc_en                      : 1,	//    26
	mon_nd0_en                      : 1,	//    27
	mon_gpu_en                      : 1,	//    28
	mon_vdec2_en                    : 1,	//    29
	mon_venc_en                     : 1,	//    30
	mon_gsc_en                      : 1;	//    31
} CTOP_DPE_CTOP_R28_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a474 ctop_r29 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :31,	//  0:30 reserved
	reserved                        : 1;	//    31
} CTOP_DPE_CTOP_R29_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a478 ctop_r30 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :17,	//  0:16 reserved
	rxclkdrv2_smv_normal            : 1,	//    17
	rxclkdrv2_outsel_normal         : 2,	// 18:19
	rxclkdrv2_pdb_normal            : 1,	//    20
	stpio_en_ctrl                   : 1,	//    21
	jtag1_disable_bot_normal        : 1,	//    22
	hdmi_i2c_en                     : 1,	//    23
	en_eb_addr_out                  : 1,	//    24
	aud_sub_en                      : 1,	//    25
	i2c6_en                         : 1,	//    26
	en_aud_dacrlrch                 : 1,	//    27
	led_vs_en                       : 1,	//    28
	led_i2c_en                      : 1,	//    29
	uart2_en                        : 1,	//    30
	reserved                        : 1;	//    31
} CTOP_DPE_CTOP_R30_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a47c ctop_r31 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                : 1,	//     0 reserved
	usb2_bt_por                     : 1,	//     1
	usb2_bt_fsel                    : 3,	//  2: 4
	usb2_bt_txrestune0              : 2,	//  5: 6
	usb2_bt_txhsxvtune0             : 2,	//  7: 8
	usb2_bt_txvreftune0             : 4,	//  9:12
	usb2_bt_txrisetune0             : 2,	// 13:14
	usb2_bt_txpreemppulsetune0      : 1,	//    15
	usb2_bt_txpreempamptune0        : 2,	// 16:17
	usb2_bt_txfslstune0             : 4,	// 18:21
	usb2_bt_sqrxtune0               : 3,	// 22:24
	usb2_bt_compdistune0            : 3,	// 25:27
	usb2_bt_commononn               : 1,	//    28
	usb2_bt_refclksel               : 2,	// 29:30
	usb2_bt_portreset0              : 1;	//    31
} CTOP_DPE_CTOP_R31_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a480 ctop_r32 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	usb2_bt_bypasssel0              : 1,	//     0
	usb2_bt_bypassdmen0             : 1,	//     1
	usb2_bt_bypassdpen0             : 1,	//     2
	usb2_bt_bypassdmdata0           : 1,	//     3
	usb2_bt_bypassdpdata0           : 1,	//     4
	usb2_bt_otgdisable0             : 1,	//     5
	usb2_bt_vatestenb               : 2,	//  6: 7
	usb2_bt_loopbackenb0            : 1,	//     8
	usb2_bt_siddq                   : 1,	//     9
	usb2_bt_testclk0                : 1,	//    10
	                                : 5,	// 11:15 reserved
	usb2_bt_testdatain0             : 8,	// 16:23
	usb2_bt_testaddr0               : 4,	// 24:27
	usb2_bt_testdataoutsel0         : 1,	//    28
	                                : 2,	// 29:30 reserved
	usb2_bt_atereset                : 1;	//    31
} CTOP_DPE_CTOP_R32_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a484 ctop_r33 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_DPE_CTOP_R33_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a488 ctop_r34 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_DPE_CTOP_R34_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a48c ctop_r35 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_DPE_CTOP_R35_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a490 ctop_r36 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_DPE_CTOP_R36_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a494 ctop_r37 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_DPE_CTOP_R37_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a498 ctop_r38 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_DPE_CTOP_R38_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a49c ctop_r39 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	reserved                        ;   	// 31: 0
} CTOP_DPE_CTOP_R39_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a4a0 ctop_r40 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	c4_link_read_tp2                :16,	//  0:15
	c4_link_read_tp1                :16;	// 16:31
} CTOP_DPE_CTOP_R40_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a4a4 ctop_r41 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	                                :10,	//  0: 9 reserved
	c4_link_tp3                     : 1,	//    10
	c4_link_tp2                     : 1,	//    11
	c4_link_tp1                     : 1,	//    12
	c4_vx1_lockn_fromip             : 1,	//    13
	c4_epi_lock_fromip              : 1,	//    14
	c4_pll_lock_fromip              : 1,	//    15
	c4_link_read_tp3                :16;	// 16:31
} CTOP_DPE_CTOP_R41_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a4a8 ctop_r42 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	monitoring_reserved3            ;   	// 31: 0
} CTOP_DPE_CTOP_R42_M16A0;

/*-----------------------------------------------------------------------------
	0xc830a4ac ctop_r43 ''
------------------------------------------------------------------------------*/
typedef struct {
	UINT32
	monitoring_reserved4            ;   	// 31: 0
} CTOP_DPE_CTOP_R43_M16A0;

typedef struct {
	VDEC0_SYN_CRG_VDEC000_M16A0     	crg_vdec000                     ;	// 0xc8c70000 : ''
	VDEC0_SYN_CRG_VDEC001_M16A0     	crg_vdec001                     ;	// 0xc8c70004 : ''
} VDEC0_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	VDEC1_SYN_CRG_VDEC100_M16A0     	crg_vdec100                     ;	// 0xc8c71000 : ''
	VDEC1_SYN_CRG_VDEC101_M16A0     	crg_vdec101                     ;	// 0xc8c71004 : ''
} VDEC1_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	VDEC2_SYN_CRG_VDEC200_M16A0     	crg_vdec200                     ;	// 0xc8c72000 : ''
	VDEC2_SYN_CRG_VDEC201_M16A0     	crg_vdec201                     ;	// 0xc8c72004 : ''
} VDEC2_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	LBUS_SYN_CRG_LBUS00_M16A0       	crg_lbus00                      ;	// 0xc8c20000 : ''
	LBUS_SYN_CRG_LBUS01_M16A0       	crg_lbus01                      ;	// 0xc8c20004 : ''
} LBUS_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	GBUS_SYN_CRG_GBUS00_M16A0       	crg_gbus00                      ;	// 0xc830b000 : ''
	GBUS_SYN_CRG_GBUS01_M16A0       	crg_gbus01                      ;	// 0xc830b004 : ''
} GBUS_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	VSD_SYN_CRG_VSD00_M16A0         	crg_vsd00                       ;	// 0xc8306000 : ''
	VSD_SYN_CRG_VSD01_M16A0         	crg_vsd01                       ;	// 0xc8306004 : ''
	VSD_SYN_CRG_VSD02_M16A0         	crg_vsd02                       ;	// 0xc8306008 : ''
} VSD_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	ND0_SYN_CRG_ND000_M16A0         	crg_nd000                       ;	// 0xc8304000 : ''
	ND0_SYN_CRG_ND001_M16A0         	crg_nd001                       ;	// 0xc8304004 : ''
	ND0_SYN_CRG_ND002_M16A0         	crg_nd002                       ;	// 0xc8304008 : ''
} ND0_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	IMX_SYN_CRG_IMX00_M16A0         	crg_imx00                       ;	// 0xc8303000 : ''
	IMX_SYN_CRG_IMX01_M16A0         	crg_imx01                       ;	// 0xc8303004 : ''
	IMX_SYN_CRG_IMX02_M16A0         	crg_imx02                       ;	// 0xc8303008 : ''
} IMX_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	GSC_SYN_CRG_GSC00_M16A0         	crg_gsc00                       ;	// 0xc8301000 : ''
	GSC_SYN_CRG_GSC01_M16A0         	crg_gsc01                       ;	// 0xc8301004 : ''
	GSC_SYN_CRG_GSC02_M16A0         	crg_gsc02                       ;	// 0xc8301008 : ''
} GSC_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	CVI_SYN_CRG_CVI00_M16A0         	crg_cvi00                       ;	// 0xc8302000 : ''
	CVI_SYN_CRG_CVI01_M16A0         	crg_cvi01                       ;	// 0xc8302004 : ''
	CVI_SYN_CRG_CVI02_M16A0         	crg_cvi02                       ;	// 0xc8302008 : ''
} CVI_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	CCO_SYN_CRG_CCO00_M16A0         	crg_cco00                       ;	// 0xc8307000 : ''
	CCO_SYN_CRG_CCO01_M16A0         	crg_cco01                       ;	// 0xc8307004 : ''
} CCO_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	SRE_SYN_CRG_SRE00_M16A0         	crg_sre00                       ;	// 0xc8305000 : ''
	SRE_SYN_CRG_SRE01_M16A0         	crg_sre01                       ;	// 0xc8305004 : ''
	SRE_SYN_CRG_SRE02_M16A0         	crg_sre02                       ;	// 0xc8305008 : ''
} SRE_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	MCU_SYN_CRG_MCU00_M16A0         	crg_mcu00                       ;	// 0xc8300000 : ''
	MCU_SYN_CRG_MCU01_M16A0         	crg_mcu01                       ;	// 0xc8300004 : ''
} MCU_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	FMC_SYN_CRG_FMC00_M16A0         	crg_fmc00                       ;	// 0xc8309000 : ''
	FMC_SYN_CRG_FMC01_M16A0         	crg_fmc01                       ;	// 0xc8309004 : ''
	FMC_SYN_CRG_FMC02_M16A0         	crg_fmc02                       ;	// 0xc8309008 : ''
} FMC_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	FME_SYN_CRG_FME00_M16A0         	crg_fme00                       ;	// 0xc8308000 : ''
	FME_SYN_CRG_FME01_M16A0         	crg_fme01                       ;	// 0xc8308004 : ''
} FME_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	M0_SYN_CRG_M000_M16A0           	crg_m000                        ;	// 0xc8c30000 : ''
} M0_SYN_REG_M16A0_T;
/* 1 regs, 1 types */

typedef struct {
	M1_SYN_CRG_M100_M16A0           	crg_m100                        ;	// 0xc8c40000 : ''
} M1_SYN_REG_M16A0_T;
/* 1 regs, 1 types */

typedef struct {
	GFX_SYN_CRG_GFX00_M16A0         	crg_gfx00                       ;	// 0xc8c10000 : ''
	GFX_SYN_CRG_GFX01_M16A0         	crg_gfx01                       ;	// 0xc8c10004 : ''
} GFX_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	VENC_SYN_CRG_VENC00_M16A0       	crg_venc00                      ;	// 0xc8c73000 : ''
	VENC_SYN_CRG_VENC01_M16A0       	crg_venc01                      ;	// 0xc8c73004 : ''
} VENC_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	AUD_SYN_CRG_AUD00_M16A0         	crg_aud00                       ;	// 0xc8c50400 : ''
	AUD_SYN_CRG_AUD01_M16A0         	crg_aud01                       ;	// 0xc8c50404 : ''
	AUD_SYN_CRG_AUD02_M16A0         	crg_aud02                       ;	// 0xc8c50408 : ''
} AUD_SYN_REG_M16A0_T;
/* 3 regs, 3 types */

typedef struct {
	TE_SYN_CRG_TE00_M16A0           	crg_te00                        ;	// 0xc8c60800 : ''
	TE_SYN_CRG_TE01_M16A0           	crg_te01                        ;	// 0xc8c60804 : ''
} TE_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	HDMI_SYN_CRG_HDMI00_M16A0       	crg_hdmi00                      ;	// 0xc830d000 : ''
	HDMI_SYN_CRG_HDMI01_M16A0       	crg_hdmi01                      ;	// 0xc830d004 : ''
	HDMI_SYN_CRG_HDMI02_M16A0       	crg_hdmi02                      ;	// 0xc830d008 : ''
	HDMI_SYN_CTOP_HDMI03_M16A0      	ctop_hdmi03                     ;	// 0xc830d00c : ''
	HDMI_SYN_CTOP_HDMI04_M16A0      	ctop_hdmi04                     ;	// 0xc830d010 : ''
	HDMI_SYN_CTOP_HDMI05_M16A0      	ctop_hdmi05                     ;	// 0xc830d014 : ''
} HDMI_SYN_REG_M16A0_T;
/* 6 regs, 6 types */

typedef struct {
	GPU_SYN_CRG_GPU_M16A0           	crg_gpu                         ;	// 0xc8205000 : ''
} GPU_SYN_REG_M16A0_T;
/* 1 regs, 1 types */

typedef struct {
	DPE_SYN_CRG_DPE00_M16A0         	crg_dpe00                       ;	// 0xc830a000 : ''
	DPE_SYN_CRG_DPE01_M16A0         	crg_dpe01                       ;	// 0xc830a004 : ''
} DPE_SYN_REG_M16A0_T;
/* 2 regs, 2 types */

typedef struct {
	PERI_SYN_CRG_CPUPERI00_M16A0    	crg_cpuperi00                   ;	// 0xc8230000 : ''
	PERI_SYN_CRG_CPUPERI01_M16A0    	crg_cpuperi01                   ;	// 0xc8230004 : ''
	PERI_SYN_CRG_CPUPERI02_M16A0    	crg_cpuperi02                   ;	// 0xc8230008 : ''
	PERI_SYN_CRG_CPUPERI03_M16A0    	crg_cpuperi03                   ;	// 0xc823000c : ''
	PERI_SYN_CRG_CPUPERI04_M16A0    	crg_cpuperi04                   ;	// 0xc8230010 : ''
	PERI_SYN_CRG_CPUPERI05_M16A0    	crg_cpuperi05                   ;	// 0xc8230014 : ''
	PERI_SYN_CRG_CPUPERI06_M16A0    	crg_cpuperi06                   ;	// 0xc8230018 : ''
	PERI_SYN_CRG_CPUPERI07_M16A0    	crg_cpuperi07                   ;	// 0xc823001c : ''
	PERI_SYN_SNAPIETRO_CRG0_M16A0   	snapietro_crg0                  ;	// 0xc8230020 : ''
	PERI_SYN_SNAPIETRO_CRG1_M16A0   	snapietro_crg1                  ;	// 0xc8230024 : ''
} PERI_SYN_REG_M16A0_T;
/* 10 regs, 10 types */

typedef struct {
	UINT32                          	                 __rsvd_00[  14];	// 0xc1cf0000 ~ 0xc1cf0034
	EMMC_SYN_CRG_EMMC_M16A0         	crg_emmc                        ;	// 0xc1cf0038 : ''
} EMMC_SYN_REG_M16A0_T;
/* 1 regs, 1 types */

typedef struct {
	CTOP_FMC_CTOP_R00_M16A0         	ctop_r00                        ;	// 0xc8309400 : ''
	CTOP_FMC_CTOP_R01_M16A0         	ctop_r01                        ;	// 0xc8309404 : ''
	CTOP_FMC_CTOP_R02_M16A0         	ctop_r02                        ;	// 0xc8309408 : ''
	CTOP_FMC_CTOP_R03_M16A0         	ctop_r03                        ;	// 0xc830940c : ''
	UINT32                          	ctop_r04                        ;	// 0xc8309410 : ''
	CTOP_FMC_CTOP_R05_M16A0         	ctop_r05                        ;	// 0xc8309414 : ''
	CTOP_FMC_CTOP_R06_M16A0         	ctop_r06                        ;	// 0xc8309418 : ''
	CTOP_FMC_CTOP_R07_M16A0         	ctop_r07                        ;	// 0xc830941c : ''
	CTOP_FMC_CTOP_R08_M16A0         	ctop_r08                        ;	// 0xc8309420 : ''
	CTOP_FMC_CTOP_R09_M16A0         	ctop_r09                        ;	// 0xc8309424 : ''
	CTOP_FMC_CTOP_R10_M16A0         	ctop_r10                        ;	// 0xc8309428 : ''
	CTOP_FMC_CTOP_R11_M16A0         	ctop_r11                        ;	// 0xc830942c : ''
	CTOP_FMC_CTOP_R12_M16A0         	ctop_r12                        ;	// 0xc8309430 : ''
	CTOP_FMC_CTOP_R13_M16A0         	ctop_r13                        ;	// 0xc8309434 : ''
} CTOP_FMC_REG_M16A0_T;
/* 14 regs, 14 types */

typedef struct {
	CTOP_VENC_CTOP_R00_M16A0        	ctop_r00                        ;	// 0xc8c73400 : ''
	CTOP_VENC_CTOP_R01_M16A0        	ctop_r01                        ;	// 0xc8c73404 : ''
	CTOP_VENC_CTOP_R02_M16A0        	ctop_r02                        ;	// 0xc8c73408 : ''
	CTOP_VENC_CTOP_R03_M16A0        	ctop_r03                        ;	// 0xc8c7340c : ''
	CTOP_VENC_CTOP_R04_M16A0        	ctop_r04                        ;	// 0xc8c73410 : ''
	CTOP_VENC_CTOP_R05_M16A0        	ctop_r05                        ;	// 0xc8c73414 : ''
	CTOP_VENC_CTOP_R06_M16A0        	ctop_r06                        ;	// 0xc8c73418 : ''
	CTOP_VENC_CTOP_R07_M16A0        	ctop_r07                        ;	// 0xc8c7341c : ''
	CTOP_VENC_CTOP_R08_M16A0        	ctop_r08                        ;	// 0xc8c73420 : ''
	CTOP_VENC_CTOP_R09_M16A0        	ctop_r09                        ;	// 0xc8c73424 : ''
	CTOP_VENC_CTOP_R10_M16A0        	ctop_r10                        ;	// 0xc8c73428 : ''
	CTOP_VENC_CTOP_R11_M16A0        	ctop_r11                        ;	// 0xc8c7342c : ''
	CTOP_VENC_CTOP_R12_M16A0        	ctop_r12                        ;	// 0xc8c73430 : ''
	CTOP_VENC_CTOP_R13_M16A0        	ctop_r13                        ;	// 0xc8c73434 : ''
	CTOP_VENC_CTOP_R14_M16A0        	ctop_r14                        ;	// 0xc8c73438 : ''
	CTOP_VENC_CTOP_R15_M16A0        	ctop_r15                        ;	// 0xc8c7343c : ''
	CTOP_VENC_CTOP_R16_M16A0        	ctop_r16                        ;	// 0xc8c73440 : ''
	CTOP_VENC_CTOP_R17_M16A0        	ctop_r17                        ;	// 0xc8c73444 : ''
	CTOP_VENC_CTOP_R18_M16A0        	ctop_r18                        ;	// 0xc8c73448 : ''
	CTOP_VENC_CTOP_R19_M16A0        	ctop_r19                        ;	// 0xc8c7344c : ''
} CTOP_VENC_REG_M16A0_T;
/* 20 regs, 20 types */

typedef struct {
	CTOP_AUD_CTOP_R00_M16A0         	ctop_r00                        ;	// 0xc8c50800 : ''
	CTOP_AUD_CTOP_R01_M16A0         	ctop_r01                        ;	// 0xc8c50804 : ''
	CTOP_AUD_CTOP_R02_M16A0         	ctop_r02                        ;	// 0xc8c50808 : ''
	CTOP_AUD_CTOP_R03_M16A0         	ctop_r03                        ;	// 0xc8c5080c : ''
	CTOP_AUD_CTOP_R04_M16A0         	ctop_r04                        ;	// 0xc8c50810 : ''
	CTOP_AUD_CTOP_R05_M16A0         	ctop_r05                        ;	// 0xc8c50814 : ''
	CTOP_AUD_CTOP_R06_M16A0         	ctop_r06                        ;	// 0xc8c50818 : ''
	CTOP_AUD_CTOP_R07_M16A0         	ctop_r07                        ;	// 0xc8c5081c : ''
	CTOP_AUD_CTOP_R08_M16A0         	ctop_r08                        ;	// 0xc8c50820 : ''
	CTOP_AUD_CTOP_R09_M16A0         	ctop_r09                        ;	// 0xc8c50824 : ''
	CTOP_AUD_CTOP_R10_M16A0         	ctop_r10                        ;	// 0xc8c50828 : ''
	CTOP_AUD_CTOP_R11_M16A0         	ctop_r11                        ;	// 0xc8c5082c : ''
	CTOP_AUD_CTOP_R12_M16A0         	ctop_r12                        ;	// 0xc8c50830 : ''
	CTOP_AUD_CTOP_R13_M16A0         	ctop_r13                        ;	// 0xc8c50834 : ''
	CTOP_AUD_CTOP_R14_M16A0         	ctop_r14                        ;	// 0xc8c50838 : ''
	CTOP_AUD_CTOP_R15_M16A0         	ctop_r15                        ;	// 0xc8c5083c : ''
	CTOP_AUD_CTOP_R16_M16A0         	ctop_r16                        ;	// 0xc8c50840 : ''
} CTOP_AUD_REG_M16A0_T;
/* 17 regs, 17 types */

typedef struct {
	CTOP_TE_CTOP_R00_M16A0          	ctop_r00                        ;	// 0xc8c60c00 : ''
	CTOP_TE_CTOP_R01_M16A0          	ctop_r01                        ;	// 0xc8c60c04 : ''
	CTOP_TE_CTOP_R02_M16A0          	ctop_r02                        ;	// 0xc8c60c08 : ''
	CTOP_TE_CTOP_R03_M16A0          	ctop_r03                        ;	// 0xc8c60c0c : ''
	CTOP_TE_CTOP_R04_M16A0          	ctop_r04                        ;	// 0xc8c60c10 : ''
	CTOP_TE_CTOP_R05_M16A0          	ctop_r05                        ;	// 0xc8c60c14 : ''
	CTOP_TE_CTOP_R06_M16A0          	ctop_r06                        ;	// 0xc8c60c18 : ''
	CTOP_TE_CTOP_R07_M16A0          	ctop_r07                        ;	// 0xc8c60c1c : ''
	CTOP_TE_CTOP_R08_M16A0          	ctop_r08                        ;	// 0xc8c60c20 : ''
	CTOP_TE_CTOP_R09_M16A0          	ctop_r09                        ;	// 0xc8c60c24 : ''
	CTOP_TE_CTOP_R10_M16A0          	ctop_r10                        ;	// 0xc8c60c28 : ''
} CTOP_TE_REG_M16A0_T;
/* 11 regs, 11 types */

typedef struct {
	CTOP_DEMOD_CTOP_R00_M16A0       	ctop_r00                        ;	// 0xc830e000 : ''
	CTOP_DEMOD_CTOP_R01_M16A0       	ctop_r01                        ;	// 0xc830e004 : ''
	CTOP_DEMOD_CTOP_R02_M16A0       	ctop_r02                        ;	// 0xc830e008 : ''
	CTOP_DEMOD_CTOP_R03_M16A0       	ctop_r03                        ;	// 0xc830e00c : ''
	CTOP_DEMOD_CTOP_R04_M16A0       	ctop_r04                        ;	// 0xc830e010 : ''
	CTOP_DEMOD_CTOP_R05_M16A0       	ctop_r05                        ;	// 0xc830e014 : ''
	CTOP_DEMOD_CTOP_R06_M16A0       	ctop_r06                        ;	// 0xc830e018 : ''
	CTOP_DEMOD_CTOP_R07_M16A0       	ctop_r07                        ;	// 0xc830e01c : ''
	CTOP_DEMOD_CTOP_R08_M16A0       	ctop_r08                        ;	// 0xc830e020 : ''
	CTOP_DEMOD_CTOP_R09_M16A0       	ctop_r09                        ;	// 0xc830e024 : ''
	CTOP_DEMOD_CTOP_R10_M16A0       	ctop_r10                       ;	// 0xc830e028 : ''
	CTOP_DEMOD_CTOP_R11_M16A0       	ctop_r11                       ;	// 0xc830e02c : ''
	CTOP_DEMOD_CTOP_R12_M16A0       	ctop_r12                       ;	// 0xc830e030 : ''
	CTOP_DEMOD_CTOP_R13_M16A0       	ctop_r13                       ;	// 0xc830e034 : ''
	CTOP_DEMOD_CTOP_R14_M16A0       	ctop_r14                       ;	// 0xc830e038 : ''
	CTOP_DEMOD_CTOP_R15_M16A0       	ctop_r15                       ;	// 0xc830e03c : ''
	CTOP_DEMOD_CTOP_R16_M16A0       	ctop_r16                       ;	// 0xc830e040 : ''
	CTOP_DEMOD_CTOP_R17_M16A0       	ctop_r17                       ;	// 0xc830e044 : ''
	CTOP_DEMOD_CTOP_R18_M16A0       	ctop_r18                       ;	// 0xc830e048 : ''
	CTOP_DEMOD_CTOP_R19_M16A0       	ctop_r19                       ;	// 0xc830e04c : ''
	CTOP_DEMOD_CTOP_R20_M16A0       	ctop_r20                       ;	// 0xc830e050 : ''
	CTOP_DEMOD_CTOP_R21_M16A0       	ctop_r21                       ;	// 0xc830e054 : ''
	CTOP_DEMOD_CTOP_R22_M16A0       	ctop_r22                       ;	// 0xc830e058 : ''
} CTOP_DEMOD_REG_M16A0_T;
/* 23 regs, 23 types */

typedef struct {
	CTOP_DPE_CTOP_R00_M16A0         	ctop_r00                        ;	// 0xc830a400 : ''
	CTOP_DPE_CTOP_R01_M16A0         	ctop_r01                        ;	// 0xc830a404 : ''
	CTOP_DPE_CTOP_R02_M16A0         	ctop_r02                        ;	// 0xc830a408 : ''
	CTOP_DPE_CTOP_R03_M16A0         	ctop_r03                        ;	// 0xc830a40c : ''
	CTOP_DPE_CTOP_R04_M16A0         	ctop_r04                        ;	// 0xc830a410 : ''
	CTOP_DPE_CTOP_R05_M16A0         	ctop_r05                        ;	// 0xc830a414 : ''
	CTOP_DPE_CTOP_R06_M16A0         	ctop_r06                        ;	// 0xc830a418 : ''
	CTOP_DPE_CTOP_R07_M16A0         	ctop_r07                        ;	// 0xc830a41c : ''
	CTOP_DPE_CTOP_R08_M16A0         	ctop_r08                        ;	// 0xc830a420 : ''
	CTOP_DPE_CTOP_R09_M16A0         	ctop_r09                        ;	// 0xc830a424 : ''
	CTOP_DPE_CTOP_R10_M16A0         	ctop_r10                        ;	// 0xc830a428 : ''
	CTOP_DPE_CTOP_R11_M16A0         	ctop_r11                        ;	// 0xc830a42c : ''
	CTOP_DPE_CTOP_R12_M16A0         	ctop_r12                        ;	// 0xc830a430 : ''
	CTOP_DPE_CTOP_R13_M16A0         	ctop_r13                        ;	// 0xc830a434 : ''
	CTOP_DPE_CTOP_R14_M16A0         	ctop_r14                        ;	// 0xc830a438 : ''
	CTOP_DPE_CTOP_R15_M16A0         	ctop_r15                        ;	// 0xc830a43c : ''
	CTOP_DPE_CTOP_R16_M16A0         	ctop_r16                        ;	// 0xc830a440 : ''
	UINT32                          	ctop_r17                        ;	// 0xc830a444 : ''
	CTOP_DPE_CTOP_R18_M16A0         	ctop_r18                        ;	// 0xc830a448 : ''
	CTOP_DPE_CTOP_R19_M16A0         	ctop_r19                        ;	// 0xc830a44c : ''
	CTOP_DPE_CTOP_R20_M16A0         	ctop_r20                        ;	// 0xc830a450 : ''
	CTOP_DPE_CTOP_R21_M16A0         	ctop_r21                        ;	// 0xc830a454 : ''
	CTOP_DPE_CTOP_R22_M16A0         	ctop_r22                        ;	// 0xc830a458 : ''
	CTOP_DPE_CTOP_R23_M16A0         	ctop_r23                        ;	// 0xc830a45c : ''
	CTOP_DPE_CTOP_R24_M16A0         	ctop_r24                        ;	// 0xc830a460 : ''
	CTOP_DPE_CTOP_R25_M16A0         	ctop_r25                        ;	// 0xc830a464 : ''
	CTOP_DPE_CTOP_R26_M16A0         	ctop_r26                        ;	// 0xc830a468 : ''
	CTOP_DPE_CTOP_R27_M16A0         	ctop_r27                        ;	// 0xc830a46c : ''
	CTOP_DPE_CTOP_R28_M16A0         	ctop_r28                        ;	// 0xc830a470 : ''
	CTOP_DPE_CTOP_R29_M16A0         	ctop_r29                        ;	// 0xc830a474 : ''
	CTOP_DPE_CTOP_R30_M16A0         	ctop_r30                        ;	// 0xc830a478 : ''
	CTOP_DPE_CTOP_R31_M16A0         	ctop_r31                        ;	// 0xc830a47c : ''
	CTOP_DPE_CTOP_R32_M16A0         	ctop_r32                        ;	// 0xc830a480 : ''
	CTOP_DPE_CTOP_R33_M16A0         	ctop_r33                        ;	// 0xc830a484 : ''
	CTOP_DPE_CTOP_R34_M16A0         	ctop_r34                        ;	// 0xc830a488 : ''
	CTOP_DPE_CTOP_R35_M16A0         	ctop_r35                        ;	// 0xc830a48c : ''
	CTOP_DPE_CTOP_R36_M16A0         	ctop_r36                        ;	// 0xc830a490 : ''
	CTOP_DPE_CTOP_R37_M16A0         	ctop_r37                        ;	// 0xc830a494 : ''
	CTOP_DPE_CTOP_R38_M16A0         	ctop_r38                        ;	// 0xc830a498 : ''
	CTOP_DPE_CTOP_R39_M16A0         	ctop_r39                        ;	// 0xc830a49c : ''
	CTOP_DPE_CTOP_R40_M16A0         	ctop_r40                        ;	// 0xc830a4a0 : ''
	CTOP_DPE_CTOP_R41_M16A0         	ctop_r41                        ;	// 0xc830a4a4 : ''
	CTOP_DPE_CTOP_R42_M16A0         	ctop_r42                        ;	// 0xc830a4a8 : ''
	CTOP_DPE_CTOP_R43_M16A0         	ctop_r43                        ;	// 0xc830a4ac : ''
} CTOP_DPE_REG_M16A0_T;
/* 44 regs, 44 types */

/* 197 regs, 197 types in Total*/


/* below was added, manually. */

typedef struct {
	VDEC0_SYN_REG_M16A0_T	* VDEC0_SYN;
	VDEC1_SYN_REG_M16A0_T	* VDEC1_SYN;
	VDEC2_SYN_REG_M16A0_T	* VDEC2_SYN;
	LBUS_SYN_REG_M16A0_T	* LBUS_SYN;
	GBUS_SYN_REG_M16A0_T	* GBUS_SYN;
	VSD_SYN_REG_M16A0_T		* VSD_SYN;
	ND0_SYN_REG_M16A0_T		* ND0_SYN;
	IMX_SYN_REG_M16A0_T		* IMX_SYN;
	GSC_SYN_REG_M16A0_T		* GSC_SYN;
	CVI_SYN_REG_M16A0_T		* CVI_SYN;
	CCO_SYN_REG_M16A0_T		* CCO_SYN;
	SRE_SYN_REG_M16A0_T		* SRE_SYN;
	MCU_SYN_REG_M16A0_T		* MCU_SYN;
	FMC_SYN_REG_M16A0_T		* FMC_SYN;
	FME_SYN_REG_M16A0_T		* FME_SYN;
	M0_SYN_REG_M16A0_T		* M0_SYN;
	M1_SYN_REG_M16A0_T		* M1_SYN;
	GFX_SYN_REG_M16A0_T		* GFX_SYN;
	VENC_SYN_REG_M16A0_T	* VENC_SYN;
	AUD_SYN_REG_M16A0_T		* AUD_SYN;
	TE_SYN_REG_M16A0_T		* TE_SYN;
	HDMI_SYN_REG_M16A0_T	* HDMI_SYN;
	GPU_SYN_REG_M16A0_T		* GPU_SYN;
	DPE_SYN_REG_M16A0_T		* DPE_SYN;
	PERI_SYN_REG_M16A0_T	* PERI_SYN;
	EMMC_SYN_REG_M16A0_T	* EMMC_SYN;
	CTOP_FMC_REG_M16A0_T	* FMC;
	CTOP_VENC_REG_M16A0_T	* VENC;
	CTOP_AUD_REG_M16A0_T	* AUD;
	CTOP_TE_REG_M16A0_T		* TE;
	CTOP_DEMOD_REG_M16A0_T	* DEMOD;
	CTOP_DPE_REG_M16A0_T	* DPE;
} CTOP_CTRL_REG_T;

#define M16_A0_CTOP_VDEC0_SYN_BASE	0xc8c70000
#define M16_A0_CTOP_VDEC1_SYN_BASE	0xc8c71000
#define M16_A0_CTOP_VDEC2_SYN_BASE	0xc8c72000
#define M16_A0_CTOP_LBUS_SYN_BASE	0xc8c20000
#define M16_A0_CTOP_GBUS_SYN_BASE	0xc830b000
#define M16_A0_CTOP_VSD_SYN_BASE	0xc8306000
#define M16_A0_CTOP_ND0_SYN_BASE	0xc8304000
#define M16_A0_CTOP_IMX_SYN_BASE	0xc8303000
#define M16_A0_CTOP_GSC_SYN_BASE	0xc8301000
#define M16_A0_CTOP_CVI_SYN_BASE	0xc8302000
#define M16_A0_CTOP_CCO_SYN_BASE	0xc8307000
#define M16_A0_CTOP_SRE_SYN_BASE	0xc8305000
#define M16_A0_CTOP_MCU_SYN_BASE	0xc8300000
#define M16_A0_CTOP_FMC_SYN_BASE	0xc8309000
#define M16_A0_CTOP_FME_SYN_BASE	0xc8308000
#define M16_A0_CTOP_M0_SYN_BASE		0xc8c30000
#define M16_A0_CTOP_M1_SYN_BASE		0xc8c40000
#define M16_A0_CTOP_GFX_SYN_BASE	0xc8c10000
#define M16_A0_CTOP_VENC_SYN_BASE	0xc8c73000
#define M16_A0_CTOP_AUD_SYN_BASE	0xc8c50400
#define M16_A0_CTOP_TE_SYN_BASE		0xc8c60800
#define M16_A0_CTOP_HDMI_SYN_BASE	0xc830d000
#define M16_A0_CTOP_GPU_SYN_BASE	0xc8205000
#define M16_A0_CTOP_DPE_SYN_BASE	0xc830a000
#define M16_A0_CTOP_PERI_SYN_BASE	0xc8230000
#define M16_A0_CTOP_EMMC_SYN_BASE	0xc1cf0000
#define M16_A0_CTOP_FMC_BASE		0xc8309400
#define M16_A0_CTOP_VENC_BASE		0xc8c73400
#define M16_A0_CTOP_AUD_BASE		0xc8c50800
#define M16_A0_CTOP_TE_BASE			0xc8c60c00
#define M16_A0_CTOP_DEMOD_BASE		0xc830e000
#define M16_A0_CTOP_DPE_BASE		0xc830a400

#define M16_A0_CTOP_VDEC0_SYN_TYPE	VDEC0_SYN_REG_M16A0_T
#define M16_A0_CTOP_VDEC1_SYN_TYPE	VDEC1_SYN_REG_M16A0_T
#define M16_A0_CTOP_VDEC2_SYN_TYPE	VDEC2_SYN_REG_M16A0_T
#define M16_A0_CTOP_LBUS_SYN_TYPE	LBUS_SYN_REG_M16A0_T
#define M16_A0_CTOP_GBUS_SYN_TYPE	GBUS_SYN_REG_M16A0_T
#define M16_A0_CTOP_VSD_SYN_TYPE	VSD_SYN_REG_M16A0_T
#define M16_A0_CTOP_ND0_SYN_TYPE	ND0_SYN_REG_M16A0_T
#define M16_A0_CTOP_IMX_SYN_TYPE	IMX_SYN_REG_M16A0_T
#define M16_A0_CTOP_GSC_SYN_TYPE	GSC_SYN_REG_M16A0_T
#define M16_A0_CTOP_CVI_SYN_TYPE	CVI_SYN_REG_M16A0_T
#define M16_A0_CTOP_CCO_SYN_TYPE	CCO_SYN_REG_M16A0_T
#define M16_A0_CTOP_SRE_SYN_TYPE	SRE_SYN_REG_M16A0_T
#define M16_A0_CTOP_MCU_SYN_TYPE	MCU_SYN_REG_M16A0_T
#define M16_A0_CTOP_FMC_SYN_TYPE	FMC_SYN_REG_M16A0_T
#define M16_A0_CTOP_FME_SYN_TYPE	FME_SYN_REG_M16A0_T
#define M16_A0_CTOP_M0_SYN_TYPE		M0_SYN_REG_M16A0_T
#define M16_A0_CTOP_M1_SYN_TYPE		M1_SYN_REG_M16A0_T
#define M16_A0_CTOP_GFX_SYN_TYPE	GFX_SYN_REG_M16A0_T
#define M16_A0_CTOP_VENC_SYN_TYPE	VENC_SYN_REG_M16A0_T
#define M16_A0_CTOP_AUD_SYN_TYPE	AUD_SYN_REG_M16A0_T
#define M16_A0_CTOP_TE_SYN_TYPE		TE_SYN_REG_M16A0_T
#define M16_A0_CTOP_HDMI_SYN_TYPE	HDMI_SYN_REG_M16A0_T
#define M16_A0_CTOP_GPU_SYN_TYPE	GPU_SYN_REG_M16A0_T
#define M16_A0_CTOP_DPE_SYN_TYPE	DPE_SYN_REG_M16A0_T
#define M16_A0_CTOP_PERI_SYN_TYPE	PERI_SYN_REG_M16A0_T
#define M16_A0_CTOP_EMMC_SYN_TYPE	EMMC_SYN_REG_M16A0_T
#define M16_A0_CTOP_FMC_TYPE		CTOP_FMC_REG_M16A0_T
#define M16_A0_CTOP_VENC_TYPE		CTOP_VENC_REG_M16A0_T
#define M16_A0_CTOP_AUD_TYPE		CTOP_AUD_REG_M16A0_T
#define M16_A0_CTOP_TE_TYPE			CTOP_TE_REG_M16A0_T
#define M16_A0_CTOP_DEMOD_TYPE		CTOP_DEMOD_REG_M16A0_T
#define M16_A0_CTOP_DPE_TYPE		CTOP_DPE_REG_M16A0_T

#ifdef __cplusplus
}
#endif

#endif	/* __CTOP_CTRL_REG_M16A0_H__ */

/* from 'm16a0_ctop_v140.csv' 20150511 17:28:26 KST by getregs v2.9 */
