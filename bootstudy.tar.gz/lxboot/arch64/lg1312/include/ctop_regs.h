#ifndef __ARCH_CTOP_REGS_HEAD_H__
#define __ARCH_CTOP_REGS_HEAD_H__

#include <arch/a0/ctop_regs.h>
#include <arch/a0/cpu_top_regs.h>

#if !defined(CONFIG_BOARD_TYPE_FPGA)
#define CTOP_CTRL_READ(_m, _r)			(*((uint32_t*)(&ctop_regs->_m->_r)))
#define CTOP_CTRL_WRITE(_m, _r, _v)		(*((uint32_t*)(&ctop_regs->_m->_r)) = _v)
extern volatile CTOP_CTRL_REG_T *ctop_regs;
#else
#define CTOP_CTRL_READ(_m, _r)			0	
#define CTOP_CTRL_WRITE(_m, _r, _v)		
#endif

#define CPU_TOP_READ(_r)			(*((uint32_t*)(&cpu_top_regs->_r)))
#define CPU_TOP_WRITE(_r, _v)		(*((uint32_t*)(&cpu_top_regs->_r)) = _v)

extern volatile CPU_TOP_REG_T *cpu_top_regs;

#endif	// __ARCH_CTOP_REGS_HEAD_H__
