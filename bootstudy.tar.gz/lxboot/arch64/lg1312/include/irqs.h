#ifndef __ARCH_IRQS_H__
#define __ARCH_IRQS_H__

/**
 * IPIs IDs
 */
#define IPI_0      0 /**< Inter Processor Interrupt ID 0 */
#define IPI_1      1 /**< Inter Processor Interrupt ID 1 */
#define IPI_2      2 /**< Inter Processor Interrupt ID 2 */
#define IPI_3      3 /**< Inter Processor Interrupt ID 3 */
#define IPI_4      4 /**< Inter Processor Interrupt ID 4 */
#define IPI_5      5 /**< Inter Processor Interrupt ID 5 */
#define IPI_6      6 /**< Inter Processor Interrupt ID 6 */
#define IPI_7      7 /**< Inter Processor Interrupt ID 7 */
#define IPI_8      8 /**< Inter Processor Interrupt ID 8 */
#define IPI_9      9 /**< Inter Processor Interrupt ID 9 */
#define IPI_10    10 /**< Inter Processor Interrupt ID 10 */
#define IPI_11    11 /**< Inter Processor Interrupt ID 11 */
#define IPI_12    12 /**< Inter Processor Interrupt ID 12 */
#define IPI_13    13 /**< Inter Processor Interrupt ID 13 */
#define IPI_14    14 /**< Inter Processor Interrupt ID 14 */
#define IPI_15    15 /**< Inter Processor Interrupt ID 15 */

#define SCHEDULER_IPI					IPI_0
#define CPU_WAKEUP_IPI					IPI_1
#define CPU_EXIT_IPI					IPI_2
#define CPU_EXIT2_IPI					IPI_3

#define IRQ_LEGACY_FIQ 				28
#define IRQ_SECURE_LOCALTIMER 		29
#define IRQ_LOCALTIMER      		30
#define IRQ_LEGACY_IRQ 				31

#define IRQ_GIC_START 				32

#define IRQ_UART0			(IRQ_GIC_START +  0)	/* UART 0 */
#define IRQ_UART1			(IRQ_GIC_START +  1)
#define IRQ_UART2			(IRQ_GIC_START +  2)
#define IRQ_SPI0			(IRQ_GIC_START +  3)	/* SPI */
#define IRQ_SPI1			(IRQ_GIC_START +  4)	/* SPI */
#define IRQ_SCI				(IRQ_GIC_START +  5)	/* Smart Card Interface */
#define IRQ_TIMER0_1		(IRQ_GIC_START +  6)	/* Timer 0 and 1 */
#define IRQ_WATCHDOG		(IRQ_GIC_START +  7)	/* Watchdog timer */
#define IRQ_GPIO0_2			(IRQ_GIC_START +  8)	/* GPIO 0 */
#define IRQ_GPIO3_5			(IRQ_GIC_START +  9)
#define IRQ_GPIO6_8			(IRQ_GIC_START + 10)
#define IRQ_GPIO9_11		(IRQ_GIC_START + 11)
#define IRQ_GPIO12_14		(IRQ_GIC_START + 12)
#define IRQ_GPIO15_17		(IRQ_GIC_START + 13)

#define IRQ_I2C0			(IRQ_GIC_START + 14)	/* I2C0 */
#define IRQ_I2C1			(IRQ_GIC_START + 15)
#define IRQ_I2C2			(IRQ_GIC_START + 16)
#define IRQ_I2C3			(IRQ_GIC_START + 17)
#define IRQ_I2C4			(IRQ_GIC_START + 18)
#define IRQ_I2C5			(IRQ_GIC_START + 19)
#define IRQ_I2C6			(IRQ_GIC_START + 20)
#define IRQ_I2C7			(IRQ_GIC_START + 21)
#define IRQ_I2C8			(IRQ_GIC_START + 22)
#define IRQ_I2C9			(IRQ_GIC_START + 23)

#define IRQ_DMAC			(IRQ_GIC_START + 24)	/* DMAINT */
#define IRQ_DVBCI			(IRQ_GIC_START + 25)
#define IRQ_RSV0 			(IRQ_GIC_START + 26)
#define IRQ_TIMER64			(IRQ_GIC_START + 27)
#define IRQ_SC				(IRQ_GIC_START + 28)
#define	IRQ_DMAC330			(IRQ_GIC_START + 29)
#define IRQ_IRBLASTER 		(IRQ_GIC_START + 30)
#define IRQ_GEM_ETHER		(IRQ_GIC_START + 31)
#define IRQ_TZ_UART			(IRQ_GIC_START + 32)
#define IRQ_TZ_TIMER		(IRQ_GIC_START + 33)

#define IRQ_SDHC			(IRQ_GIC_START + 87) 	/* emmc irq */
#define IRQ_NAND			(IRQ_GIC_START + 88) 	/* nand irq */

#define NR_IRQS				(IRQ_GIC_START + 128)
#define IRQ_GIC_END			NR_IRQS

#endif /* __IRQS_H__ */
