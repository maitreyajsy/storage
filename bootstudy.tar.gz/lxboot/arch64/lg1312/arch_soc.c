/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <string.h>
#include <timer.h>

//#define DBG
#include <debug.h>

#if 0//((defined(CONFIG_BOOT_SINGLE) || defined(FIRST_BOOT)) && !defined(CONFIG_BOARD_TYPE_FPGA))

#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3

typedef struct
{
	uint32_t	opcode;
	uint32_t	operand;
} reg_param_t;

static reg_param_t h15_bus_gating_cmm[] = {
	{0xc8600040, 0x00000003},
	{0xc8600440, 0x000000ff},
	{0xc8601040, 0x00000003},
	{0xc8601440, 0x00000003},
	{0xc8601840, 0x00000003},
	{0xc8601c40, 0x0000000f},
	{0xc8602c40, 0x0000000f},
	{0xc8604040, 0x00000003},
	{0xc8609040, 0x0000000f},
	{0xc8609840, 0x00000003},
	{0xc8708040, 0x0000000f},
	{0xc8714040, 0x0000000f},
	{0xc8744040, 0x0000003f},
	{0xc8750040, 0x0000003f},
	{0xc898c040, 0x0000000f},
	{0xc898d840, 0x00000003},
	{0xc898e040, 0x00000003},
	{0xc898e440, 0x00000003},
	{0xc8ac0040, 0x0000000f},
	{0xc8aff040, 0x0000003f},
};

static reg_param_t h15_bus_manager_cmm[] = {
	/*BW Limiter*/
	{0xc8c00240, 0xffffffff},
	{0xc8c00244, 0xffffffff},
	{0xc8c002b0, 0x0fffffff},
	{0xc8c00040, 0xffffffff},
	{0xc8c00044, 0xffffffff},
	{0xc8c000b0, 0x0fffffff},
	{0xc880a040, 0xffffffff},
	{0xc880a044, 0xffffffff},
	{0xc880a0b0, 0x0fffffff},
	{0xc880a240, 0xffffffff},
	{0xc880a244, 0xffffffff},
	{0xc880a2b0, 0x0fffffff},
	{0xc880a440, 0xffffffff},
	{0xc880a444, 0xffffffff},
	{0xc880a4b0, 0x0fffffff},
	{0xc880a640, 0xffffffff},
	{0xc880a644, 0xffffffff},
	{0xc880a6b0, 0x0fffffff},
	{0xc880a840, 0xffffffff},
	{0xc880a844, 0xffffffff},
	{0xc880a8b0, 0x0fffffff},
	{0xc880aa40, 0xffffffff},
	{0xc880aa44, 0xffffffff},
	{0xc880aab0, 0x0fffffff},
	{0xc880ac40, 0xffffffff},
	{0xc880ac44, 0xffffffff},
	{0xc880acb0, 0x0fffffff},
	{0xc8455040, 0xffffffff},
	{0xc8455044, 0xffffffff},
	{0xc84550b0, 0x0fffffff},
	{0xc8455240, 0xffffffff},
	{0xc8455244, 0xffffffff},
	{0xc84552b0, 0x0fffffff},
	{0xc8455440, 0xffffffff},
	{0xc8455444, 0xffffffff},
	{0xc84554b0, 0x0fffffff},
	{0xc8455640, 0xffffffff},
	{0xc8455644, 0xffffffff},
	{0xc84556b0, 0x0fffffff},
	{0xc8455840, 0xffffffff},
	{0xc8455844, 0xffffffff},
	{0xc84558b0, 0x0fffffff},
	{0xc8455a40, 0xffffffff},
	{0xc8455a44, 0xffffffff},
	{0xc8455ab0, 0x0fffffff},
	{0xc8455c40, 0xffffffff},
	{0xc8455c44, 0xffffffff},
	{0xc8455cb0, 0x0fffffff},
	{0xc8213040, 0xffffffff},
	{0xc8213044, 0xffffffff},
	{0xc82130b0, 0x0fffffff},
	{0xc8213240, 0xffffffff},
	{0xc8213244, 0xffffffff},
	{0xc82132b0, 0x0fffffff},
	{0xc8213440, 0xffffffff},
	{0xc8213444, 0xffffffff},
	{0xc82134b0, 0x0fffffff},
	{0xc8213640, 0xffffffff},
	{0xc8213644, 0xffffffff},
	{0xc82136b0, 0x0fffffff},
	{0xc8213840, 0xffffffff},
	{0xc8213844, 0xffffffff},
	{0xc82138b0, 0x0fffffff},
	{0xc8213a40, 0xffffffff},
	{0xc8213a44, 0xffffffff},
	{0xc8213ab0, 0x0fffffff},
	{0xc8213c40, 0xffffffff},
	{0xc8213c44, 0xffffffff},
	{0xc8213cb0, 0x0fffffff},
	{0xc8213e40, 0xffffffff},
	{0xc8213e44, 0xffffffff},
	{0xc8213eb0, 0x0fffffff},
	{0xc8214040, 0xffffffff},
	{0xc8214044, 0xffffffff},
	{0xc82140b0, 0x0fffffff},
	{0xc8214240, 0xffffffff},
	{0xc8214244, 0xffffffff},
	{0xc82142b0, 0x0fffffff},
	{0xc8214440, 0xffffffff},
	{0xc8214444, 0xffffffff},
	{0xc82144b0, 0x0fffffff},
	{0xc8214640, 0xffffffff},
	{0xc8214644, 0xffffffff},
	{0xc82146b0, 0x0fffffff},
	{0xc8214840, 0xffffffff},
	{0xc8214844, 0xffffffff},
	{0xc82148b0, 0x0fffffff},
	{0xc8214a40, 0xffffffff},
	{0xc8214a44, 0xffffffff},
	{0xc8214ab0, 0x0fffffff},
	{0xc8214c40, 0xffffffff},
	{0xc8214c44, 0xffffffff},
	{0xc8214cb0, 0x0fffffff},
	{0xc8214e40, 0xffffffff},
	{0xc8214e44, 0xffffffff},
	{0xc8214eb0, 0x0fffffff},
	/* port balencer */
	{0xc880a030, 0x00000000},
	{0xc880a034, 0x3f111111},
	{0xc880a038, 0x3f111111},
	{0xc880a230, 0x00000000},
	{0xc880a234, 0x3f222222},
	{0xc880a238, 0x3f222222},
	{0xc880a430, 0x00000000},
	{0xc880a434, 0x3f000000},
	{0xc880a438, 0x3f000000},
	{0xc880a630, 0x00000000},
	{0xc880a634, 0x3f000000},
	{0xc880a638, 0x3f000000},
	{0xc880a830, 0x00000000},
	{0xc880a834, 0x3f111133},
	{0xc880a838, 0x3f111133},
	{0xc880aa30, 0x00000000},
	{0xc880aa34, 0x3f111111},
	{0xc880aa38, 0x3f111111},
	{0xc880ac30, 0x00000000},
	{0xc880ac34, 0x3f333333},
	{0xc880ac38, 0x3f333333},
	{0xc8455030, 0x00000000},
	{0xc8455034, 0x3f111111},
	{0xc8455038, 0x3f111111},
	{0xc8455230, 0x00000000},
	{0xc8455234, 0x3f111111},
	{0xc8455238, 0x3f111111},
	{0xc8455430, 0x00000000},
	{0xc8455434, 0x3f222222},
	{0xc8455438, 0x3f222222},
	{0xc8455630, 0x00000000},
	{0xc8455634, 0x3f333333},
	{0xc8455638, 0x3f333333},
	{0xc8455830, 0x00000000},
	{0xc8455834, 0x3f222222},
	{0xc8455838, 0x3f222222},
	{0xc8455a30, 0x00000000},
	{0xc8455a34, 0x3f333333},
	{0xc8455a38, 0x3f333333},
	{0xc8455c30, 0x00000000},
	{0xc8455c34, 0x3f332222},
	{0xc8455c38, 0x3f332222},
	{0xc8213030, 0x00000000},
	{0xc8213034, 0x3f111111},
	{0xc8213038, 0x3f111111},
	{0xc8213230, 0x00000000},
	{0xc8213234, 0x3f222222},
	{0xc8213238, 0x3f222222},
	{0xc8213430, 0x00000000},
	{0xc8213434, 0x3f333333},
	{0xc8213438, 0x3f333333},
	{0xc8213630, 0x00000000},
	{0xc8213634, 0x3f221122},
	{0xc8213638, 0x3f221122},
	{0xc8213830, 0x00000000},
	{0xc8213834, 0x3f111111},
	{0xc8213838, 0x3f111111},
	{0xc8213a30, 0x00000000},
	{0xc8213a34, 0x3f111111},
	{0xc8213a38, 0x3f111111},
	{0xc8213c30, 0x00000000},
	{0xc8213c34, 0x3f222222},
	{0xc8213c38, 0x3f222222},
	{0xc8213e30, 0x00000000},
	{0xc8213e34, 0x3f000000},
	{0xc8213e38, 0x3f000000},
	{0xc8214030, 0x00000000},
	{0xc8214034, 0x3f000000},
	{0xc8214038, 0x3f000000},
	{0xc8214230, 0x00000000},
	{0xc8214234, 0x3f222222},
	{0xc8214238, 0x3f222222},
	{0xc8214430, 0x00000000},
	{0xc8214434, 0x3f111111},
	{0xc8214438, 0x3f111111},
	{0xc8214630, 0x00000000},
	{0xc8214634, 0x3f333333},
	{0xc8214638, 0x3f333333},
	{0xc8214830, 0x00000000},
	{0xc8214834, 0x3f110000},
	{0xc8214838, 0x3f110000},
	{0xc8214a30, 0x00000000},
	{0xc8214a34, 0x3f111100},
	{0xc8214a38, 0x3f111100},
	{0xc8214c30, 0x00000000},
	{0xc8214c34, 0x3f222222},
	{0xc8214c38, 0x3f222222},
	{0xc8214e30, 0x00000000},
	{0xc8214e34, 0x3f333333},
	{0xc8214e38, 0x3f333333},
	/* vdm priority */
	{0xc82136c4, 0x03020100},
	{0xc82136c8, 0x0a080504},
	{0xc82138c4, 0x03020100},
	{0xc82138c8, 0x12100504},
	{0xc88040c4, 0x4005e4c1},
	{0xc88040e4, 0x4005e4c1},
	{0xc8804104, 0x4005e4c1},
	{0xc8804124, 0x4005e4c1},
	{0xc8804144, 0x4005e4c1},
	{0xc8804164, 0x4005e4c1},
	{0xc8804184, 0x4005e4c1},
	{0xc88041a4, 0x4005e4c1},
	{0xc84040c4, 0x4005e4c1},
	{0xc84040e4, 0x4005e4c1},
	{0xc8404104, 0x4005e4c1},
	{0xc8404124, 0x4005e4c1},
	{0xc8404144, 0x4005e4c1},
	{0xc8404164, 0x4005e4c1},
	{0xc8404184, 0x4005e4c1},
	{0xc84041a4, 0x4005e4c1},
	{0xc85040c4, 0x4005e4c1},
	{0xc85040e4, 0x4005e4c1},
	{0xc8504104, 0x4005e4c1},
	{0xc8504124, 0x4005e4c1},
	{0xc8504144, 0x4005e4c1},
	{0xc8504164, 0x4005e4c1},
	{0xc8504184, 0x4005e4c1},
	{0xc85041a4, 0x4005e4c1},
	{0xc8404104, 0x8005e4c1},
	{0xc8213628, 0x10070000},

};

static void reg_param_set(reg_param_t *param, int cnt);
static void set_bus_gating(void);
static void set_bus_manager(void);

static void reg_param_set(reg_param_t *param, int cnt)
{
	while(cnt--)
	{
		switch((param->opcode&REG_PARAM_OP_GROUP_MASK))
		{
			case REG_PARAM_OP_GROUP_WAIT:	// wait
				udelay(param->operand);
				DEBUG("delay(_%dms);\n", param->operand/1000);
				break;

			case REG_PARAM_OP_GROUP_CHECK:	// check
				DEBUG("REG_PARAM_OP_GROUP_CHECK\n");
				break;

			case REG_PARAM_OP_GROUP_RESERVED:
				DEBUG("REG_PARAM_OP_GROUP_RESERVED\n");
				break;

			default:	// REG_PARAM_OP_GROUP_WRITE
				IO_WRITE((ulong)param->opcode, param->operand);
				DEBUG("IO_WRITE( 0x%08x, 0x%08x);\n", param->opcode, param->operand);
				break;
		}
		//debug("0x%08x 0x%08x\n", param->opcode, param->operand);
		param++;
	}
}

static void set_bus_gating(void)
{
	reg_param_set(h15_bus_gating_cmm, ARRAY_SIZE(h15_bus_gating_cmm));
}

static void set_bus_manager(void)
{
	reg_param_set(h15_bus_manager_cmm, ARRAY_SIZE(h15_bus_manager_cmm));
}

void soc_init(void)
{
	set_bus_gating();
	set_bus_manager();
}


#else
void soc_init(void) {}
#endif

#if defined(USE_SU_TOP) && !defined(FIRST_BOOT)

#define	DDR_SIZE_GPIO		GPIO_MODEL_OPT14
#define	DDR_SIZE_1_5GB		0
#define	DDR_SIZE_2_0GB		1

#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3

typedef struct
{
	uint32_t	opcode;
	uint32_t	operand;
} reg_param_t;

#include <iboot_param.h>
#include <arch/su_top.h>
#include <gpio.h>

static void reg_param_set_su_top(reg_param_t *param, int cnt)
{
	while(cnt--)
	{
		switch((param->opcode&REG_PARAM_OP_GROUP_MASK))
		{
			case REG_PARAM_OP_GROUP_WAIT:	// wait
				udelay(param->operand);
				DEBUG("delay(_%dms);\n", param->operand/1000);
				break;

			case REG_PARAM_OP_GROUP_CHECK:	// check
				DEBUG("REG_PARAM_OP_GROUP_CHECK\n");
				break;

			case REG_PARAM_OP_GROUP_RESERVED:
				DEBUG("REG_PARAM_OP_GROUP_RESERVED\n");
				break;

			default:	// REG_PARAM_OP_GROUP_WRITE
				IO_WRITE((ulong)param->opcode, param->operand);
				DEBUG("IO_WRITE( 0x%08x, 0x%08x);\n", param->opcode, param->operand);
				break;
		}
		write_iboot_su_top_value(param->opcode, param->operand);
		//debug("0x%08x 0x%08x\n", param->opcode, param->operand);
		param++;
	}
}

static int get_ddr_size_type(void)
{
	gpio_set_direction(DDR_SIZE_GPIO, GPIO_DIR_INPUT);

	if(gpio_get_value(DDR_SIZE_GPIO) == GPIO_LOW)
		return DDR_SIZE_2_0GB;
	else
		return DDR_SIZE_1_5GB;
}

static int check_ddr_clk(void)
{
#define GPU_PLL_REG0 	0xc8c73418
#define GPU_PLL_REG1 	0xc8c7341C
#define PLL_648_0 		0x6800001c
#define PLL_648_1 		0x0d248000
	if(REG_READ(GPU_PLL_REG0) == PLL_648_0 &&
			REG_READ(GPU_PLL_REG1) == PLL_648_1)
		return 1;

	return 0;
}

/* TODO : call after set_addr_switch() */
void set_su_top(void)
{
	if(get_chip_rev() < LX_CHIP_REV(M16, B0))
		return;

	if(get_ddr_size_type() == DDR_SIZE_1_5GB)
		return;

	if(check_ddr_clk())
		return;

	init_iboot_su_top();
	reg_param_set_su_top(su_top_cmm, ARRAY_SIZE(su_top_cmm));

}
#else
void set_su_top(void) {}
#endif


