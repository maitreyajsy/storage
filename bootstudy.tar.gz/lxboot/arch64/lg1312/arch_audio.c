/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <timer.h>
#include <i2c.h>
#include <thread.h>
#include <audio.h>

#if defined(CONFIG_AUDIO) || USE_AUDIO
#include <arch/se_codec_m16.h>

#ifndef LG1312_ADEC_BASE
#error "Have to define the LG1312_ADEC_BASE address !!!"
#endif

//#define ADEC_DEBUG
//#define ENABLE_CTOP_REG_DEBUG
//#define ENABLE_ADEC_REG_DEBUG

#ifdef ADEC_DEBUG
#define ADEC_PRINT							printf
#else
#define ADEC_PRINT(format, args...)			do{} while(0)
#endif

/*
*******************************************************************************
*                  GLOBAL  MACROS
*******************************************************************************
*/
/* define delay value */
#define AUD_RESET_DELAY_5US			5		//5us
#define AUD_READY_DELAY_1MS			1		//1ms
#define AUD_READY_DELAY_100MS		100		//100ms

/* define ADEC register  address */
#define ADEC_AUD_SPDIF_MUTE			(LG1312_ADEC_BASE + 0x110)
#define ADEC_AUD_SWRESET			(LG1312_ADEC_BASE + 0x238)
#define ADEC_AUD_DSP1OFFSET5		(LG1312_ADEC_BASE + 0x2B4)
#define ADEC_AUD_DSP1OFFSET6		(LG1312_ADEC_BASE + 0x2B8)
#define ADEC_AUD_CHIP_VERSION		(LG1312_ADEC_BASE + 0x6E8)
#define ADEC_AUD_DSP_VERSION		(LG1312_ADEC_BASE + 0x6FC)

/* define DDR  memory address */
#ifndef AUDIO_DSP_BASE
#error "Have to define AUDIO_DSP_BASE !!!"
#endif

#define ADEC_DSP1_FW_ADDR			(AUDIO_DSP_BASE)
#define ADEC_DSP1_RUNNING_ADDR		(AUDIO_DSP_BASE + 0x10000)	//128KB
#define ADEC_CHIP_VER_VALUE			(0x18A0)

/*
*******************************************************************************
*                  STATIC FUNCTIONS
*******************************************************************************
*/
static void ADEC_LoadDSP1Codec(void)
{
	UINT32	ui32CodecSize = 0;
	UINT32	*pui32Codec = NULL;
	UINT32	*pui32CodecAddr = (UINT32 *)ADEC_DSP1_FW_ADDR;

#ifdef ENABLE_ADEC_REG_DEBUG
	UINT32	data;
#endif

	 ADEC_PRINT("ADEC_SetDTOA_Clock start!!!\n");

	 //Set audio SPDIF clock using DTO-A clock
	 REG_WRITE(0xC830E028, 0x11ECA3E8);  // adto1 adto0 add_value
	 REG_WRITE(0xC830E02C, 0x00010000);  // adto1 update assert
	 REG_WRITE(0xC830E02C, 0x00000000);  // adto1 update assert
	 REG_WRITE(0xC830E048, 0x00000000);  // adto_clk <- adto1_clk, hdmi_clk <- hdmi0_clk
	 REG_WRITE(0xC830E04C, 0x0A0A0A00);  // fs23clk <- adto x1/2, fs21clk <- adto x1/2, fs20clk <- adto x1/2
	 REG_WRITE(0xC830E050, 0x00000A0A);  // fs25clk <- adto x1/2, fs24clk <- adto x1/2
	 REG_WRITE(0xC830E058, 0x000000A0);  // fs22clk <- adto x1/2

	 udelay(AUD_RESET_DELAY_5US);

#ifdef ENABLE_CTOP_REG_DEBUG
	 ADEC_PRINT("addr = 0xC830E028, data = 0x%08X(0x11ECA3E8)\n", REG_READ(0xC830E028));
	 ADEC_PRINT("addr = 0xC830E02C, data = 0x%08X(0x00000000)\n", REG_READ(0xC830E02C));
	 ADEC_PRINT("addr = 0xC830E048, data = 0x%08X(0x00000000)\n", REG_READ(0xC830E048));
	 ADEC_PRINT("addr = 0xC830E04C, data = 0x%08X(0x0A0A0A00)\n", REG_READ(0xC830E04C));
	 ADEC_PRINT("addr = 0xC830E050, data = 0x%08X(0x00000A0A)\n", REG_READ(0xC830E050));
	 ADEC_PRINT("addr = 0xC830E058, data = 0x%08X(0x000000A0)\n", REG_READ(0xC830E058));
#endif

	 ADEC_PRINT("ADEC_LoadDSP1Codec start!!!\n");

	//Reset Low : APB, SRC, ADEC DSP and AAD etc...
	REG_WRITE(ADEC_AUD_SWRESET, 0x0000);
	udelay(AUD_RESET_DELAY_5US);

#ifdef ENABLE_ADEC_REG_DEBUG
	data = REG_READ(ADEC_AUD_SWRESET);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x0)\n", ADEC_AUD_SWRESET, data);
#endif

	//Reset High : APB and SPDIF etc...
	//Reset Low : ADEC DSP1
	REG_WRITE(ADEC_AUD_SWRESET, 0x23);
	udelay(AUD_RESET_DELAY_5US);

	//Clear ADEC Register because M16 SRAM is not cleared.
	REG_WRITE(ADEC_AUD_DSP_VERSION, 0x0);

	//set chip version
	REG_WRITE(ADEC_AUD_CHIP_VERSION, ADEC_CHIP_VER_VALUE);

	//set address for DSP1 fw and running memory
	REG_WRITE(ADEC_AUD_DSP1OFFSET5, ADEC_DSP1_FW_ADDR);
	REG_WRITE(ADEC_AUD_DSP1OFFSET6, ADEC_DSP1_RUNNING_ADDR);

	// add HOST S/PDIF MUTE FREE for M16
	REG_WRITE(ADEC_AUD_SPDIF_MUTE, 0x20);

#ifdef ENABLE_ADEC_REG_DEBUG
	data = REG_READ(ADEC_AUD_SPDIF_MUTE);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x20)\n", ADEC_AUD_SPDIF_MUTE, data);

	data = REG_READ(ADEC_AUD_SWRESET);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x23)\n", ADEC_AUD_SWRESET, data);

	data = REG_READ(ADEC_AUD_CHIP_VERSION);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x%X)\n", ADEC_AUD_CHIP_VERSION, data, ADEC_CHIP_VER_VALUE);

	data = REG_READ(ADEC_AUD_DSP1OFFSET5);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x%X)\n", ADEC_AUD_DSP1OFFSET5, data, ADEC_DSP1_FW_ADDR);

	data = REG_READ(ADEC_AUD_DSP1OFFSET6);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x%X)\n", ADEC_AUD_DSP1OFFSET6, data, ADEC_DSP1_RUNNING_ADDR);
#endif

	//Copy LGSE codec for DSP1
	ui32CodecSize = sizeof(se_codec_m16);
	pui32Codec	  = (UINT32 *)se_codec_m16;

	//Copy codec fw from memory to dsp1 memory
	memcpy(pui32CodecAddr, pui32Codec, ui32CodecSize);

	//Update cache memory to DDR memory
	dcache_clean_range((ulong)pui32CodecAddr, ui32CodecSize);

#ifdef ENABLE_ADEC_REG_DEBUG
	ADEC_PRINT ("ADEC LoadCodec : FW Loaded Done(%s)!!!\n", "se_codec_m16");
#endif

	//Set DSP1 swreset register
	REG_WRITE(ADEC_AUD_SWRESET, 0x2823);

#ifdef ENABLE_ADEC_REG_DEBUG
	data = REG_READ(ADEC_AUD_SWRESET);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x2823)\n", ADEC_AUD_SWRESET, data);

	mdelay(AUD_READY_DELAY_100MS);

	data = REG_READ(ADEC_AUD_DSP_VERSION);
	ADEC_PRINT("addr = 0x%X, data = 0x%X(0x12345678)\n", ADEC_AUD_DSP_VERSION, data);
#endif

	ADEC_PRINT("ADEC_LoadDSP1Codec end!!!\n");
	return;
}

int  arch_audio_init(void)
{
#ifdef ADEC_DEBUG
	ADEC_PRINT("Audio_init start!!!\n");
#endif

	//check a chip revision.
	if (get_chip_rev() >= LX_CHIP_REV(M16, A0))
	{
		//Initializes the ADEC registers and load firmware.
		(void)ADEC_LoadDSP1Codec();

		printf("Audio_init end!!!\n");
	}
	else
	{
		printf("Audio_init : Not Supported(chip = 0x%X)\n", get_chip_rev());
	}

	return 0;
}
///////////////////////////////

#endif
