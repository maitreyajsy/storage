#include <common.h>
#include <top_ddrc.h>
#include <iboot_param.h>

#ifndef CONFIG_SHADOW_HEADER_BIN
/* include cmm -> header file */
#include <top.h>
#include <lm.h>
#include <gm.h>
#include <bus.h>

#include <lm_exit.h>
#include <gm_exit.h>
#include <lm_exit_post.h>
#include <gm_exit_post.h>

#define get_cmm_size(x) 	ARRAY_SIZE(x)

#else//CONFIG_SHADOW_HEADER_BIN

#define INCLUDE_CMM(x) 	static reg_param_t *x##_cmm; static uint32_t x##_cmm_size;

INCLUDE_CMM(top)		// top_cmm, top_cmm_size
INCLUDE_CMM(lm)
INCLUDE_CMM(gm)
INCLUDE_CMM(bus)
INCLUDE_CMM(lm_exit)
INCLUDE_CMM(gm_exit)
INCLUDE_CMM(lm_exit_post)
INCLUDE_CMM(gm_exit_post)

#define get_cmm_size(x) 	(x##_size / sizeof(reg_param_t))

#endif//CONFIG_SHADOW_HEADER_BIN


#define RETENTION_ST_LIMIT 		(500 * 1000)// 500ms
/*
 * gpio18 is used ddr io retention disble pin.
 * refer to RETENTION_DISABLE pin in lg1312 system board schematic.
 *
 * After Exiting DDR Self-Refresh,
 * gpio18 is used to request micom to disable ddr io retention from rom.
 */
#define IORET_GPIO		18

static int read_shadow_header_bin(void);

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////// get ddr vendor // ///////////////////////////////////////

#define DDR_VENDOR_GPIO0	GPIO_MODEL_OPT8
#define DDR_VENDOR_GPIO1	GPIO_MODEL_OPT7

#define DDR_VENDOR_Ax_BASE	1
#define DDR_VENDOR_Bx_BASE	2

/** 
 * ddr vendor hw opt
 *
 * OPT7/8
 * 00 : hynix_v1.2
 * 01 : samsung_v1.2
 * 10 : hynix_v1.1
 * 11 : samsung_v1.1
 *
 * ref: circuit
 */

enum 
{
	DDR_SK_12 = 0,
	DDR_SS_12,	//1
	DDR_MR_12,	//2
	DDR_NC,		//3
};

char ddr_vendor_str[4][10] = {
	"DDR-SK2",
	"DDR-SS2",
	"DDR-MR2",
	"NC",
};

static int get_ddr_vendor(void)
{
	u32 bit0;
	u32 bit1;
	u32 vendor;

	gpio_set_direction(DDR_VENDOR_GPIO0, GPIO_DIR_INPUT);
	gpio_set_direction(DDR_VENDOR_GPIO1, GPIO_DIR_INPUT);

	bit0 = gpio_get_value(DDR_VENDOR_GPIO0);
	bit1 = gpio_get_value(DDR_VENDOR_GPIO1);

	vendor = ((bit1 & 0x1) << 1) | (bit0 & 0x1);

	if(vendor > DDR_MR_12)
	{
		error("fail detect ddr vendor!, set default vendor\n");
		vendor = DDR_SK_12;
	}

	printf("[%s]", ddr_vendor_str[vendor]);
	
	return vendor;
}

////////////////////////////////////////////////////////////////////////////////
///////////////////////// impl /////////////////////////////////////////////////

static void ddr_ioret_disable(void)
{
	gpio_set_direction(IORET_GPIO, GPIO_DIR_OUTPUT);
	gpio_set_value(IORET_GPIO, GPIO_HIGH);
}

static void tzasc_allow_secure(void)
{
#define TZC400_0_BASE			(0xc8900000)
#define TZC400_1_BASE			(TZC400_0_BASE + 0x1000)
#define TZC400_2_BASE			(TZC400_0_BASE + 0x2000)
#define TZC400_3_BASE			(TZC400_0_BASE + 0x3000)
#define DDRC_LM_BASE			(TZC400_0_BASE + 0x4000)

#define TZC400_4_BASE			(0xc8910000)
#define TZC400_5_BASE			(TZC400_4_BASE + 0x1000)
#define TZC400_6_BASE			(TZC400_4_BASE + 0x2000)
#define TZC400_7_BASE			(TZC400_4_BASE + 0x3000)
#define DDRC_GM_BASE			(TZC400_4_BASE + 0x4000)


	/*
	 * When tzc-400 is enabled by ddrc, we must open filter0 and let 
	 * permission of background region(region0) be secure r/w.
	 * Otherwise lg1312 will die!!
	 * Gate keeper reg (TZC400_X_BASE + 0x008)
	 * - [0]: request the gate of the filter0 to be open.
	 * Region attribute reg (TZC400_X_BASE + 0x110)
	 * - [31]: s_wr_en, [30]:s_rd_en, [3:0]:region en for filter0.
	 */
	if(REG_READ(DDRC_LM_BASE + 0xc0) & (1 << 27))
	{
		REG_WRITE(TZC400_0_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_0_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_0_BASE + 0x114, 0x00010001);
		REG_WRITE(TZC400_1_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_1_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_2_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_2_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_3_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_3_BASE + 0x110, 0xc0000001);
		debug("tzasc lm port setup-done\n");
	}

	if(REG_READ(DDRC_GM_BASE + 0xc0) & (1 << 27))
	{
		REG_WRITE(TZC400_4_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_4_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_4_BASE + 0x114, 0x00010001);
		REG_WRITE(TZC400_5_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_5_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_6_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_6_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_7_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_7_BASE + 0x110, 0xc0000001);
		debug("tzasc gm port setup-done\n");
	}
}


static uint32_t check_retention_status(void)
{
	uint32_t val;
	uint32_t status = 0;

	val = REG_READ(0xc8904320);
	debug("LM PAD_CTRL_VAL=0x%08x\n", val);
	status = (val >> 31);

	val = REG_READ(0xc8914320);
	debug("GM PAD_CTRL_VAL=0x%08x\n", val);
	status &= (val >> 31);

	return !status;
}

static void setup_cold_boot(void)
{
	reg_param_set(top_cmm, get_cmm_size(top_cmm));
	debug("top setup-done\n");

	reg_param_set(lm_cmm, get_cmm_size(lm_cmm));
	debug("lm setup-done\n");

	reg_param_set(gm_cmm, get_cmm_size(gm_cmm));
	debug("gm setup-done\n");

	ddr_ioret_disable();
}

static void setup_instant_boot(void)
{
	uint32_t usec;
	reg_param_set(top_cmm, get_cmm_size(top_cmm));
	debug("top setup-done\n");

	reg_param_set(lm_exit_cmm, get_cmm_size(lm_exit_cmm));
	debug("lm exit setup-done\n");

	reg_param_set(gm_exit_cmm, get_cmm_size(gm_exit_cmm));
	debug("gm exit setup-done\n");

	ddr_ioret_disable();

	usec = timer_usec();
	while(check_retention_status())
	{
		if(timer_usec() - usec > RETENTION_ST_LIMIT)
		{
			error("time out : check retention status for instant boot\n");
			/* TODO : need something to handle error status */
			while(1);
		}
	}
	debug("retention released \n");

	reg_param_set(lm_exit_post_cmm, get_cmm_size(lm_exit_post_cmm));
	debug("lm exit post setup-done\n");

	reg_param_set(gm_exit_post_cmm, get_cmm_size(gm_exit_post_cmm));
	debug("gm exit post setup-done\n");
}

void reg_param_set(reg_param_t *param, int cnt)
{
	if(!cnt) return;

	while(cnt--)
	{
		switch((param->opcode&REG_PARAM_OP_GROUP_MASK))
		{
			case REG_PARAM_OP_GROUP_WAIT:	// wait
				udelay(param->operand);
				//debug("delay(_%dms);\n", param->operand/1000);
				break;

			case REG_PARAM_OP_GROUP_CHECK:	// check
				//debug("REG_PARAM_OP_GROUP_CHECK\n");
				break;

			case REG_PARAM_OP_GROUP_RESERVED:
				//debug("REG_PARAM_OP_GROUP_RESERVED\n");
				break;

			default:	// REG_PARAM_OP_GROUP_WRITE
				IO_WRITE((unsigned long)param->opcode, param->operand);
				//debug("IO_WRITE( 0x%08x, 0x%08x);\n", param->opcode, param->operand);
				break;
		}
		//debug("{0x%08x, 0x%08x},\n", param->opcode, param->operand);
		param++;
	}
}

static void control_addr_switch(void)
{
	if(!iboot_mode)//cold boot
		set_addr_switch();

	else//instant boot
	{
		if(status_iboot_addr_switch())
			recovery_iboot_addr_switch();
		else
			set_addr_switch();
	}

	debug("addr switch setup-done\n");
}

static void set_su_top(void)
{
	reg_param_t *param;
	int cnt = 0;

	if(!iboot_mode)//cold boot, return
		return;

	param = (reg_param_t*)status_iboot_su_top(&cnt);
	if(param && cnt)
	{
		cnt = cnt * sizeof(uint32_t) / sizeof(reg_param_t);
		reg_param_set(param, cnt);
	}
}

int setup_top_ddrc(void)
{
	if(read_shadow_header_bin() != 0)
		return -1;

	if(!iboot_mode)
	{
		setup_cold_boot();
		debug("cold boot setup -- done\n");
	}
	else 
	{
		setup_instant_boot();
		debug("instant boot setup -- done\n");
	}

	tzasc_allow_secure();
	
	reg_param_set(bus_cmm, get_cmm_size(bus_cmm));
	debug("bus setup-done\n");

	control_addr_switch();

	set_su_top();

	return 0;
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////// shadwo header bin ///////////////////////////////////////
#ifdef CONFIG_SHADOW_HEADER_BIN

#define SHB_SIZE 	(0x4000)//16KB, per a setup

struct 
{
	char 			*name;
	uint32_t 		*p_size; 	//ex> &top_cmm_size
	reg_param_t 	**p_obj;	//ex> &top_cmm
}soc_setup_header_table[] = 
{
#define cmt(s)	{#s, &(s##_cmm_size), &(s##_cmm)}

	cmt(top),
	cmt(lm),
	cmt(gm),
	cmt(bus),
	cmt(lm_exit),
	cmt(gm_exit),
	cmt(lm_exit_post),
	cmt(gm_exit_post),

#undef cmt
};


#ifdef CONFIG_SECURE_BOOT
// SEQ_SRC_STAT
#define SEQ_SRC_READY		0x000
#define SEQ_SRC_START		0x001
#define SEQ_SRC_MID			0x010
#define SEQ_SRC_END			0x100

static unsigned int sc_hash_phase(int i, int blocks)
{
	unsigned int phase = 0;

	if (i == 0) /* if first */
		phase = SEQ_SRC_START;

	if (i == blocks - 1) /* if last */
		phase |= SEQ_SRC_END;

	if (phase == 0) /* if neither first nor last */
		phase = SEQ_SRC_MID;

	return (phase);
}
#endif

static int read_shadow_header_bin(void)
{
	uint32_t shb_size = REG_READ(SPBC_SHADOW_HEADER_SIZE_BASE);
	uint32_t shb_offset = REG_READ(SPBC_SHADOW_HEADER_OFFSET_BASE);
	uint32_t i;
	uint32_t addr;
	uint32_t shb_index;

	shb_index = get_ddr_vendor();

	if(get_chip_rev() <  LX_CHIP_REV(M16, B0))
	{
		//M16Ax, force ddr_sk, 1056MHz
		shb_index = DDR_VENDOR_Ax_BASE + DDR_SK_12; //shb index 1
	}
	else
	{
		//M16Bx, selected by get_ddr_vendor()
		shb_index = DDR_VENDOR_Bx_BASE + shb_index;
	}

	printf("[%d]\n", shb_index);

	//shb_size = 16 * n
	if(shb_size%SHB_SIZE)
	{
		error("wrong size - shadow header bin!\n");
		return -1;
	}

//	debug("shadow header bin size : 0x%08x, offset : 0x%08x, index %d\n"
//											, shb_size, shb_offset, shb_index);
	
#ifdef CONFIG_SECURE_BOOT
	uint32_t 	shb_chunks = shb_size / SHB_SIZE;
	uint8_t 	sha256[32] = {0,};
	uint8_t  	*shb_sha256 = (uint8_t *)SPBC_SHADOW_HEADER_SHA256_BASE;

	for(i = 0; i < shb_chunks; i++)
	{
		uint32_t phase = sc_hash_phase(i, shb_chunks);

		transfer_emmc(LG1312_SRAM_BASE, SHB_SIZE, shb_offset + (i * SHB_SIZE), 0);
		
		if(do_sha256_phase(0, LG1312_SRAM_BASE, (ulong)sha256, shb_size, SHB_SIZE, phase) != 0)
		{
			error("fail calc sha256 of shb!\n");
			return -1;
		}
	}

	//compare sha256
	if(memcmp(sha256, shb_sha256, 32) != 0)
	{
		error("fail compare sha256 of shb!\n");
		return -1;
	}
#endif

	/* load shadow header bin from emmc to normal sram */
	transfer_emmc(LG1312_SRAM_BASE, SHB_SIZE, shb_offset + (shb_index * SHB_SIZE), 0);

	addr = LG1312_SRAM_BASE;
	for(i = 0; i < ARRAY_SIZE(soc_setup_header_table); i++)
	{
#define NAME_LENGTH 16
		uint32_t n_offset;
		uint32_t align_size = 16;

		if(strncmp(soc_setup_header_table[i].name, (char*)((ulong)addr), NAME_LENGTH) != 0)
		{
			error("wrong shadow header bin\n");
			return -1;
		}
		
		*soc_setup_header_table[i].p_size = REG_READ((ulong)(addr + NAME_LENGTH));
		*soc_setup_header_table[i].p_obj = (reg_param_t *)(addr + NAME_LENGTH + sizeof(uint32_t));

		n_offset = NAME_LENGTH + sizeof(uint32_t) + *soc_setup_header_table[i].p_size;
		n_offset += (align_size - (n_offset % align_size));
		addr += n_offset;

#if 0
		debug("size : %x, obj : %x, addr %x\n", *soc_setup_header_table[i].p_size
												, *soc_setup_header_table[i].p_obj
												, addr);
#endif
	}

	return 0;
}
#else
static int read_shadow_header_bin(void) {return 0;}
#endif


