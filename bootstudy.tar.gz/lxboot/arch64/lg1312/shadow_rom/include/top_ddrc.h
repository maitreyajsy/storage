#ifndef _TOP_DDRC_H_
#define _TOP_DDRC_H_

#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3

typedef struct
{
	uint32_t	opcode;
	uint32_t	operand;
} reg_param_t;

void reg_param_set(reg_param_t *param, int cnt);

int setup_top_ddrc(void);

#endif
