#ifndef _ROMAPI_H_
#define _ROMAPI_H_

#ifndef __ASSEMBLY__

extern int (*printf)(const char *fmt, ...);
extern void (*udelay)(uint32_t  usec);
extern uint32_t (*timer_usec)(void);
extern unsigned int (*transfer_emmc)(unsigned long long buffer, unsigned int size, unsigned long long address, char r_w);
extern int (*strncmp)(const char *s1, const char *s2, uint32_t count);
extern int (*memcmp)(const void *dst, const void *src, uint32_t n);
extern int (*do_sha256_phase)(uint32_t ch, uint32_t src, uint32_t dst,
					 uint32_t length, uint32_t unit_size, uint32_t phase);
extern int (*gpio_set_direction)(uint32_t pin, int dir);
extern int (*gpio_set_value)(uint32_t pin, int value);
extern int (*gpio_get_value)(uint32_t pin);

#endif //__ASSEMBLY__
#endif //_ROMAPI_H_
