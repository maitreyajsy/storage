#include <common.h>
#include <top_ddrc.h>
#include <iboot_param.h>

#include "i2c.h"
#include "eeprom.h"


/* static variables */
static uint32_t chip_rev = CONFIG_CHIP;

/* global variables */
uint32_t iboot_mode = 0;

/* static function headers */
static int chip_detect(void);
static uint32_t check_iboot(uint32_t mode0, uint32_t mode1);
static int read_nvm_vars(void);
static int modify_default_ctop(void);
static void get_soc_iboot_param(void);
static void set_emmc_datastrobe(void);


/* implement functions */
int main(uint32_t mode0, uint32_t mode1)
{
	rom_symbol_init();

	if(chip_detect() != 0)
		error("can't detect chip rev!, use default chip rev[%x]\n", get_chip_rev());

	debug("==== hello shadow rom ====\n");

	set_emmc_datastrobe();

	iboot_mode = check_iboot(mode0, mode1);

	modify_default_ctop();

	//test for eeprom
	read_nvm_vars();

	if(setup_top_ddrc() != 0)
		goto func_exit;

	get_soc_iboot_param();

	debug("shadow_rom -- done\n");
	return 0;

func_exit:
	error("shadow_rom -- fail\n");
	return -1;
}

static void set_emmc_datastrobe(void)
{
	REG_WRITE(0xc1cf0030, 0x0);
}

static void get_soc_iboot_param(void)
{
	if(!iboot_mode)
		return;

	recovery_iboot_param_dport();
	recovery_iboot_param_jtag();
}

static int modify_default_ctop(void)
{
#ifdef GPIO_M16_FLASH_WP
#define CTOP_FMC_R11	0xc830942c
	uint32_t value;
	//GPIO_M16_FLASH_WP : gpio83, ctop mux - 0xc830942c:bit13
	//gpio_set_top(GPIO_M16_FLASH_WP);
	value = REG_READ(CTOP_FMC_R11);
	value |= (1<<13);
	REG_WRITE(CTOP_FMC_R11, value);

	gpio_set_direction(GPIO_M16_FLASH_WP, GPIO_DIR_OUTPUT);
	gpio_set_value(GPIO_M16_FLASH_WP, GPIO_LOW);
#endif
	return 0;
}


static int chip_detect(void)
{
#define BX_REV_REG		(0XC830A4AC)
#define AX_REV_REG		(0xC112309C)	/* otp rev area */
#define A0_CHIP_MAGIC	(0x31364130) 	/* "16A0" */
#define A1_CHIP_MAGIC	(0x0)

#define TZ_OTP_CTRL		(0XC1124008)	/* bit[3] : otp count enable */

	if(REG_READ(BX_REV_REG) == 0xb0)
		chip_rev = ARCH_LG1312 | REV_B1;
	else//Ax
	{
		u32 data;
		u32 rev;

		data = REG_READ(TZ_OTP_CTRL);
		data |= (1<<3);		// OTP count enable
		REG_WRITE(TZ_OTP_CTRL, data);

		rev = REG_READ(AX_REV_REG);
		if(rev == A0_CHIP_MAGIC)
			chip_rev = ARCH_LG1312 | REV_A0;

		else if(rev == A1_CHIP_MAGIC)
			chip_rev = ARCH_LG1312 | REV_A1;

		else
		{
			chip_rev = ARCH_LG1312 | REV_A1;
			error("Fail chip detect!! 0x%08x\n", rev);
		}
	}

	printf("[%s%s]\n", get_arch_string(chip_rev), get_rev_string(chip_rev));

	return 0;
}

uint32_t get_chip_rev(void)
{
	return chip_rev;
}

static uint32_t check_iboot(uint32_t mode0, uint32_t mode1)
{
	if(get_chip_rev() > LX_CHIP_REV(M16, A0))
	{
		if(mode0 == 0xa && mode1 == 0xb)
			return 1;
		else
			return 0;
	}
	else //M16A0 not support iboot
	{
		if(mode0 == 0xa && mode1 == 0xb)
		{
			error("-------------------------------------------\n");
			error("not support instant boot at M16A0\n");
			error("-------------------------------------------\n");
		}
		return 0;
	}
}

#if USE_EEPROM
static int read_nvm_vars(void)
{
	u8 buf[32];
	u32 len = 32;
	u32 i;
	u32 offset = 0;

	i2c_init();

	eeprom_read(offset, buf, len);

	printf("---- eeprom --- offset %u\n", offset);

	for(i = 0; i < len; i++)
	{
		if(!(i%16) && i)
			printf("\n");

		printf("%02x ", buf[i]);
	}
	printf("\n");

	return 0;
}
#else
static int read_nvm_vars(void) {return -1;}
#endif

