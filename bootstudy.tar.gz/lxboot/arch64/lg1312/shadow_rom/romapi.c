#include <common.h>

/* 
 * SHADOW ROM share symbols of boot rom.
 * i.e. SHADOW ROM call functions of boot rom.
 * so, need init the address of symbols
 */

/* global variables */

/* symbol list to share with bootrom */
int (*printf)(const char *fmt, ...);
void (*udelay)(uint32_t  usec);
uint32_t (*timer_usec)(void);
unsigned int (*transfer_emmc)(unsigned long long buffer, unsigned int size, unsigned long long address, char r_w);
int (*strncmp)(const char *s1, const char *s2, uint32_t count);
int (*memcmp)(const void *dst, const void *src, uint32_t n);
int (*do_sha256_phase)(uint32_t ch, uint32_t src, uint32_t dst,
					 uint32_t length, uint32_t unit_size, uint32_t phase);
int (*gpio_set_direction)(uint32_t pin, int dir);
int (*gpio_set_value)(uint32_t pin, int value);
int (*gpio_get_value)(uint32_t pin);


struct
{
	int (*printf)(const char *fmt, ...);
	void (*udelay)(uint32_t  usec);
	uint32_t (*timer_usec)(void);
	unsigned int (*transfer_emmc)(unsigned long long buffer, unsigned int size, unsigned long long address, char r_w);
	int (*strncmp)(const char *s1, const char *s2, uint32_t count);
	int (*memcmp)(const void *dst, const void *src, uint32_t n);
	int (*do_sha256_phase)(uint32_t ch, uint32_t src, uint32_t dst, uint32_t length, uint32_t unit_size, uint32_t phase);

	int (*gpio_set_direction)(uint32_t pin, int dir);
	int (*gpio_set_value)(uint32_t pin, int value);
	int (*gpio_get_value)(uint32_t pin);
}bootrom_symbol[] = {
	// 0, M16
	{
		.printf				= (void*)0xc10c03f8,
		.udelay				= (void*)0xc10c07c0,
		.timer_usec			= (void*)0xc10c07a0,
		.transfer_emmc		= (void*)0xc10c5a64,
		.strncmp			= (void*)0xc10c0e50,
		.memcmp				= (void*)0xc10c0fe0,
		.do_sha256_phase 	= (void*)0xc10c8184,
		.gpio_set_direction = (void*)0xc10c0d34,
		.gpio_set_value		= (void*)0xc10c0dbc,
		.gpio_get_value		= (void*)0xc10c0e04,
	},
};

/* implement function */

void rom_symbol_init(void)
{
	uint32_t symbol_index = 0;

	printf				= bootrom_symbol[symbol_index].printf;
	udelay				= bootrom_symbol[symbol_index].udelay;
	timer_usec			= bootrom_symbol[symbol_index].timer_usec;
	transfer_emmc		= bootrom_symbol[symbol_index].transfer_emmc;
	strncmp				= bootrom_symbol[symbol_index].strncmp;
	memcmp 				= bootrom_symbol[symbol_index].memcmp;
	do_sha256_phase		= bootrom_symbol[symbol_index].do_sha256_phase;
	gpio_set_direction	= bootrom_symbol[symbol_index].gpio_set_direction;
	gpio_set_value		= bootrom_symbol[symbol_index].gpio_set_value;
	gpio_get_value		= bootrom_symbol[symbol_index].gpio_get_value;
}

