/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <arch/timers.h>
#include <arch/ctop_regs.h>
#include <serial.h>
#include <timer.h>
#include <storage.h>
#include <image.h>
#include <util.h>
#include <gpio.h>
#include <command.h>
#include <system.h>
#include <mmu.h>
#include <secureboot.h>
#include <i2c.h>
#include <version.h>

volatile CTOP_CTRL_REG_T g_ctop_regs = 
{
#define _CTOP_INIT(_m) 	(M16_A0_CTOP_##_m##_TYPE *)M16_A0_CTOP_##_m##_BASE
		_CTOP_INIT(VDEC0_SYN),
		_CTOP_INIT(VDEC1_SYN),
		_CTOP_INIT(VDEC2_SYN),
		_CTOP_INIT(LBUS_SYN),
		_CTOP_INIT(GBUS_SYN),
		_CTOP_INIT(VSD_SYN),
		_CTOP_INIT(ND0_SYN),
		_CTOP_INIT(IMX_SYN),
		_CTOP_INIT(GSC_SYN),
		_CTOP_INIT(CVI_SYN),
		_CTOP_INIT(CCO_SYN),
		_CTOP_INIT(SRE_SYN),
		_CTOP_INIT(MCU_SYN),
		_CTOP_INIT(FMC_SYN),
		_CTOP_INIT(FME_SYN),
		_CTOP_INIT(M0_SYN),
		_CTOP_INIT(M1_SYN),
		_CTOP_INIT(GFX_SYN),
		_CTOP_INIT(VENC_SYN),
		_CTOP_INIT(AUD_SYN),
		_CTOP_INIT(TE_SYN),
		_CTOP_INIT(HDMI_SYN),
		_CTOP_INIT(GPU_SYN),
		_CTOP_INIT(DPE_SYN),
		_CTOP_INIT(PERI_SYN),
		_CTOP_INIT(EMMC_SYN),
		_CTOP_INIT(FMC),
		_CTOP_INIT(VENC),
		_CTOP_INIT(AUD),
		_CTOP_INIT(TE),
		_CTOP_INIT(DEMOD),
		_CTOP_INIT(DPE),
#undef _CTOP_INIT
};

volatile CTOP_CTRL_REG_T *ctop_regs = &g_ctop_regs;
volatile CPU_TOP_REG_T *cpu_top_regs = (CPU_TOP_REG_T *)LG1312_CPUTOP_BASE;


static uint32_t chip_rev = CONFIG_CHIP;

inline __attribute__((always_inline)) void interrupt_disable(void)
{
	/* set I mask */
	asm volatile("msr daifset, #2" ::: "memory");
}

inline __attribute__((always_inline)) void serror_enable(void)
{
	/* clear A mask */
	asm volatile("msr daifclr, #4" ::: "memory");
}

inline __attribute__((always_inline)) void serror_disable(void)
{
	/* set A mask */
	asm volatile("msr daifset, #4" ::: "memory");
}

static void board_uart_ctop_init(void)
{
#if !defined(CONFIG_BOARD_TYPE_FPGA)
	CTOP_DPE_CTOP_R00_M16A0		ctop_r00;
	
	ctop_r00 = ctop_regs->DPE->ctop_r00;
	ctop_r00.uart0_sel = 2; /* cpu 0 uart tx */
	ctop_r00.uart1_sel = 2; /* cpu 1 uart tx */
	ctop_r00.uart2_sel = 2; /* cpu 2 uart tx */
	ctop_r00.rx_sel_uart0 = 1; /* rx into uart 0 */
	ctop_r00.rx_sel_uart1 = 0; /* rx into uart 1 */
	ctop_regs->DPE->ctop_r00 = ctop_r00;
#endif
}

static void board_storage_init (void)
{
}

static void watchdog_init(void)
{
	watchdog_t *wdt = (watchdog_t*)LG1312_WATCHDOG_BASE;

	wdt->load = 0xFFFFFFFF;
	wdt->control = 0;	/* disable watchdog */
}

__attribute__((weak))
void reset(void)
{
	//Watchdog reset
	watchdog_t *wdt = (watchdog_t*)LG1312_WATCHDOG_BASE;

	interrupt_disable();
	serror_disable();

	wdt->control = 2;	/* Enable Watchdog reset output */
	wdt->load = 0x0;

	mdelay(100);
	while(1);
}

#ifndef M16A_I2C_CH
#define M16A_I2C_CH 8	/* M16A */
#endif

int ace_reg_read(uint8_t slave, uint8_t addr, uint8_t *data)
{
	int idx, res;
	for(idx=0; idx<3; idx++)
	{
		res = i2c_read(M16A_I2C_CH, slave, addr, 1, data, 1, 0);
		if(res != -1) break;
	}
	if(res == -1) printf("^r^ACE : can't read slave:0x%02x, addr:0x%02x\n", slave, addr);
	return res;
}

int ace_reg_write(uint8_t slave, uint8_t addr, uint8_t data)
{
	int idx, res;
	for(idx=0; idx<3; idx++)
	{
		res = i2c_write(M16A_I2C_CH, slave, addr, 1, &data, 1, 0);
		if(res != -1) break;
	}
	if(res == -1) printf("^r^ACE : can't write slave:0x%02x, addr:0x%02x\n", slave, addr);
	return res;
}

TODO(check chip rev detect)
uint32_t get_chip_rev(void)
{
	return chip_rev;
}

static void chip_detect(void)
{
#define BX_REV_REG		(0XC830A4AC)
#define AX_REV_REG		(0xC112309C)	/* otp rev area */
#define A0_CHIP_MAGIC	(0x31364130) 	/* "16A0" */
#define A1_CHIP_MAGIC	(0x0)

#define TZ_OTP_CTRL		(0XC1124008)	/* bit[3] : otp count enable */

	if(REG_READ(BX_REV_REG) == 0xb0)
		chip_rev = ARCH_LG1312 | REV_B1;
	else//Ax
	{
		u32 data;
		u32 rev;

		data = REG_READ(TZ_OTP_CTRL);
		data |= (1<<3);		// OTP count enable
		REG_WRITE(TZ_OTP_CTRL, data);

		rev = REG_READ(AX_REV_REG);
		if(rev == A0_CHIP_MAGIC)
			chip_rev = ARCH_LG1312 | REV_A0;

		else if(rev == A1_CHIP_MAGIC)
			chip_rev = ARCH_LG1312 | REV_A1;

		else
		{
			chip_rev = ARCH_LG1312 | REV_A1;
			early_printf("Fail chip detect!! 0x%08x\n", rev);
		}
	}
}

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
static clk_dev_t clk_dev[NUM_CLK_DEV];

static void auto_clk_detect(void)
{
	ctop_detect_clk();
	clk_dev[CLK_DEV_CPU]	= ctop_get_cpu_clk();
	clk_dev[CLK_DEV_PERI]	= ctop_get_pclk();
	clk_dev[CLK_DEV_UART]	= clk_dev[CLK_DEV_PERI];
	clk_dev[CLK_DEV_TIMER]	= clk_dev[CLK_DEV_PERI];
	clk_dev[CLK_DEV_I2C]	= clk_dev[CLK_DEV_PERI];
}
#else
static const clk_dev_t clk_dev[NUM_CLK_DEV] =
{
	[CLK_DEV_CPU]	= CPU_CLOCK,
	[CLK_DEV_PERI]	= PCLK,
	[CLK_DEV_UART]	= UART_CLK,
	[CLK_DEV_TIMER] = TIMER_CLK,
	[CLK_DEV_I2C]	= I2C_CLK,
};
#endif

void  cpu_init(void)
{
	chip_detect();

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
	auto_clk_detect();
#endif

	serror_enable();

	early_timer_init();
	watchdog_init();

	/* invalidate & enable I cache */
	inv_icache();
	enable_icache();

	soc_init();
	set_addr_switch();

#if USE_DATA_CACHE
	/* setup mmu table & enable I/D cache */
	mmu_init();
#endif
}

uint32_t get_clk(clk_dev_t dev)
{
	return clk_dev[dev];
}

void cpu_exit(void)
{
	interrupt_disable();
	//serror_disable(); //TODO: need?

#if USE_DATA_CACHE
	mmu_disable();
#else
	//disable & inv I cache
	disable_icache();
	inv_icache();
	//TODO: need flush dcache??
#endif

}

void cpu_jmp_exit(void)
{
	cpu_exit();
}

#if 0
static void display_platform_memory(void)
{
	extern int _bend[];

	printf("Memory Map - 1st Boot\n");
	printf(" _______________________\n");
	printf("|                       | 0x%08x\n", FIRST_BOOT_MEM_TOP);
	printf("|                       |\n");
	printf("|   BUFFER DATA(%03dMB) |\n", DATA_BUF_SIZE / MB);
	printf("|                       |\n");
	printf("|-----------------------| 0x%08x\n", DATA_BUF_BASE);
	printf("|   NCACHE BUF(%03dMB)  |\n", NCACHE_BUF_SIZE / MB);
	printf("|-----------------------| 0x%08x\n", NCACHE_BUF_BASE);
	printf("|   DMA MEMORY(%03dMB)  |\n", DMA_MALLOC_SIZE / MB);
	printf("|-----------------------| 0x%08x\n", DMA_MALLOC_BASE);
	printf("|   HEAP MEMORY(%03dMB) |\n", SYSTEM_MALLOC_SIZE / MB);
	printf("|-----------------------| 0x%08x\n", SYSTEM_MALLOC_BASE);
	printf("|                       |\n");
	printf("|-----------------------|\n");
	printf("|   MMU L1 Table(64b)   |\n");
	printf("|-----------------------| 0x%08x\n", MMU_L1_TABLE_BASE);
	printf("|   MMU L2 Table(%02dKB)|\n", MMU_L2_TABLE_SIZE / KB);
	printf("|-----------------------| 0x%08x\n", MMU_L2_TABLE_BASE);
	printf("|-----------------------| 0x%08x\n", CONFIG_FIRST_BOOT_STACK_TOP);
	printf("|   SYSTEM STACK(%03dKB)|\n", SYS_STACK_SIZE/KB);
	printf("|-----------------------| 0x%08x\n", CONFIG_FIRST_BOOT_STACK_TOP - SYS_STACK_SIZE);
	printf("|                       |\n");
	printf("|-----------------------| 0x%08x\n", _bend);
	printf("|                       |\n");
	printf("|   TEXT + BSS + DATA   |\n");
	printf("|                       |\n");
	printf("|_______________________| 0x%08x\n", CONFIG_FIRST_BOOT_TEXT_BASE);
}
#else
static void display_platform_memory(void)
{}
#endif

void board_init(void)
{
	board_uart_ctop_init();
	board_storage_init();

#if USE_EMMC
	set_default_storage(STORAGE_TYPE_EMMC);
#else
#if USE_NAND
	set_default_storage(STORAGE_TYPE_NAND);
#endif
#endif
}

void board_exit(void)
{
	// TODO : don't write the low control functions
	// for emmc debug
	//REG_WRITE(0xC0C0002C, 0x01000000);
}

boot_param_t* get_boot_param(void)
{
	return NULL;
}

#ifdef CONFIG_SECURE_BOOT
static uint8_t* get_secure_data(void)
{
	extern uint8_t _secure_data;
	return &_secure_data;
}

static int secure_init(void)
{
	uint8_t* data = get_secure_data();
	return sb_init(data);
}
#endif

#ifndef FIRSTBOOT_PROMPT_KEY
#define FIRSTBOOT_PROMPT_KEY		'='
#endif

#define INPUT_TIMEOUT	(-1)
#define INPUT_INVALID	(0)
#define INPUT_OK		(1)

__attribute__((unused))
static int check_input(int timeout /*in ms unit*/)
{
#if USE_FIRSTBOOT_PROMPT
	uint32_t end = timer_msec() + timeout;

	while(end > timer_msec())
	{
		if(!serial_check_rx(CONSOLE_UART_PORT))
			continue;

		if(serial_getc(CONSOLE_UART_PORT) == FIRSTBOOT_PROMPT_KEY)
			return INPUT_OK;
		return INPUT_INVALID;
	}
#endif
	return -1;
}

#ifndef VERIFY_RETRY_MAX
#define VERIFY_RETRY_MAX	(3)
#endif
#if defined(CONFIG_SECURE_BOOT) && defined(USE_PARTINFO_BOOT_OFFSET)
#define MAGIC(a,b,c,d)		((a) | (b) << 8 | (c) << 16 | (d) << 24)
#define BACK_MAGIC			MAGIC('B','A','C','K')

static int backup_part_booting(int magic)
{
	storage_partition_t partition;
	char* update_list[UPDATE_PARTITION_MAX] = {NULL, };

	make_updated_part_list(update_list);

	if(storage_get_partition("emer", &partition) < 0)
	{
		printf("emergency parition is not valid !!!\n");
		return -1;
	}
	if(storage_write(partition.offset, sizeof(int), (void*)&magic) < 0)
	{
		printf("can not write emergency parition!!!\n");
		return -1;
	}

	swap_backup_partition(update_list);

	return 0;
}
#endif

static int load_2nd_boot(ulong *ep)
{
	uint64_t	offset;
	uint8_t		hdr[256];
	int			img_type;

#if USE_PARTINFO_BOOT_OFFSET
	storage_partition_t partition;

	if(storage_get_partition("boot", &partition) < 0)
	{
		offset = 0x40000;	//default offset
	}
	else
	{
		offset = partition.offset;
	}
#else
	/* They sometimes download other model partinfo.pak
	 * and the partinfo has the 'boot' partition and its offset value is '0'.
	 * In this case, if we get the boot offset from partinfo
	 * then we can't boot and goes to unexpected mode.
	 */
#ifdef CONFIG_BOOT_OFFSET
	offset = CONFIG_BOOT_OFFSET;
#else
	offset = 0x40000;
#endif
#endif

	if(storage_read(offset, 256, hdr) < 0)
		return -1;

	img_type = check_image_type(hdr);

	if(img_type == HDR_TYPE__LXB)
	{
		uint32_t data_size = lxboot_bin_get_data_size(hdr);
		ulong load_addr = (ulong)lxboot_bin_get_load(hdr);

		if(storage_read(offset, data_size, (void*)load_addr) < 0)
			return -1;

#ifdef CONFIG_SECURE_BOOT
		if(secureboot_enabled())
		{
			uint8_t*	sign;
			int			sign_size;
			int			rc;
			int			retry_cnt = 0;

			if((rc = secure_init()) < 0)
			{
				printf("Can't init sb[%d]\n", rc);
				return -1;
			}

			sign_size = sb_get_sign_size();
			sign = (uint8_t*)malloc(sign_size);

			do {
				/* load signature of 2nd boot image*/
				if(storage_read(offset + data_size, sign_size, sign) < 0)
				{
					printf("Can't read signature\n");
					return -1;
				}

#if USE_DATA_CACHE
				dcache_clean_range(load_addr, data_size);
#endif
				rc=sb_verify_image((uint8_t*)load_addr, data_size, sign);
				retry_cnt++;
			} while (rc < 0 && retry_cnt < VERIFY_RETRY_MAX);
			//printf("Signature O.K !\n");

			free(sign);
			sign=NULL;

			if(rc < 0)
			{
				printf("Failed verification[%d]\n", rc);
				goto verify_error;
			}
		}
#endif

		*ep = load_addr;
		return 0;
	}

#ifdef CONFIG_SECURE_BOOT
verify_error:
#ifdef USE_PARTINFO_BOOT_OFFSET
	if(partition.valid == PART_VALID_FLG_UNKNOWN)
	{
		printf("Try backup partition booting..\n");
		backup_part_booting(BACK_MAGIC);
		reset();
	}
#endif
#endif

	return -1;
}


/************************************************************************
 * Setup parameters to pass it to the 2nd bootloader
 ***********************************************************************/
#define CPUTOP_GP_REG17 		(LG1312_CPUTOP_BASE + 0x330)
static uint32_t bootrom_elapsed_time(void)
{
	return REG_READ(CPUTOP_GP_REG17);
}

int setup_boot_params(uint32_t boot_mode, ulong load_addr)
{
	boot_param_t *param = (boot_param_t*)BOOT_PARAM_BASE;

	memset(param, 0, sizeof(boot_param_t));

	param->magic = MAGIC_BOOT_PARAM;
	param->nand_inited = (get_default_storage() == STORAGE_TYPE_NAND) ? 1 : 0;
	param->emmc_inited = (get_default_storage() == STORAGE_TYPE_EMMC) ? 1 : 0;

	param->elapsed_bootrom = bootrom_elapsed_time();
	param->elapsed_1stboot = (u32)(timer_usec() - timer_initial_clock());

	param->boot_mode	= boot_mode;
	param->load_addr	= load_addr;

	param->version_str_magic = VERSION_STR_MAGIC;
	strncpy(param->version_str, version_string, VERSION_STR_LENGTH);
	param->version_str[VERSION_STR_LENGTH-1] = 0;

#ifdef CONFIG_SECURE_BOOT
	memcpy(param->secure_data, get_secure_data(), sizeof(param->secure_data));
#endif

	return 0;
}


#ifndef FIRSTBOOT_WAIT_TIME
#define FIRSTBOOT_WAIT_TIME		10	/* 10ms */
#endif

#if USE_FIRSTBOOT_PROMPT
static char input_cmd[1024];
#endif
int main(void)
{
	cpu_init();
	mdelay(5); //to prevent the log of bootrom break.
	board_init();

	/* TODO: don't use printf(), before serial_init() */
	serial_init(CONSOLE_UART_PORT, CONSOLE_UART_BAUDRATE);
	timer_init();

	malloc_init();
	storage_init();

	display_platform_memory();
	//printf("1st %s done\n", __func__);

	if(check_input(FIRSTBOOT_WAIT_TIME) != INPUT_OK)
	{
		ulong ep;
		if(load_2nd_boot(&ep) == 0)
		{
			setup_boot_params(BOOT_MODE_NORMAL, ep);
			jump((void*)ep, 0, NULL);
		}
		printf("Can't jump to 2nd boot !\n");
	}

#if USE_FIRSTBOOT_PROMPT
	command_init();
	while(1)
	{
		puts("lxboot-1st@M16 # ");
		gets(input_cmd);
		printf("\n");
		command_execute(input_cmd);
	}
#else
	while(1){}
#endif
	/*
	 * Never return here !!!
	 */

	return 0;
}

#if 1	/* Enable if you want to use 'stdarg.h' without -nostdinc options	*/
void abort(void)
{
	serial_printf(CONSOLE_UART_PORT, "abort !!!\n");
}
#endif

#if 1	/* Enable if you want to use the libgcc above gcc 4.x.x */
int raise (int signum)
{
	serial_printf(CONSOLE_UART_PORT, "It may be a division-by-zero signal. signum[%d]\n", signum);
	return 0;
}
#endif

void __aeabi_unwind_cpp_pr0(void){}
void __aeabi_unwind_cpp_pr1(void){}

