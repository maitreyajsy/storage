#include <stdio.h>
#include <string.h>
#include <command.h>
#include <arch/ctop_regs.h>
#include <types.h>

//#define DBG
#include <debug.h>

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT

/* -------------------------------------------------------------------------------------------------
 *  DATA TYPE
 * -------------------------------------------------------------------------------------------------
 */
typedef struct
{
 	uint32_t cpu_pll_out;
	uint32_t m1_pll_out;
	uint32_t m2_pll_out;
	uint32_t gpu_pll_out;

	uint32_t cpu_core_clk;
	uint32_t lm_ddr_clk;
	uint32_t gm_ddr_clk;
	uint32_t peri_bus_clk;

	uint32_t cpu_pll_ss;
	uint32_t m1_pll_ss;
	uint32_t m2_pll_ss;

} clk_detect_t;


/* -------------------------------------------------------------------------------------------------
 *  MACRO
 * -------------------------------------------------------------------------------------------------
 */

#define PLL_CLK_OUT(M, NPC, NSC) \
				(((4 * NPC + NSC) * (ulong)(24*MHZ))/ (M))

/* -------------------------------------------------------------------------------------------------
 *  STATIC
 * -------------------------------------------------------------------------------------------------
 */
static clk_detect_t clk = {0,};

/* -------------------------------------------------------------------------------------------------
 *  FUNCTION
 * -------------------------------------------------------------------------------------------------
 */


void ctop_detect_clk(void)
{
	u32 M, NPC, NSC;

	/* read cpu pll */
	CTOP_AUD_CTOP_R08_M16A0 cpu_pll_c0; //cpu pll configuration
	CTOP_AUD_CTOP_R09_M16A0 cpu_pll_c1; //cpu pll configuration

	cpu_pll_c0 = ctop_regs->AUD->ctop_r08;
	cpu_pll_c1 = ctop_regs->AUD->ctop_r09;

	M = cpu_pll_c0.cpupll_m;
	NPC = cpu_pll_c1.cpupll_npc;
	NSC = cpu_pll_c1.cpupll_nsc;

	if(!M)
		M = 1;

	if(NPC)
		NPC ^= 0x6; //to set NPC, bit[2][1] must be inverted

	if(NSC)
		NSC ^= 0x2; //to set NSC, bit[1] must be inverted

	clk.cpu_pll_out = PLL_CLK_OUT(M, NPC, NSC);
	clk.cpu_pll_ss = cpu_pll_c0.cpupll_dss ? 0 : 1;
	DEBUG("cpu pll m : %u, npc : %u, nsc : %u\n", M, NPC, NSC);


	/* read m1 pll */
	CTOP_VENC_CTOP_R00_M16A0 m1_pll_c0;
	CTOP_VENC_CTOP_R01_M16A0 m1_pll_c1;

	m1_pll_c0 = ctop_regs->VENC->ctop_r00;
	m1_pll_c1 = ctop_regs->VENC->ctop_r01;

	M = m1_pll_c0.m1pll_m;
	NPC = m1_pll_c1.m1pll_npc;
	NSC = m1_pll_c1.m1pll_nsc;
	
	if(!M)
		M = 1;

	clk.m1_pll_out = PLL_CLK_OUT(M, NPC, NSC);
	clk.m1_pll_ss = m1_pll_c0.m1pll_dss ? 0 : 1;
	DEBUG("m1 pll m : %u, npc : %u, nsc : %u\n", M, NPC, NSC);


	/* read m2 pll */
	CTOP_VENC_CTOP_R03_M16A0 m2_pll_c0;
	CTOP_VENC_CTOP_R04_M16A0 m2_pll_c1;

	m2_pll_c0 = ctop_regs->VENC->ctop_r03;
	m2_pll_c1 = ctop_regs->VENC->ctop_r04;

	M = m2_pll_c0.m2pll_m;
	NPC = m2_pll_c1.m2pll_npc;
	NSC = m2_pll_c1.m2pll_nsc;

	if(!M)
		M = 1;

	clk.m2_pll_out = PLL_CLK_OUT(M, NPC, NSC);
	clk.m2_pll_ss = m2_pll_c0.m2pll_dss ? 0 : 1;
	DEBUG("m2 pll m : %u, npc : %u, nsc : %u\n", M, NPC, NSC);

	/* read gpu pll */
	CTOP_VENC_CTOP_R06_M16A0 gpu_pll_c0;
	CTOP_VENC_CTOP_R07_M16A0 gpu_pll_c1;

	gpu_pll_c0 = ctop_regs->VENC->ctop_r06;
	gpu_pll_c1 = ctop_regs->VENC->ctop_r07;

	M = gpu_pll_c0.gpupll_m;
	NPC = gpu_pll_c1.gpupll_npc;
	NSC = gpu_pll_c1.gpupll_nsc;

	if(!M)
		M = 1;

	clk.gpu_pll_out = PLL_CLK_OUT(M, NPC, NSC);
	DEBUG("gpu pll m : %u, npc : %u, nsc : %u\n", M, NPC, NSC);


	/* cpu clock */
	clk.cpu_core_clk = clk.cpu_pll_out >> 1;

	/* clk mux */
	CTOP_VENC_CTOP_R14_M16A0 clk_mux;

	clk_mux = ctop_regs->VENC->ctop_r14;

	if(!clk_mux.ck_mux_pll_sel_m0)//m1pll -> m0 ddr
		clk.lm_ddr_clk = clk.m1_pll_out >> 1;
	else //m2pll -> m0 ddr
		clk.lm_ddr_clk = clk.m2_pll_out >> 1;

	if(!clk_mux.ck_mux_pll_sel_m1)//m1pll -> m1 ddr
		clk.gm_ddr_clk = clk.m1_pll_out >> 1;
	else //m2pll -> m1 ddr
		clk.gm_ddr_clk = clk.m2_pll_out >> 1;

	if(!clk_mux.ck_mux_pll_sel_lbus)//m2pll -> peri
		clk.peri_bus_clk = clk.m2_pll_out >> 3;
	else
		clk.peri_bus_clk = clk.gpu_pll_out >> 3;

}



uint32_t ctop_get_cpu_clk(void)
{
	return clk.cpu_core_clk;
}

uint32_t ctop_get_pclk(void)
{
	return clk.peri_bus_clk;
}

uint32_t ctop_get_lm_clk(void)
{
	return clk.lm_ddr_clk;
}

uint32_t ctop_get_gm_clk(void)
{
	return clk.gm_ddr_clk;
}

uint32_t ctop_get_m1_pll_ss(void)
{
	return clk.m1_pll_ss;
}

uint32_t ctop_get_m2_pll_ss(void)
{
	return clk.m2_pll_ss;
}

int do_get_clk(int argc, char *argv[])
{
	ctop_detect_clk();
	printf("CPU  CLK : %uHz\n", ctop_get_cpu_clk());
	printf("PERI CLK : %uHz\n", ctop_get_pclk());
	printf("LM   CLK : %uHz\n", ctop_get_lm_clk());
	printf("GM   CLK : %uHz\n", ctop_get_gm_clk());

	printf("cpu pll out : %u\n", clk.cpu_pll_out);
	printf("m1 pll out : %u\n", clk.m1_pll_out);
	printf("m2 pll out : %u\n", clk.m2_pll_out);
	printf("gpu pll out : %u\n", clk.gpu_pll_out);

	printf("cpu pll ss : %s\n", clk.cpu_pll_ss ? "ON" : "OFF");
	printf("m1 pll ss : %s\n", clk.m1_pll_ss ? "ON" : "OFF");
	printf("m2 pll ss : %s\n", clk.m2_pll_ss ? "ON" : "OFF");

	CTOP_VENC_CTOP_R14_M16A0 clk_mux;

	clk_mux = ctop_regs->VENC->ctop_r14;

	printf("LM SRC : %s\n", !clk_mux.ck_mux_pll_sel_m0 ? "M1 PLL" : "M2 PLL");
	printf("GM SRC : %s\n", !clk_mux.ck_mux_pll_sel_m1 ? "M1 PLL" : "M2 PLL");
	printf("PERI SRC : %s\n", !clk_mux.ck_mux_pll_sel_lbus ? "M2 PLL" : "GPU PLL");

	return 0;
}

COMMAND(clk, do_get_clk, "usage : clk", NULL);
#endif /*CONFIG_USE_DETECT_CLK*/

