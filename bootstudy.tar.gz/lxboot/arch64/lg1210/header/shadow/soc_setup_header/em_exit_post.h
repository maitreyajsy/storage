static reg_param_t em_exit_post_cmm[] = {
};
