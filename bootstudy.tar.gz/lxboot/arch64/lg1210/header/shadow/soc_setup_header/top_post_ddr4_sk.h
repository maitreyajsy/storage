static reg_param_t top_post_ddr4_sk_cmm[] = {
};
