static reg_param_t gm_exit_post_cmm[] = {
};
