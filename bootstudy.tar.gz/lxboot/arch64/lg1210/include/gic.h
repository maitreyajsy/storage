#ifndef __ARCH_GIC_H__
#define __ARCH_GIC_H__

#include "address_map.h"
#include "irqs.h"

#include <arm/gic.h>


/* Distributor Register Map */
#define GIC_ICDDCR		(LG1210_GIC_DIST_BASE	+ 0x000)	/* Interrupt Distributor Control Register (RW) */
#define GIC_ICDICTR		(LG1210_GIC_DIST_BASE	+ 0x004)	/* Interrupt Controller Type Register (RO) */
#define GIC_ICDIIDR		(LG1210_GIC_DIST_BASE	+ 0x008)	/* Distributor Implementer Identification Register (RO) */
#define GIC_ICDISR		(LG1210_GIC_DIST_BASE	+ 0x080)	/* Interrupt Security Registers (RW) */
#define GIC_ICDISER		(LG1210_GIC_DIST_BASE	+ 0x100)	/* Interrupt Set Enable Registers (RW) */
#define GIC_ICDICER		(LG1210_GIC_DIST_BASE	+ 0x180)	/* Interrupt Clear Enable Registers (RW) */
#define GIC_ICDISPR		(LG1210_GIC_DIST_BASE	+ 0x200)	/* Interrupt Set Pending Registers (RW) */
#define GIC_ICDICPR		(LG1210_GIC_DIST_BASE	+ 0x280)	/* Interrupt Clear Pending Registers (RW) */
#define GIC_ICDABR		(LG1210_GIC_DIST_BASE	+ 0x300)	/* Interrupt Active Bit Registers (RW) */
#define GIC_ICDIPR		(LG1210_GIC_DIST_BASE	+ 0x400)	/* Interrupt Priority Registers (RW) */
#define GIC_ICDIPTR		(LG1210_GIC_DIST_BASE	+ 0x800)	/* Interrupt CPU Target Registers (RW) */
#define GIC_ICDICFR		(LG1210_GIC_DIST_BASE	+ 0xC00)	/* Interrupt Configuration Registers (RW) */
#define GIC_ICDSGIR		(LG1210_GIC_DIST_BASE	+ 0xF00)	/* Software Interrupt Register (RO) */


/* CPU Interface Register Map */
#define GIC_ICCICR		(LG1210_GIC_CPU_BASE	+ 0x00)		/* Control Register (RW) */
#define GIC_ICCPMR		(LG1210_GIC_CPU_BASE	+ 0x04)		/* Priority Mask Register (RW) */
#define GIC_ICCBPR		(LG1210_GIC_CPU_BASE	+ 0x08)		/* Binary Point Register (RW) */
#define GIC_ICCIAR		(LG1210_GIC_CPU_BASE	+ 0x0C)		/* Interrupt Acknowledge Register (RO) */
#define GIC_ICCEOIR		(LG1210_GIC_CPU_BASE	+ 0x10)		/* End of Interrupt Register (WO) */
#define GIC_ICCRPR		(LG1210_GIC_CPU_BASE	+ 0x14)		/* Running Priority Register (RO) */
#define GIC_ICCHPIR		(LG1210_GIC_CPU_BASE	+ 0x18)		/* Highest Pending Interrupt Register (RO) */
#define GIC_ICCABPR		(LG1210_GIC_CPU_BASE	+ 0x1C)		/* Aliased Binary Point Register (RW) */
#define GIC_ICCIIDR		(LG1210_GIC_CPU_BASE	+ 0xFC)		/* CPU Interface Identification Register (RO) */



#endif	/* __ARCH_GIC_H__ */
