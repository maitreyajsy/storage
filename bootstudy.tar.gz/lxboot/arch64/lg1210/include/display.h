#ifndef __ARCH_DISPLAY_H__
#define __ARCH_DISPLAY_H__

typedef enum
{
	FRC_TYPE_NO_FRC,
	FRC_TYPE_INTERNAL,
	FRC_TYPE_EXTERNAL,
	FRC_TYPE_EXTERNAL2,
	FRC_TYPE_EXTERNAL3
} frc_type_t;

typedef enum
{
	PANEL_TYPE_V12 = 0,
	PANEL_TYPE_V13,
	PANEL_TYPE_V14,
	PANEL_TYPE_V15
} panel_type_t;

typedef enum
{
	PANEL_INCH_42 = 0,
	PANEL_INCH_43,
	PANEL_INCH_47,
	PANEL_INCH_49,
	PANEL_INCH_50,
	PANEL_INCH_55,
	PANEL_INCH_60,
	PANEL_INCH_65,
	PANEL_INCH_70,
	PANEL_INCH_79,
	PANEL_INCH_84,
	PANEL_INCH_98
} panel_inch_t;

typedef enum
{
	PANEL_TOOL_LA86 = 0,
	PANEL_TOOL_LA96,
	PANEL_TOOL_UF95
} panel_tool_t;

typedef enum
{
	PANEL_MAKER_LGD = 0,
	PANEL_MAKER_SHARP
} panel_maker_t;

typedef enum
{
	PANEL_BACKLIGHT_EDGE_LED = 0,
	PANEL_BACKLIGHT_ALEF_LED,
	PANEL_BACKLIGHT_OTHER
} panel_backlight_t;

typedef enum
{
	DISP_120HZ_FULLHD_EPI = 0,
	DISP_120HZ_FULLHD_LVDS4,
	DISP_120HZ_FULLHD_VX1,
	DISP_60HZ_FULLHD_LVDS2,
	DISP_60HZ_FULLHD_HSLVDS1,
	DISP_60HZ_UHD_VX1
} disp_output_type_t;

typedef enum
{
	LVDS_VESA = 0,
	LVDS_JEIDA
} lvds_type_t;

typedef enum
{
	LVDS_10BIT = 0,
	LVDS_8BIT
} lvds_bit_t;

typedef enum
{
	SOC_IN_SEP_OSD = 0,
	SOC_OUT_SEP_OSD
} osd_separate_t;

struct disp_info
{
	frc_type_t			frc_type;
	int					colordepth;
	panel_type_t		panel_type;
	panel_inch_t		panel_inch;
	panel_tool_t		panel_tool;
	panel_maker_t	panel_maker;
	panel_backlight_t	panel_backlight;
	disp_output_type_t	output_type;
	lvds_type_t		lvds_type;
	lvds_bit_t			lvds_bit;
	int				mirror;

	int					osd_img_width;
	int					osd_img_height;

	int					osd_disp_width;
	int					osd_disp_height;
};

#endif
