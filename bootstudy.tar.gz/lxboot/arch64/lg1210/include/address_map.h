#ifndef __ARCH_ADDRESS_MAP_H__
#define __ARCH_ADDRESS_MAP_H__

#define LG1210_MEMC_BASE				(0xff000000)		/* Memory devices */
#define LG1210_DMAC_SLAVE_BASE			(LG1210_MEMC_BASE+0x200000) // DMAC register
#define LG1210_SMC_BASE					(LG1210_MEMC_BASE+0x400000) // SMC register
#define LG1210_SRAM_BASE				(LG1210_MEMC_BASE+0xf00000) // Non secure SRAM

#define LG1210_DMAAPB_BASE				(0xfe000000)		/* DMAAPB */
#define LG1210_UART0_BASE				(LG1210_DMAAPB_BASE+0x000000)   /* Uart 0 */
#define LG1210_UART1_BASE				(LG1210_DMAAPB_BASE+0x100000)   /* Uart 1 */
#define LG1210_UART2_BASE				(LG1210_DMAAPB_BASE+0x200000)   /* Uart 2 */
#define LG1210_I2C0_BASE				(LG1210_DMAAPB_BASE+0x300000)   /* I2C 0 */
#define LG1210_I2C1_BASE				(LG1210_DMAAPB_BASE+0x400000)   /* I2C 1 */
#define LG1210_I2C2_BASE				(LG1210_DMAAPB_BASE+0x500000)   /* I2C 2 */
#define LG1210_I2C3_BASE				(LG1210_DMAAPB_BASE+0x600000)   /* I2C 3 */
#define LG1210_SCI_BASE					(LG1210_DMAAPB_BASE+0x700000)   /* Smart Card Interface */
#define LG1210_SPI0_BASE				(LG1210_DMAAPB_BASE+0x800000)   /* SPI 0 */
#define LG1210_SPI1_BASE				(LG1210_DMAAPB_BASE+0x900000)   /* SPI 1 */

#define LG1210_COREAPB_BASE				(0xfd000000)		/* CoreAPB */
#define LG1210_REMAP_BASE				(LG1210_COREAPB_BASE+0x000000)  /* Remap and pause */
#define LG1210_TIMER_BASE				(LG1210_COREAPB_BASE+0x100000)  /* Timer 0 and 1 */
#define LG1210_TIMER_64_BASE			(LG1210_COREAPB_BASE+0x110000)  /* 64bit Timer */
#define LG1210_WATCHDOG_BASE			(LG1210_COREAPB_BASE+0x200000)  /* Watchdog */
#define LG1210_CPUTOP_BASE				(LG1210_COREAPB_BASE+0x300000)  /* Top Control */
#define LG1210_GPIO0_BASE				(LG1210_COREAPB_BASE+0x400000)  /* GPIO port 0 */
#define LG1210_GPIO1_BASE				(LG1210_COREAPB_BASE+0x410000)  /* GPIO port 1 */
#define LG1210_GPIO2_BASE				(LG1210_COREAPB_BASE+0x420000)  /* GPIO port 2 */
#define LG1210_GPIO3_BASE				(LG1210_COREAPB_BASE+0x430000)  /* GPIO port 3 */
#define LG1210_GPIO4_BASE				(LG1210_COREAPB_BASE+0x440000)  /* GPIO port 4 */
#define LG1210_GPIO5_BASE				(LG1210_COREAPB_BASE+0x450000)  /* GPIO port 5 */
#define LG1210_GPIO6_BASE				(LG1210_COREAPB_BASE+0x460000)  /* GPIO port 6 */
#define LG1210_GPIO7_BASE				(LG1210_COREAPB_BASE+0x470000)  /* GPIO port 7 */
#define LG1210_GPIO8_BASE				(LG1210_COREAPB_BASE+0x480000)  /* GPIO port 8 */
#define LG1210_GPIO9_BASE				(LG1210_COREAPB_BASE+0x490000)  /* GPIO port 9 */
#define LG1210_GPIO10_BASE				(LG1210_COREAPB_BASE+0x4A0000)  /* GPIO port 10 */
#define LG1210_GPIO11_BASE				(LG1210_COREAPB_BASE+0x4B0000)  /* GPIO port 11 */
#define LG1210_GPIO12_BASE				(LG1210_COREAPB_BASE+0x4C0000)  /* GPIO port 12 */
#define LG1210_GPIO13_BASE				(LG1210_COREAPB_BASE+0x4D0000)  /* GPIO port 13 */
#define LG1210_GPIO14_BASE				(LG1210_COREAPB_BASE+0x4E0000)  /* GPIO port 14 */
#define LG1210_GPIO15_BASE				(LG1210_COREAPB_BASE+0x4F0000)  /* GPIO port 15 */
#define LG1210_GPIO16_BASE				(LG1210_COREAPB_BASE+0x500000)  /* GPIO port 16 */
#define LG1210_GPIO17_BASE				(LG1210_COREAPB_BASE+0x510000)  /* GPIO port 17 */


#define	LG1210_I2C_BASE					(0xf9000000)
#define LG1210_I2C4_BASE                (LG1210_I2C_BASE+0x000000)   	/* I2C 4 */
#define LG1210_I2C5_BASE                (LG1210_I2C_BASE+0x100000)   	/* I2C 5 */
#define LG1210_I2C6_BASE                (LG1210_I2C_BASE+0x200000)   	/* I2C 6 */
#define LG1210_I2C7_BASE                (LG1210_I2C_BASE+0x300000)   	/* I2C 7 */
#define LG1210_I2C8_BASE                (LG1210_I2C_BASE+0x400000)   	/* I2C 8 */
#define LG1210_I2C9_BASE                (LG1210_I2C_BASE+0x500000)   	/* I2C 9 */
#define LG1210_IRBLASTER_BASE 			(LG1210_I2C_BASE+0x600000) 		/* IR_Blaster */

#define LG1210_MMU400_BASE 				(0xf1000000) 		/* MMU400_0 (CPU_PERI) */

#define LG1210_CCI400_BASE 				(0xf0090000) 		/* CCI400 REG */

/* ------------------------------------------------------------------------
 *  Chip select base addresses
 * ------------------------------------------------------------------------
 */
#define LG1210_CS_BASE					(0xd0000000)
#define LG1210_CS0_BASE					(LG1210_CS_BASE+0x0000000)
#define LG1210_CS1_BASE					(LG1210_CS_BASE+0x4000000)
#define LG1210_CS2_BASE					(LG1210_CS_BASE+0x8000000)
#define LG1210_CS3_BASE					(LG1210_CS_BASE+0xc000000)

/* ------------------------------------------------------------------------
 *  PL301 & AVREG
 * ------------------------------------------------------------------------
 */
#define LG1210_PL301_BASE				(0xc8000000)
#define LG1210_M0_TZ_BASE				(LG1210_PL301_BASE+0x800000)
#define LG1210_M1_TZ_BASE				(LG1210_PL301_BASE+0x400000)
#define LG1210_M2_TZ_BASE				(LG1210_PL301_BASE+0x500000)
#define LG1210_M0_BASE					(LG1210_PL301_BASE+0x804000)
#define LG1210_M1_BASE					(LG1210_PL301_BASE+0x404000)
#define LG1210_M2_BASE					(LG1210_PL301_BASE+0x504000)

/* ------------------------------------------------------------------------
 *  USB
 * ------------------------------------------------------------------------
 */
#define LG1210_USB_BASE 				(0xc3000000)
#define LG1210_USB_CTRL0_BASE 			(LG1210_USB_BASE)
#define LG1210_USB_SSUSB0_BASE 			(LG1210_USB_BASE+0x100000)
#define LG1210_USB_CTRL1_BASE 			(LG1210_USB_BASE+0x200000)
#define LG1210_USB_USB2_1_BASE 			(LG1210_USB_BASE+0x300000)
#define LG1210_USB_USB2_2_BASE 			(LG1210_USB_BASE+0x400000)
#define LG1210_USB_SSUSB1_BASE 			(LG1210_USB_BASE+0x500000)
#define LG1210_USB_USB2_0_BASE 			(LG1210_USB_BASE+0x600000)

/*USB3.0 HC*/
#define LG1210_USB_XHCI0_BASE			(LG1210_USB_SSUSB0_BASE)
#define LG1210_USB_XHCI1_BASE			(LG1210_USB_SSUSB1_BASE)

/*USB2.0 HC*/
#define LG1210_USB_EHCI0_BASE			(LG1210_USB_USB2_0_BASE)
#define LG1210_USB_EHCI1_BASE			(LG1210_USB_USB2_1_BASE)
#define LG1210_USB_EHCI2_BASE			(LG1210_USB_USB2_2_BASE)

/*USB1.1 HC*/
#define LG1210_USB_OHCI0_BASE			(LG1210_USB_USB2_0_BASE+0x4000)
#define LG1210_USB_OHCI1_BASE			(LG1210_USB_USB2_1_BASE+0x4000)
#define LG1210_USB_OHCI2_BASE			(LG1210_USB_USB2_2_BASE+0x4000)

/* ------------------------------------------------------------------------
 *  Distributed Interrupt Controller (Peripheral Base)
 * ------------------------------------------------------------------------
 */
#define LG1210_GIC400_BASE 				(0xc2000000)
#define LG1210_GIC_BASE					(LG1210_GIC400_BASE+0x0000)
#define LG1210_GIC_DIST_BASE			(LG1210_GIC_BASE+0x1000)
#define LG1210_GIC_CPU_BASE				(LG1210_GIC_BASE+0x2000)



#define LG1210_EMMC_BASE 				(0xc0c00000) 	/* eMMC 5.0 HC */
#define LG1210_GEMAC_BASE				(0xc0b00000) 	/* GEM */
#define LG1210_TZ_APB_BASE 				(0xc0100000) 	/* TZ APB */
#define LG1210_TZ_ROM_BASE 				(0xc00c0000) 	/* TZ ROM */
#define LG1210_TZ_RAM_BASE 				(0xc0080000) 	/* TZ RAM */

#define LG1210_CX_CHIPREV_BASE			(0xc8601c78)	/* C0 : 0x1210cccc */
#define LG1210_CHIPREV_BASE 			(0xc8600020) 	/* A0 : 0x0, B0 : 0x1210b000 */

#define LG1210_ADEC_BASE				(0xC8836000)	/* Audio */


/* ------------------------------------------------------------------------
 * Generic Timer, Counter module control & status register
 * ------------------------------------------------------------------------
 */
#define LG1210_COUNTER_MODULE_BASE 		(0xc0105000)

/* ------------------------------------------------------------------------
 *  Sync registers for dual core booting
 * ------------------------------------------------------------------------
 */
#define LG1210_SYS_FLAGSSET 			(LG1210_CPUTOP_BASE+0x02dc) /* SYNC_reg0 */
#define LG1210_SYS_SYNCSET 				(LG1210_CPUTOP_BASE+0x02e0) /* SYNC_reg1 */
#define LG1210_SYS_AWAKEFLAG 			(LG1210_CPUTOP_BASE+0x02d0) /* Reserved */


#endif
