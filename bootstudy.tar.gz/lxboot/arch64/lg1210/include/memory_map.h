#ifndef __ARCH_MEMORY_MAP_H__
#define __ARCH_MEMORY_MAP_H__

#include "address_map.h"

#ifndef CONFIG_STACK_TOP
#error "CONFIG_STACK_TOP not defined in config"
#endif

/* Define memory map per platform and chip
   Here, check macro that must needed */
#include <platform/memory_map.h>

#ifndef SYS_STACK
#error "SYS_STACK not defined in <platform/memory_map.h>"
#endif

#ifndef MMU_L2_TABLE_BASE
#error "MMU_L2_TABLE_BASE not defined in <platform/memory_map.h>"
#endif

#ifndef MMU_L3_TABLE_BASE
#error "MMU_L3_TABLE_BASE not defined in <platform/memory_map.h>"
#endif

#ifndef SYSTEM_MALLOC_BASE
#error "SYSTEM_MALLOC_BASE not defined in <platform/memory_map.h>"
#endif

#ifndef DMA_MALLOC_BASE
#error "DMA_MALLOC_BASE not defined in <platform/memory_map.h>"
#endif

#ifndef DATA_BUF_BASE
#error "DATA_BUF_BASE not defined in <platform/memory_map.h>"
#endif


#endif //__ARCH_MEMORY_MAP_H__
