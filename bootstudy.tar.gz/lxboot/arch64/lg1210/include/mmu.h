#ifndef __ARCH_MMU_H__
#define __ARCH_MMU_H__

#include <arm/mmu.h>


#endif /* __ARCH_MMU_H__ */
