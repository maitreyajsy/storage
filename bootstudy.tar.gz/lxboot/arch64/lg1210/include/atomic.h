#ifndef __ARCH_ATOMIC_H_
#define __ARCH_ATOMIC_H_

#include <arm/atomic.h>

#endif /* __ARCH_ATOMIC_H_ */
