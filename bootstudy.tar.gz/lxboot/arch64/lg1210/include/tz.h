#ifndef _TZ_H_
#define _TZ_H_

typedef struct {
	u32 psci;
	u32 aarch;
} tz_param_t;

extern tz_param_t tz_args;

unsigned long loadtz(void);
void tz_boot(unsigned long load_addr);
void __tzboot(	unsigned long addr, void (*entry)(void), 
				unsigned long rel_addr, unsigned long method);
void __el2(void);


#endif /*_TZ_H_*/

