#include <stdio.h>
#include <string.h>
#include <command.h>
#include <arch/ctop_regs.h>
#include <types.h>

//#define DBG
#include <debug.h>

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT

/* -------------------------------------------------------------------------------------------------
 *  DATA TYPE
 * -------------------------------------------------------------------------------------------------
 */
typedef struct
{
 	uint32_t cpu0_pll_out;
 	uint32_t cpu1_pll_out;
	uint32_t m0_pll_out;
	uint32_t m1_pll_out;
	uint32_t gpu_pll_out;
	uint32_t core_pll_out;
	uint32_t cpu_core_clk;
	uint32_t lm_ddr_clk;
	uint32_t gm_ddr_clk;
	uint32_t em_ddr_clk;
	uint32_t peri_bus_clk;
	uint32_t cpu0_pll_ss;
	uint32_t cpu1_pll_ss;
	uint32_t m0_pll_ss;
	uint32_t m1_pll_ss;
	uint32_t core_pll_ss;
	uint32_t gpu_pll_ss;

} clk_detect_t;


/* -------------------------------------------------------------------------------------------------
 *  MACRO
 * -------------------------------------------------------------------------------------------------
 */
#ifndef SYS_PLL_FREQ
#define SYS_PLL_FREQ CONFIG_SYS_PLL_FREQ
#endif

#define PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC) \
	( (((4*NPC+NSC)*(1<<pre_fd))*(ulong)SYS_PLL_FREQ) / ((M+1)*(0x1<<od_fout)) )


/* -------------------------------------------------------------------------------------------------
 *  STATIC
 * -------------------------------------------------------------------------------------------------
 */
static clk_detect_t clk = {0,};

/* -------------------------------------------------------------------------------------------------
 *  FUNCTION
 * -------------------------------------------------------------------------------------------------
 */
void ctop_detect_clk(void)
{
	u32 pre_fd, od_fout, M, NPC, NSC, udex, msex;

	/* TODO: check cpu0, cpu1 pll */
	/* get cpu0 pll out */
	CTOP_CTRL_CPU_CTR32_H15A0 cpll0_c0; //cpu0 pll configuration
	CTOP_CTRL_CPU_CTR33_H15A0 cpll0_c1; //cpu0 pll configuration
	cpll0_c0 = ctop_regs->CPU->ctr32;
	cpll0_c1 = ctop_regs->CPU->ctr33;
	*(u32 *)(&cpll0_c0) = *(u32 *)(&cpll0_c0) ^ 0x4000018;
	*(u32 *)(&cpll0_c1) = *(u32 *)(&cpll0_c1) ^ 0xcc530000;

	pre_fd 	= cpll0_c0.c0_dr3p_pre_fd_ctrl;
	od_fout = cpll0_c0.c0_dr3p_od_fout_ctrl;
	M 		= cpll0_c0.c0_dr3p_m_ctrl;
	NPC 	= cpll0_c1.c0_dr3p_npc0_ctrl;
	NSC 	= cpll0_c1.c0_dr3p_nsc0_ctrl;
	udex 	= cpll0_c1.c0_dr3p_udex_ctrl;
	msex 	= cpll0_c1.c0_dr3p_msex_ctrl;
	clk.cpu0_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
	clk.cpu0_pll_ss = udex ? 1 : msex ? 1 : 0;
	DEBUG("cpu0 pll pre_fd %u, od_fout %u, M %u, npc %u, nsc %u\n",
			pre_fd, od_fout, M, NPC, NSC);
	DEBUG("cpu0 pll out %u, SS : %s\n"	, clk.cpu0_pll_out
										, clk.cpu0_pll_ss ? "ON" : "OFF");

	/* get cpu1 pll out */
	CTOP_CTRL_CPU_CTR34_H15A0 cpll1_c0;	//cpu1 pll configuration
	CTOP_CTRL_CPU_CTR35_H15A0 cpll1_c1;	//cpu1 pll configuration
	cpll1_c0 = ctop_regs->CPU->ctr34;
	cpll1_c1 = ctop_regs->CPU->ctr35;
	*(u32 *)(&cpll1_c0) = *(u32 *)(&cpll1_c0) ^ 0x4000018;
	*(u32 *)(&cpll1_c1) = *(u32 *)(&cpll1_c1) ^ 0xcc530000;

	pre_fd 	= cpll1_c0.c1_dr3p_pre_fd_ctrl;
	od_fout = cpll1_c0.c1_dr3p_od_fout_ctrl;
	M 		= cpll1_c0.c1_dr3p_m_ctrl;
	NPC 	= cpll1_c1.c1_dr3p_npc1_ctrl;
	NSC 	= cpll1_c1.c1_dr3p_nsc1_ctrl;
	udex 	= cpll1_c1.c1_dr3p_udex_ctrl;
	msex 	= cpll1_c1.c1_dr3p_msex_ctrl;
	clk.cpu1_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
	clk.cpu1_pll_ss = udex ? 1 : msex ? 1 : 0;
	DEBUG("cpu1 pll pre_fd %u, od_fout %u, M %u, npc %u, nsc %u\n",
			pre_fd, od_fout, M, NPC, NSC);
	DEBUG("cpu1 pll out %u, SS : %s\n"	, clk.cpu1_pll_out
										, clk.cpu1_pll_ss ? "ON" : "OFF");

	/* get main pll0 out */
	CTOP_CTRL_TI_CTR36_H15A0 m0_c0;		//main pll0 configuration
	CTOP_CTRL_TI_CTR37_H15A0 m0_c1;		//main pll0 configuration
	m0_c0 = ctop_regs->TI->ctr36;
	m0_c1 = ctop_regs->TI->ctr37;

	pre_fd 	= m0_c0.m0_dr3p_pre_fd_ctrl;
	od_fout = m0_c0.m0_dr3p_od_fout_ctrl;
	M 		= m0_c0.m0_dr3p_m_ctrl;
	NPC 	= m0_c1.m0_dr3p_npc_ctrl;
	NSC 	= m0_c1.m0_dr3p_nsc_ctrl;
	udex 	= m0_c1.m0_dr3p_udex_ctrl;
	msex 	= m0_c1.m0_dr3p_msex_ctrl;
	clk.m0_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
	clk.m0_pll_ss = udex ? 1 : msex ? 1 : 0;
	DEBUG("m0 pll pre_fd %u, od_fout %u, M %u, npc %u, nsc %u\n",
			pre_fd, od_fout, M, NPC, NSC);
	DEBUG("m0 pll out %u, SS : %s\n"	, clk.m0_pll_out
										, clk.m0_pll_ss ? "ON" : "OFF");

	/* get main pll1 out */
	CTOP_CTRL_TI_CTR38_H15A0 m1_c0;	 	//main pll1 configuration
	CTOP_CTRL_TI_CTR39_H15A0 m1_c1;		//main pll1 configuration
	m1_c0 = ctop_regs->TI->ctr38;
	m1_c1 = ctop_regs->TI->ctr39;
	
	pre_fd 	= m1_c0.m1_dr3p_pre_fd_ctrl;
	od_fout = m1_c0.m1_dr3p_od_fout_ctrl;
	M 		= m1_c0.m1_dr3p_m_ctrl;
	NPC 	= m1_c1.m1_dr3p_npc_ctrl;
	NSC 	= m1_c1.m1_dr3p_nsc_ctrl;
	udex 	= m1_c1.m1_dr3p_udex_ctrl;
	msex 	= m1_c1.m1_dr3p_msex_ctrl;
	clk.m1_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
	clk.m1_pll_ss = udex ? 1 : msex ? 1 : 0;
	DEBUG("m1 pll pre_fd %u, od_fout %u, M %u, npc %u, nsc %u\n",
			pre_fd, od_fout, M, NPC, NSC);
	DEBUG("m1 pll out %u, SS : %s\n"	, clk.m1_pll_out
										, clk.m1_pll_ss ? "ON" : "OFF");

	/* get core pll out */
	CTOP_CTRL_TI_CTR32_H15A0 core_c0; 	//core pll configuration
	CTOP_CTRL_TI_CTR33_H15A0 core_c1;	//core pll configuration
	core_c0 = ctop_regs->TI->ctr32;
	core_c1 = ctop_regs->TI->ctr33;

	pre_fd 	= core_c0.s_dr3p_pre_fd_ctrl;
	od_fout = core_c0.s_dr3p_od_fout_ctrl;
	M 		= core_c0.s_dr3p_m_ctrl;
	NPC 	= core_c1.s_dr3p_npc_ctrl;
	NSC 	= core_c1.s_dr3p_nsc_ctrl;
	udex 	= core_c1.s_dr3p_udex_ctrl;
	msex 	= core_c1.s_dr3p_msex_ctrl;
	clk.core_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
	clk.core_pll_ss = udex ? 1 : msex ? 1 : 0;
	DEBUG("core pll pre_fd %u, od_fout %u, M %u, npc %u, nsc %u\n",
			pre_fd, od_fout, M, NPC, NSC);
	DEBUG("core pll out %u, SS : %s\n"	, clk.core_pll_out
										, clk.core_pll_ss ? "ON" : "OFF");

	/* get gpu pll out */
	CTOP_CTRL_CPU_CTR36_H15A0 gpu_c0; 	//gpu pll configuration
	CTOP_CTRL_CPU_CTR37_H15A0 gpu_c1; 	//gpu pll configuration
	gpu_c0 = ctop_regs->CPU->ctr36;
	gpu_c1 = ctop_regs->CPU->ctr37;
	*(u32 *)(&gpu_c0) = *(u32 *)(&gpu_c0) ^ 0xfbffffe7;
	*(u32 *)(&gpu_c1) = *(u32 *)(&gpu_c1) ^ 0x99d67fff;

	pre_fd 	= gpu_c0.g_dr3p_pre_fd_ctrl;
	od_fout = gpu_c0.g_dr3p_od_fout_ctrl;
	M 		= gpu_c0.g_dr3p_m_ctrl;
	NPC 	= gpu_c1.g_dr3p_npc_ctrl;
	NSC 	= gpu_c1.g_dr3p_nsc_ctrl;
	udex 	= gpu_c1.g_dr3p_udex_ctrl;
	msex 	= gpu_c1.g_dr3p_msex_ctrl;
	clk.gpu_pll_out = PLL_CLK_OUT(pre_fd, od_fout, M, NPC, NSC);
	clk.gpu_pll_ss = udex ? 1 : msex ? 1 : 0;
	DEBUG("gpu pll pre_fd %u, od_fout %u, M %u, npc %u, nsc %u\n",
			pre_fd, od_fout, M, NPC, NSC);
	DEBUG("gpu pll out %u, SS : %s\n"	, clk.gpu_pll_out
										, clk.gpu_pll_ss ? "ON" : "OFF");

	
	CTOP_CTRL_CPU_CTR15_H15A0 cpu_clk_mode;
	cpu_clk_mode = ctop_regs->CPU->ctr15;

	/* get clock selection for cpu_clk
	 * cpu_clk_mode.ck_sel 
	 * 0: cpu0 pll fout
	 * 1: cpu1 pll fout
	 * 2,3 : xtal in
	 */
	if(cpu_clk_mode.ck_sel == 0)
	{
		clk.cpu_core_clk = clk.cpu0_pll_out;
		DEBUG("cpu clk : cpu0 pll\n");
	}
	else if(cpu_clk_mode.ck_sel == 1)
	{
		clk.cpu_core_clk = clk.cpu1_pll_out;
		DEBUG("cpu clk : cpu1 pll\n");
	}
	else
	{
		ERROR("not select cpu'pll. cpu clock source is the xtal\n");
		return;
	}

	/* get clock selection for m0, m1(m2), core0, core 1 */
	CTOP_CTRL_TI_CTR08_H15A0 clk_mux; //configure clk mux
	clk_mux = ctop_regs->TI->ctr08;

	/* M0 clock mux(lm)
	 * clk_mux.mx_m0_ddrclk
	 * 0 : main0 pll
	 * 1 : main1 pll
	 * 2 : core pll
	 * 3 : gpu pll
	 */
	if(clk_mux.mx_m0_ddrclk == 0)
	{
		clk.lm_ddr_clk = clk.m0_pll_out >> 1;
		DEBUG("lm clk : m0 pll\n");
	}
	else if(clk_mux.mx_m0_ddrclk == 1)
	{
		clk.lm_ddr_clk = clk.m1_pll_out >> 1;
		DEBUG("lm clk : m1 pll\n");
	}
	else if(clk_mux.mx_m0_ddrclk == 2)
	{
		clk.lm_ddr_clk = clk.core_pll_out >> 1;
		DEBUG("lm clk : core pll\n");
	}
	else if(clk_mux.mx_m0_ddrclk == 3)
	{
		clk.lm_ddr_clk = clk.gpu_pll_out >> 1;
		DEBUG("lm clk : gpu pll\n");
	}
	else
	{
		ERROR("wrong selected ,m0 clock mux\n");
		return;
	}

	/* M1,M2 clock mux(gm, em)
	 * clk_mux.mx_m2_ddrclk___mx_m1_ddr_clk
	 * 0 : main0 pll
	 * 1 : main1 pll
	 * 2 : core pll
	 * 3 : gpu pll
	 */
	if(clk_mux.mx_m2_ddrclk___mx_m1_ddr_clk == 0)
	{
		clk.gm_ddr_clk = clk.m0_pll_out >> 1;
		clk.em_ddr_clk = clk.m0_pll_out >> 1;
		DEBUG("gm, em clk : m0 pll\n");
	}
	else if(clk_mux.mx_m2_ddrclk___mx_m1_ddr_clk == 1)
	{
		clk.gm_ddr_clk = clk.m1_pll_out >> 1;
		clk.em_ddr_clk = clk.m1_pll_out >> 1;
		DEBUG("gm, em clk : m1 pll\n");
	}
	else if(clk_mux.mx_m2_ddrclk___mx_m1_ddr_clk == 2)
	{
		clk.gm_ddr_clk = clk.core_pll_out >> 1;
		clk.em_ddr_clk = clk.core_pll_out >> 1;
		DEBUG("gm, em clk : core pll\n");
	}
	else if(clk_mux.mx_m2_ddrclk___mx_m1_ddr_clk == 3)
	{
		clk.gm_ddr_clk = clk.gpu_pll_out >> 1;
		clk.em_ddr_clk = clk.gpu_pll_out >> 1;
		DEBUG("gm, em clk : gpu pll\n");
	}
	else
	{
		ERROR("wrong selected ,m1,m2 clock mux\n");
		return;
	}

	/* peri clock mux (i2c, uart, timer)
	 * clk_mux.mx_core0clk
	 * 0: core pll
	 * 1: main 0 pll
	 * 2: main 1 pll
	 * 3: gpu pll
	 */
	u32 core_2div_clk = 0;
	if(clk_mux.mx_core0clk == 0)
	{
		core_2div_clk = clk.core_pll_out >> 1;
		DEBUG("peri clk : core pll\n");
	}
	else if(clk_mux.mx_core0clk == 1)
	{
		core_2div_clk = clk.m0_pll_out >> 1;
		DEBUG("peri clk : m0 pll\n");
	}
	else if(clk_mux.mx_core0clk == 2)
	{
		core_2div_clk = clk.m1_pll_out >> 1;
		DEBUG("peri clk : m1 pll\n");
	}
	else if(clk_mux.mx_core0clk == 3)
	{
		core_2div_clk = clk.gpu_pll_out >> 1;
		DEBUG("peri clk : gpu pll\n");
	}
	else
	{
		ERROR("wrong selected ,core0 clock mux\n");
		return;
	}

	CTOP_CTRL_CPU_CTR04_H15A0 peri_clk_div;
	peri_clk_div = ctop_regs->CPU->ctr04;

	/*
	 * TODO: check this
	 * wrong value, different ctop manual and diagram manual 
	 * codes referenced diagram manual
	 */
	if(peri_clk_div.qrtclk_sel == 0)
		clk.peri_bus_clk = core_2div_clk >> 2; // 1/4
	else if(peri_clk_div.qrtclk_sel == 1)
		clk.peri_bus_clk = core_2div_clk >> 3; // 1/8
	else if(peri_clk_div.qrtclk_sel == 2)
		clk.peri_bus_clk = core_2div_clk >> 4; // 1/16
	else if(peri_clk_div.qrtclk_sel == 3)
		clk.peri_bus_clk = core_2div_clk >> 5; // 1/32
	else
	{
		ERROR("wrong selected ,core clock divder\n");
		return;
	}

}

uint32_t ctop_get_cpu_clk(void)
{
	return clk.cpu_core_clk;
}

uint32_t ctop_get_pclk(void)
{
	return clk.peri_bus_clk;
}

uint32_t ctop_get_lm_clk(void)
{
	return clk.lm_ddr_clk;
}

uint32_t ctop_get_gm_clk(void)
{
	return clk.gm_ddr_clk;
}

uint32_t ctop_get_em_clk(void)
{
	return clk.em_ddr_clk;
}

uint32_t ctop_get_main0_pll_ss(void)
{
	return clk.m0_pll_ss;
}

uint32_t ctop_get_main1_pll_ss(void)
{
	return clk.m1_pll_ss;
}

uint32_t ctop_get_core_pll_ss(void)
{
	return clk.core_pll_ss;
}

int do_get_clk(int argc, char *argv[])
{
	ctop_detect_clk();
	printf("CPU  CLK : %uHz\n", ctop_get_cpu_clk());
	printf("PERI CLK : %uHz\n", ctop_get_pclk());
	printf("LM   CLK : %uHz\n", ctop_get_lm_clk());
	printf("GM   CLK : %uHz\n", ctop_get_gm_clk());
	printf("EM   CLK : %uHz\n", ctop_get_em_clk());
	printf("MAIN0 PLL SS : %s\n", ctop_get_main0_pll_ss() ? "ON" : "OFF");
	printf("MAIN1 PLL SS : %s\n", ctop_get_main1_pll_ss() ? "ON" : "OFF");
	printf("CORE PLL SS : %s\n", ctop_get_core_pll_ss() ? "ON" : "OFF");
	return 0;
}

COMMAND(clk, do_get_clk, "usage : clk", NULL);
#endif /*CONFIG_USE_DETECT_CLK*/

