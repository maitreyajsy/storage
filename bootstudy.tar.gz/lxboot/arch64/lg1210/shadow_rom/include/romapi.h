#ifndef _ROMAPI_H_
#define _ROMAPI_H_

#ifndef __ASSEMBLY__

#if 0
int vsprintf(char *buf, const char *fmt, va_list args);
int vsnprintf(char *buf, size_t n, const char *fmt, va_list args);
int sprintf(char * buf, const char *fmt, ...);
int snprintf(char *buf, size_t n, const char *fmt, ...);
int putchar(char c);
void puts(const char *str);
#endif

#include "crypto.h"

#define RSA2048_LENGTH					(2048/8)	/*  256 bytes */
#define RSA4096_LENGTH					(4096/8)	/*  512 bytes */
#define PRIVATE_LENGTH					RSA4096_LENGTH

typedef struct _rsa4096_key
{
	char modulus[PRIVATE_LENGTH];
} rsa4096_key_t;

typedef struct _rsa4096_key rsa_key_t;

extern int (*printf)(const char *fmt, ...);
extern void (*puts)(const char *str);
extern void (*udelay)(uint32_t  usec);
extern uint32_t (*timer_usec)(void);
extern unsigned int (*transfer_emmc)(unsigned long long buffer, unsigned int size, unsigned long long address, char r_w);
extern int (*strncmp)(const char *s1, const char *s2, uint32_t count);
extern int (*memcmp)(const void *dst, const void *src, uint32_t n);
extern int (*do_sha256_phase)(uint32_t ch, uint32_t src, uint32_t dst,
					 uint32_t length, uint32_t unit_size, uint32_t phase);

extern int (*RSA_decrypt)(const RSA_CTX *ctx, const uint8_t *in_data, uint8_t *out_data, int is_decryption);
extern void (*RSA_pub_key_new)(RSA_CTX **ctx, const uint8_t *modulus, int mod_len, const uint8_t *pub_exp, int pub_len);
extern void (*RSA_free)(RSA_CTX *rsa_ctx);
extern rsa_key_t *(*rom_rsakey_get)(unsigned int len, unsigned int idx);
extern void (*mmu_init)(uint64_t tbl_base, int tbl_clear);
extern void (*mmu_disable)(void);


#endif //__ASSEMBLY__
#endif //_ROMAPI_H_
