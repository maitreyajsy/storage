#ifndef _COMMON_H_
#define _COMMON_H_
#include <types.h>
#include <romapi.h>
#include <chip_config.h>
#include <lxboot.h>

#include <arch/memory_map.h>

#if 1
#define debug(fmt, args...)		do{}while(0)
#else
#define debug(fmt, args...)		printf(fmt, ##args)
#endif

#define error(fmt, args...) 	printf(COLOR_RED fmt COLOR_NONE, ##args)

#define COLOR_NONE		"\x1b[0m"
#define COLOR_RED		"\x1b[1;31m"
#define COLOR_GREEN	    "\x1b[1;32m"
#define COLOR_YELLOW	"\x1b[1;33m"
#define COLOR_BLUE		"\x1b[1;34m"
#define COLOR_PURPLE	"\x1b[1;35m"
#define COLOR_CYAN		"\x1b[1;36m"

#define COLOR_BG_RED	"\x1b[37m\x1b[41m"
#define COLOR_BG_GREEN	"\x1b[30m\x1b[42m"
#define COLOR_BG_YELLOW	"\x1b[30m\x1b[43m"
#define COLOR_BG_BLUE	"\x1b[37m\x1b[44m"

#define COLOR_FAIL		COLOR_RED
#define COLOR_SUCCESS	COLOR_BG_GREEN


#define LG1210_TZ_RAM_BASE 				(0xc0080000) 	/* TZ RAM */
#define LG1210_MEMC_BASE				(0xff000000)		/* Memory devices */
#define LG1210_SRAM_BASE				(LG1210_MEMC_BASE+0xf00000) // Non secure SRAM
#define LG1210_SRAM_SIZE 				(0x4000)

#define SPBC_HEADER_BASE 				(LG1210_TZ_RAM_BASE + 0)
#define SPBC_SHADOW_HEADER_OFFSET_BASE 	(SPBC_HEADER_BASE + 0x390)
#define SPBC_SHADOW_HEADER_SIZE_BASE 	(SPBC_HEADER_BASE + 0x394)
#define SPBC_SHADOW_HEADER_SHA256_BASE 	(SPBC_HEADER_BASE + 0x398)

#ifndef __ASSEMBLY__
//main.c
extern uint32_t iboot_mode;
uint32_t get_chip_rev(void);

//addr_switch.c
void set_addr_switch(void);

//memcpy.S
void *memcpy_bio(void *dst, const void *src, uint32_t n);

//cm3_loader.c
void load_cm3_firmware(void);
void cm3_check(void);

//romapi.c
void rom_symbol_init(void);

#endif

#endif
