#include <common.h>
#include <top_ddrc.h>
#include <iboot_param.h>

#ifndef CONFIG_SHADOW_HEADER_BIN
/* cold booting parameters */
#include "top.h"
#include "lm.h"
#include "gm.h"
#include "em.h"

/* instant booting parameters */
#include "lm_exit.h"
#include "gm_exit.h"
#include "em_exit.h"
#include "bus_gating.h"
#include "bus_manager.h"

#define get_cmm_size(x) 	ARRAY_SIZE(x)

#else

#define INCLUDE_CMM(x) 	static reg_param_t *x##_cmm; static uint32_t x##_cmm_size;

INCLUDE_CMM(top)		// top_cmm, top_cmm_size
INCLUDE_CMM(lm)
INCLUDE_CMM(gm)
INCLUDE_CMM(em)
INCLUDE_CMM(lm_exit)
INCLUDE_CMM(gm_exit)
INCLUDE_CMM(em_exit)
INCLUDE_CMM(lm_exit_post)
INCLUDE_CMM(gm_exit_post)
INCLUDE_CMM(em_exit_post)
INCLUDE_CMM(bus_gating)
INCLUDE_CMM(bus_manager)
INCLUDE_CMM(top_post)

#define get_cmm_size(x) 	(x##_size / sizeof(reg_param_t))

#endif//CONFIG_SHADOW_HEADER_BIN


#define RETENTION_ST_LIMIT 		(500 * 1000)// 500ms

static int read_shadow_header_bin(void);
static void uart_pin_pullup(void);
static uint32_t read_ddr_info(void);

static void ddr_ioret_disable(void)
{
	/*
	 * gpio11 is used ddr io retention disble pin.
	 * refer to RETENTION_DISABLE pin in lg1210 system board schematic.
	 */
#define GPIO1_BASE 			(0xFD410000)
#define GPIO_RET_DISABLE 		(11%8)
	u32 ioval;

	/* 
	 * After Exiting DDR Self-Refresh,
	 * GPIO11 is used to request micom to disable ddr io retention from rom.
	 */
	ioval = REG_READ(GPIO1_BASE + 0x400) | (1 << GPIO_RET_DISABLE);
	REG_WRITE(GPIO1_BASE + 0x400, ioval);
	REG_WRITE(GPIO1_BASE + (1<<(GPIO_RET_DISABLE+2)), 0x1 << GPIO_RET_DISABLE);
}

static void tzasc_allow_secure(void)
{
#define TZC400_0_BASE			(0xc8800000)
#define TZC400_1_BASE			(TZC400_0_BASE + 0x1000)
#define TZC400_2_BASE			(TZC400_0_BASE + 0x2000)
#define TZC400_3_BASE			(TZC400_0_BASE + 0x3000)
#define DDRC_LM_BASE			(TZC400_0_BASE + 0x4000)

#define TZC400_4_BASE			(0xc8400000)
#define TZC400_5_BASE			(TZC400_4_BASE + 0x1000)
#define TZC400_6_BASE			(TZC400_4_BASE + 0x2000)
#define TZC400_7_BASE			(TZC400_4_BASE + 0x3000)
#define DDRC_GM_BASE			(TZC400_4_BASE + 0x4000)

#define TZC400_8_BASE			(0xc8500000)
#define TZC400_9_BASE			(TZC400_8_BASE + 0x1000)
#define TZC400_10_BASE			(TZC400_8_BASE + 0x2000)
#define TZC400_11_BASE			(TZC400_8_BASE + 0x3000)
#define DDRC_EM_BASE			(TZC400_8_BASE + 0x4000)

	/*
	 * When tzc-400 is enabled by ddrc, we must open filter0 and let 
	 * permission of background region(region0) be secure r/w.
	 * Otherwise lg1210 will die!!
	 * Gate keeper reg (TZC400_X_BASE + 0x008)
	 * - [0]: request the gate of the filter0 to be open.
	 * Region attribute reg (TZC400_X_BASE + 0x110)
	 * - [31]: s_wr_en, [30]:s_rd_en, [3:0]:region en for filter0.
	 */
	if(REG_READ(DDRC_LM_BASE + 0xc0) & (1 << 27))
	{
		REG_WRITE(TZC400_0_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_0_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_0_BASE + 0x114, 0x00010001);
		REG_WRITE(TZC400_1_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_1_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_2_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_2_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_3_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_3_BASE + 0x110, 0xc0000001);
		debug("tzasc lm port setup-done\n");
	}

	if(REG_READ(DDRC_GM_BASE + 0xc0) & (1 << 27))
	{
		REG_WRITE(TZC400_4_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_4_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_4_BASE + 0x114, 0x00010001);
		REG_WRITE(TZC400_5_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_5_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_6_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_6_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_7_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_7_BASE + 0x110, 0xc0000001);
		debug("tzasc gm port setup-done\n");
	}

	if(REG_READ(DDRC_EM_BASE + 0xc0) & (1 << 27))
	{
		REG_WRITE(TZC400_8_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_8_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_8_BASE + 0x114, 0x00010001);
		REG_WRITE(TZC400_9_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_9_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_10_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_10_BASE + 0x110, 0xc0000001);
		REG_WRITE(TZC400_11_BASE + 0x008, 0x1);
		REG_WRITE(TZC400_11_BASE + 0x110, 0xc0000001);
		debug("tzasc em port setup-done\n");
	}
}


static int check_retention_status(void)
{
	//H15 Ax : do nothing
	if(get_chip_rev() <  LX_CHIP_REV(H15, B0))
		return 0;
	else
	{//H15 Bx : check retention status
		unsigned int val;
		unsigned int status = 0;

		val = IO_READ(0xC8804320);
		debug("LM PAD_CTRL_VAL=0x%08x\n", val);
		status = (val >> 31);
		val = IO_READ(0xC8404320);
		debug("GM PAD_CTRL_VAL=0x%08x\n", val);
		status &= (val >> 31);
		val = IO_READ(0xC8504320);
		debug("EM PAD_CTRL_VAL=0x%08x\n", val);
		status &= (val >> 31);

		return !status;
	}
}


#if 1//H15+ DDRC WA

#define LM_SCL	0xc8804300
#define GM_SCL	0xc8404300
#define EM_SCL	0xc8504300

static int check_ddrc_scl(void *p_scl)
{
	static uint32_t cnt = 0;
	uint32_t 		scl;

	scl = REG_READ(p_scl) & 0xf;

	if(scl == 0xf)
	{
		//printf("scl test, (0x%08x : 0x%x)\n", p_scl, scl);
		cnt = 0;
		return TRUE;
	}
	else
	{
		cnt++;
		printf("scl fail[%d], (0x%08x : 0x%x)\n", cnt, p_scl, scl);

		if(cnt >= 20)
		{
			printf("Fail init ddrc!\n");
			while(1);
		}

		return FALSE;
	}
}
#else
static int check_ddrc_scl(void)
{
	return 0;
}
#endif

static void setup_cold_boot(void)
{
	reg_param_set(top_cmm, get_cmm_size(top_cmm));
	debug("top setup-done\n");

	while(1)
	{
		reg_param_set(lm_cmm, get_cmm_size(lm_cmm));
		debug("lm setup-done\n");

		if(check_ddrc_scl((void*)LM_SCL))
			break;
	}

	while(1)
	{
		reg_param_set(gm_cmm, get_cmm_size(gm_cmm));
		debug("gm setup-done\n");

		if(check_ddrc_scl((void*)GM_SCL))
			break;
	}

	while(1)
	{
		reg_param_set(em_cmm, get_cmm_size(em_cmm));
		debug("em setup-done\n");

		if(check_ddrc_scl((void*)EM_SCL))
			break;
	}

	ddr_ioret_disable();
}

static void setup_instant_boot(void)
{
	u32 usec;
	reg_param_set(top_cmm, get_cmm_size(top_cmm));
	debug("top setup-done\n");

	reg_param_set(lm_exit_cmm, get_cmm_size(lm_exit_cmm));
	debug("lm exit setup-done\n");

	reg_param_set(gm_exit_cmm, get_cmm_size(gm_exit_cmm));
	debug("gm exit setup-done\n");

	reg_param_set(em_exit_cmm, get_cmm_size(em_exit_cmm));
	debug("em exit setup-done\n");

	ddr_ioret_disable();
	
	usec = timer_usec();
	while(check_retention_status())
	{
		if(timer_usec() - usec > RETENTION_ST_LIMIT)
		{
			error("time out : check retention status for instant boot\n");
			/* TODO : need something to handle error status */
			while(1);
		}
	}
	debug("retention released \n");

	reg_param_set(lm_exit_post_cmm, get_cmm_size(lm_exit_post_cmm));
	debug("lm exit post setup-done\n");

	reg_param_set(gm_exit_post_cmm, get_cmm_size(gm_exit_post_cmm));
	debug("gm exit post setup-done\n");

	reg_param_set(em_exit_post_cmm, get_cmm_size(em_exit_post_cmm));
	debug("em exit post setup-done\n");
}

void reg_param_set(reg_param_t *param, int cnt)
{
	if(!cnt) return;

	while(cnt--)
	{
		switch((param->opcode&REG_PARAM_OP_GROUP_MASK))
		{
			case REG_PARAM_OP_GROUP_WAIT:	// wait
				udelay(param->operand);
				//debug("delay(_%dms);\n", param->operand/1000);
				break;

			case REG_PARAM_OP_GROUP_CHECK:	// check
				//debug("REG_PARAM_OP_GROUP_CHECK\n");
				break;

			case REG_PARAM_OP_GROUP_RESERVED:
				//debug("REG_PARAM_OP_GROUP_RESERVED\n");
				break;

			default:	// REG_PARAM_OP_GROUP_WRITE
				IO_WRITE((unsigned long)param->opcode, param->operand);
				//debug("IO_WRITE( 0x%08x, 0x%08x);\n", param->opcode, param->operand);
				break;
		}
		//debug("{0x%08x, 0x%08x},\n", param->opcode, param->operand);
		param++;
	}
}

static void control_addr_switch(void)
{
	if(!iboot_mode)//cold boot
		set_addr_switch();

	else//instant boot
	{
		if(status_iboot_addr_switch())
			recovery_iboot_addr_switch();
		else
			set_addr_switch();
	}

	debug("addr switch setup-done\n");
}

int setup_top_ddrc(void)
{
	if(read_shadow_header_bin() != 0)
		return -1;

	uart_pin_pullup();

	if(!iboot_mode)
	{
		setup_cold_boot();
		debug("cold boot setup -- done\n");
	}
	else 
	{
		setup_instant_boot();
		debug("instant boot setup -- done\n");
	}
	
	reg_param_set(top_post_cmm, get_cmm_size(top_post_cmm));
	debug("top_post setup-done\n");

	tzasc_allow_secure();

	reg_param_set(bus_gating_cmm, get_cmm_size(bus_gating_cmm));
	debug("bus gating setup-done\n");
	
	reg_param_set(bus_manager_cmm, get_cmm_size(bus_manager_cmm));
	debug("bus manager setup-done\n");

	control_addr_switch();

	return 0;
}

static void uart_pin_pullup(void)
{
	uint32_t val;

	/* enable pull-up of uart0~2 rx,tx pins */
	val = REG_READ(0xc860108c);
	val &= (0xfffc07ff);
	REG_WRITE(0xc860108c, val);
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
//////////////////////// shadwo header bin ///////////////////////////////////////

#define SHB_SIZE 	(0x4000)//16KB

enum
{
	H15_Ax_SETUP_PARM = 0,
	H15_Bx_SETUP_PARM = 1 ,
	H15_Bx_DDR4_SK_SETUP_PARM = 2 ,
};

#ifdef CONFIG_SHADOW_HEADER_BIN
struct 
{
	char 			*name;
	uint32_t 		*p_size; 	//ex> &top_cmm_size
	reg_param_t 	**p_obj;	//ex> &top_cmm
}soc_setup_header_table[] = 
{
#define cmt(s)	{#s, &(s##_cmm_size), &(s##_cmm)}

	cmt(top),
	cmt(lm),
	cmt(gm),
	cmt(em),
	cmt(lm_exit),
	cmt(gm_exit),
	cmt(em_exit),
	cmt(lm_exit_post),
	cmt(gm_exit_post),
	cmt(em_exit_post),
	cmt(bus_gating),
	cmt(bus_manager),
	cmt(top_post),

#undef cmt
};


#ifdef CONFIG_SECURE_BOOT
// SEQ_SRC_STAT
#define SEQ_SRC_READY		0x000
#define SEQ_SRC_START		0x001
#define SEQ_SRC_MID			0x010
#define SEQ_SRC_END			0x100

static unsigned int sc_hash_phase(int i, int chunks)
{
	unsigned int phase;

	if (i == 0)
	{
		phase = SEQ_SRC_START;
		if (chunks == 1)
			phase = SEQ_SRC_END | SEQ_SRC_START;
	}
	else if (i < (chunks - 1))
		phase = SEQ_SRC_MID;
	else
		phase = SEQ_SRC_END;

	return (phase);
}
#endif

int read_shadow_header_bin(void)
{
	uint32_t shb_size = REG_READ(SPBC_SHADOW_HEADER_SIZE_BASE);
	uint32_t shb_offset = REG_READ(SPBC_SHADOW_HEADER_OFFSET_BASE);
	uint32_t i;
	uint32_t addr;
	uint32_t shb_index;

	if(get_chip_rev() <  LX_CHIP_REV(H15, B0))
		shb_index = H15_Ax_SETUP_PARM;
	else
		shb_index = read_ddr_info();

	//shb_size = 16 * n
	if(shb_size%SHB_SIZE)
	{
		error("wrong size - shadow header bin!\n");
		return -1;
	}

//	debug("shadow header bin size : 0x%08x, offset : 0x%08x, index %d\n"
//											, shb_size, shb_offset, shb_index);
	
#ifdef CONFIG_SECURE_BOOT
	uint32_t 	shb_chunks = shb_size / SHB_SIZE;
	uint8_t 	sha256[32] = {0,};
	uint8_t  	*shb_sha256 = (uint8_t *)SPBC_SHADOW_HEADER_SHA256_BASE;

	for(i = 0; i < shb_chunks; i++)
	{
		uint32_t phase = sc_hash_phase(i, shb_chunks);

		transfer_emmc(LG1210_SRAM_BASE, SHB_SIZE, shb_offset + (i * SHB_SIZE), 0);
		
		if(do_sha256_phase(0, LG1210_SRAM_BASE, (ulong)sha256, shb_size, SHB_SIZE, phase) != 0)
		{
			error("fail calc sha256 of shb!\n");
			return -1;
		}
	}

	//compare sha256
	if(memcmp(sha256, shb_sha256, 32) != 0)
	{
		error("fail compare sha256 of shb!\n");
		return -1;
	}
#endif

	/* load shadow header bin from emmc to normal sram */
	transfer_emmc(LG1210_SRAM_BASE, SHB_SIZE, shb_offset + (shb_index * SHB_SIZE), 0);

	addr = LG1210_SRAM_BASE;
	for(i = 0; i < ARRAY_SIZE(soc_setup_header_table); i++)
	{
#define NAME_LENGTH 16
		uint32_t n_offset;
		uint32_t align_size = 16;

		if(strncmp(soc_setup_header_table[i].name, (char*)((ulong)addr), NAME_LENGTH) != 0)
		{
			error("wrong shadow header bin\n");
			return -1;
		}
		
		*soc_setup_header_table[i].p_size = REG_READ((ulong)(addr + NAME_LENGTH));
		*soc_setup_header_table[i].p_obj = (reg_param_t *)(addr + NAME_LENGTH + sizeof(uint32_t));

		n_offset = NAME_LENGTH + sizeof(uint32_t) + *soc_setup_header_table[i].p_size;
		n_offset += (align_size - (n_offset % align_size));
		addr += n_offset;

#if 0
		debug("size : %x, obj : %x, addr %x\n", *soc_setup_header_table[i].p_size
												, *soc_setup_header_table[i].p_obj
												, addr);
#endif
	}

	return 0;
}
#else
int read_shadow_header_bin(void) {return 0;}
#endif


////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
//////////////////// gpio function /////////////////////////////////////////

#define LG1210_COREAPB_BASE				(0xfd000000)		/* CoreAPB */
#define LG1210_GPIO0_BASE				(LG1210_COREAPB_BASE+0x400000)  /* GPIO port 0 */

#define GPIO_MAX_NUM			144 	//GPIO0 ~ GPIO143, total 144
#define GPIO_SHARED_PIN_START	36 		//GPIO36
#define GPIO_SHARED_PIN_END		139 	//GPIO139

#define GPIO_BASE(p)			((ulong)(LG1210_GPIO0_BASE + (((p)/8) * 0x10000)))

#define READ_GPIO_DIR(p)		IO_READ(GPIO_BASE(p) + 0x400)
#define WRITE_GPIO_DIR(p,v)		IO_WRITE(GPIO_BASE(p) + 0x400, v)

#define READ_GPIO_DATA(p)		IO_READ(GPIO_BASE(p) + 0x3FC)
#define WRITE_GPIO_DATA(p,m,v)	IO_WRITE(GPIO_BASE(p) + m, v)

#define GPIO_DIR_INPUT		0
#define GPIO_DIR_OUTPUT		1

#define GPIO_HIGH			1
#define GPIO_LOW			0

static int gpio_set_direction(uint32_t port, int dir)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		value = (dir == GPIO_DIR_OUTPUT) ? (value | mask) : (value & ~mask);
		WRITE_GPIO_DIR(port, value);

		return 0;
	}
	return -1;
}

#if 0
static int gpio_get_direction(uint32_t port)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		return (value & mask) ? GPIO_DIR_OUTPUT : GPIO_DIR_INPUT;
	}
	return -1;
}

static int gpio_set_value(uint32_t port, int value)
{
	uint32_t mask;

	if(port < GPIO_MAX_NUM)
	{
		mask = 1 << (2 + (port%8));
		value = (value == GPIO_HIGH) ? 0xFF : 0;
		WRITE_GPIO_DATA(port, mask, value);
		return 0;
	}
	return -1;
}
#endif

static int gpio_get_value(uint32_t port)
{
	uint32_t value;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DATA(port);
		value = (value >> (port%8)) & 0x01;

		return (value == 1) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}

/**
 * H15/H15+ DDR option
 *					high		low
 * gpio120(bit11)   DDR3		DDR4
 * gpio121(bit12)	SK			RSV
 *
 */

#define		DDR_TYPE_GPIO		120	//GPIO_MODEL_OPT11	
#define		DDR_VENDOR_GPIO		121	//GPIO_MODEL_OPT12

static uint32_t read_ddr_info(void)
{
	int ddr_type;
	int ddr_vendor;

	gpio_set_direction(DDR_TYPE_GPIO, GPIO_DIR_INPUT);
	ddr_type = gpio_get_value(DDR_TYPE_GPIO);

	gpio_set_direction(DDR_VENDOR_GPIO, GPIO_DIR_INPUT);
	ddr_vendor = gpio_get_value(DDR_VENDOR_GPIO);

	if(ddr_type == GPIO_HIGH && ddr_vendor == GPIO_HIGH)
	{
		printf("[DDR3-SK]\n");
		return H15_Bx_SETUP_PARM;
	}
	else if(ddr_type == GPIO_LOW && ddr_vendor == GPIO_HIGH)
	{
		printf("[DDR4-SK]\n");
		return H15_Bx_DDR4_SK_SETUP_PARM;
	}
	else
	{
		error("not support DDR config - type :%d, vendor :%d\n", ddr_type, ddr_vendor);
		return H15_Bx_SETUP_PARM;
	}
}
