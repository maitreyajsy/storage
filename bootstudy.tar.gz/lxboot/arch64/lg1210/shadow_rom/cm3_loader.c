#include <common.h>

//#define CM3_DEBUG_PRINT

#define MEMCPY 		memcpy_bio

/****************************************************/
/* DEFINE 											*/
/****************************************************/
/* CM3 												*/
#define CM3FW_BASE_ADDRESS	0xC1000000
#define CM3FW_RUN_STOP		0xC103F000	//  0:STALL, 1:RUN
#define CM3FW_UART_MUX		0xc8601084	// 0x22508000


#define CM3_IRQ_BASE	0xC1020110
#define CM3_IPC_BASE	0xC1013E00
#define PMS_INFO_BASE	(CM3_IPC_BASE + 0xC0)

#define CPU_FS				0xaa000001
#define CPU_VS				0xaa000002
#define PMS_RES				0xaa000100
#define GPU_FS				0x55000001
#define GPU_VS				0x55000002
#define GPU_PMS_RES			0x55000005


#define PMS_PARTITION_1 0x66736D70
#define PMS_PARTITION_2 0x00000077

#define PMS_FW_SHADOW_MAGIC_1 0x706d6677
#define PMS_FW_SHADOW_MAGIC_2 0x73686472
#define PMS_FW_SECURE_FLAG	  0x75636573

#define SRAM_BASE 	LG1210_SRAM_BASE //non-secure sram
#define SRAM_SIZE 	LG1210_SRAM_SIZE //16KB

/* RSA 												*/
#define SIGN_LENGTH						PRIVATE_LENGTH
#define PUBLIC_LENGTH					3

#define CRYPTO_SIGNING          		0

#define BIGINT_NUM_MODS     			1

/****************************************************/
/* STR, VAR											*/
/****************************************************/
typedef uint32_t comp;
typedef struct _sign
{
	char _dat[SIGN_LENGTH];
} sign_t;
#define sign_data(x)		((x)->_dat)
const char	public_key[PUBLIC_LENGTH] = { 0x01, 0x00, 0x01 };

unsigned char verify_key[] = {
0xa9,0xb9,0x53,0x3c,0x03,0xcd,0xf8,0xd8,0x9b,0x41,0x3b,0x78,0xc9,0x41,0x39,0x31,
0x6f,0x08,0x13,0x78,0x37,0x37,0x21,0x9c,0x77,0xc5,0x27,0x16,0x19,0x0d,0x44,0x83,
0x7c,0x40,0x84,0x52,0x3f,0xc5,0x63,0x4b,0x60,0x0a,0x6f,0xc7,0xac,0xbb,0x70,0x10,
0xf8,0xf6,0xc0,0x7b,0xca,0xf6,0x4f,0xf0,0xb6,0xae,0xec,0x2f,0x7f,0xec,0xf6,0x01,
0x78,0xc0,0x6a,0x7b,0x0e,0x39,0xa4,0x42,0x47,0xbc,0xda,0xe2,0x37,0xb5,0x5f,0x17,
0xcb,0x55,0xea,0xdc,0x78,0xf6,0xc0,0x0c,0xb9,0x12,0x4e,0x31,0xbd,0x4b,0x7d,0x34,
0xa2,0xb1,0xe4,0xbf,0xb5,0x5b,0x23,0x80,0x96,0xd4,0xe3,0xbf,0xa4,0x89,0x42,0x99,
0x05,0x1b,0xe2,0xb4,0xbe,0x1e,0x95,0x0c,0xdc,0x17,0x31,0x25,0x90,0xe9,0x0a,0x76,
0xe0,0xf4,0xb3,0xf3,0x73,0xac,0x13,0x6c,0x1d,0xc0,0xb5,0x2e,0xcf,0xc0,0xe8,0x00,
0x86,0xc8,0x16,0x88,0xbe,0x31,0xac,0xa0,0xb1,0x09,0x0b,0xf7,0x98,0x87,0xcc,0x1c,
0xd2,0x5c,0x7c,0xa5,0x18,0x06,0xf9,0xf1,0x85,0x14,0xab,0x8d,0xa3,0x86,0x75,0x02,
0x74,0xe3,0x33,0x23,0xb4,0x1f,0x18,0x0c,0x63,0x8d,0xe1,0x33,0x35,0x18,0x35,0xaa,
0x73,0x8b,0x30,0x5a,0x45,0x26,0x8f,0xce,0xdb,0x76,0x1c,0xf6,0xb9,0x70,0x95,0xab,
0x90,0x9a,0xa0,0x7e,0x96,0x11,0x16,0x1e,0x2d,0xc4,0xe7,0xa4,0xe1,0xc6,0xcb,0x6c,
0x13,0xeb,0x5a,0xb4,0xe9,0x4c,0x03,0xcd,0x5c,0xd5,0x70,0x61,0x7c,0x28,0xf3,0xca,
0x1e,0x62,0x06,0x59,0xfb,0xfa,0x8c,0x9b,0x13,0xaf,0x0e,0x75,0x64,0xb6,0x2d,0xb7};


/****************************************************/
/* EXTERN											*/
/****************************************************/

/****************************************************/
/* MAIN											*/
/****************************************************/
static inline const char *get_modulus(rsa_key_t *key)
{
	return (char *)&(key->modulus);
}

static int rsa_decrypt(uint8_t *in, uint8_t *out, unsigned int key_index)
{
	int ret = 0;
	rsa_key_t	*key = NULL;
	RSA_CTX 	*rsa_ctx = NULL;
	sign_t		*sign_in = NULL;

	mmu_init(0x0,0);

	/* create RSA context */
//	key = rom_rsakey_get(RSA2048_LENGTH, key_index);
	key = (rsa_key_t *)verify_key;

	RSA_pub_key_new(&rsa_ctx,
					(const uint8_t *)get_modulus(key), RSA2048_LENGTH,
					(const uint8_t *)public_key, PUBLIC_LENGTH);

	/* locate signature in sram; currently (0xc008_0000-keylen) */
	sign_in = (sign_t *)(u64)(in);

	/* rsa decrypt: (in, out) = (signature/public, sha256) */
	ret = RSA_decrypt(rsa_ctx, (uint8_t *)sign_data(sign_in), out,
						  CRYPTO_SIGNING);
	RSA_free(rsa_ctx);
	if (ret < 0)
	{
		debug("PMSFW RSA FAIL!\n");
		mmu_disable();
		return -1;
	}

#ifdef CM3_DEBUG_PRINT
	unsigned int di;
	debug("RSA DECRYPT OUT\n");
	for (di=0; di<32; di++)
		debug("%02X ",out[di]);
	debug("\n");
#endif
	mmu_disable();

	return 0;
}

static int hashcmp(uint8_t *src1, uint8_t *src2)
{
	unsigned int i;
	unsigned int *src1_4B, *src2_4B;

	src1_4B = (unsigned int*)src1;
	src2_4B = (unsigned int*)src2;

	for (i=0; i<(32/4); i++)
	{
		if (src1_4B[i] != src2_4B[i])
		{
			debug("PMSFW HASH MISMATCH\n");
			return -1;
		}
#ifdef CM3_DEBUG_PRINT
		else
			debug("[%u] 0x%08X\n",i, src1_4B[i]);
#endif
	}

	return 0;
}

void send_cm3_ipc(unsigned int cmd, unsigned int freq, unsigned int vol)
{
	unsigned int i;
	static unsigned int key = 0;

	key++;

	*(volatile unsigned int*)0xC1020110 = 0x0;

	*(volatile unsigned int*)(CM3_IPC_BASE) = cmd;
	*(volatile unsigned int*)(CM3_IPC_BASE + 4) = freq;
	*(volatile unsigned int*)(CM3_IPC_BASE + 8) = vol;
	*(volatile unsigned int*)(CM3_IPC_BASE + 0x1C) = key;

	*(volatile unsigned int*)0xC1020110 = 0x1;

	i = 0;
	while (1)
	{
		if (*(volatile unsigned int*)(CM3_IPC_BASE+0x20+0x1C) == key)
			break;

		udelay(1000);

		i++;
		if (i > 30)
			break;
	}
}

unsigned int send_gpu_ipc(unsigned int cmd, unsigned int freq, unsigned int vol)
{
	unsigned int i;
	static unsigned int key = 0;

	key++;

	*(volatile unsigned int*)0xC1020110 = 0x0;

	*(volatile unsigned int*)(CM3_IPC_BASE + 0x80) = cmd;
	*(volatile unsigned int*)(CM3_IPC_BASE + 0x80 + 4) = freq;
	*(volatile unsigned int*)(CM3_IPC_BASE + 0x80 + 8) = vol;
	*(volatile unsigned int*)(CM3_IPC_BASE + 0x80 + 0x1C) = key;

	*(volatile unsigned int*)0xC1020110 = 0x2;

	i = 0;
	while (1)
	{
		if (*(volatile unsigned int*)(CM3_IPC_BASE+0xA0+0x1C) == key)
			break;

		udelay(1000);

		i++;
		if (i > 30)
			break;
	}

	return 0;
}

void clear_cm3_firmware(void)
{
	unsigned int i;
	unsigned int *buffer;

	buffer = (unsigned int *)CM3FW_BASE_ADDRESS;

	for (i=0; i<(65536/4); i+=8)
	{
		buffer[i] = 'D';
		buffer[i+1] = 'E';
		buffer[i+2] = 'A';
		buffer[i+3] = 'D';
		buffer[i+4] = 'd';
		buffer[i+5] = 'e';
		buffer[i+6] = 'a';
		buffer[i+7] = 'd';
	}

	return;
}
void load_cm3_firmware(void)
{

	unsigned int *buff;
	unsigned int pmfw_offset = 0;
	unsigned int i;
	unsigned int phase;
	uint8_t 	sha256[32];
	uint8_t 	decrypt_rsa[32];
	uint8_t 	read_rsa[256];

#define SEQ_SRC_START		0x001
#define SEQ_SRC_MID			0x010
#define SEQ_SRC_END			0x100

        *(unsigned int*)(PMS_INFO_BASE + 0x3C) = 0x0;
        *(unsigned int*)(PMS_INFO_BASE + 0x00) = 0x0;

	transfer_emmc(SRAM_BASE, 16384, 0x100000, 0);
	buff = (unsigned int*)SRAM_BASE;

	for(i=0; i<(16384/4) - 2; i++)
	{
		if ((buff[i] == PMS_PARTITION_1) && (buff[i+1] == PMS_PARTITION_2))
		{
			pmfw_offset = *(unsigned int*)(buff + i + (0x20/4));
			debug("pmfw_partition 0x%X\n", pmfw_offset);
			break;
		}
	}

	if (!pmfw_offset)
		return;

	transfer_emmc(SRAM_BASE, 0x200, pmfw_offset, 0);
	if (buff[3] != PMS_FW_SECURE_FLAG)
	{
		debug("PMSFW IS NOT SECURE\n");
		return;
	}

	if ((buff[0] == PMS_FW_SHADOW_MAGIC_1) && (buff[1] == PMS_FW_SHADOW_MAGIC_2))
	{
		debug("pmfw_load in shadowrom\n");
		*(unsigned int*)(CM3FW_RUN_STOP) = 0;

		MEMCPY((void *)read_rsa,(unsigned char*)(SRAM_BASE+256), 256);

		for (i=0; i<4; i++)
		{
			transfer_emmc(SRAM_BASE, 0x4000, pmfw_offset + (0x4000 * i) + 0x200, 0);
			MEMCPY((void *)CM3FW_BASE_ADDRESS + (0x4000 * i), (void *)SRAM_BASE, 0x4000);

			if (i == 0)
				phase = SEQ_SRC_START;
			else if (i == 3)
				phase = SEQ_SRC_END;
			else
				phase = SEQ_SRC_MID;

			do_sha256_phase(0, LG1210_SRAM_BASE, (ulong)sha256, 0x10000, 0x4000, phase);
		}

#ifdef CM3_DEBUG_PRINT
		unsigned int di;
		debug("HASH H/W OUT\n");
		for (di=0; di<32; di++)
			debug("%02X ",sha256[di]);
		debug("\n");
#endif

		if (rsa_decrypt(read_rsa,decrypt_rsa,1) < 0)
		{
			clear_cm3_firmware();
			return;
		}

		if (hashcmp(sha256,decrypt_rsa) < 0)
		{
			clear_cm3_firmware();
			return;
		}

		debug("PMSFW Secure OK\n");

		*(unsigned int*)(PMS_INFO_BASE + 0x3C) = 0x0;
		*(unsigned int*)(PMS_INFO_BASE + 0x00) = 0x0;

		*(unsigned int*)(CM3FW_RUN_STOP) = 1;
	}
}

void cm3_check(void)
{
	unsigned int i;

	i = 0;

	while (1)
	{
		if (*(volatile unsigned int*)(PMS_INFO_BASE) > 0)
			break;

		udelay(1000);

		i++;
		if (i>200)
		{
			debug("pmfw_load fail next step to LxBOOT\n");
			return;
		}
	}

	send_cm3_ipc(CPU_VS,0,1050000);
	if (*(unsigned int*)(PMS_INFO_BASE + 0x8) != 1050)
	{
		debug("cpu vol setting fail\n");
		return;
	}

	send_cm3_ipc(CPU_FS,1404000,0);
	if (*(unsigned int*)(PMS_INFO_BASE + 0x4) != 1404)
	{
		debug("cpu freq setting fail\n");
		return;
	}
	debug("CPU : 1404Mhz/1050mv\n");

	send_gpu_ipc(GPU_VS,0,1000000);
	if (*(unsigned int*)(PMS_INFO_BASE + 0x14) != 1000)
	{
		debug("gpu vol setting fail\n");
		return;
	}
	debug("gpu vol 1000mv\n");

	send_gpu_ipc(GPU_FS,672000,0);
	if (*(unsigned int*)(PMS_INFO_BASE + 0x10) != 672)
	{
		debug("gpu freq setting fail\n");
		return;
	}
	debug("GPU : 672Mhz/1000mv\n");
}

