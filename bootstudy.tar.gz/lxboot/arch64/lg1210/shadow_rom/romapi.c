#include <common.h>

/* 
 * SHADOW ROM share symbols of boot rom.
 * i.e. SHADOW ROM call functions of boot rom.
 * so, need init the address of symbols
 */

/* global variables */

/* symbol list to share with bootrom */
int (*printf)(const char *fmt, ...);
void (*udelay)(uint32_t  usec);
uint32_t (*timer_usec)(void);
unsigned int (*transfer_emmc)(unsigned long long buffer, unsigned int size, unsigned long long address, char r_w);
int (*strncmp)(const char *s1, const char *s2, uint32_t count);
int (*memcmp)(const void *dst, const void *src, uint32_t n);
int (*do_sha256_phase)(uint32_t ch, uint32_t src, uint32_t dst,
					 uint32_t length, uint32_t unit_size, uint32_t phase);
rsa_key_t *(*rom_rsakey_get)(unsigned int len, unsigned int idx);
int (*RSA_decrypt)(const RSA_CTX *ctx, const uint8_t *in_data, uint8_t *out_data, int is_decryption);
void (*RSA_pub_key_new)(RSA_CTX **ctx, const uint8_t *modulus, int mod_len, const uint8_t *pub_exp, int pub_len);
void (*RSA_free)(RSA_CTX *rsa_ctx);
void (*mmu_init)(uint64_t tbl_base, int tbl_clear);
void (*mmu_disable)(void);
struct
{
	int (*printf)(const char *fmt, ...);
	void (*udelay)(uint32_t  usec);
	uint32_t (*timer_usec)(void);
	unsigned int (*transfer_emmc)(unsigned long long buffer, unsigned int size, unsigned long long address, char r_w);
	int (*strncmp)(const char *s1, const char *s2, uint32_t count);
	int (*memcmp)(const void *dst, const void *src, uint32_t n);
	int (*do_sha256_phase)(uint32_t ch, uint32_t src, uint32_t dst, uint32_t length, uint32_t unit_size, uint32_t phase);
	rsa_key_t *(*rom_rsakey_get)(unsigned int len, unsigned int idx);
	int (*RSA_decrypt)(const RSA_CTX *ctx, const uint8_t *in_data, uint8_t *out_data, int is_decryption);
	void (*RSA_pub_key_new)(RSA_CTX **ctx, const uint8_t *modulus, int mod_len, const uint8_t *pub_exp, int pub_len);
	void (*RSA_free)(RSA_CTX *rsa_ctx);
	void (*mmu_init)(uint64_t tbl_base, int tbl_clear);
	void (*mmu_disable)(void);
}bootrom_symbol[] = {
	// 0, H15 Ax
	{
		.printf				= (void*)0xc00c0374,
		.udelay				= (void*)0xc00c07f4,
		.timer_usec			= (void*)0xc00c07d0,
		.transfer_emmc		= (void*)0xc00c4b5c,
		.strncmp			= (void*)0xc00c0de4,
		.memcmp				= (void*)0xc00c0f7c,
		.do_sha256_phase 	= (void*)0xc00c51dc,
		.rom_rsakey_get		= (void*)0xc00c6950,
		.RSA_decrypt 		= (void*)0xc00c64b8,
		.RSA_pub_key_new 	= (void*)0xc00c63e0,
		.RSA_free			= (void*)0xc00c6374,
		.mmu_init 			= (void*)0xc00c0a60,
		.mmu_disable 		= (void*)0xc00c0ae4,
	},

	// 1, H15 Bx
	{
		.printf				= (void*)0xc00c0374,
		.udelay				= (void*)0xc00c07f4,
		.timer_usec			= (void*)0xc00c07d0,
		.transfer_emmc		= (void*)0xc00c4b68,
		.strncmp			= (void*)0xc00c0de4,
		.memcmp 		 	= (void*)0xc00c0f7c,
		.do_sha256_phase 	= (void*)0xc00c51e8,
		.rom_rsakey_get		= (void*)0xc00c695c,
		.RSA_decrypt 		= (void*)0xc00c64c4,
		.RSA_pub_key_new 	= (void*)0xc00c63ec,
		.RSA_free 			= (void*)0xc00c6380,
		.mmu_init 			= (void*)0xc00c0a60,
		.mmu_disable 		= (void*)0xc00c0ae4,
	},
};

/* implement function */

void rom_symbol_init(void)
{
	uint32_t symbol_index;

	if(get_chip_rev() <  LX_CHIP_REV(H15, B0))
		symbol_index = 0;
	else
		symbol_index = 1;

	printf				= bootrom_symbol[symbol_index].printf;
	udelay				= bootrom_symbol[symbol_index].udelay;
	timer_usec			= bootrom_symbol[symbol_index].timer_usec;
	transfer_emmc		= bootrom_symbol[symbol_index].transfer_emmc;
	strncmp				= bootrom_symbol[symbol_index].strncmp;
	memcmp 				= bootrom_symbol[symbol_index].memcmp;
	do_sha256_phase		= bootrom_symbol[symbol_index].do_sha256_phase;
	rom_rsakey_get 		= bootrom_symbol[symbol_index].rom_rsakey_get;
	RSA_decrypt			= bootrom_symbol[symbol_index].RSA_decrypt; 
	RSA_pub_key_new 	= bootrom_symbol[symbol_index].RSA_pub_key_new;
	RSA_free      		= bootrom_symbol[symbol_index].RSA_free;
	mmu_init			= bootrom_symbol[symbol_index].mmu_init;
	mmu_disable 		= bootrom_symbol[symbol_index].mmu_disable;
}

