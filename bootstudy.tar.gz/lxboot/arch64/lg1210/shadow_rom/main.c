#include <common.h>
#include <top_ddrc.h>
#include <iboot_param.h>


/* static variables */
static uint32_t chip_rev = CONFIG_CHIP;

/* global variables */

uint32_t iboot_mode = 0;


/* static function headers */
static int chip_detect(void);
static void get_soc_iboot_param(void);


/* define macro */
#define LG1210_CX_CHIPREV_BASE			(0xc8601c78)	/* C0 : 0x1210cccc */
#define LG1210_CHIPREV_BASE 			(0xc8600020) 	/* A0 : 0x0, B0 : 0x1210b000 */
#define LG1210_TZ_ROM_BASE 				(0xc00c0000) 	/* TZ ROM */


/* implement functions */

int main(uint32_t mode0, uint32_t mode1)
{
	int check_chip;

	check_chip = chip_detect();
	rom_symbol_init();

	if(check_chip != 0)
		error("can't detect chip rev!, use default chip rev[%x]\n", get_chip_rev());

	debug("==== hello shadow rom ====\n");

	printf("[%s%s]\n", get_arch_string(chip_rev), get_rev_string(chip_rev));

	if(mode0 == 0xa && mode1 == 0xb)
		iboot_mode = 1;
	else
		iboot_mode = 0;

	load_cm3_firmware();

	if(setup_top_ddrc() != 0)
		goto func_exit;

	cm3_check();
	
	get_soc_iboot_param();

	debug("shadow_rom -- done\n");
	return 0;

func_exit:
	error("shadow_rom -- fail\n");
	return -1;
}

static void get_soc_iboot_param(void)
{
	if(!iboot_mode)
		return;

	recovery_iboot_param_dport();
	recovery_iboot_param_jtag();
}


/*
 * name : chip_detect
 * TODO: cant' call bootrom function , not yet initialize bootrom symbols.
 */
static int chip_detect(void)
{
	uint32_t version;
	uint32_t rev;
	int ret = 0;

	version = REG_READ(LG1210_CX_CHIPREV_BASE);
	if(version == 0x1210cccc)
	{//Cx
		chip_rev = ARCH_LG1210 | REV_C0;
	}
	else
	{
		version = REG_READ(LG1210_CHIPREV_BASE);
		if(version == 0)
		{//Ax
			rev = REG_READ(LG1210_TZ_ROM_BASE);
			if(rev == 0)
			{
				chip_rev = ARCH_LG1210 | REV_A0;
			}
			else
			{
				chip_rev = ARCH_LG1210 | REV_A1;
			}
		}
		else if(version == 0x1210b000)
		{//Bx
			chip_rev = ARCH_LG1210 | REV_B0;
		}
		else
			ret = -1;
	}

	return ret;
}

uint32_t get_chip_rev(void)
{
	return chip_rev;
}



#if 0
int raise (int signum){ return 0;}
void __aeabi_unwind_cpp_pr0(void){}
void __aeabi_unwind_cpp_pr1(void){}

int i = 20;
uint32_t usec;


usec = timer_usec();
printf("timer_usec test, %d usec\n", usec);

udelay(1000);

printf("printf test %d\n", i++);

udelay(1000);

printf("printf test %d\n", i++);

udelay(1000);

puts("puts test\n");

usec = timer_usec();
printf("dummy shadow rom, to be used setup bus & ddrc\n");
#endif
