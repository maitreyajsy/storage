#include <types.h>
#include <string.h>
#include <arch/cpu.h>
#include <arch/ctop_regs.h>
#include <command.h>
#include <gpio.h>

//#define DBG
#include <debug.h>

#define GPIO_MAX_NUM			144 	//GPIO0 ~ GPIO143, total 144
#define GPIO_SHARED_PIN_START	36 		//GPIO36
#define GPIO_SHARED_PIN_END		139 	//GPIO139

#define GPIO_BASE(p)			((ulong)(LG1210_GPIO0_BASE + (((p)/8) * 0x10000)))

#define READ_GPIO_DIR(p)		IO_READ(GPIO_BASE(p) + 0x400)
#define WRITE_GPIO_DIR(p,v)		IO_WRITE(GPIO_BASE(p) + 0x400, v)

#define READ_GPIO_DATA(p)		IO_READ(GPIO_BASE(p) + 0x3FC)
#define WRITE_GPIO_DATA(p,m,v)	IO_WRITE(GPIO_BASE(p) + m, v)


#if defined(CONFIG_BOARD_TYPE_FPGA)
int gpio_set_top(uint32_t port){ return 0;}
#else
int gpio_set_top(uint32_t port)
{
	return gpio_set_pin_mux(port, 1);
}
#endif

int gpio_set_pin_mux(u32 port, int enable)
{
	uint32_t value = 0;
	uint32_t mask = 0;
	uint32_t bit = 0;

	if(port < GPIO_SHARED_PIN_START)
	{
		if(port == 31)
		{
			CTOP_CTRL_VIP_CTR37_H15A0 ctr37;
			ctr37 = ctop_regs->VIP->ctr37;
			ctr37.cpu_mon_31_en = enable ? 1 : 0;
			ctop_regs->VIP->ctr37 = ctr37;
			return 0;
		}

		DEBUG("port %03d, static gpio\n", port);
		return 0;
	}
	else if(port <= 63)
	{
		if(port == 56 || port == 57)
		{
			/* SR, CTR32 gpio57[2] gpio56[1] */
			value = CTOP_CTRL_READ(SR, ctr32);
			bit = 1 + (port - 56);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(SR, ctr32, value);
		}
		else if(port == 60 || port == 61)
		{
			/* ND0, CTR32 gpio60[31] gpio60[30] */
			value = CTOP_CTRL_READ(ND0, ctr32);
			bit = 30 + (port - 60);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(ND0, ctr32, value);
		}
		else
		{
			/* CVI, CTR34
			 * 31...28.27...24.23...16.15....8.7..6..3..2
			 * [39:36] [xx:xx] [47:40] [55:48] 63 62 59 58
			 */
			if(port <= 39)
				bit = 28 + (port - 36);
			else if(port <= 47)
				bit = 16 + (port - 40);
			else if(port <= 55)
				bit = 8 + (port - 48);
			else
				bit = 2 + (port - 58);

			value = CTOP_CTRL_READ(CVI, ctr34);
			mask = 1 << bit;
			value = enable ? (value | mask) : (value & (~mask));
			CTOP_CTRL_WRITE(CVI, ctr34, value);
		}
	}
	else if(port <= 66)
	{
		/* SR, CTR32 gpio66[5] gpio64[3] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 3 + (port - 64);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(SR, ctr32, value);
	}
	else if(port <= 70)
	{
		/* VIP, CTR37 gpio70[30] gpio67[27] */
		value = CTOP_CTRL_READ(VIP, ctr37);
		bit = 27 + (port - 67);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(VIP, ctr37, value);
	}
	else if(port <= 80)
	{
		/* SR, CTR32  gpio80[15] gpio71[6] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 6 + (port - 71);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(SR, ctr32, value);
	}
	else if(port <= 86)
	{
		/* ND0, CTR32 gpio86[14] gpio81[9] */
		value = CTOP_CTRL_READ(ND0, ctr32);
		bit = 9 + (port - 81);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(ND0, ctr32, value);
	}
	else if(port <= 87)
	{
		/* SR, CTR32  gpio87[17] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 17 + (port - 87);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(SR, ctr32, value);
	}
	else if(port <= 93)
	{
		/* VIP, CTR32 gpio93[31] gpio88[26] */
		/* 0 : enable gpio (except 89) */
		if(port != 89)
			enable = (~enable & 0x01);

		value = CTOP_CTRL_READ(VIP, ctr32);
		bit = 26 + (port - 88);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(VIP, ctr32, value);
	}
	else if(port <= 96)
	{
		/* SR, CTR32  gpio96[20] gpio94[18] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 18 + (port - 94);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(SR, ctr32, value);
	}
	else if(port <= 103)
	{
		/* CVI, CTR35 gpio103[31] gpio97[25] */
		value = CTOP_CTRL_READ(CVI, ctr35);
		bit = 25 + (port - 97);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(CVI, ctr35, value);
	}
	else if(port <= 111)
	{
		/* 104 ~ 111 ,not exist!!! */
		DEBUG("not exist pin\n");
		return -1;
	}
	else if(port <= 119)
	{
		/* SR, CTR32 gpio119[28] gpio112[21] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 21 + (port - 112);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(SR, ctr32, value);
	}
	else if(port <= 125)
	{
		/* VIP, CTR32 gpio125[25] gpio120[20] */
		/* 0 : enable gpio */
		enable = (~enable & 0x01);

		value = CTOP_CTRL_READ(VIP, ctr32);
		bit = 20 + (port - 120);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(VIP, ctr32, value);
	}
	else if(port <= 127)
	{
		/* SR, CTR32 gpio127[30] gpio126[29] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 29 + (port - 126);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(SR, ctr32, value);
	}
	else if(port <= 131)
	{
		/* 128 ~ 131, not exist!! */
		DEBUG("not exist pin\n");
		return -1;
	}
	else if(port <= 132)
	{
		/* SR, CTR32 gpio132[31] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 31 + (port - 132);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(SR, ctr32, value);
	}
	else if(port <= 133)
	{
		/* VIP, CTR37 gpio133[31] */
		value = CTOP_CTRL_READ(VIP, ctr37);
		bit = 31 + (port - 133);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(VIP, ctr37, value);
	}
	else if(port <= 135)
	{
		/* VIP, CTR32 gpio135[19] gpio134[18] */
		/* 0 : enable gpio */
		enable = (~enable & 0x01);

		value = CTOP_CTRL_READ(VIP, ctr32);
		bit = 18 + (port - 134);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(VIP, ctr32, value);
	}
	else if(port <= 139)
	{
		/* CVI, CTR34  gpio139[27] gpio136[24] */
		value = CTOP_CTRL_READ(CVI, ctr34);
		bit = 24 + (port - 136);
		mask = 1 << bit;
		value = enable ? (value | mask) : (value & (~mask));
		CTOP_CTRL_WRITE(CVI, ctr34, value);
	}
	else if(port <= 143)
	{
	}
	else
	{
		DEBUG("not exist pin\n");
		return -1;
	}

	DEBUG("port %03d, bit %02d, mask %08x\n", port, bit, mask);

	return 0;
}

int gpio_get_pin_mux(u32 port)
{
	uint32_t value = 0;
	uint32_t mask = 0;
	uint32_t bit = 0;

	if(port < GPIO_SHARED_PIN_START)
	{
		if(port == 31)
		{
			CTOP_CTRL_VIP_CTR37_H15A0 ctr37;
			ctr37 = ctop_regs->VIP->ctr37;
			if(ctr37.cpu_mon_31_en)
				return 1;
			else 
				return 0;
		}

		DEBUG("port %03d, static gpio\n", port);
		return 1;
	}
	else if(port <= 63)
	{
		if(port == 56 || port == 57)
		{
			/* SR, CTR32 gpio57[2] gpio56[1] */
			value = CTOP_CTRL_READ(SR, ctr32);
			bit = 1 + (port - 56);
			mask = 1 << bit;
		}
		else if(port == 60 || port == 61)
		{
			/* ND0, CTR32 gpio60[31] gpio60[30] */
			value = CTOP_CTRL_READ(ND0, ctr32);
			bit = 30 + (port - 60);
			mask = 1 << bit;
		}
		else
		{
			/* CVI, CTR34
			 * 31...28.27...24.23...16.15....8.7..6..3..2
			 * [39:36] [xx:xx] [47:40] [55:48] 63 62 59 58
			 */
			if(port <= 39)
				bit = 28 + (port - 36);
			else if(port <= 47)
				bit = 16 + (port - 40);
			else if(port <= 55)
				bit = 8 + (port - 48);
			else
				bit = 2 + (port - 58);

			value = CTOP_CTRL_READ(CVI, ctr34);
			mask = 1 << bit;
		}
	}
	else if(port <= 66)
	{
		/* SR, CTR32 gpio66[5] gpio64[3] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 3 + (port - 64);
		mask = 1 << bit;
	}
	else if(port <= 70)
	{
		/* VIP, CTR37 gpio70[30] gpio67[27] */
		value = CTOP_CTRL_READ(VIP, ctr37);
		bit = 27 + (port - 67);
		mask = 1 << bit;
	}
	else if(port <= 80)
	{
		/* SR, CTR32  gpio80[15] gpio71[6] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 6 + (port - 71);
		mask = 1 << bit;
	}
	else if(port <= 86)
	{
		/* ND0, CTR32 gpio86[14] gpio81[9] */
		value = CTOP_CTRL_READ(ND0, ctr32);
		bit = 9 + (port - 81);
		mask = 1 << bit;
	}
	else if(port <= 87)
	{
		/* SR, CTR32  gpio87[17] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 17 + (port - 87);
		mask = 1 << bit;
	}
	else if(port <= 93)
	{
		/* VIP, CTR32 gpio93[31] gpio88[26] */
		value = CTOP_CTRL_READ(VIP, ctr32);
		bit = 26 + (port - 88);
		mask = 1 << bit;
		/* 0 : enable gpio (except 89) */
		if(port != 89)
			value = ~value;
	}
	else if(port <= 96)
	{
		/* SR, CTR32  gpio96[20] gpio94[18] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 18 + (port - 94);
		mask = 1 << bit;
	}
	else if(port <= 103)
	{
		/* CVI, CTR35 gpio103[31] gpio97[25] */
		value = CTOP_CTRL_READ(CVI, ctr35);
		bit = 25 + (port - 97);
		mask = 1 << bit;
	}
	else if(port <= 111)
	{
		/* 104 ~ 111 ,not exist!!! */
		DEBUG("not exist pin\n");
		return -1;
	}
	else if(port <= 119)
	{
		/* SR, CTR32 gpio119[28] gpio112[21] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 21 + (port - 112);
		mask = 1 << bit;
	}
	else if(port <= 125)
	{
		/* VIP, CTR32 gpio125[25] gpio120[20] */
		value = CTOP_CTRL_READ(VIP, ctr32);
		bit = 20 + (port - 120);
		mask = 1 << bit;
		/* 0 : enable gpio */
		value = ~value;
	}
	else if(port <= 127)
	{
		/* SR, CTR32 gpio127[30] gpio126[29] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 29 + (port - 126);
		mask = 1 << bit;
	}
	else if(port <= 131)
	{
		/* 128 ~ 131, not exist!! */
		DEBUG("not exist pin\n");
		return -1;
	}
	else if(port <= 132)
	{
		/* SR, CTR32 gpio132[31] */
		value = CTOP_CTRL_READ(SR, ctr32);
		bit = 31 + (port - 132);
		mask = 1 << bit;
	}
	else if(port <= 133)
	{
		/* VIP, CTR37 gpio133[31] */
		value = CTOP_CTRL_READ(VIP, ctr37);
		bit = 31 + (port - 133);
		mask = 1 << bit;
	}
	else if(port <= 135)
	{
		/* VIP, CTR32 gpio135[19] gpio134[18] */
		value = CTOP_CTRL_READ(VIP, ctr32);
		bit = 18 + (port - 134);
		mask = 1 << bit;
		/* 0 : enable gpio */
		value = ~value;
	}
	else if(port <= 139)
	{
		/* CVI, CTR34  gpio139[27] gpio136[24] */
		value = CTOP_CTRL_READ(CVI, ctr34);
		bit = 24 + (port - 136);
		mask = 1 << bit;
	}
	else if(port <= 143)
	{
	}
	else
	{
		DEBUG("not exist pin\n");
		return -1;
	}

	DEBUG("port %03d, bit %02d, mask %08x\n", port, bit, mask);

	return (value & mask) ? 1 : 0;
}

int gpio_set_direction(uint32_t port, int dir)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		value = (dir == GPIO_DIR_OUTPUT) ? (value | mask) : (value & ~mask);
		WRITE_GPIO_DIR(port, value);

		return 0;
	}
	return -1;
}

int gpio_get_direction(uint32_t port)
{
	uint32_t value, mask;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DIR(port);
		mask = 1 << (port%8);
		return (value & mask) ? GPIO_DIR_OUTPUT : GPIO_DIR_INPUT;
	}
	return -1;
}

int gpio_set_value(uint32_t port, int value)
{
	uint32_t mask;

	if(port < GPIO_MAX_NUM)
	{
		mask = 1 << (2 + (port%8));
		value = (value == GPIO_HIGH) ? 0xFF : 0;
		WRITE_GPIO_DATA(port, mask, value);
		return 0;
	}
	return -1;
}

int gpio_get_value(uint32_t port)
{
	uint32_t value;

	if(port < GPIO_MAX_NUM)
	{
		value = READ_GPIO_DATA(port);
		value = (value >> (port%8)) & 0x01;

		return (value == 1) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}

/* ---------- h15a gpio ----------- */
static int gpio_ex_dir[2] = {-1, -1};

static void gpio_ex_init(void)
{
	static int inited = 0;

	if(inited) return;
	inited = 1;

	/* Set Interrupt Sense to get the value */
	ace_reg_write(0x28, 0x12, 0xFF);
	ace_reg_write(0x28, 0x13, 0xFF);

	/*
	(3) GPIO_IEV 가 1일면 input level인 '1' 인 경우 High, '0'이면 Low
	(4) GPIO_IEV 가 0일면 input level인 '0' 인 경우 High, '1'이면 Low
	*/
	ace_reg_write(0x28, 0x16, 0xFF);
	ace_reg_write(0x28, 0x17, 0xFF);
}

int gpio_ex_set_direction(uint32_t port, int dir)
{
	gpio_ex_init();
	if(port < 16)
	{
		int block = port/8;
		uint8_t addr, mask, value;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x10 : 0x11;

		if(gpio_ex_dir[block] == -1)
		{
			ace_reg_read(0x28, addr, &value);
			gpio_ex_dir[block] = value;
		}

		value = (dir == GPIO_DIR_INPUT) ? gpio_ex_dir[block] & (~mask) : gpio_ex_dir[block] | mask;

		if(gpio_ex_dir[block] != value)
		{
			ace_reg_write(0x28, addr, value);
			gpio_ex_dir[block] = value;
		}
		return 0;
	}
	return -1;
}

int gpio_ex_get_direction(uint32_t port)
{
	gpio_ex_init();
	if(port < 16)
	{
		int block = port/8;
		uint8_t addr, value, mask;

		mask = 1 << (port % 8);
		if(gpio_ex_dir[block] == -1)
		{
			addr = (port < 8) ? 0x10 : 0x11;
			ace_reg_read(0x28, addr, &value);
			gpio_ex_dir[block] = value;
		}

		DEBUG("DIR:0x%02x\n", gpio_ex_dir[block]);
		return (gpio_ex_dir[block] & mask) ? GPIO_DIR_OUTPUT : GPIO_DIR_INPUT;
	}
	return -1;
}

int gpio_ex_set_value(uint32_t port, int value)
{
	gpio_ex_init();
	if(port < 16)
	{
		uint8_t data, mask;
		uint8_t addr;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x00 : 0x01;

		ace_reg_read(0x28, addr, &data);
		data = (value == GPIO_LOW) ? data & (~mask) : data | mask;
		DEBUG("DATA:0x%02x\n", data);
		ace_reg_write(0x28, addr, data);
		return 0;
	}
	return -1;
}

int gpio_ex_get_value(uint32_t port)
{
	gpio_ex_init();
	if(port < 16)
	{
		uint8_t data, mask;
		uint8_t addr;

		mask = 1 << (port % 8);
		addr = (port < 8) ? 0x1e : 0x1f;

		ace_reg_read(0x28, addr, &data);
		DEBUG("DATA:0x%02x\n", data);
		return (data & mask) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}

/* For Performance Improvement */
int gpio_ex_get_static_value(uint32_t port)
{
	static int value[2] = {-1, -1};

	gpio_ex_init();
	if(port < 16)
	{
		uint8_t mask = 1 << (port % 8);
		int block = port/8;

		if(value[block] == -1)
		{
			uint8_t data, addr;
			addr = (port < 8) ? 0x1e : 0x1f;
			ace_reg_read(0x28, addr, &data);
			value[block] = data;
		}

		return (value[block] & mask) ? GPIO_HIGH : GPIO_LOW;
	}
	return -1;
}



#if !defined(FIRST_BOOT)
/*********************************
 * GPIO TEST CODE START
 *********************************/
static void print_gpio_pin_mux(int value)
{
	printf("Direction : %s\n", (value == GPIO_DIR_INPUT) ? "INPUT" :
						(value == GPIO_DIR_OUTPUT) ? "OUTPUT" : "XXX");
}

static void print_gpio_direction(int value)
{
	printf("Direction : %s\n", (value == GPIO_DIR_INPUT) ? "INPUT" :
						(value == GPIO_DIR_OUTPUT) ? "OUTPUT" : "XXX");
}

static void print_gpio_value(int value)
{
	printf("Data : %s\n", (value == GPIO_LOW) ? "LOW" :
						(value == GPIO_HIGH) ? "HIGH" : "XXX");
}

static int input_gpio_pin_mux(void)
{
	int c;

	while(1)
	{
		printf("Input pin mux - normal(0), gpio(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? 0 : 1;
}

static int input_gpio_direction(void)
{
	int c;

	while(1)
	{
		printf("Input direction - input(0), output(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? GPIO_DIR_INPUT : GPIO_DIR_OUTPUT;
}

static int input_gpio_value(void)
{
	int c;

	while(1)
	{
		printf("Input value - Low(0), High(1) : ");
		c = getchar();
		if(c == '0' || c == '1') break;
		printf("\n");
	}
	printf("%c\n", isprint((int)c) ? c : ' ');
	return (c == '0') ? GPIO_LOW : GPIO_HIGH;
}

static int gpio_cmd(int argc, char **argv)
{
	char name[32];
	int len, port;
	char c;

	do{
		printf("###### GPIO Test #######\n");
		printf("========================\n");
		printf(" 1. SetPinMux\n");
		printf(" 2. GetPinMux\n");
		printf(" 3. SetDirection\n");
		printf(" 4. GetDirection\n");
		printf(" 5. SetValue\n");
		printf(" 6. GetValue\n");
		printf("========================\n");
		printf(" A. ExSetDirection\n");
		printf(" S. ExGetDirection\n");
		printf(" D. ExSetValue\n");
		printf(" F. ExGetValue\n");
		printf("========================\n");
		printf(" X. Exit\n");
		while(1)
		{
			printf("Select : ");
			c = getchar();
			if(isalnum(c))
				break;
			printf("\n");
		}

		printf("%c\n", isprint((int)c) ? c : ' ');

		if(toupper(c) == 'X')
			break;

		while(1)
		{
			printf("Input pin number : ");
			len = gets(name);
			printf("\n");
			if(len > 0) break;
		}
		port = strtoul(name, NULL, 10);

		switch(toupper(c))
		{
			case '1': gpio_set_pin_mux(port, input_gpio_pin_mux()); break;
			case '2': print_gpio_pin_mux(gpio_get_pin_mux(port)); break;
			case '3': gpio_set_direction(port, input_gpio_direction()); break;
			case '4': print_gpio_direction(gpio_get_direction(port)); break;
			case '5': gpio_set_value(port, input_gpio_value()); break;
			case '6': print_gpio_value(gpio_get_value(port)); break;

			case 'A': gpio_ex_set_direction(port, input_gpio_direction()); break;
			case 'S': print_gpio_direction(gpio_ex_get_direction(port)); break;
			case 'D': gpio_ex_set_value(port, input_gpio_value()); break;
			case 'F': print_gpio_value(gpio_ex_get_value(port)); break;

			default: printf("unknown \n");
		}
	}while(1);
	return 0;
}

COMMAND(gpio, gpio_cmd, "GPIO Test", NULL);
#endif	/* if !defined(FIRST_BOOT) */
