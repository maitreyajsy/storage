/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/


#if (defined(CONFIG_SHADOW_ROM) && defined(CONFIG_ADDR_SWITCH_SHADOW))
	#if defined(SHADOW_ROM)
		#include <iboot_param.h>
		#define INCLUDE_ADDR_SWITCH_CODES 		1
		#define early_printf 	printf
	#else
		#if USE_2ND_ADDR_SWITCH /* 2nd boot, enable addr_switch */
			#include <stdio.h>
			#include <iboot_param.h>
			#define INCLUDE_ADDR_SWITCH_CODES 		1
		#else
			#define INCLUDE_ADDR_SWITCH_CODES 		0
		#endif
	#endif
#else
	#if (defined(CONFIG_BOOT_SINGLE) || defined(FIRST_BOOT)) && \
			((defined(CONFIG_ADDR_SWITCH) || USE_ADDR_SWITCH))
		#include <stdio.h>
		#define INCLUDE_ADDR_SWITCH_CODES 		1
	#else
		#define INCLUDE_ADDR_SWITCH_CODES 		0
	#endif
#endif

#if USE_2ND_ADDR_SWITCH && !defined(SHADOW_ROM)
	#define REG_WRITE_IBOOT_SAVE(addr, val) \
					do {\
						REG_WRITE(addr, val); \
						write_iboot_addr_switch_value((uint32_t)((ulong)addr),val);\
					}while(0)
#else
	#define REG_WRITE_IBOOT_SAVE(addr, val) 	REG_WRITE(addr,val)
#endif



#if 0
	/* It will generate address switch CMM for T32. Define USE_EARLY_PRINTF before you use it  */
#define REG_WRITE_ADDRSW(addr, val)	\
		do { \
			early_printf("D.S ASD:0x%08X %%LONG 0x%08X\n", (ulong)addr, (u32)val); \
			REG_WRITE_IBOOT_SAVE(addr, val);	\
		} while(0)
#else
#define REG_WRITE_ADDRSW(addr, val)		REG_WRITE_IBOOT_SAVE(addr, val)
#endif

//#define 	USE_BW_BALANCER
//#define 	USE_MPRO_STALL
#define 	USE_MEM_PROTECT

//address switch, qos reg cmn base address
#define 	LBUS_QOS_REG_CMN 		0XC880C000
#define 	GBUS_QOS_REG_CMN 		0xC8457000
#define 	EBUS_QOS_REG_CMN 		0xC8217000
#define 	GPU_QOS_REG_CMN 		0xC8AC0200
#define 	GFX_QOS_REG_CMN 		0xC8708200
#define 	CCO_QOS_REG_CMN 		0xC870D000
#define 	CPU_QOS_REG_CMN 		0xFD300000

//memory protect, qos reg btop base address
#define		LBUS_REG_BTOP_E00		  0xC880A000	  //(gpu0)	
#define		LBUS_REG_BTOP_E01		  0xC880A200	  //(gfx0)	
#define		LBUS_REG_BTOP_E02		  0xC880A400	  //(te)		
#define		LBUS_REG_BTOP_E03		  0xC880A600	  //(icod)	
#define		LBUS_REG_BTOP_E04		  0xC880A800	  //(venc0)	
#define		LBUS_REG_BTOP_E05		  0xC880AA00	  //(aud)		
#define		LBUS_REG_BTOP_E06		  0xC880AC00	  //(vip)		
#define		GBUS_REG_BTOP_E00		  0xC8455000	  //(gpu1)	
#define		GBUS_REG_BTOP_E01		  0xC8455200	  //(gfx1)	
#define		GBUS_REG_BTOP_E02		  0xC8455400	  //(vdec0_m0)
#define		GBUS_REG_BTOP_E03		  0xC8455600	  //(vdec0_m1)
#define		GBUS_REG_BTOP_E04		  0xC8455800	  //(vdec1_m0)
#define		GBUS_REG_BTOP_E05		  0xC8455A00	  //(vdec2_m0)
#define		GBUS_REG_BTOP_E06		  0xC8455C00	  //(osd0)	
#define		EBUS_REG_BTOP_E00		  0xC8213000	  //(vdec1_m1)
#define		EBUS_REG_BTOP_E01		  0xC8213200	  //(vdec2_m1)
#define		EBUS_REG_BTOP_E02		  0xC8213400	  //(osd1)	
#define		EBUS_REG_BTOP_E03		  0xC8213600	  //(vdm0)	
#define		EBUS_REG_BTOP_E04		  0xC8213800	  //(vdm1)	
#define		EBUS_REG_BTOP_E05		  0xC8213A00	  //(smx0)	
#define		EBUS_REG_BTOP_E06		  0xC8213C00	  //(smx1)	
#define		EBUS_REG_BTOP_E07		  0xC8213E00	  //(mcu)		
#define		EBUS_REG_BTOP_E08		  0xC8214000	  //(cvd)		
#define		EBUS_REG_BTOP_E09		  0xC8214200	  //(nd0)		
#define		EBUS_REG_BTOP_E10		  0xC8214400	  //(nd1)		
#define		EBUS_REG_BTOP_E11		  0xC8214600	  //(gsc0)	
#define		EBUS_REG_BTOP_E12		  0xC8214800	  //(gsc1)	
#define		EBUS_REG_BTOP_E13		  0xC8214A00	  //(vcp0)	
#define		EBUS_REG_BTOP_E14		  0xC8214C00	  //(vcp1)	
#define		EBUS_REG_BTOP_E15		  0xC8214E00	  //(sub)		

/*
 * macro bandwidth balancer 
 */

/* memory interleaving mode */
#define BWB_MODE_DIS 		0x0 	//diable
#define BWB_MODE_M0_M1 		0x4 	// m0 <-> m1 interleaving
#define BWB_MODE_M1_M2 		0x5 	// m1 <-> m2 interleaving
#define BWB_MODE_M0_M2 		0x6 	// m0 <-> m2 interleaving
#define BWB_MODE_M012 		0x7 	// m0 <-> m1 <-> m2 interleaving

/* memory interleaving unit */
#define BWB_UNIT_8K 		0x0
#define BWB_UNIT_4K 		0x1
#define BWB_UNIT_2K 		0x2
#define BWB_UNIT_1K 		0x3
#define BWB_UNIT_512B		0x4
#define BWB_UNIT_256B 		0x5
#define BWB_UNIT_128B		0x6
#define BWB_UNIT_64B		0x7

/* balacer offset mode */
#define BWB_OFFSET_DIS 		0x0 	//disable offset
#define BWB_OFFSET_M0 		0x4 	//offset for M0 area
#define BWB_OFFSET_M1 		0x5 	//offset for M1 area
#define BWB_OFFSET_M2 		0x6 	//offset for M2 area

#define MAX_ADDR_SWITCH 	16
#define MAX_ADDR_SWITCH_IDX (MAX_ADDR_SWITCH -1)

#define MAX_BWB 			16
#define MAX_BWB_IDX 		(MAX_BWB -1)

#define MAX_MPRO			2
#define MAX_MPRO_IDX		(MAX_MPRO -1)

struct addr_switch
{
	uint16_t  	asw_start;
	uint16_t 	asw_end;
	uint16_t 	asw_offset;
};

struct bw_balancer
{
	uint16_t 	bwb_start;
	uint16_t 	bwb_end;
	uint16_t 	bwb_mode;
	uint16_t 	bwb_unit;
	uint16_t 	bwb_offset;
	uint16_t 	bwb_offset_mode;
};

#ifdef USE_MEM_PROTECT
struct mem_protect
{
	uint32_t 	mpro_start;
	uint32_t 	mpro_end;
};
#endif
	

const ulong asw_base[] = 
{
	LBUS_QOS_REG_CMN + 0x80,// 0
	GBUS_QOS_REG_CMN + 0x80,// 1
	EBUS_QOS_REG_CMN + 0x80,// 2
	GPU_QOS_REG_CMN  + 0x80,// 3
	GFX_QOS_REG_CMN  + 0x80,// 4
	CCO_QOS_REG_CMN  + 0x80,// 5
	CPU_QOS_REG_CMN  + 0x20,// 6
};

const ulong bwb_base[] =
{
	LBUS_QOS_REG_CMN + 0x100,// 0
	GBUS_QOS_REG_CMN + 0x100,// 1
	EBUS_QOS_REG_CMN + 0x100,// 2
	GPU_QOS_REG_CMN  + 0x100,// 3
	GFX_QOS_REG_CMN  + 0x100,// 4
	CCO_QOS_REG_CMN  + 0x100,// 5
	CPU_QOS_REG_CMN  + 0x1C4,// 6
};

#ifdef USE_MEM_PROTECT
const ulong mpro_base[] =
{
	//LBUS_REG_BTOP_E00 + 0x60, //(gpu0) : use kernel memory
	//LBUS_REG_BTOP_E01 + 0x60, //(gfx0)	
	LBUS_REG_BTOP_E02 + 0x60, //(te)		
	LBUS_REG_BTOP_E03 + 0x60, //(icod)	
	LBUS_REG_BTOP_E04 + 0x60, //(venc0)	
	LBUS_REG_BTOP_E05 + 0x60, //(aud)		
	//LBUS_REG_BTOP_E06 + 0x60, //(vip)	 : use kernel memory
	//GBUS_REG_BTOP_E00 + 0x60, //(gpu1) : use kernel memory
	//GBUS_REG_BTOP_E01 + 0x60, //(gfx1) : use kernel memory
	GBUS_REG_BTOP_E02 + 0x60, //(vdec0_m0)
	GBUS_REG_BTOP_E03 + 0x60, //(vdec0_m1)
	GBUS_REG_BTOP_E04 + 0x60, //(vdec1_m0)
	GBUS_REG_BTOP_E05 + 0x60, //(vdec2_m0)
	GBUS_REG_BTOP_E06 + 0x60, //(osd0)	
	EBUS_REG_BTOP_E00 + 0x60, //(vdec1_m1)
	EBUS_REG_BTOP_E01 + 0x60, //(vdec2_m1)
	EBUS_REG_BTOP_E02 + 0x60, //(osd1)	
	EBUS_REG_BTOP_E03 + 0x60, //(vdm0)	
	EBUS_REG_BTOP_E04 + 0x60, //(vdm1)	
	EBUS_REG_BTOP_E05 + 0x60, //(smx0)	
	EBUS_REG_BTOP_E06 + 0x60, //(smx1)	
	EBUS_REG_BTOP_E07 + 0x60, //(mcu)		
	//EBUS_REG_BTOP_E08 + 0x60, //(cvd) : use kernel memory	(hdmi)
	EBUS_REG_BTOP_E09 + 0x60, //(nd0)		
	EBUS_REG_BTOP_E10 + 0x60, //(nd1)		
	EBUS_REG_BTOP_E11 + 0x60, //(gsc0)	
	EBUS_REG_BTOP_E12 + 0x60, //(gsc1)	
	EBUS_REG_BTOP_E13 + 0x60, //(vcp0)	
	EBUS_REG_BTOP_E14 + 0x60, //(vcp1)	
	EBUS_REG_BTOP_E15 + 0x60, //(sub)		
};
#endif

/////////////////////////////////////////////////////////////////////////
//////////////////////////// H15 Bx addr map ////////////////////////////

const struct addr_switch asw_bx[] =
{
#if 0
	//8th map + BWB
	{ 0x000, 0x017, 0x000},//0x0 0000 0000 ~ 0x0 17FF FFFF => 0x0 0000 0000 ~ 0x0 17FF FFFF : 384MB
	{ 0x018, 0x02F, 0x068},//0x0 1800 0000 ~ 0x0 2FFF FFFF => 0x0 8000 0000 ~ 0x0 97FF FFFF : 384MB
	{ 0x030, 0x041, 0x1E8},//0x0 3000 0000 ~ 0x0 41FF FFFF => 0x0 1800 0000 ~ 0x0 29FF FFFF : 288MB
	{ 0x042, 0x049, 0x056},//0x0 4200 0000 ~ 0x0 49FF FFFF => 0x0 9800 0000 ~ 0x0 9FFF FFFF : 128MB
	{ 0x04A, 0x069, 0x056},//0x0 4A00 0000 ~ 0x0 69FF FFFF => 0x0 A000 0000 ~ 0x0 BFFF FFFF : 512MB
	{ 0x06A, 0x07F, 0x000},//0x0 6A00 0000 ~ 0x0 7FFF FFFF => 0x0 6A00 0000 ~ 0x0 7FFF FFFF : 352MB
	{ 0x080, 0x08F, 0x080},//0x0 8000 0000 ~ 0x0 8FFF FFFF => 0x1 0000 0000 ~ 0x1 0FFF FFFF : 256MB
	{ 0x090, 0x09D, 0x080},//0x0 9000 0000 ~ 0x0 9DFF FFFF => 0x1 1000 0000 ~ 0x1 1DFF FFFF : 244MB
	{ 0x09E, 0x0BF, 0x080},//0x0 9E00 0000 ~ 0x0 BFFF FFFF => 0x1 1E00 0000 ~ 0x1 3FFF FFFF : 544MB
	{ 0x0C0, 0x0FF, 0x000},//0x0 C000 0000 ~ 0x0 FFFF FFFF => 0x0 C000 0000 ~ 0x0 FFFF FFFF : 1024MB
	{ 0x100, 0x13F, 0x140},//0x1 0000 0000 ~ 0x1 3FFF FFFF => 0x0 4000 0000 ~ 0x0 7FFF FFFF : 1024MB
	{ 0x140, 0x17F, 0x000},//0x1 4000 0000 ~ 0x1 7FFF FFFF => 0x1 4000 0000 ~ 0x1 7FFF FFFF : 1024MB
#endif

#if 0
	//6th map
	//start, end,   offset, logic addr 						 ,phy addr
	{ 0x000, 0x01F, 0x000},//0x0 0000 0000 ~ 0x0 1FFF FFFF => 0x0 0000 0000 ~ 0x0 1FFF FFFF : 512MB
	{ 0x020, 0x032, 0x060},//0x0 2000 0000 ~ 0x0 32FF FFFF => 0x0 8000 0000 ~ 0x0 92FF FFFF : 304MB
	{ 0x033, 0x049, 0x0CD},//0x0 3300 0000 ~ 0x0 49FF FFFF => 0x1 0000 0000 ~ 0x1 16FF FFFF : 368MB
	{ 0x04A, 0x069, 0x1D6},//0x0 4A00 0000 ~ 0x0 69FF FFFF => 0x0 2000 0000 ~ 0x0 3FFF FFFF : 512MB
	{ 0x06A, 0x07A, 0x029},//0x0 6A00 0000 ~ 0x0 7AFF FFFF => 0x0 9300 0000 ~ 0x0 A3FF FFFF : 272MB
	{ 0x07B, 0x096, 0x029},//0x0 7B00 0000 ~ 0x0 96FF FFFF => 0x0 A400 0000 ~ 0x0 BFFF FFFF : 448MB
	{ 0x097, 0x09D, 0x080},//0x0 9700 0000 ~ 0x0 9DFF FFFF => 0x1 1700 0000 ~ 0x1 1DFF FFFF : 112MB
	{ 0x09E, 0x0BF, 0x080},//0x0 9E00 0000 ~ 0x0 BFFF FFFF => 0x1 1E00 0000 ~ 0x1 3FFF FFFF : 544MB
	{ 0x0C0, 0x0FF, 0x000},//0x0 C000 0000 ~ 0x0 FFFF FFFF => 0x0 C000 0000 ~ 0x0 FFFF FFFF : 1024MB
	{ 0x100, 0x13F, 0x140},//0x1 0000 0000 ~ 0x1 3FFF FFFF => 0x0 4000 0000 ~ 0x0 7FFF FFFF : 1024MB
	{ 0x140, 0x17F, 0x000},//0x1 4000 0000 ~ 0x1 7FFF FFFF => 0x1 4000 0000 ~ 0x1 7FFF FFFF : 1024MB
#endif

#if 0
	//8th map
	{ 0x000, 0x029, 0x000},//0x0 0000 0000 ~ 0x0 29FF FFFF => 0x0 0000 0000 ~ 0x0 29FF FFFF : 672MB
	{ 0x02A, 0x041, 0x056},//0x0 2A00 0000 ~ 0x0 41FF FFFF => 0x0 8000 0000 ~ 0x0 97FF FFFF : 384MB
	{ 0x042, 0x049, 0x056},//0x0 4200 0000 ~ 0x0 49FF FFFF => 0x0 9800 0000 ~ 0x0 9FFF FFFF : 128MB
	{ 0x04A, 0x069, 0x056},//0x0 4A00 0000 ~ 0x0 69FF FFFF => 0x0 A000 0000 ~ 0x0 BFFF FFFF : 512MB
	{ 0x06A, 0x07F, 0x000},//0x0 6A00 0000 ~ 0x0 7FFF FFFF => 0x0 6A00 0000 ~ 0x0 7FFF FFFF : 352MB
	{ 0x080, 0x08F, 0x080},//0x0 8000 0000 ~ 0x0 8FFF FFFF => 0x1 0000 0000 ~ 0x1 0FFF FFFF : 256MB
	{ 0x090, 0x09D, 0x080},//0x0 9000 0000 ~ 0x0 9DFF FFFF => 0x1 1000 0000 ~ 0x1 1DFF FFFF : 244MB
	{ 0x09E, 0x0BF, 0x080},//0x0 9E00 0000 ~ 0x0 BFFF FFFF => 0x1 1E00 0000 ~ 0x1 3FFF FFFF : 544MB
	{ 0x0C0, 0x0FF, 0x000},//0x0 C000 0000 ~ 0x0 FFFF FFFF => 0x0 C000 0000 ~ 0x0 FFFF FFFF : 1024MB
	{ 0x100, 0x13F, 0x140},//0x1 0000 0000 ~ 0x1 3FFF FFFF => 0x0 4000 0000 ~ 0x0 7FFF FFFF : 1024MB
	{ 0x140, 0x17F, 0x000},//0x1 4000 0000 ~ 0x1 7FFF FFFF => 0x1 4000 0000 ~ 0x1 7FFF FFFF : 1024MB
#endif

#if 0
	//9th 1 map
	{ 0x000, 0x02D, 0x000},//0x0 0000 0000 ~ 0x0 2DFF FFFF => 0x0 0000 0000 ~ 0x0 2DFF FFFF : 736MB
	{ 0x02E, 0x045, 0x052},//0x0 2E00 0000 ~ 0x0 45FF FFFF => 0x0 8000 0000 ~ 0x0 97FF FFFF : 384MB
	{ 0x046, 0x04D, 0x052},//0x0 4600 0000 ~ 0x0 4DFF FFFF => 0x0 9800 0000 ~ 0x0 9FFF FFFF : 128MB
	{ 0x04E, 0x06D, 0x052},//0x0 4E00 0000 ~ 0x0 6DFF FFFF => 0x0 A000 0000 ~ 0x0 BFFF FFFF : 512MB
	{ 0x06E, 0x07F, 0x000},//0x0 6E00 0000 ~ 0x0 7FFF FFFF => 0x0 6E00 0000 ~ 0x0 7FFF FFFF : 288MB
	{ 0x080, 0x091, 0x080},//0x0 8000 0000 ~ 0x0 91FF FFFF => 0x1 0000 0000 ~ 0x1 11FF FFFF : 288MB
	{ 0x092, 0x09F, 0x080},//0x0 9200 0000 ~ 0x0 9FFF FFFF => 0x1 1200 0000 ~ 0x1 1FFF FFFF : 244MB
	{ 0x0A0, 0x0BF, 0x080},//0x0 A000 0000 ~ 0x0 BFFF FFFF => 0x1 2000 0000 ~ 0x1 3FFF FFFF : 512MB
	{ 0x0C0, 0x0FF, 0x000},//0x0 C000 0000 ~ 0x0 FFFF FFFF => 0x0 C000 0000 ~ 0x0 FFFF FFFF : 1024MB
	{ 0x100, 0x13F, 0x140},//0x1 0000 0000 ~ 0x1 3FFF FFFF => 0x0 4000 0000 ~ 0x0 7FFF FFFF : 1024MB
	{ 0x140, 0x17F, 0x000},//0x1 4000 0000 ~ 0x1 7FFF FFFF => 0x1 4000 0000 ~ 0x1 7FFF FFFF : 1024MB
#endif

#if 1
	//9th 2 map, 9th 3 map
	{ 0x000, 0x02D, 0x000},//0x0 0000 0000 ~ 0x0 2DFF FFFF => 0x0 0000 0000 ~ 0x0 2DFF FFFF : 736MB
	{ 0x02E, 0x04D, 0x052},//0x0 2E00 0000 ~ 0x0 4DFF FFFF => 0x0 8000 0000 ~ 0x0 9FFF FFFF : 512MB
	{ 0x04E, 0x06D, 0x052},//0x0 4E00 0000 ~ 0x0 6DFF FFFF => 0x0 A000 0000 ~ 0x0 BFFF FFFF : 512MB
	{ 0x06E, 0x07F, 0x000},//0x0 6E00 0000 ~ 0x0 7FFF FFFF => 0x0 6E00 0000 ~ 0x0 7FFF FFFF : 288MB
	{ 0x080, 0x092, 0x080},//0x0 8000 0000 ~ 0x0 92FF FFFF => 0x1 0000 0000 ~ 0x1 12FF FFFF : 304MB
	{ 0x093, 0x09F, 0x080},//0x0 9300 0000 ~ 0x0 9FFF FFFF => 0x1 1300 0000 ~ 0x1 1FFF FFFF : 208MB
	{ 0x0A0, 0x0BF, 0x080},//0x0 A000 0000 ~ 0x0 BFFF FFFF => 0x1 2000 0000 ~ 0x1 3FFF FFFF : 512MB
	{ 0x0C0, 0x0FF, 0x000},//0x0 C000 0000 ~ 0x0 FFFF FFFF => 0x0 C000 0000 ~ 0x0 FFFF FFFF : 1024MB
	{ 0x100, 0x13F, 0x140},//0x1 0000 0000 ~ 0x1 3FFF FFFF => 0x0 4000 0000 ~ 0x0 7FFF FFFF : 1024MB
	{ 0x140, 0x17F, 0x000},//0x1 4000 0000 ~ 0x1 7FFF FFFF => 0x1 4000 0000 ~ 0x1 7FFF FFFF : 1024MB
#endif

};


const struct bw_balancer bwb_bx[] =
{
	//8th map + BWB
	{ 0x00, 0x17, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},//m0 phy 0x0 ~ 0x17FF FFFF & m1 phy 0x8000 0000 ~ 0x9800 0000
};

const struct mem_protect mpro_bx[] = 
{
#if 0//6th
	{ 0x000000, 0x01FFFF}, //0x0 0000 0000 ~ 0x0 1FFF FFFF
	{ 0x040000, 0x092FFF}, //0x0 4000 0000 ~ 0x0 92FF FFFF
#endif

#if 0//8th or 8th + BWB
	{ 0x000000, 0x069FFF}, //0x0 0000 0000 ~ 0x0 69FF FFFF
	{ 0x080000, 0x097FFF}, //0x0 8000 0000 ~ 0x0 97FF FFFF
#endif

#if 0//9th 1
	{ 0x000000, 0x06DFFF}, //0x0 0000 0000 ~ 0x0 6DFF FFFF
	{ 0x080000, 0x097FFF}, //0x0 8000 0000 ~ 0x0 97FF FFFF
#endif

#if 0//9th 2
	{ 0x000000, 0x06DFFF}, //0x0 0000 0000 ~ 0x0 6DFF FFFF
	{ 0x080000, 0x09FFFF}, //0x0 8000 0000 ~ 0x0 9FFF FFFF
#endif

#if 1//9th 3
	{ 0x000000, 0x06DFFF}, //0x0 0000 0000 ~ 0x0 6DFF FFFF
	{ 0x080000, 0x09CFFF}, //0x0 8000 0000 ~ 0x0 9CFF FFFF
#endif
};

static const int asw_bx_cnt = ARRAY_SIZE(asw_bx);
static const int bwb_bx_cnt = ARRAY_SIZE(bwb_bx);
static const int mpro_bx_cnt = ARRAY_SIZE(mpro_bx);

/////////////////////////////////////////////////////////////////////////
//////////////////////////// H15 Cx addr map ////////////////////////////

const struct addr_switch asw_cx[] =
{
#if 1
	//9th 2 map, 9th 3 map
	{ 0x000, 0x02D, 0x000},//0x0 0000 0000 ~ 0x0 2DFF FFFF => 0x0 0000 0000 ~ 0x0 2DFF FFFF : 736MB
	{ 0x02E, 0x04D, 0x052},//0x0 2E00 0000 ~ 0x0 4DFF FFFF => 0x0 8000 0000 ~ 0x0 9FFF FFFF : 512MB
	{ 0x04E, 0x06D, 0x052},//0x0 4E00 0000 ~ 0x0 6DFF FFFF => 0x0 A000 0000 ~ 0x0 BFFF FFFF : 512MB
	{ 0x06E, 0x07F, 0x000},//0x0 6E00 0000 ~ 0x0 7FFF FFFF => 0x0 6E00 0000 ~ 0x0 7FFF FFFF : 288MB
	{ 0x080, 0x092, 0x080},//0x0 8000 0000 ~ 0x0 92FF FFFF => 0x1 0000 0000 ~ 0x1 12FF FFFF : 304MB
	{ 0x093, 0x09F, 0x080},//0x0 9300 0000 ~ 0x0 9FFF FFFF => 0x1 1300 0000 ~ 0x1 1FFF FFFF : 208MB
	{ 0x0A0, 0x0BF, 0x080},//0x0 A000 0000 ~ 0x0 BFFF FFFF => 0x1 2000 0000 ~ 0x1 3FFF FFFF : 512MB
	{ 0x0C0, 0x0FF, 0x000},//0x0 C000 0000 ~ 0x0 FFFF FFFF => 0x0 C000 0000 ~ 0x0 FFFF FFFF : 1024MB
	{ 0x100, 0x13F, 0x140},//0x1 0000 0000 ~ 0x1 3FFF FFFF => 0x0 4000 0000 ~ 0x0 7FFF FFFF : 1024MB
	{ 0x140, 0x17F, 0x000},//0x1 4000 0000 ~ 0x1 7FFF FFFF => 0x1 4000 0000 ~ 0x1 7FFF FFFF : 1024MB
#endif

};


const struct bw_balancer bwb_cx[] =
{
	//8th map + BWB
	{ 0x00, 0x17, BWB_MODE_M0_M1, BWB_UNIT_4K, 0, 0},//m0 phy 0x0 ~ 0x17FF FFFF & m1 phy 0x8000 0000 ~ 0x9800 0000
};

const struct mem_protect mpro_cx[] = 
{
#if 1//9th 3
	{ 0x000000, 0x06DFFF}, //0x0 0000 0000 ~ 0x0 6DFF FFFF
	{ 0x080000, 0x09CFFF}, //0x0 8000 0000 ~ 0x0 9CFF FFFF
#endif
};

static const int asw_cx_cnt = ARRAY_SIZE(asw_cx);
static const int bwb_cx_cnt = ARRAY_SIZE(bwb_cx);
static const int mpro_cx_cnt = ARRAY_SIZE(mpro_cx);


///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

#if INCLUDE_ADDR_SWITCH_CODES
void set_addr_switch(void)
{
	int i,j;
	u32 ctr0;
	u32 ctr1;
	u32 ex_offset;
	volatile u32 *ctrl_reg;

	struct addr_switch	*p_asw;
	struct bw_balancer	*p_bwb;
	struct mem_protect	*p_mpro;

	int asw_cnt;
	int bwb_cnt;
	int mpro_cnt;

#if USE_2ND_ADDR_SWITCH && !defined(SHADOW_ROM)
	init_iboot_addr_switch();
	//early_printf("init_iboot_addr_switch()\n");
#endif

	//early_printf("do set_addr_switch()\n");

	/* select addr_switch map */
	if(1)// H15 Bx map
	{
		p_asw	= (struct addr_switch *)asw_bx;
		p_bwb	= (struct bw_balancer *)bwb_bx;
		p_mpro	= (struct mem_protect *)mpro_bx;
		
		asw_cnt = asw_bx_cnt;
		bwb_cnt = bwb_bx_cnt;
		mpro_cnt = mpro_bx_cnt;

		STATIC_ASSERT((asw_bx_cnt <= MAX_ADDR_SWITCH), "Over max address switch slot");
		STATIC_ASSERT((bwb_bx_cnt <= MAX_BWB), "Over max bw balancer slot");
		STATIC_ASSERT((mpro_bx_cnt <= MAX_MPRO), "Over memory protector slot");
		early_printf("[Bx Map]\n");
	}
	else// H15 Cx map(== Bx)
	{
		p_asw	= (struct addr_switch *)asw_cx;
		p_bwb	= (struct bw_balancer *)bwb_cx;
		p_mpro	= (struct mem_protect *)mpro_cx;
		
		asw_cnt = asw_cx_cnt;
		bwb_cnt = bwb_cx_cnt;
		mpro_cnt = mpro_cx_cnt;

		STATIC_ASSERT((asw_cx_cnt <= MAX_ADDR_SWITCH), "Over max address switch slot");
		STATIC_ASSERT((bwb_cx_cnt <= MAX_BWB), "Over max bw balancer slot");
		STATIC_ASSERT((mpro_cx_cnt <= MAX_MPRO), "Over memory protector slot");
		early_printf("[Cx Map]\n");
	}

	for(j = 0; j < ARRAY_SIZE(asw_base); j++)
	{
		ctrl_reg = (volatile u32 *)asw_base[j];

		for(i = 0; i < asw_cnt; i++)
		{
			ex_offset = 0;
			/* ==exception== */
			if(j == 4)//GFX_QOS_REG_CMN
			{
				//if logic L,G,E -> phy E, then E phy address [32:31] 10 -> 11
				if(((p_asw[i].asw_start + p_asw[i].asw_offset) & 0x1ff) >= 0x100)
						ex_offset = 0x80;
			}
			else if(j == 5)//CCO_QOS_REG_CMN
			{
				//if logic L,G,E -> phy L, then L phy address [32:31] 00 -> 11
				if(((p_asw[i].asw_start + p_asw[i].asw_offset) & 0x1ff) < 0x080)
						ex_offset = 0x180;
			}
			
			ctr0 = (p_asw[i].asw_start & 0x1ff) << 16;
			ctr0 |= (p_asw[i].asw_end & 0x1ff);

			ctr1 = ((p_asw[i].asw_offset & 0x1ff) + ex_offset) & 0x1ff;
			ctr1 |= 1 << 28;

			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			//early_printf("D.S ASD:0x%08X %%LONG 0x%08X", ctrl_reg, ctr0);
			//early_printf("\t;0x%03x ~ 0x%03x -> 0x%03x\n" 
			//		, p_asw[i].asw_start, p_asw[i].asw_end 
			//		, ((p_asw[i].asw_start + p_asw[i].asw_offset)&0x1ff));
			ctrl_reg++;

			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			//early_printf("D.S ASD:0x%08X %%LONG 0x%08X\n", ctrl_reg, ctr1);
			ctrl_reg++;

		}
		//early_printf("\n\n");
	}

#ifdef USE_BW_BALANCER

	for(j = 0; j < ARRAY_SIZE(bwb_base); j++)
	{
		ctrl_reg = (volatile u32 *)bwb_base[j];

		for(i = 0; i < bwb_cnt; i++)
		{
			ctr0 =  (p_bwb[i].bwb_start & 0x7f) << 8;
			ctr0 |= (p_bwb[i].bwb_end & 0x7f) << 0;
			ctr0 |= (p_bwb[i].bwb_mode & 0x7) << 28;
			ctr0 |= (p_bwb[i].bwb_unit & 0x7) << 24;

			ctr1 =  (p_bwb[i].bwb_offset & 0x1ff) << 0;
			ctr1 |= (p_bwb[i].bwb_offset_mode & 0x7) << 28;
			
			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			ctrl_reg++;
			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			ctrl_reg++;
		}

	}
#endif

#ifdef USE_MEM_PROTECT
	for(j = 0; j < ARRAY_SIZE(mpro_base); j++)
	{
		ctrl_reg = (volatile u32 *)mpro_base[j];

		for(i = 0; i < mpro_cnt; i++)
		{
			ctr0 = p_mpro[i].mpro_start & 0x1fffff;
			ctr0 |= (1<<28); //enable
#ifdef 	USE_MPRO_STALL
			ctr0 |= (1<<24);
#endif
			ctr1 = p_mpro[i].mpro_end & 0x1fffff;

			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			ctrl_reg++;
			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			ctrl_reg++;
		}
	}
#endif

}
#else

#ifndef TODO
#define DO_PRAGMA(x) _Pragma (#x)
#define TODO(x) DO_PRAGMA(message ("TODO - " #x))
#endif

TODO (dummy_addr_switch)
void set_addr_switch(void){}
#endif//#if INCLUDE_ADDR_SWITCH_CODES


#if (!defined(SHADOW_ROM)) && (!defined(FIRST_BOOT))
#include <stdio.h>
#include <string.h>
#include <command.h>
#include <env.h>
static int addr_switch_menu(int argc, char **argv)
{
#ifdef USE_MEM_PROTECT
	int i,j;
	u32 ctr0;
	u32 ctr1;
	volatile u32 *ctrl_reg;
	ulong s0_start, s0_end, s1_start, s1_end;
	struct mem_protect mpro[2] = {
		{0, 0},
		{0, 0},};

	if(argc < 5)
	{
		command_usuage(argv[0]);
		return -1;
	}

    s0_start = strtoul(argv[1], NULL,0);
    s0_end = strtoul(argv[2], NULL,0);
    s1_start = strtoul(argv[3], NULL,0);
    s1_end = strtoul(argv[4], NULL,0);

	mpro[0].mpro_start = s0_start >> 12;
	mpro[0].mpro_end = s0_end >> 12;
	mpro[1].mpro_start = s1_start >> 12;
	mpro[1].mpro_end = s1_end >> 12;

	printf("set mpro0: 0x%x~0x%x, mpro1: 0x%x~0x%x(unit : 4k)\n", mpro[0].mpro_start
													 , mpro[0].mpro_end
													 , mpro[1].mpro_start
													 , mpro[1].mpro_end);

	for(j = 0; j < ARRAY_SIZE(mpro_base); j++)
	{
		ctrl_reg = (volatile u32 *)mpro_base[j];

		for(i = 0; i < 2; i++)
		{
			ctr0 = mpro[i].mpro_start & 0x1fffff;
			ctr0 |= (1<<28); //enable
#ifdef 	USE_MPRO_STALL
			ctr0 |= (1<<24);
#endif
			ctr1 = mpro[i].mpro_end & 0x1fffff;

			REG_WRITE_ADDRSW(ctrl_reg, ctr0);
			ctrl_reg++;
			REG_WRITE_ADDRSW(ctrl_reg, ctr1);
			ctrl_reg++;
		}
	}

#else
	printf("not support this command!\n");
#endif

	return 0;
}
COMMAND(adswitch, addr_switch_menu, "setup addr switch range"
			, "slot0_start_add slot0_end_add slot1_start_add slot1_end_add\n"
			"ex> adswitch 0x0 0x6DFFFFFF 0x80000000 0x9FFFFFFF");
#endif
