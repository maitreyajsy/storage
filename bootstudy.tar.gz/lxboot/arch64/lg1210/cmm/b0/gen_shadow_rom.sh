
rm -rf *.lst *.h

../../../../tools/convert_cmm H15_B0_TOP.cmm top_b0.h
../../../../tools/convert_cmm H15_M0_900.cmm lm_b0.h
../../../../tools/convert_cmm H15_M1_900.cmm gm_b0.h
../../../../tools/convert_cmm H15_M2_900.cmm em_b0.h

../../../../tools/convert_cmm ../common/BUS_GATING_EN.cmm 			bus_gating_b0.h
../../../../tools/convert_cmm ../common/BUS_MANAGER.cmm 			bus_manager_b0.h

../../../../tools/convert_cmm ./instant_boot/H15_M0_self_refresh_exit1.cmm lm_exit_b0.h
../../../../tools/convert_cmm ./instant_boot/H15_M1_self_refresh_exit1.cmm gm_exit_b0.h
../../../../tools/convert_cmm ./instant_boot/H15_M2_self_refresh_exit1.cmm em_exit_b0.h

../../../../tools/convert_cmm ./instant_boot/H15_M0_self_refresh_exit2.cmm lm_exit_post_b0.h
../../../../tools/convert_cmm ./instant_boot/H15_M1_self_refresh_exit2.cmm gm_exit_post_b0.h
../../../../tools/convert_cmm ./instant_boot/H15_M2_self_refresh_exit2.cmm em_exit_post_b0.h

../../../../tools/convert_cmm H15_B0_TOP_POST.cmm top_post_b0.h

#cp ./*.h ../../shadow_rom/include/
cp ./*.h ../../header/shadow/soc_setup_header/

rm -rf *.lst *.h
