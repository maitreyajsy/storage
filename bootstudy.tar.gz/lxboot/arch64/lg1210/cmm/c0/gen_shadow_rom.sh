
rm -rf *.lst *.h

../../../../tools/convert_cmm ./ddr4_sk/H15_B0_TOP.cmm		top_ddr4_sk.h
../../../../tools/convert_cmm ./ddr4_sk/H15_M0_1152.cmm		lm_ddr4_sk.h
../../../../tools/convert_cmm ./ddr4_sk/H15_M1_1152.cmm		gm_ddr4_sk.h
../../../../tools/convert_cmm ./ddr4_sk/H15_M2_1152.cmm		em_ddr4_sk.h

../../../../tools/convert_cmm ../common/BUS_GATING_EN.cmm 	bus_gating_ddr4_sk.h
../../../../tools/convert_cmm ../common/BUS_MANAGER.cmm 	bus_manager_ddr4_sk.h

../../../../tools/convert_cmm ./ddr4_sk/instant_boot/H15_M0_self_refresh_exit1.cmm lm_exit_ddr4_sk.h
../../../../tools/convert_cmm ./ddr4_sk/instant_boot/H15_M1_self_refresh_exit1.cmm gm_exit_ddr4_sk.h
../../../../tools/convert_cmm ./ddr4_sk/instant_boot/H15_M2_self_refresh_exit1.cmm em_exit_ddr4_sk.h

../../../../tools/convert_cmm ./ddr4_sk/instant_boot/H15_M0_self_refresh_exit2.cmm lm_exit_post_ddr4_sk.h
../../../../tools/convert_cmm ./ddr4_sk/instant_boot/H15_M1_self_refresh_exit2.cmm gm_exit_post_ddr4_sk.h
../../../../tools/convert_cmm ./ddr4_sk/instant_boot/H15_M2_self_refresh_exit2.cmm em_exit_post_ddr4_sk.h

../../../../tools/convert_cmm ./ddr4_sk/H15_B0_TOP_POST.cmm		top_post_ddr4_sk.h

#cp ./*.h ../../shadow_rom/include/
cp ./*.h ../../header/shadow/soc_setup_header/

rm -rf *.lst *.h
