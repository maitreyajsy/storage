
rm -rf *.lst *.h

../../../../tools/convert_cmm H15_A0_TOP.cmm top.lst
../../../../tools/convert_cmm H15_M0_936.cmm m0.lst
../../../../tools/convert_cmm H15_M1_936.cmm m1.lst
../../../../tools/convert_cmm H15_M2_936.cmm m2.lst

../../../../tools/convert_cmm ../BUS_GATING_EN.cmm 			bus_gating.lst
../../../../tools/convert_cmm ../BUS_MANAGER.cmm 			bus_manager.lst
../../../../tools/convert_cmm ../H15_ADDR_SWITCH_8th.cmm 	addr_switch.lst

cat top.lst > ddrc.lst
cat m0.lst >> ddrc.lst
cat m1.lst >> ddrc.lst
cat m2.lst >> ddrc.lst
cat bus_gating.lst >> ddrc.lst
cat bus_manager.lst >> ddrc.lst
cat addr_switch.lst >> ddrc.lst

cp ./ddrc.lst ../../header/system/a0/

rm -rf *.lst *.h
