
rm -rf *.lst *.h

../../../../tools/convert_cmm H15_A0_TOP.cmm top.h
../../../../tools/convert_cmm H15_M0_936.cmm lm.h
../../../../tools/convert_cmm H15_M1_936.cmm gm.h
../../../../tools/convert_cmm H15_M2_936.cmm em.h

../../../../tools/convert_cmm ../common/BUS_GATING_EN.cmm 			bus_gating.h
../../../../tools/convert_cmm ../common/BUS_MANAGER.cmm 			bus_manager.h

../../../../tools/convert_cmm ./instant_boot/H15_M0_self_refresh_exit.cmm lm_exit.h
../../../../tools/convert_cmm ./instant_boot/H15_M1_self_refresh_exit.cmm gm_exit.h
../../../../tools/convert_cmm ./instant_boot/H15_M2_self_refresh_exit.cmm em_exit.h

../../../../tools/convert_cmm ./instant_boot/dummy.cmm lm_exit_post.h
../../../../tools/convert_cmm ./instant_boot/dummy.cmm gm_exit_post.h
../../../../tools/convert_cmm ./instant_boot/dummy.cmm em_exit_post.h

../../../../tools/convert_cmm H15_A0_TOP_POST.cmm top_post.h

#cp ./*.h ../../shadow_rom/include/
cp ./*.h ../../header/shadow/soc_setup_header/

rm -rf *.lst *.h
