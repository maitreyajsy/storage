/****************************************************************************************
 *   SIC Lab., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/
#include <types.h>
#include <string.h>
#include <timer.h>
#include <arch/usb_top_regs.h>
#include <gpio.h>

USB2_CTRL_REG_T usb2_regs[] = {
	{ (USB2_PHY_CTRL *)USB2_PHY_CTRL0, (USB2_HOST_CTRL *)USB2_HOST_CTRL0}, // USB2_0
	{ (USB2_PHY_CTRL *)USB2_PHY_CTRL1, (USB2_HOST_CTRL *)USB2_HOST_CTRL1 } // USB2_1
};

USB3_CTRL_REG_T usb3_regs[] = {
	{ (USB3_PHY_CTRL *)USB3_PHY_CTRL0, (USB3_HOST_CTRL *)USB3_HOST_CTRL0 }, // USB3_0
	{ (USB3_PHY_CTRL *)USB3_PHY_CTRL1, (USB3_HOST_CTRL *)USB3_HOST_CTRL1 } // USB3_1
};

#define USB2_MAX	(sizeof(usb2_regs)/sizeof(usb2_regs[0]))
#define USB3_MAX	(sizeof(usb3_regs)/sizeof(usb3_regs[0]))

#define RX_EQ_01	0x100
#define RX_EQ_02	0x200
#define RX_EQ_03	0x300
#define RX_EQ_04	0x400
#define RX_EQ_05	0x500

#define CR_ACK		0x1
#define CR_NAK		0x0

#define RX_OVRD_IN_HI	0x1006
#define RX_OVRD_IN_LO	0x1005

#define RX_EQ_OVRD_MASK		(1 << 11)	//RX_OVRD_IN_HI[11] Override enable for rx_eq
#define RX_EQ_MASK			(7 << 8)	//RX_OVRD_IN_HI[10:8] Override value for rx_eq
#define RX_EQ_EN_OVRD_MASK	(1 << 7)	//RX_OVRD_IN_HI[7] Override value for rx_eq_en
#define RX_EQ_EN_MASK		(1 << 6)	//RX_OVRD_IN_HI[6] Override value for rx_eq_en

unsigned long xhci_base_addr[] = {LG1210_USB_SSUSB0_BASE, LG1210_USB_SSUSB1_BASE};

static void _arch_usb_reset(void)
{
	int i;

	//USB20 reset
	for(i=0; i<USB2_MAX; i++)
	{
		USB2_PHY_RESET usb2PhyRst = usb2_regs[i].pPhy->usb2_phy_reset;
		USB2_HOST_RESET usb2HostRst = usb2_regs[i].pHost->usb2_host_reset;

		/* PHY Reset */
		usb2PhyRst.usb2_phy_reset = 1;
		usb2_regs[i].pPhy->usb2_phy_reset = usb2PhyRst;
		mdelay(1);
		/* UTMI Reset */
		usb2HostRst.usb2_host_utmi_reset = 1;
		usb2_regs[i].pHost->usb2_host_reset = usb2HostRst;

		/* Bus and Core  Reset */
		usb2HostRst.usb2_host_bus_reset = 1;
		usb2HostRst.usb2_host_core_reset = 1;
		usb2_regs[i].pHost->usb2_host_reset = usb2HostRst;
	}

	/* USB30 reset */
	for(i=0; i<USB3_MAX; i++)
	{
		USB3_PHY_RESET usb3PhyRst = usb3_regs[i].pPhy->usb3_phy_reset;
		USB3_HOST_RESET usb3HostRst = usb3_regs[i].pHost->usb3_host_reset;

		/* PHY Reset */
		usb3PhyRst.usb3_phy_reset = 1;
		usb3_regs[i].pPhy->usb3_phy_reset = usb3PhyRst;
		mdelay(1);

		/* Bus and Core  Reset */
		usb3HostRst.usb3_host_bus_reset= 1;
		usb3HostRst.usb3_host_core_reset = 1;
		usb3_regs[i].pHost->usb3_host_reset = usb3HostRst;
	}
}

static void _arch_usb_phy_init(void)
{
	int i;

	/* USB 2.0 PHY init*/
	for(i=0; i<USB2_MAX; i++)
	{
		USB2_PHY_PARAM_0 usbPhyParm0 = usb2_regs[i].pPhy->usb2_phy_param0;

		/* Adjust txpreepaptune for USB2.0 CTS*/
		usbPhyParm0.phy_txpreempamptune = 0x3;
		usb2_regs[i].pPhy->usb2_phy_param0 = usbPhyParm0;
	}

	/* USB 3.0 PHY init*/
	for(i=0; i<USB3_MAX; i++)
	{
		USB3_PHY_PARAM_0 usbPhyParm0 = usb3_regs[i].pPhy->usb3_phy_param0;
		USB3_PHY_PARAM_1 usbPhyParm1 = usb3_regs[i].pPhy->usb3_phy_param1;
		USB3_PHY_PARAM_2 usbPhyParm2 = usb3_regs[i].pPhy->usb3_phy_param2;
		USB3_PHY_PARAM_3 usbPhyParm3 = usb3_regs[i].pPhy->usb3_phy_param3;
		USB3_PHY_PARAM_6 usbPhyParm6 = usb3_regs[i].pPhy->usb3_phy_param6;

		usbPhyParm0.phy_lane0_ext_pclk_req = 1;
		usb3_regs[i].pPhy->usb3_phy_param0 = usbPhyParm0;

		usbPhyParm1.phy_ssc_range = 1;
		usb3_regs[i].pPhy->usb3_phy_param1 = usbPhyParm1;

		/* pcs_tx_swing_full = 7'h7F */
		usbPhyParm3.phy_pcs_tx_swing_full = 0x7F;
		usbPhyParm3.phy_los_bias = 0x5;
		usb3_regs[i].pPhy->usb3_phy_param3 = usbPhyParm3;

		/* modify usb txvreftune value for adjusting signal level of EYE Diagram */
		usbPhyParm2.phy_tx_vboost_lvl = 0x4;
		usbPhyParm2.phy_txpreempamptune = 0x3;
		usbPhyParm2.phy_los_level = 0x11;
		usb3_regs[i].pPhy->usb3_phy_param2 = usbPhyParm2;

		usbPhyParm6.phy_pcs_rx_los_mask_val = 0x0;
		usb3_regs[i].pPhy->usb3_phy_param6 = usbPhyParm6;
	}
}

static inline void _arch_usb_ss_wait_cr_ack(USB3_PHY_CTRL *phy, int ack_val)
{
	long cnt = 0;
	long timeout = 10 * 1000;
	USB3_PHY_PARAM_5 ack_reg;

	while(cnt < timeout) {
		ack_reg = phy->usb3_phy_param5;
		if(ack_reg.phy_cr_ack == ack_val)
			break;
		cnt++;
		udelay(1);
	}
}

/* CR BUS Address Capture Transaction */
static void _arch_usb_ss_cr_addr_capture(USB3_PHY_CTRL *phy, u16 addr)
{
	USB3_PHY_PARAM_4 cap_reg;

	cap_reg = phy->usb3_phy_param4;
	/* Write Cap Register Bus Address */
	cap_reg.phy_cr_data_in = addr;
	phy->usb3_phy_param4 = cap_reg;

	/* Address Capture Request: Captures cr_data_in into the Address Register */
	cap_reg.phy_cr_cap_addr = 0x1;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_ACK);

	/* Clear Address Capture Request */
	cap_reg.phy_cr_cap_addr = 0x0;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_NAK);
}

/* CR Bus Read Transaction */
static unsigned short _arch_usb_ss_cr_read(USB3_PHY_CTRL *phy, u16 addr)
{
	USB3_PHY_PARAM_4 cap_reg;
	USB3_PHY_PARAM_5 read_reg;
	unsigned short val;

	/* CR BUS Address Capture Transaction */
	_arch_usb_ss_cr_addr_capture(phy, addr);

	cap_reg = phy->usb3_phy_param4;

	/* Read Transaction start : read from the referenced address register */
	cap_reg.phy_cr_read = 1;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_ACK);

	/* Get read data from the bus */
	read_reg = phy->usb3_phy_param5;
	val = read_reg.phy_cr_data_out;

	/* Finish Read Transaction */
	cap_reg.phy_cr_read = 0;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_NAK);

	return val;
}

/* CR Bus Write Transaction */
static void _arch_usb_ss_cr_write(USB3_PHY_CTRL *phy, u16  addr, u16 val)
{
	USB3_PHY_PARAM_4 cap_reg;

	/* CR BUS Address Capture Transaction */
	_arch_usb_ss_cr_addr_capture(phy, addr);

	cap_reg = phy->usb3_phy_param4;

	/* put data on the bus */
	cap_reg.phy_cr_data_in = val;
	phy->usb3_phy_param4 = cap_reg;

	/* Write cr_data_in into Write Data Register */
	cap_reg.phy_cr_cap_data = 1;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_ACK);
	cap_reg.phy_cr_cap_data = 0;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_NAK);

	/* Writes the Write Data register to the referenced Address  register  */
	cap_reg.phy_cr_write = 1;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_ACK);
	cap_reg.phy_cr_write = 0;
	phy->usb3_phy_param4 = cap_reg;
	_arch_usb_ss_wait_cr_ack(phy, CR_NAK);
}

/*
 * EQ1 : 0x100(A0 EV B'd)
 * EQ2 : 0x200(A1 EV B'd)
 * EQ4 : 0x400 (A1 System B'd)
 * EQ5 : 0x500(A0 System B'd)
*/
static void _arch_usb_ss_rx_eq_setting(int id, u16 val)
{
	if(val & RX_EQ_MASK)
		val |= RX_EQ_OVRD_MASK;

	if(val & RX_EQ_EN_MASK)
		val |= RX_EQ_EN_OVRD_MASK;

	if(val) {
		u16 addr = RX_OVRD_IN_HI;
		_arch_usb_ss_cr_write(usb3_regs[id].pPhy,addr, val | RX_EQ_OVRD_MASK);
		val = _arch_usb_ss_cr_read(usb3_regs[id].pPhy, addr);
		printf("ss[%d] RX_OVRD_IN_HI=0x%x, RX_EQ=0x%x\n", id, val, val&RX_EQ_MASK);
	}
}

static void _arch_vbus_ctrl(int enable)
{
	int value;

	if(enable)
		value = GPIO_HIGH;  //VBUS On
	else
		value = GPIO_LOW;  //VBUS Off

#ifdef GPIO_USB_OCD1
	gpio_set_top(GPIO_USB_OCD1);
	gpio_set_direction(GPIO_USB_OCD1, GPIO_DIR_INPUT);
#endif

#ifdef GPIO_USB_CTL1
	gpio_set_top(GPIO_USB_CTL1);
	gpio_set_direction(GPIO_USB_CTL1, GPIO_DIR_OUTPUT);
	gpio_set_value(GPIO_USB_CTL1, value);
#endif

#ifdef GPIO_USB_OCD2
	gpio_set_top(GPIO_USB_OCD2);
	gpio_set_direction(GPIO_USB_OCD2, GPIO_DIR_INPUT);
#endif

#ifdef GPIO_USB_CTL2
	gpio_set_top(GPIO_USB_CTL2);
	gpio_set_direction(GPIO_USB_CTL2, GPIO_DIR_OUTPUT);
	gpio_set_value(GPIO_USB_CTL2, value);
#endif

#ifdef GPIO_USB_OCD3
	gpio_set_top(GPIO_USB_OCD3);
	gpio_set_direction(GPIO_USB_OCD3, GPIO_DIR_INPUT);
#endif

#ifdef GPIO_USB_CTL3
	gpio_set_top(GPIO_USB_CTL3);
	gpio_set_direction(GPIO_USB_CTL3, GPIO_DIR_OUTPUT);
	gpio_set_value(GPIO_USB_CTL3, value);
#endif
}

static void _arch_ss_gbl_init(void)
{
	uint32_t temp;
	uint32_t vers;
	int i;

	for(i=0; i<USB3_MAX; i++)
	{
		// Global SoC Bus Configuration Register 0 : GSBUSCFG0. Max busrt size ==>8 : GSBUSCFG0 = xhci base addr + 0xC100
		temp = REG_READ(xhci_base_addr[i] + 0xC100) | (1<<1); //INCR4 Burst Type Enable (INCR4BrstEna) Input to BUS-GM.
		temp = temp | (1<<2);//INCR8 Burst Type Enable (INCR8BrstEna) Input to BUS-GM.
		REG_WRITE( (xhci_base_addr[i] + 0xC100), temp);

		// Global Rx Threshold Control Register: GRXTHRCFG : GRXTHRCFG = xhci base addr + 0xC10C
		REG_WRITE((xhci_base_addr[i] + 0xC10C), 0x0);// Set all register values to 0

		// Global Synopsys ID Register: GSNPSID : GSNPSID = xhci base addr + 0xC120
		temp = REG_READ(xhci_base_addr[i] + 0xC120);
		vers = temp;
		if ((vers & 0xFFFF) >= 0x280A) {
			// XHCI 3.0 core v2.80a
			// Global User Control Register: GUCTL1 : GUCTL1 = xhci base addr + 0xC11C
			temp = REG_READ(xhci_base_addr[i] + 0xC11C) | (1<<18); //NAK_PER_ENH_HS[18] = 1'b1
			REG_WRITE( (xhci_base_addr[i] + 0xC11C), temp);
		}

		// USBHstInAutoRetryEn : Auto Retry Enabled : GUCTL = xhci base addr + 0xC12C
		temp = REG_READ(xhci_base_addr[i] + 0xC12C) | (1<<14); //Global User Control Register, GUCTL[14] = 1'b1
		REG_WRITE( (xhci_base_addr[i] + 0xC12C), temp);

		if ((vers & 0xFFFF) >= 0x280A) {
			temp = REG_READ(xhci_base_addr[i] + 0xC200) & ~(1<<3);
			REG_WRITE( (xhci_base_addr[i] + 0xC200), temp);
		} else {
			// UTMI Data width : 16bit. : GUSB2PHYCFGn = xhci base addr + 0xC200
			temp = REG_READ(xhci_base_addr[i] + 0xC200) | (1<<3); //PHY Interface (PHYIf) :GUSB2PHYCFGn[3] = 1'b1
			REG_WRITE( (xhci_base_addr[i] + 0xC200), temp);
		}
	}
}

static void _arch_ss_rx_eq_init(void)
{
	int i;

	for(i=0 ; i<USB3_MAX; i++)
		_arch_usb_ss_rx_eq_setting(i, RX_EQ_04);
}

void arch_usb_init(void)
{
	printf("^g^""arch_usb_init \n");
	_arch_usb_phy_init();
	_arch_usb_reset();
	_arch_ss_gbl_init();
	_arch_ss_rx_eq_init();
}

void arch_usb_start(void)
{
	printf("^g^""arch_usb_start \n");
	_arch_vbus_ctrl(1);
}

void arch_usb_stop(void)
{
	printf("^g^""arch_usb_stop \n");
	_arch_vbus_ctrl(0);
}



