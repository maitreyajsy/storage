#include <string.h>
#include <serial.h>
#include <arch/cpu.h>
#include <arch/timers.h>
#include <timer.h>
#include <mmu.h>
#include <thread.h>
#include <arch/ctop_regs.h>
#include <i2c.h>
#include <debug.h>

#define NUM_EXEC_VECTOR		16

#ifndef VECTOR_BASE
#error "VECTOR_BASE not defined in <platform/memory_map.h>"
#endif

#define EXIT_JMP	(0)
#define EXIT_BOT	(1)

#ifndef H15A_I2C_CH
#define H15A_I2C_CH 8	/* H15A */
#endif

extern void sp_el0_sync_excep(void);
extern void sp_el0_irq_excep(void);	
extern void sp_el0_fiq_excep(void);	
extern void sp_el0_serror_excep(void);

extern void sp_elx_sync_excep(void);
extern void sp_elx_irq_excep(void);	
extern void sp_elx_fiq_excep(void);	
extern void sp_elx_serror_excep(void);

extern void low64_sync_excep(void);
extern void low64_irq_excep(void);	
extern void low64_fiq_excep(void);	
extern void low64_serror_excep(void);

extern void low32_sync_excep(void);
extern void low32_irq_excep(void);	
extern void low32_fiq_excep(void);	
extern void low32_serror_excep(void);

typedef struct
{
	ulong offset;
	void (*func)(void);
} excep_vector_t;

/* el3 vector table */
/* aarch 64 vector size : 2KB(0x800) */
static excep_vector_t exec_vector[NUM_EXEC_VECTOR] =
{
	/* current exception level with sp_el0 */
	{0x000, 	sp_el0_sync_excep		},
	{0x080, 	sp_el0_irq_excep		},
	{0x100, 	sp_el0_fiq_excep		},
	{0x180, 	sp_el0_serror_excep	},

	/* current exception level with sp_elx, x>0 */
	{0x200, 	sp_elx_sync_excep		},
	{0x280, 	sp_elx_irq_excep		},
	{0x300, 	sp_elx_fiq_excep		},
	{0x380, 	sp_elx_serror_excep	},

	/* Lower Exception level, where the implemented 
	   level immediately lower than the target level is 
	   using AArch64 */
	{0x400, 	low64_sync_excep 	},
	{0x480, 	low64_irq_excep 	},
	{0x500, 	low64_fiq_excep 	},
	{0x580, 	low64_serror_excep 	},

	/* Lower Exception level, where the implemented 
	   level immediately lower than the target level is 
	   using AArch32 */
	{0x600, 	low32_sync_excep 	},
	{0x680, 	low32_irq_excep 	},
	{0x700, 	low32_fiq_excep 	},
	{0x780, 	low32_serror_excep 	},
};

volatile CTOP_CTRL_REG_T g_ctop_regs = 
{
#define _CTOP_INIT(_m) 	(H15_A0_CTOP_##_m##_TYPE *)H15_A0_CTOP_##_m##_BASE
	_CTOP_INIT(CVI),
	_CTOP_INIT(IMX),
	_CTOP_INIT(ND0),
	_CTOP_INIT(ND1),
	_CTOP_INIT(SUB),
	_CTOP_INIT(GSC),
	_CTOP_INIT(SR),
	_CTOP_INIT(VSD),
	_CTOP_INIT(DPE),
	_CTOP_INIT(CCO),
	_CTOP_INIT(MCU),
	_CTOP_INIT(M1),
	_CTOP_INIT(GFX),
	_CTOP_INIT(VDEC0),
	_CTOP_INIT(VDEC1),
	_CTOP_INIT(M2),
	_CTOP_INIT(VDEC2),
	_CTOP_INIT(M0),
	_CTOP_INIT(TI),
	_CTOP_INIT(AUD),
	_CTOP_INIT(VENC),
	_CTOP_INIT(VIP),
	_CTOP_INIT(GPU),
	_CTOP_INIT(CPU),
#undef _CTOP_INIT
};

volatile CTOP_CTRL_REG_T *ctop_regs = &g_ctop_regs;
volatile CPU_TOP_REG_T *cpu_top_regs = (CPU_TOP_REG_T *)LG1210_CPUTOP_BASE;

volatile int smp_inited = 0;

static uint32_t chip_rev = CONFIG_CHIP;
static uint32_t ace_rev = CONFIG_CHIP;

static ulong set_excep_vector(void)
{
	ulong vector_base = VECTOR_BASE;

	asm volatile("msr vbar_el3, %0" :: "r" (vector_base) : "memory");
	return vector_base;

}

static void exec_vector_init(void)
{
	int i;
	ulong vector_base = set_excep_vector();
	ulong branch_offset;

	for(i = 0; i < NUM_EXEC_VECTOR; i++)
	{
		branch_offset = (ulong)exec_vector[i].func;
		branch_offset -= vector_base + exec_vector[i].offset;
		/* generate branch instuction.
		 * this function is call before mmu_init()
		 */
		*(uint32_t *)(exec_vector[i].offset + vector_base) = 
									(0x14000000 | (branch_offset >> 2));
	}

	dsb();
	isb();
}

int ace_reg_read(uint8_t slave, uint8_t addr, uint8_t *data)
{
	int idx, res;
	for(idx=0; idx<3; idx++)
	{
		res = i2c_read(H15A_I2C_CH, slave, addr, 1, data, 1, 0);
		if(res != -1) break;
	}
	if(res == -1) printf("^r^ACE : can't read slave:0x%02x, addr:0x%02x\n", slave, addr);
	return res;
}

int ace_reg_write(uint8_t slave, uint8_t addr, uint8_t data)
{
	int idx, res;
	for(idx=0; idx<3; idx++)
	{
		res = i2c_write(H15A_I2C_CH, slave, addr, 1, &data, 1, 0);
		if(res != -1) break;
	}
	if(res == -1) printf("^r^ACE : can't write slave:0x%02x, addr:0x%02x\n", slave, addr);
	return res;
}

static void watchdog_init(void)
{
	watchdog_t *wdt = (watchdog_t*)LG1210_WATCHDOG_BASE;

	wdt->load = 0xFFFFFFFF;
	wdt->control = 0;	/* disable watchdog */
}

static void chip_detect(void)
{
	uint32_t version;
	uint32_t rev;

	version = REG_READ(LG1210_CX_CHIPREV_BASE);
	if(version == 0x1210cccc)
	{//Cx
		chip_rev = ARCH_LG1210 | REV_C0;
	}
	else
	{
		version = REG_READ(LG1210_CHIPREV_BASE);
		if(version == 0)
		{//Ax
			rev = REG_READ(LG1210_TZ_ROM_BASE);
			if(rev == 0)
			{
				chip_rev = ARCH_LG1210 | REV_A0;
				ace_rev = ARCH_LG1210 | REV_A0;
			}
			else
			{
				chip_rev = ARCH_LG1210 | REV_A1;
				ace_rev = ARCH_LG1210 | REV_A0;
			}
		}
		else if(version == 0x1210b000)
		{//Bx
			chip_rev = ARCH_LG1210 | REV_B0;
			ace_rev = ARCH_LG1210 | REV_B0;
		}
		else
			ERROR("can't detect chip rev!, use default chip rev\n");
	}
}

uint32_t get_chip_rev(void)
{
	return chip_rev;
}

uint32_t get_ace_rev(void)
{
	return ace_rev;
}

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
static clk_dev_t clk_dev[NUM_CLK_DEV];

static void auto_clk_detect(void)
{
	ctop_detect_clk();
	clk_dev[CLK_DEV_CPU]	= ctop_get_cpu_clk();
	clk_dev[CLK_DEV_PERI]	= ctop_get_pclk();
	clk_dev[CLK_DEV_UART]	= clk_dev[CLK_DEV_PERI];
	clk_dev[CLK_DEV_TIMER]	= clk_dev[CLK_DEV_PERI];
	clk_dev[CLK_DEV_I2C]	= clk_dev[CLK_DEV_PERI];
}
#else
static const clk_dev_t clk_dev[NUM_CLK_DEV] =
{
	[CLK_DEV_CPU]	= CPU_CLOCK,
	[CLK_DEV_PERI]	= PCLK,
	[CLK_DEV_UART]	= UART_CLK,
	[CLK_DEV_TIMER] = TIMER_CLK,
	[CLK_DEV_I2C]	= I2C_CLK,
};
#endif

uint32_t get_clk(clk_dev_t dev)
{
	return clk_dev[dev];
}

void cpu_init(void)
{
	chip_detect();

#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
	auto_clk_detect();
#endif

	early_timer_init();
	watchdog_init();

	soc_init(); 		/* used firstboot , setup about bus*/
	set_addr_switch();  /* used firstboot , setup address switch */

	exec_vector_init();

	serror_enable();	/* after setup exception_vection, enable SError */

	/* enable I cache, do mmu_init() more fast */
	inv_icache();
	enable_icache();

#if USE_DATA_CACHE
	/* setup mmu table & enable I/D cache */
	mmu_init();
#endif

}

void display_arch_info(void)
{
#if defined(CONFIG_USE_CLK_DETECT) || USE_CLK_DETECT
	printf("^y^LM CLK:%dMHz, GM CLK:%dMHz, EM CLK:%dMHz, PERI CLK:%dMHz, GPU CCI:%s\n",
		ctop_get_lm_clk()/MHZ, ctop_get_gm_clk()/MHZ, 
		ctop_get_em_clk()/MHZ, ctop_get_pclk()/MHZ,
		(REG_READ(0xc8ac03ac) & 0x1) ? "ON" : "OFF");
	printf("^c^PLL SS - MAIN0:%s, MAIN1:%s, CORE:%s\n"
							, ctop_get_main0_pll_ss() ? "ON" : "OFF"
							, ctop_get_main1_pll_ss() ? "ON" : "OFF"
							, ctop_get_core_pll_ss() ? "ON" : "OFF");
#endif
}

__attribute__((weak))
void reset(void)
{
	//Watchdog reset
	watchdog_t *wdt = (watchdog_t*)LG1210_WATCHDOG_BASE;

	interrupt_disable();
	serror_disable();

	wdt->control = 2;	/* Enable Watchdog reset output */
	wdt->load = 0x0;

	mdelay(100);
	while(1);
}

/*
 ********************************************************
 * SMP or not
 ********************************************************
 */

#if USE_SMP

static volatile int *cpu_local_signal = (volatile int*)CPU_LOCAL_SIGNAL;

static void set_local_signal(void)
{
	u32 i;
	for(i = 0; i < CPU_NUM; i++)
		cpu_local_signal[i] = 1;
	dmb();

}
void clear_local_signal(void)
{
	u32 cpu_id = get_cpu_id();

	if(cpu_id >= CPU_NUM)
	{
		printf("^r^[%s]error!!\n", __func__);
		return;
	}
	cpu_local_signal[cpu_id] = 0;
	dmb();

}


/*
 * desc : all cpu flag clear?
 */
static int local_cpu_ready(void)
{
	u32 i;
	
	dmb();
	for(i = 0; i < CPU_NUM; i++)
	{
		if(cpu_local_signal[i])
			return -1;
	}
	return 0;
}

static int wakeup_local_cpus(void)
{
	int timeout = 1000000;	// 1sec
	volatile u32* wakeup_signal = (volatile u32*)BOOTROM_CPUS_SPIN_CODE_REG;

	// wake up local cpus
	*wakeup_signal = CONFIG_TEXT_BASE;
	dmb();

	set_local_signal(); 	//set flag of all cpu
	clear_local_signal(); 	//clear flag of local cpu

	//if wfi
	ipi_broadcast(CPU_WAKEUP_IPI);
	//if wfe
	//sev();

	while(local_cpu_ready() != 0 && timeout > 0)
	{
		loop_udelay(1);
		timeout--;
	}

	return local_cpu_ready();
}

void smp_init(void)
{
	u32 tick;
	int rc;

	printf("Smp Init...");

#if USE_DATA_CACHE
	/* TODO: why needed? */
	flush_dcache();
#endif
	smp_inited = 1;
	dmb();

	tick = timer_tick();
	rc = wakeup_local_cpus();

	if(rc == 0) printf("%dus elapsed\n", timer_elapsed(tick));
	else printf("^r^Fail !!!\n");

}

void cpu_local_init(void)
{
	set_excep_vector();	//set exception vector base
	
	serror_enable();	/* after setup exception_vection, enable SError */

#if USE_DATA_CACHE
	/* setup mmu table & enable I/D cache */
	mmu_init();
#else
	/* invalidate & enable I cache */
	inv_icache();
	enable_icache();
#endif

	interrupt_local_init();
	
	//printf("%s:%d, smp %d\n", __func__, __LINE__, smp_inited);
}

/**************************************************************
 * desc: call by _local_main()
 **************************************************************/
/*TODO*/ TODO(need more exit codes about local resources)
void cpu_local_exit(int exitMode)
{
	extern void _cpu_exit_2nd(int);	// start.S

	local_timer_finalize();

	interrupt_disable();
	//serror_disable(); //TODO: need?

#if USE_DATA_CACHE
	/* disable mmu & disable I/D cache */
	mmu_disable();
#else
	//disable & inv I cache
	disable_icache();
	inv_icache();
	inv_dcache();
#endif

	_cpu_exit_2nd(exitMode);
}

static void smp_exit_mode(int mode)
{
#if USE_MULTI_THREAD
	u32 tick;
	u32	ipi = CPU_EXIT_IPI;

	int timeout = 1000000;	// 1sec

	printf("Smp Exit...");

	if (mode == EXIT_JMP) ipi = CPU_EXIT2_IPI;
	else                  ipi = CPU_EXIT_IPI;

	// change local cpu to waiting status
	set_local_signal();		//set flag of all cpu
	clear_local_signal();	//clear flag of local cpu
	ipi_broadcast(ipi);

	tick = timer_tick();
	while(local_cpu_ready() != 0 && timeout > 0)
	{
		loop_udelay(1);
		timeout--;
	}

	if(local_cpu_ready() == 0)
	{
		printf("%dus elapsed\n", timer_elapsed(tick));
	}
	else
	{
		u32 i;
		for(i = 0; i < CPU_NUM; i++)
		{
			printf("cpu local signal[%d] : %d\n", i, cpu_local_signal[i]);
		}
		printf("Fail !!!. timeout:%d\n", timeout);
		while(1);
	}
#endif
	smp_inited = 0;
}

static void smp_exit(void)
{
	smp_exit_mode(EXIT_BOT);
}

static void smp_jmp_exit(void)
{
	smp_exit_mode(EXIT_JMP);
}

#else //USE_SMP == 0
void smp_init(void)
{
	volatile u32* wakeup_signal = (volatile u32*)BOOTROM_CPUS_SPIN_CODE_REG;
	*wakeup_signal = CONFIG_TEXT_BASE;
	dmb();

	ipi_broadcast(CPU_WAKEUP_IPI);
	smp_inited = 1;
}
#endif 	//#if USE_SMP

/* called before jumping to linux or separated app */
/*TODO*/ TODO(need more exit codes about local or global resources)
static void cpu_exit_mode(int mode)
{
#if USE_SMP
	if (mode == EXIT_BOT) smp_exit();
	else                  smp_jmp_exit();
#else
	smp_inited = 0;
#endif
	timer_finalize();

	interrupt_disable();
	//serror_disable(); //TODO: need?

#if USE_DATA_CACHE
	mmu_disable();
#else
	//disable & inv I cache
	disable_icache();
	inv_icache();
	inv_dcache();
#endif
}

void cpu_exit(void)
{
	cpu_exit_mode(EXIT_BOT);
}

void cpu_jmp_exit(void)
{
	cpu_exit_mode(EXIT_JMP);
}


//EOF
