/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <command.h>
#include <util.h>
#include <storage.h>
#include <image.h>
#include <serial.h>


#define SERIAL_WAIT_TIMEOUT	(1000*60*3)	/* 3 minutes */
#define SERIAL_RX_TIMEOUT	5000	/* in ms unit */
static int cmd_download(int argc, char *argv[])
{
	uint8_t* buf = (uint8_t*)DATA_BUF_BASE;
	int ch;
	int cnt = 0;
	int hdr_found = FALSE;
	uint32_t hdr_checked = 0;
	int img_format = HDR_TYPE_NONE;
	int img_size = 0;
	uint32_t start_tick;
	timeout_id_t tid;


	set_timeout(&tid, SERIAL_WAIT_TIMEOUT);
	start_tick = timer_tick();
	while(1)
	{
		if(serial_check_rx(CONSOLE_UART_PORT))
		{
			ch = serial_getc(CONSOLE_UART_PORT);
			if(ch == -1)	// error occured
			{
				printf("serial error occured\n");
				return -1;
			}
			buf[cnt++] = (uint8_t)ch;


			if(hdr_found == TRUE)
			{
				if(cnt >= img_size)		// we've got all data
				{
					ulong load_addr;
					uint8_t* img_base;
					int data_size;

					printf("Download completed. received %dbytes\n", cnt);

					load_addr = get_img_load_addr(buf);
					if(load_addr == 0)
					{
						/* ����� download command�� �뵵�� 2nd ��Ʈ�� �����ϱ� ����������
						 * load address�� ���ǵ��� ���� ��� 2ndboot�� text base�� jump �Ѵ�.
						 */
						load_addr = CONFIG_TEXT_BASE;
					}
					img_base = buf + get_img_hdr_size(buf);
					data_size = get_img_data_size(buf);

					memcpy((void*)load_addr, img_base, data_size);
					jump((void*)load_addr, 0, NULL);
					/* Never return here */
				}
			}
			else
			{
				/*
				 * serial �ٿ��� �ϱ� ���� header�� �����ؾ� �ϸ�(size�� �˼� ����)
				 * ���⼭�� uimg, pak ���˸� ������ �Ѵ�.
				 */
				if(uimg_get_hdr_size() == cnt)
				{
					if(uimg_check_magic(buf))
					{
						img_format = HDR_TYPE_UIMG;
						img_size = uimg_get_size(buf);
						hdr_found = TRUE;
						printf("found uimg hdr\n");
					}
					hdr_checked |= (1 << HDR_TYPE_UIMG);
				}

				if(pak_get_hdr_size() == cnt)
				{
					if(pak_check_magic(buf))
					{
						img_format = HDR_TYPE__PAK;
						img_size = pak_get_size(buf);
						hdr_found = TRUE;
					}
					hdr_checked |= (1 << HDR_TYPE__PAK);
				}

				// we have already checked all headers but can't find
				if(hdr_found == FALSE &&
					hdr_checked == ((1 << HDR_TYPE__PAK) | (1 << HDR_TYPE_UIMG)))
				{
					printf("Can't find image header !!!\n");
					return -1;
				}
			}

			//start timer to check timeout
			set_timeout(&tid, SERIAL_RX_TIMEOUT);
			start_tick = timer_tick();
		}
		else
		{
			//data�� ������ �ʴ� ��� ���� �ð����� wait �� timeout ó���Ѵ�.
			if(is_timeout(&tid))
			{
				printf("timeout occured. start=0x%x, current=0x%x\n", start_tick, timer_tick());
				return -1;
			}
		}
	}

	printf("\ndownload aborted by User Break or Error, received=%d \n\n", cnt);
	return -1;
}

COMMAND(dn, cmd_download, "download image file", NULL);
