/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#if USE_BOOT_LOGO
#include <types.h>
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include <arch/pwm.h>

#define RET_OK	0
#define RET_ERROR -1
#define BE_PRINT(fmt,args...)		printf(fmt, ##args)
#define BREAK_WRONG(val)           { printf("Wrong %s(0x%x)\n", #val, val); ret = RET_ERROR; break; }
#define CHECK_KNULL(ptr) if (!ptr) { printf("%s is Null\n", #ptr); ret = RET_ERROR; break; }

#define USE_PWM_RUN_IN_KDRIVER

#ifdef USE_PWM_RUN_IN_KDRIVER

#define PWM_DUTY_MAX_S		255

typedef enum {
	PWM_ORD_1ST_S  ,
	PWM_ORD_2ND_S  ,
	PWM_ORD_3RD_S  ,
	PWM_ORD_4TH_S  ,
	PWM_ORD_5TH_S  ,
	PWM_ORD_6TH_S  ,
	PWM_ORD_7TH_S  ,
	PWM_ORD_8TH_S  ,
	PWM_ORD_MAX_S
} PWM_ORD_S_T;

typedef enum {
	PWM_FREQ_60HZ_S  ,
	PWM_FREQ_120HZ_S ,
	PWM_FREQ_240HZ_S ,
	PWM_FREQ_480HZ_S ,
	PWM_FREQ_MAX_S
} PWM_FREQ_S_T;

typedef enum {
	PWM_FREE_OFF_S ,
	PWM_FREE_ON_S  ,
	PWM_FREE_MAX_S
} PWM_FREE_S_T;

typedef enum {
	PWM_RES_256_S   ,
	PWM_RES_512_S   ,
	PWM_RES_1024_S  ,
	PWM_RES_MAX_S
} PWM_RES_S_T;

typedef enum {
	PWM_MODE_DUTY_S	,
	PWM_MODE_WIDTH_S	,
	PWM_MODE_MAX_S
} PWM_MODE_S_T;

typedef enum {
	PWM_CTRL_ENB_S ,
	PWM_CTRL_FRQ_S ,
	PWM_CTRL_FRE_S ,
	PWM_CTRL_RES_S ,
	PWM_CTRL_INV_S ,
	PWM_CTRL_MOD_S ,
	PWM_CTRL_POS_S ,
	PWM_CTRL_LOW_S ,
	PWM_CTRL_HIG_S ,
	PWM_CTRL_WDH_S ,
	PWM_CTRL_MSK_S ,
	PWM_CTRL_SCN_S,
	PWM_CTRL_MAX_S
} PWM_CTRL_TYPE_S_T;

typedef struct {
	// ctrl0 reg
	UINT32 pwm_en		;
	UINT32 pwm_freq_mode;
	UINT32 pwm_resolution;
	UINT32 pwm_inv		;
	UINT32 pwm_sel		;
	UINT32 pwm_width_falling_pos;
	// ctrl1 reg
	UINT32 pwm_free_width       ;
	// ctrl2 reg
	UINT32 pwm_intr_mask	;
	UINT32 pwm_method	;
	UINT32 pwm_mux	;
	UINT32 pwm_fc_h_disp;
	UINT32 pwm_fc_l_disp;
} PWM_CTRL_S_T;

typedef struct {
	UINT32 pwm_v_f;		// rising count
	UINT32 pwm_v_r;		// falling count
	UINT32 pwm_v_id;	// Duty range ID
	UINT32 pwm_v_we;	// load/write
} PWM_TIMING_S_T;

typedef struct {
	UINT32             unit;
	UINT32             ordr;
	UINT32             pxls;
	UINT32             free;
	UINT32			   mask;
	UINT32			   scan;
	UINT32			   wdth;
	PWM_CTRL_S_T   ctrl;
	PWM_TIMING_S_T t1st;
	PWM_TIMING_S_T t2nd;
	UINT32             duty;
	UINT32             offs;
	UINT32             freq;
} PWM_INFO_S_T;

static PWM_INFO_S_T gPwmInfo[BE_PWM_MAX];

static int PWM_InitCtrl(void);
static int PWM_SetCtrl(UINT32 pwmId, PWM_CTRL_TYPE_S_T ctrId, UINT32 ctrVal);
static int PWM_SetTiming(UINT32 pwmId, PWM_ORD_S_T pwmOrd, UINT32 *pR1st, UINT32 *pR2nd, UINT32 *pF1st, UINT32 *pF2nd);
static int PWM_SetRegCtrl(UINT32 pwmId, BOOLEAN zeroDuty);
static int _REG_SetPwmCtrl(UINT32 pwmId, BOOLEAN zeroDuty);
static int _REG_SetPwmMask(UINT32 pwmId);
static int _REG_SetPwmWidth(UINT32 pwmId);
static int _REG_SetPwmTiming(UINT32 pwmId);


volatile H15A0_PE_PWM0_CTRL0 *dvo_pwm0_ctrl0 = (volatile H15A0_PE_PWM0_CTRL0 *)0xC800B110;
volatile H15A0_PE_PWM0_CTRL1 *dvo_pwm0_ctrl1 = (volatile H15A0_PE_PWM0_CTRL1 *)0xC800B114;
volatile H15A0_PE_PWM0_CTRL2 *dvo_pwm0_ctrl2 = (volatile H15A0_PE_PWM0_CTRL2 *)0xC800B118;
volatile H15A0_PE_PWM1_CTRL0 *dvo_pwm1_ctrl0 = (volatile H15A0_PE_PWM1_CTRL0 *)0xC800B11C;
volatile H15A0_PE_PWM1_CTRL1 *dvo_pwm1_ctrl1 = (volatile H15A0_PE_PWM1_CTRL1 *)0xC800B120;
volatile H15A0_PE_PWM1_CTRL2 *dvo_pwm1_ctrl2 = (volatile H15A0_PE_PWM1_CTRL2 *)0xC800B124;
volatile H15A0_PE_PWM2_CTRL0 *dvo_pwm2_ctrl0 = (volatile H15A0_PE_PWM2_CTRL0 *)0xC800B128;
volatile H15A0_PE_PWM2_CTRL1 *dvo_pwm2_ctrl1 = (volatile H15A0_PE_PWM2_CTRL1 *)0xC800B12C;
volatile H15A0_PE_PWM2_CTRL2 *dvo_pwm2_ctrl2 = (volatile H15A0_PE_PWM2_CTRL2 *)0xC800B130;
volatile H15A0_PE_PWM3_CTRL0 *dvo_pwm3_ctrl0 = (volatile H15A0_PE_PWM3_CTRL0 *)0xC800B134;
volatile H15A0_PE_PWM3_CTRL1 *dvo_pwm3_ctrl1 = (volatile H15A0_PE_PWM3_CTRL1 *)0xC800B138;
volatile H15A0_PE_PWM_V_LOAD_WRITE *dvo_pwm_v_load_write = (volatile H15A0_PE_PWM_V_LOAD_WRITE *)0xC800B17C;
volatile H15A0_PE_PWM0_V_R *dvo_pwm0_v_r = (volatile H15A0_PE_PWM0_V_R *)0xC800B180;
volatile H15A0_PE_PWM0_V_F *dvo_pwm0_v_f = (volatile H15A0_PE_PWM0_V_F *)0xC800B184;
volatile H15A0_PE_PWM1_V_R *dvo_pwm1_v_r = (volatile H15A0_PE_PWM1_V_R *)0xC800B188;
volatile H15A0_PE_PWM1_V_F *dvo_pwm1_v_f = (volatile H15A0_PE_PWM1_V_F *)0xC800B18C;
volatile H15A0_PE_PWM2_V_R *dvo_pwm2_v_r = (volatile H15A0_PE_PWM2_V_R *)0xC800B190;
volatile H15A0_PE_PWM2_V_F *dvo_pwm2_v_f = (volatile H15A0_PE_PWM2_V_F *)0xC800B194;
volatile H15A0_PE_PWM0_V_SUB_R *dvo_pwm0_v_sub_r = (volatile H15A0_PE_PWM0_V_SUB_R *)0xC800B198;
volatile H15A0_PE_PWM1_V_SUB_R *dvo_pwm1_v_sub_r = (volatile H15A0_PE_PWM1_V_SUB_R *)0xC800B19C;
volatile H15A0_PE_PWM2_V_SUB_R *dvo_pwm2_v_sub_r = (volatile H15A0_PE_PWM2_V_SUB_R *)0xC800B1A0;
volatile H15A0_PE_PWM0_V_SUB_F *dvo_pwm0_v_sub_f = (volatile H15A0_PE_PWM0_V_SUB_F *)0xC800B1DC;
volatile H15A0_PE_PWM1_V_SUB_F *dvo_pwm1_v_sub_f = (volatile H15A0_PE_PWM1_V_SUB_F *)0xC800B1E0;
volatile H15A0_PE_PWM2_V_SUB_F *dvo_pwm2_v_sub_f = (volatile H15A0_PE_PWM2_V_SUB_F *)0xC800B1E4;

#define PE_PWM_H15_Wr01(_r,f,v)	(_r.f) = (v)


int BE_PWM_Init(UINT32 type)
{
	int ret = RET_OK;
	BE_PWM_ID_T pwmId;

	do {
		ret = PWM_InitCtrl();
		if (ret) break;

		pwmId = BE_PWM0;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_ENB_S, TRUE);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_FRQ_S, PWM_FREQ_120HZ_S);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_MOD_S, PWM_MODE_DUTY_S);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_FRE_S, PWM_FREE_OFF_S);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_RES_S, PWM_RES_1024_S);
		if (ret) break;
		ret = _REG_SetPwmCtrl(pwmId, FALSE);
		if (ret) break;

		ret = PWM_SetCtrl(pwmId, PWM_CTRL_MSK_S, 0x00);	// mask intr
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_WDH_S, FALSE);	// duty mode

		if (ret) break;
		ret = _REG_SetPwmMask(pwmId);
		if (ret) break;
		ret = _REG_SetPwmWidth(pwmId);
		if (ret) break;

		ret = PWM_SetTiming(pwmId, PWM_ORD_1ST_S, NULL, NULL, NULL, NULL);
		if (ret) break;

		if(type == 0)
		{
			pwmId = BE_PWM1;
			ret = PWM_SetCtrl(pwmId, PWM_CTRL_ENB_S, TRUE);
			if (ret) break;
			ret = PWM_SetCtrl(pwmId, PWM_CTRL_FRQ_S, PWM_FREQ_120HZ_S);
			if (ret) break;
			ret = PWM_SetCtrl(pwmId, PWM_CTRL_MOD_S, PWM_MODE_DUTY_S);
			if (ret) break;
			ret = PWM_SetCtrl(pwmId, PWM_CTRL_FRE_S, PWM_FREE_OFF_S);
			if (ret) break;
			ret = PWM_SetCtrl(pwmId, PWM_CTRL_RES_S, PWM_RES_1024_S);
			if (ret) break;
			ret = _REG_SetPwmCtrl(pwmId, FALSE);
			if (ret) break;

			ret = PWM_SetCtrl(pwmId, PWM_CTRL_MSK_S, 0x00);	// mask intr
			if (ret) break;
			ret = PWM_SetCtrl(pwmId, PWM_CTRL_WDH_S, FALSE);	// duty mode

			if (ret) break;
			ret = _REG_SetPwmMask(pwmId);
			if (ret) break;
			ret = _REG_SetPwmWidth(pwmId);
			if (ret) break;

			ret = PWM_SetTiming(pwmId, PWM_ORD_1ST_S, NULL, NULL, NULL, NULL);
			if (ret) break;
		}

#if 0
		pwmId = BE_PWM2;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_ENB_S, TRUE);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_FRQ_S, PWM_FREQ_120HZ_S);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_MOD_S, PWM_MODE_DUTY_S);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_FRE_S, PWM_FREE_OFF_S);
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_RES_S, PWM_RES_1024_S);
		if (ret) break;
		ret = _REG_SetPwmCtrl(pwmId, FALSE);
		if (ret) break;

		ret = PWM_SetCtrl(pwmId, PWM_CTRL_MSK_S, 0x00);	// mask intr
		if (ret) break;
		ret = PWM_SetCtrl(pwmId, PWM_CTRL_WDH_S, FALSE);	// duty mode

		if (ret) break;
		ret = _REG_SetPwmMask(pwmId);
		if (ret) break;
		ret = _REG_SetPwmWidth(pwmId);
		if (ret) break;

		ret = PWM_SetTiming(pwmId, PWM_ORD_1ST_S, NULL, NULL, NULL);
		if (ret) break;
#endif
	} while ( 0 );

	BE_PRINT("BE_PWM_Init : done.\n");

	return ret;
}

int BE_SetPwmControl(BE_PWM_CTRL_T *pstParams)
{
	int ret = RET_OK;

	do {
		PWM_SetCtrl(pstParams->port, PWM_CTRL_ENB_S, pstParams->enable); // force to high

		if(!pstParams->enable) break;

		switch (pstParams->pwmOutput)
		{
			case BE_PWM_LOW :
				PWM_SetCtrl(pstParams->port, PWM_CTRL_LOW_S, TRUE);
				break;
			case BE_PWM_NORMAL :
				PWM_SetCtrl(pstParams->port, PWM_CTRL_LOW_S, FALSE);
				PWM_SetCtrl(pstParams->port, PWM_CTRL_HIG_S, FALSE);
				PWM_SetCtrl(pstParams->port, PWM_CTRL_INV_S, FALSE);
				break;
			case BE_PWM_HIGH :
				PWM_SetCtrl(pstParams->port, PWM_CTRL_HIG_S, TRUE);
				break;
			case BE_PWM_INVERSION :
				PWM_SetCtrl(pstParams->port, PWM_CTRL_INV_S, TRUE);
				break;
			default :
				BREAK_WRONG(pstParams->pwmOutput);
		}

		PWM_SetCtrl(pstParams->port, PWM_CTRL_FRE_S, (pstParams->pwmMode)?PWM_FREE_OFF_S:PWM_FREE_ON_S);

		PWM_SetCtrl(pstParams->port, PWM_CTRL_SCN_S, pstParams->pwmScanning);
	} while(0);

	return ret;
}

int BE_SetPwmDutyCycle(BE_PWM_DUTY_T *pstParams)
{
	int ret = RET_OK;
	UINT32 i;
	UINT32 ordr;
	UINT32 offs;
	UINT32 high;
	UINT32 falt;
	UINT32 unit_pixel;

	do {
		if(pstParams->duty > PWM_DUTY_MAX_S) break;
		if(pstParams->offset > PWM_DUTY_MAX_S) break;
		if((pstParams->offset + pstParams->duty) > PWM_DUTY_MAX_S)
		{
			if (gPwmInfo[pstParams->port].scan)
			{
				pstParams->offset = PWM_DUTY_MAX_S - pstParams->duty;
			}
			else
			{
				pstParams->duty = PWM_DUTY_MAX_S - pstParams->offset;
			}
		}

		gPwmInfo[pstParams->port].duty = pstParams->duty;
		gPwmInfo[pstParams->port].offs = pstParams->offset;

		unit_pixel = gPwmInfo[pstParams->port].pxls / gPwmInfo[pstParams->port].unit;
		ordr	   = gPwmInfo[pstParams->port].ordr;

		offs = (unit_pixel * pstParams->offset)/PWM_DUTY_MAX_S;
		high = (unit_pixel * pstParams->duty)/PWM_DUTY_MAX_S;
		falt = offs + high;

		for(i=PWM_ORD_1ST_S; i<ordr+1; i++)
		{
			//BE_PRINT("Port[%d] : ordr[%d] -  unit_pixel[%d] offs[%d] falt[%d] high[%d] \n", pstParams->port, i, unit_pixel, offs, falt, high);

			ret = PWM_SetTiming(pstParams->port, i, &offs, &offs, &falt, &falt);
			if(ret) break;
		}
		ret = PWM_SetRegCtrl(pstParams->port, offs == falt ? TRUE : FALSE); /* In case of zero duty, force to low PWM signal. */
	} while(0);

	return ret;
}

int BE_SetPwmFrequency(BE_PWM_FREQ_T *pstParams)
{
	int ret = RET_OK;
	BE_PWM_DUTY_T stParams;

	do {
		gPwmInfo[pstParams->port].unit = 1024;
		gPwmInfo[pstParams->port].freq = pstParams->frequency;

		if( gPwmInfo[pstParams->port].ctrl.pwm_method == PWM_FREE_OFF_S ) // locking mode
		{
			/*
			 * h      = hactive + hsync + h_bp + h_fp
			 * v      = vactive + vsync + v_bp + v_fp
			 * pixels = h * v
			 *
			 * result ->
			 * 60_h   = 1920    + 44    + 148  + 88   = 2200
			 * 60_v   = 1080    +  5    + 36   + 4    = 1125
			 *    h*v = 2475000
			 * 50_h   = 1920    + 44    + 148  + 88   = 2200
			 * 50_v   = 1080    +  5    + 36   + 229  = 1350
			 *    h*v = 2970000
			 * 48_h   = 1920    + 44    + 148  + 638  = 2750
			 * 48_v   = 1080    +  5    + 36   + 4    = 1125
			 *    h*v = 3093750
			 *
			 *    for UD (3820x2160 30p,25p,24p)
			 * 30_h   = 1920    + 44    + 88   + 72   = 2124
			 * 30_v   = 2160    + 148   + 10   + 8    = 2326
			 *    h*v = 4940424
			 * 25_h   = 1920    + 44    + 88   + 72   = 2124
			 * 25_v   = 2160    + 148   + 10   + 458  = 2776
			 *    h*v = 5896224
			 * 24_h   = 1920    + 44    + 638  + 72   = 2674
			 * 24_v   = 2160    + 148   + 10   + 8    = 2326
			 *    h*v = 6219724

			 */
			#define PWM_PIXELS_60HZ	2475000*2
			#define PWM_PIXELS_50HZ	2970000*2
			#define PWM_PIXELS_48HZ	3093750*2
			#define PWM_PIXELS_30HZ 	4940424*2
			#define PWM_PIXELS_25HZ 	5896224*2
			#define PWM_PIXELS_24HZ 	6219724*2

			switch ( pstParams->frequency )
			{
				case 384 :
				case 400 :
				case 480 :
					gPwmInfo[pstParams->port].ordr				  = PWM_ORD_8TH_S;
					gPwmInfo[pstParams->port].ctrl.pwm_method	  = FALSE;
					gPwmInfo[pstParams->port].ctrl.pwm_freq_mode = 3;
					if( pstParams->frequency == 384) 		gPwmInfo[pstParams->port].pxls = PWM_PIXELS_48HZ >> 3;
					else if(pstParams->frequency == 400) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_50HZ >> 3;
					else if(pstParams->frequency == 480) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_60HZ >> 3;
					break;
				case 192 :
				case 200 :
				case 240 :
					gPwmInfo[pstParams->port].ordr				  = PWM_ORD_4TH_S;
					gPwmInfo[pstParams->port].ctrl.pwm_method	  = FALSE;
					gPwmInfo[pstParams->port].ctrl.pwm_freq_mode = 2;
					if( pstParams->frequency == 192) 		gPwmInfo[pstParams->port].pxls = PWM_PIXELS_48HZ >> 2;
					else if(pstParams->frequency == 200) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_50HZ >> 2;
					else if(pstParams->frequency == 240) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_60HZ >> 2;
					break;
				case 96 :
				case 100 :
				case 120 :
					gPwmInfo[pstParams->port].ordr				  = PWM_ORD_2ND_S;
					gPwmInfo[pstParams->port].ctrl.pwm_method	  = FALSE;
					gPwmInfo[pstParams->port].ctrl.pwm_freq_mode = 1;
					if( pstParams->frequency == 96) 		gPwmInfo[pstParams->port].pxls = PWM_PIXELS_48HZ >> 1;
					else if(pstParams->frequency == 100) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_50HZ >> 1;
					else if(pstParams->frequency == 120) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_60HZ >> 1;
					break;
				case 48 :
				case 50 :
				case 60 :
					gPwmInfo[pstParams->port].ordr				  = PWM_ORD_1ST_S;
					gPwmInfo[pstParams->port].ctrl.pwm_method	  = FALSE;
					gPwmInfo[pstParams->port].ctrl.pwm_freq_mode = 0;
					if( pstParams->frequency == 48) 		gPwmInfo[pstParams->port].pxls = PWM_PIXELS_48HZ >> 0;
					else if(pstParams->frequency == 50) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_50HZ >> 0;
					else if(pstParams->frequency == 60) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_60HZ >> 0;
					break;
				case 24 :
				case 25 :
				case 30 :
					gPwmInfo[pstParams->port].ordr               = PWM_ORD_1ST_S;
					gPwmInfo[pstParams->port].ctrl.pwm_method    = TRUE;
					gPwmInfo[pstParams->port].ctrl.pwm_freq_mode = 0;
					if( pstParams->frequency == 24) 		gPwmInfo[pstParams->port].pxls = PWM_PIXELS_24HZ >> 0;
					else if(pstParams->frequency == 25) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_25HZ >> 0;
					else if(pstParams->frequency == 30) 	gPwmInfo[pstParams->port].pxls = PWM_PIXELS_30HZ >> 0;
					break;
				case 180 :
				case 160 :
				default :
					gPwmInfo[pstParams->port].ordr				  = PWM_ORD_1ST_S;
					gPwmInfo[pstParams->port].pxls				  = (2475000*2) * 60 / pstParams->frequency;
					gPwmInfo[pstParams->port].ctrl.pwm_free_width= (2475000*2) * 60 / pstParams->frequency;
					gPwmInfo[pstParams->port].ctrl.pwm_method	  = TRUE;
					gPwmInfo[pstParams->port].ctrl.pwm_freq_mode = 0;
					break;
			}
		}
		else	// freeeun mode
		{
			gPwmInfo[pstParams->port].ordr				   = PWM_ORD_1ST_S;
			gPwmInfo[pstParams->port].pxls				   = (2475000*2) * 60 / pstParams->frequency;
			gPwmInfo[pstParams->port].ctrl.pwm_free_width = (2475000*2) * 60 / pstParams->frequency;
			gPwmInfo[pstParams->port].ctrl.pwm_method	   = TRUE;
			gPwmInfo[pstParams->port].ctrl.pwm_freq_mode  = 0;
		}

		stParams.port	= pstParams->port;
		stParams.offset = gPwmInfo[pstParams->port].offs;
		stParams.duty	= gPwmInfo[pstParams->port].duty;
		ret = BE_SetPwmDutyCycle(&stParams);
	} while(0);

	return ret;
}

static int PWM_InitCtrl(void)
{
	int ret = RET_OK;
	UINT32 pwmId;

	for (pwmId=0;pwmId<BE_PWM_MAX;pwmId++) {
		gPwmInfo[pwmId].ctrl.pwm_en				 = FALSE;
		gPwmInfo[pwmId].ctrl.pwm_freq_mode			 = PWM_FREQ_60HZ_S;
		gPwmInfo[pwmId].ctrl.pwm_resolution		 = PWM_RES_1024_S;
		gPwmInfo[pwmId].ctrl.pwm_inv				 = FALSE;
		gPwmInfo[pwmId].ctrl.pwm_sel				 = PWM_MODE_DUTY_S;
		gPwmInfo[pwmId].ctrl.pwm_width_falling_pos  = 0;
		gPwmInfo[pwmId].ctrl.pwm_method			 = PWM_FREE_OFF_S;
		gPwmInfo[pwmId].ctrl.pwm_fc_h_disp			 = FALSE;
		gPwmInfo[pwmId].ctrl.pwm_fc_l_disp			 = FALSE;
		gPwmInfo[pwmId].wdth						 = 0;
		gPwmInfo[pwmId].mask						 = 0xff;
		gPwmInfo[pwmId].unit						 = 2417;
		gPwmInfo[pwmId].duty                        = 0xcc;
		gPwmInfo[pwmId].freq                        = 120;
		gPwmInfo[pwmId].offs						 = 0;
	}

	return ret;
}

static int PWM_SetCtrl(UINT32 pwmId, PWM_CTRL_TYPE_S_T ctrId, UINT32 ctrVal)
{
	int ret = RET_OK;

	switch (ctrId) {
		case PWM_CTRL_ENB_S :
			gPwmInfo[pwmId].ctrl.pwm_en				= ctrVal?TRUE:FALSE;
			break;
		case PWM_CTRL_FRQ_S :
			gPwmInfo[pwmId].ctrl.pwm_freq_mode			= ctrVal & 0x3;
			break;
		case PWM_CTRL_FRE_S :
			gPwmInfo[pwmId].ctrl.pwm_method			= ctrVal & 0x1;
			break;
		case PWM_CTRL_RES_S :
			gPwmInfo[pwmId].ctrl.pwm_resolution		= ctrVal & 0x3;
			break;
		case PWM_CTRL_INV_S :
			gPwmInfo[pwmId].ctrl.pwm_inv				= ctrVal?TRUE:FALSE;
			break;
		case PWM_CTRL_MOD_S :
			gPwmInfo[pwmId].ctrl.pwm_sel				= ctrVal;
			break;
		case PWM_CTRL_POS_S :
			gPwmInfo[pwmId].ctrl.pwm_width_falling_pos = ctrVal & 0x3FFFFF;
			break;
		case PWM_CTRL_LOW_S :
			gPwmInfo[pwmId].ctrl.pwm_fc_l_disp			= ctrVal?TRUE:FALSE;
			break;
		case PWM_CTRL_HIG_S :
			gPwmInfo[pwmId].ctrl.pwm_fc_h_disp			= ctrVal?TRUE:FALSE;
			break;
		case PWM_CTRL_WDH_S :
			gPwmInfo[pwmId].wdth						= ctrVal;
			break;
		case PWM_CTRL_MSK_S :
			gPwmInfo[pwmId].mask						= ctrVal;
			break;
		case PWM_CTRL_SCN_S :
			gPwmInfo[pwmId].scan						= ctrVal;
			break;
		default :
			break;
	}

	return ret;
}

static int PWM_SetTiming(UINT32 pwmId, PWM_ORD_S_T pwmOrd, UINT32 *pR1st, UINT32 *pR2nd, UINT32 *pF1st, UINT32 *pF2nd)
{
	PWM_TIMING_S_T t1st;
	PWM_TIMING_S_T t2nd;

	t1st = gPwmInfo[pwmId].t1st;
	t2nd = gPwmInfo[pwmId].t2nd;
	t1st.pwm_v_id = pwmOrd & 0xf;
	t2nd.pwm_v_id = pwmOrd & 0xf;
	t1st.pwm_v_we = TRUE;
	t2nd.pwm_v_we = TRUE;
	do {
		if (pR1st) t1st.pwm_v_r = *pR1st;
		if (pR2nd) t2nd.pwm_v_r = *pR2nd;
		else if (pR1st) t2nd.pwm_v_r = *pR1st;

		if (pF1st) t1st.pwm_v_f = *pF1st;
		if (pF2nd) t2nd.pwm_v_f = *pF2nd;
		else if (pF1st) t2nd.pwm_v_f = *pF1st;
	} while ( 0 );
	gPwmInfo[pwmId].t1st = t1st;
	gPwmInfo[pwmId].t2nd = t2nd;

	//Workaround for M14/H15
	if (gPwmInfo[pwmId].t1st.pwm_v_r == 0) gPwmInfo[pwmId].t1st.pwm_v_r = 1;
	if (gPwmInfo[pwmId].t1st.pwm_v_f == 0) gPwmInfo[pwmId].t1st.pwm_v_f = 2;
	if (gPwmInfo[pwmId].t2nd.pwm_v_r == 0) gPwmInfo[pwmId].t2nd.pwm_v_r = 1;
	if (gPwmInfo[pwmId].t2nd.pwm_v_f == 0) gPwmInfo[pwmId].t2nd.pwm_v_f = 2;

	return _REG_SetPwmTiming(pwmId);
}

static int PWM_SetRegCtrl(UINT32 pwmId, BOOLEAN zeroDuty)
{
	int ret = RET_OK;

	ret = _REG_SetPwmCtrl(pwmId, zeroDuty);

	return ret;
}

static int _REG_SetPwmCtrl(UINT32 pwmId, BOOLEAN zeroDuty)
{
	int ret = RET_OK;
	UINT32 regVal;

	switch (pwmId) {
		case 0 :
		{
			H15A0_PE_PWM0_CTRL0 dvo_pwm0_ctrl0_reg;
			H15A0_PE_PWM0_CTRL1 dvo_pwm0_ctrl1_reg;
			H15A0_PE_PWM0_CTRL2 dvo_pwm0_ctrl2_reg;

			// prevent PWM signal low in exceptional cases
			if(gPwmInfo[pwmId].ctrl.pwm_en)
			{
				regVal = REG_READ(0xC8602080);
				regVal = regVal & (~0x00000004);
				REG_WRITE(0xC8602080, regVal);
			}

			dvo_pwm0_ctrl0_reg = *dvo_pwm0_ctrl0;
			dvo_pwm0_ctrl1_reg = *dvo_pwm0_ctrl1;
			dvo_pwm0_ctrl2_reg = *dvo_pwm0_ctrl2;
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl0_reg, pwm0_en, gPwmInfo[pwmId].ctrl.pwm_en);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl0_reg, pwm0_freq_mode, gPwmInfo[pwmId].ctrl.pwm_freq_mode);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl0_reg, pwm0_resolution, gPwmInfo[pwmId].ctrl.pwm_resolution);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl0_reg, pwm0_inv, gPwmInfo[pwmId].ctrl.pwm_inv);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl0_reg, pwm0_sel, gPwmInfo[pwmId].ctrl.pwm_sel);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl0_reg, pwm0_width_falling_pos, gPwmInfo[pwmId].ctrl.pwm_width_falling_pos);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl1_reg, pwm0_free_width, gPwmInfo[pwmId].ctrl.pwm_free_width);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl2_reg, pwm0_method, gPwmInfo[pwmId].ctrl.pwm_method);
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl2_reg, pwm0_fc_h_disp, gPwmInfo[pwmId].ctrl.pwm_fc_h_disp);
			if(zeroDuty && (!gPwmInfo[pwmId].ctrl.pwm_fc_h_disp))
			{
				PE_PWM_H15_Wr01(dvo_pwm0_ctrl2_reg, pwm0_fc_l_disp, 1);
			}
			else
			{
				PE_PWM_H15_Wr01(dvo_pwm0_ctrl2_reg, pwm0_fc_l_disp, gPwmInfo[pwmId].ctrl.pwm_fc_l_disp);
			}
			*dvo_pwm0_ctrl0 = dvo_pwm0_ctrl0_reg;
			*dvo_pwm0_ctrl1 = dvo_pwm0_ctrl1_reg;
			*dvo_pwm0_ctrl2 = dvo_pwm0_ctrl2_reg;
		}
			break;
		case 1 :
		{
			H15A0_PE_PWM1_CTRL0 dvo_pwm1_ctrl0_reg;
			H15A0_PE_PWM1_CTRL1 dvo_pwm1_ctrl1_reg;
			H15A0_PE_PWM1_CTRL2 dvo_pwm1_ctrl2_Reg;

			// prevent PWM signal low in exceptional cases
			if(gPwmInfo[pwmId].ctrl.pwm_en)
			{
				regVal = REG_READ(0xC8602080);
				regVal = regVal & (~0x00000002);
				REG_WRITE(0xC8602080, regVal);
			}

			dvo_pwm1_ctrl0_reg = *dvo_pwm1_ctrl0;
			dvo_pwm1_ctrl1_reg = *dvo_pwm1_ctrl1;
			dvo_pwm1_ctrl2_Reg = *dvo_pwm1_ctrl2;
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl0_reg, pwm1_en, gPwmInfo[pwmId].ctrl.pwm_en);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl0_reg, pwm1_freq_mode, gPwmInfo[pwmId].ctrl.pwm_freq_mode);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl0_reg, pwm1_resolution, gPwmInfo[pwmId].ctrl.pwm_resolution);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl0_reg, pwm1_inv, gPwmInfo[pwmId].ctrl.pwm_inv);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl0_reg, pwm1_sel, gPwmInfo[pwmId].ctrl.pwm_sel);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl0_reg, pwm1_width_falling_pos, gPwmInfo[pwmId].ctrl.pwm_width_falling_pos);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl1_reg, pwm1_free_width, gPwmInfo[pwmId].ctrl.pwm_free_width);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl2_Reg, pwm1_method, gPwmInfo[pwmId].ctrl.pwm_method);
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl2_Reg, pwm1_fc_h_disp, gPwmInfo[pwmId].ctrl.pwm_fc_h_disp);
			if(zeroDuty && (!gPwmInfo[pwmId].ctrl.pwm_fc_h_disp))
			{
				PE_PWM_H15_Wr01(dvo_pwm1_ctrl2_Reg, pwm1_fc_l_disp, 1);
			}
			else
			{
				PE_PWM_H15_Wr01(dvo_pwm1_ctrl2_Reg, pwm1_fc_l_disp, gPwmInfo[pwmId].ctrl.pwm_fc_l_disp);
			}
			*dvo_pwm1_ctrl0 = dvo_pwm1_ctrl0_reg;
			*dvo_pwm1_ctrl1 = dvo_pwm1_ctrl1_reg;
			*dvo_pwm1_ctrl2 = dvo_pwm1_ctrl2_Reg;
		}
			break;
		case 2 :
		{
			H15A0_PE_PWM2_CTRL0 dvo_pwm2_ctrl0_reg;
			H15A0_PE_PWM2_CTRL1 dvo_pwm2_ctrl1_reg;
			H15A0_PE_PWM2_CTRL2 dvo_pwm2_ctrl2_reg;

			// prevent PWM signal low in exceptional cases
			if(gPwmInfo[pwmId].ctrl.pwm_en)
			{
				regVal = REG_READ(0xC8602080);
				regVal = regVal & (~0x00000040);
				REG_WRITE(0xC8602080, regVal);
			}

			dvo_pwm2_ctrl0_reg = *dvo_pwm2_ctrl0;
			dvo_pwm2_ctrl1_reg = *dvo_pwm2_ctrl1;
			dvo_pwm2_ctrl2_reg = *dvo_pwm2_ctrl2;
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl0_reg, pwm2_en, gPwmInfo[pwmId].ctrl.pwm_en);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl0_reg, pwm2_freq_mode, gPwmInfo[pwmId].ctrl.pwm_freq_mode);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl0_reg, pwm2_resolution, gPwmInfo[pwmId].ctrl.pwm_resolution);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl0_reg, pwm2_inv, gPwmInfo[pwmId].ctrl.pwm_inv);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl0_reg, pwm2_sel, gPwmInfo[pwmId].ctrl.pwm_sel);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl0_reg, pwm2_width_falling_pos, gPwmInfo[pwmId].ctrl.pwm_width_falling_pos);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl1_reg, pwm2_free_width, gPwmInfo[pwmId].ctrl.pwm_free_width);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl2_reg, pwm2_method, gPwmInfo[pwmId].ctrl.pwm_method);
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl2_reg, pwm2_fc_h_disp, gPwmInfo[pwmId].ctrl.pwm_fc_h_disp);
			if(zeroDuty && (!gPwmInfo[pwmId].ctrl.pwm_fc_h_disp))
			{
				PE_PWM_H15_Wr01(dvo_pwm2_ctrl2_reg, pwm2_fc_l_disp, 1);
			}
			else
			{
				PE_PWM_H15_Wr01(dvo_pwm2_ctrl2_reg, pwm2_fc_l_disp, gPwmInfo[pwmId].ctrl.pwm_fc_l_disp);
			}
			*dvo_pwm2_ctrl0 = dvo_pwm2_ctrl0_reg;
			*dvo_pwm2_ctrl1 = dvo_pwm2_ctrl1_reg;
			*dvo_pwm2_ctrl2 = dvo_pwm2_ctrl2_reg;
		}
			break;
		case 3 :
		{
			H15A0_PE_PWM3_CTRL0 dvo_pwm3_ctrl0_reg;

			dvo_pwm3_ctrl0_reg = *dvo_pwm3_ctrl0;
			PE_PWM_H15_Wr01(dvo_pwm3_ctrl0_reg, pwm3_en, gPwmInfo[pwmId].ctrl.pwm_en);
			PE_PWM_H15_Wr01(dvo_pwm3_ctrl0_reg, pwm3_freq_mode, gPwmInfo[pwmId].ctrl.pwm_freq_mode);
			*dvo_pwm3_ctrl0 = dvo_pwm3_ctrl0_reg;
		}
			break;
		default :
			BREAK_WRONG(pwmId);
	}

	return ret;
}

static int _REG_SetPwmMask(UINT32 pwmId)
{
	int ret = RET_OK;

	switch (pwmId) {
		case 0 :
		{
			H15A0_PE_PWM0_CTRL2 dvo_pwm0_ctrl2_Reg;

			dvo_pwm0_ctrl2_Reg = *dvo_pwm0_ctrl2;
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl2_Reg, pwm0_intr_mask, gPwmInfo[pwmId].mask);
			*dvo_pwm0_ctrl2 = dvo_pwm0_ctrl2_Reg;
		}
			break;
		case 1 :
		{
			H15A0_PE_PWM1_CTRL2 dvo_pwm1_ctrl2_reg;

			dvo_pwm1_ctrl2_reg = *dvo_pwm1_ctrl2;
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl2_reg, pwm1_intr_mask, gPwmInfo[pwmId].mask);
			*dvo_pwm1_ctrl2 = dvo_pwm1_ctrl2_reg;
		}
			break;
		case 2 :
		{
			H15A0_PE_PWM2_CTRL2 dvo_pwm2_ctrl2_reg;

			dvo_pwm2_ctrl2_reg = *dvo_pwm2_ctrl2;
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl2_reg, pwm2_intr_mask, gPwmInfo[pwmId].mask);
			*dvo_pwm2_ctrl2 = dvo_pwm2_ctrl2_reg;
		}
			break;
		default :
			BREAK_WRONG(pwmId);
	}

	return ret;
}

static int _REG_SetPwmWidth(UINT32 pwmId)
{
	int ret = RET_OK;

	switch (pwmId) {
		case 0 :
		{
			H15A0_PE_PWM0_CTRL1 dvo_pwm0_ctrl1_reg;

			dvo_pwm0_ctrl1_reg = *dvo_pwm0_ctrl1;
			PE_PWM_H15_Wr01(dvo_pwm0_ctrl1_reg, pwm0_free_width, gPwmInfo[pwmId].wdth);
			*dvo_pwm0_ctrl1 = dvo_pwm0_ctrl1_reg;
		}
			break;
		case 1 :
		{
			H15A0_PE_PWM1_CTRL1 dvo_pwm1_ctrl1_reg;

			dvo_pwm1_ctrl1_reg = *dvo_pwm1_ctrl1;
			PE_PWM_H15_Wr01(dvo_pwm1_ctrl1_reg, pwm1_free_width, gPwmInfo[pwmId].wdth);
			*dvo_pwm1_ctrl1 = dvo_pwm1_ctrl1_reg;
		}
			break;
		case 2 :
		{
			H15A0_PE_PWM2_CTRL1 dvo_pwm2_ctrl1_reg;

			dvo_pwm2_ctrl1_reg = *dvo_pwm2_ctrl1;
			PE_PWM_H15_Wr01(dvo_pwm2_ctrl1_reg, pwm2_free_width, gPwmInfo[pwmId].wdth);
			*dvo_pwm2_ctrl1 = dvo_pwm2_ctrl1_reg;
		}
			break;
		default :
			BREAK_WRONG(pwmId);
	}

	return ret;
}

static int _REG_SetPwmTiming(UINT32 pwmId)
{
	int ret = RET_OK;
	H15A0_PE_PWM0_V_R pwm0_v_r;
	H15A0_PE_PWM0_V_F pwm0_v_f;
	H15A0_PE_PWM0_V_SUB_R pwm0_v_sub_r;
	H15A0_PE_PWM0_V_SUB_F pwm0_v_sub_f;
	H15A0_PE_PWM1_V_R pwm1_v_r;
	H15A0_PE_PWM1_V_F pwm1_v_f;
	H15A0_PE_PWM1_V_SUB_R pwm1_v_sub_r;
	H15A0_PE_PWM1_V_SUB_F pwm1_v_sub_f;
	H15A0_PE_PWM2_V_R pwm2_v_r;
	H15A0_PE_PWM2_V_F pwm2_v_f;
	H15A0_PE_PWM2_V_SUB_R pwm2_v_sub_r;
	H15A0_PE_PWM2_V_SUB_F pwm2_v_sub_f;
	H15A0_PE_PWM_V_LOAD_WRITE pwm_v_load_write;

	switch (pwmId) {
		case 0 :
			pwm_v_load_write = *dvo_pwm_v_load_write;
			pwm_v_load_write.pwm0_v_we = gPwmInfo[pwmId].t1st.pwm_v_we;
			pwm_v_load_write.pwm0_v_sub_we = gPwmInfo[pwmId].t2nd.pwm_v_we;
			pwm_v_load_write.pwm0_v_sub_f_we = gPwmInfo[pwmId].t2nd.pwm_v_we;
			*dvo_pwm_v_load_write = pwm_v_load_write;

			pwm0_v_r = *dvo_pwm0_v_r;
			pwm0_v_f = *dvo_pwm0_v_f;
			pwm0_v_sub_r = *dvo_pwm0_v_sub_r;
			pwm0_v_sub_f = *dvo_pwm0_v_sub_f;
			pwm0_v_r.pwm0_v_r = gPwmInfo[pwmId].t1st.pwm_v_r;
			pwm0_v_r.pwm0_v_r_id = gPwmInfo[pwmId].t1st.pwm_v_id;
			pwm0_v_f.pwm0_v_f = gPwmInfo[pwmId].t1st.pwm_v_f;
			pwm0_v_f.pwm0_v_f_id = gPwmInfo[pwmId].t1st.pwm_v_id;
			pwm0_v_sub_r.pwm0_v_sub = gPwmInfo[pwmId].t2nd.pwm_v_r;
			pwm0_v_sub_r.pwm0_v_sub_id = gPwmInfo[pwmId].t2nd.pwm_v_id;
			pwm0_v_sub_f.pwm0_v_sub_f = gPwmInfo[pwmId].t2nd.pwm_v_f;
			pwm0_v_sub_f.pwm0_v_sub_f_id = gPwmInfo[pwmId].t2nd.pwm_v_id;
			*dvo_pwm0_v_r = pwm0_v_r;
			*dvo_pwm0_v_f = pwm0_v_f;
			*dvo_pwm0_v_sub_r = pwm0_v_sub_r;
			*dvo_pwm0_v_sub_f = pwm0_v_sub_f;
			break;
		case 1 :
			pwm_v_load_write = *dvo_pwm_v_load_write;
			pwm_v_load_write.pwm1_v_we = gPwmInfo[pwmId].t1st.pwm_v_we;
			pwm_v_load_write.pwm1_v_sub_we = gPwmInfo[pwmId].t2nd.pwm_v_we;
			pwm_v_load_write.pwm1_v_sub_f_we = gPwmInfo[pwmId].t2nd.pwm_v_we;
			*dvo_pwm_v_load_write = pwm_v_load_write;

			pwm1_v_r = *dvo_pwm1_v_r;
			pwm1_v_f = *dvo_pwm1_v_f;
			pwm1_v_sub_r = *dvo_pwm1_v_sub_r;
			pwm1_v_sub_f = *dvo_pwm1_v_sub_f;
			pwm1_v_r.pwm1_v_r = gPwmInfo[pwmId].t1st.pwm_v_r;
			pwm1_v_r.pwm1_v_r_id = gPwmInfo[pwmId].t1st.pwm_v_id;
			pwm1_v_f.pwm1_v_f = gPwmInfo[pwmId].t1st.pwm_v_f;
			pwm1_v_f.pwm1_v_f_id = gPwmInfo[pwmId].t1st.pwm_v_id;
			pwm1_v_sub_r.pwm1_v_sub = gPwmInfo[pwmId].t2nd.pwm_v_r;
			pwm1_v_sub_r.pwm1_v_sub_id = gPwmInfo[pwmId].t2nd.pwm_v_id;
			pwm1_v_sub_f.pwm1_v_sub_f = gPwmInfo[pwmId].t2nd.pwm_v_f;
			pwm1_v_sub_f.pwm1_v_sub_f_id = gPwmInfo[pwmId].t2nd.pwm_v_id;
			*dvo_pwm1_v_r = pwm1_v_r;
			*dvo_pwm1_v_f = pwm1_v_f;
			*dvo_pwm1_v_sub_r = pwm1_v_sub_r;
			*dvo_pwm1_v_sub_f = pwm1_v_sub_f;
			break;
		case 2 :
			pwm_v_load_write = *dvo_pwm_v_load_write;
			pwm_v_load_write.pwm2_v_we = gPwmInfo[pwmId].t1st.pwm_v_we;
			pwm_v_load_write.pwm2_v_sub_we = gPwmInfo[pwmId].t2nd.pwm_v_we;
			pwm_v_load_write.pwm2_v_sub_f_we = gPwmInfo[pwmId].t2nd.pwm_v_we;
			*dvo_pwm_v_load_write = pwm_v_load_write;

			pwm2_v_r = *dvo_pwm2_v_r;
			pwm2_v_f = *dvo_pwm2_v_f;
			pwm2_v_sub_r = *dvo_pwm2_v_sub_r;
			pwm2_v_sub_f = *dvo_pwm2_v_sub_f;
			pwm2_v_r.pwm2_v_r = gPwmInfo[pwmId].t1st.pwm_v_r;
			pwm2_v_r.pwm2_v_r_id = gPwmInfo[pwmId].t1st.pwm_v_id;
			pwm2_v_f.pwm2_v_f = gPwmInfo[pwmId].t1st.pwm_v_f;
			pwm2_v_f.pwm2_v_f_id = gPwmInfo[pwmId].t1st.pwm_v_id;
			pwm2_v_sub_r.pwm2_v_sub = gPwmInfo[pwmId].t2nd.pwm_v_r;
			pwm2_v_sub_r.pwm2_v_sub_id = gPwmInfo[pwmId].t2nd.pwm_v_id;
			pwm2_v_sub_f.pwm2_v_sub_f = gPwmInfo[pwmId].t2nd.pwm_v_f;
			pwm2_v_sub_f.pwm2_v_sub_f_id = gPwmInfo[pwmId].t2nd.pwm_v_id;
			*dvo_pwm2_v_r = pwm2_v_r;
			*dvo_pwm2_v_f = pwm2_v_f;
			*dvo_pwm2_v_sub_r = pwm2_v_sub_r;
			*dvo_pwm2_v_sub_f = pwm2_v_sub_f;
			break;
		default :
			BREAK_WRONG(pwmId);
	}

	return ret;
}
#endif
#endif
