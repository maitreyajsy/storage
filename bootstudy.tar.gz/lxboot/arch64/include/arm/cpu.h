#ifndef __ARCH_ARM_CPU_H__
#define __ARCH_ARM_CPU_H__


#define PRIMARY_CPU 			0x0
#define SECONDARY_CPU 			0x1
#define THIRD_CPU 				0x2
#define FOURTH_CPU 				0x3

#ifndef D_CACHE_LINE_SIZE
#define D_CACHE_LINE_SIZE 		64
#endif

/* struct regs index */
#define REGS_SP_OFFSET		(8*0)
#define REGS_LR_OFFSET		(8*1)
#define REGS_PC_OFFSET		(8*2)
#define REGS_SPSR_OFFSET	(8*3)
#define REGS_X0_OFFSET		(8*4)
#define REGS_X1_OFFSET		(8*5)
#define REGS_X2_OFFSET		(8*6)
#define REGS_X3_OFFSET		(8*7)


#ifdef __ASSEMBLY__
.macro get_cpuid, reg
    mrs 	\reg, mpidr_el1
    and 	\reg, \reg, #0xf
.endm

.macro	push, reg0, reg1
stp		\reg0, \reg1, [sp, #-16]!
.endm

.macro	pop, reg0, reg1
ldp		\reg0, \reg1, [sp], #16
.endm

lr 		.req 		x30
#else

typedef struct regs
{
	ulong 	sp,lr,pc;
	ulong 	spsr; /* value : 32bit, just align */
	ulong 	r[31];
} regs_t;

/* must do "always_inline & memory" when setup system register */

static inline __attribute__((always_inline)) unsigned int read_sctlr_el3(void)
{
	unsigned int value;
	asm volatile("mrs %0, sctlr_el3" : "=r" (value) :: "memory");
	return value;
}

/* must do "isb()" after write sctlr_register */
static inline __attribute__((always_inline)) void write_sctlr_el3(unsigned int value)
{
	asm volatile("msr sctlr_el3, %0" :: "r" (value) : "memory");
	asm volatile("isb" ::: "memory");
}

static inline __attribute__((always_inline)) void write_scr_el3(unsigned int value)
{
	asm volatile("msr scr_el3, %0" :: "r" (value) : "memory");
}

static inline __attribute__((always_inline)) void write_elr_el3(unsigned int value)
{
	asm volatile("msr elr_el3, %0" :: "r" (value) : "memory");
}

static inline __attribute__((always_inline)) void write_spsr_el3(unsigned int value)
{
	asm volatile("msr spsr_el3, %0" :: "r" (value) : "memory");
}

static inline __attribute__((always_inline)) uint32_t get_cpu_id(void)
{
	uint32_t id;
	asm volatile("mrs %0, mpidr_el1" : "=r" (id));
	id &= 0x0f;
	return id;
}

static inline __attribute__((always_inline)) void write_thread_id(ulong id)
{
	asm volatile("msr tpidr_el3, %0" :: "r" (id) : "memory");
}

static inline __attribute__((always_inline)) ulong get_thread_id(void)
{
	ulong id;
	asm volatile("mrs %0, tpidr_el3" : "=r" (id) :: "memory");
	return id;
}

static inline u32 arch_swap32(u32 x)
{
	asm volatile("rev32 %0, %1" : "=r" (x) : "r" (x));
	return x;
}

static inline u64 arch_swap64(u64 x)
{
	asm volatile("rev %0, %1" : "=r" (x) : "r" (x));
	return x;
}

#define isb() __asm__ __volatile__ ("isb" : : : "memory")
#define dsb() __asm__ __volatile__ ("dsb sy" : : : "memory")
#define dmb() __asm__ __volatile__ ("dmb ish" : : : "memory")

#define wfi() __asm__ __volatile__ ("wfi" : : : "memory")
#define wfe() __asm__ __volatile__ ("wfe" : : : "memory")
#define sev() __asm__ __volatile__ ("sev" : : : "memory")
#define sevl() __asm__ __volatile__ ("sevl" : : : "memory")

#endif	// __ASSEMBLY__

#endif	// __ARCH_ARM_CPU_H__
