#ifndef __ARCH_ARM_ATOMIC_H_
#define __ARCH_ARM_ATOMIC_H_


#define ATOMIC_READ(ptr) 		(*(volatile int32_t *)&(ptr)->a_val)
#define ATOMIC64_READ(ptr) 		(*(volatile int64_t *)&(ptr)->a_val)

typedef struct
{
	int32_t a_val;
}atomic_t;

typedef struct
{
	int64_t a_val;
}atomic64_t;



/********************************************
 *	val = *ptr;
 *	if(val == old){ *ptr = new;}
 *	return val;
 *********************************************/
static inline __attribute__((always_inline)) 
	int32_t atomic_compare_n_change(int32_t old, int32_t new, volatile int32_t *ptr)
{
	int32_t res, val;

	dmb();
	asm volatile (
      "1:  ldxr %w0, [%4]\n"
      "    cmp %w2, %w0\n"
      "    b.ne 2f\n"
      "    stxr %w1, %3, [%4]\n"
      "    cbnz  %1, 1b\n"
      "2:"
	: "=&r" (val), "=&r" (res) : "r" (old), "r" (new), "r" (ptr)
    : "cc", "memory");

	dmb();

	return val;
}

/********************************************
 * val = *ptr; *ptr = new;
 * return val;
 ********************************************/
static inline __attribute__((always_inline)) 
	int32_t atomic_swap(int32_t new, volatile int32_t *ptr)
{
	int32_t res, val;

	asm volatile(
      "1:  ldxr %w0, [%3]\n"
      "    stxr %w1, %w2, [%3]\n"
      "    cbnz %w1, 1b\n"
	: "=&r" (val), "=&r" (res) : "r" (new), "r" (ptr)
	: "cc", "memory");

	//TODO : remove dmb() ???
	dmb();

	return val;
}

/*
 * atomic dec
 */
static inline __attribute__((always_inline)) 
	int32_t atomic_dec(atomic_t *ptr)
{
	int32_t res, val;

	asm volatile(
	"1:  ldxr %w1, [%2]\n"
	"    sub %w1, %w1, #1\n"
	"    stxr %w0, %w1, [%2]\n"
	"    cbnz %w0, 1b"
	: "=&r" (res), "=&r" (val) : "r" (&ptr->a_val)
	: "cc", "memory");

	//TODO : remove dmb() ???
	dmb();
	return val;
}

/*
 * atomic inc
 */
static inline __attribute__((always_inline)) 
	int32_t atomic_inc(atomic_t *ptr)
{
	int32_t res, val;

	asm volatile(
	"1:  ldxr %w1, [%2]\n"
	"    add %w1, %w1, #1\n"
	"    stxr %w0, %w1, [%2]\n"
	"    cbnz %w0, 1b"
	: "=&r" (res), "=&r" (val) : "r" (&ptr->a_val)
	: "cc", "memory");

	//TODO : remove dmb() ???
	dmb();
	return val;
}

/*
 * atomic64_dec
 */
static inline __attribute__((always_inline)) 
	int64_t atomic64_dec(atomic64_t *ptr)
{
	int64_t res, val;

	asm volatile(
	"1:  ldxr %1, [%2]\n"
	"    sub %1, %1, #1\n"
	"    stxr %w0, %1, [%2]\n"
	"    cbnz %w0, 1b"
	: "=&r" (res), "=&r" (val) : "r" (&ptr->a_val)
	: "cc", "memory");

	//TODO : remove dmb() ???
	dmb();
	return val;
}

/*
 * atomic inc
 */
static inline __attribute__((always_inline)) 
	int64_t atomic64_inc(atomic64_t *ptr)
{
	int64_t res, val;

	asm volatile(
	"1:  ldxr %1, [%2]\n"
	"    add %1, %1, #1\n"
	"    stxr %w0, %1, [%2]\n"
	"    cbnz %w0, 1b"
	: "=&r" (res), "=&r" (val) : "r" (&ptr->a_val)
	: "cc", "memory");

	//TODO : remove dmb() ???
	dmb();
	return val;
}

#endif /* __ARCH_ATOMIC_H_ */
