#!/bin/sh

if [ -z $1 ]; then
	echo "Enter target directory"
	exit 1
fi

hostname=`hostname`
trans_serverip=${PROD_TRANS_SERVER}
transferred_lists=`cat $1/changed_file_list.txt`

if [ "${trans_serverip}" != "" ]; then
	if	 [ "${trans_serverip}" == "165.186.175.92" ]; then
		trans_hostname="swfarm-trans-s1"
		trans_servername="���� �߰輭��(${trans_hostname} : ${trans_serverip})"
	elif [ "${trans_serverip}" == "165.186.175.93" ]; then
		trans_hostname="swfarm-trans-s2"
		trans_servername="���� �߰輭��(${trans_hostname} : ${trans_serverip})"
	elif [ "${trans_serverip}" == "156.147.69.80" ]; then
		trans_hostname="swfarm-trans"
		trans_servername="���� �߰輭��(${trans_hostname} : ${trans_serverip})"
	elif [ "${trans_serverip}" == "156.147.69.81" ]; then
		trans_hostname="swfarm-trans1"
		trans_servername="���� �߰輭��(${trans_hostname} : ${trans_serverip})"
	elif [ "${trans_serverip}" == "156.147.69.82" ]; then
		trans_hostname="swfarm-trans2"
		trans_servername="���� �߰輭��(${trans_hostname} : ${trans_serverip})"
	fi	
else
	case ${hostname} in
		swfarm-l[1-3] )
			trans_hostname="swfarm-trans1"
			;;
		swfarm-l[7-9] )
			trans_hostname="swfarm-trans1"
			;;
		swfarm-l[4-6] )
			trans_hostname="swfarm-trans"
			;;
		swfarm-l10 )
			trans_hostname="swfarm-trans"
			;;
		swfarm-l11 )
			trans_hostname="swfarm-trans"
			;;
		swfarm-l12 )
			trans_hostname="swfarm-trans"
			;;
		swfarm-l13 )
			trans_hostname="swfarm-trans2"
			;;
		swfarm-l14 )
			trans_hostname="swfarm-trans2"
			;;
		swfarm-l15 )
			trans_hostname="swfarm-trans2"
			;;
		swfarm-l16 )
			trans_hostname="swfarm-trans2"
			;;
		swfarm-l17 )
			trans_hostname="swfarm-trans2"
			;;
		swfarm-l18 )
			trans_hostname="swfarm-trans2"
			;;
	esac		

	trans_serverip=`getip ${trans_hostname} | grep 'IP Address' | cut -d: -f2 | sed -e "s/^[ ]//g"`
	trans_servername="���� �߰輭��(${trans_hostname} : ${trans_serverip})"
fi

for list in ${transferred_lists}; do
	echo -ne "[1;33m[${list}][0;39m\n"
done

if [ "${transferred_lists}" != "" ]; then
	echo -ne "[1;32m<<< ���� ���ϵ��� ${trans_servername} �� $1 �� ���۵˴ϴ�!![0;39m\n"
fi
