#if !defined(CONFIG_ARCH)
	#error CONFIG_ARCH is not defined !!!
#endif


#if (CONFIG_ARCH == ARCH_LG1210)
#include "shadow_header_h15.c"
#elif (CONFIG_ARCH == ARCH_LG1312)
#include "shadow_header_m16.c"
#else
#error "Not supported arch ..."
#endif

