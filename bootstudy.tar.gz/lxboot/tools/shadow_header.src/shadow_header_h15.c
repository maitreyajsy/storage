#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define error_exit(fmt, args...)	\
	do {	\
		fprintf(stderr, "\x1b[31m"fmt"\x1b[0m", ##args); \
		exit(-1); \
	} while(0)

#define error(fmt, args...)	\
	do{fprintf(stderr, fmt, ##args);} while(0)

#if 0
#define debug(fmt, args...) 	printf(fmt, ##args);
#else
#define debug(fmt, args...)
#endif

#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))

#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3

typedef struct
{
	uint32_t	opcode;
	uint32_t	operand;
} reg_param_t;

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

static FILE* file_open(const char *name, const char *mode)
{
	FILE		*file;

	file = fopen(name, mode);
	if(file == NULL) error_exit("Can't open file '%s'\n", name);

	return file;
}

static int file_write(FILE* file, const void* buf, int size)
{
	int res;
	if((res = fwrite(buf, 1, size, file)) != size)
		error_exit("Can't write file !\n");
	return res;
}

static int file_read(FILE* file, void* buf, int size)
{
	int res;
	if((res = fread(buf, 1, size, file)) < 0)
		error_exit("Can't read file !\n");
	return res;
}

static int file_seek(FILE* file, long offset, int whence)
{
	if(fseek(file, offset, whence) != 0)
		error_exit("Can't seek file !\n");
	return 0;
}

static int file_close(FILE* file)
{
	return fclose(file);
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

// A0 header
#include "top.h"
#include "lm.h"
#include "gm.h"
#include "em.h"

#include "bus_gating.h"
#include "bus_manager.h"

#include "lm_exit.h"
#include "gm_exit.h"
#include "em_exit.h"

#include "lm_exit_post.h"
#include "gm_exit_post.h"
#include "em_exit_post.h"

#include "top_post.h"

// B0 header
#include "top_b0.h"
#include "lm_b0.h"
#include "gm_b0.h"
#include "em_b0.h"

#include "bus_gating_b0.h"
#include "bus_manager_b0.h"

#include "lm_exit_b0.h"
#include "gm_exit_b0.h"
#include "em_exit_b0.h"

#include "lm_exit_post_b0.h"
#include "gm_exit_post_b0.h"
#include "em_exit_post_b0.h"

#include "top_post_b0.h"

// DDR4 Hynix
#include "top_ddr4_sk.h"
#include "lm_ddr4_sk.h"
#include "gm_ddr4_sk.h"
#include "em_ddr4_sk.h"

#include "bus_gating_ddr4_sk.h"
#include "bus_manager_ddr4_sk.h"

#include "lm_exit_ddr4_sk.h"
#include "gm_exit_ddr4_sk.h"
#include "em_exit_ddr4_sk.h"

#include "lm_exit_post_ddr4_sk.h"
#include "gm_exit_post_ddr4_sk.h"
#include "em_exit_post_ddr4_sk.h"

#include "top_post_ddr4_sk.h"


#define REG_PARAM_SET_NUM		3
#define REG_PARAM_ELEMENT_NUM	13

typedef struct 
{
	char 			*name;
	uint32_t 		size;
	reg_param_t 	*obj;
}shb_t;


shb_t shb[REG_PARAM_SET_NUM][REG_PARAM_ELEMENT_NUM] =
{
	{
#define cmt(s)	{#s, sizeof(s##_cmm), s##_cmm, }
		cmt(top),
		cmt(lm),
		cmt(gm),
		cmt(em),
		cmt(lm_exit),
		cmt(gm_exit),
		cmt(em_exit),
		cmt(lm_exit_post),
		cmt(gm_exit_post),
		cmt(em_exit_post),
		cmt(bus_gating),
		cmt(bus_manager),
		cmt(top_post),
#undef cmt
	},

	{
#define cmt(s)	{#s, sizeof(s##_b0_cmm), s##_b0_cmm, }
		cmt(top),
		cmt(lm),
		cmt(gm),
		cmt(em),
		cmt(lm_exit),
		cmt(gm_exit),
		cmt(em_exit),
		cmt(lm_exit_post),
		cmt(gm_exit_post),
		cmt(em_exit_post),
		cmt(bus_gating),
		cmt(bus_manager),
		cmt(top_post),
#undef cmt
	},
	
	{
#define cmt(s)	{#s, sizeof(s##_ddr4_sk_cmm), s##_ddr4_sk_cmm, }
		cmt(top),
		cmt(lm),
		cmt(gm),
		cmt(em),
		cmt(lm_exit),
		cmt(gm_exit),
		cmt(em_exit),
		cmt(lm_exit_post),
		cmt(gm_exit_post),
		cmt(em_exit_post),
		cmt(bus_gating),
		cmt(bus_manager),
		cmt(top_post),
#undef cmt
	},

};


/* 
 * soc setup header binary struct
 * name[16]
 * size[4]
 * content[size]
 * padding[x] <- align 8*byte
 *
 */
static void soc_setup_bin(const char *fname)
{
#define NAME_LENGTH 16
	int i,j,s;
	FILE *file;
	char name[NAME_LENGTH] = {0,};
	uint32_t size = 0;
	uint32_t wr_size = 0;
	uint32_t wr_size_sum = 0;
	const uint32_t align_size = 16;
	const uint32_t chip_align = 16*1024;//16kB
	char dummy[1] = {0};

	debug("target file : %s\n", fname);
	
	file = file_open(fname, "w+");

	wr_size_sum = 0;

	for(s = 0; s < REG_PARAM_SET_NUM; s++)
	{
		for(i = 0; i < REG_PARAM_ELEMENT_NUM; i++)
		{
			uint32_t temp;
			wr_size = 0;
			memset(name, 0, NAME_LENGTH);
			snprintf(name, 16, "%s", shb[s][i].name);
			wr_size += file_write(file, name, NAME_LENGTH);
			wr_size += file_write(file, &shb[s][i].size, sizeof(shb[s][i].size));
			wr_size += file_write(file, shb[s][i].obj, shb[s][i].size);

			temp = align_size - (wr_size%align_size);
			for(j = 0; j < temp; j++)
				wr_size += file_write(file, dummy, 1);

			wr_size_sum += wr_size;
		}
		debug("wr sum %d\n", wr_size_sum);

		wr_size = 0;
		for(j = 0; j < chip_align - (wr_size_sum%chip_align); j++)
			wr_size += file_write(file, dummy, 1);

		wr_size_sum += wr_size;
		debug("wr sum %d\n", wr_size_sum);
	}

	file_close(file);
}



int main(int argc, char **argv)
{
	
	if(argc != 2)
	{
		error("wrong parameters\n");
		return -1;
	}

	soc_setup_bin(argv[1]);

	return 0;
}
