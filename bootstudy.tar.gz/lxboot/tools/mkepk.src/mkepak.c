/******************************************************************************
	Include Files
*******************************************************************************/
#include <stdio.h>
#include <sys/mount.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/msg.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <pthread.h>
#include <unistd.h>
#include "mkepak.h"

/******************************************************************************
	Constant & Type Definition
*******************************************************************************/
//#define DEBUG


#ifdef  DEBUG
#define PRINTF(x) printf x;
#else
#define PRINTF(x)
#endif

#undef BIG_ENDIAN
#ifdef BIG_ENDIAN
#define SWAP32(x)	((x & 0x000000FF) << 24) | ((x & 0x0000FF00) << 8) | \
					((x & 0x00FF0000) >> 8) | ((x & 0xFF000000) >> 24)
#else
#define SWAP32(x)	x
#endif

#define CRC32_POLY		0x04c11db7		/* AUTODIN II, Ethernet, & FDDI */
#define VALID_PAK_ARG	10

/******************************************************************************
	Global Variables and Functions
*******************************************************************************/

CREATE_OPT_T	option;
UINT32			crc32_table[256];
/******************************************************************************
	Static Variables and Functions
*******************************************************************************/
#if 0
static char	*CS[] = {   /* color    : index: Value      */
			"\x1b[30m",         /* blac[k]  :    0 : 30         */
			"\x1b[31m",         /* [r]ed    :    1 : 31         */
			"\x1b[32m",         /* [g]reen  :    2 : 32         */
			"\x1b[33m\x1b[40m", /* [y]ellow :    3 : 33         */
			"\x1b[34m",         /* [b]lue   :    4 : 34         */
			"\x1b[35m",         /* [p]urple :    5 : 35         */
			"\x1b[36m",         /* [c]yan   :    6 : 36         */
			"\x1b[37m",         /* gr[a]y   :    7 : 37==0 -> x */
			"\x1b[37m\x1b[40m", /* blac[K]  :    0 : 40         */
			"\x1b[37m\x1b[41m", /* [R]ed    :    1 : 41         */
			"\x1b[30m\x1b[42m", /* [G]reen  :    2 : 42         */
			"\x1b[30m\x1b[43m", /* [Y]ellow :    3 : 43         */
			"\x1b[37m\x1b[44m", /* [B]lue   :    4 : 44         */
			"\x1b[37m\x1b[45m", /* [P]urple :    5 : 45         */
			"\x1b[30m\x1b[46m", /* [C]yan   :    6 : 46         */
			"\x1b[37m\x1b[40m", /* gr[A]y   :    7 : 47==0 -> x */
			"\x1b[0m"           /* Reset  : Reset fg coloring */
			};
#endif
#define CRED 		"\x1b[31m"
#define CGREEN		"\x1b[32m"
#define CRST		"\x1b[0m"
#define CBLUE		"\x1b[34m"
#define CYAN		"\x1b[36m"
#define CYELLOW		"\x1b[33m\x1b[40m"
#define cprintf printf(CRST);printf

#define ERR_OPEN	CRED"\n   - %s open fail\n"
#define ERR_READ	CRED"\n   - %s read fail\n"
#define ERR_WRITE	CRED"\n   - %s write fail\n"
#define ERR_ARG		CRED"\n   - %d is wrong argnum\n"
#define ERR_UNKNOW CRED"\n   - %s is unknown %s\n"
/******************************************************************************
	Help & Info Print Function
*******************************************************************************/
void print_help ()
{
	cprintf (CYAN"[Extended PAK Utility]\n");
	cprintf ("   mkepk -c <dst.pak> <app.img> <ImageType> <MODEL_NAME> <APP Ver> <Date> <LoadAddr> <DEV_MODE>\n");
	cprintf ("   mkepk -d <dst.img> <src.pak>\n");
	cprintf ("   mkepk -m <EPK Ver> <OTA ID> <dst.epk> <src_1.pak> <src_2.pak> ... <src_n.pak>\n");
	cprintf ("   mkepk -u <dst.epk>\n");
	cprintf ("   mkepk -i <src.epk|src.pak>\n");
}

/******************************************************************************
	argument�� �Ѿ�� file type�� ��������� �����ϴ� �Լ�
*******************************************************************************/

/******************************************************************************
	CRC Check Function
*******************************************************************************/
static void init_crc32(void)
{
	int		i, j;
	UINT32	c;

	for (i = 0; i < 256; ++i) {
		for (c = i << 24, j = 8; j > 0; --j)
			c = c & 0x80000000 ? (c << 1) ^ CRC32_POLY : (c << 1);
			crc32_table[i] = c;
	}
}
UINT32 calccrc32(unsigned char *buf, UINT32 len)
{

	unsigned char	*p;
	UINT32			crc;

	if (!crc32_table[1])    /* if not already done, */
		init_crc32();   	/* build table */

	crc = 0xffffffff;       /* preload shift register, per CRC-32 spec */

	for (p = buf; len > 0; ++p, --len)
		crc = (crc << 8) ^ crc32_table[(crc >> 24) ^ *p];

	return(crc);
//	return ~crc;            /* transmit complement, per CRC-32 spec */
}

static void* _malloc(size_t size)
{
	void* m = malloc(size);
	if(m == NULL)
	{
		fprintf(stderr, "can't alloc mem - %ubytes\n", size);
		exit(-1);
	}
	return m;
}
/******************************************************************************
	Create Pak Function
*******************************************************************************/
int create_pak(int argc, char *argv[])
{
	int		readfd, writefd;
	char	dst_path[FILE_PATH_LEN];
	char	src_path[FILE_PATH_LEN];
	UINT32	version;
	UINT32	t_version;
	UINT32	imgSize;
	UINT32	t_CRC;
	UINT32	loadAddr;
	UINT32	t_loadAddr;
	UINT32	swDate;
	UINT32	t_swDate;
	UINT32	CRC;
	UINT32	magic;
	PAK_HEADER_T pak_header;
	unsigned char *buf;
	unsigned char *ptr;

	cprintf(CYAN"[Pak Information]\n");
	if (argc != VALID_PAK_ARG)
	{
		cprintf (ERR_ARG,argc);
		return -1;
	}

	strcpy(dst_path, argv[2]);
	strcpy(src_path, argv[3]);
	strncpy(pak_header.imageType, argv[4], 4);
	strcpy(pak_header.modelName, argv[5]);

	t_version	= strtoul(argv[6], NULL, 16);
	version		= SWAP32(t_version);
	memcpy(&(pak_header.swVersion), &version, sizeof(UINT32));

	t_swDate = strtoul(argv[7], NULL, 16);
	swDate = SWAP32(t_swDate);
	memcpy(&(pak_header.swDate), &swDate, sizeof(UINT32));

	t_loadAddr = strtoul(argv[8], NULL, 16);
	loadAddr = SWAP32(t_loadAddr);
	memcpy(&(pak_header.loadAddr), &loadAddr, sizeof(UINT32));

	if		(!strcmp ("RELEASE",	argv[9]))
		pak_header.devMode = SWAP32(0);
	else if (!strcmp ("DEBUG",		argv[9]))
		pak_header.devMode = SWAP32(1);
	else if (!strcmp ("TEST",		argv[9]))
		pak_header.devMode = SWAP32(2);
	else
	{
		cprintf (ERR_UNKNOW,argv[8],"mode");
		return -1 ;
	}

	magic = SWAP32(PAK_HDR_MAGIC);
	memcpy(&(pak_header.magic_number), &magic, sizeof(UINT32));

	cprintf ("   DST["CGREEN"%s"CRST"]\n",dst_path);
	cprintf ("   SRC["CGREEN"%s"CRST"]\n",src_path);
	cprintf ("   VER["CGREEN"0x%.4x"CRST"] MODE["CGREEN"%s"CRST"] LOAD["CGREEN"%s"CRST"] DATE["CGREEN"0x%.6x"CRST"]",
					t_version, argv[9], argv[8], t_swDate);
#if 0
	cprintf ("\n     - Dest File    : %s",		dst_path);
	cprintf ("\n     - Src File     : %s",		src_path);
	cprintf ("\n     - Version      : 0x%4x",	t_version);
	cprintf ("\n     - Dev Mode     : %s",		argv[8]);
#if 1
	cprintf ("\n     - Date         : 0x%6x",	t_swDate);
#else
	cprintf ("\n     - Date\t\t: %.2x/%.2x/%.2x",year,mon,date);
#endif
#endif
	if ((readfd = open(src_path, O_RDONLY|O_SYNC, 0)) == -1)
	{
		cprintf (ERR_OPEN,src_path);
		return -1;
	}

	if ((writefd = open(dst_path, O_WRONLY|O_CREAT|O_SYNC|O_TRUNC, 0666)) == -1)
	{
		cprintf (ERR_OPEN, dst_path);

		close (readfd);
		return -1;
	}

	imgSize	 				= lseek(readfd, 0, SEEK_END);
	pak_header.imageSize	= SWAP32(imgSize);

	buf = ptr = malloc(sizeof(PAK_HEADER_T)+imgSize+4/*crc*/);

	lseek(readfd, 0, SEEK_SET);
	memcpy(ptr, &pak_header, sizeof(PAK_HEADER_T));

	ptr += sizeof(PAK_HEADER_T);

	if (read (readfd, ptr, imgSize) != imgSize)
	{
		cprintf (ERR_READ,src_path);

		close(readfd);
		close(writefd);
		return -1;
	}

	t_CRC	= calccrc32(ptr, imgSize);
	CRC		= SWAP32(t_CRC);
	cprintf (" SIZE["CGREEN"0x%.8x"CRST"] CRC["CGREEN"0x%.8x"CRST"]\n",imgSize,t_CRC);

	ptr += imgSize;
	memcpy(ptr, &CRC, sizeof(UINT32));

	lseek(writefd, 0, SEEK_SET);

	if (write (writefd, buf, (sizeof(PAK_HEADER_T)+imgSize+4/*crc*/)) != (sizeof(PAK_HEADER_T)+imgSize+4/*crc*/))
	{
		cprintf (ERR_WRITE,dst_path);

		close(readfd);
		close(writefd);
		return -1 ;
	}
	close(readfd);
	close(writefd);
	return 0 ;
}

int uncomp_pak(int argc, char *argv[])
{
	char src_path[FILE_PATH_LEN];
	char dst_path[FILE_PATH_LEN];
	PAK_HEADER_T	pak_header;
	int  readfd ,writefd;
	unsigned char	*readbuf;
	UINT32			imgSize;

	if (argc !=4)
	{
		cprintf (ERR_ARG,argc);
		return -1;
	}

	strcpy(src_path, argv[3]);
	strcpy(dst_path, argv[2]);
	cprintf ("   SRC["CGREEN"%s"CRST"]\n",src_path);
	cprintf ("   DST["CGREEN"%s"CRST"]\n",dst_path);

	if ((readfd = open(src_path, O_RDONLY|O_SYNC, 0)) == -1)
	{
		cprintf (ERR_OPEN,src_path);
		return -1;
	}

	if (read(readfd, &pak_header, sizeof(pak_header)) != sizeof(pak_header))
	{
		cprintf (ERR_READ,src_path);

		close(readfd);
		return -1;
	}

	//Check format
	if(pak_header.magic_number != SWAP32(PAK_HDR_MAGIC))
	{
		cprintf (ERR_UNKNOW,src_path,"format");
		close(readfd);
		return -1;
	}

	imgSize = SWAP32(pak_header.imageSize);
	cprintf ("   TYPE["CGREEN"%.4s"CRST"] MODEL["CGREEN"%s"CRST"] SIZE["CGREEN"%d"CRST"]\n", pak_header.imageType, pak_header.modelName, imgSize);
	cprintf ("   VER["CGREEN"0x%.4x"CRST"] MODE["CGREEN"%s"CRST"] LOAD["CGREEN"0x%08x"CRST"] DATE["CGREEN"0x%.6x"CRST"]\n",
					SWAP32(pak_header.swVersion),
					SWAP32(pak_header.devMode) ? "DEBUG" : "RELEASE",
					SWAP32(pak_header.loadAddr),
					SWAP32(pak_header.swDate));

	readbuf  = (unsigned char *)_malloc(imgSize);
	if(read (readfd, readbuf, imgSize) != imgSize)
	{
		cprintf (ERR_READ,src_path);
		close(readfd);
		return -1;
	}

	if ((writefd = open(dst_path, O_WRONLY|O_CREAT|O_SYNC, 0666)) == -1)
	{
		cprintf (ERR_OPEN, dst_path);
		return -1;
	}

	if (write (writefd, readbuf, imgSize)	!= imgSize)
	{
		cprintf (ERR_OPEN, dst_path);
		close(writefd);
		return -1 ;
	}

	close(writefd);
	return 0;

}

int uncomp_epk(int argc, char *argv[])
{
	int  i;
	int  readfd ,writefd;
	char src_path[FILE_PATH_LEN];
	char imagetype[PAK_TYPE_ID_LEN+1];
	char filename[128];
	UINT32			fileNum;
	UINT32			imgSize;
	UINT32			imgOffset;
	UINT32			version;
	UINT32			devMode;
	EPK_HEADER_T	epk_header;
	PAK_LOCATION_T	*imageLocation;
	PAK_HEADER_T	*pak_header;
	UINT8			*buf;

	cprintf(CYELLOW"[EPK UnPacking]\n");

	if (argc !=3)
	{
		cprintf (ERR_ARG,argc);
		return -1;
	}

	strcpy(src_path, argv[2]);
	cprintf ("   SRC["CGREEN"%s"CRST"]\n",src_path);

	if ((readfd = open(src_path, O_RDONLY|O_SYNC, 0)) == -1)
	{
		cprintf (ERR_OPEN,src_path);
		return -1;
	}

	if (read(readfd, &epk_header, sizeof(epk_header)) != sizeof(epk_header))
	{
		cprintf (ERR_READ,src_path);
		close(readfd);
		return -1;
	}

	if(memcmp(epk_header.fileType, "epak", 4))
	{
		cprintf (ERR_UNKNOW,src_path,"format");
		close(readfd);
		return -1;
	}
	cprintf ("   EPAK VER["CGREEN"0x%4x"CRST"]\n",SWAP32(epk_header.epkVersion));

	fileNum	= SWAP32(epk_header.fileNum);
	imgSize = sizeof(PAK_LOCATION_T) * fileNum;
	imageLocation = (PAK_LOCATION_T*)_malloc(imgSize);
	if (read(readfd, imageLocation, imgSize) != imgSize)
	{
		cprintf (ERR_READ,src_path);
		close(readfd);
		return -1;
	}

	for (i = 0; i < fileNum; i++)
	{
		imgSize	= SWAP32(imageLocation[i].imageSize);
		if (imgSize)
		{
			imgOffset	=	SWAP32(imageLocation[i].imageOffset);
			if(lseek(readfd, imgOffset, SEEK_SET) != imgOffset)
			{
				cprintf (ERR_READ,src_path);
				close(readfd);
				return -1;
			}
			buf = (UINT8*)_malloc(imgSize);

			if(read (readfd, buf, imgSize) != imgSize)
			{
				cprintf (ERR_READ,src_path);
				close(readfd);
				return -1;
			}
			pak_header = (PAK_HEADER_T*)buf;

			version		=	SWAP32(pak_header->swVersion);
			devMode		=	SWAP32(pak_header->devMode);
			strncpy(imagetype, pak_header->imageType, PAK_TYPE_ID_LEN);
			imagetype[PAK_TYPE_ID_LEN] = '\0';

			if (!devMode)
				sprintf(filename, "%s-%s-%s-0x%04x.pak", imagetype, pak_header->modelName, "RELEASE", version);
			else
				sprintf(filename, "%s-%s-%s-0x%04x.pak", imagetype, pak_header->modelName, "DEBUG",   version);

			cprintf ("   ["CGREEN"%.2d"CRST"]PAK["CGREEN"%s"CRST"]\n",i+1,filename);

			if ((writefd = open(filename, O_WRONLY|O_CREAT|O_SYNC, 0666)) == -1)
			{
				cprintf (ERR_OPEN,filename);
				return -1;
			}

			if (write (writefd, buf, imgSize)	!= imgSize)
			{
				cprintf (ERR_OPEN, filename);
				close(writefd);
				return -1 ;
			}
			close(writefd);
			free(buf);
		}
	}
	free(imageLocation);
	close(readfd);

	return 0 ;
}

const char padStr[] = "\0\0\0\0";
int create_epk(int argc, char * argv[])
{
	int  			i;
	char 			* buf;
	char 			dst_path[FILE_PATH_LEN];
	char 			src_path[FILE_PATH_LEN];
	char 			filetype[PAK_TYPE_ID_LEN+1];
	int	 			readfd, writefd;
	UINT32			fileNum;
	UINT32			imgOffset;
	UINT32			imgSize;
	UINT32			fileSize = 0;
	UINT32			epkVer;
	EPK_HEADER_T	*epk_header;
	UINT32			epkHeaderSize;
	UINT32			padCnt;
	unsigned long	size;
	cprintf(CYELLOW"[EPK Information]\n");

	if (argc < 6)
	{
		cprintf (ERR_ARG,argc);
		return -1 ;
	}

	fileNum = argc - 5;
	epkHeaderSize = sizeof(EPK_HEADER_T) + sizeof(PAK_LOCATION_T)*(fileNum+1);	// why +1 ? sync with HE

	epk_header = (EPK_HEADER_T*)_malloc(epkHeaderSize);
	memset(epk_header, 0, epkHeaderSize);

	strcpy(epk_header->ota_id, argv[3]);
	strcpy(dst_path, argv[4]);
	strncpy(epk_header->fileType, "epak", 4);

	epk_header->fileNum			= SWAP32(fileNum);

	if ((writefd = open(dst_path, O_WRONLY|O_CREAT|O_SYNC|O_TRUNC, 0666)) == -1)
	{
		cprintf (ERR_OPEN, dst_path);
		return -1;
	}

	if (write(writefd, epk_header, epkHeaderSize) != epkHeaderSize)
	{
		cprintf (ERR_WRITE, dst_path);

		close(writefd);
		return -1 ;
	}


	cprintf ("   DST["CGREEN"%s"CRST"]\n",dst_path);
	for (i = 0; i < fileNum; i++)
	{
		strcpy(src_path, argv[i+5]);

		if ((readfd = open(src_path, O_RDONLY|O_SYNC,0)) == -1)
		{
			cprintf (ERR_OPEN,src_path);
			return -1;
		}

		cprintf ("   ["CGREEN"%.2d"CRST"]SRC["CGREEN"%s"CRST"]\n",i+1,src_path);

		if (read (readfd, filetype, 4) == -1)
		{
			cprintf (ERR_READ,src_path);
			return -1;
		}

		filetype[PAK_TYPE_ID_LEN] = '\0';

		imgOffset	= lseek(writefd, 0, SEEK_CUR);
		imgSize		= lseek(readfd,  0, SEEK_END);
		padCnt 		= imgOffset % 4;
		if(padCnt > 0)
		{
			padCnt = 4 - padCnt;
			if (write(writefd, padStr, padCnt) != padCnt)
			{
				cprintf (ERR_WRITE,dst_path);

				close(readfd);
				close(writefd);
				return -1 ;
			}
			imgOffset += padCnt;
		}

		epk_header->imageLocation[i].imageOffset	= SWAP32(imgOffset);
		epk_header->imageLocation[i].imageSize		= SWAP32(imgSize);

		lseek(readfd, 0, SEEK_SET);
		size = epk_header->imageLocation[i].imageSize;
		buf = _malloc(size);

		if (read(readfd, buf, size)!=size)
		{
			cprintf (ERR_READ,src_path);
			close(readfd);
			close(writefd);
			return -1;
		}
		if( write(writefd, buf, size) != size)
		{
			cprintf (ERR_WRITE,dst_path);
			close(readfd);
			close(writefd);
			return -1;
		}
		free(buf);

		cprintf ("       TYPE["CGREEN"%s"CRST"] SIZE["CGREEN"0x%.8x"CRST"] OFFSET["CGREEN"0x%.8x"CRST"]\n",filetype,imgSize,imgOffset);


		fileSize += imgSize;

		close(readfd);
	}

	epk_header->fileSize	= SWAP32(fileSize);
	epkVer					= strtoul (argv[2],NULL,16);
	epk_header->epkVersion	= SWAP32(epkVer);

	lseek(writefd, 0, SEEK_SET);

	if (write(writefd, epk_header, epkHeaderSize) != epkHeaderSize)
	{
		cprintf (ERR_WRITE,dst_path);
		close(writefd);
		return -1 ;
	}

	cprintf ("   TOTAL SIZE["CGREEN"0x%.8x"CRST"]\n", fileSize);
	close(writefd);

	return 0 ;
}

static char* get_size_str(UINT32 size)
{
	static char str[16];

	if(size > 1024*1024){
		UINT32 remainder = (size%(1024*1024))/1024;	// KB
		sprintf(str, "%d.%02dMB", size/(1024*1024), remainder*100/1024);
	}else if(size > 1024){
		UINT32 remainder = size%1024;	// Bytes
		sprintf(str, "%d.%02dKB", size/1024, remainder*100/1024);
	}else {
		sprintf(str, "%dBytes", size);
	}
	return str;
}

static int display_info(int argc, char * argv[])
{
	char	filetype[PAK_TYPE_ID_LEN];
	char	src_path[FILE_PATH_LEN];
	int		readfd;
	UINT32	imgSize;

	if (argc !=3)
	{
		cprintf (ERR_ARG,argc);
		return -1;
	}

	strcpy(src_path, argv[2]);
	if ((readfd = open(src_path, O_RDONLY|O_SYNC, 0)) == -1)
	{
		cprintf (ERR_OPEN,src_path);
		return -1;
	}

	if (read(readfd, filetype, PAK_TYPE_ID_LEN) != PAK_TYPE_ID_LEN)
	{
		cprintf (ERR_READ,src_path);
		close(readfd);
		return -1;
	}

	lseek(readfd, 0, SEEK_SET);
	if(!memcmp(filetype, "epak", 4))
	{
		EPK_HEADER_T	epk_header;
		PAK_LOCATION_T	*imageLocation;
		PAK_HEADER_T	pak_header;
		UINT32			fileNum;

		cprintf (CGREEN"EPK FORMAT"CRST"\n");
		if (read(readfd, &epk_header, sizeof(epk_header)) != sizeof(epk_header))
		{
			cprintf (ERR_READ,src_path);
			close(readfd);
			return -1;
		}

		printf ("  TOTAL SIZE  : %s(%d)\n", get_size_str(SWAP32(epk_header.fileSize)),
											SWAP32(epk_header.fileSize));
		printf ("  TOTAL FILE  : %d\n",SWAP32(epk_header.fileNum));
		printf ("  EPK VERSION : 0x%4x\n",SWAP32(epk_header.epkVersion));
		printf ("  OTA ID      : %s\n",epk_header.ota_id);

		fileNum = SWAP32(epk_header.fileNum);
		if(fileNum > 0)
		{
			int		i;
			UINT32	imgOffset;

			imgSize = sizeof(PAK_LOCATION_T) * fileNum;
			imageLocation = (PAK_LOCATION_T*)_malloc(imgSize);
			if (read(readfd, imageLocation, imgSize) != imgSize)
			{
				cprintf (ERR_READ,src_path);
				close(readfd);
				return -1;
			}


			for (i = 0; i < fileNum; i++)
			{
				printf("[%02d]===============================\n", i);
				imgSize = SWAP32(imageLocation[i].imageSize);
				if (imgSize)
				{
					imgOffset	=	SWAP32(imageLocation[i].imageOffset);
					if(lseek(readfd, imgOffset, SEEK_SET) != imgOffset)
					{
						cprintf (ERR_READ,src_path);
						close(readfd);
						return -1;
					}

					if(read (readfd, &pak_header, sizeof(pak_header)) != sizeof(pak_header))
					{
						cprintf (ERR_READ,src_path);
						close(readfd);
						return -1;
					}

					imgSize = SWAP32(pak_header.imageSize);
					printf("    TYPE  : %.4s\n", pak_header.imageType);
					printf("    MODEL : %s\n", pak_header.modelName);
					printf("    MODE  : %s\n", SWAP32(pak_header.devMode) ? "DEBUG" : "RELEASE");
					printf("    SIZE  : %s(%d)\n", get_size_str(imgSize), imgSize);
					printf("    VER   : 0x%08x\n", SWAP32(pak_header.swVersion));
					printf("    DATE  : %.8x\n", SWAP32(pak_header.swDate));
					//printf("    LOAD  : 0x%x\n", SWAP32(pak_header.loadAddr),
				}
			}
			free(imageLocation);
		}


	}
	else
	{
		PAK_HEADER_T	pak_header;
		read(readfd, &pak_header, sizeof(pak_header));
		if(pak_header.magic_number == SWAP32(PAK_HDR_MAGIC))
		{
			imgSize = SWAP32(pak_header.imageSize);
			cprintf (CGREEN"PAK FORMAT"CRST"\n");
			printf("    TYPE  : %.4s\n", pak_header.imageType);
			printf("    MODEL : %s\n", pak_header.modelName);
			printf("    MODE  : %s\n", SWAP32(pak_header.devMode) ? "DEBUG" : "RELEASE");
			printf("    SIZE  : %s(%d)\n", get_size_str(imgSize), imgSize);
			printf("    VER   : 0x%08x\n", SWAP32(pak_header.swVersion));
			printf("    DATE  : %.8x\n", SWAP32(pak_header.swDate));
			//printf("	  LOAD	: 0x%x\n", SWAP32(pak_header.loadAddr),
		}
		else
		{
			cprintf (CGREEN"UNKNOWN FORMAT"CRST"\n");
		}
	}

	close(readfd);
	return 0;

}

int main(int argc, char * argv[])
{
	if (argc < 2)
	{
		print_help();
		exit (-1);
	}

	if		(!strcmp(argv[1], "-c"))
		option = CREATE_PAK;
	else if	(!strcmp(argv[1], "-d"))
		option = UNCOMP_PAK;
	else if (!strcmp(argv[1], "-m"))
		option = CREATE_EPK;
	else if (!strcmp(argv[1], "-u"))
		option = UNCOMP_EPK;
	else if (!strcmp(argv[1], "-i"))
		option = DISPLAY_INFO;
	else
	{
		print_help();
		exit (-1);
	}

	switch (option)
	{
		case CREATE_PAK:
			if (create_pak(argc,argv))
			{
				print_help();
				exit (-1);
			}
			break;

		case UNCOMP_PAK:
			if (uncomp_pak(argc,argv))
			{
				print_help();
				exit (-1);
			}
			break;

		case CREATE_EPK:
			if (create_epk(argc,argv))
			{
				print_help();
				exit (-1);
			}
			break;

		case UNCOMP_EPK:
			if (uncomp_epk(argc,argv))
			{
				print_help();
				exit (-1);
			}
			break;

		case DISPLAY_INFO:
			if (display_info(argc,argv))
			{
				print_help();
				exit (-1);
			}
			break;

		default :
			break ;
	};

	exit(0);
}
