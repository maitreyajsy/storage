#ifndef __MKEPAK_H__
#define __MKEPAK_H__

#ifdef MK_TOOL
typedef unsigned char		UINT8;
typedef unsigned int		UINT32, uint32_t;
#endif

typedef enum {
	RELEASE_MODE 		= 0,								/**< release mode */
	DEBUG_MODE, 											/**< debug mode */
	TEST_MODE,												/**< test mode */
	UNKNOWN_MODE,											/**< unknown mode */
} BUILD_MODE_T;

#define PAK_TYPE_ID_LEN		4
#define FILE_PATH_LEN		1024


#define PAK_HDR_MAGIC		0x14723873
#define PAK_MAGIC_STR		{0x14, 0x72, 0x38, 0x73, 0x00}
#define CRC32_SZ			4

/* FILE TYPE */
typedef enum
{
	FILE_TYPE_PAK		= 0,
	FILE_TYPE_EPK,
	FILE_TYPE_UNKNOWN
} FILE_TYPE_T;

typedef struct {
	UINT32				imageOffset; 						/**< offset information of pak image */
	UINT32				imageSize;							/**< image size of pak image */
} PAK_LOCATION_T;

// EPK�� ���� �� PAK Header 128 Bytes
typedef struct {
	char				imageType[PAK_TYPE_ID_LEN]; 		/**< 0x00 : type of pak image                 */
	UINT32				imageSize;							/**< 0x04 : image size                        */
	char				modelName[64];						/**< 0x08 : model name                        */
	UINT32				swVersion;							/**< 0x18 : version                           */
	UINT32				swDate; 							/**< 0x1C : build date                        */
	UINT32				devMode;							/**< 0x20 : 0 : Release mode , 1 : Debug mode */
	UINT32				loadAddr;							/**< 0x24 : laod Address                      */
	UINT32				magic_number;						/**< 0x28 : Magic Number                      */
	UINT8				reserved[36];						/**< reservation                              */
} PAK_HEADER_T;

typedef struct
{
	char				fileType[PAK_TYPE_ID_LEN];
	UINT32				fileSize;
	UINT32				fileNum;
	UINT32				epkVersion;
	char				ota_id[32];
	PAK_LOCATION_T		imageLocation[];
} EPK_HEADER_T;

typedef enum
{
	CREATE_PAK,
	UNCOMP_PAK,
	CREATE_EPK,
	UNCOMP_EPK,
	DISPLAY_INFO,
} CREATE_OPT_T;




static inline uint32_t epk_check_magic(void *hdr)
{
	EPK_HEADER_T* h = (EPK_HEADER_T*)hdr;

	if(strncmp("epak", h->fileType, 4))
		return 0;

	return 1;
}

static inline uint32_t epk_get_hdr_size(void)
{
	return sizeof(EPK_HEADER_T);
}

static inline uint32_t epk_get_data_size(void *hdr)
{
	EPK_HEADER_T* h = (EPK_HEADER_T*)hdr;
	return (h->fileSize);
}

static inline uint32_t epk_get_size(void *hdr)
{
	EPK_HEADER_T* h = (EPK_HEADER_T*)hdr;
	return (sizeof(EPK_HEADER_T) + h->fileSize);
}

static inline uint32_t pak_check_magic(void* hdr)
{
	PAK_HEADER_T *h = (PAK_HEADER_T*)hdr;

	if(h->magic_number != PAK_HDR_MAGIC)
		return 0;
	return 1;
}

static inline uint32_t pak_get_magic(void* hdr)
{
	PAK_HEADER_T *h = (PAK_HEADER_T*)hdr;
	return (h->magic_number);
}

static inline uint32_t pak_get_hdr_size(void)
{
	return sizeof(PAK_HEADER_T);
}

static inline uint32_t pak_get_data_size(void* hdr)
{
	PAK_HEADER_T *h = (PAK_HEADER_T*)hdr;
	return (h->imageSize);
}

static inline uint32_t pak_get_size(void* hdr)
{
	PAK_HEADER_T *h = (PAK_HEADER_T*)hdr;
	return (sizeof(PAK_HEADER_T) + h->imageSize + CRC32_SZ);
}

static inline uint32_t pak_get_dcrc(void* hdr)
{
	PAK_HEADER_T *h = (PAK_HEADER_T*)hdr;
	char *pBuf = (char*)hdr;

	return *(uint32_t *)(&pBuf[sizeof(PAK_HEADER_T) + h->imageSize]);
}

static inline uint32_t pak_get_load(void* hdr)
{
	PAK_HEADER_T *h = (PAK_HEADER_T*)hdr;
	return (h->loadAddr);
}

static inline char *pak_get_name(void* hdr)
{
	PAK_HEADER_T *h = (PAK_HEADER_T*)hdr;
	return ((char *)&h->imageType[0]);
}


#endif
