echo "making flash image for linux emulation...."
dd if=/dev/zero of=emul_flash.img bs=1048576 count=1024
dd if=/dev/zero of=emul_env.img bs=262144 count=1
