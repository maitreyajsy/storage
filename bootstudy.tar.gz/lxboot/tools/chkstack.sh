#!/bin/bash
# Usage: chkstack.sh [-f elf_name] address_list_file

set +x
qfix=0
file1=stdin
file2=lxboot.elf
sefmt1="s/\\(.*\\): sp=0x\\([0-9a-fA-F]\\+\\), pc=0x\\([0-9a-fA-F]\\+\\).*/\\3/"
sefmt2="s^/^\\n^g"

###############################################################################
#	Fuction to execute sed script to extract addresses from input stream
###############################################################################
function extractAddrList()
{
  cat $file1 | sed -e "$sefmt1" -e "$sefmt2" 
}

###############################################################################
#	Fuction to trace stack with original GNU addr2line
#		Relatively slow command.
###############################################################################
function traceViaAddr2Line_1()
{
  echo =========================================================================
  for addr in $addrlist
  do
   addr2line -f -e $file2 $addr | awk "{ printf \"0x$addr %-24.24s\", \$1; getline; printf \"%s\n\", \$1}"
  done
  echo =========================================================================
}

###############################################################################
#	Fuction to trace stack with modified GNU addr2line
###############################################################################
function traceViaAddr2Line_2()
{
  echo =========================================================================
  addr2line.lge -n 24 -e $file2 $addrlist
  echo =========================================================================
}

###############################################################################
#	Fuction to trace stack with modified GNU addr2line
###############################################################################
function traceViaAddr2Line_Vim()
{
  addr2line.lge -q -e $file2 $addrlist > .qfix || vi -q .qfix
  rm -r .qfix
}

while [ "$1" != "" ]
do
  case "$1" in
    -f)
	file2=$2
	shift 2
	;;
    -q)
	qfix=1
	shift
	;;
    *)
	file1=$1
	shift
	;;
  esac
done

if [ "$file1" = "" ]; then
  echo "====  Tracing stack from \"stdin\" with $file2"
else
  echo "====  Tracing stack from \"$file1\" with $file2"
  if [ ! -f $file1 ]; then
    file1=
  fi
fi

addrlist=`extractAddrList`
traceViaAddr2Line_1

#if [ $qfix = 1 ]; then
#  traceViaAddr2Line_Vim
#else
#  traceViaAddr2Line_2
#fi
