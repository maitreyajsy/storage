#if !defined(CONFIG_CHIP)
	#error CONFIG_CHIP is not defined !!!
#endif


#if	(CONFIG_CHIP < LX_CHIP_REV(M14, B0))
#include "genheader_lg1311_a0.c"
#elif	(CONFIG_CHIP < LX_CHIP_REV(M14, D0))
#include "genheader_lg1311_b0.c"
#elif	(CONFIG_CHIP < LX_CHIP_REV(H15, C0))
#include "genheader_lg1210_a0.c"
#elif	(CONFIG_CHIP < LX_CHIP_REV(M16, C0))
#include "genheader_lg1312_a0.c"
#elif	(CONFIG_CHIP <= CHIP_LINUX_EMUL)
#include "genheader_linux_emul.c"
#else
#error "Not supported chip"
#endif

