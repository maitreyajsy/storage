#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define LINE_BUF_SZ			( 500)
#define CR					(0x0d)
#define LF					(0x0a)
#define TAB					(0x09)
#define SPACE				(0x20)

/**
* difference between h13 and l9 for bypass boot.
*/
#define M14_BYPASS_BOOT

typedef unsigned char		UINT08;
typedef unsigned short		UINT16;
typedef unsigned int		UINT32;

typedef signed char			SINT08;
typedef signed short		SINT16;
typedef signed int			SINT32;

typedef unsigned int		uint32_t;
typedef unsigned short		uint16_t;
typedef unsigned char		uint8_t; /*add in lg1154*/



#define HDR_TYPE_STR		(0xf001)
#define HDR_TYPE_HEX		(0xf002)
#define HDR_TYPE_DEC		(0xf003)

#define MAGIC_INFO_HEADER	0x7EDF3AC2


#define offsetof(TYPE,MEMBER)		(long)(&(((TYPE*)0)->MEMBER))

typedef struct
{
	char	*chkName;
	int		type;
	union
	{
		UINT32	value;
		char	*str;
	} u;
} head_list;


#define HDR_MAGIC			0x48134130	/* 'H'+13+"A0" */
#define EXTRA_CONF_MAGIC	0x53494321	/* SIC! */

static int		verbose   = 0;
#define PRINT(x...)		if (verbose) {printf(x); fflush(stdout);}

#define MAX_DDR_PARAM_SIZE		120
#define HEADER_SIZE				2048

typedef struct
{
	uint32_t	op;
	uint32_t	addr;
	uint32_t	val;
	uint32_t	mask;
} ddr_params_t;

typedef struct
{
	uint16_t	port;
	uint16_t	bit;
} gpio_set_t;

typedef struct
{
	uint32_t	nand_class;				// ex) 0x00220001 : Cycle 22 Type 1
	uint32_t	page_size;				// one page size
	uint16_t	block_pages;			// pages per block
	uint16_t	ecc_mode;

	uint32_t	nand_tr;				// data transfer time from cell to register
	uint32_t	nand_trea;				// RE access time
	uint32_t	nand_talh;				// ALE(Address Latch Enable) hold time
	uint32_t	nand_div_trp;			// clock divider value for read enable low pulse width
	uint32_t	nand_div_trc;			// clock divider value for read cycle time
	uint32_t	nand_tadl;				// address to data loading time
	uint32_t	nand_div_twp;			// clock divider value for write enable low pulse width
} nand_conf_t;

typedef struct
{
	uint32_t	cpu_clk;
	uint32_t	bus_clk;
	uint32_t	baudrate;
	uint32_t	cmdq_size;
	uint32_t	printf_enable;
#ifdef M14_BYPASS_BOOT
	uint32_t	max_iosiz; /*added in lg1154*/
	uint32_t	mmu_nouse; /*added in lg1154*/
	uint32_t	mmu_base;  /*added in lg1154*/
	uint32_t	reserved[2];
#else
	uint32_t	reserved[5];
#endif
} hw_setting_t;


typedef struct
{
#ifdef M14_BYPASS_BOOT
	uint32_t	reserved[3]; /*changed 2->3 in lg1154*/
#else
	uint32_t	reserved[2];
#endif
	uint32_t	ddr_params;
	uint32_t	next_header;
} header_conf_t;

typedef struct
{
	gpio_set_t	status_gpio;
	uint32_t	mode;			/*0:no, 1:jump to ddr, 2:load from storage & jump */
	uint32_t	jump_address;

	uint32_t	image_size;		/* used if mode = 2 */
	uint32_t	image_offset;	/* used if mode = 2 */

	uint32_t	ddr_params;
#ifdef M14_BYPASS_BOOT
	uint8_t 	sha256[32]; /*added in lg1154*/
#endif
} instant_boot_conf_t;

typedef struct
{
	uint32_t	magic;
	uint32_t	reserved[7];
} extra_conf_t;

typedef struct
{
#ifdef M14_BYPASS_BOOT
	uint32_t	img_exist;
	uint32_t	res1[1];
#else
	uint32_t	res1[2];
#endif
	uint32_t	img_size;
	uint32_t	img_pos;
	uint32_t	img_ldr;
	uint32_t	jump_addr;
#ifdef M14_BYPASS_BOOT
	uint32_t	res2[6];
#endif
} level0_hdr_t;

typedef struct
{
	uint32_t			magic;
	nand_conf_t			nand_conf;
	hw_setting_t		hw_setting;
	uint32_t			res1[11];

	header_conf_t		header_conf;
	gpio_set_t			debug_gpio;
	instant_boot_conf_t	instant_boot_conf;
	extra_conf_t		extra_conf;
#ifdef M14_BYPASS_BOOT
	uint32_t			res2[128];	/* 128 * 4 = 512-byte = 4096-byte */
#else
	uint32_t			res2[32];	/*	32 * 4 = 128-byte = 1024-byte */
#endif

	level0_hdr_t		level0_hdr;
} conf_hdr_t;





/* ddr1, ddr2�� ���� ����. ��Ʈ start code�� reserved ������ �߰��Ѵ�
 2011. 06. 02. offset 0x04 ��ġ��
*/
#define EXT_INFO_OFFSET		32
#define EXT_INFO_MAX_SIZE	(2048 - EXT_INFO_OFFSET)
typedef struct
{
	uint32_t		magic;
	uint32_t		ddr_params;
	ddr_params_t	ddr_param[MAX_DDR_PARAM_SIZE];
} ext_info_hdr_t;


static head_list check_head_table[] =
{
	{ "lst_addr_sw",	HDR_TYPE_STR, 0 },
	{ "lst_top",		HDR_TYPE_STR, 0 },
	{ "lst_m0",			HDR_TYPE_STR, 0 },
	{ "cpu_clk",		HDR_TYPE_DEC, 0 },
	{ "bus_clk",		HDR_TYPE_DEC, 0 },
	{ "baudrate",		HDR_TYPE_DEC, 0 },
	{ "cmdq_size",		HDR_TYPE_DEC, 0 },
	{ "printf_enable",	HDR_TYPE_DEC, 0 },
#ifdef M14_BYPASS_BOOT
	{ "max_iosiz",		HDR_TYPE_HEX, 0 }, /*added in lg1154*/
	{ "mmu_nouse",		HDR_TYPE_DEC, 0 }, /*added in lg1154*/
	{ "mmu_base",		HDR_TYPE_HEX, 0 }, /*added in lg1154*/
#endif
	{ "debug_port", 	HDR_TYPE_DEC, 0 },
	{ "debug_bit",		HDR_TYPE_DEC, 0 },

	{ "page_size",		HDR_TYPE_DEC, 0 },
	{ "block_size",		HDR_TYPE_DEC, 0 },
	{ "ecc_mode",		HDR_TYPE_DEC, 0 },
	{ "nand_class",		HDR_TYPE_HEX, 0 },
	{ "nand_tr",		HDR_TYPE_DEC, 0 },
	{ "nand_trea",		HDR_TYPE_DEC, 0 },
	{ "nand_talh",		HDR_TYPE_DEC, 0 },
	{ "nand_div_trc",	HDR_TYPE_DEC, 0 },
	{ "nand_div_trp",	HDR_TYPE_DEC, 0 },
	{ "nand_tadl",		HDR_TYPE_DEC, 0 },
	{ "nand_div_twp",	HDR_TYPE_DEC, 0 },

	{ "img_offset",		HDR_TYPE_HEX, 0 },
	{ "img_load",		HDR_TYPE_HEX, 0 },
	{ "img_jump",		HDR_TYPE_HEX, 0 },
#ifdef M14_BYPASS_BOOT
	{ "spare_offset",	HDR_TYPE_HEX, 0 },
#endif
	{ "iboot_port",		HDR_TYPE_DEC, 0 },
	{ "iboot_bit",		HDR_TYPE_DEC, 0 },
	{ "iboot_mode",		HDR_TYPE_DEC, 0 },
	{ "iboot_jump",		HDR_TYPE_HEX, 0 },
	{ "iboot_size", 	HDR_TYPE_DEC, 0 },
	{ "iboot_offset", 	HDR_TYPE_HEX, 0 },
	{ "iboot_lst",		HDR_TYPE_STR, 0 },

	{ "lst_m1",			HDR_TYPE_STR, 0 },
	{ NULL }
};

static char lineBuf[LINE_BUF_SZ] = {'\0', };

static void print_usage(void)
{
	printf("Usage:\n");
	printf("genheader -f [genhead file] -i [img file] -o [output file]\n");
	printf("Options:\n");
	printf("  -f genhead file \n\t%s\n", "header generation script file");
	printf("  -i img file \n\t%s\n", "image file of head");
	printf("  -o output file \n\t%s\n", "generated header file");
	printf("  -v verbose mode \n\t%s\n", "print information");

	exit(-1);
}

static char *strtok2(char *srcStr, char *del, char **ptr)
{
	char	*resStr;
	size_t	srcLen, resLen;

	if (del == NULL)
	{
		del = (char *)"\t ";
	}

	/* Normal Type Of strtok	*/
	if (ptr == NULL)
	{
		return((char*)strtok(srcStr, del));
	}

	if (srcStr && *srcStr)
	{
		srcLen = strlen(srcStr);
		resStr = (char*)strtok(srcStr, del);
		resLen = strlen(resStr);
	}
	else
	{
		srcStr = NULL;
		srcLen = 0;
		resStr = NULL;
		resLen = 0;
	}

	if (resStr && ((srcStr+srcLen) > (resStr+resLen)))
		*ptr = (resStr + resLen + 1);
	else
		*ptr = NULL;
	return(resStr);
}

static int readline (char *line, FILE *fp)
{
	static int line_num = 0;
	char*      tmp_line = line;
	int        i;

	while (1)
	{
		char c = (char)fgetc(fp);

		if (c == EOF)
		{
			line_num = 0;
			return -1;
		}

		if(c == CR)
		{
			c = (char)fgetc(fp);
			break;
		}

		*(tmp_line++) = c;
	}
	*(tmp_line++) = '\0';

	line_num++;

	return (line_num);
}

static int trim_line(char *inputline, int line_num)
{
	char	*delStr;
	char	*line = inputline;
	int		i = 0, j = 0;
	char	tmpline[200];

	while ((*line == TAB) || (*line == SPACE))
		line++;

	if (*line == '\0')
		return -1;

	if (line[0] == '#' || line[0] == ';')
		return -1;

	strtok2(line, ";", &delStr);
	strtok2(line, "#", &delStr);

	line = inputline;

	while(line[i] != '\0')
	{
		if((line[i] != SPACE) && (line[i] != TAB))
		{
			tmpline[j++] = line[i];
		}
		i++;
	}

	tmpline[j] = '\0';
	strcpy(&inputline[0], &tmpline[0]);
	return 0;
}

static int parse (char *line)
{
	int		i = 0;
	char 	*checkItem, *value;

	checkItem = strtok2(line, ":", &value);

	if (value == NULL)
		return -1;

	/* Process special variable gets from system env */
	if(value[0] == '$')
	{
		char *env;
		value++;
		if(*value == '{' || *value == '(')
		{
			const char bracket = (*value == '{') ? '}' : ')';
			value++;
			env = value;
			while(*value)
			{
				if(*value == bracket)
				{
					*value = '\0';
					break;
				}
				value++;
			}
		}
		else
		{
			env = value;
		}
		value = getenv(env);
		if(value == NULL) return -1;
	}
	/*******************/

	while (check_head_table[i].chkName != NULL)
	{
		head_list *list = NULL;

		list = &check_head_table[i];

		if (strcmp(list->chkName, checkItem))
		{
			i++;
			continue;
		}
		switch (list->type)
		{
			case HDR_TYPE_STR:
			{
				list->u.str = (char *)malloc(strlen(value)+1);
				strcpy(list->u.str, value);
				break;
			}
			case HDR_TYPE_HEX:
			{
				list->u.value = (UINT32)strtoul(value, NULL, 16);
				break;
			}
			case HDR_TYPE_DEC:
			{
				list->u.value = (UINT32)strtoul(value, NULL, 10);
				break;
			}
		}
		return 0;
	}

	return -1;
}

static int get_chk_value(const char *item)
{
	head_list	*list = NULL;
	int			i = 0;

	while (check_head_table[i].chkName != NULL)
	{
		list = &check_head_table[i];

		if (strcmp(list->chkName, item))
		{
			i++;continue;
		}
		if (list->type == HDR_TYPE_STR)
		{
			fprintf(stderr, "check the source code !\n");
			return -1;
		}
		return list->u.value;
	}

	fprintf(stderr, "'%s' item is not exist !\n", item);
	exit(-1);

	return -1;
}

static char *get_item_str(const char *item)
{
	head_list	*list = NULL;
	int			i = 0;

	while (check_head_table[i].chkName != NULL)
	{
		list = &check_head_table[i];

		if (strcmp(list->chkName, item))
		{
			i++;continue;
		}
		if (list->type != HDR_TYPE_STR)
		{
			fprintf(stderr, "item type is not string !\n");
			return NULL;
		}

		if(list->u.str == NULL)
			goto error;

		return list->u.str;
	}

error:
	return NULL;
}

static char *get_chk_str(const char *item)
{
	char* value = get_item_str(item);

	if(value == NULL)
	{
		fprintf(stderr, "'%s' item is not exist !\n", item);
		exit(-1);
	}
	return value;
}


static int get_ddr_params(const char* fname, ddr_params_t *ddrparam, int offset)
{
	char addr[128], val[128], op[128], mask[128];
	int params, i;
	int count = 0;

	FILE *fd;

	fd = fopen(fname, "r");
	if (fd == NULL)
	{
		printf("Can't open %s\n", fname);
		exit(-1);
	}

	params = offset;
	while ((fscanf(fd, "%s %s %s %s", op, addr, val, mask)) != EOF)
	{
		if(params >= MAX_DDR_PARAM_SIZE)
		{
			while ((fscanf(fd, "%s %s %s %s", op, addr, val, mask)) != EOF) params++;
			printf("DDR Param over max params:%d!!!!\n", params);
			exit(-1);
		}
		ddrparam[params].op = strtoul(op, NULL, 16);
		ddrparam[params].addr = strtoul(addr, NULL, 16);
		ddrparam[params].val = strtoul(val, NULL, 16);
		ddrparam[params].mask = strtoul(mask, NULL, 16);

		params++;
		count++;
	}

	PRINT(" %d parameters\n", params);

	for (i = offset; i < params; i++)
	{
		PRINT("OpCode: ");
		switch(ddrparam[i].op)
		{
			case 0:
				PRINT("Write");
				break;
			case 1:
				PRINT("Wait");
				break;
			case 2:
				PRINT("Eval");
				break;
			case 3:
				PRINT("Delay");
				break;
		}
		PRINT(",\tAddress: 0x%08x, Value: 0x%08x, Mask: 0x%08x\n", ddrparam[i].addr, ddrparam[i].val, ddrparam[i].mask);
	}
	fclose(fd);

	return count;
}

#define TOTAL_HEADER		4
#define TOTAL_HEADER_SIZE	(HEADER_SIZE*TOTAL_HEADER)

static unsigned char dummy[HEADER_SIZE];

static conf_hdr_t conf_hdr;
static conf_hdr_t instant_conf_hdr;

static ext_info_hdr_t ext_info_hdr;

int main(int argc, char **argv)
{
	FILE *fd = NULL;
	FILE *out_file = NULL;

	char *head_fname = NULL;
	char *img_fname = NULL;
	char *out_fname = NULL;

	int img_size;
	struct stat fst;
	int img_pos, img_ldr;

	int i, len, ret, options = 0;
	int c;

	ddr_params_t	instant_ddrparam[MAX_DDR_PARAM_SIZE];
	unsigned int	instant_ddrparam_count;

	ddr_params_t	ddrparam[MAX_DDR_PARAM_SIZE];
	unsigned int	ddrparam_count;

	ddr_params_t	ext_ddrparam[MAX_DDR_PARAM_SIZE];
	unsigned int	ext_ddrparam_count;

	nand_conf_t		nand_conf;
	header_conf_t	header_conf;
	instant_boot_conf_t instant_boot_conf;
	extra_conf_t	extra_conf;
	hw_setting_t	hw_setting;

	level0_hdr_t	level0_hdr;

	gpio_set_t		debug_gpio;

	char* name;
	int line_num = 0;



	memset(dummy, 0, HEADER_SIZE);

	while((c = getopt(argc, argv, "f:i:o:v?")) != EOF)
	{
		switch(c)
		{
			case 'f':
				//memcpy(head_fname, optarg, strlen(optarg));
				head_fname = optarg;
				PRINT("Header Generation File: %s\n", head_fname);
				options |= 1;
				break;
			case 'i':
				//memcpy(img_fname, optarg, strlen(optarg));
				img_fname = optarg;
				options |= 2;
				PRINT("Image File Name: %s\n", img_fname);
				break;
			case 'o':
				out_fname = optarg;
				PRINT("Output File Name: %s\n", out_fname);
				break;
			case 'v':
				verbose = 1;
				break;
			case '?':
				fprintf(stderr, "Unkown option\n");
				print_usage();
				break;
		}
	}

	if(head_fname == NULL || img_fname == NULL || out_fname == NULL)
		print_usage();

	/* SP���� �ε��� �̹����� ���� ����� �ʿ��ϴ�.
	 * ���⿡�� ������ ������ ��ŭ �޸𸮷� �ε��Ѵ�
	 */
	if ((fd = fopen(img_fname, "r")) == NULL)
	{
		printf("can't open '%s'\n", img_fname);
		return -1;
	}
	fstat(fileno(fd), &fst);
	img_size = fst.st_size;
	fclose(fd);

	if ((fd = fopen(head_fname, "r")) == NULL)
	{
		printf("can't open '%s'\n", head_fname);
		return -1;
	}

	while (1)
	{
		if ((line_num = readline(lineBuf, fd)) == -1)
			break;

		if (trim_line(lineBuf, line_num))
			continue;

		parse(lineBuf);
	}
	fclose(fd);

	if ((out_file = fopen(out_fname, "wb")) == NULL)
	{
		printf("can't open '%s'\n", out_fname);
		return -1;
	}

	for(i=0; i<TOTAL_HEADER; i++)
	{
		fwrite(dummy, 1, HEADER_SIZE, out_file);
	}


	PRINT("\nParsing DDR Parameters...");

	ddrparam_count = 0;
	memset(ddrparam, 0, sizeof(ddrparam));

	/* LST ������ ����κ��� ���� address switch, top, ddr0 �����κ��� �и��� */
	name = get_item_str("lst_addr_sw");
	if(name != NULL) {
		int count = get_ddr_params(name, ddrparam, ddrparam_count);
		ddrparam_count += count;
	}

	name = get_item_str("lst_top");
	if(name != NULL) {
		int count = get_ddr_params(name, ddrparam, ddrparam_count);
		ddrparam_count += count;
	}

	name = get_item_str("lst_m0");
	if(name != NULL) {
		int count = get_ddr_params(name, ddrparam, ddrparam_count);
		ddrparam_count += count;
	}
	PRINT("BOOTROM Parameter Count : %d\n", ddrparam_count);

	PRINT("\nParsing DDR parameters for instant boot...");
	instant_ddrparam_count = 0;
	memset(instant_ddrparam, 0, sizeof(instant_ddrparam));

	name = get_item_str("iboot_lst");
	if(name != NULL) {
		instant_ddrparam_count = get_ddr_params(name, instant_ddrparam, 0);
	}

	PRINT("\nParsing M1 Parameters...");
	memset(ext_ddrparam, 0, sizeof(ext_ddrparam));
	name = get_chk_str("lst_m1");
	ext_ddrparam_count = get_ddr_params(name, ext_ddrparam, 0);


	PRINT("\nSystem information: \n");
	memset(&hw_setting, 0, sizeof(hw_setting));

	hw_setting.cpu_clk = get_chk_value("cpu_clk");
	PRINT("CPU clock (0:default): %d\n", hw_setting.cpu_clk);

	hw_setting.bus_clk = get_chk_value("bus_clk");
	PRINT("BUS clock (0:default): %d\n", hw_setting.bus_clk);

	hw_setting.baudrate = get_chk_value("baudrate");
	PRINT("UART baudrate (0:default): %d\n", hw_setting.baudrate);

	hw_setting.cmdq_size = get_chk_value("cmdq_size");
	PRINT("NAND CMDQ size (0:default): %d\n", hw_setting.cmdq_size);

	hw_setting.printf_enable = get_chk_value("printf_enable");
	PRINT("Print Enable : %d\n", hw_setting.printf_enable);

#ifdef M14_BYPASS_BOOT /* dwkim */
	hw_setting.max_iosiz = get_chk_value("max_iosiz");
	PRINT("max iosize (0:default) : 0x%8x\n", hw_setting.max_iosiz);
	hw_setting.mmu_nouse = get_chk_value("mmu_nouse");
	PRINT("mmu nouse  (0:default) : 0x%8x\n", hw_setting.mmu_nouse);
#endif

	debug_gpio.port = get_chk_value("debug_port");
	PRINT("debug gpio port: %d\n", debug_gpio.port);

	debug_gpio.bit = get_chk_value("debug_bit");
	PRINT("debug gpio bit: %d\n", debug_gpio.bit);



	PRINT("\nNAND information: \n");
	memset(&nand_conf, 0, sizeof(nand_conf));

	nand_conf.page_size = get_chk_value("page_size");
	PRINT("Page size: %d\n", (int)nand_conf.page_size);

	nand_conf.block_pages = get_chk_value("block_size");
	PRINT("Pages per block: %d\n", nand_conf.block_pages);

	nand_conf.ecc_mode = get_chk_value("ecc_mode");
	PRINT("ECC type: %d\n", nand_conf.ecc_mode);

	nand_conf.nand_class = get_chk_value("nand_class");
	PRINT("NAND class (hex): 0x%08x\n", (unsigned int)nand_conf.nand_class);

	nand_conf.nand_tr = get_chk_value("nand_tr");
	PRINT("tr: %d\n", (int)nand_conf.nand_tr);

	nand_conf.nand_trea = get_chk_value("nand_trea");
	PRINT("trea: %d\n", (int)nand_conf.nand_trea);

	nand_conf.nand_talh = get_chk_value("nand_talh");
	PRINT("talh: %d\n", (int)nand_conf.nand_talh);

	nand_conf.nand_div_trp = get_chk_value("nand_div_trp");
	PRINT("div_trp: %d\n", (int)nand_conf.nand_div_trp);

	nand_conf.nand_div_trc = get_chk_value("nand_div_trc");
	PRINT("div_trc: %d\n", (int)nand_conf.nand_div_trc);

	nand_conf.nand_tadl = get_chk_value("nand_tadl");
	PRINT("tadl: %d\n", (int)nand_conf.nand_tadl);

	nand_conf.nand_div_twp = get_chk_value("nand_div_twp");
	PRINT("div_twp: %d\n", (int)nand_conf.nand_div_twp);


	PRINT("\nInstant boot Information...\n");
	memset(&instant_boot_conf, 0, sizeof(instant_boot_conf));

	instant_boot_conf.status_gpio.port = get_chk_value("iboot_port");
	PRINT("status gpio no: %d\n", instant_boot_conf.status_gpio.port);

	instant_boot_conf.status_gpio.bit = get_chk_value("iboot_bit");
	PRINT("status gpio bit: %d\n", instant_boot_conf.status_gpio.bit);

	instant_boot_conf.mode = get_chk_value("iboot_mode");
	PRINT("instant boot mode : 0x%8x\n", instant_boot_conf.mode);

	instant_boot_conf.jump_address = get_chk_value("iboot_jump");
	PRINT("instant boot jump address: 0x%8x\n", instant_boot_conf.jump_address);

	instant_boot_conf.image_size = get_chk_value("iboot_size");
	PRINT("instant boot image size : 0x%8x\n", instant_boot_conf.image_size);

	instant_boot_conf.image_offset = get_chk_value("iboot_offset");
	PRINT("instant boot image offset : 0x%8x\n", instant_boot_conf.image_offset);
#ifdef M14_BYPASS_BOOT /* dwkim */
	instant_boot_conf.ddr_params = instant_ddrparam_count;
	PRINT("instant boot ddr params : 0x%8x\n", instant_boot_conf.ddr_params);
#endif

	PRINT("\nExtran configuration...\n");
	memset(&extra_conf, 0, sizeof(extra_conf));

	extra_conf.magic = EXTRA_CONF_MAGIC;




	PRINT("\nLevel0 Header...\n");
	memset(&level0_hdr, 0, sizeof(level0_hdr));
#ifdef M14_BYPASS_BOOT
	level0_hdr.img_exist =	0x80000000;		// Have to define
#endif
	level0_hdr.img_size = img_size;

	PRINT("Level0 image location in storage (hex): ");
	level0_hdr.img_pos = get_chk_value("img_offset");
	PRINT("0x%0x\n", level0_hdr.img_pos);

	PRINT("Level0 image loading address (hex): ");
	level0_hdr.img_ldr = get_chk_value("img_load");
	PRINT("0x%0x\n", level0_hdr.img_ldr);

	PRINT("Level0 image jump address (hex): ");
	level0_hdr.jump_addr = get_chk_value("img_jump");
	PRINT("0x%0x\n", level0_hdr.jump_addr);

	PRINT("\nGenerating configuration header...\n");
	memset(&header_conf, 0, sizeof(header_conf));
	header_conf.ddr_params 	= ddrparam_count;
	header_conf.next_header	= offsetof(conf_hdr_t, level0_hdr);		//0x14C;

#ifdef M14_BYPASS_BOOT /* dwkim */
	PRINT("Level0 hdr offset = %d\n", header_conf.next_header);
#endif

	memset(&conf_hdr, 0, sizeof(conf_hdr));

	conf_hdr.magic = HDR_MAGIC;
	memcpy(&conf_hdr.nand_conf, &nand_conf, sizeof(nand_conf));
	memcpy(&conf_hdr.hw_setting, &hw_setting, sizeof(hw_setting));

	memcpy(&conf_hdr.header_conf, &header_conf, sizeof(header_conf));
	memcpy(&conf_hdr.debug_gpio, &debug_gpio, sizeof(gpio_set_t));
	memcpy(&conf_hdr.instant_boot_conf, &instant_boot_conf, sizeof(instant_boot_conf));
	memcpy(&conf_hdr.extra_conf, &extra_conf, sizeof(extra_conf));

	memcpy(&conf_hdr.level0_hdr, &level0_hdr, sizeof(level0_hdr_t));

	fseek(out_file, 0, SEEK_SET);
	fwrite(&conf_hdr, sizeof(conf_hdr), 1, out_file);


	PRINT("\nGenerating ddr parameters for normal booting...\n");
	fseek(out_file, 1*HEADER_SIZE, SEEK_SET);
	fwrite(ddrparam, sizeof(ddr_params_t) * ddrparam_count, 1, out_file);


	PRINT("\nGenerating ddr parameters for instant booting...\n");
	fseek(out_file, 2*HEADER_SIZE, SEEK_SET);
	fwrite(instant_ddrparam, sizeof(ddr_params_t) * instant_ddrparam_count, 1, out_file);

	fclose(out_file);



	PRINT("Generating ext info(ddr0, ddr1 parameter)...\n");
	if((out_file = fopen(img_fname, "r+")) == NULL)
	{
		printf("can't open '%s'\n", out_fname);
		return -1;
	}

	memset(&ext_info_hdr, 0, sizeof(ext_info_hdr));
	ext_info_hdr.magic = HDR_MAGIC;
	ext_info_hdr.ddr_params = ext_ddrparam_count;
	memcpy(ext_info_hdr.ddr_param, ext_ddrparam, sizeof(ddr_params_t) * ext_ddrparam_count);
	fseek(out_file, EXT_INFO_OFFSET, SEEK_SET);
	fwrite(&ext_info_hdr, sizeof(ext_info_hdr), 1, out_file);
	fclose(out_file);

	return 0;
}

