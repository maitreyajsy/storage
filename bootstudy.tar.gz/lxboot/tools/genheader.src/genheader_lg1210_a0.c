#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define DEBUG_ENABLE	0

#if DEBUG_ENABLE
#define debug(fmt, args...)		printf(fmt, ##args)
#else
#define debug(fmt, args...)		do{}while(0)
#endif


#define LINE_BUF_SZ			( 500)


#define HDR_TYPE_STR		(0x01)
#define HDR_TYPE_HEX		(0x02)
#define HDR_TYPE_DEC		(0x04)

#define offsetof(TYPE,MEMBER)		(unsigned long)(&(((TYPE*)0)->MEMBER))


typedef struct
{
	char	*name;
	int		type;
	int		option;		/* is optional item ? */
	void	*dvalue;	/* default value. if no input & optional item, it will use this value */

	void	*value;
	int		valid;		/* is entered value ? */
} item_list_t;



#define printx(fmt, args...)	\
	do{ if(verbose){fprintf(stdout, fmt, ##args); fflush(stdout);} } while(0)

#define error_exit(fmt, args...)	\
	do {	\
		fprintf(stderr, "\x1b[31m"fmt"\x1b[0m", ##args); \
		exit(-1); \
	} while(0)

#define error(fmt, args...)	\
	do{fprintf(stderr, fmt, ##args);} while(0)


#define HDR_MAGIC				0x48154130  /* 'H'15"A0" */
#define EXTRA_CONF_MAGIC		0x53494321	/* SIC! */

/* SPBC Header Structure */
#define TOTAL_HEADER_SIZE		(18*1024)
#define CONFIG_HEADER_SIZE		( 1*1024)
#define DDRC_PARAMS_SIZE		(16*1024)

#define CONFIG_HEADER_OFFSET	( 0*1024)
#define DDRC_PARAMS_OFFSET		(CONFIG_HEADER_OFFSET + CONFIG_HEADER_SIZE)


#define DDRC_PARAM_PAD_SIZE		(32)
#define DDRC_MAX_PARAMS			((DDRC_PARAMS_SIZE - DDRC_PARAM_PAD_SIZE) / sizeof(ddrc_params_t)) /* 1022 */



typedef struct
{
	uint32_t	op;
	uint32_t	addr;
	uint32_t	val;
	uint32_t	mask;
} ddrc_params_t;

typedef struct
{
	uint16_t	port;
	uint16_t	bit;
} gpio_set_t;

typedef struct
{
	uint8_t		mmu_use;
	uint8_t		tlb_noclear;
	uint8_t		reserved[2];
	uint32_t	mmu_base;
} mmu_ctrl_t;

typedef struct
{
	uint32_t	cpu_clk;
	uint32_t	bus_clk;
	uint32_t	baudrate;
	uint32_t	reserved1;
	uint32_t	printf_enable;
	uint32_t	max_iosiz;
	mmu_ctrl_t	mmu_ctrl;
	uint32_t	reserved2[2];
} hw_setting_t;

typedef struct
{
	uint32_t	reserved[5];
} header_info_t;

typedef struct
{
	uint16_t 	pin;
	uint16_t 	polarity;
}iboot_gpio_t;

typedef struct
{
	iboot_gpio_t gpio_conf;
	uint32_t	mode;			/*0:no, 1:jump to ddr, 2:load from storage & jump */
	uint32_t	jump_address;

	uint32_t	image_size;		/* used if mode = 2 */
	uint32_t	image_offset;	/* used if mode = 2 */

	uint32_t	reserved1;
	uint8_t		reserved2[32];
} iboot_info_t;

typedef struct
{
	uint32_t	magic;
	uint32_t	reserved[7];
} extra_conf_t;

typedef struct
{
	uint32_t	reserved1[2];
	uint32_t	img_size;
	uint32_t	img_pos;
	uint32_t	img_ldr;
	uint32_t	jump_addr;
	uint32_t	reserved2[4];
	uint32_t	spare_pos;
	uint32_t	reserved3[1];
	uint32_t	reserved4[8];
} level0_hdr_t;

typedef struct
{
    uint16_t	size;    /* size in bytes */
    uint16_t	offset;  /* offset in bytes */
} ddrc_param_info_t;

typedef struct
{
    gpio_set_t   		vendor0;
    gpio_set_t   		vendor1;
	uint32_t			reserved1[2];
    ddrc_param_info_t	info[8];
    uint32_t			reserved2[8];
} ddrc_param_conf_t;

typedef struct
{
	uint32_t 	offset;
	uint32_t 	size;
	uint32_t	reserved[8];
} shadow_header_t;

typedef struct
{
	uint32_t			magic;				/*  4  :  1 * 4 */
	uint32_t			reserved1[10];		/*  40 : 10 * 4 */
	hw_setting_t		hw_setting;			/*  40 : 10 * 4 */
	uint32_t			reserved2[11];		/*	44 : 11 * 4 */
	header_info_t		header_info;		/*  20 :  5 * 4 */
	uint32_t			reserved3;			/*  4  :  1 * 4 */
	iboot_info_t		iboot_info;			/*  56 : 14 * 4 */
	extra_conf_t		extra_conf;			/*  32 :  8 * 4 */
	uint32_t			reserved4[128];		/*  512: 128 * 4 = 512-byte = 4096-byte; h13 */
	level0_hdr_t		level0_hdr;			/*  80 : 20 * 4 */
	ddrc_param_conf_t	ddrc_param_conf;	/*  80 : 20 * 4 */
	shadow_header_t 	shadow_header;
} config_hdr_t;



/* Its space is defined in start.S as _ext_info*/
#define EXT_INFO_RESERVED_SIZE		(2048)
#define EXT_INFO_OFFSET				32
#define EXT_INFO_MAX_SIZE			(EXT_INFO_RESERVED_SIZE - EXT_INFO_OFFSET)
#define EXT_INFO_MAX_DDRC_PARAMS	((EXT_INFO_MAX_SIZE - 8)/sizeof(reg_param_t))

#define REG_PARAM_OP_GROUP_WRITE		0x0
#define REG_PARAM_OP_GROUP_WAIT			0x1
#define REG_PARAM_OP_GROUP_CHECK		0x2
#define REG_PARAM_OP_GROUP_RESERVED		0x3
#define REG_PARAM_OP_GROUP_MASK			0x3
typedef struct
{
	uint32_t	opcode;
	uint32_t	operand;
} reg_param_t;

typedef struct
{
	uint32_t		magic;
	uint32_t		ddr_params;
	reg_param_t		ddr_param[EXT_INFO_MAX_DDRC_PARAMS];
} ext_info_hdr_t;


static item_list_t item_list_table[] =
{
	{ .name = "top_lst0",		.type = HDR_TYPE_STR,},
	{ .name = "ddr_lst0",		.type = HDR_TYPE_STR,},
	{ .name = "top_lst1",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "ddr_lst1",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "top_lst2",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "ddr_lst2",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "top_lst3",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "ddr_lst3",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},

	{ .name = "shadow_rom",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "shadow_offset",	.type = HDR_TYPE_HEX,},

	{ .name = "cpu_clk",		.type = HDR_TYPE_DEC,},
	{ .name = "bus_clk",		.type = HDR_TYPE_DEC,},
	{ .name = "baudrate",		.type = HDR_TYPE_DEC,},

	{ .name = "printf_enable",	.type = HDR_TYPE_DEC,},
	{ .name = "max_iosiz",		.type = HDR_TYPE_HEX,},
	{ .name = "mmu_use",		.type = HDR_TYPE_DEC,},
	{ .name = "tlb_noclear",	.type = HDR_TYPE_DEC,},
	{ .name = "mmu_base",		.type = HDR_TYPE_HEX,},

	{ .name = "img_offset",		.type = HDR_TYPE_HEX, .option = 1, .dvalue = (void*)TOTAL_HEADER_SIZE},
	{ .name = "img_load",		.type = HDR_TYPE_HEX,},
	{ .name = "img_jump",		.type = HDR_TYPE_HEX,},
	{ .name = "spare_offset",	.type = HDR_TYPE_HEX,},

	{ .name = "vendor_gpio0",	.type = HDR_TYPE_DEC, .option = 1, .dvalue = 0},
	{ .name = "vendor_gpio1",	.type = HDR_TYPE_DEC, .option = 1, .dvalue = 0},

	{ .name = "iboot_gpio",		.type = HDR_TYPE_HEX, .option = 1, .dvalue = NULL},
	{ .name = "iboot_mode",		.type = HDR_TYPE_DEC, .option = 1, .dvalue = 0},
	{ .name = "iboot_jump",		.type = HDR_TYPE_HEX, .option = 1, .dvalue = 0},
	{ .name = "iboot_size", 	.type = HDR_TYPE_DEC, .option = 1, .dvalue = 0},
	{ .name = "iboot_offset", 	.type = HDR_TYPE_HEX, .option = 1, .dvalue = 0},
	{ .name = "iboot_lst0",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "iboot_lst1",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "iboot_lst2",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},
	{ .name = "iboot_lst3",		.type = HDR_TYPE_STR, .option = 1, .dvalue = NULL},

	{ .name = "ext_lst",		.type = HDR_TYPE_STR,},

	{ .name = "soc_setup_header", 		.type = HDR_TYPE_STR,},
	{ .name = "shadow_header_size",	.type = HDR_TYPE_DEC, .option = 1, .dvalue = 0},
	{ NULL }
};

static char line_buf[LINE_BUF_SZ];

#if DEBUG_ENABLE
static int verbose = 1;
static int verbose_ddrc = 1;
#else
static int verbose = 0;
static int verbose_ddrc = 0;
#endif

static uint8_t *spbc_hdr;

static void print_usage(void)
{
	printf("Usage:\n");
	printf("genheader -f [genhead file] -i [img file] -o [output file]\n");
	printf("Options:\n");
	printf("  -f genhead file \n\t%s\n", "header generation script file");
	printf("  -i img file \n\t%s\n", "image file of head");
	printf("  -o output file \n\t%s\n", "generated header file");
	printf("  -v verbose mode \n\t%s\n", "print information");
	printf("  -d verbose mode(ddrc)\n\t%s\n", "print ddrc parameters");

	exit(-1);
}


/*** File Operation Functions ***/
static int get_filesize(FILE* file)
{
	int size, current;

	current = ftell(file);
	if(fseek(file, 0, SEEK_END) != 0) goto error;
	size = ftell(file);
	if(fseek(file, current, SEEK_SET) != 0) goto error;

	return size;

error:
	error_exit("Cant' get file size !\n");
	return -1;
}

static FILE* file_open(const char *name, const char *mode)
{
	FILE		*file;

	file = fopen(name, mode);
	if(file == NULL) error_exit("Can't open file '%s'\n", name);

	return file;
}

static int file_write(FILE* file, const void* buf, int size)
{
	int res;
	if((res = fwrite(buf, 1, size, file)) != size)
		error_exit("Can't write file !\n");
	return res;
}

static int file_read(FILE* file, void* buf, int size)
{
	int res;
	if((res = fread(buf, 1, size, file)) < 0)
		error_exit("Can't read file !\n");
	return res;
}

static int file_seek(FILE* file, long offset, int whence)
{
	if(fseek(file, offset, whence) != 0)
		error_exit("Can't seek file !\n");
	return 0;
}


static int file_close(FILE* file)
{
	return fclose(file);
}
/*** End of File Operation Functions ***/

/*** String Functions ****/
/* Remove white space */
static int trim(char *str)
{
	char *s1;
	char *s2;
	int n;

	s1 = str;
	while(isspace(*s1)) s1++;
	if(*s1 == '\0')
	{
		*str = '\0';
		return 0;
	}

	s2 = s1;
	while(*s2) s2++;	/* Move to the end of string */

	while(--s2 != s1 && isspace(*s2));
	*(++s2) = '\0';

	n = s2 - s1;
	if(str != s1) while((*str++ = *s1++));

	return n;
}

/* Remove white space & comments */
static int trim_line(char *str)
{
	char *s1;

	s1 = str;
	/* Remove comments start with '#' or ';' */
	while(*s1 && *s1 != '#' && *s1 != ';') s1++;
	*s1 = '\0';

	return trim(str);
}
/*** End of String Functions ****/

/*** Functions for processing genheader file format ***/
static int parse(char *line)
{
	char 	*item, *value;
	char	*last;
	const char *delim = ":";
	item_list_t *list;

	debug("parse : '%s'\n", line);

	item = strtok_r(line, delim, &last);
	value = strtok_r(NULL, delim, &last);

	if(item == NULL || value == NULL)
		return -1;

	trim(item);
	trim(value);

	/* Process special variable gets from system env */
	if(value[0] == '$')
	{
		char *env;
		value++;
		if(*value == '{' || *value == '(')
		{
			const char bracket = (*value == '{') ? '}' : ')';
			value++;
			env = value;
			while(*value)
			{
				if(*value == bracket)
				{
					*value = '\0';
					break;
				}
				value++;
			}
		}
		else
		{
			env = value;
		}
		debug("getenv(%s)\n", env);
		value = getenv(env);
		if(value == NULL) return -1;
	}

	debug("item:'%s', value:'%s'\n", item, value);

	list = item_list_table;
	while(list->name != NULL)
	{
		if(!strcmp(list->name, item))
		{
			switch (list->type)
			{
				case HDR_TYPE_STR:
					list->value = (void *)strdup(value);
					break;
				case HDR_TYPE_HEX:
					list->value = (void*)strtoul(value, NULL, 16);
					break;
				case HDR_TYPE_DEC:
					list->value = (void*)strtoul(value, NULL, 10);
					break;
			}
			list->valid = 1;
			return 0;
		}
		list++;
	}
	error_exit("Invalid item : '%s'\n", item);
	return -1;
}


static int get_item(const char* item, int type, void **v)
{
	item_list_t *list = (item_list_t*)item_list_table;

	while(list->name != NULL)
	{
		if(!strcmp(list->name, item))
		{
			if(!(list->type&type))
			{
				error_exit("item[%s]: invalid item type\n", list->name);
			}

			if(!list->valid && !list->option)
			{
				error_exit("item[%s]: mandatory item but no input data\n", list->name);
			}

			if(!list->valid) *v = list->dvalue;
			else *v = list->value;
			return 0;
		}
		list++;
	}
	return -1;
}

static uint32_t get_item_value(const char *item)
{
	uint32_t value;

	if(get_item(item, HDR_TYPE_HEX|HDR_TYPE_DEC, (void**)&value) < 0)
		error_exit("item[%s] : invalid item\n", item);

	return value;
}

static char* get_item_str(const char *item)
{
	char *str;

	if(get_item(item, HDR_TYPE_STR, (void**)&str) < 0)
		error_exit("item[%s] : invalid item\n", item);

	return str;
}


static int parse_ddrc_params(const char* fname, ddrc_params_t *ddrparam, int offset, int max)
{
#define DDRC_PARAM_INPUT_ARGS		4
	int i;
	int idx;
	FILE *file;
	const char *delim = " \t";
	char *last;
	char *tok;
	char *argv[DDRC_PARAM_INPUT_ARGS + 1];
	int argc;
	int lineno;
	int count;

	file = file_open(fname, "r");

	idx = offset;
	lineno = 0;
	count = 0;
	while(fgets(line_buf, LINE_BUF_SZ, file) != NULL)
	{
		lineno++;
		if(!trim_line(line_buf)) continue;

		argc = 0;
		for(tok = strtok_r(line_buf, delim, &last); tok; tok = strtok_r(NULL, delim, &last))
		{
			argv[argc++] = tok;
			if(argc > DDRC_PARAM_INPUT_ARGS) break;
		}

		if(argc != DDRC_PARAM_INPUT_ARGS)
		{
			error_exit("Invalid ddrc lst format. file:%s, line:%d\n", fname, lineno);
		}

		if(idx >= max)
		{
			error_exit("DDRC parameters over max. file:%s, line:%d\n", fname, lineno);
		}

		ddrparam[idx].op	= strtoul(argv[0], NULL, 0);
		ddrparam[idx].addr	= strtoul(argv[1], NULL, 0);
		ddrparam[idx].val	= strtoul(argv[2], NULL, 0);
		ddrparam[idx].mask	= strtoul(argv[3], NULL, 0);
		idx++;
		count++;
	}


	if(verbose_ddrc)
	{
		printf("'%s' ddrc parameters. count:%d\n", fname, count);
		for (i = offset; i < idx; i++)
		{
			printf("OpCode: ");
			switch(ddrparam[i].op)
			{
				case 0: printf("Write"); break;
				case 1: printf("Check1"); break;
				case 2: printf("Check2"); break;
				case 3: printf("Wait"); break;
			}
			printf(",\tAddress: 0x%08x, Value: 0x%08x, Mask: 0x%08x\n",
				ddrparam[i].addr, ddrparam[i].val, ddrparam[i].mask);
		}
	}
	file_close(file);

	return count;
}

static int parse_reg_params(const char* fname, reg_param_t *reg_param, int offset, int max)
{
#define REG_PARAM_INPUT_ARGS		4
	int i;
	int idx;
	FILE *file;
	const char *delim = " \t";
	char *last;
	char *tok;
	char *argv[REG_PARAM_INPUT_ARGS + 1];
	int argc;
	int lineno;
	int count;
	uint32_t op, addr, val, mask;

	file = file_open(fname, "r");

	idx = offset;
	lineno = 0;
	count = 0;
	while(fgets(line_buf, LINE_BUF_SZ, file) != NULL)
	{
		lineno++;
		if(!trim_line(line_buf)) continue;

		argc = 0;
		for(tok = strtok_r(line_buf, delim, &last); tok; tok = strtok_r(NULL, delim, &last))
		{
			argv[argc++] = tok;
			if(argc > REG_PARAM_INPUT_ARGS) break;
		}

		if(argc != REG_PARAM_INPUT_ARGS)
		{
			error_exit("Invalid lst format. file:%s, line:%d\n", fname, lineno);
		}

		if(idx >= max)
		{
			error_exit("Register parameters(%d) over max(%d). file:%s, line:%d\n", idx, max, fname, lineno);
		}

		/* Convert old format to new format */
		op		= strtoul(argv[0], NULL, 0);
		addr	= strtoul(argv[1], NULL, 0);
		val		= strtoul(argv[2], NULL, 0);
		mask	= strtoul(argv[3], NULL, 0);
		switch(op)
		{
			case 0: // Write
				reg_param[idx].opcode	= addr;
				reg_param[idx].operand	= val;
				break;
			case 3:	// Wait
				reg_param[idx].opcode	= REG_PARAM_OP_GROUP_WAIT;
				reg_param[idx].operand	= val;
				break;
			default:
				error_exit("Not implemented opcode !!!\n");
				break;
		}
		idx++;
		count++;
	}


	if(verbose_ddrc)
	{
		printf("'%s' register parameters. count:%d\n", fname, count);
		for (i = offset; i < idx; i++)
		{
			printf("OpCode: ");
			switch((reg_param[i].opcode&REG_PARAM_OP_GROUP_MASK))
			{
				case REG_PARAM_OP_GROUP_WRITE:
					printf("Write\tAddress:0x%08x, Value:0x%08x", reg_param[i].opcode, reg_param[i].operand);
					break;
				case REG_PARAM_OP_GROUP_WAIT:
					printf("Wait %dus", reg_param[i].operand);
					break;
			}
		}
	}
	file_close(file);

	return count;
}


static void proc_ddrc_params(ddrc_param_conf_t *conf, ddrc_params_t *params)
{
	char *name;
	uint32_t value;
	int i, j;
	int count;
	int size;
	int valid;
	int start_offset;
	int current_offset;
	char lst_name[16];
	const char *nboot_lst_prefix[] = {"top_lst", "ddr_lst"};
	const char *iboot_lst_prefix = "iboot_lst";

	printx("\nParsing DDRC Parameters...\n");


	value = get_item_value("vendor_gpio0");
	printx("Vendor GPIO0 : %d\n", value);
	conf->vendor0.port	= value/8;
	conf->vendor0.bit	= value%8;

	value = get_item_value("vendor_gpio1");
	printx("Vendor GPIO1 : %d\n", value);
	conf->vendor1.port	= value/8;
	conf->vendor1.bit	= value%8;

	debug("parsing ddrc parameters for normal boot\n");
	current_offset = 0;
	for(i=0; i<4; i++)
	{
		size = 0;
		valid = 0;
		start_offset = current_offset;
		for(j=0; j<2; j++)
		{
			sprintf(lst_name, "%s%d", nboot_lst_prefix[j], i);
			name = get_item_str(lst_name);
			if(name)
			{
				count = parse_ddrc_params(name, params, current_offset, DDRC_MAX_PARAMS);
				current_offset += count;
				size += (count * sizeof(ddrc_params_t));
				valid = 1;
			}
		}

		if(valid)
		{
			conf->info[i*2].offset = DDRC_PARAMS_OFFSET + (start_offset*sizeof(ddrc_params_t));
			conf->info[i*2].size = size;
		}
		else
		{
			/* "top_lst0" & "ddr_lst0" are mandatory value, so always has the offset & size */
			conf->info[i*2].offset = conf->info[0].offset;
			conf->info[i*2].size = conf->info[0].size;
		}
		printx("Vendor[%d] : DDRC Parameters for Normal Boot offset:0x%x, size:0x%x\n",
			i, conf->info[i*2].offset, conf->info[i*2].size);
	}


	debug("parsing ddrc parameters for instant boot\n");
	for(i=0; i<4; i++)
	{
		start_offset = current_offset;
		sprintf(lst_name, "%s%d", iboot_lst_prefix, i);
		name = get_item_str(lst_name);
		if(name)
		{
			count = parse_ddrc_params(name, params, current_offset, DDRC_MAX_PARAMS);
			current_offset += count;
			conf->info[i*2 + 1].offset = DDRC_PARAMS_OFFSET + (start_offset*sizeof(ddrc_params_t));
			conf->info[i*2 + 1].size = count * sizeof(ddrc_params_t);
		}
		else
		{
			/* "top_lst0" & "ddr_lst0" are mandatory value, so always has the offset & size */
			conf->info[i*2 + 1].offset = conf->info[0].offset;
			conf->info[i*2 + 1].size = conf->info[0].size;
		}
		printx("Vendor[%d] : DDRC Parameters for Instant Boot offset:0x%x, size:0x%x\n",
			i, conf->info[i*2 + 1].offset, conf->info[i*2 + 1].size);
	}

	debug("parsing for shadow binary\n");
	name = get_item_str("shadow_rom");
	if(name)
	{
		FILE *file;
		uint32_t bin_offset;
		int size;
		uint8_t *data;
		
		bin_offset = get_item_value("shadow_offset");
		if(bin_offset < (current_offset*sizeof(ddrc_params_t) + CONFIG_HEADER_SIZE))
		{
			error_exit("Shadow Binary offset is conflicted with ddrc params. bin_offset:%d, current_offset:%d\n",
				bin_offset, (current_offset*sizeof(ddrc_params_t) + CONFIG_HEADER_SIZE));
		}
		
		file = file_open(name, "r");
		size = get_filesize(file);
		if((bin_offset+size) > (DDRC_PARAMS_OFFSET + DDRC_PARAMS_SIZE))
		{
			error_exit("Shadow Binary Size is over max.. offset:%d, size:%d, avaiable:%d\n",
				bin_offset, size, (DDRC_PARAMS_OFFSET + DDRC_PARAMS_SIZE) - bin_offset );
		}
		data = (uint8_t*)params + (bin_offset - CONFIG_HEADER_SIZE);
		file_read(file, data, size);
	}	
	printx("Total DDRC parameters : %d/%d\n", current_offset, DDRC_MAX_PARAMS);

}

static void proc_hw_setting(hw_setting_t *hw_setting)
{
	printx("\nHW Setting\n");

	hw_setting->cpu_clk = get_item_value("cpu_clk");
	printx("CPU clock : %d\n", hw_setting->cpu_clk);

	hw_setting->bus_clk = get_item_value("bus_clk");
	printx("BUS clock : %d\n", hw_setting->bus_clk);

	hw_setting->baudrate = get_item_value("baudrate");
	printx("UART baudrate : %d\n", hw_setting->baudrate);

	hw_setting->printf_enable = get_item_value("printf_enable");
	printx("Print Enable : %d\n", hw_setting->printf_enable);

	hw_setting->max_iosiz = get_item_value("max_iosiz");
	printx("max iosize : 0x%x\n", hw_setting->max_iosiz);

	hw_setting->mmu_ctrl.mmu_use = get_item_value("mmu_use");
	printx("mmu use  : %d\n", hw_setting->mmu_ctrl.mmu_use);

	hw_setting->mmu_ctrl.tlb_noclear = get_item_value("tlb_noclear");
	printx("tlb noclear : %d\n", hw_setting->mmu_ctrl.tlb_noclear);

	hw_setting->mmu_ctrl.mmu_base = get_item_value("mmu_base");
	printx("mmu base  : %d\n", hw_setting->mmu_ctrl.mmu_use);

}


static void proc_iboot_info(iboot_info_t *iboot_info)
{
	uint32_t value;

	printx("\nInstant boot Information...\n");

	value = get_item_value("iboot_gpio");
	iboot_info->gpio_conf.pin = value & 0xffff;
	iboot_info->gpio_conf.polarity = (value >> 16) & 0xffff;
	printx("instant boot gpio conf : pin 0x%x, polarity 0x%x\n"
									,iboot_info->gpio_conf.pin
									,iboot_info->gpio_conf.polarity);

	iboot_info->mode = get_item_value("iboot_mode");
	printx("instant boot mode : %d\n", iboot_info->mode);

	iboot_info->jump_address = get_item_value("iboot_jump");
	printx("instant boot jump address: 0x%08x\n", iboot_info->jump_address);

	iboot_info->image_size = get_item_value("iboot_size");
	printx("instant boot image size : 0x%08x\n", iboot_info->image_size);

	iboot_info->image_offset = get_item_value("iboot_offset");
	printx("instant boot image offset : 0x%08x\n", iboot_info->image_offset);

}

static void proc_extra_conf(extra_conf_t *extra_conf)
{
	printx("\nExtra configuration...\n");
	extra_conf->magic = EXTRA_CONF_MAGIC;
}


static void proc_level0_header(level0_hdr_t *level0_hdr, uint32_t img_size)
{
	printx("\nLevel0 Header...\n");

	level0_hdr->img_size = img_size;
	printx("Levle0 image size : %d\n", level0_hdr->img_size);

	/* The lxboot image is located in back of spbc header(but it's optional),
	 * and spbc header is located in 0 offset. So img_pos is the size of spbc header */
	level0_hdr->img_pos = get_item_value("img_offset");
	printx("Level0 image location : 0x%0x\n", level0_hdr->img_pos);

	level0_hdr->img_ldr = get_item_value("img_load");
	printx("Level0 image loading address : 0x%08x\n", level0_hdr->img_ldr);

	level0_hdr->jump_addr = get_item_value("img_jump");
	printx("Level0 image jump address : 0x%08x\n", level0_hdr->jump_addr);
}

static void proc_shadow_header(shadow_header_t *shadow_header, level0_hdr_t *level0_hdr)
{
	if(get_item_value("shadow_header_size"))
	{
		printx("\nShadow Header Bin...\n");
		shadow_header->size = get_item_value("shadow_header_size");
		printx("Shadow Header bin size : %d\n", shadow_header->size);
		shadow_header->offset = level0_hdr->img_pos + (level0_hdr->img_size - shadow_header->size);
		printx("Shadow Header bin offset : 0x%08x\n", shadow_header->offset);
		printx("\n");
	}
}
static void proc_ext_info(const char *fname)
{
	ext_info_hdr_t *ext_info_hdr;
	FILE *file;
	char *lst_fname;

	printx("Generating ext info for bootloader... file='%s'\n", fname);

	ext_info_hdr = (ext_info_hdr_t*)calloc(1, sizeof(ext_info_hdr_t));

	if(!ext_info_hdr) error_exit("Can't alloc memory\n");

	lst_fname = get_item_str("ext_lst");

	ext_info_hdr->magic = HDR_MAGIC;
	ext_info_hdr->ddr_params = parse_reg_params(lst_fname, ext_info_hdr->ddr_param, 0, EXT_INFO_MAX_DDRC_PARAMS);

	file = file_open(fname, "r+");
	file_seek(file, EXT_INFO_OFFSET, SEEK_SET);
	file_write(file, ext_info_hdr, sizeof(ext_info_hdr_t));
	file_close(file);
	free(ext_info_hdr);
}


static void display_structure(void)
{
#if DEBUG_ENABLE
	unsigned int offset;

	debug("## SPBC Header Structure ##\n");
	debug("Config Header Offset  : 0x%04x(%d)\n", CONFIG_HEADER_OFFSET, CONFIG_HEADER_OFFSET/4);
	debug("DDRC Parameters Offset : 0x%04x(%d)\n", DDRC_PARAMS_OFFSET, DDRC_PARAMS_OFFSET/4);

	debug("\nConfig Header Structure\n");
	offset = (unsigned int)offsetof(config_hdr_t, magic);
	debug("%-20s : 0x%04x(%d)\n", "Magic", offset, offset/4);

	offset = (unsigned int)offsetof(config_hdr_t, hw_setting);
	debug("%-20s : 0x%04x(%d)\n", "HW Setting", offset, offset/4);

	offset = (unsigned int)offsetof(config_hdr_t, header_info);
	debug("%-20s : 0x%04x(%d)\n", "Header Info", offset, offset/4);

	offset = (unsigned int)offsetof(config_hdr_t, iboot_info);
	debug("%-20s : 0x%04x(%d)\n", "Instant Boot Info", offset, offset/4);

	offset = (unsigned int)offsetof(config_hdr_t, extra_conf);
	debug("%-20s : 0x%04x(%d)\n", "Extra", offset, offset/4);

	offset = (unsigned int)offsetof(config_hdr_t, level0_hdr);
	debug("%-20s : 0x%04x(%d)\n", "Level 0 Header", offset, offset/4);

	offset = (unsigned int)offsetof(config_hdr_t, ddrc_param_conf);
	debug("%-20s : 0x%04x(%d)\n", "DDR Multivendor", offset, offset/4);

	offset = (unsigned int)offsetof(config_hdr_t, shadow_header);
	debug("%-20s : 0x%04x(%d)\n", "Shadow Rom Header", offset, offset/4);
#endif
}

int main(int argc, char **argv)
{
	FILE *in_file;
	FILE *out_file;

	char *head_fname = NULL;
	char *img_fname = NULL;
	char *out_fname = NULL;

	int img_size;

	config_hdr_t		*config_hdr;	/* Config Header */
	ddrc_params_t		*ddrc_params;	/* DDRC Parameter */

	int	c;
	int	options = 0;


	display_structure();

	while((c = getopt(argc, argv, "f:i:o:vd?")) != EOF)
	{
		switch(c)
		{
			case 'f':
				head_fname = optarg;
				printx("Header Generation File: %s\n", head_fname);
				options |= 1;
				break;
			case 'i':
				img_fname = optarg;
				options |= 2;
				printx("Image File Name: %s\n", img_fname);
				break;
			case 'o':
				out_fname = optarg;
				printx("Output File Name: %s\n", out_fname);
				break;
			case 'v':
				verbose = 1;
				break;
			case 'd':
				verbose_ddrc = 1;
				break;
			case '?':
				error("Unkown option\n");
				print_usage();
				break;
		}
	}

	if(head_fname == NULL || img_fname == NULL || out_fname == NULL)
		print_usage();

	/* Get the 1st bootloader image size becase it's need in spbc header */
	in_file = file_open(img_fname, "r");
	img_size = get_filesize(in_file);
	file_close(in_file);

	/* Parse the genheader input file */
	in_file = file_open(head_fname, "r");
	while (fgets(line_buf, LINE_BUF_SZ, in_file) != NULL)
	{
		if(!trim_line(line_buf))
			continue;

		parse(line_buf);
	}
	file_close(in_file);

	/* Allocate memory for whole spbc header */
	spbc_hdr = (uint8_t*)calloc(1, TOTAL_HEADER_SIZE);
	if(!spbc_hdr) error_exit("Can't alloc memroy\n");

	config_hdr = (config_hdr_t*)(spbc_hdr + CONFIG_HEADER_OFFSET);
	ddrc_params = (ddrc_params_t*)(spbc_hdr + DDRC_PARAMS_OFFSET);


	/* Insert the spbc header data in order of structure member's position */
	config_hdr->magic = HDR_MAGIC;

	proc_hw_setting(&config_hdr->hw_setting);

	proc_iboot_info(&config_hdr->iboot_info);

	proc_extra_conf(&config_hdr->extra_conf);

	proc_level0_header(&config_hdr->level0_hdr, img_size);

	proc_ddrc_params(&config_hdr->ddrc_param_conf, ddrc_params);

	proc_shadow_header(&config_hdr->shadow_header, &config_hdr->level0_hdr);

	/* Write it to the file */
	out_file = file_open(out_fname, "wb");
	file_write(out_file, spbc_hdr, TOTAL_HEADER_SIZE);
	file_close(out_file);
	free(spbc_hdr);

	/* Insert the header information for lxboot */
	proc_ext_info(img_fname);

	return 0;
}


