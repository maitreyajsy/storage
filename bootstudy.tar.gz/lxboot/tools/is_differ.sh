#!/bin/bash

# Skip arguement is not file
[ ! -f  $1           ] && exit

# Skip arguement is svn related file
[ $1 != ${1/\/.svn/} ] && exit

# Skip same file is already present in destination directory
diff $1 $2/$1 2>/dev/null 1>/dev/null
if [  $? -eq 0 	 ]; then
	exit
fi

# redirect change file to list
if [ ! -z $3 ]; then 
	if [ $2 == $3 ]; then 	printf "%s\n" ${1/.\//} >> $3/changed_file_list.txt
	else 					printf "%s/%s\n" ${2/$3\//} ${1/.\//} >> $3/changed_file_list.txt
	fi
fi

# display source filename
printf "%s\n" ${1/.\//}
