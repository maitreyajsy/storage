#!/bin/sh

if [ $# -ne 1 ]; then
	echo "Usuage: `basename $0` config-file"
	exit 65
fi

config_file=$1
temp_file=".autoconf.tmp"

sed -e '/^#/d' -e '/^$/d' -e 's/:=/  /g' -e 's/=/ /g' $1 > $temp_file


awk '
BEGIN {
	print "/*";
	print " * Automatically generated config: do not edit";
	print " */";
	printf "\n\n";
	print "#ifndef __AUTOCONF_H__";
	print "#define __AUTOCONF_H__";
	printf "\n";

	define_list = ":AARCH:ARCH:CHIP_REV:PLATFORM:BOARD_TYPE:";
}

{
	if (index(define_list, ":"$1":") != 0)
	{
		print "#define CONFIG_"$1"_"toupper($2)

		if($1 == "ARCH")
			print "#define CONFIG_ARCH ARCH_"toupper($2)

		if($1 == "CHIP_REV")
			print "#define CONFIG_REV REV_"toupper($2)
	}
	else if(index($1, "CONFIG_") != 0)
	{
		value = $0;
		sub($1,"",value);
		sub(/^[\t ]*/, "", value);	# strip leading spaces
		sub(/[\t ]*$/, "", value);	# strip trailing spaces

		if(value == "y")
			print "#define "$1;
		else if(value == "n")
			print "//#define "$1;
		else
			printf "#define %-30s %s\n", $1, value;
	}
}

END {
	printf "\n#endif\n\n";
}
' "$temp_file"

rm $temp_file

exit 0
