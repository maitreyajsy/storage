#!/bin/sh

usuage()
{
	echo "Usage : `basename $0` in_file align_size"
}

if [ $# -ne 2 ]; then
	usuage
	exit 1
fi

in_file=$1
align_size=$2

filesize=`stat -c %s $in_file`

echo "'`basename $1`' will be align to $align_size bytes"

remainder=`expr $filesize % $align_size`
if [ $remainder -ne 0 ]; then
	added=`expr $align_size - $remainder`
	dd if=/dev/zero of=$in_file bs=1 count=$added conv=notrunc oflag=append > /dev/null 2>&1
fi

echo "Done"

