LXBOOT Release Notes

1. SUMMARY
    LXBOOT is a boot loader/downloader combination for embedded software development.

    * http://sicsvn.lge.com/svn/LG1150/dev/SW/lxboot


2. Directory structure

    The directory structure is as follows.

	/
        |-- arch
        |   |-- lg1150
        |   `-- lg1152
        |
	|	|-- common/     ...
	|	|-- configs/    ... configurations to make
	|	|-- drivers/
    |   |   |-- i2c
    |   |   |-- nand
    |   |
	|	|-- include/
	|   |   |-- i2c
    |   |   |-- nand
    |   |
	|	|-- lib/
	|	|   `--
	|	|-- platform/
	|	|   `--
	|	`-- tools/
	|       |-- ccdv
    |       |-- nand
    |
	|-- Makefile        ... Makefile
	|-- README.txt      ... This file
	|-- rules.mk        ...


3. Configuring the lxboot



4. Compiling the lxboot






