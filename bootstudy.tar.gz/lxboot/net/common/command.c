/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>
#include <command.h>
#include <env.h>
#include <net.h>



#define TFTP_SLOW_BLOCK_SIZE		1468	// max = 65535
#define TFTP_FAST_BLOCK_SIZE		32768	// max = 65535


static int	tftp_cmd( int argc, char **argv )
{
	int	 rx_len;
	char filename[128];
	ulong load_addr;

	char url[256];
	char *server_ip;
	char *cp;

	rx_len = 0;

	if(argc != 3)
	{
		command_error(argv[0]);
		return -1;
	}

	load_addr = strtoul(argv[1], NULL, 0);
#if (CONFIG_CHIP == CHIP_LINUX_EMUL)
	{
		extern	uint32_t board_mem_base;
		/* linux emulator supports 256MB system memory. */
		load_addr += board_mem_base;
		MSG(1, "tftp load addr = 0x%x\n", load_addr );
	}
#endif
	if(load_addr == 0)
	{
		printf("load address is invalid[%s] !\n", argv[1]);
		return -1;
	}

	strncpy(url, argv[2], 256);

	cp = url;
	server_ip = strsep(&cp, "/");

	if(cp == NULL)
	{
		printf("No file name !\n");
		return -1;
	}
	strncpy(filename, cp, 128);

	printf("SERVER IP=%s, FILE=%s\n", server_ip, filename);
	rx_len = tftp_download(strtoip(server_ip), load_addr, filename);

	if( rx_len <= 0 )
	{
		printf( " receive Error!\n" );
		return -1;
	}

	return 0;
}
COMMAND(tftp, tftp_cmd, "download image using tftp", "mem url");


static int	fasttftp_cmd(int argc, char **argv)
{
	char* env_blksize = env_get(ENV_TFTPBLKSIZE);

	printf("fast tftp : ");
	if(argc < 2)
	{
		char *str;
		if(env_blksize == NULL || !strcmp(env_blksize, MK_STR(TFTP_FAST_BLOCK_SIZE)))
			str = "on";
		else if(!strcmp(env_blksize, MK_STR(TFTP_SLOW_BLOCK_SIZE)))
			str = "off";
		else
			str = "custom";

		printf("%s\n", str);
		return 0;
	}

	if(!strcmp(argv[1], "on"))
	{
		env_set(ENV_TFTPBLKSIZE, MK_STR(TFTP_FAST_BLOCK_SIZE));
		printf("on\n");
	}
	else if(!strcmp(argv[1], "off"))
	{
		env_set(ENV_TFTPBLKSIZE, MK_STR(TFTP_SLOW_BLOCK_SIZE));
		printf("off\n");
	}
	else
	{
		printf("invalid !\n");
	}

	return 0;
}
COMMAND(fasttftp, fasttftp_cmd, "increase the tftp download speed", "on/off");



