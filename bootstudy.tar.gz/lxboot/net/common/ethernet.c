#include <types.h>
#include <stdio.h>
#include <string.h>
#include <ethernet.h>
#include <net.h>
#include <env.h>
#include <util.h>

static eth_driver_t *driver;
static u8 mac_addr[6];


int eth_init(void)
{
	const uint8_t* env_mac_addr;
	static int inited = 0;

	if(inited) {
		/* If the mac address was changed than set it to the hardware */
		if(driver->setaddr) {
			env_mac_addr = strtomac(env_get(ENV_ETHADDR));
			if(is_valid_mac_addr(env_mac_addr)) {
				int i;
				for(i=0; i<6; i++) {
					if(mac_addr[i] != env_mac_addr[i]) break;
				}
				if(i != 6) {
					memcpy(mac_addr, env_mac_addr, 6);
					driver->setaddr(mac_addr);
					printf("^g^Set MAC Address[%s]\n", mactostr(mac_addr));
				}
			}
		}
		return 0;
	}

	if(driver == NULL) driver = get_eth_driver();
	if(driver == NULL) return -1;
	
	env_mac_addr = strtomac(env_get(ENV_ETHADDR));
	if(is_valid_mac_addr(env_mac_addr)) {
		memcpy(mac_addr, env_mac_addr, 6);
	} else {
		printf("^r^Invalid MAC Address[%s]\n", mactostr(env_mac_addr));
		gen_mac_addr(mac_addr);
		printf("Generate MAC Address[%s]\n", mactostr(mac_addr));
	}

	if(driver->init(mac_addr) < 0) return -1;
	inited = 1;
	return 0;
}

uint8_t *eth_getaddr( void )
{
	if(driver->getaddr) driver->getaddr();

	return mac_addr;
}

int eth_setaddr(const u8 *mac_addr)
{
	if(driver->setaddr) return driver->setaddr(mac_addr);
	return -1;
}

int eth_transmit(const void *data, size_t size)
{
	if(driver->transmit == NULL)
		return 0;

	return driver->transmit( data, size );
}

int eth_receive(void *data, size_t size)
{
	if( driver->receive == NULL)
		return 0;

	return driver->receive( data, size);
}

int	eth_start(void)
{
	if(eth_init() < 0) return -1;

	if(driver->start)
	driver->start();

	return 0;
}

int register_eth_driver(eth_driver_t *eth_driver)
{
	if(driver == NULL) {
		driver = eth_driver;
		return 0;
	}
	printf("Already registerd another ethernet driver\n");
	return -1;
}

eth_driver_t* __attribute__((weak)) get_eth_driver(void)
{
	return NULL;
}
