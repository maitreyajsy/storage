/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <ethernet.h>
#include <net.h>
#include <env.h>
#include <util.h>


uint32_t strtoip(const char *str)
{
	const char *delim = ".";
	uint32_t ip;
	char	 ip_str[128];
	int	 v[4];
	char	 *tok;
	int	 idx;

	strncpy(ip_str, str, 128);
	memset(v, 0, 4);

	for(idx=0, tok=strtok(ip_str, delim); tok; tok=strtok(NULL, delim), idx++)
	{
		if(idx >= 4) return 0;  // invalid format
		v[idx] = atoi(tok) & 0xFF;
	}

	if(idx != 4) return 0;  // invalid format

	ip = v[3]<<24 | v[2]<<16 | v[1]<< 8 | v[0];

	return ip;
}

char* iptostr(uint32_t ip)
{
	static char str[16];
	sprintf(str, "%d.%d.%d.%d",
			(int) ((ip >> 0) & 0xff),
			(int) ((ip >> 8) & 0xff),
			(int) ((ip >> 16) & 0xff), (int) ((ip >> 24) & 0xff));

	return str;
}

uint8_t* strtomac(const char *str)
{
	static uint8_t mac[6];

	if(is_valid_mac(str))
	{
		mac[0] = tohex(str[0] ) << 4 | tohex(str[1]);
		mac[1] = tohex(str[3] ) << 4 | tohex(str[4]);
		mac[2] = tohex(str[6] ) << 4 | tohex(str[7]);
		mac[3] = tohex(str[9] ) << 4 | tohex(str[10]);
		mac[4] = tohex(str[12]) << 4 | tohex(str[13]);
		mac[5] = tohex(str[15]) << 4 | tohex(str[16]);
	}
	else
	{
		memset(mac, 0, 6);
//		printf("^r^strtomac: invalid mac address\n");
	}

	return mac;
}

char* mactostr(const uint8_t* mac)
{
	static char str[18];
	sprintf(str, "%02X:%02X:%02X:%02X:%02X:%02X",
			mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

	return str;
}

int is_valid_ip(const char* str)
{
	const char *delim = ".";
	char *tok;
	char *endptr;
	char str_ip[20 + 1];
	long num;
	int cnt = 0;

	strncpy(str_ip, str, 20);
	str_ip[20] = '\0';

	for(tok = strtok(str_ip, delim); tok; tok = strtok(NULL, delim))
	{
		num = strtol(tok, &endptr, 10);
		if(*endptr != '\0' || num < 0 || num > 255)
			return 0;
		cnt++;
	}

	if(cnt == 4)
		return 1;
	return 0;
}

int is_valid_mac(const char* str)
{
	if(str != NULL && strlen(str) == 17 &&
			str[2] == ':' && str[5] == ':' && str[8] == ':' &&
			str[11] == ':' && str[14] == ':')
	{
		if( isxdigit(str[0]) && isxdigit(str[1]) &&
				isxdigit(str[3]) && isxdigit(str[4]) &&
				isxdigit(str[6]) && isxdigit(str[7]) &&
				isxdigit(str[9]) && isxdigit(str[10]) &&
				isxdigit(str[12]) && isxdigit(str[13]) &&
				isxdigit(str[15]) && isxdigit(str[16]))
			return 1;
	}
	return 0;
}

int is_valid_mac_addr(const uint8_t* mac)
{
	/* All 0 is invalid MAC Addr. */
	if(!(mac[0] | mac[1] | mac[2] | mac[3] | mac[4] | mac[5])) return 0;

	/* Multicast address */
	if(mac[0]&0x1) return 0;

	/* Broadcast address */
	if((mac[0] & mac[1] & mac[2] & mac[3] & mac[4] & mac[5]) == 0xFF) return 0;

	return 1;
}

void gen_mac_addr(u8 *addr)
{
	int i;
	for(i=0; i<6; i++)
		addr[i] = rand_num(256);
	addr[0] &= 0xFE;
	addr[0] |= 0x02;
}