#ifndef __LXIF_H__
#define __LXIF_H__

#include "lwip/netif.h"

err_t lxif_init(struct netif *netif);


#endif
