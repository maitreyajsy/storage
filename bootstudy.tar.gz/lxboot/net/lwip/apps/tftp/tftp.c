/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <default.h>
#include <string.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <timer.h>
#include <net.h>
#include <progress.h>

#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"


#if 0
#define TFTP_DEBUG(fmt, args...)		printf("[%d] : "fmt, __LINE__, ##args)
#else
#define TFTP_DEBUG(fmt, args...)		do{}while(0)
#endif


#define TFTP_OPCODE_RRQ			1		/* Read request */
#define TFTP_OPCODE_WRQ			2		/* Write request */
#define TFTP_OPCODE_DATA		3		/* Read or write the next block of data */
#define TFTP_OPCODE_ACK			4		/* Acknowledgment */
#define TFTP_OPCODE_ERROR		5		/* Error message */
#define TFTP_OPCODE_OACK		6		/* option acknowledgment */

#define TFTP_PORT_HOST				69		// Well known TFTP port #
#define TFTP_DEFAULT_BLOCK_SIZE		512
#define TFTP_FAST_BLOCK_SIZE		32768	// max = 65535
#define TFTP_SLOW_BLOCK_SIZE		1468	// max = 65535

#define TFTP_TIMEOUT				2		// second unit

#define TFTP_FILE_MODE				"octet"

/* TFTP Packets */
struct tftp_pkt
{
	u16 opcode;
	union {
		char payload[0];
		struct {
			u16 block;
			char data[0];
		} data;

		struct {
			u16 block;
		} ack;

		struct {
			u16	code;
			char msg[0];
		} error;

		struct {
			char data[0];
		} optack;
	} p;
};



typedef enum
{
	TFTP_STATE_NONE = 0,
	TFTP_STATE_FAIL,
	TFTP_STATE_OK,
	TFTP_STATE_END,
} tftp_state_t;



/** TFTP Context */
typedef struct
{
	u16			last_block_num;
	u32			block_wraps_count;

	/* tftp options */
	u16			block_size;
	u16			timeout;

	struct progress_info pi;

	void			*buf;
	put_data_func	*put_data;
	int				verbose;
} tftp_ctx_t;

static tftp_ctx_t _tftp_ctx;
static tftp_ctx_t *tftp_ctx = &_tftp_ctx;


static int sock;
static struct sockaddr_in servaddr;
static char pktbuf[512];


/**
 * TFTP send packets
 */
static int send_packets(const void* data, int len)
{
	if(lwip_sendto(sock, data, len, 0, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
		TFTP_DEBUG("tftp_sender: not sendto==%i\n", errno);
		return -1;
	}
	return 0;
}


/**
 * RRQ(Read Request) Packet
 */
static int send_request_packet(const char *filename)
{
	int len;
	u16 blksize = TFTP_FAST_BLOCK_SIZE;
	char* env_blksize;
	char* data;
	struct tftp_pkt *pkt = (struct tftp_pkt*)pktbuf;

	env_blksize = env_get(ENV_TFTPBLKSIZE);
	if(env_blksize != NULL)
	{
		blksize = strtoul(env_blksize, NULL, 0);
		if(blksize < 512)
			blksize = 512;
		else if(blksize > 65535)
			blksize = 65535;
	}

	pkt->opcode	= PP_HTONS(TFTP_OPCODE_RRQ);
	data = pkt->p.payload;

	//filename | mode
	len = sprintf(data, "%s%c%s", filename, 0, TFTP_FILE_MODE) + 1;

	//timeout
	len += sprintf(data + len, "%s%c%d", "timeout", 0, TFTP_TIMEOUT) + 1;

	//blocksize
	len += sprintf(data + len, "%s%c%d", "blksize", 0, blksize) + 1;

	//request total size
	len += sprintf(data + len, "%s%c0", "tsize", 0) + 1;

	return send_packets(pkt, len+2);
}

/** Data Ack Packet
 *
 */
static int send_ack_packet(uint16_t block_num)
{
	struct tftp_pkt *pkt = (struct tftp_pkt*)pktbuf;

	pkt->opcode			= PP_HTONS(TFTP_OPCODE_ACK);
	pkt->p.ack.block	= htons(block_num);

	send_packets(pkt, 4);

	return 0;
}



static int tftp_handler(const void* input, int len)
{
	struct tftp_pkt *pkt = (struct tftp_pkt*)input;
	u16 opcode;

	opcode = ntohs(pkt->opcode);
	switch ( opcode )
	{
		case TFTP_OPCODE_ERROR:
		{
			printf("\nTFTP Error[%d] : %s\n", ntohs(pkt->p.error.code), pkt->p.error.msg);
			return TFTP_STATE_FAIL;
		}

		case TFTP_OPCODE_DATA:
		{
			u16 block_num	= ntohs(pkt->p.data.block);
			int data_size	= len - 4;			// opcode(2) + blocknum(2)
			u8*	src_data	= (u8*)(pkt->p.data.data);	// tftp payload

			//TFTP_DEBUG("TFTP_OPCODE_DATA: block[%d]\n", block_num);

			/* The 'block_num' field is 16bit, so the overflow happens
			 * when the filesize is greater than 65536 * block_size.
			 * We can decide whether 'block_num=0' is the initial or wraparound value
			 * as below :
			 */
			if(block_num == 0 && tftp_ctx->last_block_num == 0xFFFF)
			{
				tftp_ctx->block_wraps_count++;
			}

			/* Check next block number */
			if((u16)(tftp_ctx->last_block_num + 1) == block_num)
			{
				if(tftp_ctx->put_data(src_data, data_size) < 0)
					return TFTP_STATE_FAIL;
				
				tftp_ctx->last_block_num = block_num;
				tftp_ctx->pi.received_size += data_size;
			}
			else
			{
				/* Sometimes it happens, same or strange block number */
				TFTP_DEBUG("lastblock=%d, received=%d\n", tftp_ctx->last_block_num, block_num);
				return TFTP_STATE_NONE;
			}

			/* if the received size is less than the block size
			 * it means that the transmission is completed
			 */
			if(data_size < tftp_ctx->block_size) return TFTP_STATE_END;
			return TFTP_STATE_OK;
		}

		case TFTP_OPCODE_OACK:
		{
		#if 0
			#define TFTP_OPTION_DEBUG(fmt, args...)		printf(fmt, ##args)
		#else
			#define TFTP_OPTION_DEBUG(fmt, args...)		do{}while(0)
		#endif

			#define MAX_OPTION_STRING_LEN	31
			char	*ack_data;
			int		data_len;
			int		idx, max_str;
			char	option[MAX_OPTION_STRING_LEN + 1];
			char	value[MAX_OPTION_STRING_LEN + 1];

			idx = 0;

			ack_data	= (char*)(pkt->p.optack.data);
			data_len	= len;

			TFTP_OPTION_DEBUG("TFTP OACK : \n");
			TFTP_OPTION_DEBUG("+------------------------+\n");
			while(idx < data_len)
			{
				max_str = (data_len - idx) > MAX_OPTION_STRING_LEN ? MAX_OPTION_STRING_LEN : (data_len - idx);

				strncpy(option, (char*)&ack_data[idx], max_str);
				option[max_str] = '\0';

				idx += (strlen(option) + 1);
				if(idx < data_len)
				{
					max_str = (data_len - idx) > MAX_OPTION_STRING_LEN ?
								MAX_OPTION_STRING_LEN : (data_len - idx);
					strncpy(value, (char*)&ack_data[idx], max_str);
					value[max_str] = '\0';

					TFTP_OPTION_DEBUG("|%10s | %10s |\n", option, value);
					TFTP_OPTION_DEBUG("+------------------------+\n");
					if(strcmp(option, "blksize") == 0)
					{
						tftp_ctx->block_size = (uint16_t)strtoul(value, NULL, 0);
					}
					else if(strcmp(option, "tsize") == 0)
					{
						tftp_ctx->pi.total_size = strtoll(value, NULL, 0);
					}
					else if(strcmp(option, "timeout") == 0)
					{
						tftp_ctx->timeout = (uint16_t)strtoul(value, NULL, 0);
					}
					idx += (strlen(value) + 1);
				}

				if(ack_data[idx] == 0)
					idx++;
			}
			TFTP_OPTION_DEBUG("\n");

			return TFTP_STATE_OK;
		}

		case TFTP_OPCODE_RRQ:
		case TFTP_OPCODE_WRQ:
		case TFTP_OPCODE_ACK: break;
		default       		: break;
	}

	return TFTP_STATE_NONE;
}

static int tftp_put_data(const void *buf, int size)
{
	if(size > 0) {
		u8* dst_data = (u8*)tftp_ctx->buf + tftp_ctx->pi.received_size;
		memcpy(dst_data, buf, size);
	}
	return 0;
}


static s64 _tftp_get(struct url_cfg* cfg, void *buf, put_data_func *put_data, int verbose)
{
	s64 rc = -1;
	int nbytes, stat;
	timeout_id_t tid;
	struct sockaddr_in addr_in;
	char *rx_buf;
	struct fd_set readfds;
	struct timeval tv;
	int timeout_cnt = 20;
	char* env_timeout_cnt;
	uint32_t host_ip;
	uint16_t port;
	const char* file_name;

	if(net_start() < 0) return -1;

	host_ip = host2ip(cfg->host);
	if(host_ip == 0) 
	{
		printf("can't get host ip : %s\n", cfg->host);
		return -1;
	}

	if(net_arp_process(host_ip) < 0)
		return -1;

	if(cfg->port == 0) port = TFTP_PORT_HOST;
	else port = cfg->port;
	file_name = cfg->filename;

	env_timeout_cnt = env_get(ENV_TFTPTIMEOUTCNT);
	if(env_timeout_cnt != NULL)
	{
		timeout_cnt = (int)strtoul(env_timeout_cnt, NULL, 0);
	}

	sock = lwip_socket(AF_INET, SOCK_DGRAM, 0);
	if(sock < 0) {
		printf("can't create socket !\n");
		return -1;
	}

	rx_buf = (char*)malloc(64*1024);

	memset(tftp_ctx, 0, sizeof(tftp_ctx_t));

	tftp_ctx->block_size	= TFTP_DEFAULT_BLOCK_SIZE;
	tftp_ctx->timeout		= TFTP_TIMEOUT;

	if(buf != NULL) {
		tftp_ctx->buf		= buf;
		tftp_ctx->put_data	= tftp_put_data;
	} else {
		tftp_ctx->put_data	= put_data;
	}
	tftp_ctx->verbose		= verbose;
	

	/* prepare TFTP server address */
	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_port        = htons(port);
	servaddr.sin_addr.s_addr = host_ip;

	if(send_request_packet(file_name) < 0)
	{
		printf("can't request file !\n");
		goto end;
	}

	set_timeout(&tid, 2*TFTP_TIMEOUT*1000);

	progress_start(&tftp_ctx->pi);

	while(1)
	{
		if(get_ctrl_c())
		{
			printf("\nInterrupted by ctrl + c\n");
			break;
		}
		poll_timer();

		if(verbose) progress_run(&tftp_ctx->pi);

		FD_ZERO(&readfds);
		FD_SET(sock, &readfds);
		tv.tv_sec	= 0;
		tv.tv_usec	= 100*1000;	/* 100ms */

		stat = lwip_select(sock+1, &readfds, NULL, NULL, &tv);

		if(stat > 0)
		{
			socklen_t addrlen = sizeof(addr_in);
			if((nbytes = lwip_recvfrom(sock, rx_buf, 64*1024, 0,
							(struct sockaddr*)&servaddr, &addrlen)) < 0)
			{
				printf("recvfrom error !\n");
				break;
			}

			switch(tftp_handler(rx_buf, nbytes))
			{
				case TFTP_STATE_OK:
					send_ack_packet(tftp_ctx->last_block_num);
					set_timeout(&tid, 2*tftp_ctx->timeout*1000);
					continue;

				case TFTP_STATE_FAIL:
					TFTP_DEBUG("TFTP_STATE_FAIL BLOCK=0x%x\n", tftp_ctx->last_block_num);
					rc = -1;
					goto end;

				case TFTP_STATE_END:
					send_ack_packet(tftp_ctx->last_block_num);
					progress_end(&tftp_ctx->pi);

					rc = tftp_ctx->pi.received_size;
					goto end;
			}
		}
		else if(stat == 0)
		{
			// time overflow
			if( is_timeout(&tid) )
			{
				if(--timeout_cnt < 0)
				{
					printf( "Time Overflow\n" );
					break;
				}
				else
				{
					printf("\nRetry(%d)...\n", timeout_cnt);
					send_ack_packet(tftp_ctx->last_block_num);
					set_timeout(&tid, 2*tftp_ctx->timeout*1000);
				}
			}
		}
		else
		{
			printf("select error\n");
			break;
		}
	}

end:
	free(rx_buf);
	lwip_close(sock);

	return rc;
}

s64 tftp_get(struct url_cfg* cfg, void *load_addr)
{
	return _tftp_get(cfg, load_addr, NULL, 1);
}

s64 tftp_get_ex(struct url_cfg* cfg, put_data_func *put_data)
{
	return _tftp_get(cfg, NULL, put_data, 0);
}

s64 tftp_download(uint32_t host_ip, ulong load_addr, const char *file_name)
{
	struct url_cfg cfg;

	memset(&cfg, 0, sizeof(cfg));
	strcpy(cfg.host, iptostr(host_ip));
	cfg.filename = file_name;

	return _tftp_get(&cfg, (void*)load_addr, NULL, 1);
}

s64 tftp_download_ex(uint32_t host_ip, const char *file_name, put_data_func *put_data)
{
	struct url_cfg cfg;

	memset(&cfg, 0, sizeof(cfg));
	strcpy(cfg.host, iptostr(host_ip));
	cfg.filename = file_name;

	return _tftp_get(&cfg, NULL, put_data, 0);
}

