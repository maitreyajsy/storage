/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <default.h>
#include <string.h>
#include <command.h>
#include <timer.h>
#include <net.h>
#include <thread.h>

#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"
#include "lwip/ip.h"
#include "lwip/dns.h"
#include "lwip/netdb.h"

#include "lwip/api_msg.h"
#include "lwip/tcpip.h"


#if LWIP_DNS

#define DNS_MSG_STATUS_WAIT			0
#define DNS_MSG_STATUS_DONE			1
#define DNS_MSG_STATUS_CANCLED		2

typedef struct dns_msg {
	const char *name;
	ip_addr_t *addr;
	sys_mutex_t mutex;
	volatile int status;
	err_t err;
} dns_msg_t;


static void _free_msg(dns_msg_t *msg)
{
	sys_mutex_free(&msg->mutex);
	free(msg);
}

static void _dns_found(const char *name, ip_addr_t *ipaddr, void *arg)
{
	dns_msg_t *msg = (dns_msg_t*)arg;
	int done = 0;
	
	LWIP_ASSERT("DNS response for wrong host name", strcmp(msg->name, name) == 0);
	LWIP_UNUSED_ARG(name);

	sys_mutex_lock(&msg->mutex);
	if(msg->status != DNS_MSG_STATUS_WAIT) done = 1;
	else
	{
		if (ipaddr == NULL) {
			/* timeout or memory error */
			msg->err = ERR_VAL;
		} else {
			/* address was resolved */
			msg->err = ERR_OK;
			*msg->addr = *ipaddr;
		}
		msg->status = DNS_MSG_STATUS_DONE;
	}
	sys_mutex_unlock(&msg->mutex);

	if(done) _free_msg(msg);
}

static void _gethostbyname(void *arg)
{
	dns_msg_t *msg = (dns_msg_t*)arg;

	msg->err = dns_gethostbyname(msg->name, msg->addr, _dns_found, msg);
	if (msg->err != ERR_INPROGRESS) {
		int done = 0;
		sys_mutex_lock(&msg->mutex);
		if(msg->status != DNS_MSG_STATUS_WAIT) done = 1;
		else msg->status = DNS_MSG_STATUS_DONE;
		sys_mutex_unlock(&msg->mutex);

		if(done) _free_msg(msg);
	}
}


uint32_t host2ip(const char *name)
{
#if 0
	struct dns_api_msg msg;
	err_t err;
	sys_sem_t sem;

	LWIP_ERROR("netconn_gethostbyname: invalid name", (name != NULL), return ERR_ARG;);
	LWIP_ERROR("netconn_gethostbyname: invalid addr", (addr != NULL), return ERR_ARG;);

	err = sys_sem_new(&sem, 0);
	if (err != ERR_OK) {
	return err;
	}

	msg.name = name;
	msg.addr = addr;
	msg.err = &err;
	msg.sem = &sem;

	tcpip_callback(do_gethostbyname, &msg);
	sys_sem_wait(&sem);
	sys_sem_free(&sem);

	return err;
#else
	dns_msg_t *msg;
	ip_addr_t addr;
	err_t err;
	int done = 0;

	msg = (dns_msg_t*)malloc(sizeof(dns_msg_t));
	if(msg == NULL) return -1;
	
	if(sys_mutex_new(&msg->mutex) != ERR_OK) 
		return -1;

	net_start();

	msg->name = name;
	msg->addr = &addr;
	msg->status = DNS_MSG_STATUS_WAIT;

	tcpip_callback(_gethostbyname, msg);

	while(msg->status == DNS_MSG_STATUS_WAIT) {
		if(get_ctrl_c()) break;
		msleep(5);
	}

	sys_mutex_lock(&msg->mutex);
	if(msg->status == DNS_MSG_STATUS_WAIT) {
		msg->status = DNS_MSG_STATUS_CANCLED;
		err = -ECANCELED;
	} else {
		done = 1;
		err = msg->err;
	}
	sys_mutex_unlock(&msg->mutex);

	if(done) _free_msg(msg);

	return (err == ERR_OK) ? (uint32_t)addr.addr : 0;
#endif
}


static int host2ip_cmd( int argc, char **argv )
{
	uint32_t ipaddr;
	ip_addr_t addr;

	if(argc < 2)
	{
		command_error(argv[0]);
		return -1;
	}

	ipaddr = host2ip(argv[1]);
	if(ipaddr == 0)
	{
		printf("can't get ip : %s\n", argv[1]);
		return -1;
	}	
	ip4_addr_set_u32(&addr, ipaddr);
	printf("%s : %s\n", argv[1], inet_ntoa(addr));

#if 0
	struct hostent	*myent;
	struct in_addr	myen;
	long int *add;

	myent = gethostbyname(argv[1]);
	if (myent == NULL)
	{
		printf("can't get ip : %s\n", argv[1]);
		return -1;
	}

	printf("%s\n", myent->h_name);
	while(*myent->h_addr_list != NULL)
	{
		add = (long int *)*myent->h_addr_list;
		myen.s_addr = *add;
		printf("%s\n", inet_ntoa(myen));
		myent->h_addr_list++;
	}
#endif

	return 0;
}
COMMAND(host2ip, host2ip_cmd, "get host ip", "<target domain name>");
#endif /* LWIP_DNS */

