/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <default.h>
#include <string.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <timer.h>
#include <net.h>
#include <progress.h>

#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"

/*
 * Refer to http://tools.ietf.org/html/rfc3659, http://tools.ietf.org/html/rfc959
 */

/*
4.2.2 Numeric Order List of Reply Codes
	110 Restart marker reply.
	    In this case, the text is exact and not left to the
	    particular implementation; it must read:
	         MARK yyyy = mmmm
	    Where yyyy is User-process data stream marker, and mmmm
	    server's equivalent marker (note the spaces between markers
	    and "=").
	120 Service ready in nnn minutes.
	125 Data connection already open; transfer starting.
	150 File status okay; about to open data connection.
	 200 Command okay.
	202 Command not implemented, superfluous at this site.
	211 System status, or system help reply.
	212 Directory status.
	213 File status.
	214 Help message.
	    On how to use the server or the meaning of a particular
	    non-standard command.  This reply is useful only to the
	    human user.
	215 NAME system type.
	    Where NAME is an official system name from the list in the
	   Assigned Numbers document.
	220 Service ready for new user.
	221 Service closing control connection.
	    Logged out if appropriate.
	225 Data connection open; no transfer in progress.
	226 Closing data connection.
	    Requested file action successful (for example, file
	    transfer or file abort).
	227 Entering Passive Mode (h1,h2,h3,h4,p1,p2).
	230 User logged in, proceed.
	250 Requested file action okay, completed.
	257 "PATHNAME" created.

	331 User name okay, need password.
	332 Need account for login.
	350 Requested file action pending further information.

	421 Service not available, closing control connection.
	    This may be a reply to any command if the service knows it
	    must shut down.
	425 Can't open data connection.
	426 Connection closed; transfer aborted.
	450 Requested file action not taken.
	    File unavailable (e.g., file busy).
	451 Requested action aborted: local error in processing.
	452 Requested action not taken.
	    Insufficient storage space in system.
	   500 Syntax error, command unrecognized.
	    This may include errors such as command line too long.
	501 Syntax error in parameters or arguments.
	502 Command not implemented.
	503 Bad sequence of commands.
	504 Command not implemented for that parameter.
	530 Not logged in.
	532 Need account for storing files.
	550 Requested action not taken.
	    File unavailable (e.g., file not found, no access).
	551 Requested action aborted: page type unknown.
	552 Requested file action aborted.
	    Exceeded storage allocation (for current directory or
	    dataset).
	553 Requested action not taken.
	    File name not allowed.
*/

/*
5.3.1. FTP COMMANDS

	The following are the FTP commands:

	USER <SP> <username> <CRLF>
	PASS <SP> <password> <CRLF>
	ACCT <SP> <account-information> <CRLF>
	CWD  <SP> <pathname> <CRLF>
	CDUP <CRLF>
	SMNT <SP> <pathname> <CRLF>
	QUIT <CRLF>
	REIN <CRLF>
	PORT <SP> <host-port> <CRLF>
	PASV <CRLF>
	TYPE <SP> <type-code> <CRLF>
	STRU <SP> <structure-code> <CRLF>
	MODE <SP> <mode-code> <CRLF>
	RETR <SP> <pathname> <CRLF>
	STOR <SP> <pathname> <CRLF>
	STOU <CRLF>
	APPE <SP> <pathname> <CRLF>
	ALLO <SP> <decimal-integer>
	    [<SP> R <SP> <decimal-integer>] <CRLF>
	REST <SP> <marker> <CRLF>
	RNFR <SP> <pathname> <CRLF>
	RNTO <SP> <pathname> <CRLF>
	ABOR <CRLF>
	DELE <SP> <pathname> <CRLF>
	RMD  <SP> <pathname> <CRLF>
	MKD  <SP> <pathname> <CRLF>
	PWD  <CRLF>
	LIST [<SP> <pathname>] <CRLF>
	NLST [<SP> <pathname>] <CRLF>
	SITE <SP> <string> <CRLF>
	SYST <CRLF>
	STAT [<SP> <pathname>] <CRLF>
	HELP [<SP> <string>] <CRLF>
	NOOP <CRLF>
*/

#if 0
#define FTP_DEBUG(fmt, args...)		printf("FTP DEBUG(%d) - "fmt, __LINE__, ##args)
#else
#define FTP_DEBUG(fmt, args...)		do{}while(0)
#endif

#define FTP_PORT_HOST				21		// Well known HTTP port #

#define FTP_CONNECTION_TIMEOUT		7000	/* 5 seconds */
#define FTP_READ_TIMEOUT			2000	/* 2 seconds */

#define FTP_TIMEOUT_DEC_INTERVAL	200

/** FTP Context */
struct ftp_ctx
{

	struct progress_info pi;
};

static struct ftp_ctx *ftp_ctx;

static int sock_ctrl;
static int sock_data;
static struct sockaddr_in addr_ctrl;
static struct sockaddr_in addr_data;


static int ftp_get_connection(struct sockaddr_in *addr)
{
	int sock;
	struct fd_set rfds, wfds;
	struct timeval tv;
	int rc = 0;
	int stat, val;

	sock = lwip_socket(AF_INET, SOCK_STREAM, 0);
	if(sock < 0)
	{
		printf("can't create socket !\n");
		return -1;
	}

	val = lwip_fcntl(sock, F_GETFL, 0);
	lwip_fcntl(sock, F_SETFL, (val | O_NONBLOCK));

	if(lwip_connect(sock, (struct sockaddr*)addr, sizeof(struct sockaddr_in)) < 0)
	{
		int timeout = FTP_CONNECTION_TIMEOUT;	/* timeout */
		while(1)
		{
			FD_ZERO(&rfds);
			FD_SET(sock, &rfds);
			wfds = rfds;

			tv.tv_sec	= 0;
			tv.tv_usec	= FTP_TIMEOUT_DEC_INTERVAL*1000;
			timeout -= FTP_TIMEOUT_DEC_INTERVAL;

			stat = lwip_select(sock+1, &rfds, &wfds, NULL, &tv);

			if(stat > 0) break;

			if(stat < 0){ rc = stat; break;}
			if(timeout <= 0){ rc = -ETIMEDOUT; break; }
			if(get_ctrl_c()){ rc = -ECANCELED; break; }	/* Canceld by user */
		}
	}

	if(rc < 0)
	{
		lwip_close(sock);
		return rc;
	}
	lwip_fcntl(sock, F_SETFL, val);
	return sock;
}

static int get_line(int sock, char *line, int len)
{
	int rc = 0, stat;
	char c;
	int idx = 0;
	struct fd_set readfds;
	struct timeval tv;
	int timeout;

	if(line == NULL || len <= 0)
		return -1;

	timeout = FTP_READ_TIMEOUT;
	while(1)
	{
		FD_ZERO(&readfds);
		FD_SET(sock, &readfds);

		tv.tv_sec	= 0;
		tv.tv_usec	= FTP_TIMEOUT_DEC_INTERVAL * 1000;
		timeout -= FTP_TIMEOUT_DEC_INTERVAL;

		stat = lwip_select(sock+1, &readfds, NULL, NULL, &tv);
		if(stat > 0)
		{
			timeout = FTP_READ_TIMEOUT;
			if((rc = lwip_read(sock, &c, 1)) <= 0)
			{
				FTP_DEBUG("lwip_read. rc:%d\n", rc);
				break;
			}

			if(c == '\n' && idx > 0 && line[idx-1] == '\r')
			{
				line[idx-1] = 0;
				return (idx-1);
			}
			else
			{
				line[idx++] = c;
				if(idx >= len)
				{
					line[idx-1] = 0;
					printf("line overflow.... line='%s'\n", line);
					return (idx-1);
				}
			}
		}
		else if(stat == 0)
		{
			if(timeout <= 0){ rc = -ETIMEDOUT; break; }
		}
		else
		{
			printf("select error\n");
			rc = stat;
			break;
		}

		if(get_ctrl_c()){ rc = -ECANCELED; break; }	/* Canceld by user */

	}

	return rc;
}


static int recv_reply(char* reply, int rsize)
{
	char msg[1024];
	int code;
	int len;

	/*
	 * 4.2. FTP REPLIES
	 */
	len = get_line(sock_ctrl, msg, 1024);
	if(len < 0) return 0;

	printf("%s\n", msg);
	if(len < 3) return 0;

	if(!isdigit(msg[0]) || !isdigit(msg[1]) || !isdigit(msg[2]))
		return 0;

	code = (int)(msg[0]-'0')*100 + (int)(msg[1]-'0')*10 + (int)(msg[2]-'0')*1;

	if(reply == NULL) rsize = 0;
	if(rsize > 0) rsize -= snprintf(reply, rsize, "%s", &msg[4]);

	if(msg[3] == '-')	/* it is multi-line replies */
	{
		/* The last line will begin with the same code, followed immediately by Space <SP> */
		char str_code[4];
		strncpy(str_code, msg, 3);
		str_code[3] = ' ';

		while(get_line(sock_ctrl, msg, 1024) >= 0)
		{
			printf("%s\n", msg);
			if(!strncmp(str_code, msg, 4))
			{
				if(rsize > 0) rsize -= snprintf(reply, rsize, "\n%s", &msg[4]);
				break;
			}
			else
			{
				if(rsize > 0) rsize -= snprintf(reply, rsize, "\n%s", msg);
			}
		}
	}

	return code;
}

#define send_command(fmt,args...)	send_command_ex(NULL, 0, fmt, ##args)
static int send_command_ex(char *reply, int rsize, const char* fmt, ...)
{
	char msg[512];

	va_list args;
	int n;

	va_start(args, fmt);
	n = vsnprintf(msg, 510, fmt, args);
	va_end(args);
	strcpy(msg+n, "\r\n");

	FTP_DEBUG("COMMAND:%s", msg);

	if(lwip_write(sock_ctrl, msg, n+2) < 0)
	{
		return -1;
	}

	return recv_reply(reply, rsize);
}

#define PASS_BUF_SIZE	256
/* getpass() is a variant of gets() with no echo */
static int getpass(char *s)
{
	int cnt = 0;
	char  c;

	while((c = getchar()) != ASCII_CR)
	{
		switch( c )
		{
			case ASCII_BS:
				if( cnt > 0 )
				{
					cnt--; *s-- = ' ';
				}
				break;
			case ASCII_HT:  //  Tab
				break;
			default:
				cnt++;
				*s++ = c;
				break;
		}

		if(cnt >= (PASS_BUF_SIZE-1))
			break;
	}
	*s = 0;

	return(cnt);
}

static int ftp_connect(const char* id, const char* pass)
{
	int code;
	char buff[PASS_BUF_SIZE];

	if((sock_ctrl = ftp_get_connection(&addr_ctrl)) < 0)
	{
		printf("can't connect to server(%d)\n",sock_ctrl);
		return -1;
	}

	// we will get the greeting message from the server
	code = recv_reply(NULL, 0);
	if(code != 220)
	{
		printf("Can't get the service ready reply : %d\n", code);
		return -1;
	}

	// login
	if(id[0] == 0) id = "anonymous";
	code = send_command("USER %s", id);
	if(code != 331) return -1;

	if(!strcmp(id, "anonymous"))
	{
		if (pass[0] == 0) pass = "ftp@lge.com";
	}
	else
	{
		if(pass[0] == 0)
		{
			printf("Password:");
			getpass(buff);
			pass = buff;
			printf("\n");
		}
	}
	code = send_command("PASS %s", pass);
	if(code != 230) return -1;

	// set basic options
//	send_command("SYST");
//	send_command("PWD");

	return 0;
}

static void ftp_close(void)
{
	if(sock_data > 0) lwip_close(sock_data);
	if(sock_ctrl > 0) lwip_close(sock_ctrl);
}

static int ftp_data_connection(void)
{
	int i, len;
	int v[6], valid;
	char str_msg[128];
	ip_addr_t ip_addr;

	if(send_command_ex(str_msg, 128, "PASV") != 227) return -1;
	/* When we send the PASV command, the server might respond with
	 * something similar to the following:
	 * 227 Entering Passive Mode (127,0,0,1,54,255) */
	len = strlen(str_msg);
	valid = 0;
	FTP_DEBUG("Parse '%s'\n", str_msg);
	for(i=0; i<len; i++)
	{
		/* Only check the digit and delimiters not brackets */
		if(isdigit(str_msg[i]))
		{
			int idx = 0;

			memset(v, 0, sizeof(v));
			v[idx] = str_msg[i] - '0';
			do {
				i++;
				if(isdigit(str_msg[i]))
				{
					v[idx] = v[idx]*10 + (str_msg[i] - '0');
					if(v[idx] > 255) break;
				}
				else if(str_msg[i] == ',' || str_msg[i] == '.' || str_msg[i] == ' ')	/* delimiter */
				{
					if(idx == 5){ valid = 1; break;}
					idx++;
				}
				else
				{
					if(idx == 5) valid = 1;
					break;	// unexpected character or end of port
				}
			} while(1);
		}
		if(valid) break;
	}
	if(!valid) return -1;

	FTP_DEBUG("DATA PORT = %d.%d.%d.%d:%d\n", v[0], v[1], v[2], v[3], (v[4] << 8) + v[5]);

	IP4_ADDR(&ip_addr, v[0], v[1], v[2], v[3]);

	memset(&addr_data, 0, sizeof(addr_data));
	addr_data.sin_family		= AF_INET;
	addr_data.sin_addr.s_addr	= ip4_addr_get_u32(&ip_addr);
	addr_data.sin_port			= htons((u16_t)((v[4] << 8) + v[5]));

	if((sock_data = ftp_get_connection(&addr_data)) < 0)
	{
		printf("can't connect to data port\n");
		return -1;
	}

	return 0;
}

static int get_pwd_str(char *buf, u32 size)
{
	u32 i = 0;
	char p[size];

	memset(p, 0, size);

	for(i = 0; i < size; i++)
	{
		if(buf[i] == '"')
		{
			strncpy(p, &(buf[i+1]), size);
			break;
		}
	}
	for(i = 0; i < size; i++)
	{
		if(p[i] == '"')
		{
			p[i] = 0;
			break;
		}
	}

	strncpy(buf, p, size);

	return 0;
}

static s64 ftp_request(const char *file_name)
{
	int len;
	char *name = NULL;
	char *dname, *fname;
	char str_msg[16];
	s64 rc = -1;
	char* root_dir = "/";
	char pwd[64];

	/* parse filename */
	len = strlen(file_name);
	if(len == 0) return -1;

	send_command_ex(pwd, 64, "PWD");
	get_pwd_str(pwd, 64);
	name = (char*)malloc(strlen(pwd) + strlen(file_name) + 1);
	memcpy(name, pwd, strlen(pwd));
	
	strcpy(&(name[strlen(pwd)]), file_name);

	fname = strrchr(name, '/');
	if(fname == NULL)
	{
		dname = root_dir;
		fname = name;
	}
	else
	{
		if(fname == name) dname = root_dir;		/* "/abc.txt" */
		else dname = name;
		*fname = '\0';
		fname++;
	}

	if(send_command("TYPE I") != 200) goto end;
	if(send_command("CWD %s", dname) != 250) goto end;

	rc = 0;
	if(send_command_ex(str_msg, 16, "SIZE %s", fname) == 213)
	{
		rc = strtoll(str_msg, NULL, 10);
		if(rc <= 0){ rc = -1; goto end; }
	}

	/* establish data connection. we only use passive mode for data transfer */
	if(ftp_data_connection() < 0)
	{
		rc = -1;
		goto end;
	}

	if(send_command("RETR %s", fname) != 150)
	{
		rc = -1;
		goto end;
	}

end:
	free(name);
	return rc;

}


s64 ftp_download(uint32_t host_ip, ulong load_addr, const char *file_name)
{
	struct url_cfg cfg;

	memset(&cfg, 0, sizeof(cfg));	
	strcpy(cfg.host, iptostr(host_ip));
	cfg.filename = file_name;

	return ftp_get(&cfg, (void*)load_addr);
}

s64 ftp_get(struct url_cfg* cfg, void *load_addr)
{
	s64 rc = -1;
	int nbytes, stat;
	char *rx_buf = NULL;

	struct fd_set readfds;
	struct timeval tv;
	s64 file_size;
	int timeout;
	uint32_t host_ip;
	uint16_t port;
	const char* file_name;

	if(net_start() < 0) return -1;

	host_ip = host2ip(cfg->host);
	if(host_ip == 0) 
	{
		printf("can't get host ip : %s\n", cfg->host);
		return -1;
	}

	if(net_arp_process(host_ip) < 0)
		return -1;

	if(cfg->port == 0) port = FTP_PORT_HOST;
	else port = cfg->port;
	file_name = cfg->filename;

	/* prepare server address */
	memset(&addr_ctrl, 0, sizeof(addr_ctrl));
	addr_ctrl.sin_family      	= AF_INET;
	addr_ctrl.sin_addr.s_addr	= host_ip;
	addr_ctrl.sin_port			= htons(port);

	sock_ctrl = sock_data = -1;

	ftp_ctx = (struct ftp_ctx*)malloc(sizeof(struct ftp_ctx));

	/* connect to server */
	if(ftp_connect(cfg->id, cfg->pass) < 0)
		goto end;

	if((file_size = ftp_request(file_name)) < 0)
		goto end;

	progress_start(&ftp_ctx->pi);
	
	ftp_ctx->pi.total_size = file_size;
	timeout = FTP_READ_TIMEOUT;
	rx_buf = (char*)load_addr;
	while(1)
	{
		if(get_ctrl_c())
		{
			printf("\nInterrupted by ctrl + c\n");
			break;
		}
		poll_timer();

		progress_run(&ftp_ctx->pi);

		FD_ZERO(&readfds);
		FD_SET(sock_data, &readfds);

		tv.tv_sec	= 0;
		tv.tv_usec	= FTP_TIMEOUT_DEC_INTERVAL*1000;	/* 100ms */
		timeout -= FTP_TIMEOUT_DEC_INTERVAL;

		stat = lwip_select(sock_data+1, &readfds, NULL, NULL, &tv);
		if(stat > 0)
		{
			timeout = FTP_READ_TIMEOUT;
			if((nbytes = lwip_read(sock_data, rx_buf, 32*1024)) < 0)
			{
				printf("read error !\n");
				break;
			}

			rx_buf += nbytes;
			ftp_ctx->pi.received_size += nbytes;

			if((ftp_ctx->pi.total_size == 0 && nbytes == 0) ||
				(ftp_ctx->pi.received_size >= ftp_ctx->pi.total_size))
			{
				progress_end(&ftp_ctx->pi);

				rc = ftp_ctx->pi.received_size;
				break;
			}
		}
		else if(stat == 0)
		{
			if(timeout <= 0)
			{
				printf("time out\n");
				rc = -ETIMEDOUT;
				break;
			}
		}
		else if(stat < 0)
		{
			printf("select error\n");
			break;
		}
	}

end:
	send_command("QUIT");
	ftp_close();
	free(ftp_ctx);

	return rc;
}

