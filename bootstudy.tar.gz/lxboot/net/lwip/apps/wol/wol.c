/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <default.h>
#include <string.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <timer.h>
#include <net.h>
#include <progress.h>

#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"


#define WOL_PORT		9

static int sock;
static struct sockaddr_in servaddr;

char host[512] = "10.178.37.255";

/* wol_send :

   this function is just for test

*/

static int wol_send(int argc, char **argv)
{

	uint32_t 	host_ip = 0xffffffff;
	uint16_t 	port = WOL_PORT;
	char 		data[1024];
	char		mac[6] = {0x80, 0xee ,0x73 ,0x28 ,0x30, 0x61};
	int			len, i;

	for(i = 0; i < 6; i++)
		data[i] = 0xff;

	for(i = 0; i < 16; i++)
	{
		memcpy((data+6) + (i*6), mac, 6);
	}

	len = 102;

	if(net_start() < 0) return -1;

#if 0
	host_ip = host2ip(host);
	if(host_ip == 0) 
	{
		printf("can't get host ip : %s\n", host);
		return -1;
	}

	if(net_arp_process(host_ip) < 0)
		return -1;
#endif

	sock = lwip_socket(AF_INET, SOCK_DGRAM, 0);
	if(sock < 0) {
		printf("can't create socket !\n");
		return -1;
	}

	/* prepare WOL host address */
	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_port        = htons(port);
	servaddr.sin_addr.s_addr = host_ip;

	if(lwip_sendto(sock, data, len, 0, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
	{
		printf("lwip_sendto error\n");
		return -1;
	}

	sys_msleep(10);

	lwip_close(sock);

	return 0;
}

COMMAND(wol, wol_send, "WOL", "");
