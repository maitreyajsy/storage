/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <default.h>
#include <string.h>
#include <env.h>
#include <command.h>
#include <util.h>
#include <timer.h>
#include <net.h>
#include <progress.h>

#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"


/*
 * Refer to http://www.w3.org/Protocols/rfc2616/rfc2616.html
 */

#if 0
#define HTTP_DEBUG(fmt, args...)		printf("[%d] : "fmt, __LINE__, ##args)
#else
#define HTTP_DEBUG(fmt, args...)		do{}while(0)
#endif


#define HTTP_PORT_HOST				80		// Well known HTTP port #

#define HTTP_CONNECTION_TIMEOUT		5000	/* 5 seconds */
#define HTTP_READ_TIMEOUT			2000	/* 2 seconds */

#define HTTP_TIMEOUT_DEC_INTERVAL	200

enum
{
	STATUS_OK			= 200,
	STATUS_BAD_REQUEST	= 400,
	STATUS_UNAUTHORIZED	= 401,
	STATUS_FORBIDDEN	= 403,
	STATUS_NOT_FOUND	= 404,
	STATUS_INTERNAL_SERVER_ERROR = 500,
	STATUS_SERVICE_UNAVAILABLE = 503,
};

struct http_header
{
	int	status_code;
	s64	content_length;
};

/** HTTP Context */
struct http_ctx
{

	struct progress_info info;
};


static int sock;
static struct sockaddr_in servaddr;


static struct http_ctx *http_ctx;

static const char* get_status_string(int status_code)
{
	struct {
		int code;
		const char* string;
	} status_list[] = {
		{STATUS_BAD_REQUEST,			"Bad Request"},
		{STATUS_UNAUTHORIZED,			"Unauthorized"},
		{STATUS_FORBIDDEN,				"Forbidden"},
		{STATUS_NOT_FOUND,				"Not Found"},
		{STATUS_INTERNAL_SERVER_ERROR,	"Internal Server Error"},
		{STATUS_SERVICE_UNAVAILABLE,	"Service Unavailable"},
		{-1,							"Unknown"}
	};
	int i;

	for(i=0; status_list[i].code != -1; i++)
	{
		if(status_list[i].code == status_code)
			break;
	}
	return status_list[i].string;
}

static int http_connect(void)
{
	struct fd_set rfds, wfds;
	struct timeval tv;
	int rc = 0;
	int stat, val;

	val = lwip_fcntl(sock, F_GETFL, 0);
	lwip_fcntl(sock, F_SETFL, (val | O_NONBLOCK));

	if(lwip_connect(sock, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0)
	{
		int timeout = HTTP_CONNECTION_TIMEOUT;	/* timeout */
		while(1)
		{
			FD_ZERO(&rfds);
			FD_SET(sock, &rfds);
			wfds = rfds;

			tv.tv_sec	= 0;
			tv.tv_usec	= HTTP_TIMEOUT_DEC_INTERVAL*1000;
			timeout -= HTTP_TIMEOUT_DEC_INTERVAL;

			stat = lwip_select(sock+1, &rfds, &wfds, NULL, &tv);

			if(stat > 0) break;
			else if(stat < 0){ rc = stat; break;}

			if(timeout <= 0){ rc = -ETIMEDOUT; break; }
			if(get_ctrl_c()) { rc = -ECANCELED; break; }	/* Canceld by user */
		}
	}
	if(rc < 0)
	{
		lwip_close(sock);
		return rc;
	}

	lwip_fcntl(sock, F_SETFL, val);
	return 0;
}

static int send_request(const char* host, const char* filename)
{
	char msg[512];

	snprintf(msg, 512, "GET %s HTTP/1.1\r\nHost: %s\r\n\r\n", filename, host);
	HTTP_DEBUG("HTTP REQ : '%s'\n", msg);

	if(lwip_write(sock, msg, strlen(msg)) < 0)
	{
		return -1;
	}

	return 0;
}

/* Parse http header */
static int parse_header(struct http_header* header)
{
	char line[1024];
	char c;
	int idx = 0;
	int rc = 0;
	char *token, *last;
	struct fd_set readfds;
	struct timeval tv;
	int stat, timeout;

	memset(header, 0, sizeof(*header));

	timeout = HTTP_READ_TIMEOUT;
	while(1)
	{
		FD_ZERO(&readfds);
		FD_SET(sock, &readfds);

		tv.tv_sec	= 0;
		tv.tv_usec	= HTTP_TIMEOUT_DEC_INTERVAL * 1000;
		timeout -= HTTP_TIMEOUT_DEC_INTERVAL;

		stat = lwip_select(sock+1, &readfds, NULL, NULL, &tv);
		if(stat > 0)
		{
			timeout = HTTP_READ_TIMEOUT;
			if((rc = lwip_read(sock, &c, 1)) <= 0)
			{
				printf("rc:%d\n", rc);
				break;
			}

			/* HTTP/1.1 defines the sequence CR LF as the end-of-line marker
			 * for all protocol elements except the entity-body
			 */
			if(c == '\n' && idx > 0 && line[idx-1] == '\r')
			{
				if(idx == 1) break;	// End of header

				line[idx-1] = 0;
				idx = 0;

				token = strtok_r(line, " ", &last);
				if(!strcmp(token, "HTTP/1.0") || !strcmp(token, "HTTP/1.1"))
				{
					token = strtok_r(NULL, " ", &last);
					header->status_code = atoi(token);
				}
				else if(!strcmp(token, "Content-Length:"))
				{
					token = strtok_r(NULL, " ", &last);
					header->content_length = strtoll(token, NULL, 10);
				}
				else
				{
					HTTP_DEBUG("TOKEN:%s\n", token);
				}
			}
			else
			{
				line[idx++] = c;
				if(idx >= 1024)
				{
					line[1023] = 0;
					printf("line overflow.... line='%s'\n", line);
					rc = -EOVERFLOW;
					break;
				}
			}
		}
		else if(stat == 0)
		{
			if(timeout <= 0){ rc = -ETIMEDOUT; break; }
		}
		else
		{
			printf("select error\n");
			rc = stat;
			break;
		}

		if(get_ctrl_c()){ rc = -ECANCELED; break; }	/* Canceld by user */

	}

	return rc;
}

s64 http_download(uint32_t host_ip, ulong load_addr, const char *file_name)
{
	struct url_cfg cfg;

	memset(&cfg, 0, sizeof(cfg));
	strcpy(cfg.host, iptostr(host_ip));
	cfg.filename = file_name;

	return http_get(&cfg, (void*)load_addr);
}

s64 http_get(struct url_cfg* cfg, void *load_addr)
{
	s64 rc = -1;
	int nbytes, stat;
	char *rx_buf = NULL;
	struct http_header http_header;
	struct fd_set readfds;
	struct timeval tv;
	uint32_t host_ip;
	uint16_t port;
	const char* file_name;

	if(net_start() < 0) return -1;

	host_ip = host2ip(cfg->host);
	if(host_ip == 0) 
	{
		printf("can't get host ip : %s\n", cfg->host);
		return -1;
	}

	if(net_arp_process(host_ip) < 0)
		return -1;

	if(cfg->port == 0) port = HTTP_PORT_HOST;
	else port = cfg->port;
	file_name = cfg->filename;


	sock = lwip_socket(AF_INET, SOCK_STREAM, 0);
	if(sock < 0)
	{
		printf("can't create socket !\n");
		return -1;
	}

	/* prepare HTTP server address */
	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_port        = htons(port);
	servaddr.sin_addr.s_addr = host_ip;

	http_ctx = (struct http_ctx*)malloc(sizeof(struct http_ctx));
	memset(http_ctx, 0, sizeof(*http_ctx));

	if(http_connect() < 0)
	{
		printf("can't connect to server.\n");
		goto end;
	}

	progress_start(&http_ctx->info);

	if(send_request(cfg->host, file_name) < 0)
	{
		printf("can't connect to server..\n");
		goto end;
	}

	if(parse_header(&http_header) < 0)
	{
		printf("can't parse header !\n");
		goto end;
	}

	if(http_header.status_code != STATUS_OK)
	{
		printf("STATUS CODE:%d(%s)\n", http_header.status_code, get_status_string(http_header.status_code));
		goto end;
	}
	HTTP_DEBUG("Content Length : %ld\n", http_header.content_length);

	http_ctx->info.total_size = http_header.content_length;
	rx_buf = (char*)load_addr;

	while(1)
	{
		if(get_ctrl_c())
		{
			printf("\nInterrupted by ctrl + c\n");
			break;
		}
		poll_timer();

		progress_run(&http_ctx->info);

		FD_ZERO(&readfds);
		FD_SET(sock, &readfds);
		tv.tv_sec	= 0;
		tv.tv_usec	= 1000*1000;	/* 1000ms */

		stat = lwip_select(sock+1, &readfds, NULL, NULL, &tv);
		if(stat > 0)
		{
			if((nbytes = lwip_read(sock, rx_buf, 64*1024)) < 0)
			{
				printf("read error !\n");
				break;
			}

			rx_buf += nbytes;
			http_ctx->info.received_size += nbytes;

			if((http_ctx->info.total_size == 0 && nbytes == 0) ||
				(http_ctx->info.received_size >= http_ctx->info.total_size))
			{
				progress_end(&http_ctx->info);

				rc = http_ctx->info.received_size;
				break;
			}
		}
		else if(stat == 0)
		{
			printf("time out\n");
			/* TODO: need process */
		}
		else
		{
			printf("select error\n");
			break;
		}
	}

end:
	lwip_close(sock);
	free(http_ctx);
	return rc;
}

