/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <default.h>
#include <command.h>
#include <string.h>
#include <timer.h>
#include <net.h>

#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/sockets.h"
#include "lwip/icmp.h"
#include "lwip/ip.h"
#include "lwip/inet_chksum.h"


#if 0
#define PING_DEBUG(fmt, args...)		printf("[%d] : "fmt, __LINE__, ##args)
#else
#define PING_DEBUG(fmt, args...)		do{}while(0)
#endif

/** ping try count */
#define PING_COUNT			3

/** max busy waiting time - in ms */
#define PING_MAX_LOOP_TIME	100

/** recevie time out - in ms */
#define PING_RCV_TIMEO		3000

/** ping delay - in milliseconds */
#define PING_DELAY			1000

/** ping identifier - must fit on a u16_t */
#define PING_ID        0xAFAF

/** ping additional data size to include in the packet */
#define PING_DATA_SIZE 32

/* ping variables */
static u16_t ping_seq_num;

/** Prepare a echo ICMP request */
static void ping_prepare_echo( struct icmp_echo_hdr *iecho, u16_t len)
{
	size_t i;
	size_t data_len = len - sizeof(struct icmp_echo_hdr);

	ICMPH_TYPE_SET(iecho, ICMP_ECHO);
	ICMPH_CODE_SET(iecho, 0);
	iecho->chksum = 0;
	iecho->id     = PING_ID;
	iecho->seqno  = htons(++ping_seq_num);

	/* fill the additional data buffer with some data */
	for(i = 0; i < data_len; i++) {
		((char*)iecho)[sizeof(struct icmp_echo_hdr) + i] = (char)i;
	}

	iecho->chksum = inet_chksum(iecho, len);
}

/* Ping using the socket ip */
static err_t ping_send(int s, ip_addr_t *addr)
{
	int err;
	struct icmp_echo_hdr *iecho;
	struct sockaddr_in to;
	size_t ping_size = sizeof(struct icmp_echo_hdr) + PING_DATA_SIZE;
	LWIP_ASSERT("ping_size is too big", ping_size <= 0xffff);

	iecho = (struct icmp_echo_hdr *)malloc(ping_size);
	if (!iecho) {
		return ERR_MEM;
	}

	ping_prepare_echo(iecho, (u16_t)ping_size);

	to.sin_len = sizeof(to);
	to.sin_family = AF_INET;
	inet_addr_from_ipaddr(&to.sin_addr, addr);

	err = lwip_sendto(s, iecho, ping_size, 0, (struct sockaddr*)&to, sizeof(to));

	free(iecho);

	return (err ? ERR_OK : ERR_VAL);
}

static int ping_recv(int s)
{
	char buf[64];
	int fromlen, len;
	struct sockaddr_in from;

	struct fd_set readfds;
	struct timeval tv;
	int stat;
	u32 tick;

	tick = timer_tick();

	while(1)
	{
		if(get_ctrl_c()) { return -ECANCELED; }

		FD_ZERO(&readfds);
		FD_SET(s, &readfds);
		tv.tv_sec	= 0;
		tv.tv_usec	= 100*1000; /* 100ms */

		stat = lwip_select(s+1, &readfds, NULL, NULL, &tv);
		if(stat > 0)
		{
			if((len = lwip_recvfrom(s, buf, sizeof(buf), 0, (struct sockaddr*)&from, (socklen_t*)&fromlen)) <= 0)
				return -EIO;

			if (len >= (int)(sizeof(struct ip_hdr)+sizeof(struct icmp_echo_hdr)))
			{
				struct ip_hdr *iphdr;
				struct icmp_echo_hdr *iecho;
			#if 0
				ip_addr_t fromaddr;
				inet_addr_to_ipaddr(&fromaddr, &from.sin_addr);
			#endif

				iphdr = (struct ip_hdr *)buf;
				iecho = (struct icmp_echo_hdr *)(buf + (IPH_HL(iphdr) * 4));
				if ((iecho->type == ICMP_ER) && (iecho->id == PING_ID)
						&& (iecho->seqno == htons(ping_seq_num)))
				{
					return 0;
				}
				else
				{
					PING_DEBUG("ping: drop\n");
				}
			}
		}
		else if(stat < 0)
		{
			return -EIO;
		}

		if(timer_elapsed(tick) > (PING_RCV_TIMEO*1000))
			return -ETIMEDOUT;
	}

}

static void ping_test(uint32_t target_ip)
{
	int s;
	int rc;
	ip_addr_t ping_target;
	int count = PING_COUNT;

	if ((s = lwip_socket(AF_INET, SOCK_RAW, IP_PROTO_ICMP)) < 0)
	{
		printf("can't create socket !\n");
		return;
	}

	while (count-- > 0)
	{
		ip4_addr_set_u32(&ping_target, target_ip);

		printf("ping %s ", ipaddr_ntoa(&ping_target));
		if (ping_send(s, &ping_target) == ERR_OK)
		{
			u32_t start, elapsed;

			start = timer_tick();
			rc = ping_recv(s);
			elapsed = timer_elapsed(start);

			if(rc == 0) {
				printf("time=%d.%03dms\n", elapsed/1000, elapsed%1000);
			} else if(rc == -ETIMEDOUT) {
				printf("timeout\n", elapsed);
			} else if(rc == -ECANCELED) {
				printf("cancelled\n");
				break;
			} else {
				printf("internal error : %d\n", rc);
				break;
			}
		}
		else
		{
			printf("error\n", ipaddr_ntoa(&ping_target));
		}

		int timeout = PING_DELAY;
		while(timeout > 0)
		{
			if(get_ctrl_c()){ count = 0; break; }

			sys_msleep(PING_MAX_LOOP_TIME);
			timeout -= PING_MAX_LOOP_TIME;
		}
	}

	lwip_close(s);
}

static int ping_cmd( int argc, char **argv )
{
	uint32_t ip_addr;

	if(argc < 2)
	{
		command_error(argv[0]);
		return -1;
	}

	ip_addr = strtoip(argv[1]);
	if(ip_addr == 0)
	{
		printf("invalid target ip !!!\n");
		return -1;
	}
	net_start();

	ping_test(ip_addr);

	return 0;
}
COMMAND(ping, ping_cmd, "PING", "<target ip>");

