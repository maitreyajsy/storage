#include <default.h>
#include <types.h>
#include <env.h>
#include <thread.h>
#include <timer.h>
#include <ethernet.h>
#include <net.h>
#include <util.h>

#include "lwip/init.h"
#include "lwip/sys.h"
#include "lwip/netif.h"
#include "lwip/ip.h"
#include "lwip/tcp.h"
#include "lwip/tcpip.h"
#include "lwip/dns.h"

#include "netif/etharp.h"
#include "netif/lxif.h"


static struct netif _netif;
static int net_inited;
static int dhcp_started;
static uint32_t arp_ip;



int net_arp_process(uint32_t host_ip)
{
	ip_addr_t find_ip;
	ip_addr_t *ip_ret;
	struct eth_addr *eth_ret;
	int     cnt;
	timeout_id_t tid;

	uint32_t local_ip = _netif.ip_addr.addr;
	uint32_t gateway_ip = _netif.gw.addr;
	uint32_t netmask = _netif.netmask.addr;

	if((local_ip&netmask) != (host_ip&netmask))
		host_ip = gateway_ip;

	arp_ip = host_ip;
	ip4_addr_set_u32(&find_ip, arp_ip);

	for(cnt = 0; cnt < 10; cnt++)
	{
		netifapi_arp_process(&_netif);

		set_timeout(&tid, 300);

		while(!is_timeout(&tid))
		{
			if(get_ctrl_c())
				return -1;
			poll_timer();

			if(etharp_find_addr(&_netif, &find_ip, &eth_ret, &ip_ret) >= 0)
				return 0;
		}
		msleep(10);
	}

	printf("^r^fail connect to server.\n");
	return -1;
}


/* to be call by tcp_ip thread through net_arp_process() */
err_t arp_process(struct netif *netif)
{
	err_t err = 0;
	
	ip_addr_t arp_target;

	ip4_addr_set_u32(&arp_target, arp_ip);

	err = etharp_request(&_netif, &arp_target);

	return err;

}

static inline void set_ip_addr(int dhcp, ip_addr_t *ipaddr, ip_addr_t *netmask, ip_addr_t *gateway)
{
	if(dhcp)
	{
		ip_addr_set_any(ipaddr);
		ip_addr_set_any(netmask);
		ip_addr_set_any(gateway);
	}
	else
	{
		ip4_addr_set_u32(ipaddr, env_get_ip(ENV_IPADDR));
		ip4_addr_set_u32(netmask, env_get_ip(ENV_NETMASK));
		ip4_addr_set_u32(gateway, env_get_ip(ENV_GATEWAYIP));
	}
}

#if LWIP_NETIF_STATUS_CALLBACK
static void status_callback(struct netif *netif)
{
	if(netif_is_up(netif))
	{

	}
	else
	{

	}
}
#endif

static void tcpip_init_done(void *arg)
{
	ip_addr_t ipaddr, netmask, gateway;
	sys_sem_t *sem = arg;
	int dhcp = !strcmp(env_get(ENV_DHCP), "on");

	set_ip_addr(dhcp, &ipaddr, &netmask, &gateway);
	netif_add(&_netif, &ipaddr, &netmask, &gateway, NULL, lxif_init, tcpip_input);
	netif_set_default(&_netif);

#if LWIP_NETIF_STATUS_CALLBACK
	netif_set_status_callback(&_netif, status_callback);
#endif

	if(dhcp)
	{
		dhcp_start(&_netif);
		dhcp_started = 2;
	}
	else
	{
#if LWIP_DNS
#define DEFAULT_DNS_SERVER	"156.147.1.1"
		ip_addr_t dnsserver;
		char *s;
		s = env_get(ENV_DNSSERVER);
		if(s == NULL) s = DEFAULT_DNS_SERVER;

		ipaddr_aton(s, &dnsserver);
		dns_setserver(0, &dnsserver);
#endif
		netif_set_up(&_netif);
		dhcp_started = 0;
	}
	sys_sem_signal(sem);
}

int net_start(void)
{
	sys_sem_t sem;

	if(net_inited)
	{
		ip_addr_t ipaddr, netmask, gateway;

		/*
		 * Caution !
		 * netif_set_addr, dhcp_start, dhcp_stop, and netif_set_down functions are lwIP core functions.
		 * They are not protected against concurrent access. So they must be called from the core thread only.
		 * When calling from other threads, we have to use the netifapi_xxxx functions defined in the netifapi.c
		 */
		if(!strcmp(env_get(ENV_DHCP), "on"))
		{
			if(!dhcp_started)
			{
				netifapi_netif_set_down(&_netif);
				set_ip_addr(1, &ipaddr, &netmask, &gateway);
				netifapi_netif_set_addr(&_netif, &ipaddr, &netmask, &gateway);

				netifapi_dhcp_start(&_netif);
				dhcp_started = 2;
			}
		}
		else
		{
			int netif_setup = 0;
			const uint8_t* env_mac_addr;
			
			if(dhcp_started)
			{
				netifapi_dhcp_stop(&_netif);
				dhcp_started = 0;
			}

			env_mac_addr = strtomac(env_get(ENV_ETHADDR));
			if(is_valid_mac_addr(env_mac_addr)) {
				if(memcmp(env_mac_addr, _netif.hwaddr, NETIF_MAX_HWADDR_LEN))
				{
					netifapi_netif_set_down(&_netif);
					eth_init(); 
					
					/* set MAC hardware address */
					memcpy(_netif.hwaddr, env_mac_addr, NETIF_MAX_HWADDR_LEN);
					netif_setup = 1;
				}
			}
			
			set_ip_addr(0, &ipaddr, &netmask, &gateway);
			if(!ip_addr_cmp(&_netif.ip_addr, &ipaddr) ||
				!ip_addr_cmp(&_netif.netmask, &netmask) ||
				!ip_addr_cmp(&_netif.gw, &gateway)) {
				netifapi_netif_set_addr(&_netif, &ipaddr, &netmask, &gateway);			
				netif_setup = 1;
			}

			if(netif_setup) netifapi_netif_set_up(&_netif);			
		}
	}
	else
	{
		if(eth_start() != 0)/* if eth_start() fail, do retry! */
			return  -1;
		if(sys_sem_new(&sem, 0) != ERR_OK)
		{
			LWIP_ASSERT("failed to create semaphore", 0);
			return -1;
		}
		tcpip_init(tcpip_init_done, &sem);
		sys_sem_wait(&sem);
		sys_sem_free(&sem);
		net_inited = 1;
	}

	/* wait for netif to be up */
	if(dhcp_started == 2)
	{
		printf("DHCP Processing");
		while(!netif_is_up(&_netif))
		{
			if(get_ctrl_c())
			{
				printf("\nInterrupted by ctrl + c\n");
				break;
			}
			msleep(100);
			printf(".");
		}
		printf("\n");

		if(netif_is_up(&_netif))
		{
			printf(" ip: %s", ipaddr_ntoa(&_netif.ip_addr));
			printf(" gw: %s", ipaddr_ntoa(&_netif.gw));
			printf(" netmask: %s\n\n", ipaddr_ntoa(&_netif.netmask));
		}
		dhcp_started = 1;
	}

	return 0;
}

