/*
 * Copyright (c) 2001-2003 Swedish Institute of Computer Science.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of the lwIP TCP/IP stack.
 *
 * Author: Adam Dunkels <adam@sics.se>
 *
 */

/*
 * Wed Apr 17 16:05:29 EDT 2002 (James Roth)
 *
 *  - Fixed an unlikely sys_thread_new() race condition.
 *
 *  - Made current_thread() work with threads which where
 *    not created with sys_thread_new().  This includes
 *    the main thread and threads made with pthread_create().
 *
 *  - Catch overflows where more than SYS_MBOX_SIZE messages
 *    are waiting to be read.  The sys_mbox_post() routine
 *    will block until there is more room instead of just
 *    leaking messages.
 */
#include "lwip/debug.h"

#include <default.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <thread.h>
#include <timer.h>

#include "lwip/sys.h"
#include "lwip/opt.h"
#include "lwip/stats.h"

#define UMAX(a, b)      ((a) > (b) ? (a) : (b))

static u32 starttime;


static struct sys_thread *threads = NULL;
static mutex_t threads_mutex;


#define SYS_MBOX_SIZE 128

struct sys_sem {
	unsigned int c;
	cond_t cond;
	mutex_t mutex;
};

struct sys_thread {
	struct sys_thread *next;
	thread_t *thread;
};

#if SYS_LIGHTWEIGHT_PROT
static pthread_mutex_t lwprot_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_t lwprot_thread = (pthread_t)0xDEAD;
static int lwprot_count = 0;
#endif /* SYS_LIGHTWEIGHT_PROT */

/*-----------------------------------------------------------------------------------*/
static struct sys_thread *
introduce_thread(thread_t *id)
{
	struct sys_thread *thread;

	thread = (struct sys_thread *)malloc(sizeof(struct sys_thread));

	if (thread != NULL) {
		mutex_lock(&threads_mutex);
		thread->next = threads;
		thread->thread = id;
		threads = thread;
		mutex_unlock(&threads_mutex);
	}

	return thread;
}
/*-----------------------------------------------------------------------------------*/
static int get_thread_cpu_id(const char *name)
{
	struct thread_cpu_id {
		const char *name;
		int cpuid;
	} thread_cpu_ids[] = {
		{NETIF_THREAD_NAME, NETIF_THREAD_CPUID},
		{TCPIP_THREAD_NAME, TCPIP_THREAD_CPUID},
	};
	int i;

	for(i=0; i<sizeof(thread_cpu_ids)/sizeof(struct thread_cpu_id); i++)
	{
		if(!strcmp(name, thread_cpu_ids[i].name))
			return thread_cpu_ids[i].cpuid;
	}
	return DEFAULT_THREAD_CPUID;
}

sys_thread_t
sys_thread_new(const char *name, lwip_thread_fn function, void *arg, int stacksize, int prio)
{
	struct sys_thread *st = NULL;
	thread_t *thread;
	thread_attr_t attr;

	init_thread_attribute(&attr);

	prio = (prio < THREAD_MIN_PRIORITY) ? THREAD_MIN_PRIORITY :
			(prio > THREAD_MAX_PRIORITY) ? THREAD_MAX_PRIORITY : prio;
	stacksize = (stacksize < THREAD_MIN_STACK_SIZE) ? THREAD_MIN_STACK_SIZE : stacksize;

	attr.priority = prio;
	attr.stack_size = stacksize;
	attr.cpu_id = get_thread_cpu_id(name);

	thread = thread_create(name, &attr, (int (*)(void *))function, arg);
	if (thread != NULL) {
		st = introduce_thread(thread);
	} else {
		LWIP_DEBUGF(SYS_DEBUG, ("sys_thread_new: pthread_create"));
		abort();
	}
	return st;
}
/*-----------------------------------------------------------------------------------*/
err_t
sys_mbox_new(struct sys_mbox **mb, int size)
{
	msg_t *mbox;
	LWIP_ASSERT("invalid mbox", (mb != NULL));

	mbox = (msg_t*)malloc(sizeof(msg_t));
	if(mbox == NULL) return ERR_MEM;

	size = (size > 0) ? size : 128;

	if(msg_init(mbox, size) < 0)
		return ERR_IF;

	SYS_STATS_INC_USED(mbox);
	*mb = (struct sys_mbox*)mbox;
	return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_free(struct sys_mbox **mb)
{
	msg_t *mbox;
	LWIP_ASSERT("invalid mbox", (mb != NULL) && (*mb != NULL));
	mbox = (msg_t*)*mb;

	SYS_STATS_DEC(mbox.used);

	msg_destroy(mbox);
	free(mbox);
	/*  LWIP_DEBUGF("sys_mbox_free: mbox 0x%lx\n", mbox); */
}
/*-----------------------------------------------------------------------------------*/
err_t
sys_mbox_trypost(struct sys_mbox **mb, void *msg)
{
	msg_t *mbox = (msg_t*)*mb;
	if(msg_send(mbox, msg) < 0)
		return ERR_MEM;
	return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
void
sys_mbox_post(struct sys_mbox **mb, void *msg)
{
	msg_t *mbox;
	LWIP_ASSERT("invalid mbox", (mb != NULL) && (*mb != NULL));
	mbox = (msg_t*)*mb;

	while(msg_send(mbox, msg) < 0) {
		LWIP_PLATFORM_DIAG(("msg full. I will modify !!!\n"));
		msleep(1);
	}
}
/*-----------------------------------------------------------------------------------*/
u32_t
sys_arch_mbox_tryfetch(struct sys_mbox **mb, void **msg)
{
	msg_t *mbox;
	LWIP_ASSERT("invalid mbox", (mb != NULL) && (*mb != NULL));
	LWIP_ASSERT("invalid msg", (msg != NULL));

	mbox = (msg_t*)*mb;

	if(msg_recv_timeout(mbox, msg, 0) < 0)
		return SYS_MBOX_EMPTY;

	return 0;
}
/*-----------------------------------------------------------------------------------*/
u32_t sys_arch_mbox_fetch(struct sys_mbox **mb, void **msg, u32_t timeout)
{
	int rc;
	int mtimeout;
	msg_t *mbox;
	LWIP_ASSERT("invalid mbox", (mb != NULL) && (*mb != NULL));
	mbox = (msg_t*)*mb;

	mtimeout = (timeout == 0) ? -1 : timeout;
	rc = msg_recv_timeout(mbox, msg, mtimeout);
	if(rc < 0) return SYS_ARCH_TIMEOUT;
	return (timeout - rc);		/* time (in milliseconds) waited for a message */
}
/*-----------------------------------------------------------------------------------*/
err_t
sys_sem_new(struct sys_sem **sem, u8_t count)
{
	struct sys_sem* s;
	LWIP_ASSERT("invalid sem", (sem != NULL));

	s = (struct sys_sem *)malloc(sizeof(struct sys_sem));
	if(s == NULL)
		return ERR_MEM;

	s->c = count;
	cond_init(&(s->cond));
	mutex_init(&(s->mutex));

	SYS_STATS_INC_USED(s);
	*sem = s;
	return ERR_OK;
}
/*-----------------------------------------------------------------------------------*/
u32_t sys_arch_sem_wait(struct sys_sem **s, u32_t timeout)
{
	int rc = 0;
	struct sys_sem *sem;
	LWIP_ASSERT("invalid sem", (s != NULL) && (*s != NULL));
	sem = *s;

	mutex_lock(&(sem->mutex));
	while (sem->c <= 0) {
		if (timeout > 0) {
			rc = cond_timedwait(&(sem->cond), &(sem->mutex), timeout);

			if (rc < 0) {
				mutex_unlock(&(sem->mutex));
				return SYS_ARCH_TIMEOUT;
			}
			/*      pthread_mutex_unlock(&(sem->mutex));
					return time_needed; */
		} else {
			cond_wait(&(sem->cond), &(sem->mutex));
		}
	}
	sem->c--;
	mutex_unlock(&(sem->mutex));
	return (timeout - rc);		/* time (in milliseconds) waited for the semaphore */
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_signal(struct sys_sem **s)
{
	struct sys_sem *sem;
	LWIP_ASSERT("invalid sem", (s != NULL) && (*s != NULL));
	sem = *s;

	mutex_lock(&(sem->mutex));
	sem->c++;

	if (sem->c > 1) {
		sem->c = 1;
	}

	cond_broadcast(&(sem->cond));
	mutex_unlock(&(sem->mutex));
}
/*-----------------------------------------------------------------------------------*/
void
sys_sem_free(struct sys_sem **sem)
{
	struct sys_sem *s;
	LWIP_ASSERT("invalid sem", (sem != NULL) && (*sem != NULL));
	s = *sem;
	cond_destroy(&(s->cond));
	mutex_destroy(&(s->mutex));
	free(s);
	SYS_STATS_DEC(sem.used);
}


/*-----------------------------------------------------------------------------------*/
err_t sys_mutex_new(struct sys_mutex **mutex)
{
	mutex_t *mtx;
	LWIP_ASSERT("invalid mutex", (mutex != NULL));
	mtx = (mutex_t*)malloc(sizeof(mutex_t));
	if(mtx == NULL) return ERR_MEM;

	if(mutex_init(mtx) < 0)
		return ERR_IF;
	SYS_STATS_INC_USED(mutex);
	*mutex = (struct sys_mutex *)mtx;
	return ERR_OK;
}

void sys_mutex_lock(struct sys_mutex **mutex)
{
	mutex_t *mtx;
	LWIP_ASSERT("invalid mutex", (mutex != NULL) && (*mutex != NULL));
	mtx = (mutex_t*)*mutex;

	mutex_lock(mtx);
}

void sys_mutex_unlock(struct sys_mutex **mutex)
{
	mutex_t *mtx;
	LWIP_ASSERT("invalid mutex", (mutex != NULL) && (*mutex != NULL));
	mtx = (mutex_t*)*mutex;

	mutex_unlock(mtx);
}

void sys_mutex_free(struct sys_mutex **mutex)
{
	mutex_t *mtx;
	LWIP_ASSERT("invalid mutex", (mutex != NULL) && (*mutex != NULL));
	mtx = (mutex_t*)*mutex;

	mutex_destroy(mtx);
	free(mtx);
	SYS_STATS_DEC(mutex.used);
}
/*-----------------------------------------------------------------------------------*/
static mutex_t sys_arch_mutex;

#define SYS_ARCH_PROTECT_OWNER_CHECK	1
#if SYS_ARCH_PROTECT_OWNER_CHECK
static thread_t* sys_prot_owner;
#endif
void sys_arch_protect(void)
{
	mutex_lock(&sys_arch_mutex);
#if SYS_ARCH_PROTECT_OWNER_CHECK
	sys_prot_owner = thread_self();
#endif
}

void sys_arch_unprotect(void)
{
#if SYS_ARCH_PROTECT_OWNER_CHECK
	LWIP_ASSERT("not my protection\n", sys_prot_owner == thread_self());
	sys_prot_owner = NULL;
#endif
	mutex_unlock(&sys_arch_mutex);
}
/*-----------------------------------------------------------------------------------*/
u32_t
sys_now(void)
{
	return timer_msec();
}
/*-----------------------------------------------------------------------------------*/
void
sys_init(void)
{
	mutex_init(&threads_mutex);
	mutex_init(&sys_arch_mutex);
	starttime = timer_msec();
}
/*-----------------------------------------------------------------------------------*/
#ifndef HZ
#define HZ 1000
#endif

u32_t
sys_jiffies(void)
{
	u32 jiffies;
	u32 elapsed = timer_msec() - starttime;

	if(HZ <= 1000) jiffies = elapsed/(1000/HZ);
	else jiffies = elapsed * (HZ/1000);

	return jiffies;
}

void sys_msleep(u32_t ms)
{
	msleep(ms);
}
