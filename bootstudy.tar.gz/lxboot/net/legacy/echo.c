/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <ethernet.h>
#include <net.h>

#include <util.h>
#include <command.h>

#include "legacyip.h"


static int echo_send_packet(ip_addr_t target)
{
	static u16		icmp_seq = 1;

	echo_packet_t	echo_packet;
	icmp_echo_t*	icmp_echo;

	icmp_echo = &echo_packet.icmp;

	icmp_echo->type		= ICMP_ECHO_REQUEST;
	icmp_echo->code		= 0;
	icmp_echo->chksum	= 0;
	icmp_echo->id		= 0;
	icmp_echo->seqno	= icmp_seq++;

	icmp_echo->chksum	= ~ ip_chksum(icmp_echo, sizeof(icmp_echo_t));


	set_ip_header(&echo_packet.ip, IPPROTO_ICMP, target, get_local_ip(),
					ICMP_TTL, sizeof(icmp_echo_t));

	set_eth_header((eth_t*)&echo_packet.eth, ETHTYPE_IP);
	eth_transmit(&echo_packet, sizeof(echo_packet));

	return 0;
}

static int echo_process(ip_addr_t target)
{
	uint8_t rx_buf[2048];
	ip_addr_t ip_addr;
	int cnt;
	timeout_id_t tid;

	ip_addr = get_local_ip();

	for(cnt=0; cnt<10; cnt++ )
	{
		echo_send_packet(target);

		set_timeout(&tid, 1000 );
		while( !is_timeout(&tid) )
		{
			if(get_ctrl_c())
				return -1;
			poll_timer();

			int len = eth_receive( rx_buf, 2048 );
			if(len > 0)
			{
				eth_t *eth = (eth_t*)rx_buf;

				if(eth->type == HTONS(ETHTYPE_IP))
				{
					ip_t*			ip;
					icmp_echo_t*	icmp_echo;

					ip = (ip_t*)eth->data;
					len -= sizeof(eth_t);

					if((len = ip_input(ip, len, ip_addr, IPPROTO_ICMP, (void**)&icmp_echo)) > 0)
					{
						if(icmp_echo->type == ICMP_ECHO_REPLY)
						{
							printf("OK.\n\n");
							//printf("Received the echo data from %s.\n\n", iptostr(target));
							return 0;
						}
					}

				}
			}
		}
	}

	printf("FAIL.\n");
	printf("Request timed out.\n\n" );
	return -1;
}


int ping_cmd( int argc, char **argv )
{
	uint32_t ip_addr;

	if(argc < 2)
	{
		command_error(argv[0]);
		return -1;
	}

	ip_addr = strtoip(argv[1]);
	if(ip_addr == 0)
	{
		printf("invalid target ip !!!\n");
		return -1;
	}

	net_start();
	printf("\nPinging %s : ", iptostr(ip_addr));
	if(arp_process(ip_addr) < 0)
	{
		printf("FAIL.\n");
		printf("Can't resolve the target hw address\n\n");
		return -1;
	}

	echo_process(ip_addr);

	return 0;
}

COMMAND(ping, ping_cmd, "PING Command", "<target ip>");
