/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <timer.h>
#include <stdio.h>
#include <string.h>
#include <ethernet.h>
#include <net.h>
#include <command.h>
#include <util.h>
#include <env.h>
#include <malloc.h>
#include <debug.h>
#include <progress.h>
#include <download.h>

#include "legacyip.h"

#if 0
#define TFTP_DEBUG(fmt, args...)		printf("[%d] : "fmt, __LINE__, ##args)
#else
#define TFTP_DEBUG(fmt, args...)		do{}while(0)
#endif

/*
RFC 1350 - The TFTP Protocol http://tools.ietf.org/html/rfc1350
RFC 2347 - TFTP Option Extension http://tools.ietf.org/html/rfc2347
RFC 2348 - TFTP Blocksize Option http://tools.ietf.org/html/rfc2348
RFC 2349 - TFTP Timeout Interval and Transfer Size Options http://tools.ietf.org/html/rfc2349

Type   Op # 	Format without header

	   2 bytes	  string   1 byte	  string   1 byte
	   -----------------------------------------------
RRQ/  | 01/02 |  Filename  |   0  |    Mode    |   0  |
WRQ    -----------------------------------------------
	   2 bytes	  2 bytes		n bytes
	   ---------------------------------
DATA  | 03	  |   Block #  |	Data	|
	   ---------------------------------
	   2 bytes	  2 bytes
	   -------------------
ACK   | 04	  |   Block #  |
	   --------------------
	   2 bytes	2 bytes 	   string	 1 byte
	   ----------------------------------------
ERROR | 05	  |  ErrorCode |   ErrMsg	|	0  |
	   ----------------------------------------
*/


/* Opcode */
#define TFTP_OPCODE_RRQ			1		/* Read request */
#define TFTP_OPCODE_WRQ			2		/* Write request */
#define TFTP_OPCODE_DATA		3		/* Read or write the next block of data */
#define TFTP_OPCODE_ACK			4		/* Acknowledgment */
#define TFTP_OPCODE_ERROR		5		/* Error message */
#define TFTP_OPCODE_OACK		6		/* option acknowledgment */

typedef struct
{
	ip_addr_t	local_ip_addr;
	u16			local_port;

	ip_addr_t	server_ip_addr;
	u16			server_port;

	u16			last_block_num;
	u32			block_wraps_count;

	/* tftp options */
	u16			block_size;
	u16			timeout;

	progress_info_t pi;

	void			*buf;
	put_data_func	*put_data;
	int				verbose;
} tftp_ctx_t;



typedef enum
{
	TFTP_STATE_NONE = 0,
	TFTP_STATE_FAIL,
	TFTP_STATE_OK,
	TFTP_STATE_END,
} tftp_state_t;


#define TFTP_PORT_HOST				69		// Well known TFTP port #
#define TFTP_DEFAULT_BLOCK_SIZE		512
#define TFTP_FAST_BLOCK_SIZE		32768	// max = 65535
#define TFTP_SLOW_BLOCK_SIZE		1468	// max = 65535

#define TFTP_TIMEOUT				5		// second unit

#define TFTP_FILE_MODE				"octet"


static tftp_ctx_t _tftp_ctx;
static tftp_ctx_t *tftp_ctx = &_tftp_ctx;

static int tftp_send_packet(tftp_packet_t* packet, int len)
{
	set_udp_header(&(packet->udp), tftp_ctx->server_port, tftp_ctx->local_port, len);

	set_ip_header(&(packet->ip), IPPROTO_UDP, tftp_ctx->server_ip_addr, tftp_ctx->local_ip_addr,
					UDP_TTL, sizeof(udp_t) + len);

	set_eth_header((eth_t*)&(packet->eth), ETHTYPE_IP);

	// transmit packet
	eth_transmit(packet, sizeof(udp_packet_t) + len);
	return 0;
}


/** RRQ(Read Request) Packet
 *
 */
static int make_RRQ_packet(tftp_t *tftp, const char *filename)
{
	int len;
	char* data = (char*)tftp->data;
	u16 blksize = TFTP_FAST_BLOCK_SIZE;
	char* env_blksize;

	env_blksize = env_get(ENV_TFTPBLKSIZE);
	if(env_blksize != NULL)
	{
		blksize = strtoul(env_blksize, NULL, 0);
		if(blksize < 512)
			blksize = 512;
		else if(blksize > 65535)
			blksize = 65535;
	}

	tftp->opcode = HTONS(TFTP_OPCODE_RRQ);

	//filename | mode
	len = sprintf(data, "%s%c%s", filename, 0, TFTP_FILE_MODE) + 1;

	//timeout
	len += sprintf(data + len, "%s%c%d", "timeout", 0, TFTP_TIMEOUT) + 1;

	//blocksize
	len += sprintf(data + len, "%s%c%d", "blksize", 0, blksize) + 1;

	//request total size
	len += sprintf(data + len, "%s%c0", "tsize", 0) + 1;

	return (len + 2);
}

/** Data Ack Packet
 *
 */
static int make_ACK_packet(tftp_t *tftp, uint16_t block_num)
{
	int len;
	uint16_t *data;

	tftp->opcode = HTONS(TFTP_OPCODE_ACK);
	len = 2;

	data = (uint16_t*)tftp->data;
	*data = HTONS(block_num);
	len += 2;

	return len;
}



static int tftp_handler(tftp_t *tftp, int len)
{
	u16	opcode;

	opcode = HTONS(tftp->opcode);
	switch ( opcode )
	{
		case TFTP_OPCODE_ERROR:
		{
			u16		err_code = net_get16(tftp->data);
			char*	err_msg = (char*)(tftp->data + 2);

			printf("\nTFTP Error[%d] : %s\n", err_code, err_msg);
			return TFTP_STATE_FAIL;
		}

		case TFTP_OPCODE_DATA:
		{
			u16 block_num	= net_get16(tftp->data);
			int data_size	= len - 4;					// opcode(2) + blocknum(2)
			u8*	src_data	= (u8*)(tftp->data + 2);	// tftp payload


			// ���� ũ�Ⱑ 0�� ��� ó��, block number�� 16bit���� wrap-around�� �߻���.
			if(block_num == 0 && tftp_ctx->last_block_num == 0xFFFF)
			{
				tftp_ctx->block_wraps_count++;
			}

			// ����Ÿ ���� ��ȣ�� �˻� �Ѵ�.
			if((u16)(tftp_ctx->last_block_num + 1) == block_num)
			{
				if(tftp_ctx->put_data(src_data, data_size) < 0)
					return TFTP_STATE_FAIL;

				tftp_ctx->last_block_num = block_num;
				tftp_ctx->pi.received_size += data_size;
			}
			else
			{
				//������ ��Ŷ�� �����۵Ǵ� ��찡 �����Ѵ�. server�� �ָ� ������ ���
				TFTP_DEBUG("lastblock=%d, received=%d\n", tftp_ctx->last_block_num, block_num);
				return TFTP_STATE_NONE;
			}

			// block size���� ���� ���� ��� ����Ÿ�� ���� ���̴�.
			if(data_size < tftp_ctx->block_size) return TFTP_STATE_END;
			return TFTP_STATE_OK;
		}

		case TFTP_OPCODE_OACK:
		{
		#if 0
			#define TFTP_OPTION_DEBUG(fmt, args...)		printf(fmt, ##args)
		#else
			#define TFTP_OPTION_DEBUG(fmt, args...)		do{}while(0)
		#endif

			#define MAX_OPTION_STRING_LEN	31
			char	*data;
			int		data_len;
			int		idx, max_str;
			char	option[MAX_OPTION_STRING_LEN + 1];
			char	value[MAX_OPTION_STRING_LEN + 1];

			idx = 0;

			data		= (char*)(tftp->data);
			data_len	= len;

			TFTP_OPTION_DEBUG("TFTP OACK : ");
			while(idx < data_len)
			{
				max_str = (data_len - idx) > MAX_OPTION_STRING_LEN ? MAX_OPTION_STRING_LEN : (data_len - idx);

				strncpy(option, (char*)&data[idx], max_str);
				option[max_str] = '\0';

				idx += (strlen(option) + 1);
				if(idx < data_len)
				{
					max_str = (data_len - idx) > MAX_OPTION_STRING_LEN ?
								MAX_OPTION_STRING_LEN : (data_len - idx);
					strncpy(value, (char*)&data[idx], max_str);
					value[max_str] = '\0';

					TFTP_OPTION_DEBUG("%s=%s\n", option, value);
					if(strcmp(option, "blksize") == 0)
					{
						tftp_ctx->block_size = (uint16_t)strtoul(value, NULL, 0);
					}
					else if(strcmp(option, "tsize") == 0)
					{
						tftp_ctx->pi.total_size = (uint32_t)strtoul(value, NULL, 0);
					}
					else if(strcmp(option, "timeout") == 0)
					{
						tftp_ctx->timeout = (uint16_t)strtoul(value, NULL, 0);
					}
					idx += (strlen(value) + 1);
				}

				if(data[idx] == 0)
					idx++;
			}
			TFTP_OPTION_DEBUG("\n");

			return TFTP_STATE_OK;
		}

		case TFTP_OPCODE_RRQ:
		case TFTP_OPCODE_WRQ:
		case TFTP_OPCODE_ACK: break;
		default       		: break;
	}

	return TFTP_STATE_NONE;
}

static int tftp_put_data(const void *buf, int size)
{
	if(size > 0) {
		u8* dst_data = (u8*)tftp_ctx->buf + tftp_ctx->pi.received_size;
		memcpy(dst_data, buf, size);
	}
	return 0;
}

static int _tftp_download(uint32_t host_ip, const char *file_name, void *buf, put_data_func *put_data, int verbose)
{
	uint8_t		tx_buf[2048];
	uint8_t		rx_buf[2048];
	int			len;

	tftp_packet_t *packet;

	int			size;
	int			timeout_cnt = 50;

	timeout_id_t tid;

	char* env_timeout_cnt;

	env_timeout_cnt = env_get(ENV_TFTPTIMEOUTCNT);
	if(env_timeout_cnt != NULL)	{
		timeout_cnt = (int)strtoul(env_timeout_cnt, NULL, 0);
	}

	if(net_start() < 0) return -1;

	memset(tftp_ctx, 0, sizeof(tftp_ctx_t));

	tftp_ctx->local_ip_addr	= get_local_ip();
	tftp_ctx->local_port	= 1024 + rand_num(3000);

	tftp_ctx->server_ip_addr	= host_ip;
	tftp_ctx->server_port	= TFTP_PORT_HOST;

	tftp_ctx->block_size	= TFTP_DEFAULT_BLOCK_SIZE;
	tftp_ctx->timeout		= TFTP_TIMEOUT;

	if(buf != NULL) {
		tftp_ctx->buf		= buf;
		tftp_ctx->put_data	= tftp_put_data;
	} else {
		tftp_ctx->put_data	= put_data;
	}
	tftp_ctx->verbose		= verbose;

//	set_host_ip(host_ip);

	if(arp_process(host_ip) < 0)
	{
		printf( " - Fail Network Infomation\n" );
		return -1;
	}

	printf(" HOST  IP : %s\n", iptostr(tftp_ctx->server_ip_addr));
	printf(" LOCAL IP : %s\n", iptostr(tftp_ctx->local_ip_addr));

	packet = (tftp_packet_t*)tx_buf;

	size = make_RRQ_packet(&(packet->tftp), file_name);
	tftp_send_packet(packet, size);

	set_timeout(&tid, TFTP_TIMEOUT*1000);

	progress_start(&tftp_ctx->pi);

	while(1)
	{
		if(get_ctrl_c())
		{
			printf("\nInterrupted by ctrl + c\n");
			break;
		}
		poll_timer();

		len = eth_receive(rx_buf, 2048);

		if(verbose) progress_run(&tftp_ctx->pi);

		if(len > 0)
		{
			eth_t*	eth = (eth_t*)rx_buf;
			ip_t*	ip;
			udp_t*	udp;

			if(eth->type == HTONS(ETHTYPE_ARP))
			{
				arp_t* arp = (arp_t*)eth->data;
				len -= sizeof(eth_t);

				arp_in(arp, len);
				continue;
			}

			if(eth->type != HTONS(ETHTYPE_IP))
				continue;

			ip = (ip_t*)eth->data;
			len -= sizeof(eth_t);

			if((len = ip_input(ip, len, tftp_ctx->local_ip_addr, IPPROTO_UDP, (void**)&udp)) > 0)
			{
				tftp_t *tftp;

				//TFTP_DEBUG("UDP Received. data=0x%08x, len=%d\n", udp, len);
				if(len < sizeof(udp_t) || len < HTONS(udp->len))
				{
					TFTP_DEBUG("invalid udp packet, len=%d, udp->len=%d\n", len, HTONS(udp->len));
					continue;
				}

				if(udp->dst != HTONS(tftp_ctx->local_port))
				{
					TFTP_DEBUG("not tftp data. port=%d\n", HTONS(udp->dst));
					continue;
				}
				tftp_ctx->server_port = HTONS(udp->src);

				tftp = (tftp_t*)(udp->data);
				len -= sizeof(udp_t);
				switch(tftp_handler(tftp, len))
				{
					case TFTP_STATE_OK:
						size = make_ACK_packet( &(packet->tftp), tftp_ctx->last_block_num);
						tftp_send_packet(packet, size);
						set_timeout(&tid, tftp_ctx->timeout*1000);
						continue;

					case TFTP_STATE_FAIL:
						TFTP_DEBUG("TFTP_STATE_FAIL BLOCK=0x%x\n", tftp_ctx->last_block_num);
						return -1;

					case TFTP_STATE_END:
						size = make_ACK_packet(&(packet->tftp), tftp_ctx->last_block_num);
						tftp_send_packet( packet, size);

						progress_end(&tftp_ctx->pi);
						return tftp_ctx->pi.received_size;
				}
			}

		}

		// time overflow
		if( is_timeout(&tid) )
		{
			if(--timeout_cnt < 0)
			{
				printf( "Time Overflow\n" );
				break;
			}
			else
			{
				printf("\nRetry(%d)...\n", timeout_cnt);
				size = make_ACK_packet( &packet->tftp , tftp_ctx->last_block_num);
				tftp_send_packet(packet, size);
				set_timeout(&tid, tftp_ctx->timeout*1000);
			}
		}

	}

	return -1;
}

int tftp_download(uint32_t host_ip, ulong load_addr, const char *file_name)
{
	return _tftp_download(host_ip, file_name, (void*)load_addr, NULL, 1);
}

int tftp_download_ex(uint32_t host_ip, const char *file_name, put_data_func *put_data)
{
	return _tftp_download(host_ip, file_name, NULL, put_data, 0);
}

int tftp_get(struct url_cfg* cfg, void *load_addr)
{
	uint32_t host_ip;
	if(cfg->port != 0) printf("Not support port option in legacy ip !\n");

	host_ip = host2ip(cfg->host);
	return tftp_download(host_ip, (ulong)load_addr, cfg->filename);
}

int tftp_get_ex(struct url_cfg* cfg, put_data_func *put_data)
{
	uint32_t host_ip;
	if(cfg->port != 0) printf("Not support port option in legacy ip !\n");

	host_ip = host2ip(cfg->host);
	return tftp_download_ex(host_ip, cfg->filename, put_data);
}

