/****************************************************************************************
 *   SIC R&D LAB., LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011,2012 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#ifndef _LEGACYIP_H_
#define _LEGACYIP_H_

#include <download.h>

typedef uint8_t	 eth_addr_t[6];
typedef uint32_t	 ip_addr_t;


#define ETHTYPE_IP		0x0800
#define ETHTYPE_ARP		0x0806
#define ETHTYPE_RARP	0x0835
#define ETHTYPE_IP6		0x86dd

typedef struct
{
	eth_addr_t  dst;
	eth_addr_t  src;
	u16		 type;
	u8 		 data[0];
} __attribute__ ((packed)) eth_t;



/*
 * ARP(Address Resolution Protocol)
 */
typedef struct
{
	uint16_t	 hwtype;
	uint16_t	 protocol;
	uint8_t	 hwlen;
	uint8_t	 protolen;
	uint16_t	 opcode;
	eth_addr_t  src_hwaddr;
	uint32_t	 src_ipaddr;
	eth_addr_t  dst_hwaddr;
	uint32_t	 dst_ipaddr;
} __attribute__ ((packed)) arp_t;

typedef struct
{
	eth_t		 eth;
	arp_t		 arp;
} __attribute__ ((packed)) arp_packet_t;

#define ARP_REQUEST			1
#define ARP_REPLY			2
#define RARP_REQUEST		3
#define RARP_REPLY			4

#define ARP_HWTYPE_ETH		1


/*
 * IP(Internet Protocol)
 */
#define IPPROTO_ICMP	1
#define IPPROTO_TCP		6
#define IPPROTO_UDP		17


#define IP_DF			0x4000        // Dont fragment flag
#define IP_MF			0x2000        // More fragments flag
#define IP_OFFMASK		0x1fff        // Mask for fragmenting bits

#define IP_VERSION		0x04

typedef struct
{
	u8 		 hl_v;		 // header length and version
	u8 		 tos;		 // type of service
	u16		 len;		 // total length
	u16		 id;		 // identification
	u16		 off;		 // flags and fragment offset
	u8 		 ttl;		 // time to live
	u8 		 proto; 	 // protocol
	u16		 chksum;	 // header checksum
	ip_addr_t	 src;		 // source IP address
	ip_addr_t	 dst;		 // destination IP address
	u8 		 data[0];	 // data
} __attribute__ ((packed)) ip_t;


#define IP_HDR_SIZE		(sizeof (ip_t))


#define IPH_HLEN(h)		(h->hl_v&0x0F)
#define IPH_VER(h)		((h->hl_v>>4)&0x0F)
#define IPH_OFF(h)		(h->off)

typedef struct
{
	eth_t		 ethernet;
	ip_t		 ip;
} __attribute__ ((packed)) ip_packet_t;



#define ICMP_TTL                255              // ICMP time to live
#define UDP_TTL                 255              // UDP time to live
#define TCP_TTL                 255              // TCP time to live

/*
 * ICMP(Internet Control Message Protocol)
 */
typedef struct
{
	u8 	  type;
	u8 	  code;
	u16	  chksum;
	u16	  id;
	u16	  seqno;
} __attribute__ ((packed)) icmp_echo_t;

#define ICMP_ECHO_REQUEST       8
#define ICMP_ECHO_REPLY         0

typedef struct
{
	eth_t			 eth;
	ip_t			 ip;
	icmp_echo_t	 icmp;
} __attribute__ ((packed)) echo_packet_t;


/*
 * UDP(User Datagram Protocol)
 */
typedef struct
{
	u16	 src;			 // source port.
	u16	 dst;			 // destination port.
	u16	 len;			 // length
	u16	 chksum;		 // checksum.
	char	 data[0];		 // data
} __attribute__ ((packed)) udp_t;

typedef struct
{
	eth_t	 eth;
	ip_t	 ip;
	udp_t	 udp;
} __attribute__ ((packed)) udp_packet_t;


//-------------------------------------------------------------------------------------------------
//  general UDP/IP data
//-------------------------------------------------------------------------------------------------
typedef struct
{
	eth_t		 eth;
	ip_t		 ip;
	udp_t		 udp;
	char		 appdata[0];	// dhcp app data
}
__attribute__ ((packed)) udp_app_t;


//-------------------------------------------------------------------------------------------------
//  TFTP
//-------------------------------------------------------------------------------------------------
typedef struct
{
	u16	 opcode;
	u8 	 data[0];
} __attribute__ ((packed)) tftp_t;

typedef struct
{
	eth_t		 eth;
	ip_t		 ip;
	udp_t		 udp;
	tftp_t		 tftp;
} __attribute__ ((packed)) tftp_packet_t;




//-------------------------------------------------------------------------------------------------
//  DHCP
//-------------------------------------------------------------------------------------------------
typedef struct
{
	eth_t		 eth;
	ip_t		 ip;
	udp_t		 udp;

	char		 appdata[0];	// dhcp app data
	u8 		 op;
	u8 		 htype;
	u8 		 hlen;
	u8 		 hops;
	u32		 xid;
	u16		 secs;
	u16		 flags;

	u32		 ciaddr;
	u32		 yiaddr;
	u32		 siaddr;
	u32		 giaddr;
	u8 		 chaddr[16];

	u8 		 bootp[192];	 /* reserved for the legacy bootp */
	u8 		 opt[316];		 /* DHCP option byte steream */
} __attribute__ ((packed)) dhcp_packet_t;

static inline u16 net_get16(const void *p)
{
	return get_be16(p);
}

static inline u32 net_get32(const void *p)
{
	return get_be32(p);
}



u16			ip_chksum(void *ptr, int len);
int			check_ipchksum(void *ptr, int len);

void		set_eth_header(eth_t *eth, uint16_t protocol);
void		set_ip_header(ip_t* ip, u16 protocol, ip_addr_t dst, ip_addr_t src, u8 ttl, u16 len);
void		set_udp_header(udp_t* udp, u16 dst, u16 src, u16 len);

int			ip_input(ip_t *ip, int len, ip_addr_t ipaddr, u16 protocol, void** data);

BOOL		net_check_udp_packet   ( udp_app_t* pkt, int len, uint32_t my_ip_addr, uint16_t my_port );

void		dhcp_reset(void);
BOOL		dhcp_start(void);

uint32_t	dhcp_get_ip_addr(void);
uint32_t	dhcp_get_netmask(void);
uint32_t	dhcp_get_gw_ip_addr(void);


int			arp_out(void);
int			arp_in(arp_t *arp, int len);
int			arp_process(ip_addr_t ip_addr);

uint8_t*	arp_get_target_ethaddr(void);


uint32_t	get_local_ip(void);
uint32_t	get_netmask(void);
uint32_t	get_gateway(void);
uint32_t	get_host_ip(void);
int			set_host_ip(uint32_t ip);


#endif
