/****************************************************************************************
 *   System IC Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   COPYRIGHT(c) 2011 by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work covered by this copyright hereon
 *   may be reproduced, stored in a retrieval system, in any form
 *   or by any means, electronic, mechanical, photocopying, recording
 *   or otherwise, without the prior written  permission of LG Electronics.
 ***************************************************************************************/

#include <types.h>
#include <stdio.h>
#include <string.h>
#include <debug.h>

#include <timer.h>
#include <ethernet.h>
#include <net.h>

#include <env.h>
#include <command.h>
#include <util.h>
#include <malloc.h>

#include "legacyip.h"


#define IP_MAX_PACKET_SIZE		65535
#define MAX_IP_FRAGMENT_QUEUE	4
#define IP_TIMER_INTERVAL		1000	/* 1 sec */

#define IP_FRAG_DATA_TTL		10		/* 10 sec */

#if 0
#define debug(fmt, args...)		printf(fmt, ##args)
#else
#define debug(fmt, args...)		do{}while(0)
#endif

#define error(fmt, args...)		printf("^r^"fmt, ##args)


typedef struct ip_frag_queue
{
	struct ip_frag_queue *next;
	u16 offset;
	u16 len;
} ip_frag_queue_t;

typedef struct
{
	u16				id;			// identification of IP
	u16				lastfrag;
	int				ttl;		// time to live
	ip_frag_queue_t	*ifq;
	u8				data[0];
} ip_frag_data_t;


static ip_frag_data_t* ip_frag_data[MAX_IP_FRAGMENT_QUEUE];
static u8 *ip_fragment_buf;
static int timer_id = -1;

static int free_ip_frag_data(ip_frag_data_t *ifd);

/*
 * Calculate the checksum
 */
uint16_t ip_chksum(void *ptr, int len)
{
	uint32_t	xsum;
	uint16_t*	p = (uint16_t*)ptr;

	len /= 2;

	xsum = 0;
	while (len-- > 0)
	{
		xsum += *p;
		p++;
	}

	xsum = (xsum & 0xffff) + (xsum >> 16);
	xsum = (xsum & 0xffff) + (xsum >> 16);

	return (uint16_t)(xsum & 0xffff);
}

/*
 * 1:valid
 */
int check_ipchksum(void *ptr, int len)
{
	return !((ip_chksum(ptr, len) + 1) & 0xfffe);
}


static void ip_timer(void* unsed)
{
	int i;

	for(i=0; i<MAX_IP_FRAGMENT_QUEUE; i++)
	{
		if(ip_frag_data[i] != NULL)
		{
			ip_frag_data[i]->ttl--;

			if(ip_frag_data[i]->ttl <= 0)
			{
				debug("discard fragments. id=0x%x\n", ip_frag_data[i]->id);
				free_ip_frag_data(ip_frag_data[i]);
				ip_frag_data[i] = NULL;
			}
		}
	}
}

/** start network module
 *
 *
 */
int net_start(void)
{
	if(ip_fragment_buf == NULL)
	{
		ip_fragment_buf = (u8*)malloc(IP_MAX_PACKET_SIZE);
	}

	if(timer_id == -1)
	{
		timer_id = add_timer(IP_TIMER_INTERVAL, 0, ip_timer, NULL);
	}

	if(eth_start() < 0) return -1;

	/* start DHCP. dhcp_start() will ignore the request if DHCP is not set */
	dhcp_start();

	return 0;
}

/** check UDP packet is valid or not
 *
 *	@param pkt [IN] UDP application data
 *	@paramalen [IN] size of UDP application packet
 *	@param my_ip_addr [IN] if you don't want to compare ip address, use -1
 *	@param my_port [IN] if you don't want to compare port, use -1
 */
BOOL net_check_udp_packet   ( udp_app_t* pkt, int len, uint32_t my_ip_addr, uint16_t my_port )
{
//#define	RET_ERR()	do { printf("%s:%d err\n", __FUNCTION__,__LINE__); return FALSE; } while(0)
#define		RET_ERR()	do { return FALSE; } while(0)

	if(len == 0 ) return FALSE;
    if(len < ( sizeof(eth_t) + sizeof( ip_t ) + sizeof( udp_t ) ) ) RET_ERR();
//	if(len < ( sizeof(eth_t) + HTONS( pkt->ip.len) ) ) RET_ERR();

    if((pkt->ip.hl_v & 0x0f) > 0x05)
    {
		RET_ERR();
    }

    if( ( pkt->ip.hl_v & 0xf0 ) != 0x40 ) RET_ERR();

    if( pkt->ip.off & HTONS(0x1fff)) RET_ERR();

    if(!check_ipchksum((char *) &pkt->ip, sizeof( pkt->ip )) ) RET_ERR();

    if( pkt->ip.proto != IPPROTO_UDP )	RET_ERR();

	if( pkt->eth.type == HTONS(ETHTYPE_ARP))
	{
		arp_t* arp = (arp_t*)pkt->eth.data;
		arp_in( arp, len - sizeof(eth_t));
		RET_ERR();
	}
	else if( pkt->eth.type == HTONS(ETHTYPE_RARP))
	{
		RET_ERR();
	}

	if(pkt->eth.type != HTONS(ETHTYPE_IP)) RET_ERR();

	/* check port */
	if( my_port != 0xffff && pkt->udp.dst != HTONS( my_port ) )
	{
//		printf("port mimatch: req %d - recv %d\n", my_port, NTOHS16(pkt->udp.dst));
		RET_ERR();
	}

	/* check ip addr */
    if( my_ip_addr != 0xffffffff && pkt->ip.dst != HTONL(my_ip_addr) )
	{
		 RET_ERR();
	}

	return TRUE;
}


void set_eth_header(eth_t *eth, u16 type)
{
	memcpy(eth->dst, arp_get_target_ethaddr(), sizeof(eth->dst));
	memcpy(eth->src, eth_getaddr(), sizeof(eth->src));

	eth->type = HTONS(type);
}

void set_ip_header(ip_t* ip, u16 protocol, ip_addr_t dst, ip_addr_t src, u8 ttl, u16 len)
{
	static u16	ip_id	= 0;

	if(len&1) ip->data[len] = 0; // if len is an odd number, pads 0 to end of the data to calcuate the checksum

	ip->hl_v	= 0x45;		// IP Version 4, Header Length = 20/4
	ip->tos		= 0;
	ip->len		= HTONS(sizeof(ip_t) + len);
	ip->id		= HTONS(ip_id);
	ip->off		= HTONS(0x0000);	// no fragmentation
	ip->ttl		= ttl;				// time to live
	ip->proto	= protocol;
	ip->chksum	= 0;

	memcpy(&ip->src, &src, 4);
	memcpy(&ip->dst, &dst, 4);

	ip->chksum	= ~ ip_chksum(ip, sizeof(ip_t));

	ip_id++;
}


void set_udp_header(udp_t* udp, u16 dst, u16 src, u16 len)
{
	udp->dst	= HTONS(dst);
	udp->src	= HTONS(src);
	udp->len	= HTONS(sizeof(udp_t) + len);
	udp->chksum	= 0;
}


/*
http://tools.ietf.org/html/rfc791

 0					 1					 2					 3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|Version|  IHL	|Type of Service|		   Total Length 		|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|		  Identification		|Flags| 	 Fragment Offset	|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|  Time to Live |	 Protocol	|		  Header Checksum		|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|						Source Address							|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|					 Destination Address						|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|					 Options					|	 Padding	|
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

				 Example Internet Datagram Header
*/

static int free_ip_frag_data(ip_frag_data_t *ifd)
{
	ip_frag_queue_t *ifq, *pifq;

	if(ifd == NULL) return -1;

	for(ifq = ifd->ifq; ifq != NULL;)
	{
		pifq = ifq;
		ifq = ifq->next;
		free(pifq);
	}
	free(ifd);

	return 0;
}

static int add_ip_frag_queue(ip_frag_data_t *ifd, u16 frag_offset, u16 len)
{
	ip_frag_queue_t *new_ifq, *ifq;

	for(ifq = ifd->ifq; ifq != NULL; ifq = ifq->next)
	{
		if(ifq->offset == frag_offset)
		{
		#if 0
			if(len != ifq->len)
			{
				printf("same fragment offset but different len !\n");
			}
		#endif
			return -2;
		}
	}
	new_ifq = (ip_frag_queue_t*)malloc(sizeof(ip_frag_queue_t));
	new_ifq->offset = frag_offset;
	new_ifq->len = len;
	new_ifq->next = NULL;


	if(ifd->ifq == NULL)	// first frgment, no queue
	{
		ifd->ifq = new_ifq;
	}
	else
	{
		if(ifd->ifq->offset > new_ifq->offset)	// new fragment is the first one
		{
			new_ifq->next = ifd->ifq;
			ifd->ifq = new_ifq;
		}
		else
		{
			for(ifq = ifd->ifq; ifq != NULL; ifq = ifq->next)
			{
				if(ifq->next == NULL)
				{
					ifq->next = new_ifq;
					break;
				}

				if(ifq->next->offset > new_ifq->offset)
				{
					new_ifq->next = ifq->next;
					ifq->next = new_ifq;
					break;
				}
			}
		}
	}

	return 0;
}

static int ip_frag(ip_t *ip, void** data)
{
#if 0
#define IP_FRAG_DEBUG(fmt, args...)		printf("IP_FRAG:"fmt, ##args)
#else
#define IP_FRAG_DEBUG(fmt, args...)		do{}while(0)
#endif

	int i, frag_idx;
	u16 frag_offset;
	u16 ip_off = NTOHS(IPH_OFF(ip));
	ip_frag_data_t *ifd = NULL;
	ip_frag_queue_t *ifq;
	int len;

	frag_idx = MAX_IP_FRAGMENT_QUEUE;
	for(i=0; i<MAX_IP_FRAGMENT_QUEUE; i++)
	{
		if(ip_frag_data[i] != NULL)
		{
			if(ip_frag_data[i]->id == ip->id)
			{
				ifd = ip_frag_data[i];
				frag_idx = i;
				break;
			}
		}
		else if(frag_idx == MAX_IP_FRAGMENT_QUEUE)
		{
			frag_idx = i;
		}
	}

	if(ifd == NULL)
	{
		if(frag_idx == MAX_IP_FRAGMENT_QUEUE)
		{
			error("no left fragment queue !!!\n");
			return -1;
		}
		ip_frag_data[frag_idx] = (ip_frag_data_t*)malloc(sizeof(ip_frag_data_t) + IP_MAX_PACKET_SIZE);
		ifd = ip_frag_data[frag_idx];

		//initialize
		memset(ifd, 0, sizeof(ip_frag_data_t));
		ifd->id		= ip->id;
		ifd->ttl	= IP_FRAG_DATA_TTL;
	}

#if 0
	if(sizeof(ip_t) != IPH_HLEN(ip)*4)
	{
		error("IP HL is different !!. [%d]\n", IPH_HLEN(ip)*4);
	}
#endif

	len = HTONS(ip->len) - sizeof(ip_t);
	frag_offset = (ip_off & IP_OFFMASK) << 3;

	IP_FRAG_DEBUG("id=%x, offset=%d, len=%d\n", ip->id, frag_offset, len);

	if(add_ip_frag_queue(ifd, frag_offset, len) < 0)
		return -2;


	memcpy(ifd->data + frag_offset, ip->data, len);

	if(!(ip_off & IP_MF))		// end of fragment
	{
		IP_FRAG_DEBUG("end of frag. frag_offset=%d\n", frag_offset);
		ifd->lastfrag = 1;
	}

	if(ifd->lastfrag)
	{
		u16 flen = 0;

		for(ifq = ifd->ifq; ifq != NULL; ifq = ifq->next)
		{
			if(flen != ifq->offset)
			{
				IP_FRAG_DEBUG("fragment swaped. next=%d, off=%d\n", flen, ifq->offset);
				return -3;
			}
			flen += ifq->len;
		}
		IP_FRAG_DEBUG("reassembled one fragmeted ip data, flen=%d\n", flen);

		memcpy(ip_fragment_buf, ifd->data, flen);
		*data = (void*)ip_fragment_buf;

		// empty queue
		free_ip_frag_data(ifd);
		ip_frag_data[frag_idx] = NULL;

		return flen;
	}

	return -1;

}


/*
 * ���ÿ� �������� protocol�� ���� ó���� ���� ��������
 * ���ϴ� protocol�� ���� data�� �����ϴ� ������ ���´�
 */
int ip_input(ip_t *ip, int len, ip_addr_t ipaddr, u16 protocol, void** data)
{
#if 0
#define IP_DEBUG(fmt, args...)		printf("IP:"fmt, ##args)
#else
#define IP_DEBUG(fmt, args...)		do{}while(0)
#endif

	u16 ip_len;
	u16 hdrlen;

	hdrlen = IPH_HLEN(ip) * 4;
	if(hdrlen < sizeof(ip_t))		// minimum header
	{
		IP_DEBUG("drop ip packet. header len=%d\n", hdrlen);
		return -1;
	}

	if(IPH_VER(ip) != IP_VERSION)
	{
		IP_DEBUG("drop ip packet. ip ver=%d\n", IPH_VER(ip));
		return -1;
	}

	ip_len = HTONS(ip->len);
	if(len < ip_len)
	{
		IP_DEBUG("drop ip packet. packet len=%d, ip->len=%d\n", len, ip_len);
		return -1;
	}


	// check checksum.
	if(!check_ipchksum(ip, sizeof(ip_t)))
	{
		IP_DEBUG("drop ip packet. checksum error\n");
		return -1;
	}

	if(memcmp(&ip->dst, &ipaddr, 4))
	{
	#if 0
		// do not consider broadcast ip
		IP_DEBUG("drop ip packet. not  mine\n");
		IP_DEBUG("local ip=%s\n", iptostr(ipaddr));
		IP_DEBUG("dest  ip=%s\n", iptostr(ip->dst));
		IP_DEBUG("src   ip=%s\n", iptostr(ip->src));
	#endif
		return -1;
	}

	if(ip->proto != protocol)
	{
		IP_DEBUG("unexpected protocol[%d]\n", ip->proto);
		return -2;
	}


	if(IPH_OFF(ip) & HTONS(IP_OFFMASK|IP_MF))
	{
		IP_DEBUG("ip fragmented data\n");
		return ip_frag(ip, data);
	}
	else
	{
		*data = ip->data;
		return (ip_len - sizeof(ip_t));
	}
}



uint32_t get_local_ip(void)
{
    if ( !strcmp( env_get(ENV_DHCP), "on") )	return dhcp_get_ip_addr();
	else										return env_get_ip(ENV_IPADDR);
}

uint32_t get_netmask(void)
{
    if ( !strcmp( env_get(ENV_DHCP), "on") )	return dhcp_get_netmask();
	else										return env_get_ip(ENV_NETMASK);
}

uint32_t get_gateway(void)
{
    if ( !strcmp( env_get(ENV_DHCP), "on") )	return dhcp_get_gw_ip_addr();
	else										return env_get_ip(ENV_GATEWAYIP);
}

uint32_t get_host_ip(void)
{
	return env_get_ip(ENV_SERVERIP);
}

int set_host_ip(uint32_t ip)
{
	return env_set_ip(ENV_SERVERIP, ip);
}

uint32_t host2ip(const char *name)
{
	if(!is_valid_ip(name)) return 0;
	return strtoip(name);
}

int http_get(struct url_cfg* cfg, void *load_addr)
{
	printf("Not support http in legacy ip !\n");
	return -1;
}

int http_download(uint32_t host_ip, ulong load_addr, const char *file_name)
{
	return http_get(NULL, NULL);
}

int ftp_get(struct url_cfg* cfg, void *load_addr)
{
	printf("Not support ftp in legacy ip !\n");
	return -1;
}

int ftp_download(uint32_t host_ip, ulong load_addr, const char *file_name)
{
	return ftp_get(NULL, NULL);
}
