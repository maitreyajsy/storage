#include <types.h>
#include <timer.h>
#include <debug.h>

#include <stdio.h>
#include <string.h>

#include <ethernet.h>
#include <net.h>

#include <command.h>
#include <util.h>

#include "legacyip.h"

#if 0
#define ARP_DEBUG(fmt, args...)		printf(fmt, ##args)
#else
#define ARP_DEBUG(fmt, args...)		do{}while(0)
#endif

static eth_addr_t	target_ethaddr;
static ip_addr_t	arp_target_ipaddr;

/*
TARGET HOST(server)�� ���� ethernet address(MAC)�� �����Ѵ�.
�ٸ� HOST�� ���� MAC�� �ʿ�ġ ������ �ʿ�� �߰� ���� �ʿ�
*/
uint8_t *arp_get_target_ethaddr(void)
{
	return target_ethaddr;
}

int arp_out(void)
{
	uint8_t tx_buf[2048];
	arp_packet_t* arp_pkt = (arp_packet_t*)tx_buf;

	memset(arp_pkt, 0, sizeof(arp_packet_t));

	arp_pkt->arp.opcode		= HTONS(ARP_REQUEST); /* ARP request. */
	arp_pkt->arp.hwtype		= HTONS(ARP_HWTYPE_ETH);
	arp_pkt->arp.protocol	= HTONS(ETHTYPE_IP);
	arp_pkt->arp.hwlen		= 6;
	arp_pkt->arp.protolen	= 4;

	memcpy(arp_pkt->arp.src_hwaddr, eth_getaddr(), sizeof(eth_addr_t));
	memset(arp_pkt->arp.dst_hwaddr, 0, sizeof(eth_addr_t));

	put32(get_local_ip(), &arp_pkt->arp.src_ipaddr);
	put32(arp_target_ipaddr, &arp_pkt->arp.dst_ipaddr);

	arp_pkt->eth.type = HTONS(ETHTYPE_ARP);
	memset(arp_pkt->eth.dst, 0xff, sizeof(eth_addr_t));	// broadcast
	memcpy(arp_pkt->eth.src, eth_getaddr(), sizeof(eth_addr_t));

	eth_transmit(arp_pkt, sizeof(arp_packet_t));

	return 0;
}


int arp_in(arp_t* arp, int len)
{
	uint8_t tx_buf[2048];
	uint32_t ipaddr;
	uint32_t local_ip = get_local_ip();

	if(len < sizeof(arp_t) ||
		arp->hwtype		!= HTONS(ARP_HWTYPE_ETH) ||
		arp->protocol	!= HTONS(ETHTYPE_IP) ||
		arp->hwlen		!= 6 ||
		arp->protolen	!= 4)
	{
		ARP_DEBUG("Invalid ARP Header !\n");
		return -1;
	}

	ipaddr = get32(&arp->dst_ipaddr);
	if(ipaddr != local_ip)
	{
		ARP_DEBUG("not my ip. %s\n", iptostr(ipaddr));
		return -2;
	}

	if(arp->opcode == HTONS(ARP_REPLY))
	{
		ipaddr = get32(&arp->src_ipaddr);
		ARP_DEBUG("ARP Reply. IP=%s, HWADDR=%s\n", iptostr(ipaddr), mactostr(arp->src_hwaddr));

		if(ipaddr != arp_target_ipaddr)
		{
			ARP_DEBUG("Not request[%s] IP.\n", iptostr(arp_target_ipaddr));
			return -3;
		}

		memcpy(target_ethaddr, arp->src_hwaddr, sizeof(eth_addr_t));
		return 1;
	}
	else if(arp->opcode == HTONS(ARP_REQUEST))
	{
		arp_packet_t* arp_pkt = (arp_packet_t*)tx_buf;

		ARP_DEBUG("ARP_REQUEST\n");

		memset(arp_pkt, 0, sizeof(arp_packet_t));
		arp_pkt->arp.opcode		= HTONS(ARP_REPLY);
		arp_pkt->arp.hwtype		= HTONS(ARP_HWTYPE_ETH);
		arp_pkt->arp.protocol	= HTONS(ETHTYPE_IP);
		arp_pkt->arp.hwlen		= 6;
		arp_pkt->arp.protolen	= 4;

		memcpy(arp_pkt->arp.src_hwaddr, eth_getaddr(), sizeof(eth_addr_t));
		memcpy(arp_pkt->arp.dst_hwaddr, arp->src_hwaddr, sizeof(eth_addr_t));

		ipaddr = get32(&arp->src_ipaddr);
		put32(local_ip, &arp_pkt->arp.src_ipaddr);
		put32(ipaddr, &arp_pkt->arp.dst_ipaddr);


		arp_pkt->eth.type = HTONS(ETHTYPE_ARP);
		memcpy(arp_pkt->eth.dst, arp->src_hwaddr, sizeof(eth_addr_t));
		memcpy(arp_pkt->eth.src, eth_getaddr(), sizeof(eth_addr_t));

		eth_transmit(arp_pkt, sizeof(arp_packet_t));
		return 0;
	}

	return -4;
}


int arp_process(ip_addr_t ip_addr)
{
	char    rx_buf[2048];
	int     cnt;
	int		rx_size;
	ip_addr_t netmask, local_ip;
	timeout_id_t tid;

	netmask = get_netmask();
	local_ip = get_local_ip();
	if((local_ip&netmask) != (ip_addr&netmask))
	{
		arp_target_ipaddr = get_gateway();
	}
	else
	{
		arp_target_ipaddr = ip_addr;
	}


	for(cnt=0; cnt<10; cnt++)
	{
		arp_out();

		set_timeout(&tid, 1000);

		while(!is_timeout(&tid))
		{
			if(get_ctrl_c())
				return -1;
			poll_timer();

			rx_size = eth_receive(rx_buf, 2048);
			if( rx_size > 0  )
			{
				eth_t *eth = (eth_t*)rx_buf;
				if(eth->type == HTONS(ETHTYPE_ARP))
				{
					arp_t* arp = (arp_t*)eth->data;
					if(arp_in(arp, rx_size - sizeof(eth_t)) > 0)
						return 0;
				}
			}
		}
	}

	return -1;
}


static int arp_cmd(int argc, char **argv)
{
	uint32_t target_ip;

	memset(target_ethaddr, 0, sizeof(target_ethaddr));

	if(argc == 1) target_ip = get_host_ip();
	else target_ip = strtoip(argv[1]);

	if(target_ip == 0)
	{
		printf("invalid target ip !!!\n");
		return -1;
	}

	if(net_start() < 0)
		return -1;

	printf("\nArping %s : ", iptostr(target_ip));
	if(arp_process(target_ip) == 0)
	{
		int i;

		printf("OK\n");
		printf("HW ADDRESS : ");
		for( i = 0; i<5 ; i++) printf("%02X:", target_ethaddr[i] & 0xFF );
		printf("%02X\n\n", target_ethaddr[i] & 0xFF );
	}
	else
	{
		printf("FAIL\n");
		printf("Can't resolve the hw address\n\n");
	}

	return 0;
}


COMMAND(arp, arp_cmd, "ARP Command", "[target]");
